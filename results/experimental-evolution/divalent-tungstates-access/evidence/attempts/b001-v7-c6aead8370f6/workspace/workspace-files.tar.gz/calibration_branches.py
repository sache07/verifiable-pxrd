from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "developed" / "r3_mn3teo6_2211528" / "developed.gpx"
OUT = ROOT / ".tmp" / "calibration"


def clear_bounds(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}


def fractions(project):
    hist = project.histogram(0)
    values = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(max(value, 0.0) for value in values.values())
    return {name: max(value, 0.0) / total for name, value in values.items()}


def covariance_summary(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    correlations = []
    if matrix.shape == (len(names), len(names)) and names:
        sigmas = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        denom = np.outer(sigmas, sigmas)
        corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
        for i in range(len(names)):
            for j in range(i + 1, len(names)):
                value = float(corr[i, j])
                if abs(value) >= 0.70:
                    correlations.append([names[i], names[j], value])
        correlations.sort(key=lambda row: abs(row[2]), reverse=True)
    values = np.asarray(covariance.get("variables", []), dtype=float)
    parameter_esds = {}
    if len(values) == len(names) and matrix.shape == (len(names), len(names)):
        for index, name in enumerate(names):
            if name in {":0:Zero", ":0:Shift"}:
                parameter_esds[name] = {
                    "value": float(values[index]),
                    "esd": float(np.sqrt(max(matrix[index, index], 0.0))),
                }
    return {
        "Rvals": covariance.get("Rvals", {}),
        "parameter_esds": parameter_esds,
        "high_correlations": correlations[:30],
    }


def refine(project, label):
    records = []
    for pass_index in range(3):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(project.histogram(0).get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
        }
        records.append(record)
        print(json.dumps({"branch": label, **record}), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    return records


def run_branch(name, zero_value, zero_refine, shift_value, shift_refine):
    destination = OUT / name / "calibrated.gpx"
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(destination))
    clear_bounds(project)
    hist = project.histogram(0)
    hist.InstrumentParameters["Zero"][1] = float(zero_value)
    hist.InstrumentParameters["Zero"][2] = bool(zero_refine)
    hist.SampleParameters["Shift"] = [float(shift_value), bool(shift_refine)]
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    records = refine(project, name)
    hist = project.histogram(0)
    summary = {
        "name": name,
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "zero_refined": bool(hist.InstrumentParameters["Zero"][2]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "shift_refined": bool(hist.SampleParameters["Shift"][1]),
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "passes": records,
        "covariance": covariance_summary(project),
    }
    (destination.parent / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    return summary


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    summaries = [
        run_branch("shift_only", 0.0, False, -522.0, True),
        run_branch("zero_only", 0.08, True, 0.0, False),
        run_branch("zero_and_shift", 0.08, True, -522.0, True),
        run_branch("fixed_none", 0.0, False, 0.0, False),
    ]
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2, default=str) + "\n")
    print(json.dumps([
        {
            "name": row["name"], "Rwp_percent": row["Rwp_percent"],
            "zero_deg": row["zero_deg"], "shift_um": row["shift_um"],
            "calibration_esds": row["covariance"]["parameter_esds"],
        }
        for row in summaries
    ], indent=2))


if __name__ == "__main__":
    main()
