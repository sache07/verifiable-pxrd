from pathlib import Path

from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif")


def cif_path(identifier):
    return CIF_ROOT / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def main():
    reference = CifParser(str(cif_path("1528915")), occupancy_tolerance=2).parse_structures(primitive=False)[0]
    neutron = CifParser(str(cif_path("2311041")), occupancy_tolerance=2).parse_structures(primitive=False)[0]
    matcher = StructureMatcher(
        ltol=0.3, stol=0.5, angle_tol=10,
        primitive_cell=False, scale=False, attempt_supercell=False,
    )
    mapped = matcher.get_s2_like_s1(reference, neutron)
    if mapped is None:
        raise RuntimeError("could not map neutron WO3 parent into the selected P21/c supercell")
    # Swap the transformed a/c axes while reversing b to retain a right-handed
    # basis. This gives the same conventional setting as COD 1528915.
    mapped.make_supercell([[0, 0, 1], [0, -1, 0], [1, 0, 0]])
    target = Lattice.monoclinic(
        7.302016789690313, 7.5418444570788985, 7.691845364413137,
        90.85651330495722,
    )
    adapted = Structure(
        target, mapped.species, mapped.frac_coords,
        coords_are_cartesian=False, to_unit_cell=True,
    )
    output = ROOT / "candidates" / "WO3_p21c_2311041_neutron_adapted.cif"
    # Emit the same explicit P21/n setting and tag conventions as the working
    # COD 1528915 reference. This avoids an importer remap to conventional
    # P21/c after the neutron parent has already been transformed.
    symmetrized = SpacegroupAnalyzer(adapted, symprec=1.0e-3).get_symmetrized_structure()
    representatives = [adapted[group[0]] for group in symmetrized.equivalent_indices]
    representatives.sort(key=lambda site: (site.specie.symbol != "W", *site.frac_coords))
    cell = adapted.lattice
    lines = [
        "data_WO3_neutron_2311041_adapted",
        "_chemical_formula_sum 'O3 W'",
        "_space_group_IT_number 14",
        "_symmetry_space_group_name_Hall '-P 2yn'",
        "_symmetry_space_group_name_H-M 'P 1 21/n 1'",
        f"_cell_length_a {cell.a:.10f}",
        f"_cell_length_b {cell.b:.10f}",
        f"_cell_length_c {cell.c:.10f}",
        f"_cell_angle_alpha {cell.alpha:.10f}",
        f"_cell_angle_beta {cell.beta:.10f}",
        f"_cell_angle_gamma {cell.gamma:.10f}",
        "_cell_formula_units_Z 8",
        "loop_",
        "_symmetry_equiv_pos_as_xyz",
        "x,y,z",
        "-x+1/2,y+1/2,-z+1/2",
        "-x,-y,-z",
        "x-1/2,-y-1/2,z-1/2",
        "loop_",
        "_atom_site_label",
        "_atom_site_type_symbol",
        "_atom_site_fract_x",
        "_atom_site_fract_y",
        "_atom_site_fract_z",
        "_atom_site_occupancy",
        "_atom_site_U_iso_or_equiv",
    ]
    counts = {"W": 0, "O": 0}
    for site in representatives:
        element = site.specie.symbol
        counts[element] += 1
        x, y, z = site.frac_coords % 1.0
        lines.append(
            f"{element}{counts[element]} {element} {x:.10f} {y:.10f} {z:.10f} 1 0.005"
        )
    output.write_text("\n".join(lines) + "\n")
    print({
        "output": str(output), "formula": adapted.composition.reduced_formula,
        "space_group": adapted.get_space_group_info(),
        "cell": adapted.lattice.parameters, "sites": len(adapted),
    })


if __name__ == "__main__":
    main()
