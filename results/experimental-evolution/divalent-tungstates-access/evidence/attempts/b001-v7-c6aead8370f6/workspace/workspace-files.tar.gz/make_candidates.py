from pathlib import Path
import json

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
LIB = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif')
SPECS = [
    ('r3_mn3teo6_2211528', '2211528', {'Te': 'W'}),
    ('r3_cd3teo6_2242674', '2242674', {'Cd': 'Mn', 'Te': 'W'}),
    ('c2c_co3teo6_2015468', '2015468', {'Co': 'Mn', 'Te': 'W'}),
    ('pa3_cu3wo6_1527404', '1527404', {'Cu': 'Mn'}),
    ('p21c_ca3wo6_1563081', '1563081', {'Ca': 'Mn'}),
]
INDEXED_R3_A = 8.8932755236
INDEXED_R3_C = 10.4528300819
INDEXED_R3_VOLUME_PER_FORMULA = Lattice.hexagonal(
    INDEXED_R3_A, INDEXED_R3_C).volume / 10.0


def path_for(cid):
    return LIB / cid[0] / cid[1:3] / cid[3:5] / f'{cid}.cif'


def main():
    out = ROOT / 'candidates'
    out.mkdir(exist_ok=True)
    records = []
    for name, cid, mapping in SPECS:
        source = path_for(cid)
        structure = Structure.from_file(source, primitive=False)
        structure.replace_species(mapping)
        destination = out / f'Mn3WO6_{name}.cif'
        CifWriter(structure, symprec=1e-3, refine_struct=False,
                  significant_figures=10).write_file(destination)
        adapted = structure.copy()
        _, formula_units = adapted.composition.get_reduced_composition_and_factor()
        if name.startswith('r3_'):
            adapted.lattice = Lattice.hexagonal(INDEXED_R3_A, INDEXED_R3_C)
        else:
            adapted.scale_lattice(INDEXED_R3_VOLUME_PER_FORMULA * formula_units)
        adapted_destination = out / f'Mn3WO6_{name}_adapted.cif'
        CifWriter(adapted, symprec=1e-3, refine_struct=False,
                  significant_figures=10).write_file(adapted_destination)
        screen_destination = adapted_destination
        if name.startswith('p21c_'):
            # The source's nonstandard P21/n operator setting is rejected by
            # GSAS-II's CIF reader. P1 expansion preserves its exact powder
            # structure for a diagnostic topology comparison.
            screen_destination = out / f'Mn3WO6_{name}_adapted_p1.cif'
            expanded = Structure(adapted.lattice, [site.species for site in adapted],
                                 adapted.frac_coords)
            CifWriter(expanded, symprec=None, significant_figures=10).write_file(
                screen_destination)
        records.append({
            'name': name, 'target_formula': structure.composition.reduced_formula,
            'parent_cod_id': cid, 'parent_path': str(source),
            'substitutions': mapping, 'candidate_path': str(destination),
            'adapted_candidate_path': str(adapted_destination),
            'screen_candidate_path': str(screen_destination),
            'adaptation': {
                'method': ('indexed R-3 target cell' if name.startswith('r3_')
                           else 'isotropic scale to indexed R-3 volume per Mn3WO6'),
                'indexed_r3_a_A': INDEXED_R3_A,
                'indexed_r3_c_A': INDEXED_R3_C,
                'target_volume_per_formula_A3': INDEXED_R3_VOLUME_PER_FORMULA,
            },
            'space_group': structure.get_space_group_info(symprec=1e-3),
            'sites': len(structure),
            'cell': {'a': structure.lattice.a, 'b': structure.lattice.b,
                     'c': structure.lattice.c, 'alpha': structure.lattice.alpha,
                     'beta': structure.lattice.beta, 'gamma': structure.lattice.gamma},
        })
    (out / 'provenance.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(records, indent=2))


if __name__ == '__main__':
    main()
