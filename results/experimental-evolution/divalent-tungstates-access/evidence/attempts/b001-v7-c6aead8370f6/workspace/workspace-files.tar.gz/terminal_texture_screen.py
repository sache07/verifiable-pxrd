from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "terminal_base" / "base.gpx"
OUT = ROOT / ".tmp" / "terminal_texture_screen"
AXES = (None, [0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def clear_flags(project):
    hist = project.histogram(0)
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "


def md_esd(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if "1:0:MD" not in names or matrix.shape != (len(names), len(names)):
        return None
    index = names.index("1:0:MD")
    return float(np.sqrt(max(matrix[index, index], 0.0)))


def run_branch(axis):
    label = "none" if axis is None else "".join(map(str, axis))
    directory = OUT / label
    directory.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(directory / "texture.gpx"))
    clear_flags(project)
    hist = project.histogram(0)
    hist.InstrumentParameters["SH/L"][1] = 0.02
    hist.InstrumentParameters["SH/L"][2] = False
    po = project.phases()[1].data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, axis is not None, [0, 0, 1] if axis is None else list(axis)
    records = []
    for pass_index in range(3):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 15)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "MD_ratio": float(po[1]),
            "MD_esd": md_esd(project),
            "shift_um": float(hist.SampleParameters["Shift"][0]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(map(str, project.get_Frozen())),
        }
        records.append(record)
        print(json.dumps({"axis": axis, **record}), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    clear_flags(project)
    project.save()
    summary = {
        "axis": axis, "Rwp_percent": float(hist.get_wR()),
        "MD_ratio": float(po[1]), "shift_um": float(hist.SampleParameters["Shift"][0]),
        "records": records,
    }
    (directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run_branch(axis) for axis in AXES]
    results.sort(key=lambda row: row["Rwp_percent"])
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
