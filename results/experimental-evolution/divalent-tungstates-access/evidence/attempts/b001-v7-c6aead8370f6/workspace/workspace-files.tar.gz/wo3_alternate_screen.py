from __future__ import annotations

import copy
import json
from pathlib import Path
import re

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "background_screen" / "chebyshev_10" / "background.gpx"
CANDIDATE = ROOT / "candidates" / "WO3_p21c_2311041_neutron_adapted.cif"
OUT = ROOT / ".tmp" / "wo3_alternate"
DESTINATION = OUT / "alternate.gpx"
COORD = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def clear_special_flags(project):
    hist = project.histogram(0)
    for parameter in hist.InstrumentParameters.values():
        if isinstance(parameter, list) and len(parameter) > 2:
            parameter[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap:
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][2] = [False, False, False]
            hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "


def state(project, candidate):
    hist = project.histogram(0)
    hap = candidate.data["Histograms"][hist.name]
    return {
        "cell": candidate.get_cell(),
        "scale": float(hap["Scale"][0]),
        "size_um": float(hap["Size"][1][0]),
        "mustrain_type": hap["Mustrain"][0],
        "mustrain_values": list(map(float, hap["Mustrain"][1][:2])),
        "MD_ratio": float(hap["Pref.Ori."][1]),
        "Uiso_A2": float(candidate.atoms()[0].uiso),
    }


def normalized_shifts(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    shifts = {str(key): float(value) for key, value in covariance.get("Rvals", {}).get("lastShifts", {}).items()}
    rows = []
    if matrix.shape == (len(names), len(names)):
        sigmas = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        for index, name in enumerate(names):
            if name in shifts and sigmas[index] > 0:
                rows.append([name, shifts[name], float(sigmas[index]), abs(shifts[name]) / sigmas[index]])
    rows.sort(key=lambda row: row[3], reverse=True)
    return rows[:20]


def run(project, candidate, stage, records, cycles=15):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
        "largest_shift_ratios": normalized_shifts(project),
        "candidate": state(project, candidate),
    }
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def stable(record):
    return record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]


def refine_until(project, candidate, stage, records, passes=3):
    record = None
    for pass_index in range(passes):
        record = run(project, candidate, f"{stage}_{pass_index + 1}", records)
        if stable(record):
            break
    return record


def coordinate_atoms(record, pid, ratio_threshold=1.0):
    atoms = set()
    for variable in record["frozen"]:
        match = COORD.match(variable)
        if match and int(match.group(1)) == pid:
            atoms.add(int(match.group(2)))
    for variable, _, _, ratio in record["largest_shift_ratios"]:
        match = COORD.match(variable)
        if match and int(match.group(1)) == pid and ratio > ratio_threshold:
            atoms.add(int(match.group(2)))
    return atoms


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    clear_special_flags(project)
    hist = project.histogram(0)
    original = project.phases()[1]
    original_hap = original.data["Histograms"][hist.name]
    weighted_scale = float(original.data["General"]["Mass"]) * float(original_hap["Scale"][0])
    candidate = project.add_phase(
        str(CANDIDATE), phasename="WO3_gamma_neutron_2311041",
        histograms=[hist], fmthint="CIF",
    )
    project.index_ids()
    pid = int(candidate.data["pId"])
    candidate_hap = copy.deepcopy(original_hap)
    candidate_hap["Use"] = True
    candidate_hap["Scale"] = [weighted_scale / float(candidate.data["General"]["Mass"]), True]
    candidate.data["Histograms"][hist.name] = candidate_hap
    original_hap["Use"] = False
    original_hap["Scale"][1] = False
    original.clear_refinements({"Cell": True})
    candidate.set_refinements({"Cell": True})
    for atom in candidate.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.015013802268774638
        atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
        atom.refinement_flags = " "
    variables = [f"{pid}::AUiso:{index}" for index in range(len(candidate.atoms()))]
    if len(variables) > 1:
        project.add_EquivConstr(variables, reloadIdx=False)
    project.set_Controls("parmMin", 0.003, variable=variables[0])
    project.set_Controls("parmMax", 0.020, variable=variables[0])
    project.set_Controls("parmMin", max(candidate_hap["Scale"][0] * 0.2, 0.0), variable=f"{pid}:0:Scale")
    project.set_Controls("parmMax", candidate_hap["Scale"][0] * 5.0, variable=f"{pid}:0:Scale")
    project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;a")
    project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
    cell = candidate.get_cell()
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    source_coordinates = [tuple(map(float, atom.coordinates)) for atom in candidate.atoms()]
    for atom_index, source in enumerate(source_coordinates):
        for axis, value, length in zip("xyz", source, lengths):
            project.set_Controls("parmMin", value - 0.10 / length, variable=f"{pid}::dA{axis}:{atom_index}")
            project.set_Controls("parmMax", value + 0.10 / length, variable=f"{pid}::dA{axis}:{atom_index}")

    records = []
    refine_until(project, candidate, "initial_cell_scale_background", records)
    excluded = set()
    for oxygen, label in ((False, "heavy"), (True, "oxygen")):
        for atom_index, atom in enumerate(candidate.atoms()):
            is_oxygen = atom.element.strip().upper() in {"O", "O-2"}
            atom.refinement_flags = "X" if is_oxygen == oxygen else " "
        record = refine_until(project, candidate, f"candidate_{label}_coordinates", records)
        excluded.update(coordinate_atoms(record, pid))
        for atom_index in excluded:
            candidate.atoms()[atom_index].coordinates = source_coordinates[atom_index]
    for pass_index in range(4):
        for atom_index, atom in enumerate(candidate.atoms()):
            atom.refinement_flags = " " if atom_index in excluded else "X"
        record = run(project, candidate, f"candidate_joint_coordinates_{pass_index + 1}", records)
        unstable = coordinate_atoms(record, pid)
        if unstable:
            excluded.update(unstable)
            for atom_index in excluded:
                candidate.atoms()[atom_index].coordinates = source_coordinates[atom_index]
            continue
        if stable(record):
            break
    for atom in candidate.atoms():
        atom.refinement_flags = "U"
    refine_until(project, candidate, "candidate_common_uiso", records)
    for atom in candidate.atoms():
        atom.refinement_flags = " "
    candidate_hap["Size"][2] = [True, False, False]
    candidate_hap["Mustrain"][2] = [True, True, False]
    refine_until(project, candidate, "candidate_profile", records)
    candidate_hap["Size"][2] = [False, False, False]
    candidate_hap["Mustrain"][2] = [False, False, False]
    candidate_hap["Pref.Ori."][2] = True
    refine_until(project, candidate, "candidate_texture", records)
    candidate_hap["Pref.Ori."][2] = False
    for name in ("U", "W", "X"):
        hist.InstrumentParameters[name][2] = True
    refine_until(project, candidate, "common_profile", records)
    for name in ("U", "W", "X"):
        hist.InstrumentParameters[name][2] = False
    clear_special_flags(project)
    refine_until(project, candidate, "final_settle", records)
    project.save()
    summary = {
        "baseline_Rwp_percent": float(G2.G2Project(gpxfile=str(SOURCE)).histogram(0).get_wR()),
        "alternate_Rwp_percent": float(hist.get_wR()),
        "excluded_coordinate_atoms": sorted(excluded),
        "state": state(project, candidate),
        "short_contacts": [list(row) for row in candidate.ShortDistances(useAll=False)],
        "records": records,
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
