from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "wo3_alternate" / "alternate.gpx"
OUT = ROOT / ".tmp" / "selected"
DESTINATION = OUT / "selected.gpx"
MNWO4 = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif/1/52/02/1520200.cif")
WO3 = ROOT / "candidates" / "WO3_p21c_2311041_neutron_adapted.cif"
MN3WO6 = ROOT / "candidates" / "Mn3WO6_r3_mn3teo6_2211528_adapted.cif"


def install_bounds(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    for name, low, high in (
        ("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10), ("Polariz.", 0.5, 1.0),
        ("Zero", -0.25, 0.25),
    ):
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    hist = project.histogram(0)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        project.set_Controls("parmMin", max(0.2 * scale, 0.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(5.0 * scale, 1.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;a")
        project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(0.01 * abs(value), 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        for atom_index in range(len(phase.atoms())):
            variable = f"{pid}::AUiso:{atom_index}"
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    source = G2.G2Project(gpxfile=str(SOURCE))
    source_hist = source.histogram(0)
    source_phases = [source.phases()[0], source.phases()[3], source.phases()[2]]

    project = G2.G2Project(newgpx=str(DESTINATION))
    hist = project.add_powder_histogram(
        str(ROOT / ".tmp" / "pattern.xye"), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    phases = [
        project.add_phase(str(MNWO4), phasename="MnWO4_wolframite", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(WO3), phasename="WO3_gamma_monoclinic", histograms=[hist], fmthint="CIF"),
        project.add_phase(str(MN3WO6), phasename="Mn3WO6_rhombohedral", histograms=[hist], fmthint="CIF"),
    ]
    project.index_ids()
    hist.data["Instrument Parameters"] = copy.deepcopy(source_hist.data["Instrument Parameters"])
    hist.data["Sample Parameters"] = copy.deepcopy(source_hist.data["Sample Parameters"])
    hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    hist.data["Limits"] = copy.deepcopy(source_hist.data["Limits"])
    hist.data["Reflection Lists"] = {}

    for phase, old_phase in zip(phases, source_phases):
        phase.data["General"]["Cell"] = copy.deepcopy(old_phase.data["General"]["Cell"])
        phase.data["Histograms"][hist.name] = copy.deepcopy(old_phase.data["Histograms"][source_hist.name])
        phase.data["Histograms"][hist.name]["Use"] = True
        for atom, old_atom in zip(phase.atoms(), old_phase.atoms()):
            atom.coordinates = tuple(map(float, old_atom.coordinates))
            atom.occupancy = float(old_atom.occupancy)
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(old_atom.uiso)
            atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6
            atom.refinement_flags = " "
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False

    # Recreate the per-phase common Uiso constraints with the new phase IDs.
    project.data["Constraints"]["data"] = {"Hist": [], "HAP": [], "Phase": [], "Global": []}
    for phase in phases:
        pid = int(phase.data["pId"])
        variables = [f"{pid}::AUiso:{index}" for index in range(len(phase.atoms()))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)

    # Keep only the accepted active set for the replay settle.
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for name, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = name == "Shift"
    hist.Background[0][1] = True
    install_bounds(project)
    project.set_Controls("cycles", 15)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    summary = {
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
        "phase_names": [phase.name for phase in phases],
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "short_contacts": {phase.name: [list(row) for row in phase.ShortDistances(useAll=False)] for phase in phases},
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
