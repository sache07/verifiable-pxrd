from pathlib import Path
import json
import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
MNWO4 = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif/1/52/02/1520200.cif')


def report(gpx, stage):
    h = gpx.histogram(0)
    p = gpx.phase(0)
    hap = p.data['Histograms'][h.name]
    cov = gpx.data.get('Covariance', {}).get('data', {})
    row = {
        'stage': stage,
        'Rwp': h.get_wR(),
        'cell': p.get_cell(),
        'instrument': {k: h.InstrumentParameters[k][1] for k in
                       ('Zero', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'Polariz.')},
        'sample': {k: h.SampleParameters[k][0] for k in
                   ('Shift', 'SurfRoughA', 'SurfRoughB')},
        'scale': hap['Scale'][0],
        'size': hap['Size'][:3],
        'mustrain': hap['Mustrain'][:3],
        'converged': cov.get('Rvals', {}).get('converged'),
        'max_shift_esd': cov.get('Rvals', {}).get('Max shft/sig'),
        'frozen': list(gpx.get_Frozen()),
    }
    print(json.dumps(row, default=lambda x: x.tolist() if hasattr(x, 'tolist') else str(x)), flush=True)


def run_stage(gpx, name, cycles=8):
    gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
    gpx.set_Controls('cycles', cycles)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()
    report(gpx, name)


def main():
    G2.SetPrintLevel('error')
    out = ROOT / '.tmp' / 'mnwo4_single.gpx'
    gpx = G2.G2Project(newgpx=str(out))
    h = gpx.add_powder_histogram(str(ROOT / '.tmp' / 'pattern.xye'),
                                 str(ROOT / 'instrument.instprm'), fmthint='xye')
    p = gpx.add_phase(str(MNWO4), phasename='MnWO4_wolframite',
                      histograms=[h], fmthint='CIF')
    h.SampleParameters['Scale'] = [1.0, False]
    h.SampleParameters['Gonio. radius'] = 200.0
    h.SampleParameters['Shift'] = [-500.0, False]
    h.InstrumentParameters['Zero'][0] = h.InstrumentParameters['Zero'][1] = 0.08
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 10,
                                      'coeffs': [1400.0] + [0.0] * 9,
                                      'refine': True}})
    hap = p.data['Histograms'][h.name]
    hap['Scale'] = [1.0, True]
    hap['Size'][0] = 'isotropic'
    hap['Size'][1][0] = 0.3
    hap['Size'][2] = [False, False, False]
    hap['Mustrain'][0] = 'isotropic'
    hap['Mustrain'][1][0] = 1500.0
    hap['Mustrain'][2] = [False, False, False]
    run_stage(gpx, 'background_scale', 10)

    h.SampleParameters['Shift'][1] = True
    p.set_refinements({'Cell': True})
    run_stage(gpx, 'shift_cell', 10)

    for k in ('U', 'W', 'X'):
        h.InstrumentParameters[k][2] = True
    run_stage(gpx, 'instrument_profile', 10)

    for k in ('U', 'W', 'X'):
        h.InstrumentParameters[k][2] = False
    hap['Size'][2][0] = True
    hap['Mustrain'][2][0] = True
    run_stage(gpx, 'phase_profile', 12)

    x = np.asarray(h.getdata('x'))
    obs = np.asarray(h.getdata('yobs'))
    calc = np.asarray(h.getdata('ycalc'))
    bg = np.asarray(h.getdata('background'))
    np.savetxt(ROOT / '.tmp' / 'mnwo4_single_fit.csv',
               np.column_stack([x, obs, calc, obs-calc, bg]), delimiter=',',
               header='two_theta_deg,observed,calculated,difference,background', comments='')


if __name__ == '__main__':
    main()
