from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "selected" / "selected.gpx"
OUT = ROOT / ".tmp" / "selected_effect_screen"
TEXTURE_AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
STRAIN_AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def clear_flags(project):
    hist = project.histogram(0)
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "


def covariance_parameter(project, name):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    values = np.asarray(covariance.get("variables", []), dtype=float)
    if name not in names or matrix.shape != (len(names), len(names)) or len(values) != len(names):
        return None
    index = names.index(name)
    return {"value": float(values[index]), "esd": float(np.sqrt(max(matrix[index, index], 0.0)))}


def refine(project, stage, wanted):
    records = []
    for pass_index in range(2):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 15)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(project.histogram(0).get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(map(str, project.get_Frozen())),
            "parameters": {name: covariance_parameter(project, name) for name in wanted},
        }
        records.append(record)
        print(json.dumps({"stage": stage, **record}), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    clear_flags(project)
    project.save()
    return records


def texture_branch(axis):
    label = "".join(map(str, axis))
    directory = OUT / f"wo3_texture_{label}"
    directory.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(directory / "screen.gpx"))
    clear_flags(project)
    hist = project.histogram(0)
    phase = project.phases()[1]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
    records = refine(project, f"wo3_texture_{label}", ["1:0:MD"])
    summary = {"kind": "texture", "phase": phase.name, "axis": list(axis), "ratio": float(po[1]), "Rwp_percent": float(hist.get_wR()), "records": records}
    (directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def strain_branch(phase_index, axis):
    label = "isotropic" if axis is None else "".join(map(str, axis))
    directory = OUT / f"phase_{phase_index}_strain_{label}"
    directory.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(directory / "screen.gpx"))
    clear_flags(project)
    hist = project.histogram(0)
    phase = project.phases()[phase_index]
    pid = int(phase.data["pId"])
    strain = phase.data["Histograms"][hist.name]["Mustrain"]
    initial = float(np.mean(strain[1][:2])) if strain[0] == "uniaxial" else float(strain[1][0])
    strain[1][0] = initial
    if axis is None:
        strain[0] = "isotropic"
        strain[1][1] = initial
        strain[2] = [True, False, False]
        wanted = [f"{pid}:0:Mustrain;i"]
    else:
        strain[0] = "uniaxial"
        strain[1][1] = initial
        strain[2] = [True, True, False]
        strain[3] = list(axis)
        wanted = [f"{pid}:0:Mustrain;i", f"{pid}:0:Mustrain;a"]
    records = refine(project, f"phase_{phase_index}_strain_{label}", wanted)
    summary = {
        "kind": "strain", "phase_index": phase_index, "phase": phase.name,
        "axis": None if axis is None else list(axis), "type": strain[0],
        "values_ppm": list(map(float, strain[1][:2])),
        "Rwp_percent": float(hist.get_wR()), "records": records,
    }
    (directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = [texture_branch(axis) for axis in TEXTURE_AXES]
    for phase_index in (0, 1):
        results.append(strain_branch(phase_index, None))
        results.extend(strain_branch(phase_index, axis) for axis in STRAIN_AXES)
    results.sort(key=lambda row: row["Rwp_percent"])
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
