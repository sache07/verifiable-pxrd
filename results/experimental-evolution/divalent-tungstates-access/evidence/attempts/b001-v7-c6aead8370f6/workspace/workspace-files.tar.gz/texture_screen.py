from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "uiso" / "uiso.gpx"
OUT = ROOT / ".tmp" / "texture_screen"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def clear_texture(project):
    hist = project.histogram(0)
    for phase in project.phases():
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = False
        po[3] = [0, 0, 1]


def parameter_esd(project, name):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    if name not in names:
        return None
    index = names.index(name)
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(names), len(names)):
        return None
    return float(np.sqrt(max(matrix[index, index], 0.0)))


def run_candidate(phase_index, axis):
    axis_label = "".join(map(str, axis))
    directory = OUT / f"phase_{phase_index}_axis_{axis_label}"
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / "texture.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(destination))
    clear_texture(project)
    hist = project.histogram(0)
    phase = project.phases()[phase_index]
    pid = int(phase.data["pId"])
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    variable = f"{pid}:0:MD"
    project.set_Controls("parmMin", 0.7, variable=variable)
    project.set_Controls("parmMax", 1.4, variable=variable)
    records = []
    for pass_index in range(2):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "ratio": float(po[1]),
            "esd": parameter_esd(project, variable),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(map(str, project.get_Frozen())),
        }
        records.append(record)
        print(json.dumps({
            "phase_index": phase_index, "phase": phase.name,
            "axis": list(axis), **record,
        }), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    po[2] = False
    project.save()
    summary = {
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": list(axis),
        "ratio": float(po[1]),
        "Rwp_percent": float(hist.get_wR()),
        "improvement_percent": float(G2.G2Project(gpxfile=str(SOURCE)).histogram(0).get_wR() - hist.get_wR()),
        "records": records,
    }
    (directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    summaries = []
    for phase_index in range(3):
        for axis in AXES:
            summaries.append(run_candidate(phase_index, axis))
    summaries.sort(key=lambda row: row["Rwp_percent"])
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
