from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "nuisance_screen" / "shl" / "nuisance.gpx"
OUT = ROOT / ".tmp" / "background_screen"


def run_order(order):
    directory = OUT / f"chebyshev_{order}"
    directory.mkdir(parents=True, exist_ok=True)
    destination = directory / "background.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(destination))
    hist = project.histogram(0)
    current = list(hist.Background[0][3:])
    coefficients = (current + [0.0] * order)[:order]
    hist.Background[0] = ["chebyschev-1", True, order, *coefficients]
    records = []
    for pass_index in range(3):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 15)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        nobs = int(rvals.get("Nobs", len(hist.getdata("x"))))
        nvars = int(rvals.get("Nvars", 0))
        chisq = float(rvals.get("chisq", np.nan))
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "chisq": chisq,
            "Nobs": nobs,
            "Nvars": nvars,
            "BIC_proxy": chisq + nvars * np.log(max(nobs, 1)),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(map(str, project.get_Frozen())),
            "background_min": float(np.min(hist.getdata("background"))),
            "background_max": float(np.max(hist.getdata("background"))),
        }
        records.append(record)
        print(json.dumps({"order": order, **record}), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    summary = {
        "order": order,
        "coefficients": list(map(float, hist.Background[0][3:])),
        "Rwp_percent": float(hist.get_wR()),
        "records": records,
    }
    (directory / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    return summary


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    summaries = [run_order(order) for order in (8, 10, 12, 14)]
    (OUT / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
    print(json.dumps(summaries, indent=2))


if __name__ == "__main__":
    main()
