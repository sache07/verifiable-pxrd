from __future__ import annotations

import json
from pathlib import Path
import re

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "calibration" / "shift_only" / "calibrated.gpx"
OUT = ROOT / ".tmp" / "coordinates"
DESTINATION = OUT / "coordinates.gpx"
WINDOW_ANGSTROM = 0.10
COORDINATE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def clear_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def install_bounds(project, source_coordinates):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hist = project.histogram(0)
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        project.set_Controls("parmMin", max(scale * 0.20, 0.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(scale * 5.0, 1.0), variable=f"{pid}:0:Scale")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(0.01 * abs(value), 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for atom_index, atom in enumerate(phase.atoms()):
            source = source_coordinates[(pid, atom_index)]
            for axis, value, length in zip("xyz", source, lengths):
                half_width = WINDOW_ANGSTROM / float(length)
                variable = f"{pid}::dA{axis}:{atom_index}"
                project.set_Controls("parmMin", float(value) - half_width, variable=variable)
                project.set_Controls("parmMax", float(value) + half_width, variable=variable)


def coordinate_atoms(frozen):
    result = set()
    for variable in frozen:
        match = COORDINATE.match(str(variable))
        if match:
            result.add((int(match.group(1)), int(match.group(2))))
    return result


def mass_fractions(project):
    hist = project.histogram(0)
    weighted = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(max(value, 0.0) for value in weighted.values())
    return {name: max(value, 0.0) / total for name, value in weighted.items()}


def run(project, stage, records, cycles=8):
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
        "fractions": mass_fractions(project),
    }
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def rollback(project, excluded, source_coordinates):
    for phase in project.phases():
        pid = int(phase.data["pId"])
        for atom_index, atom in enumerate(phase.atoms()):
            if (pid, atom_index) in excluded:
                atom.coordinates = source_coordinates[(pid, atom_index)]


def active_atoms(project, excluded, phase_filter=None, oxygen=None):
    clear_flags(project)
    active = 0
    for phase in project.phases():
        pid = int(phase.data["pId"])
        if phase_filter is not None and pid != phase_filter:
            continue
        for atom_index, atom in enumerate(phase.atoms()):
            is_oxygen = atom.element.strip().upper() in {"O", "O-2"}
            wanted = oxygen is None or is_oxygen == oxygen
            if wanted and (pid, atom_index) not in excluded:
                atom.refinement_flags = "X"
                active += 1
    return active


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    project.index_ids()
    source_coordinates = {
        (int(phase.data["pId"]), atom_index): tuple(map(float, atom.coordinates))
        for phase in project.phases()
        for atom_index, atom in enumerate(phase.atoms())
    }
    install_bounds(project, source_coordinates)
    records = []
    excluded = set()

    for phase in project.phases():
        pid = int(phase.data["pId"])
        for oxygen, label in ((False, "heavy"), (True, "oxygen")):
            if not active_atoms(project, excluded, phase_filter=pid, oxygen=oxygen):
                continue
            record = run(project, f"phase_{pid}_{label}_coordinates", records, cycles=8)
            new_excluded = coordinate_atoms(record["frozen"])
            if new_excluded:
                excluded.update(new_excluded)
                rollback(project, excluded, source_coordinates)

    for pass_index in range(5):
        if not active_atoms(project, excluded):
            break
        record = run(project, f"joint_interior_coordinates_{pass_index + 1}", records, cycles=8)
        new_excluded = coordinate_atoms(record["frozen"])
        if new_excluded:
            excluded.update(new_excluded)
            rollback(project, excluded, source_coordinates)
            continue
        maximum = record["max_shift_esd"]
        if record["converged"] and maximum is not None and maximum <= 1.0:
            break

    clear_flags(project)
    run(project, "cell_scale_background_calibration_settle", records, cycles=10)
    clear_flags(project)
    project.save()
    hist = project.histogram(0)
    summary = {
        "Rwp_percent": float(hist.get_wR()),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "fractions": mass_fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "excluded_bound_hit_atoms": [list(item) for item in sorted(excluded)],
        "coordinates": {
            phase.name: [
                {
                    "index": atom_index, "label": atom.label,
                    "element": atom.element,
                    "xyz": list(map(float, atom.coordinates)),
                    "refined": (int(phase.data["pId"]), atom_index) not in excluded
                    and tuple(map(float, atom.coordinates)) != source_coordinates[(int(phase.data["pId"]), atom_index)],
                }
                for atom_index, atom in enumerate(phase.atoms())
            ]
            for phase in project.phases()
        },
        "short_contacts": {
            phase.name: [list(row) for row in phase.ShortDistances(useAll=False)]
            for phase in project.phases()
        },
        "stages": records,
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps({
        "Rwp_percent": summary["Rwp_percent"],
        "excluded_bound_hit_atoms": summary["excluded_bound_hit_atoms"],
        "short_contacts": summary["short_contacts"],
    }))


if __name__ == "__main__":
    main()
