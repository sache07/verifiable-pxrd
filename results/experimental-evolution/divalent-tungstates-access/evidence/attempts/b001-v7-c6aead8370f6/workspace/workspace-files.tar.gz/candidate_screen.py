from pathlib import Path
import argparse
import json
import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
MNWO4 = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif/1/52/02/1520200.cif')
WO3 = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif/1/52/89/1528915.cif')


def run(gpx, cycles):
    gpx.data['Controls']['data']['parmFrozen'] = {'FrozenList': []}
    gpx.set_Controls('cycles', cycles)
    gpx.save()
    gpx.refine(makeBack=False)
    gpx.save()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('candidate')
    parser.add_argument('--fixed-cell', action='store_true')
    args = parser.parse_args()
    provenance = json.loads((ROOT / 'candidates' / 'provenance.json').read_text())
    record = next(row for row in provenance if row['name'] == args.candidate)
    work = ROOT / '.tmp' / 'screens' / args.candidate
    work.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel('error')
    gpx = G2.G2Project(newgpx=str(work / 'screen.gpx'))
    h = gpx.add_powder_histogram(str(ROOT / '.tmp' / 'pattern.xye'),
                                 str(ROOT / 'instrument.instprm'), fmthint='xye')
    phases = [
        gpx.add_phase(str(MNWO4), phasename='MnWO4_wolframite', histograms=[h], fmthint='CIF'),
        gpx.add_phase(str(WO3), phasename='WO3_gamma_monoclinic', histograms=[h], fmthint='CIF'),
        gpx.add_phase(record.get('screen_candidate_path', record['adapted_candidate_path']),
                      phasename='Mn3WO6_' + args.candidate,
                      histograms=[h], fmthint='CIF'),
    ]
    h.SampleParameters['Scale'] = [1.0, False]
    h.SampleParameters['Gonio. radius'] = 200.0
    h.SampleParameters['Shift'] = [-524.5, False]
    h.InstrumentParameters['Zero'][0] = h.InstrumentParameters['Zero'][1] = 0.08
    h.set_refinements({'Background': {'type': 'chebyschev-1', 'no. coeffs': 10,
                                      'coeffs': [1400.0] + [0.0] * 9,
                                      'refine': True}})
    weighted_scales = [105000.0, 25000.0, 25000.0]
    profiles = [(0.083, 4250.0), (0.72, 8000.0), (0.30, 1500.0)]
    for p, weighted, (size, strain) in zip(phases, weighted_scales, profiles):
        hap = p.data['Histograms'][h.name]
        hap['Scale'] = [weighted / p.data['General']['Mass'], True]
        hap['Size'][0] = 'isotropic'
        hap['Size'][1][0] = size
        hap['Size'][2] = [False, False, False]
        hap['Mustrain'][0] = 'isotropic'
        hap['Mustrain'][1][0] = strain
        hap['Mustrain'][2] = [False, False, False]
    run(gpx, 10)
    if args.fixed_cell:
        run(gpx, 10)
    else:
        h.SampleParameters['Shift'][1] = True
        for p in phases:
            p.set_refinements({'Cell': True})
        run(gpx, 12)
        run(gpx, 12)

    masses = {p.name: p.data['General']['Mass'] * p.data['Histograms'][h.name]['Scale'][0]
              for p in phases}
    total = sum(max(v, 0.0) for v in masses.values())
    cov = gpx.data.get('Covariance', {}).get('data', {})
    summary = {
        'candidate': args.candidate,
        'fixed_cell_checkpoint': args.fixed_cell,
        'Rwp_percent': float(h.get_wR()),
        'fractions': {k: max(v, 0.0) / total for k, v in masses.items()},
        'cells': {p.name: p.get_cell() for p in phases},
        'shift_um': h.SampleParameters['Shift'][0],
        'zero_deg': h.InstrumentParameters['Zero'][1],
        'converged': bool(cov.get('Rvals', {}).get('converged', False)),
        'max_shift_esd': cov.get('Rvals', {}).get('Max shft/sig'),
        'frozen': list(gpx.get_Frozen()),
    }
    (work / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    x = np.asarray(h.getdata('x'))
    obs = np.asarray(h.getdata('yobs'))
    calc = np.asarray(h.getdata('ycalc'))
    np.savetxt(work / 'fit.csv', np.column_stack([x, obs, calc, obs-calc]), delimiter=',',
               header='two_theta_deg,observed,calculated,difference', comments='')
    print(json.dumps(summary))


if __name__ == '__main__':
    main()
