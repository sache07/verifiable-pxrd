from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "uiso" / "uiso.gpx"
OUT = ROOT / ".tmp" / "combined"
DESTINATION = OUT / "combined.gpx"


def set_common(project, active):
    hist = project.histogram(0)
    for name in ("U", "W", "X"):
        hist.InstrumentParameters[name][2] = bool(active)


def clear_phase_flags(project):
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "


def activate_profiles(project):
    hist = project.histogram(0)
    for phase_index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [True, False, False]
        if phase_index in (0, 1):
            hap["Mustrain"][2] = [True, True, False]
        else:
            hap["Mustrain"][2] = [True, False, False]


def activate_supported_effects(project):
    hist = project.histogram(0)
    for phase_index in (0, 1):
        hap = project.phases()[phase_index].data["Histograms"][hist.name]
        hap["Mustrain"][2] = [True, True, False]
    project.phases()[1].data["Histograms"][hist.name]["Pref.Ori."][2] = True


def activate_uiso(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"


def top_correlations(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    rows = []
    if matrix.shape == (len(names), len(names)) and names:
        sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        denom = np.outer(sigma, sigma)
        corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
        for left in range(len(names)):
            for right in range(left + 1, len(names)):
                value = float(corr[left, right])
                if abs(value) >= 0.85:
                    rows.append([names[left], names[right], value])
    rows.sort(key=lambda row: abs(row[2]), reverse=True)
    return rows[:20]


def state(project):
    hist = project.histogram(0)
    return {
        "instrument": {name: float(hist.InstrumentParameters[name][1]) for name in ("U", "W", "X", "SH/L", "Polariz.")},
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "mustrain_type": phase.data["Histograms"][hist.name]["Mustrain"][0],
                "mustrain_values": list(map(float, phase.data["Histograms"][hist.name]["Mustrain"][1][:2])),
                "mustrain_axis": list(phase.data["Histograms"][hist.name]["Mustrain"][3]),
                "MD_ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "MD_axis": list(phase.data["Histograms"][hist.name]["Pref.Ori."][3]),
                "Uiso_A2": float(phase.atoms()[0].uiso),
            }
            for phase in project.phases()
        },
    }


def run(project, stage, records, cycles=15):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
        "state": state(project),
        "high_correlations": top_correlations(project),
    }
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    hist = project.histogram(0)
    clear_phase_flags(project)
    set_common(project, False)
    # Install the physical, interior winners from the equal screens.
    strain0 = project.phases()[0].data["Histograms"][hist.name]["Mustrain"]
    strain0[0] = "uniaxial"
    strain0[1][0], strain0[1][1], strain0[3] = 5385.262581787576, 4966.2980039288395, [1, 0, 0]
    strain1 = project.phases()[1].data["Histograms"][hist.name]["Mustrain"]
    strain1[0] = "uniaxial"
    strain1[1][0], strain1[1][1], strain1[3] = 6724.702992310793, 9377.543907171432, [0, 0, 1]
    strain2 = project.phases()[2].data["Histograms"][hist.name]["Mustrain"]
    strain2[0] = "isotropic"
    strain2[1][1] = strain2[1][0]
    texture = project.phases()[1].data["Histograms"][hist.name]["Pref.Ori."]
    texture[0], texture[1], texture[3] = "MD", 0.9369819293688494, [1, 1, 1]
    for phase_index in (0, 2):
        po = project.phases()[phase_index].data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[3] = "MD", 1.0, [0, 0, 1]
    for pid in (0, 1):
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;a")
        project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
    project.set_Controls("parmMin", 0.7, variable="1:0:MD")
    project.set_Controls("parmMax", 1.4, variable="1:0:MD")

    records = []
    activate_supported_effects(project)
    run(project, "supported_strain_texture", records)
    clear_phase_flags(project)
    set_common(project, True)
    run(project, "common_profile_update", records)
    set_common(project, False)
    activate_profiles(project)
    run(project, "phase_profile_update", records)
    clear_phase_flags(project)
    set_common(project, True)
    run(project, "common_profile_replay", records)
    set_common(project, False)
    project.phases()[1].data["Histograms"][hist.name]["Pref.Ori."][2] = True
    run(project, "texture_replay", records)
    clear_phase_flags(project)
    activate_uiso(project)
    run(project, "phase_common_uiso_replay", records)
    clear_phase_flags(project)
    run(project, "nuisance_settle", records, cycles=12)
    clear_phase_flags(project)
    set_common(project, False)
    project.save()
    summary = {
        "Rwp_percent": float(hist.get_wR()),
        "state": state(project),
        "records": records,
        "short_contacts": {
            phase.name: [list(row) for row in phase.ShortDistances(useAll=False)]
            for phase in project.phases()
        },
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
