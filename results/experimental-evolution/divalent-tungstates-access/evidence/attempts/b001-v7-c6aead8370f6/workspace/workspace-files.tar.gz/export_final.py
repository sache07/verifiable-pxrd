from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT_PATH = ROOT / "final.gpx"
PREDICTION_PATH = ROOT / ".tmp" / "replay" / "prediction.npz"

PHASE_EXPORTS = (
    ("MnWO4_wolframite", "MnWO4", "phase_1_MnWO4.cif"),
    ("WO3_gamma_monoclinic", "WO3", "phase_2_gamma_WO3.cif"),
    ("Mn3WO6_rhombohedral", "Mn3WO6", "phase_3_Mn3WO6.cif"),
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    G2.SetPrintLevel("error")
    project_hash = digest(PROJECT_PATH)
    project = G2.G2Project(gpxfile=str(PROJECT_PATH))
    histogram = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    mass_fractions = histogram.ComputeMassFracs()

    with np.load(PREDICTION_PATH, allow_pickle=False) as replay:
        x = np.asarray(replay["x"], dtype=float)
        observed = np.asarray(replay["observed"], dtype=float)
        calculated = np.asarray(replay["predicted"], dtype=float)
    if not np.array_equal(x, np.asarray(histogram.getdata("x"), dtype=float)):
        raise RuntimeError("replay grid does not match final.gpx")
    if not np.array_equal(observed, np.asarray(histogram.getdata("yobs"), dtype=float)):
        raise RuntimeError("replay observations do not match final.gpx")

    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.8f", "%.8f", "%.8f"),
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    n_observations = int(observed.size)
    n_variables = int(rvals["Nvars"])
    degrees_of_freedom = n_observations - n_variables
    rwp = 100.0 * np.sqrt(chi_square / denominator)
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))
    rexp = 100.0 * np.sqrt(degrees_of_freedom / denominator)
    goodness_of_fit = np.sqrt(chi_square / degrees_of_freedom)

    # Export saved atoms/cells, without applying stale covariance coordinate
    # values. This changes only the in-memory object and is never saved.
    project.data["Covariance"]["data"] = {}
    phases = []
    for phase_name, formula, filename in PHASE_EXPORTS:
        phase = project.phase(phase_name)
        phase.export_CIF(str(ROOT / filename))
        fraction, uncertainty = mass_fractions[phase_name]
        cell = phase.get_cell()
        phases.append(
            {
                "name": phase_name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": filename,
                "weight_fraction": float(fraction),
                "weight_fraction_standard_uncertainty": float(uncertainty),
                "unit_cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
            }
        )

    result = {
        "phases": phases,
        "weight_fraction_basis": "normalized over the three modeled crystalline phases; amorphous content not determined",
        "fit_statistics": {
            "Rwp_percent": float(rwp),
            "Rp_percent": float(rp),
            "Rexp_percent": float(rexp),
            "goodness_of_fit": float(goodness_of_fit),
            "chi_square": float(chi_square),
            "n_observations": n_observations,
            "n_variables_last_settle": n_variables,
            "degrees_of_freedom": degrees_of_freedom,
            "converged": bool(rvals["converged"]),
            "maximum_shift_over_esd_last_settle": float(rvals["Max shft/sig"]),
            "calculated_profile_source": "zero-optimization native GSAS-II atomic replay of final.gpx",
        },
        "fit_csv": "fit.csv",
        "project_file": "final.gpx",
        "project_sha256": project_hash,
        "refinement_histogram": histogram.name,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    if digest(PROJECT_PATH) != project_hash:
        raise RuntimeError("final.gpx changed during export")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
