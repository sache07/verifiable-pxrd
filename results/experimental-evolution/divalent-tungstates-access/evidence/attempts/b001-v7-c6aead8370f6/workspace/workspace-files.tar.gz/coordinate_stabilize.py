from __future__ import annotations

import json
from pathlib import Path
import re

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "coordinates" / "coordinates.gpx"
DESTINATION = ROOT / ".tmp" / "coordinates" / "stabilized.gpx"
SUMMARY = ROOT / ".tmp" / "coordinates" / "stabilized.json"
EXCLUDED = {(1, 0), (1, 2), (1, 3), (1, 4), (1, 5), (1, 6), (2, 3), (2, 4)}
COORDINATE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def clear_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def activate(project, phase_id=None):
    clear_flags(project)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        if phase_id is not None and pid != phase_id:
            continue
        for atom_index, atom in enumerate(phase.atoms()):
            if (pid, atom_index) not in EXCLUDED:
                atom.refinement_flags = "X"


def diagnostic(project):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    shifts = {str(key): float(value) for key, value in covariance.get("Rvals", {}).get("lastShifts", {}).items()}
    ratios = []
    if matrix.shape == (len(names), len(names)):
        for index, name in enumerate(names):
            sigma = float(np.sqrt(max(matrix[index, index], 0.0)))
            shift = shifts.get(name)
            if shift is not None and sigma > 0:
                ratios.append([name, shift, sigma, abs(shift) / sigma])
    ratios.sort(key=lambda row: row[3], reverse=True)
    return ratios[:20]


def run(project, stage, records, cycles=15):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
        "largest_shift_ratios": diagnostic(project),
    }
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def stable(record):
    return bool(record["converged"]) and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    records = []
    for phase in project.phases():
        pid = int(phase.data["pId"])
        activate(project, phase_id=pid)
        for pass_index in range(4):
            record = run(project, f"phase_{pid}_coordinate_stabilize_{pass_index + 1}", records)
            if stable(record):
                break
    activate(project)
    for pass_index in range(5):
        record = run(project, f"joint_coordinate_stabilize_{pass_index + 1}", records)
        if stable(record):
            break
    clear_flags(project)
    run(project, "nuisance_settle", records, cycles=12)
    clear_flags(project)
    project.save()
    summary = {
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "records": records,
        "short_contacts": {
            phase.name: [list(row) for row in phase.ShortDistances(useAll=False)]
            for phase in project.phases()
        },
    }
    SUMMARY.write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps({"Rwp_percent": summary["Rwp_percent"], "short_contacts": summary["short_contacts"]}))


if __name__ == "__main__":
    main()
