from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "terminal_texture_screen" / "100" / "texture.gpx"
OUT = ROOT / ".tmp" / "terminal"
DESTINATION = OUT / "terminal.gpx"


def clear_flags(project):
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        try:
            phase.clear_refinements({"Cell": True})
        except Exception:
            phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False


def set_fixed_model(project):
    hist = project.histogram(0)
    hist.InstrumentParameters["Zero"][1:3] = [0.0, False]
    hist.InstrumentParameters["SH/L"][1:3] = [0.02, False]
    hist.InstrumentParameters["Polariz."][1:3] = [0.75, False]
    hist.SampleParameters["SurfRoughA"][0:2] = [0.0, False]
    hist.SampleParameters["SurfRoughB"][0:2] = [0.0, False]
    # Preserve only the selected, uniquely supported texture correction.
    for index, phase in enumerate(project.phases()):
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        if index == 1:
            po[3] = [1, 0, 0]
        else:
            po[1], po[3] = 1.0, [0, 0, 1]


def install_bounds(project):
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    for name, low, high in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
        ("Zero", -0.25, 0.25),
    ):
        project.set_Controls("parmMin", low, variable=f":0:{name}")
        project.set_Controls("parmMax", high, variable=f":0:{name}")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")

    hist = project.histogram(0)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        project.set_Controls("parmMin", max(0.2 * scale, 0.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(5.0 * scale, 1.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        for suffix in ("i", "a"):
            project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;{suffix}")
            project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;{suffix}")
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(0.01 * abs(value), 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        for atom_index in range(len(phase.atoms())):
            variable = f"{pid}::AUiso:{atom_index}"
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)


def enable_core(project):
    hist = project.histogram(0)
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def enable_phase_profiles(project):
    hist = project.histogram(0)
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        if index == 0:
            hap["Mustrain"][0], hap["Mustrain"][3] = "uniaxial", [1, 0, 0]
            hap["Mustrain"][2] = [True, True, False]
        elif index == 1:
            hap["Mustrain"][0], hap["Mustrain"][3] = "uniaxial", [0, 1, 0]
            hap["Mustrain"][2] = [True, True, False]
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2] = [True, False, False]


def enable_common_profile(project, include_u=True):
    hist = project.histogram(0)
    for name in (("U", "W", "X") if include_u else ("W", "X")):
        hist.InstrumentParameters[name][2] = True


def enable_uiso(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"


def enable_texture(project):
    hist = project.histogram(0)
    project.phases()[1].data["Histograms"][hist.name]["Pref.Ori."][2] = True


def top_correlations(project, threshold=0.90):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(map(str, covariance.get("varyList", [])))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    rows = []
    if matrix.shape == (len(names), len(names)) and names:
        sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        denominator = np.outer(sigma, sigma)
        corr = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator > 0)
        for left in range(len(names)):
            for right in range(left + 1, len(names)):
                value = float(corr[left, right])
                if abs(value) >= threshold:
                    rows.append([names[left], names[right], value])
    rows.sort(key=lambda row: abs(row[2]), reverse=True)
    return rows[:30]


def fractions(project):
    values = project.histogram(0).ComputeMassFracs()
    return {str(name): [float(item) for item in value] for name, value in values.items()}


def state(project):
    hist = project.histogram(0)
    return {
        "Rwp_percent": float(hist.get_wR()),
        "instrument": {
            name: float(hist.InstrumentParameters[name][1])
            for name in ("U", "W", "X", "SH/L", "Polariz.", "Zero")
        },
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "background": list(map(float, hist.Background[0][3:])),
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "strain_values": list(map(float, phase.data["Histograms"][hist.name]["Mustrain"][1][:2])),
                "strain_type": phase.data["Histograms"][hist.name]["Mustrain"][0],
                "strain_axis": list(phase.data["Histograms"][hist.name]["Mustrain"][3]),
                "MD_ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "MD_axis": list(phase.data["Histograms"][hist.name]["Pref.Ori."][3]),
                "Uiso_A2": float(phase.atoms()[0].uiso),
            }
            for phase in project.phases()
        },
    }


def run(project, stage, records, cycles=15):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": stage,
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(map(str, project.get_Frozen())),
        "high_correlations": top_correlations(project),
    }
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def run_until(project, stage, records, maximum_passes=4):
    record = None
    for pass_index in range(maximum_passes):
        record = run(project, f"{stage}_{pass_index + 1}", records)
        maximum = record["max_shift_esd"]
        if record["converged"] and maximum is not None and maximum <= 1.0 and not record["frozen"]:
            break
    return record


def configure_stage(project, kind):
    clear_flags(project)
    set_fixed_model(project)
    enable_core(project)
    if kind in ("profiles", "joint"):
        enable_phase_profiles(project)
    if kind in ("common", "joint"):
        enable_common_profile(project, include_u=True)
    if kind == "joint_u_fixed":
        enable_phase_profiles(project)
        enable_common_profile(project, include_u=False)
        enable_uiso(project)
        enable_texture(project)
    if kind in ("uiso", "joint"):
        enable_uiso(project)
    if kind in ("texture", "joint"):
        enable_texture(project)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(DESTINATION))
    set_fixed_model(project)
    install_bounds(project)
    records = []
    # Develop each profile class separately. If a common term then becomes
    # bound-seeking in the joint model, retain this last interior checkpoint.
    for kind in ("profiles", "common", "uiso", "texture"):
        configure_stage(project, kind)
        run_until(project, f"develop_{kind}", records)
    retained_u = float(project.histogram(0).InstrumentParameters["U"][1])

    # U and Mn3WO6 strain become bound-seeking when all terms float together.
    # Hold U at the preceding interior checkpoint and replay the remaining
    # supported model twice, with identical flags, to test stability.
    replay_states = []
    for replay in range(2):
        project.histogram(0).InstrumentParameters["U"][1] = retained_u
        configure_stage(project, "joint_u_fixed")
        run_until(project, f"replay_{replay + 1}_joint_u_fixed", records)
        replay_states.append(state(project))

    clear_flags(project)
    set_fixed_model(project)
    project.save()
    summary = {
        "Rwp_percent": float(project.histogram(0).get_wR()),
        "profile_rollback": {
            "term": ":0:U",
            "retained_value": retained_u,
            "reason": "joint refinement was pinned at the tested upper bound",
        },
        "fractions": fractions(project),
        "state": state(project),
        "replay_states": replay_states,
        "records": records,
        "short_contacts": {
            phase.name: [list(row) for row in phase.ShortDistances(useAll=False)]
            for phase in project.phases()
        },
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    print(json.dumps(summary, default=str), flush=True)


if __name__ == "__main__":
    main()
