#!/usr/bin/env python3
"""Create fit.csv and result.json from the independently replayed final GPX."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


REPLAY_DIR = Path(".tmp/verify")


def main() -> None:
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError("Final project did not pass clean independent replay")
    with np.load(REPLAY_DIR / "prediction.npz") as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))

    np.savetxt(
        "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    exported = json.loads(Path(".tmp/final_export.json").read_text())
    replay_by_name = {row["name"]: row for row in replay["phases"]}
    phases = []
    for row in exported["phases"]:
        independent = replay_by_name[row["name"]]
        if abs(row["weight_fraction"] - independent["weight_fraction"]) > 1e-12:
            raise RuntimeError("Exported and independently replayed fractions differ")
        phases.append(
            {
                "name": row["name"],
                "cif_path": row["cif_path"],
                "weight_fraction": row["weight_fraction"],
                "unit_cell": row["cell"],
            }
        )
    if abs(sum(row["weight_fraction"] for row in phases) - 1.0) > 1e-12:
        raise RuntimeError("Final crystalline fractions are not normalized")

    result = {
        "phases": phases,
        "normalization": "Weight fractions normalized over the three modeled crystalline phases.",
        "refinement_histogram": replay["histogram"],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "weighted_chi_square": chi_square,
            "mean_weighted_squared_residual": chi_square / len(x),
            "bins": int(len(x)),
            "weighting": "1/max(observed_counts,1)",
            "difference_convention": "observed-calculated",
        },
        "project": {
            "path": "final.gpx",
            "sha256": replay["project_sha256"],
            "independent_replay_status": replay["status"],
            "profile_review_flags": replay["profile_review_flags"],
        },
        "calibration": {
            "zero_deg": replay["instrument"]["Zero"][1],
            "wavelength_Kalpha1_angstrom": replay["instrument"]["Lam1"][1],
            "wavelength_Kalpha2_angstrom": replay["instrument"]["Lam2"][1],
            "Kalpha2_to_Kalpha1_ratio": replay["instrument"]["I(L2)/I(L1)"][1],
        },
    }
    Path("result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
