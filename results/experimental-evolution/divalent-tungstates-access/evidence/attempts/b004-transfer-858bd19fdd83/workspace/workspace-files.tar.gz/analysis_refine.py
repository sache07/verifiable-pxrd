#!/usr/bin/env python3
"""Exploratory GSAS-II Rietveld refinement for the supplied powder pattern.

Run with the GSAS-II Python environment. This script intentionally keeps all
intermediate projects in a requested work directory so candidate phase sets can
be compared without touching the final submission until a model is selected.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    supplied = Path(cod_id)
    if supplied.is_file():
        return supplied.resolve()
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    return (
        "#GSAS-II Cu K-alpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.18;Polariz.:0.8;Azimuth:0.0\n"
        "U:8.0;V:0.0;W:5.0;X:0.5;Y:0.0;Z:0.0;SH/L:0.025\n"
    )


def summarize(project: G2.G2Project, hist: G2.G2PwdrData) -> dict:
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for phase, value in zip(phases, masses):
        phase["weight_fraction"] = value / total if total else None
    inst = hist.data["Instrument Parameters"][0]
    return {
        "histogram": hist.name,
        "wR_percent": hist.get_wR(),
        "residuals": hist.data["data"][0],
        "instrument": {
            key: value for key, value in inst.items()
            if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"],
        "phases": phases,
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "variables": project.data.get("Covariance", {}).get("data", {}).get("variables", []).tolist()
        if hasattr(project.data.get("Covariance", {}).get("data", {}).get("variables", []), "tolist")
        else project.data.get("Covariance", {}).get("data", {}).get("variables", []),
    }


def run(pattern: Path, work: Path, ids: list[str], names: list[str]) -> None:
    G2.SetPrintLevel("warn")
    work.mkdir(parents=True, exist_ok=True)
    raw = np.loadtxt(pattern, delimiter=",", skiprows=1)
    x, y = raw.T
    data_path = work / "pattern.xye"
    # The supplied intensities are Poisson counts; this gives weights 1/max(y,1).
    np.savetxt(data_path, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")
    inst_path = work / "instrument.instprm"
    inst_path.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(work / "model.gpx"))
    phases = [
        project.add_phase(str(cod_path(cid)), phasename=name, fmthint="CIF")
        for cid, name in zip(ids, names)
    ]
    hist = project.add_powder_histogram(
        str(data_path), str(inst_path), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # A redundant specimen scale is otherwise refined by default and is
    # exactly correlated with every phase scale.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1300.0, -400.0] + [0.0] * 10,
                "refine": True,
            },
        }
    )

    # Use comparable starting mass contributions and plausible phase-specific
    # widths. The dominant Ba3W2O9 family is visibly broader than the sharp
    # oxide/carbonate families.
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [5000.0 / float(phase.data["General"]["Mass"]), False]
        phase.setSampleProfile(hist.name, "size", "isotropic", 1.0)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 1800.0 if i == 0 else 200.0)
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 8)
    # Stabilize global intensity/background and phase abundances first.
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.refine()
    (work / "step01.json").write_text(json.dumps(summarize(project, hist), indent=2, default=str) + "\n")

    # Peak positions: first angular zero, then symmetry-constrained cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.refine()
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine()
    (work / "step02.json").write_text(json.dumps(summarize(project, hist), indent=2, default=str) + "\n")

    # Instrument profile followed by phase-dependent broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L", "Polariz."]})
    project.refine()
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    project.refine()
    project.refine()
    project.save(str(work / "model.gpx"))
    (work / "summary.json").write_text(json.dumps(summarize(project, hist), indent=2, default=str) + "\n")

    arrays = hist.data["data"][1]
    np.savetxt(
        work / "fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4]]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--names", nargs="+")
    args = parser.parse_args()
    names = args.names or [f"COD_{cid}" for cid in args.ids]
    if len(names) != len(args.ids):
        parser.error("--names must have the same length as --ids")
    run(args.pattern, args.work, args.ids, names)


if __name__ == "__main__":
    main()
