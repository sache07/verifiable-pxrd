#!/usr/bin/env python3
"""Apply one controlled refinement variant to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from analysis_refine import summarize


def axis(text: str) -> list[int]:
    values = [int(v) for v in text.replace(",", " ").split()]
    if len(values) != 3 or not any(values):
        raise argparse.ArgumentTypeError("axis must contain three integers")
    return values


def bounds(project: G2.G2Project, variable: str, lo: float, hi: float) -> None:
    project.set_Controls("parmMin", float(lo), variable)
    project.set_Controls("parmMax", float(hi), variable)


def write_outputs(project: G2.G2Project, hist: G2.G2PwdrData, output: Path) -> None:
    project.save(str(output))
    report = summarize(project, hist)
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    a = hist.data["data"][1]
    np.savetxt(
        output.with_suffix(".csv"),
        np.column_stack([a[0], a[1], a[3], a[1] - a[3], a[4]]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int)
    parser.add_argument("--texture", type=axis)
    parser.add_argument("--uniaxial-strain", type=axis)
    parser.add_argument("--coordinates", choices=["all", "heavy", "oxygen"])
    parser.add_argument("--uiso", choices=["all", "heavy", "oxygen"])
    parser.add_argument("--set-uiso", type=float)
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--shift-start", type=float, default=0.0)
    parser.add_argument("--zero-with-shift", action="store_true")
    parser.add_argument("--surface", action="store_true")
    parser.add_argument("--clear-v", action="store_true")
    parser.add_argument("--reset-flags", action="store_true")
    parser.add_argument("--refine-scales", action="store_true")
    parser.add_argument("--refine-background", action="store_true")
    parser.add_argument("--refine-cells", action="store_true")
    parser.add_argument("--refine-phase-cell", action="store_true")
    parser.add_argument("--instrument-profile", action="store_true")
    parser.add_argument("--refine-zero", action="store_true")
    parser.add_argument("--isotropic-profile", action="store_true")
    parser.add_argument("--set-size", type=float)
    parser.add_argument("--set-strain", type=float)
    parser.add_argument("--refine-size-only", action="store_true")
    parser.add_argument("--refine-strain-only", action="store_true")
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=2)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.input))
    hist = project.histograms()[0]
    phases = project.phases()
    print(f"loaded {args.input} at Rwp={hist.get_wR()}", flush=True)
    # GSAS-II writes to the currently attached project path whenever controls
    # are changed or a refinement starts. Redirect immediately so variants
    # never mutate their input project.
    project.save(str(args.output))
    if (any(v is not None for v in [args.texture, args.uniaxial_strain, args.coordinates, args.uiso, args.set_uiso, args.set_size, args.set_strain])
            or args.isotropic_profile or args.refine_size_only or args.refine_strain_only or args.refine_phase_cell) and args.phase is None:
        parser.error("--phase is required for phase-specific variants")
    project.set_Controls("cycles", args.cycles)
    h_id = hist.data["data"][0]["hId"]

    inst = hist.data["Instrument Parameters"][0]
    if args.reset_flags:
        hist.data["Background"][0][1] = False
        for value in inst.values():
            if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], (bool, np.bool_)):
                value[2] = False
        for key in ["Scale", "Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
            value = hist.SampleParameters.get(key)
            if isinstance(value, list) and len(value) > 1:
                value[1] = False
        for phase in phases:
            phase.data["General"]["Cell"][0] = False
            for atom in phase.atoms():
                atom.refinement_flags = ""
            hap = phase.data["Histograms"][hist.name]
            hap["Scale"][1] = False
            hap["Pref.Ori."][2] = False
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
    if args.refine_background:
        hist.data["Background"][0][1] = True
    if args.refine_scales:
        for phase in phases:
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    if args.refine_cells:
        for phase in phases:
            phase.data["General"]["Cell"][0] = True
    if args.instrument_profile:
        for key in ["U", "W", "X", "SH/L", "Polariz."]:
            inst[key][2] = True
    if args.refine_zero:
        inst["Zero"][2] = True
    if args.clear_v:
        inst["V"] = [0.0, 0.0, False]
    for key, lo, hi in [
        ("Zero", -0.25, 0.25),
        ("Polariz.", 0.5, 1.0),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.1),
    ]:
        bounds(project, f":{h_id}:{key}", lo, hi)

    if args.shift:
        # The previous zero-only fit absorbed most of the displacement. Start
        # with a modest negative height and let zero and height separate by
        # their different angular dependence.
        hist.SampleParameters["Shift"] = [args.shift_start, True]
        inst["Zero"][2] = args.zero_with_shift
        bounds(project, f":{h_id}:Shift", -800.0, 800.0)

    if args.surface:
        hist.SampleParameters["SurfRoughA"] = [0.25, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
        bounds(project, f":{h_id}:SurfRoughA", 0.0, 0.6)
        bounds(project, f":{h_id}:SurfRoughB", 0.0, 0.5)

    if args.phase is not None:
        phase = phases[args.phase]
        p_id = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        if args.refine_phase_cell:
            phase.data["General"]["Cell"][0] = True
        if args.set_size is not None:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = float(args.set_size)
        if args.set_strain is not None:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = float(args.set_strain)
        if args.refine_size_only:
            hap["Size"][0] = "isotropic"
            hap["Size"][2][0] = True
            bounds(project, f"{p_id}:{h_id}:Size;i", 0.02, 1.5)
        if args.refine_strain_only:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][0] = True
            bounds(project, f"{p_id}:{h_id}:Mustrain;i", 0.0, 8000.0)
        if args.set_uiso is not None:
            if not 0.0 <= args.set_uiso <= 0.05:
                parser.error("--set-uiso must be between 0 and 0.05 A^2")
            for atom in phase.atoms():
                atom.uiso = float(args.set_uiso)
        if args.isotropic_profile:
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = min(1.5, max(0.02, float(hap["Size"][1][0])))
            hap["Size"][2][0] = True
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = min(8000.0, max(0.0, float(hap["Mustrain"][1][0])))
            hap["Mustrain"][2][0] = True
            bounds(project, f"{p_id}:{h_id}:Size;i", 0.02, 2.0)
            bounds(project, f"{p_id}:{h_id}:Mustrain;i", 0.0, 8000.0)
        if args.texture is not None:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = args.texture
            bounds(project, f"{p_id}:{h_id}:MD", 0.7, 1.4)
        if args.uniaxial_strain is not None:
            current = float(hap["Mustrain"][1][0])
            phase.setSampleProfile(
                hist.name,
                "microstrain",
                "uniaxial",
                max(1.0, current),
                max(1.0, current),
                args.uniaxial_strain,
            )
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "uniaxial", "refine": True}}, [hist]
            )
            bounds(project, f"{p_id}:{h_id}:Mustrain;i", 0.0, 8000.0)
            bounds(project, f"{p_id}:{h_id}:Mustrain;a", 0.0, 32000.0)
        if args.coordinates is not None or args.uiso is not None:
            for atom in phase.atoms():
                element = atom.element
                flags = ""
                if args.coordinates and (
                    args.coordinates == "all"
                    or (args.coordinates == "oxygen" and element == "O")
                    or (args.coordinates == "heavy" and element != "O")
                ):
                    flags += "X"
                if args.uiso and (
                    args.uiso == "all"
                    or (args.uiso == "oxygen" and element == "O")
                    or (args.uiso == "heavy" and element != "O")
                ):
                    flags += "U"
                if flags:
                    atom.refinement_flags = flags

    for _ in range(args.passes):
        print("starting refinement pass", _ + 1, flush=True)
        project.refine()
        print("finished refinement pass", _ + 1, "Rwp", hist.get_wR(), flush=True)
    write_outputs(project, hist, args.output)


if __name__ == "__main__":
    main()
