#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export submission-consistent CIFs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/phys/u1b_1.gpx")
FINAL = Path("final.gpx")
PHASE_FILES = [
    Path("phase_1_Ba3W2O9.cif"),
    Path("phase_2_WO3.cif"),
    Path("phase_3_BaCO3.cif"),
]


def clear_flags(project: G2.G2Project, hist: G2.G2PwdrData) -> None:
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], (bool, np.bool_)):
            value[2] = False
    for key in ["Scale", "Absorption", "DisplaceX", "DisplaceY", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]:
        value = hist.SampleParameters.get(key)
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    hist = project.histograms()[0]
    public = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    arrays = hist.data["data"][1]
    if not np.allclose(arrays[0], public[:, 0], rtol=0, atol=1e-8):
        raise RuntimeError("Final histogram grid differs from the supplied pattern")
    if not np.allclose(arrays[1], public[:, 1], rtol=0, atol=1e-8):
        raise RuntimeError("Final histogram observations differ from the supplied pattern")

    # Redirect before any save-triggering operation, then remove all active
    # refinement flags. The frozen model parameters themselves are unchanged.
    project.save(str(FINAL))
    clear_flags(project, hist)
    project.data["Covariance"]["data"] = {}
    project.save(str(FINAL))

    phases = project.phases()
    if len(phases) != len(PHASE_FILES):
        raise RuntimeError("Unexpected final phase count")
    for phase, path in zip(phases, PHASE_FILES):
        phase.export_CIF(str(path))

    mass_scales = np.array(
        [
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0])
            for phase in phases
        ]
    )
    fractions = mass_scales / mass_scales.sum()
    info = {
        "histogram": hist.name,
        "source_project": str(SOURCE),
        "final_project": str(FINAL),
        "phases": [
            {
                "name": phase.name,
                "cif_path": str(path),
                "weight_fraction": float(fraction),
                "cell": phase.get_cell(),
            }
            for phase, path, fraction in zip(phases, PHASE_FILES, fractions)
        ],
    }
    Path(".tmp/final_export.json").write_text(json.dumps(info, indent=2) + "\n")


if __name__ == "__main__":
    main()
