#!/usr/bin/env python3
"""Build and stage the preliminary three-phase GSAS-II refinement."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_trials import ROOT, TMP, fresh_project, phase_summary


OUT = TMP / "combined"


def rvals(project):
    return project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})


def validate(project, label):
    hist = project.histograms()[0]
    fit = hist.data["data"][1]
    vals = rvals(project)
    if vals.get("Aborted") or not hist.residuals:
        raise RuntimeError(f"{label}: refinement aborted")
    if not np.all(np.isfinite(fit[3])):
        raise RuntimeError(f"{label}: nonfinite calculated profile")
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap.get("Use", True) and (not np.isfinite(hap["Scale"][0]) or hap["Scale"][0] <= 0):
            raise RuntimeError(f"{label}: nonpositive scale for {phase.name}")
        cell = phase.data["General"]["Cell"][1:7]
        if not np.all(np.isfinite(cell)) or min(cell[:3]) <= 1.5:
            raise RuntimeError(f"{label}: invalid cell for {phase.name}: {cell}")


def refine_until_stable(project, label, max_runs=5):
    for run in range(1, max_runs + 1):
        project.refine(makeBack=False)
        validate(project, label)
        vals = rvals(project)
        print(
            f"{label} run {run}: Rwp={vals.get('Rwp', math.nan):.5f} "
            f"GOF={vals.get('GOF', math.nan):.4f} "
            f"maxshift={vals.get('Max shft/sig', math.nan):.3f} "
            f"converged={vals.get('converged')}",
            flush=True,
        )
        if vals.get("converged") or abs(float(vals.get("Max shft/sig", 999))) < 0.15:
            break
    project.save()


def snapshot(project, label):
    project.save()
    target = OUT / f"{label}.gpx"
    shutil.copy2(project.filename, target)
    summary = phase_summary(project)
    (OUT / f"{label}.json").write_text(json.dumps(summary, indent=2) + "\n")
    fractions = ", ".join(
        f"{p['name']}={p.get('weight_fraction', float('nan')):.4f}"
        for p in summary["phases"]
    )
    print(f"snapshot {label}: {fractions}", flush=True)


def set_bounds(project):
    hist = project.histograms()[0]
    bounds = {
        f":{hist.id}:U": (0.0, 40.0),
        f":{hist.id}:W": (2.0, 40.0),
        f":{hist.id}:X": (0.1, 6.0),
        f":{hist.id}:SH/L": (0.005, 0.10),
        f":{hist.id}:Polariz.": (0.5, 1.0),
        f":{hist.id}:Zero": (-0.5, 0.5),
        f":{hist.id}:Shift": (-800.0, 800.0),
    }
    for phase in project.phases():
        bounds[f"{phase.id}:{hist.id}:Scale"] = (1e-8, 1000.0)
        bounds[f"{phase.id}:{hist.id}:Size;i"] = (0.04, 2.0)
        bounds[f"{phase.id}:{hist.id}:Mustrain;i"] = (0.0, 10000.0)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project, hist, phases = fresh_project(
        OUT / "working.gpx",
        [
            {
                "name": "ZnWO4_wolframite_P2c",
                "cif": ".tmp/candidates/znwo4_wolframite_p2c.cif",
                "scale": 90.0,
                "size_um": 0.5,
            },
            {
                "name": "WO3_monoclinic_P21c",
                "cif": ".tmp/candidates/wo3_monoclinic_p21c_1563541.cif",
                "scale": 15.0,
                "size_um": 0.5,
            },
            {
                "name": "ZnO_wurtzite_P63mc",
                "cif": ".tmp/candidates/zno_wurtzite_p63mc.cif",
                "scale": 25.0,
                "size_um": 0.5,
            },
        ],
    )
    project.set_Controls("cycles", 10)
    set_bounds(project)

    # Stage 1: scale and background only.
    for phase in phases.values():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    hist.set_refinements({"Background": {"refine": True}})
    refine_until_stable(project, "01_scale_background")
    snapshot(project, "01_scale_background")

    # Stage 2: one common zero term and all symmetry-independent cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases.values():
        phase.set_refinements({"Cell": True})
    refine_until_stable(project, "02_zero_cells")
    snapshot(project, "02_zero_cells")

    # Stage 3: add Bragg-Brentano specimen displacement after cell convergence.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_until_stable(project, "03_shift")
    snapshot(project, "03_shift")

    # Stage 4: common isotropic instrumental profile, retaining generator priors.
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    refine_until_stable(project, "04_instrument_profile")
    snapshot(project, "04_instrument_profile")

    # Stage 5: one isotropic size term per phase.
    for phase in phases.values():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine_until_stable(project, "05_isotropic_size")
    snapshot(project, "05_isotropic_size")

    # Stage 6: add isotropic microstrain only after size terms are stable.
    for phase in phases.values():
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine_until_stable(project, "06_isotropic_microstrain")
    snapshot(project, "06_isotropic_microstrain")

    print("frozen variables", project.get_Frozen(), flush=True)
    project.save(OUT / "preliminary.gpx")


if __name__ == "__main__":
    main()
