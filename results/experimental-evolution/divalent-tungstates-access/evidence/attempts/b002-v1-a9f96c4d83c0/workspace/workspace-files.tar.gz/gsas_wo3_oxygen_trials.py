#!/usr/bin/env python3
"""Independent, limited WO3 oxygen-coordinate trials from one stable project."""

from __future__ import annotations

import json
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_profile_trials import correlations, fit
from gsas_trials import ROOT, TMP


SOURCE = TMP / "minor_texture" / "wo3_corrected" / "md_110.gpx"
OUT = TMP / "wo3_oxygen_trials"
PHASE = "trial_wo3_wo3_monoclinic_p21c_2311041"


def lattice_matrix(cell):
    a, b, c, alpha, beta, gamma = map(float, cell)
    alpha, beta, gamma = np.radians([alpha, beta, gamma])
    avec = np.array([a, 0.0, 0.0])
    bvec = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    cz = np.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack([avec, bvec, [cx, cy, cz]])


def displacement_A(before, after, cell):
    delta = np.asarray(after, float) - np.asarray(before, float)
    delta -= np.round(delta)
    return float(np.linalg.norm(delta @ lattice_matrix(cell)))


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    reference = G2.G2Project(gpxfile=str(SOURCE))
    labels = [atom.label for atom in reference.phase(PHASE).atoms() if atom.element == "O"]
    rows = []
    for label in labels:
        target = OUT / f"{label}.gpx"
        print(f"WO3 oxygen-coordinate trial {label}", flush=True)
        try:
            project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
            project.set_Frozen()
            project.set_Controls("cycles", 18)
            phase = project.phase(PHASE)
            atom = next(atom for atom in phase.atoms() if atom.label == label)
            before = list(atom.coordinates)
            atom.refinement_flags = "X"
            wr = fit(project, f"WO3 {label} coordinates", max_runs=6)
            after = list(atom.coordinates)
            shift = displacement_A(before, after, phase.data["General"]["Cell"][1:7])
            project.save()
            phase.export_CIF(str(OUT / f"{label}.cif"))
            rows.append(
                {
                    "label": label,
                    "status": "tested",
                    "Rwp": wr,
                    "before": before,
                    "after": after,
                    "displacement_A": shift,
                    "frozen_variables": project.get_Frozen(),
                    "high_correlations": correlations(project),
                    "project": str(target.relative_to(ROOT)),
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "label": label,
                    "status": "unknown",
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )
        print(json.dumps(rows[-1], indent=2), flush=True)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
