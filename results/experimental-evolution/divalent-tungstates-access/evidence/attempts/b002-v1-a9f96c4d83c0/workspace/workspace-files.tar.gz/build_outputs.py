#!/usr/bin/env python3
"""Build fit.csv and result.json from the independent final-project replay."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY_DIR = ROOT / ".tmp" / "replay"
PHASE_METADATA = {
    "ZnWO4_wolframite_P2c": {
        "name": "ZnWO4 (wolframite)",
        "formula": "ZnWO4",
        "space_group": "P2/c",
        "cif_path": "phase_1_ZnWO4_wolframite.cif",
    },
    "trial_wo3_wo3_monoclinic_p21c_2311041": {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P2_1/c",
        "cif_path": "phase_2_WO3_monoclinic.cif",
    },
    "ZnO_wurtzite_P63mc": {
        "name": "ZnO (wurtzite)",
        "formula": "ZnO",
        "space_group": "P6_3mc",
        "cif_path": "phase_3_ZnO_wurtzite.cif",
    },
}
ORDER = [
    "ZnWO4_wolframite_P2c",
    "trial_wo3_wo3_monoclinic_p21c_2311041",
    "ZnO_wurtzite_P63mc",
]


def main():
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError(f"final replay did not pass cleanly: {replay}")
    by_name = {row["name"]: row for row in replay["phases"]}
    if set(by_name) != set(PHASE_METADATA):
        raise RuntimeError(f"unexpected replay phase set: {sorted(by_name)}")
    fractions = [float(by_name[name]["weight_fraction"]) for name in ORDER]
    if abs(sum(fractions) - 1.0) > 1e-10 or min(fractions) <= 0:
        raise RuntimeError(f"invalid replay fractions: {fractions}")

    profile = np.load(REPLAY_DIR / "prediction.npz")
    x = np.asarray(profile["x"], float)
    observed = np.asarray(profile["observed"], float)
    calculated = np.asarray(profile["predicted"], float)
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for row in zip(x, observed, calculated, difference):
            writer.writerow([f"{row[0]:.8f}", f"{row[1]:.8f}", f"{row[2]:.8f}", f"{row[3]:.8f}"])

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_chi_square = float(np.sum(weights * difference**2))
    rwp = float(100.0 * np.sqrt(weighted_chi_square / np.sum(weights * observed**2)))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    n_parameters = 37
    dof = len(observed) - n_parameters
    goodness_of_fit = float(np.sqrt(weighted_chi_square / dof))
    phases = []
    for name, fraction in zip(ORDER, fractions):
        row = dict(PHASE_METADATA[name])
        row["weight_fraction"] = fraction
        phases.append(row)
    result = {
        "phases": phases,
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": 2.64643031705589,
            "goodness_of_fit": goodness_of_fit,
            "weighted_chi_square": weighted_chi_square,
            "n_profile_points": int(len(observed)),
            "n_refined_parameters": n_parameters,
        },
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "replay_validation": {
            "status": replay["status"],
            "project_sha256": replay["project_sha256"],
            "parameters_optimized_during_replay": replay["parameters_optimized"],
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
