#!/usr/bin/env python3
"""Controlled one-effect-at-a-time profile and specimen trials."""

from __future__ import annotations

import argparse
import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_trials import ROOT, TMP, phase_summary


SOURCE = TMP / "uiso_trials" / "mainpol_0.0035.gpx"
OUT = TMP / "profile_trials"
MAIN = "ZnWO4_wolframite_P2c"
WO3 = "trial_wo3_wo3_monoclinic_p21c_2311041"
ZNO = "ZnO_wurtzite_P63mc"


def fit(project, label, max_runs=5):
    hist = project.histograms()[0]
    for run in range(max_runs):
        project.refine(makeBack=False)
        values = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if values.get("Aborted") or not hist.residuals:
            raise RuntimeError(f"{label}: refinement aborted")
        if not np.all(np.isfinite(hist.data["data"][1][3])):
            raise RuntimeError(f"{label}: nonfinite calculated profile")
        print(
            f"{label} run {run + 1}: Rwp={hist.residuals['wR']:.7f} "
            f"shift/esd={values.get('Max shft/sig')}",
            flush=True,
        )
        if abs(float(values.get("Max shft/sig", 999))) < 0.1:
            break
    return float(hist.residuals["wR"])


def correlations(project, cutoff=0.90):
    data = project.data.get("Covariance", {}).get("data", {})
    names = data.get("varyList", [])
    matrix = np.asarray(data.get("covMatrix", []), float)
    if matrix.shape != (len(names), len(names)) or not len(names):
        return []
    errors = np.sqrt(np.maximum(np.diag(matrix), 0))
    denom = np.outer(errors, errors)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    rows = []
    for i in range(len(names)):
        for j in range(i):
            if abs(corr[i, j]) >= cutoff:
                rows.append([names[j], names[i], float(corr[i, j])])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)


def trial_anisotropy(axis):
    tag = "".join(str(value) for value in axis)
    target = OUT / "anisotropy" / f"main_uniaxial_{tag}.gpx"
    try:
        project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
        project.set_Frozen()
        project.set_Controls("cycles", 18)
        hist = project.histograms()[0]
        phase = project.phase(MAIN)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
        for suffix in ("Mustrain;i", "Mustrain;a"):
            variable = f"{phase.id}:{hist.id}:{suffix}"
            project.set_Controls("parmMin", 0.0, variable=variable)
            project.set_Controls("parmMax", 8000.0, variable=variable)
        wr = fit(project, f"uniaxial {tag}")
        project.save()
        values = [float(hap["Mustrain"][1][0]), float(hap["Mustrain"][1][1])]
        return {
            "axis": axis,
            "status": "tested",
            "Rwp": wr,
            "microstrain_equatorial_axial_ppm": values,
            "main_size_um": float(hap["Size"][1][0]),
            "frozen_variables": project.get_Frozen(),
            "high_correlations": correlations(project),
            "project": str(target.relative_to(ROOT)),
        }
    except Exception as exc:
        return {
            "axis": axis,
            "status": "unknown",
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }


def run_anisotropy():
    directory = OUT / "anisotropy"
    directory.mkdir(parents=True, exist_ok=True)
    rows = []
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0]):
        print(f"main-phase uniaxial microstrain axis {axis}", flush=True)
        row = trial_anisotropy(axis)
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    (directory / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_roughness():
    directory = OUT / "roughness"
    directory.mkdir(parents=True, exist_ok=True)
    target = directory / "refined_pair.gpx"
    try:
        project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
        project.set_Frozen()
        project.set_Controls("cycles", 18)
        hist = project.histograms()[0]
        hist.SampleParameters["SurfRoughA"] = [0.30, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
        project.set_Controls("parmMin", 0.05, variable=f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=f":{hist.id}:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=f":{hist.id}:SurfRoughB")
        wr = fit(project, "surface roughness pair")
        project.save()
        result = {
            "status": "tested",
            "Rwp": wr,
            "SurfRoughA": float(hist.SampleParameters["SurfRoughA"][0]),
            "SurfRoughB": float(hist.SampleParameters["SurfRoughB"][0]),
            "frozen_variables": project.get_Frozen(),
            "high_correlations": correlations(project),
            "project": str(target.relative_to(ROOT)),
        }
    except Exception as exc:
        result = {
            "status": "unknown",
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
    (directory / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


def fixed_uiso_trial(phase_name, uiso, source, target):
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    phase = project.phase(phase_name)
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.uiso = float(uiso)
        else:
            atom.ADP = [float(uiso)] * 3 + [0.0, 0.0, 0.0]
        atom.refinement_flags = atom.refinement_flags.replace("U", "")
    wr = fit(project, f"{phase_name} Uiso={uiso:.4f}", max_runs=3)
    project.save()
    return {
        "phase": phase_name,
        "Uiso_A2": uiso,
        "Rwp": wr,
        "frozen_variables": project.get_Frozen(),
        "project": str(target.relative_to(ROOT)),
    }


def run_minor_uiso():
    directory = OUT / "minor_uiso"
    directory.mkdir(parents=True, exist_ok=True)
    values = [0.003, 0.005, 0.008, 0.012, 0.016, 0.020]
    rows = []
    for short, phase_name in (("wo3", WO3), ("zno", ZNO)):
        for value in values:
            target = directory / f"{short}_{value:.3f}.gpx"
            print(f"fixed-Uiso trial {short} {value:.3f}", flush=True)
            try:
                row = fixed_uiso_trial(phase_name, value, SOURCE, target)
                row["status"] = "tested"
            except Exception as exc:
                row = {
                    "phase": phase_name,
                    "Uiso_A2": value,
                    "status": "unknown",
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            rows.append(row)
            print(json.dumps(row, indent=2), flush=True)
    (directory / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("branch", choices=["anisotropy", "roughness", "minor-uiso"])
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    if args.branch == "anisotropy":
        run_anisotropy()
    elif args.branch == "roughness":
        run_roughness()
    else:
        run_minor_uiso()


if __name__ == "__main__":
    main()
