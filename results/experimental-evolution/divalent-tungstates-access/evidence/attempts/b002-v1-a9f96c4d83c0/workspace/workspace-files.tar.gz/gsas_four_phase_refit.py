#!/usr/bin/env python3
"""Refit the tentative triclinic-WO3 addition with all accepted common terms."""

from __future__ import annotations

import json

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_profile_trials import correlations, fit
from gsas_trials import ROOT, TMP, phase_summary


SOURCE = TMP / "closure_trials" / "wo3_additions" / "wo3_triclinic_p-1_converged.gpx"
TEMPLATE = TMP / "minor_texture" / "wo3_corrected" / "md_110.gpx"
TARGET = TMP / "closure_trials" / "four_phase_common_refit.gpx"
CANDIDATE = "closure_wo3_triclinic_p-1"


def copy_flags(project, template):
    hist = project.histograms()[0]
    reference_hist = template.histograms()[0]
    hist.Background[0][1] = reference_hist.Background[0][1]
    for key, value in reference_hist.InstrumentParameters.items():
        if key in hist.InstrumentParameters and len(value) > 2:
            hist.InstrumentParameters[key][2] = value[2]
    for key, value in reference_hist.SampleParameters.items():
        if (
            key in hist.SampleParameters
            and isinstance(value, list)
            and len(value) > 1
            and isinstance(value[1], bool)
        ):
            hist.SampleParameters[key][1] = value[1]
    for reference_phase in template.phases():
        try:
            phase = project.phase(reference_phase.name)
        except Exception:
            continue
        phase.data["General"]["Cell"][0] = reference_phase.data["General"]["Cell"][0]
        for atom, reference_atom in zip(phase.atoms(), reference_phase.atoms()):
            atom.refinement_flags = reference_atom.refinement_flags
        hap = phase.data["Histograms"].get(hist.name)
        reference_hap = reference_phase.data["Histograms"].get(reference_hist.name)
        if not hap or not reference_hap:
            continue
        hap["Scale"][1] = reference_hap["Scale"][1]
        hap["Size"][2] = list(reference_hap["Size"][2])
        hap["Size"][5] = list(reference_hap["Size"][5])
        hap["Mustrain"][2] = list(reference_hap["Mustrain"][2])
        hap["Mustrain"][5] = list(reference_hap["Mustrain"][5])
        hap["Pref.Ori."][2] = reference_hap["Pref.Ori."][2]


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(TARGET))
    template = G2.G2Project(gpxfile=str(TEMPLATE))
    project.set_Frozen()
    copy_flags(project, template)
    hist = project.histograms()[0]
    candidate = project.phase(CANDIDATE)
    candidate.data["General"]["Cell"][0] = True
    candidate.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 18)
    wr = fit(project, "four-phase common refit", max_runs=8)
    project.save()
    result = {
        "status": "tested",
        "Rwp": wr,
        "frozen_variables": project.get_Frozen(),
        "high_correlations": correlations(project, cutoff=0.80),
        "summary": phase_summary(project),
    }
    (TARGET.with_suffix(".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
