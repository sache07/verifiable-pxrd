#!/usr/bin/env python3
"""Sequentially test bounded instrumental-profile terms with rollback."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_trials import ROOT, TMP, phase_summary


SOURCE = TMP / "profile_main_size.gpx"
OUT = TMP / "instrument_opt"


def fit(project, label):
    hist = project.histograms()[0]
    for run in range(5):
        project.refine(makeBack=False)
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rvals.get("Aborted") or not hist.residuals:
            raise RuntimeError(f"{label}: refinement aborted")
        print(
            f"{label} run {run + 1}: Rwp={hist.residuals['wR']:.6f} "
            f"maxshift={rvals.get('Max shft/sig')}",
            flush=True,
        )
        if abs(float(rvals.get("Max shft/sig", 999))) < 0.1:
            break
    return float(hist.residuals["wR"])


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    working = OUT / "working.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(working))
    project.set_Frozen()
    project.set_Controls("cycles", 15)
    hist = project.histograms()[0]
    best = float(hist.residuals["wR"])
    trials = []
    specifications = [
        ("W", 2.0, 40.0),
        ("U", 0.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
    ]
    for index, (parameter, low, high) in enumerate(specifications, 1):
        before = OUT / f"before_{index:02d}_{parameter.replace('/', '_')}.gpx"
        project.save()
        shutil.copy2(project.filename, before)
        hist = project.histograms()[0]
        variable = f":{hist.id}:{parameter}"
        hist.InstrumentParameters[parameter][2] = True
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
        status = "tested"
        try:
            wr = fit(project, parameter)
            value = float(hist.InstrumentParameters[parameter][1])
            frozen = project.get_Frozen()
            if variable in frozen or not low < value < high or wr > best + 1e-4:
                status = "rejected"
        except Exception as exc:
            wr, value, frozen = None, None, []
            status = "unknown"
            error = str(exc)
        trials.append(
            {
                "parameter": parameter,
                "status": status,
                "Rwp": wr,
                "value": value,
                "frozen_variables": frozen,
                **({"error": error} if status == "unknown" else {}),
            }
        )
        if status == "tested":
            best = wr
            project.set_Frozen()
            project.save()
            shutil.copy2(project.filename, OUT / f"accepted_{index:02d}_{parameter.replace('/', '_')}.gpx")
        else:
            project = G2.G2Project(gpxfile=str(before), newgpx=str(working))
            project.set_Frozen()
            project.set_Controls("cycles", 15)
        print(trials[-1], flush=True)
    project.save(OUT / "instrument_accepted.gpx")
    (OUT / "summary.json").write_text(json.dumps(trials, indent=2) + "\n")
    (OUT / "final_summary.json").write_text(json.dumps(phase_summary(project), indent=2) + "\n")


if __name__ == "__main__":
    main()
