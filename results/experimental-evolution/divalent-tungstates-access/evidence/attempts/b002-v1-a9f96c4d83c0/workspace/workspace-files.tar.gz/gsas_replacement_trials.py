#!/usr/bin/env python3
"""Replacement-phase trials from one stable multiphase GSAS-II project."""

from __future__ import annotations

import argparse
import json
import math
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_trials import ROOT, TMP, phase_summary


BASE = TMP / "combined" / "test_size_main.gpx"


def clear_refinement_flags(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        if hist.name not in phase.data.get("Histograms", {}):
            continue
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
    project.set_Frozen()


def refine(project, label, max_runs=3):
    hist = project.histograms()[0]
    for run in range(max_runs):
        project.refine(makeBack=False)
        vals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if vals.get("Aborted") or not hist.residuals:
            raise RuntimeError(f"{label}: GSAS-II refinement aborted")
        if not np.all(np.isfinite(hist.data["data"][1][3])):
            raise RuntimeError(f"{label}: nonfinite profile")
        if vals.get("converged") or abs(float(vals.get("Max shft/sig", 999))) < 0.2:
            break
    return float(hist.residuals["wR"])


def add_trial_phase(project, candidate, trial_name, scale):
    hist = project.histograms()[0]
    phase = project.add_phase(
        str((ROOT / candidate).resolve()),
        phasename=trial_name,
        histograms=[hist],
        fmthint="CIF",
    )
    if phase.name != trial_name:
        raise RuntimeError(f"phase identity changed: {trial_name!r} -> {phase.name!r}")
    hap = phase.data["Histograms"][hist.name]
    hap["Use"] = True
    hap["Scale"] = [float(scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.uiso = 0.01
        else:
            atom.ADP = [0.01, 0.01, 0.01, 0.0, 0.0, 0.0]
        atom.refinement_flags = " "
    return phase


def trial(branch, replace_name, candidate, output_dir):
    stem = Path(candidate).stem
    trial_name = f"trial_{branch}_{stem}"
    output = output_dir / f"{stem}.gpx"
    try:
        project = G2.G2Project(gpxfile=str(BASE), newgpx=str(output))
        project.set_Controls("cycles", 10)
        clear_refinement_flags(project)
        hist = project.histograms()[0]
        old = project.phase(replace_name)
        old_hap = old.data["Histograms"][hist.name]
        starting_scale = max(0.5, float(old_hap["Scale"][0]))
        old_hap["Use"] = False
        old_hap["Scale"] = [0.0, False]
        candidate_phase = add_trial_phase(project, candidate, trial_name, starting_scale)
        # Confirm exactly one phase is active in the replacement branch.
        active_branch = [
            p.name
            for p in project.phases()
            if p.name in {replace_name, trial_name}
            and p.data["Histograms"][hist.name].get("Use", True)
            and p.data["Histograms"][hist.name]["Scale"][0] > 0
        ]
        if active_branch != [trial_name]:
            raise RuntimeError(f"incorrect active replacement set: {active_branch}")
        # Stage 1: all active scales plus the same background basis.
        hist.Background[0][1] = True
        for phase in project.phases():
            hap = phase.data["Histograms"].get(hist.name)
            if hap and hap.get("Use", True) and hap["Scale"][0] > 0:
                hap["Scale"][1] = True
        project.set_Controls("parmMin", 1e-8, variable=f"{candidate_phase.id}:{hist.id}:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{candidate_phase.id}:{hist.id}:Scale")
        wr_scale = refine(project, "scale/background")
        trial_hap = candidate_phase.data["Histograms"][hist.name]
        frozen = project.get_Frozen()
        scale_var = f"{candidate_phase.id}:{hist.id}:Scale"
        if scale_var in frozen or trial_hap["Scale"][0] <= 1.01e-8:
            project.save()
            return {
                "status": "rejected",
                "reason": "stable nonnegative scale collapsed to zero",
                "candidate": candidate,
                "Rwp_scale_background": wr_scale,
                "scale": float(trial_hap["Scale"][0]),
            }
        # Stage 2: only the replacement candidate's symmetry-allowed cell terms.
        candidate_phase.data["General"]["Cell"][0] = True
        wr_cell = refine(project, "candidate cell")
        cell = np.asarray(candidate_phase.data["General"]["Cell"][1:7], float)
        if not np.all(np.isfinite(cell)) or np.min(cell[:3]) <= 1.5:
            raise RuntimeError(f"invalid refined cell: {cell.tolist()}")
        project.save()
        summary = phase_summary(project)
        row = next(p for p in summary["phases"] if p["name"] == trial_name)
        return {
            "status": "tested",
            "candidate": candidate,
            "trial_phase": trial_name,
            "Rwp_scale_background": wr_scale,
            "Rwp_cell": wr_cell,
            "candidate_summary": row,
            "frozen_variables": project.get_Frozen(),
            "project": str(output.relative_to(ROOT)),
        }
    except Exception as exc:
        return {
            "status": "unknown",
            "candidate": candidate,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("branch", choices=["wo3", "zno"])
    parser.add_argument("candidates", nargs="+")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    replace = {
        "wo3": "WO3_monoclinic_P21c",
        "zno": "ZnO_wurtzite_P63mc",
    }[args.branch]
    out = TMP / "replacement_trials" / args.branch
    out.mkdir(parents=True, exist_ok=True)
    results = []
    for candidate in args.candidates:
        print(f"replacement trial {args.branch}: {candidate}", flush=True)
        result = trial(args.branch, replace, candidate, out)
        results.append(result)
        print(
            f"  {result['status']} Rwp={result.get('Rwp_cell')} "
            f"fraction={result.get('candidate_summary', {}).get('weight_fraction')} "
            f"error={result.get('error', '')}",
            flush=True,
        )
    (out / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
