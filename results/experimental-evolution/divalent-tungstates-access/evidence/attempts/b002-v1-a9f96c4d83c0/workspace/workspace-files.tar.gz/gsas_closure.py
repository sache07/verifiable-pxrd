#!/usr/bin/env python3
"""Falsifiable inventory-closure trials from the accepted three-phase model."""

from __future__ import annotations

import json
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_replacement_trials import add_trial_phase, clear_refinement_flags, refine
from gsas_trials import ROOT, TMP, phase_summary


SOURCE = TMP / "uiso_trials" / "mainpol_0.0035.gpx"
OUT = TMP / "closure_trials"
ACTIVE_WO3 = "trial_wo3_wo3_monoclinic_p21c_2311041"

ADDITIONS = [
    "zn3wo6_cu3wo6_type_pa-3.cif",
    "zn3wo6_ca3wo6_type_p21c.cif",
    "zn3wo6_mn3wo6_type_r-3.cif",
    "zn2wo5_pb2moo5_type_c2m.cif",
    "znw2o7_mgmo2o7_type_p21c.cif",
]


def prepare_scale_stage(project, candidate_phase):
    """Use identical nuisance settings and positive scales for an inventory trial."""
    clear_refinement_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if not hap or not hap.get("Use", True) or hap["Scale"][0] <= 0:
            continue
        hap["Scale"][1] = True
        variable = f"{phase.id}:{hist.id}:Scale"
        project.set_Controls("parmMin", 1e-10, variable=variable)
        project.set_Controls("parmMax", 1000.0, variable=variable)
    candidate_hap = candidate_phase.data["Histograms"][hist.name]
    if not candidate_hap.get("Use", True) or candidate_hap["Scale"][0] <= 0:
        raise RuntimeError("candidate was not active with a positive initialized scale")


def active_fraction(project, phase_name):
    summary = phase_summary(project)
    rows = [row for row in summary["phases"] if row["use"] and row["scale"] > 0]
    total = sum(row["mass_product"] for row in rows)
    row = next(row for row in rows if row["name"] == phase_name)
    return row["mass_product"] / total, row


def addition_trial(filename, source=SOURCE, scale=0.5, output_group="additions"):
    stem = Path(filename).stem
    output = OUT / output_group / f"{stem}.gpx"
    trial_name = f"closure_{stem}"
    try:
        output.parent.mkdir(parents=True, exist_ok=True)
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        project.set_Controls("cycles", 12)
        candidate = add_trial_phase(
            project,
            f".tmp/candidates/{filename}",
            trial_name,
            scale=scale,
        )
        prepare_scale_stage(project, candidate)
        wr_scale = refine(project, f"{stem} scale/background", max_runs=4)
        fraction, row = active_fraction(project, trial_name)
        scale_var = f"{candidate.id}:{project.histograms()[0].id}:Scale"
        if scale_var in project.get_Frozen() or row["scale"] <= 1.01e-10:
            project.save()
            return {
                "candidate": filename,
                "status": "rejected",
                "reason": "stable nonnegative scale collapsed to zero",
                "Rwp_scale_background": wr_scale,
                "weight_fraction": fraction,
                "project": str(output.relative_to(ROOT)),
            }
        candidate.data["General"]["Cell"][0] = True
        wr_cell = refine(project, f"{stem} cell", max_runs=4)
        fraction, row = active_fraction(project, trial_name)
        project.save()
        return {
            "candidate": filename,
            "status": "tested",
            "Rwp_scale_background": wr_scale,
            "Rwp_cell": wr_cell,
            "weight_fraction": fraction,
            "candidate_summary": row,
            "frozen_variables": project.get_Frozen(),
            "project": str(output.relative_to(ROOT)),
        }
    except Exception as exc:
        return {
            "candidate": filename,
            "status": "unknown",
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }


def replacement_trial():
    filename = "wo3_monoclinic_p21c_1528915.cif"
    stem = Path(filename).stem
    output = OUT / "wo3_retry" / f"{stem}.gpx"
    trial_name = f"retry_{stem}"
    try:
        project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(output))
        project.set_Controls("cycles", 12)
        hist = project.histograms()[0]
        old = project.phase(ACTIVE_WO3)
        old_hap = old.data["Histograms"][hist.name]
        start_scale = float(old_hap["Scale"][0])
        old_hap["Use"] = False
        old_hap["Scale"] = [0.0, False]
        candidate = add_trial_phase(
            project,
            f".tmp/candidates/{filename}",
            trial_name,
            scale=start_scale,
        )
        prepare_scale_stage(project, candidate)
        branch_active = [
            phase.name
            for phase in project.phases()
            if phase.name in {ACTIVE_WO3, trial_name}
            and phase.data["Histograms"][hist.name].get("Use", True)
            and phase.data["Histograms"][hist.name]["Scale"][0] > 0
        ]
        if branch_active != [trial_name]:
            raise RuntimeError(f"incorrect active replacement branch: {branch_active}")
        wr_scale = refine(project, "standardized WO3 scale/background", max_runs=4)
        fraction, row = active_fraction(project, trial_name)
        scale_var = f"{candidate.id}:{hist.id}:Scale"
        if scale_var in project.get_Frozen() or row["scale"] <= 1.01e-10:
            project.save()
            return {
                "candidate": filename,
                "status": "rejected",
                "reason": "stable nonnegative scale collapsed to zero",
                "Rwp_scale_background": wr_scale,
                "weight_fraction": fraction,
                "project": str(output.relative_to(ROOT)),
            }
        candidate.data["General"]["Cell"][0] = True
        wr_cell = refine(project, "standardized WO3 cell", max_runs=4)
        fraction, row = active_fraction(project, trial_name)
        project.save()
        return {
            "candidate": filename,
            "status": "tested",
            "Rwp_scale_background": wr_scale,
            "Rwp_cell": wr_cell,
            "weight_fraction": fraction,
            "candidate_summary": row,
            "frozen_variables": project.get_Frozen(),
            "project": str(output.relative_to(ROOT)),
        }
    except Exception as exc:
        return {
            "candidate": filename,
            "status": "unknown",
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }


def main():
    G2.SetPrintLevel("warn")
    (OUT / "additions").mkdir(parents=True, exist_ok=True)
    (OUT / "wo3_retry").mkdir(parents=True, exist_ok=True)
    results = []
    for filename in ADDITIONS:
        print(f"closure addition: {filename}", flush=True)
        result = addition_trial(filename)
        results.append(result)
        print(json.dumps(result, indent=2), flush=True)
    (OUT / "additions_summary.json").write_text(json.dumps(results, indent=2) + "\n")
    print("retry standardized WO3 1528915", flush=True)
    retry = replacement_trial()
    (OUT / "wo3_retry_summary.json").write_text(json.dumps(retry, indent=2) + "\n")
    print(json.dumps(retry, indent=2), flush=True)


if __name__ == "__main__":
    main()
