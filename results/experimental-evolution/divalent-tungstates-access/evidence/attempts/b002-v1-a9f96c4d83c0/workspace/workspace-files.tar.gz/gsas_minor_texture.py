#!/usr/bin/env python3
"""March-Dollase axis trials for each retained minor phase."""

from __future__ import annotations

import argparse
import json
import traceback

from GSASII import GSASIIscriptable as G2

from gsas_profile_trials import correlations, fit
from gsas_trials import ROOT, TMP


SOURCE = TMP / "uiso_trials" / "mainpol_0.0035.gpx"
PHASES = {
    "wo3": "trial_wo3_wo3_monoclinic_p21c_2311041",
    "zno": "ZnO_wurtzite_P63mc",
    "triclinic-wo3": "closure_wo3_triclinic_p-1",
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("branch", choices=sorted(PHASES))
    parser.add_argument("--source", type=str, default=str(SOURCE))
    parser.add_argument("--tag", type=str, default="")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    phase_name = PHASES[args.branch]
    directory = TMP / "minor_texture" / (args.branch + args.tag)
    directory.mkdir(parents=True, exist_ok=True)
    rows = []
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
        tag = "".join(str(value) for value in axis)
        target = directory / f"md_{tag}.gpx"
        print(f"{args.branch} MD trial {axis}", flush=True)
        try:
            project = G2.G2Project(gpxfile=args.source, newgpx=str(target))
            project.set_Frozen()
            project.set_Controls("cycles", 18)
            hist = project.histograms()[0]
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            variable = f"{phase.id}:{hist.id}:MD"
            project.set_Controls("parmMin", 0.7, variable=variable)
            project.set_Controls("parmMax", 1.4, variable=variable)
            wr = fit(project, f"{args.branch} MD {tag}", max_runs=5)
            project.save()
            rows.append(
                {
                    "status": "unknown" if variable in project.get_Frozen() else "tested",
                    "axis": axis,
                    "Rwp": wr,
                    "MD_ratio": float(hap["Pref.Ori."][1]),
                    "frozen_variables": project.get_Frozen(),
                    "high_correlations": correlations(project),
                    "project": str(target.relative_to(ROOT)),
                }
            )
        except Exception as exc:
            rows.append(
                {
                    "status": "unknown",
                    "axis": axis,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )
        print(json.dumps(rows[-1], indent=2), flush=True)
    (directory / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
