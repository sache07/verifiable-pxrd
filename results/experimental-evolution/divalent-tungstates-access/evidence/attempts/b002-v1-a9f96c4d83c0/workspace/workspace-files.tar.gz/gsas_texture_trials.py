#!/usr/bin/env python3
"""Common-project March-Dollase axis trials for the principal ZnWO4 phase."""

from __future__ import annotations

import json
import traceback
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_trials import ROOT, TMP


BASE = TMP / "combined" / "inventory_base.gpx"
OUT = TMP / "texture_trials"
PHASE = "ZnWO4_wolframite_P2c"


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]
    results = []
    for axis in axes:
        tag = "".join(str(v) for v in axis)
        target = OUT / f"md_{tag}.gpx"
        print("MD trial", axis, flush=True)
        try:
            project = G2.G2Project(gpxfile=str(BASE), newgpx=str(target))
            project.set_Frozen()
            project.set_Controls("cycles", 12)
            hist = project.histograms()[0]
            phase = project.phase(PHASE)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            variable = f"{phase.id}:{hist.id}:MD"
            project.set_Controls("parmMin", 0.7, variable=variable)
            project.set_Controls("parmMax", 1.4, variable=variable)
            for run in range(4):
                project.refine(makeBack=False)
                rvals = project.data["Covariance"]["data"].get("Rvals", {})
                if rvals.get("Aborted") or not hist.residuals:
                    raise RuntimeError("GSAS-II refinement aborted")
                print(
                    f"  run {run + 1}: Rwp={hist.residuals['wR']:.6f} "
                    f"MD={hap['Pref.Ori.'][1]:.6f} "
                    f"maxshift={rvals.get('Max shft/sig')}",
                    flush=True,
                )
                if abs(float(rvals.get("Max shft/sig", 999))) < 0.1:
                    break
            project.save()
            frozen = project.get_Frozen()
            results.append(
                {
                    "status": "unknown" if variable in frozen else "tested",
                    "axis": axis,
                    "Rwp": float(hist.residuals["wR"]),
                    "MD_ratio": float(hap["Pref.Ori."][1]),
                    "frozen_variables": frozen,
                    "project": str(target.relative_to(ROOT)),
                }
            )
        except Exception as exc:
            results.append(
                {
                    "status": "unknown",
                    "axis": axis,
                    "error": str(exc),
                    "traceback": traceback.format_exc(),
                }
            )
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
    for row in results:
        print(row, flush=True)


if __name__ == "__main__":
    main()
