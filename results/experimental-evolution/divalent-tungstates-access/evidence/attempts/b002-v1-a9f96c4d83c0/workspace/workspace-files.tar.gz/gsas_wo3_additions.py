#!/usr/bin/env python3
"""Test exact-formula WO3 polymorphs as additions to the closed inventory."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2

from gsas_closure import OUT, addition_trial
from gsas_trials import TMP


SOURCE = TMP / "minor_texture" / "wo3_corrected" / "md_110.gpx"
CANDIDATES = [
    "wo3_hexagonal_p6mmm.cif",
    "wo3_tetragonal_p4ncc.cif",
    "wo3_tetragonal_p4nmm.cif",
    "wo3_monoclinic_p21c_1528915.cif",
    "wo3_monoclinic_p21c_1563541.cif",
    "wo3_triclinic_p-1.cif",
    "wo3_orthorhombic_pnma.cif",
]


def main():
    G2.SetPrintLevel("warn")
    rows = []
    for candidate in CANDIDATES:
        print(f"WO3 addition trial: {candidate}", flush=True)
        row = addition_trial(candidate, source=SOURCE, scale=0.10, output_group="wo3_additions")
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    (OUT / "wo3_additions_summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
