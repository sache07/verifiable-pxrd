#!/usr/bin/env python3
"""Stage symmetry-allowed coordinate refinements from the accepted texture model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_trials import ROOT, TMP, phase_summary


SOURCE = TMP / "texture_trials" / "md_111.gpx"
OUT = TMP / "structural"
MAIN = "ZnWO4_wolframite_P2c"
WO3 = "trial_wo3_wo3_monoclinic_p21c_2311041"
ZNO = "ZnO_wurtzite_P63mc"


def refine(project, label, max_runs=5):
    hist = project.histograms()[0]
    for run in range(max_runs):
        project.refine(makeBack=False)
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rvals.get("Aborted") or not hist.residuals:
            raise RuntimeError(f"{label}: refinement aborted")
        if not np.all(np.isfinite(hist.data["data"][1][3])):
            raise RuntimeError(f"{label}: nonfinite profile")
        print(
            f"{label} run {run + 1}: Rwp={hist.residuals['wR']:.6f} "
            f"maxshift={rvals.get('Max shft/sig')} converged={rvals.get('converged')}",
            flush=True,
        )
        if abs(float(rvals.get("Max shft/sig", 999))) < 0.1:
            break


def save_stage(project, tag):
    project.save()
    target = OUT / f"{tag}.gpx"
    shutil.copy2(project.filename, target)
    (OUT / f"{tag}.json").write_text(json.dumps(phase_summary(project), indent=2) + "\n")


def set_coordinate_flags(phase, elements):
    selected = []
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = "X"
            selected.append(atom.label)
    print(f"coordinate stage {phase.name}: {selected}", flush=True)


def main():
    G2.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT / "working.gpx"))
    project.set_Frozen()
    project.set_Controls("cycles", 12)

    main_phase = project.phase(MAIN)
    set_coordinate_flags(main_phase, {"Zn", "W"})
    refine(project, "01_main_cations")
    save_stage(project, "01_main_cations")

    set_coordinate_flags(main_phase, {"O"})
    refine(project, "02_main_oxygen")
    save_stage(project, "02_main_oxygen")

    zno_phase = project.phase(ZNO)
    set_coordinate_flags(zno_phase, {"O"})
    refine(project, "03_zno_internal")
    save_stage(project, "03_zno_internal")

    wo3_phase = project.phase(WO3)
    set_coordinate_flags(wo3_phase, {"W"})
    refine(project, "04_wo3_tungsten")
    save_stage(project, "04_wo3_tungsten")

    set_coordinate_flags(wo3_phase, {"O"})
    refine(project, "05_wo3_oxygen")
    save_stage(project, "05_wo3_oxygen")

    project.save(OUT / "coordinates_full.gpx")
    print("frozen variables", project.get_Frozen(), flush=True)


if __name__ == "__main__":
    main()
