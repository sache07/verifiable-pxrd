# Candidate ledger

All trials use Cu Kα1/Kα2, the same observed histogram, Poisson weights, and a
common staged nuisance model. A failed import, divergent fit, or invalid cell is
recorded as unknown rather than rejected. Candidate names, not phase-list
positions, are used in refinement scripts.

| Branch | Candidate / parent | Initial rationale | Status |
|---|---|---|---|
| ZnWO4 | Wolframite P2/c from CoMoO4 COD 7205001; Co→Zn, Mo→W | Dominant observed families at about 15.8, 19.2, 24.1/24.8, 31.0, 36.7, and 41.6° match this topology; refined cell and geometry remain physical | tested — selected |
| ZnWO4 | Triclinic P-1 from ZnMoO4 COD 1528282; Mo→W | Same cation and stoichiometry, symmetry/topology-diverse | unknown — scale/background trial aborted |
| ZnWO4 | Scheelite I41/a from CaWO4 COD 7219229; Ca→Zn | Common ABO4 topology and symmetry-diverse control | unknown — scale/background trial aborted |
| ZnWO4 | Fergusonite C2/c from CaWO4 COD 1546035; Ca→Zn; transformed to the conventional setting | Distorted scheelite-family control | unknown — scale/background trial aborted |
| ZnWO4 | HgWO4-type C2/c COD 2012578; Hg→Zn | Same W–O composition and monoclinic alternative | unknown — scale/background trial aborted |
| WO3 | Hexagonal P6/mmm COD 1004057 | Exact formula, symmetry-diverse control | rejected — scale collapsed to about 0.15 wt% and fit was inferior |
| WO3 | Orthorhombic record COD 1010618 | Exact formula control | rejected before fitting — source geometry has a 0.464 Å contact |
| WO3 | Tetragonal P4/ncc COD 1521532 and P4/nmm COD 1521533 | Exact-formula polymorphs | rejected — common-setting replacement fits were substantially worse; addition scales were below 0.2 wt% |
| WO3 | Monoclinic P21/c COD 1528915, standardized setting | Exact-formula monoclinic alternative | rejected — imported after standardization but replacement Rwp was 11.50% versus 10.22% for the then-current model |
| WO3 | Monoclinic P21/c COD 1563541 | Exact-formula monoclinic alternative | rejected — worse replacement fit and only about 0.05 wt% as an added polymorph |
| WO3 | Monoclinic P21/c COD 2311041 | Exact formula; coherent precursor peak families | tested — selected; preferred orientation [110] was uniquely supported |
| WO3 | Triclinic P-1 COD 2106293 | Lower-symmetry exact-formula alternative | rejected as a reported extra phase — replacement did not explain the full WO3 pattern; as an addition it stabilized at only 0.7–1.2 wt% and duplicated the principal WO3 lines |
| WO3 | Orthorhombic Pnma COD 2107312 | Exact-formula polymorph | rejected as replacement (inferior fit); later addition trial aborted and remains unknown in that role |
| ZnO | Wurtzite P63mc COD 9004178 | Narrow residuals near 32.05, 34.9, 36.7, 47.9, and 63.5°; unreacted precursor is plausible | tested — selected; corrected-cell branch and isotropic microstrain were stable |
| ZnO | Rocksalt Fm-3m COD 1534836 | High-pressure/metastable polymorph control | unknown — scale/background replacement trial aborted |
| ZnO | Zincblende F-43m COD 1537875 | Metastable polymorph control | rejected — worse fit and only about 0.4 wt% in the common replacement screen |
| Zn3WO6 | Cu3WO6-type Pa-3 COD 1527404; Cu→Zn | Charge-balanced zinc-rich intermediate and symmetry-diverse prototype | rejected — stable scale only 0.12 wt% with negligible improvement |
| Zn3WO6 | Ca3WO6-type P21/c COD 1563081; Ca→Zn | Charge-balanced zinc-rich intermediate and monoclinic prototype | unknown — GSAS-II setting import failed |
| Zn3WO6 | Mn3WO6-type R-3 COD 2002703; Mn→Zn | Charge-balanced zinc-rich intermediate and trigonal prototype | rejected — stable scale only 0.11 wt% with negligible improvement |
| Zn2WO5 | Pb2MoO5-type C2/m COD 7220560; Pb→Zn, Mo→W | Charge-balanced 2:1 intermediate; no exact A2WO5 record was available | rejected — stable scale below 0.05 wt% and no fit gain |
| ZnW2O7 | MgMo2O7-type P21/c COD 2106441; Mg→Zn, Mo→W | Charge-balanced W-rich intermediate with chemically close divalent/Mo analogue | unknown — scale/background refinement aborted |
