#!/usr/bin/env python3
"""Fair single-triclinic-WO3 replacement trial from the accepted nuisance model."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2

from gsas_replacement_trials import add_trial_phase, clear_refinement_flags, refine
from gsas_trials import ROOT, TMP, phase_summary


SOURCE = TMP / "minor_texture" / "wo3_corrected" / "md_110.gpx"
TARGET = TMP / "closure_trials" / "wo3_single_triclinic.gpx"
OLD = "trial_wo3_wo3_monoclinic_p21c_2311041"
NEW = "replacement_wo3_triclinic_p-1"


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(TARGET))
    project.set_Controls("cycles", 18)
    hist = project.histograms()[0]
    old = project.phase(OLD)
    old_hap = old.data["Histograms"][hist.name]
    scale = float(old_hap["Scale"][0])
    size = float(old_hap["Size"][1][0])
    md_ratio = float(old_hap["Pref.Ori."][1])
    md_axis = list(old_hap["Pref.Ori."][3])
    old_hap["Use"] = False
    old_hap["Scale"] = [0.0, False]
    phase = add_trial_phase(
        project,
        ".tmp/candidates/wo3_triclinic_p-1.cif",
        NEW,
        scale=scale,
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][1][0] = size
    hap["Pref.Ori."][1] = md_ratio
    hap["Pref.Ori."][3] = md_axis
    clear_refinement_flags(project)
    hist.Background[0][1] = True
    for active in project.phases():
        active_hap = active.data["Histograms"].get(hist.name)
        if active_hap and active_hap.get("Use", True) and active_hap["Scale"][0] > 0:
            active_hap["Scale"][1] = True
            variable = f"{active.id}:{hist.id}:Scale"
            project.set_Controls("parmMin", 1e-10, variable=variable)
            project.set_Controls("parmMax", 1000.0, variable=variable)
    wr_scale = refine(project, "single triclinic WO3 scale/background", max_runs=5)
    phase.data["General"]["Cell"][0] = True
    wr_cell = refine(project, "single triclinic WO3 cell", max_runs=6)
    project.save()
    result = {
        "status": "tested",
        "Rwp_scale_background": wr_scale,
        "Rwp_cell": wr_cell,
        "frozen_variables": project.get_Frozen(),
        "summary": phase_summary(project),
    }
    (TARGET.with_suffix(".json")).write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
