#!/usr/bin/env python3
"""Save the selected GSAS-II model and export exactly one CIF per active phase."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "phase_strain" / "zno" / "isotropic_iso.gpx"
FINAL = ROOT / "final.gpx"
EXPORTS = {
    "ZnWO4_wolframite_P2c": ROOT / "phase_1_ZnWO4_wolframite.cif",
    "trial_wo3_wo3_monoclinic_p21c_2311041": ROOT / "phase_2_WO3_monoclinic.cif",
    "ZnO_wurtzite_P63mc": ROOT / "phase_3_ZnO_wurtzite.cif",
}


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.save()
    hist = project.histograms()[0]
    active = {
        phase.name
        for phase in project.phases()
        if phase.data["Histograms"].get(hist.name, {}).get("Use", True)
        and phase.data["Histograms"].get(hist.name, {}).get("Scale", [0.0])[0] > 0
    }
    if active != set(EXPORTS):
        raise RuntimeError(f"unexpected active phase set: {sorted(active)}")
    for name, path in EXPORTS.items():
        project.phase(name).export_CIF(str(path))
        print(f"exported {name} -> {path.name}", flush=True)
    print(f"saved {FINAL.name}; Rwp={hist.residuals['wR']:.7f}", flush=True)


if __name__ == "__main__":
    main()
