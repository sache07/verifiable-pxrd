#!/usr/bin/env python3
"""GSAS-II candidate screening and staged refinement helpers.

Run this file with the GSAS-II Python environment.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp"
CANDIDATES = TMP / "candidates"


def fresh_project(path: Path, phase_specs: list[dict]):
    """Create a project with one observed histogram and explicitly named phases."""
    path.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(path))
    hist = project.add_powder_histogram(
        str(TMP / "pattern.xye"),
        str(TMP / "instrument.instprm"),
        fmthint="xye",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    # The first terms approximate the monotone low-angle tail before fitting.
    background = [1050.0, -420.0, 160.0, -75.0] + [0.0] * 4
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(background),
                "coeffs": background,
                "refine": False,
            },
        }
    )
    phases = {}
    for spec in phase_specs:
        name = spec["name"]
        cif = Path(spec["cif"])
        if not cif.is_absolute():
            cif = ROOT / cif
        phase = project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        if phase.name != name:
            raise RuntimeError(f"phase identity changed: {name!r} -> {phase.name!r}")
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = bool(spec.get("use", True))
        hap["Scale"] = [float(spec.get("scale", 20.0)), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(spec.get("size_um", 1.0))
        hap["Size"][1][1] = float(spec.get("size_um", 1.0))
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = float(spec.get("microstrain_ppm", 500.0))
        hap["Mustrain"][1][1] = float(spec.get("microstrain_ppm", 500.0))
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
        # Put every imported phase on the same physically plausible Uiso start.
        for atom in phase.atoms():
            uiso = float(spec.get("uiso", 0.01))
            if atom.adp_flag == "I":
                atom.uiso = uiso
            else:
                atom.ADP = [uiso, uiso, uiso, 0.0, 0.0, 0.0]
            atom.refinement_flags = " "
        phases[name] = phase
    project.set_Controls("cycles", 6)
    project.save()
    return project, hist, phases


def checked_refine(project, label: str):
    """Refine and perform immediate numerical/physical sanity checks."""
    project.refine(makeBack=False)
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    if not hist.residuals or rvals.get("Aborted"):
        raise RuntimeError(f"{label}: GSAS-II refinement did not complete")
    arrays = hist.data["data"][1]
    if not np.all(np.isfinite(arrays[3])):
        raise RuntimeError(f"{label}: nonfinite calculated profile")
    for phase in project.phases():
        cell = phase.data["General"]["Cell"][1:7]
        if not np.all(np.isfinite(cell)) or min(cell[:3]) <= 1.5:
            raise RuntimeError(f"{label}: invalid cell for {phase.name}: {cell}")
        hap = phase.data["Histograms"][hist.name]
        if not np.isfinite(hap["Scale"][0]):
            raise RuntimeError(f"{label}: nonfinite scale for {phase.name}")
    return float(hist.residuals.get("wR", math.nan))


def phase_summary(project, status="tested"):
    hist = project.histograms()[0]
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        rows.append(
            {
                "name": phase.name,
                "use": bool(hap.get("Use", True)),
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "mass_product": float(hap["Scale"][0] * phase.data["General"]["Mass"]),
                "cell": [float(x) for x in phase.data["General"]["Cell"][1:7]],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    masses = np.array([max(0.0, row["mass_product"]) for row in rows])
    if masses.sum() > 0:
        for row, fraction in zip(rows, masses / masses.sum()):
            row["weight_fraction"] = float(fraction)
    arrays = hist.data["data"][1]
    return {
        "status": status,
        "project": str(Path(project.filename).relative_to(ROOT)),
        "histogram": hist.name,
        "residuals": {
            k: float(v)
            for k, v in hist.residuals.items()
            if isinstance(v, (int, float, np.integer, np.floating))
        },
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "calculated_min": float(np.min(arrays[3])),
        "calculated_max": float(np.max(arrays[3])),
        "background_min": float(np.min(arrays[4])),
        "phases": rows,
    }


def single_trial(candidate: str, group: str) -> dict:
    name = Path(candidate).stem
    output = TMP / "trials" / group / f"{name}.gpx"
    spec = {"name": name, "cif": candidate, "scale": 50.0}
    try:
        project, hist, phases = fresh_project(output, [spec])
        phase = phases[name]
        hap = phase.data["Histograms"][hist.name]
        # Stage 1: only the phase scale and smooth background.
        hap["Scale"] = [50.0, True]
        hist.set_refinements({"Background": {"refine": True}})
        checked_refine(project, "scale/background")
        # Stage 2: common angular offset and symmetry-allowed cell terms.
        phase.set_refinements({"Cell": True})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        checked_refine(project, "zero/cell")
        project.save()
        result = phase_summary(project)
    except Exception as exc:
        result = {
            "status": "unknown",
            "candidate": candidate,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
    result["candidate"] = candidate
    return result


def run_single_group(group: str, candidates: list[str]) -> None:
    outdir = TMP / "trials" / group
    outdir.mkdir(parents=True, exist_ok=True)
    results = []
    for candidate in candidates:
        print(f"TRIAL {group}: {candidate}", flush=True)
        result = single_trial(candidate, group)
        results.append(result)
        residual = result.get("residuals", {}).get("wR")
        print(
            f"  {result['status']} wR={residual} "
            f"error={result.get('error', '')}",
            flush=True,
        )
    (outdir / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("group")
    parser.add_argument("candidates", nargs="+")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run_single_group(args.group, args.candidates)


if __name__ == "__main__":
    main()
