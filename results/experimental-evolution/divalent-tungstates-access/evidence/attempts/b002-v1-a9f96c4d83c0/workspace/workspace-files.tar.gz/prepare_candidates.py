#!/usr/bin/env python3
"""Prepare chemically transformed PXRD candidate CIFs and GSAS-II inputs."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser, CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)
CANDIDATES = ROOT / ".tmp" / "candidates"


def cod_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def transform(
    name: str,
    cod_id: str,
    substitutions: dict[str, str],
    standardize: bool = False,
) -> dict:
    source = cod_path(cod_id)
    structure = CifParser(str(source)).parse_structures(primitive=False)[0]
    parent_formula = structure.composition.formula
    structure.replace_species(substitutions)
    if standardize:
        structure = SpacegroupAnalyzer(structure, symprec=0.02).get_conventional_standard_structure()
    target = CANDIDATES / f"{name}.cif"
    CifWriter(structure, symprec=0.01, refine_struct=False).write_file(target)
    checked = CifParser(str(target)).parse_structures(primitive=False)[0]
    sga = SpacegroupAnalyzer(checked, symprec=0.02)
    distances = checked.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    return {
        "name": name,
        "path": str(target.relative_to(ROOT)),
        "parent_cod_id": cod_id,
        "parent_path": str(source),
        "parent_formula": parent_formula,
        "substitutions": substitutions,
        "standardized_setting": standardize,
        "target_formula": checked.composition.formula,
        "space_group": sga.get_space_group_symbol(),
        "space_group_number": sga.get_space_group_number(),
        "cell": [*checked.lattice.abc, *checked.lattice.angles],
        "site_count": len(checked),
        "density_g_cm3": float(checked.density),
        "minimum_pair_distance_A": float(np.min(distances)),
    }


def copy_candidate(name: str, cod_id: str) -> dict:
    return transform(name, cod_id, {})


def write_gsas_inputs() -> None:
    pattern = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    with (ROOT / ".tmp" / "pattern.xye").open("w", newline="") as stream:
        out = csv.writer(stream, delimiter=" ", lineterminator="\n")
        for two_theta, intensity in pattern:
            out.writerow((f"{two_theta:.8f}", f"{intensity:.8f}", f"{np.sqrt(max(intensity, 1.0)):.8f}"))
    (ROOT / ".tmp" / "instrument.instprm").write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.12;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:20.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


def main() -> None:
    CANDIDATES.mkdir(parents=True, exist_ok=True)
    records = [
        transform("znwo4_wolframite_p2c", "7205001", {"Co": "Zn", "Mo": "W"}),
        transform("znwo4_triclinic_p-1", "1528282", {"Mo": "W"}),
        transform("znwo4_scheelite_i41a", "7219229", {"Ca": "Zn"}),
        transform("znwo4_fergusonite_c2c", "1546035", {"Ca": "Zn"}, standardize=True),
        transform("znwo4_hgwo4_type_c2c", "2012578", {"Hg": "Zn"}),
        copy_candidate("wo3_hexagonal_p6mmm", "1004057"),
        copy_candidate("wo3_orthorhombic_p21m", "1010618"),
        copy_candidate("wo3_tetragonal_p4ncc", "1521532"),
        copy_candidate("wo3_tetragonal_p4nmm", "1521533"),
        transform("wo3_monoclinic_p21c_1528915", "1528915", {}, standardize=True),
        copy_candidate("wo3_monoclinic_p21c_1563541", "1563541"),
        copy_candidate("wo3_monoclinic_p21c_2311041", "2311041"),
        copy_candidate("wo3_triclinic_p-1", "2106293"),
        copy_candidate("wo3_orthorhombic_pnma", "2107312"),
        copy_candidate("zno_wurtzite_p63mc", "9004178"),
        copy_candidate("zno_rocksalt_fm3m", "1534836"),
        copy_candidate("zno_zincblende_f-43m", "1537875"),
        transform("zn3wo6_cu3wo6_type_pa-3", "1527404", {"Cu": "Zn"}),
        transform("zn3wo6_ca3wo6_type_p21c", "1563081", {"Ca": "Zn"}),
        transform("zn3wo6_mn3wo6_type_r-3", "2002703", {"Mn2+": "Zn2+"}),
        transform("zn2wo5_pb2moo5_type_c2m", "7220560", {"Pb": "Zn", "Mo": "W"}),
        transform("znw2o7_mgmo2o7_type_p21c", "2106441", {"Mg": "Zn", "Mo": "W"}),
    ]
    write_gsas_inputs()
    (CANDIDATES / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")
    for row in records:
        print(
            f"{row['name']:<38} {row['target_formula']:<18} "
            f"SG {row['space_group_number']:>3} {row['space_group']:<8} "
            f"dmin={row['minimum_pair_distance_A']:.3f} A"
        )


if __name__ == "__main__":
    main()
