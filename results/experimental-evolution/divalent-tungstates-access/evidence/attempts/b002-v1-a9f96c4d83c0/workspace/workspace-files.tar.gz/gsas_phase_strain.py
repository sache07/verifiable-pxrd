#!/usr/bin/env python3
"""Isotropic and allowed uniaxial microstrain trials for retained minor phases."""

from __future__ import annotations

import argparse
import json
import traceback

from GSASII import GSASIIscriptable as G2

from gsas_profile_trials import correlations, fit
from gsas_trials import ROOT, TMP


DEFAULT_SOURCE = TMP / "minor_texture" / "wo3_corrected" / "md_110.gpx"
PHASES = {
    "wo3": "trial_wo3_wo3_monoclinic_p21c_2311041",
    "zno": "ZnO_wurtzite_P63mc",
}


def trial(source, phase_name, model, axis, target):
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    project.set_Frozen()
    project.set_Controls("cycles", 18)
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = model
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [True, False, False]
    if model == "uniaxial":
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
    for suffix in (["Mustrain;i"] if model == "isotropic" else ["Mustrain;i", "Mustrain;a"]):
        variable = f"{phase.id}:{hist.id}:{suffix}"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 8000.0, variable=variable)
    tag = "iso" if model == "isotropic" else "".join(str(value) for value in axis)
    wr = fit(project, f"{phase_name} strain {tag}", max_runs=6)
    project.save()
    return {
        "status": "tested",
        "model": model,
        "axis": axis,
        "Rwp": wr,
        "microstrain_equatorial_axial_ppm": [
            float(hap["Mustrain"][1][0]),
            float(hap["Mustrain"][1][1]),
        ],
        "size_um": float(hap["Size"][1][0]),
        "frozen_variables": project.get_Frozen(),
        "high_correlations": correlations(project),
        "project": str(target.relative_to(ROOT)),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("branch", choices=sorted(PHASES))
    parser.add_argument("--source", default=str(DEFAULT_SOURCE))
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    directory = TMP / "phase_strain" / args.branch
    directory.mkdir(parents=True, exist_ok=True)
    settings = [("isotropic", [0, 0, 1])] + [
        ("uniaxial", axis) for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0])
    ]
    rows = []
    for model, axis in settings:
        tag = "iso" if model == "isotropic" else "".join(str(value) for value in axis)
        target = directory / f"{model}_{tag}.gpx"
        print(f"{args.branch} strain trial {model} {axis}", flush=True)
        try:
            row = trial(args.source, PHASES[args.branch], model, axis, target)
        except Exception as exc:
            row = {
                "status": "unknown",
                "model": model,
                "axis": axis,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
        rows.append(row)
        print(json.dumps(row, indent=2), flush=True)
    (directory / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
