from __future__ import annotations

import argparse
import json
from math import cos, radians, sin, sqrt

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE_COORDINATES = {
    "SrCO3": {"Sr": [(0.7583, 0.25, 0.4159)]},
    "WO3_2311041": {
        "W": [(0.028, 0.037, 0.746), (0.534, 0.023, 0.750)]
    },
}


def lattice_matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = (cell[f"length_{axis}"] for axis in "abc")
    alpha, beta, gamma = (
        radians(cell[f"angle_{axis}"]) for axis in ("alpha", "beta", "gamma")
    )
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * cos(gamma), b * sin(gamma), 0.0])
    cx = c * cos(beta)
    cy = c * (cos(alpha) - cos(beta) * cos(gamma)) / sin(gamma)
    cz = sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.array([va, vb, [cx, cy, cz]])


def constrain_element(phase, element: str, target_rms: float) -> dict[str, float]:
    atoms = [atom for atom in phase.atoms() if atom.element == element]
    sources = SOURCE_COORDINATES[phase.name][element]
    if len(atoms) != len(sources):
        raise ValueError(f"Unexpected {element} atom count in {phase.name}")
    lattice = lattice_matrix(phase.get_cell())
    deltas = []
    for atom, source in zip(atoms, sources):
        delta = np.asarray(atom.coordinates, float) - np.asarray(source, float)
        delta -= np.rint(delta)
        deltas.append(delta)
    current_rms = sqrt(np.mean([np.linalg.norm(delta @ lattice) ** 2 for delta in deltas]))
    factor = min(1.0, target_rms / current_rms) if current_rms else 0.0
    for atom, source, delta in zip(atoms, sources, deltas):
        atom.coordinates = (np.asarray(source) + factor * delta) % 1.0
        atom.refinement_flags = atom.refinement_flags.replace("X", "")
    return {"before_rms_A": current_rms, "target_rms_A": target_rms, "factor": factor}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--sr-rms", type=float, default=0.04)
    parser.add_argument("--w-rms", type=float, default=0.04)
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    G2sc.SetPrintLevel("error")
    project = G2sc.G2Project(args.input)
    project.save(args.output)
    project["Controls"]["data"]["max cyc"] = args.cycles

    constraints = {
        "SrCO3": constrain_element(project.phase("SrCO3"), "Sr", args.sr_rms),
        "WO3_2311041": constrain_element(
            project.phase("WO3_2311041"), "W", args.w_rms
        ),
    }
    project.do_refinements([{}])
    project.save(args.output)
    histogram = project.histograms()[0]
    print(
        "CONSTRAINED_RESULT "
        + json.dumps(
            {
                "rwp": histogram.get_wR(),
                "fractions": {
                    key: value[0]
                    for key, value in histogram.ComputeMassFracs().items()
                },
                "constraints": constraints,
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
