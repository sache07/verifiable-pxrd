from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


COD = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c04/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cod_id")
    ap.add_argument("output")
    ap.add_argument("--refine-w", action="store_true")
    ap.add_argument("--po-axis", default="0,1,0")
    ap.add_argument("--polarization", type=float, default=0.84)
    ap.add_argument("--fix-uiso", type=float)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    axis = [int(v) for v in args.po_axis.split(",")]

    G2sc.SetPrintLevel("error")
    p = G2sc.G2Project("analysis_work/full_pol_84.gpx")
    p.save(args.output)
    h = p.histograms()[0]
    h.data["Instrument Parameters"][0]["Polariz."][1] = args.polarization
    h.data["Instrument Parameters"][0]["Polariz."][2] = False
    controls = p["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-6
    controls["SVDtol"] = 1e-8

    old = p.phase("WO3")
    old_hap = old.data["Histograms"][h.name]
    old_hap["Use"] = False
    alt = p.add_phase(
        str(cod_path(args.cod_id)),
        phasename=f"WO3_{args.cod_id}",
        histograms=[h],
        fmthint="CIF",
    )
    hap = alt.data["Histograms"][h.name]
    old_mass = old.data["General"]["Mass"]
    new_mass = alt.data["General"]["Mass"]
    hap["Scale"] = [old_hap["Scale"][0] * old_mass / new_mass, True]
    hap["Size"] = copy.deepcopy(old_hap["Size"])
    hap["Size"][2] = [True, False, False]
    hap["Mustrain"] = copy.deepcopy(old_hap["Mustrain"])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][2] = [True, False, False]
    hap["Pref.Ori."] = copy.deepcopy(old_hap["Pref.Ori."])
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    alt.set_refinements({"Cell": True})

    p.index_ids()
    for atom in alt.atoms():
        atom.uiso = args.fix_uiso if args.fix_uiso is not None else 0.010
        atom.refinement_flags = "X" if args.refine_w and atom.element == "W" else " "
        if args.fix_uiso is None:
            atom.refinement_flags += "U"
    if args.fix_uiso is None:
        vars_ = [f"{alt.id}::AUiso:{i}" for i in range(len(alt.atoms()))]
        p.add_EquivConstr(vars_, reloadIdx=False)

    p.do_refinements([{}])
    p.save(args.output)
    result = {
        "cod_id": args.cod_id,
        "rwp": h.get_wR(),
        "fractions": {k: v[0] for k, v in h.ComputeMassFracs().items()},
        "cell": alt.get_cell(),
        "size": hap["Size"][1],
        "strain": hap["Mustrain"][1],
        "po": {"axis": hap["Pref.Ori."][3], "ratio": hap["Pref.Ori."][1]},
        "uiso": [a.uiso for a in alt.atoms()],
        "atoms": [{"label": a.label, "element": a.element, "xyz": list(a.coordinates)} for a in alt.atoms()],
    }
    print("CANDIDATE_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
