from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path("analysis_work")


def summary(p, label):
    h = p.histograms()[0]
    inst = h.data["Instrument Parameters"][0]
    print(f"\n--- {label} Rwp={h.get_wR():.6f} mass={h.ComputeMassFracs()}")
    print("inst", {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    print("sample", {k: h.data["Sample Parameters"][k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]})
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        print(ph.name, "size", hap["Size"][:3], "strain", hap["Mustrain"][:4], "cell", ph.get_cell())


def run(p, label):
    p.save(str(WORK / f"physical_{label}_pre.gpx"))
    p.do_refinements([{}])
    p.save(str(WORK / f"physical_{label}.gpx"))
    summary(p, label)


def set_instrument_flags(h, enabled):
    inst = h.data["Instrument Parameters"][0]
    for key, row in inst.items():
        if isinstance(row, list) and len(row) > 2:
            row[2] = key in enabled


def set_profile_flags(ph, hname, size=False, strain=False):
    hap = ph.data["Histograms"][hname]
    hap["Size"][2] = [bool(size), False, False]
    hap["Mustrain"][2] = [bool(strain), False, False]


def main():
    p = G2sc.G2Project(str(WORK / "trial_02_cells_shift.gpx"))
    p.save(str(WORK / "physical.gpx"))
    h = p.histograms()[0]
    p["Controls"]["data"]["max cyc"] = 10
    p["Controls"]["data"]["min dM/M"] = 1e-6
    p["Controls"]["data"]["SVDtol"] = 1e-8

    inst = h.data["Instrument Parameters"][0]
    for key, value in {"U": 20.0, "V": 0.0, "W": 12.0, "X": 1.0, "SH/L": 0.02}.items():
        inst[key][1] = value
    set_instrument_flags(h, set())

    starts = {"SrWO4": (0.18, 2500.0), "WO3": (0.20, 3000.0), "SrCO3": (0.20, 2500.0)}
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        size, strain = starts[ph.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        set_profile_flags(ph, h.name, size=True, strain=True)
    run(p, "01_phase_profile")

    # Fit only the Gaussian instrument terms with the positive phase widths fixed.
    for ph in p.phases():
        set_profile_flags(ph, h.name, size=False, strain=False)
    set_instrument_flags(h, {"U", "W"})
    run(p, "02_instrument_gaussian")

    # Fit Lorentzian instrument width and axial asymmetry separately.
    set_instrument_flags(h, {"X", "SH/L"})
    run(p, "03_instrument_lorentz")

    # Re-equilibrate phase widths while the instrument is held.
    set_instrument_flags(h, set())
    for ph in p.phases():
        set_profile_flags(ph, h.name, size=True, strain=True)
    run(p, "04_phase_profile")

    p.save(str(WORK / "physical_final.gpx"))


if __name__ == "__main__":
    main()
