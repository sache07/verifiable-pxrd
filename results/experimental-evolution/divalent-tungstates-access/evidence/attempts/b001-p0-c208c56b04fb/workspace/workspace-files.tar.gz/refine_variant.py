from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def parse_axis(text: str):
    vals = [int(v) for v in text.split(",")]
    if len(vals) != 3 or not any(vals):
        raise argparse.ArgumentTypeError("axis must be h,k,l")
    return vals


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--polarization", type=float)
    ap.add_argument("--rough-a", type=float)
    ap.add_argument("--rough-b", type=float)
    ap.add_argument("--srwo4-oxygen", action="store_true")
    ap.add_argument("--coords-phase")
    ap.add_argument("--coords-elements", help="comma-separated element symbols")
    ap.add_argument(
        "--fix-phase-uiso",
        action="append",
        default=[],
        metavar="PHASE=VALUE",
        help="fix all isotropic displacement parameters in a phase",
    )
    ap.add_argument("--po-phase")
    ap.add_argument("--po-axis", type=parse_axis)
    ap.add_argument("--po-start", type=float, default=1.0)
    ap.add_argument("--refine-all-po", action="store_true")
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()

    G2sc.SetPrintLevel("error")
    p = G2sc.G2Project(args.input)
    p.save(args.output)
    h = p.histograms()[0]
    controls = p["Controls"]["data"]
    controls["max cyc"] = args.cycles
    controls["min dM/M"] = 1e-6
    controls["SVDtol"] = 1e-8

    if args.polarization is not None:
        h.data["Instrument Parameters"][0]["Polariz."][1] = args.polarization
        h.data["Instrument Parameters"][0]["Polariz."][2] = False
    if args.rough_a is not None:
        h.data["Sample Parameters"]["SurfRoughA"] = [args.rough_a, False]
    if args.rough_b is not None:
        h.data["Sample Parameters"]["SurfRoughB"] = [args.rough_b, False]

    if args.srwo4_oxygen:
        for atom in p.phase("SrWO4").atoms():
            atom.refinement_flags = "XU" if atom.element == "O" else "U"

    if args.coords_phase:
        if not args.coords_elements:
            ap.error("--coords-elements is required with --coords-phase")
        selected = {v.strip() for v in args.coords_elements.split(",") if v.strip()}
        for atom in p.phase(args.coords_phase).atoms():
            atom.refinement_flags = "XU" if atom.element in selected else "U"

    for item in args.fix_phase_uiso:
        try:
            phase_name, raw_value = item.rsplit("=", 1)
            value = float(raw_value)
        except Exception as exc:
            ap.error(f"invalid --fix-phase-uiso value {item!r}: {exc}")
        for atom in p.phase(phase_name).atoms():
            atom.uiso = value
            atom.refinement_flags = atom.refinement_flags.replace("U", "")

    if args.po_phase:
        if args.po_axis is None:
            ap.error("--po-axis is required with --po-phase")
        for phase in p.phases():
            hap = phase.data["Histograms"][h.name]
            hap["Pref.Ori."][2] = False
        phase = p.phase(args.po_phase)
        hap = phase.data["Histograms"][h.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.po_start
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = args.po_axis

    if args.refine_all_po:
        for phase in p.phases():
            hap = phase.data["Histograms"][h.name]
            hap["Pref.Ori."][2] = bool(hap.get("Use", True))

    p.do_refinements([{}])
    p.save(args.output)
    result = {
        "output": args.output,
        "rwp": h.get_wR(),
        "fractions": {k: v[0] for k, v in h.ComputeMassFracs().items()},
        "polarization": h.data["Instrument Parameters"][0]["Polariz."][1],
        "roughness": {
            "A": h.data["Sample Parameters"]["SurfRoughA"][0],
            "B": h.data["Sample Parameters"]["SurfRoughB"][0],
        },
        "phases": {},
    }
    for phase in p.phases():
        hap = phase.data["Histograms"][h.name]
        result["phases"][phase.name] = {
            "uiso": [a.uiso for a in phase.atoms()],
            "coordinates": [list(a.coordinates) for a in phase.atoms()],
            "po_ratio": hap["Pref.Ori."][1],
            "po_axis": hap["Pref.Ori."][3],
        }
    print("VARIANT_RESULT " + json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
