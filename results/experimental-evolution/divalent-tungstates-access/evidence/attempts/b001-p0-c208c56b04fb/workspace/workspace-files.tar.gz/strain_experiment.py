from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def axis(text: str) -> list[int]:
    value = [int(part) for part in text.split(",")]
    if len(value) != 3 or not any(value):
        raise argparse.ArgumentTypeError("axis must be h,k,l")
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("phase")
    parser.add_argument("axis", type=axis)
    parser.add_argument("--fix-perpendicular", type=float)
    parser.add_argument("--refine-size", action="store_true")
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()

    G2sc.SetPrintLevel("error")
    project = G2sc.G2Project(args.input)
    project.save(args.output)
    histogram = project.histograms()[0]
    project["Controls"]["data"]["max cyc"] = args.cycles
    hap = project.phase(args.phase).data["Histograms"][histogram.name]
    initial = float(hap["Mustrain"][1][0])
    axial = float(hap["Mustrain"][1][1]) if hap["Mustrain"][0] == "uniaxial" else initial
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = (
        args.fix_perpendicular if args.fix_perpendicular is not None else initial
    )
    hap["Mustrain"][1][1] = axial
    hap["Mustrain"][2] = [args.fix_perpendicular is None, True, False]
    hap["Mustrain"][3] = args.axis
    if args.refine_size:
        hap["Size"][2] = [True, False, False]
    project.do_refinements([{}])
    project.save(args.output)
    print(
        "STRAIN_RESULT "
        + json.dumps(
            {
                "phase": args.phase,
                "axis": args.axis,
                "rwp": histogram.get_wR(),
                "strain": hap["Mustrain"][1],
                "fractions": {
                    key: value[0]
                    for key, value in histogram.ComputeMassFracs().items()
                },
            },
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
