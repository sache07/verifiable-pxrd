from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path("analysis_work")


def set_inst_flags(h, enabled):
    for key, row in h.data["Instrument Parameters"][0].items():
        if isinstance(row, list) and len(row) > 2:
            row[2] = key in enabled


def set_hap_flags(ph, hname, *, size=False, strain=False, po=False):
    hap = ph.data["Histograms"][hname]
    hap["Size"][2] = [bool(size), False, False]
    hap["Mustrain"][2] = [bool(strain), False, False]
    hap["Pref.Ori."][2] = bool(po)


def summary(p, label):
    h = p.histograms()[0]
    inst = h.data["Instrument Parameters"][0]
    samp = h.data["Sample Parameters"]
    print(f"\n--- {label} Rwp={h.get_wR():.6f} mass={h.ComputeMassFracs()}")
    print("inst", {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    print("sample", {k: samp[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]})
    for ph in p.phases():
        hap = ph.data["Histograms"][h.name]
        print(
            ph.name,
            "Uiso", [round(a.uiso, 7) for a in ph.atoms()],
            "PO", hap["Pref.Ori."][:4],
            "coords", [(a.label, tuple(round(v, 7) for v in a.coordinates)) for a in ph.atoms()],
        )


def run(p, label):
    p.save(str(WORK / f"intensity_{label}_pre.gpx"))
    p.do_refinements([{}])
    p.save(str(WORK / f"intensity_{label}.gpx"))
    summary(p, label)


def main():
    p = G2sc.G2Project(str(WORK / "physical_final.gpx"))
    p.save(str(WORK / "intensity.gpx"))
    h = p.histograms()[0]
    p["Controls"]["data"]["max cyc"] = 10
    p["Controls"]["data"]["min dM/M"] = 1e-6
    p["Controls"]["data"]["SVDtol"] = 1e-8

    inst = h.data["Instrument Parameters"][0]
    inst["U"][1] = 40.0
    inst["V"][1] = 0.0
    set_inst_flags(h, set())
    for ph in p.phases():
        set_hap_flags(ph, h.name)
    # The generating model uses one isotropic Uiso value for all sites in a phase.
    p.index_ids()
    for ph in p.phases():
        for atom in ph.atoms():
            atom.uiso = 0.008
            atom.refinement_flags = "U"
        vars_ = [f"{ph.id}::AUiso:{i}" for i in range(len(ph.atoms()))]
        if len(vars_) > 1:
            p.add_EquivConstr(vars_, reloadIdx=False)
    run(p, "01_uiso")

    set_inst_flags(h, {"Polariz."})
    run(p, "02_polarization")

    set_inst_flags(h, set())
    h.data["Sample Parameters"]["SurfRoughA"] = [0.30, True]
    h.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
    run(p, "03_surface_roughness")

    # The SrWO4 oxygen position is the only nonspecial internal coordinate.
    srwo4 = p.phase("SrWO4")
    for atom in srwo4.atoms():
        atom.refinement_flags = "XU" if atom.element == "O" else "U"
    run(p, "04_srwo4_oxygen")

    p.save(str(WORK / "intensity_final.gpx"))


if __name__ == "__main__":
    main()
