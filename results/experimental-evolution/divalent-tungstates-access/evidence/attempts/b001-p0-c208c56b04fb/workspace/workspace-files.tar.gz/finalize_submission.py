from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE_PROJECT = Path("analysis_work/joint2_pol_860.gpx")
FINAL_PROJECT = Path("final.gpx")
EXPORTS = {
    "SrWO4": Path("phase_SrWO4.cif"),
    "WO3_2311041": Path("phase_WO3.cif"),
    "SrCO3": Path("phase_SrCO3.cif"),
}


def main() -> None:
    G2sc.SetPrintLevel("error")
    project = G2sc.G2Project(str(SOURCE_PROJECT))

    # Remove the superseded WO3 trial model. It was disabled during refinement,
    # but the submitted project should contain only the three modeled phases.
    del project.data["Phases"]["WO3"]
    phase_branch = next(branch for branch in project.names if branch[0] == "Phases")
    phase_branch.remove("WO3")
    histogram = project.histograms()[0]
    histogram.data.get("Reflection Lists", {}).pop("WO3", None)

    # Constraints contain persistent object identifiers, including the removed
    # trial phase. The final snapshot needs none of them for forward replay.
    constraints = project.data["Constraints"]["data"]
    for key in ("Hist", "HAP", "Phase", "Global"):
        constraints[key] = []
    project.index_ids()
    project.save(str(FINAL_PROJECT))

    # Reload the serialized object before exporting, then suppress covariance-
    # based rounding so the CIFs retain sufficient digits for replay checks.
    project = G2sc.G2Project(str(FINAL_PROJECT))
    histogram = project.histograms()[0]
    if {phase.name for phase in project.phases()} != set(EXPORTS):
        raise RuntimeError("Final project phase inventory is not the expected three phases")
    saved_covariance = project.data["Covariance"]["data"]
    project.data["Covariance"]["data"] = {}
    for name, path in EXPORTS.items():
        project.phase(name).export_CIF(str(path))
    project.data["Covariance"]["data"] = saved_covariance

    arrays = [np.asarray(row, float) for row in histogram.data["data"][1][:6]]
    x, observed, weights, calculated, background, residual = arrays
    public_x, public_y = np.loadtxt(
        "inputs/pattern.csv", delimiter=",", skiprows=1, unpack=True
    )
    if not np.allclose(x, public_x, rtol=0, atol=1e-8):
        raise RuntimeError("Project and public angular grids differ")
    if not np.allclose(observed, public_y, rtol=0, atol=1e-8):
        raise RuntimeError("Project and public observations differ")
    fit = np.column_stack(
        [public_x, public_y, calculated, public_y - calculated, background]
    )
    np.savetxt(
        "fit.csv",
        fit,
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
    )

    covariance = saved_covariance
    rvals = covariance.get("Rvals", {})
    fractions = histogram.ComputeMassFracs()
    rp = 100.0 * np.sum(np.abs(public_y - calculated)) / np.sum(public_y)
    output = {
        "histogram": histogram.name,
        "rwp_percent": histogram.get_wR(),
        "rp_percent": float(rp),
        "gof": rvals.get("GOF"),
        "chi_square": rvals.get("chisq"),
        "n_observations": len(public_x),
        "n_variables": rvals.get("Nvars"),
        "fractions": {
            name: {"value": value[0], "formal_esd": value[1]}
            for name, value in fractions.items()
        },
        "cells": {name: project.phase(name).get_cell() for name in EXPORTS},
        "exports": {name: str(path) for name, path in EXPORTS.items()},
        "calculated_min": float(calculated.min()),
        "background_min": float(background.min()),
    }
    print("FINALIZATION_RESULT " + json.dumps(output, sort_keys=True))


if __name__ == "__main__":
    main()
