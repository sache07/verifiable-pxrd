import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.signal import find_peaks, peak_widths
from scipy import sparse
from scipy.sparse.linalg import spsolve


def load_pattern(path: Path):
    data = np.genfromtxt(path, delimiter=",", names=True)
    return data["two_theta_deg"], data["intensity"]


def arpls(y, lam=2e7, ratio=1e-5, max_iter=50):
    """Asymmetrically reweighted penalized least-squares baseline."""
    y = np.asarray(y, dtype=float)
    n = y.size
    d = sparse.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(n - 2, n))
    h = lam * (d.T @ d)
    w = np.ones(n)
    z = y.copy()
    for _ in range(max_iter):
        z_prev = z
        z = spsolve(sparse.diags(w, 0) + h, w * y)
        residual = y - z
        neg = residual[residual < 0]
        if neg.size < 2:
            break
        mu = neg.mean()
        sigma = neg.std(ddof=1) or 1.0
        exponent = np.clip(2.0 * (residual - (2.0 * sigma - mu)) / sigma, -60, 60)
        w = 1.0 / (1.0 + np.exp(exponent))
        if np.linalg.norm(z - z_prev) / max(np.linalg.norm(z), 1.0) < ratio:
            break
    return z


def main():
    x, y = load_pattern(Path("inputs/pattern.csv"))
    baseline = arpls(y)
    signal = y - baseline
    smooth = gaussian_filter1d(signal, 1.25)
    peaks, props = find_peaks(
        smooth,
        prominence=75,
        height=45,
        distance=max(2, int(round(0.055 / np.median(np.diff(x))))),
    )
    widths = peak_widths(smooth, peaks, rel_height=0.5)
    fwhm_deg = widths[0] * np.median(np.diff(x))
    order = np.argsort(props["prominences"])[::-1]

    print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={np.median(np.diff(x)):.7f}")
    print("intensity percentiles", np.percentile(y, [0, 1, 10, 50, 90, 99, 100]))
    print("baseline endpoints/range", baseline[0], baseline[-1], baseline.min(), baseline.max())
    print(f"detected peaks={len(peaks)}")
    print("rank  two_theta   Iobs    I-bg   prominence  FWHM")
    for rank, oi in enumerate(order, start=1):
        p = peaks[oi]
        print(
            f"{rank:3d} {x[p]:10.5f} {y[p]:7.1f} {signal[p]:7.1f} "
            f"{props['prominences'][oi]:10.1f} {fwhm_deg[oi]:7.4f}"
        )

    out = Path("analysis_plots")
    out.mkdir(exist_ok=True)
    fig, ax = plt.subplots(figsize=(16, 6))
    ax.plot(x, y, lw=0.65, color="black")
    ax.plot(x, baseline, lw=1.0, color="tab:red")
    ax.set(xlabel=r"$2\theta$ (deg)", ylabel="counts", xlim=(x.min(), x.max()))
    fig.tight_layout()
    fig.savefig(out / "pattern_full.png", dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(3, 1, figsize=(16, 10), sharey=False)
    for ax, lo, hi in zip(axes, [9.8, 40, 70], [40, 70, 100.2]):
        sel = (x >= lo) & (x <= hi)
        ax.plot(x[sel], y[sel], lw=0.7, color="black")
        ax.plot(x[sel], baseline[sel], lw=0.9, color="tab:red")
        psel = peaks[(x[peaks] >= lo) & (x[peaks] <= hi)]
        ax.plot(x[psel], y[psel], "v", ms=3, color="tab:blue")
        ax.set_xlim(lo, hi)
        ax.set_ylabel("counts")
    axes[-1].set_xlabel(r"$2\theta$ (deg)")
    fig.tight_layout()
    fig.savefig(out / "pattern_segments.png", dpi=180)
    plt.close(fig)

    with open(out / "peaks.csv", "w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta_deg", "intensity", "height_over_baseline", "prominence", "fwhm_deg"])
        for oi in np.argsort(x[peaks]):
            p = peaks[oi]
            writer.writerow([x[p], y[p], signal[p], props["prominences"][oi], fwhm_deg[oi]])


if __name__ == "__main__":
    main()
