from __future__ import annotations

from pathlib import Path
from pprint import pformat

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path("analysis_work")
COD = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c04/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    print(f"\n===== {label}: Rwp={hist.get_wR()} =====")
    print("mass fractions", hist.ComputeMassFracs())
    inst = hist.data["Instrument Parameters"][0]
    print(
        "instrument",
        {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."]},
    )
    sample = hist.data["Sample Parameters"]
    print(
        "sample",
        {k: sample[k][0] for k in ["Shift", "SurfRoughA", "SurfRoughB"]},
    )
    print("background", hist.data["Background"][0])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell", phase.get_cell(),
            "scale", hap["Scale"][0],
            "size", hap["Size"][:3],
            "strain", hap["Mustrain"][:4],
            "PO", hap["Pref.Ori."][:4],
        )


def refine(project: G2sc.G2Project, label: str) -> None:
    project.save(str(WORK / f"trial_{label}_pre.gpx"))
    project.do_refinements([{}])
    project.save(str(WORK / f"trial_{label}.gpx"))
    summarize(project, label)


def main() -> None:
    project = G2sc.G2Project(newgpx=str(WORK / "trial.gpx"))
    hist = project.add_powder_histogram(
        str(WORK / "pattern.xye"),
        str(WORK / "lab_cuka.instprm"),
        fmthint="xye",
    )
    phase_specs = [
        ("SrWO4", WORK / "initial_SrWO4.cif"),
        ("WO3", cod_path("1528915")),
        ("SrCO3", cod_path("9008198")),
    ]
    phases = [
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        for name, path in phase_specs
    ]

    controls = project["Controls"]["data"]
    controls["max cyc"] = 8
    controls["min dM/M"] = 1e-5
    controls["SVDtol"] = 1e-8

    # Sample-height estimate from the indexed SrWO4 peak positions.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Shift"] = [547.0, False]

    # Smooth baseline estimates, used only to initialize a flexible polynomial.
    fixed_points = [
        (10.001231, 1662.417), (14.999775, 966.406), (19.998319, 654.693),
        (24.996863, 566.643), (29.995407, 486.750), (35.004817, 445.827),
        (40.003361, 398.922), (45.001905, 445.859), (50.000449, 419.479),
        (54.998993, 454.309), (59.997537, 399.458), (64.996081, 376.739),
        (69.994625, 378.887), (75.004036, 394.524), (80.002580, 369.645),
        (85.001124, 385.121), (89.999668, 332.667), (94.998212, 337.761),
        (99.996756, 297.251),
    ]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "FixedPoints": fixed_points,
                "fit fixed points": True,
                "refine": True,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, "01_scale_background")

    # Refine phase cells and specimen displacement, retaining nominal zero first.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "02_cells_shift")

    # Separate the common instrumental width from each phase's size/strain broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    starts = {
        "SrWO4": (0.25, 1800.0),
        "WO3": (0.20, 1800.0),
        "SrCO3": (0.20, 1800.0),
    }
    for phase in phases:
        size, strain = starts[phase.name]
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = size
        hap["Mustrain"][1][0] = strain
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": size, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, "03_profile")

    # Let angular zero share the remaining common position residual.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "04_zero")

    project.save(str(WORK / "trial_final.gpx"))


if __name__ == "__main__":
    main()
