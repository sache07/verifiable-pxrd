from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c04/cif")
OUT = Path("analysis_work")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def read_structure(cod_id: str) -> Structure:
    return CifParser(cod_path(cod_id)).parse_structures(primitive=False)[0]


def write_symmetry_cif(structure: Structure, path: Path) -> None:
    CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(path)


def main() -> None:
    OUT.mkdir(exist_ok=True)

    # Exact-A-site scheelite analogue SrMoO4 (COD 2300460), with Mo -> W.
    srwo4 = read_structure("2300460")
    srwo4.replace_species({"Mo": "W"})
    srwo4 = Structure(
        # Peak-position fit with the common Bragg-Brentano specimen shift
        # separated from the lattice gives this close starting cell.
        Lattice.tetragonal(5.38565, 11.90228),
        srwo4.species,
        srwo4.frac_coords,
        site_properties=srwo4.site_properties,
    )
    write_symmetry_cif(srwo4, OUT / "initial_SrWO4.cif")

    # Room-temperature monoclinic gamma-WO3 and orthorhombic strontianite.
    wo3 = read_structure("1528915")
    write_symmetry_cif(wo3, OUT / "initial_WO3.cif")

    srco3 = read_structure("9008198")
    write_symmetry_cif(srco3, OUT / "initial_SrCO3.cif")

    data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
    x = data["two_theta_deg"]
    y = data["intensity"]
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        OUT / "pattern.xye",
        np.column_stack([x, y, sigma]),
        fmt=["%.8f", "%.8f", "%.8f"],
        header="two_theta_deg intensity sigma",
        comments="# ",
    )

    (OUT / "lab_cuka.instprm").write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


if __name__ == "__main__":
    main()
