#!/usr/bin/env python3
"""Screen permitted March-Dollase axes for the accepted secondary phases."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


AXES = [None, [0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    if len(sys.argv) not in (3, 4):
        raise SystemExit(
            "usage: screen_secondary_texture.py INPUT.gpx OUTPUT_DIR [PHASE_INDICES]"
        )
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    results = []
    phase_indices = (
        tuple(int(item) for item in sys.argv[3].split(","))
        if len(sys.argv) == 4 else (1, 2)
    )
    for phase_index in phase_indices:
        for axis in AXES:
            tag = "none" if axis is None else "".join(str(v) for v in axis)
            output = outdir / f"phase{phase_index}_{tag}.gpx"
            project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
            controls = project.data["Controls"]["data"]
            controls["parmMinDict"] = {}
            controls["parmMaxDict"] = {}
            controls["parmFrozen"] = {"FrozenList": []}
            project.index_ids()
            hist = project.histogram(0)
            clear_flags(project)
            hist.Background[0][1] = True
            for phase in project.phases():
                phase.data["Histograms"][hist.name]["Scale"][1] = True
            phase = project.phases()[phase_index]
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            if axis is not None:
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = axis
                project.set_Controls("parmMin", 0.7, variable=f"{phase_index}:0:MD")
                project.set_Controls("parmMax", 1.4, variable=f"{phase_index}:0:MD")
            for _ in range(2):
                controls["parmFrozen"] = {"FrozenList": []}
                project.set_Controls("cycles", 10)
                project.save()
                project.refine(makeBack=False)
            project.save()
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            record = {
                "phase_index": phase_index,
                "phase": phase.name,
                "axis": axis,
                "Rwp_percent": float(hist.get_wR()),
                "MD_ratio": float(hap["Pref.Ori."][1]),
                "converged": rvals.get("converged"),
                "max_shift_esd": rvals.get("Max shft/sig"),
                "frozen": list(project.get_Frozen()),
                "output": str(output),
            }
            results.append(record)
            print(json.dumps(record), flush=True)
    (outdir / "screen.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
