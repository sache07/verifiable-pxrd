#!/usr/bin/env python3
"""Develop one substituted wolframite parent to a common nuisance checkpoint."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def run(project: G2.G2Project, label: str, cycles: int = 12) -> dict:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "cell": phase.get_cell(),
        "shift_um": hist.SampleParameters["Shift"][0],
        "W": hist.InstrumentParameters["W"][1],
        "size_um": hap["Size"][1][0],
        "MD_ratio": hap["Pref.Ori."][1],
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
    }
    print(json.dumps(record), flush=True)
    return record


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: screen_wolframite_parent.py START.cif OUTPUT.gpx")
    cif = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    work = cif.parent
    G2.SetPrintLevel("error")
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(work / "pattern.xye"), str(work / "instrument.instprm"), fmthint="xye"
    )
    phase = project.add_phase(
        str(cif), phasename="ZnWO4_wolframite", histograms=[hist], fmthint="CIF"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-600.0, False]
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["W"][1] = 10.0
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1000.0] + [0.0] * 11,
            "refine": True,
        }
    })
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [10.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.060
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [1, 1, 1]
    project.save()
    project.index_ids()
    for variable, low, high in (
        (":0:Shift", -800.0, 800.0),
        (":0:W", 2.0, 40.0),
        ("0:0:Scale", 0.0, 1000.0),
        ("0:0:Size;i", 0.04, 1.5),
        ("0:0:MD", 0.7, 1.4),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    records = []
    records.append(run(project, "scale_background"))
    phase.set_refinements({"Cell": True})
    hist.SampleParameters["Shift"][1] = True
    records.append(run(project, "cell_shift"))
    hist.InstrumentParameters["W"][2] = True
    hap["Size"][2][0] = True
    hap["Pref.Ori."][2] = True
    records.append(run(project, "profile_texture"))
    records.append(run(project, "profile_texture_settle"))
    output.with_suffix(".parent_screen.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
