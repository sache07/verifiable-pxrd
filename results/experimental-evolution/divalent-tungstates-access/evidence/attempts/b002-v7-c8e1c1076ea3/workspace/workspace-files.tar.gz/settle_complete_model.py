#!/usr/bin/env python3
"""Converge the accepted multiphase model with bounded physical nuisance terms."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    values = hist.ComputeMassFracs()
    return {name: float(value[0]) for name, value in values.items()}


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: settle_complete_model.py INPUT.gpx OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hist = project.histogram(0)
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["Zero"][2] = False
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["U"][2] = False

    for variable, low, high in (
        (":0:Shift", -800.0, 800.0),
        (":0:W", 2.0, 40.0),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(float(hap["Scale"][0]) * 20.0, 10.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
    project.set_Controls("parmMin", 0.7, variable="0:0:MD")
    project.set_Controls("parmMax", 1.4, variable="0:0:MD")

    clear_flags(project)
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    hist.InstrumentParameters["W"][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
    project.phases()[0].data["Histograms"][hist.name]["Pref.Ori."][2] = True

    records = []
    for pass_index in range(4):
        controls["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "fractions": fractions(project),
            "cells": {phase.name: phase.get_cell() for phase in project.phases()},
            "sizes_um": {
                phase.name: float(phase.data["Histograms"][hist.name]["Size"][1][0])
                for phase in project.phases()
            },
            "shift_um": float(hist.SampleParameters["Shift"][0]),
            "W": float(hist.InstrumentParameters["W"][1]),
            "MD_ratio": float(project.phases()[0].data["Histograms"][hist.name]["Pref.Ori."][1]),
            "converged": rvals.get("converged"),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
        }
        records.append(record)
        print(json.dumps(record), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    clear_flags(project)
    project.save()
    output.with_suffix(".settle.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
