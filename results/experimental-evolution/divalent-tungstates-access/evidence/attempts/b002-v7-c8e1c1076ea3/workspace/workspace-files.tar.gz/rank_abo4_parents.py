#!/usr/bin/env python3
"""Rank symmetry-diverse ABO4 parents after identical ZnWO4 adaptation."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
import sys

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Lattice, Structure


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/index.json.gz"
)
CIFS = INDEX.parent / "cif"
TARGET_VOLUME_PER_FORMULA = 132.9762108795943 / 2.0


def cif_path(cod_id: str) -> Path:
    return CIFS / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def is_abo4(formula: str, system: str) -> bool:
    try:
        comp = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return False
    return (
        len(comp) == 3
        and "O" in comp
        and abs(float(comp["O"]) - 4.0) < 1.0e-6
        and sorted(float(v) for key, v in comp.items() if key != "O") == [1.0, 1.0]
        and set(comp) == set(system.split("-"))
    )


def target_structure(source: Structure, mapping: dict[str, str]) -> Structure:
    structure = source.copy()
    structure.remove_oxidation_states()
    structure.replace_species(mapping)
    oxygen = float(structure.composition.get_el_amt_dict().get("O", 0.0))
    formula_units = oxygen / 4.0
    if formula_units <= 0:
        raise ValueError("no ABO4 formula units")
    target_volume = TARGET_VOLUME_PER_FORMULA * formula_units
    factor = (target_volume / float(structure.volume)) ** (1.0 / 3.0)
    lattice = Lattice(np.asarray(structure.lattice.matrix) * factor)
    return Structure(lattice, structure.species, structure.frac_coords)


def broaden(x, peaks, intensities, fwhm, shift):
    sigma = fwhm / 2.354820045
    out = np.zeros_like(x)
    for center, intensity in zip(peaks + shift, intensities):
        lo = np.searchsorted(x, center - 4.5 * sigma)
        hi = np.searchsorted(x, center + 4.5 * sigma)
        if hi > lo:
            out[lo:hi] += intensity * np.exp(-0.5 * ((x[lo:hi] - center) / sigma) ** 2)
    return out


def rank_pattern(x, residual, weight, pattern):
    peaks = np.asarray(pattern.x, dtype=float)
    intensities = np.asarray(pattern.y, dtype=float)
    best = None
    for fwhm in (0.10, 0.16, 0.24, 0.36):
        for shift in np.linspace(-0.30, 0.30, 41):
            trial = broaden(x, peaks, intensities, fwhm, float(shift))
            denominator = float(np.sum(weight * trial * trial))
            if denominator <= 0:
                continue
            amplitude = max(0.0, float(np.sum(weight * residual * trial)) / denominator)
            improvement = float(
                np.sum(weight * residual * residual)
                - np.sum(weight * (residual - amplitude * trial) ** 2)
            )
            candidate = (improvement, amplitude, fwhm, float(shift))
            if best is None or candidate[0] > best[0]:
                best = candidate
    return best, peaks, intensities


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: rank_abo4_parents.py PROFILE.csv OUTPUT.json")
    table = np.loadtxt(sys.argv[1], delimiter=",", skiprows=1)
    x, observed, calculated, residual = table[:, :4].T
    weight = 1.0 / np.maximum(observed, 1.0)
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    calculator = XRDCalculator(wavelength=1.540598)
    records = []
    for system, entries in index.items():
        elements = system.split("-")
        if "O" not in elements or len(elements) != 3:
            continue
        cations = [item for item in elements if item != "O"]
        for formula, cod_id, space_group, r_factor in entries:
            if not is_abo4(formula, system):
                continue
            base = {
                "parent_system": system,
                "parent_formula": formula,
                "cod_id": str(cod_id),
                "space_group_number": int(space_group),
                "reported_R": r_factor,
            }
            try:
                source = Structure.from_file(cif_path(str(cod_id)), primitive=False)
                source_symbols = {item.symbol for item in source.composition.elements}
                if not set(cations).issubset(source_symbols):
                    raise ValueError("parsed source is missing formula cations")
                for zinc_parent, tungsten_parent in (cations, cations[::-1]):
                    target = target_structure(
                        source, {zinc_parent: "Zn", tungsten_parent: "W"}
                    )
                    pattern = calculator.get_pattern(
                        target, two_theta_range=(float(x[0]), float(x[-1]))
                    )
                    ranked, peaks, intensities = rank_pattern(
                        x, residual, weight, pattern
                    )
                    if ranked is None:
                        continue
                    improvement, amplitude, fwhm, shift = ranked
                    records.append({
                        **base,
                        "mapping": {zinc_parent: "Zn", tungsten_parent: "W"},
                        "adapted_volume_A3": float(target.volume),
                        "adapted_lattice": target.lattice.as_dict(),
                        "weighted_SSE_improvement": improvement,
                        "amplitude": amplitude,
                        "trial_fwhm_deg": fwhm,
                        "trial_shift_deg": shift,
                        "strongest_peaks_deg": [
                            float(v) for v in peaks[np.argsort(intensities)[::-1][:14]]
                        ],
                    })
            except Exception as exc:
                records.append({**base, "error": str(exc)})
    records.sort(
        key=lambda item: item.get("weighted_SSE_improvement", -1.0), reverse=True
    )
    Path(sys.argv[2]).write_text(json.dumps(records, indent=2) + "\n")
    for item in records[:60]:
        print(json.dumps(item), flush=True)


if __name__ == "__main__":
    main()
