#!/usr/bin/env python3
"""Prepare physically comparable wolframite starts and GSAS-II input files."""

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)
WORK = ROOT / ".tmp" / "refine"


def cod_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


TARGET = Lattice.monoclinic(4.6900, 5.7200, 4.9300, 90.60)


def adapted_structure(cod_id: str, substitutions: dict[str, str]) -> Structure:
    structure = Structure.from_file(cod_path(cod_id), primitive=False)
    for index, site in enumerate(structure):
        symbol = site.specie.symbol
        if symbol in substitutions:
            structure.replace(index, substitutions[symbol])
    structure.remove_oxidation_states()
    return Structure(
        TARGET,
        structure.species,
        structure.frac_coords,
        site_properties=structure.site_properties,
    )


def periodic_distance(frac, target) -> float:
    delta = (np.asarray(frac) - np.asarray(target) + 0.5) % 1.0 - 0.5
    return float(np.linalg.norm(delta))


def canonical_wolframite(structure: Structure, reference: Structure | None) -> Structure:
    if reference is not None:
        matcher = StructureMatcher(
            ltol=0.4,
            stol=0.5,
            angle_tol=10,
            primitive_cell=False,
            scale=False,
            attempt_supercell=False,
        )
        aligned = matcher.get_s2_like_s1(reference, structure)
        if aligned is None:
            raise ValueError("candidate does not align with the wolframite reference")
        structure = aligned

    targets = [
        ("Zn", [0.5, 0.33, 0.75]),
        ("W", [0.0, 0.18, 0.25]),
        ("O", [0.22, 0.10, 0.56]),
        ("O", [0.26, 0.38, 0.10]),
    ]
    representatives = []
    for element, target in targets:
        sites = [site for site in structure if site.specie.symbol == element]
        representatives.append(min(sites, key=lambda site: periodic_distance(site.frac_coords, target)).frac_coords)
    return Structure.from_spacegroup(
        "P2/c", TARGET, [item[0] for item in targets], representatives
    )


def write_wolframite_start(
    cod_id: str,
    substitutions: dict[str, str],
    name: str,
    reference: Structure,
) -> None:
    candidate = canonical_wolframite(adapted_structure(cod_id, substitutions), reference)
    CifWriter(candidate, symprec=1.0e-3, refine_struct=False).write_file(WORK / name)


def main() -> None:
    WORK.mkdir(parents=True, exist_ok=True)
    reference = adapted_structure("7205001", {"Co": "Zn", "Mo": "W"})
    reference = canonical_wolframite(reference, None)
    CifWriter(reference, symprec=1.0e-3, refine_struct=False).write_file(
        WORK / "znwo4_from_comoo4.cif"
    )
    write_wolframite_start("2100243", {"Mn": "Zn", "Re": "W"}, "znwo4_from_mnreo4.cif", reference)
    write_wolframite_start("2002235", {"Fe": "Zn", "Nb": "W"}, "znwo4_from_fenbo4.cif", reference)
    write_wolframite_start("1524100", {"In": "Zn", "Nb": "W"}, "znwo4_from_innbo4.cif", reference)
    write_wolframite_start("4329321", {"In": "Zn", "Ta": "W"}, "znwo4_from_intao4.cif", reference)

    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(WORK / "pattern.xye", np.column_stack((x, y, sigma)), fmt="%.8f %.6f %.6f")

    (WORK / "instrument.instprm").write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano start\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


if __name__ == "__main__":
    main()
