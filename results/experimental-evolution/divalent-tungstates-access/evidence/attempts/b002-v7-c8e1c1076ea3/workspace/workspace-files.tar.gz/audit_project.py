#!/usr/bin/env python3
"""Read-only audit of a completed GSAS-II powder project."""

from __future__ import annotations

import json
import hashlib
import gc
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrMain as G2st


def correlations(covariance: dict, limit: int = 20) -> list[dict]:
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if not names or matrix.shape != (len(names), len(names)):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denominator = np.outer(sigma, sigma)
    corr = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator > 0)
    pairs = []
    for left in range(len(names)):
        for right in range(left):
            pairs.append({
                "left": names[left],
                "right": names[right],
                "correlation": float(corr[left, right]),
            })
    pairs.sort(key=lambda item: abs(item["correlation"]), reverse=True)
    return pairs[:limit]


def geometry(phase) -> dict:
    controls, data = phase.InitDisAgl(False)
    controls["Factors"] = [1.25, 0.0]
    _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
    atoms = phase.atoms()
    minima: dict[str, float] = {}
    for center, rows in distances.items():
        for row in rows:
            other = int(row[0])
            pair = "-".join(sorted((atoms[center].element, atoms[other].element)))
            value = float(row[-2])
            minima[pair] = min(minima.get(pair, value), value)
    return {
        "pair_min_A": minima,
        "catastrophic_contacts": [
            [str(left), str(right), float(distance)]
            for left, right, distance in phase.ShortDistances(useAll=False)
        ],
    }


def residual_extrema(hist, count: int = 15) -> list[dict]:
    x, observed, _, calculated = [
        np.asarray(item, dtype=float) for item in hist.data["data"][1][:4]
    ]
    standardized = (observed - calculated) / np.sqrt(np.maximum(observed, 1.0))
    fitted_limits = hist.data.get("Limits", [[float(x[0]), float(x[-1])]] * 2)[1]
    active = (x >= float(fitted_limits[0])) & (x <= float(fitted_limits[1]))
    standardized = np.where(active, standardized, -np.inf)
    # Smooth over approximately one narrow laboratory peak core and list
    # separated positive residual maxima. This is diagnostic only.
    grid = np.arange(-6, 7, dtype=float)
    kernel = np.exp(-0.5 * (grid / 2.0) ** 2)
    kernel /= kernel.sum()
    # Replace excluded edge bins with zero during convolution, then exclude
    # their neighborhood from the ranked result below.
    smooth = np.convolve(np.where(active, standardized, 0.0), kernel, mode="same")
    local = np.where((smooth[1:-1] > smooth[:-2]) & (smooth[1:-1] >= smooth[2:]))[0] + 1
    ranked = sorted(local, key=lambda index: smooth[index], reverse=True)
    selected = []
    for index in ranked:
        if not active[index]:
            continue
        if any(abs(float(x[index] - item["two_theta_deg"])) < 0.12 for item in selected):
            continue
        selected.append({
            "two_theta_deg": float(x[index]),
            "smoothed_standardized_residual": float(smooth[index]),
            "observed": float(observed[index]),
            "calculated": float(calculated[index]),
        })
        if len(selected) >= count:
            break
    return selected


def main() -> None:
    if len(sys.argv) not in (2, 3):
        raise SystemExit("usage: audit_project.py PROJECT.gpx [OUTPUT.json]")
    source = Path(sys.argv[1]).resolve()
    before = hashlib.sha256(source.read_bytes()).hexdigest()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source))
    hist = project.histogram(0)
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    sigmas = list(covariance.get("sig", []))
    variables = {
        str(name): {"value": float(value), "esd": float(sigma)}
        for name, value, sigma in zip(names, covariance.get("variables", []), sigmas)
    }
    report = {
        "project": str(source),
        "histogram": hist.name,
        "Rwp_percent": float(hist.get_wR()),
        "Rvals": covariance.get("Rvals", {}),
        "frozen": list(project.get_Frozen()),
        "mass_fractions": {
            str(name): float(value[0])
            for name, value in hist.ComputeMassFracs().items()
        },
        "variables": variables,
        "largest_correlations": correlations(covariance),
        "phases": [
            {
                "name": phase.name,
                "atom_types": phase.data.get("General", {}).get("AtomTypes", []),
                "formula_mass": phase.data.get("General", {}).get("Mass"),
                "cell": phase.get_cell(),
                "geometry": geometry(phase),
            }
            for phase in project.phases()
        ],
        "residual_extrema": residual_extrema(hist),
    }
    rendered = json.dumps(report, indent=2, default=str) + "\n"
    if len(sys.argv) == 3:
        Path(sys.argv[2]).write_text(rendered)
    print(rendered, end="")
    del hist
    del project
    gc.collect()
    after = hashlib.sha256(source.read_bytes()).hexdigest()
    if after != before:
        raise RuntimeError("source GSAS-II project changed during read-only audit")


if __name__ == "__main__":
    main()
