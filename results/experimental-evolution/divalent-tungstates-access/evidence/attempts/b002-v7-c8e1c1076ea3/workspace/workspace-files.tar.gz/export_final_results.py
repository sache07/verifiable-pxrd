#!/usr/bin/env python3
"""Assemble submission artifacts from a read-only GSAS-II replay."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import sys

import numpy as np


PHASE_METADATA = {
    "ZnWO4_wolframite": {
        "name": "ZnWO4 (ordered inverse-wolframite)",
        "filename": "phase_1_ZnWO4_inverse_wolframite.cif",
        "space_group": "P 1 2/c 1",
    },
    "WO3_p21c_c": {
        "name": "WO3 (monoclinic)",
        "filename": "phase_2_WO3_monoclinic.cif",
        "space_group": "P 1 21/c 1",
    },
    "ZnO_wurtzite": {
        "name": "ZnO (wurtzite)",
        "filename": "phase_3_ZnO_wurtzite.cif",
        "space_group": "P 63 m c",
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit(
            "usage: export_final_results.py REPLAY_DIR PROJECT_AUDIT.json OUTPUT_DIR"
        )
    replay_dir = Path(sys.argv[1]).resolve()
    audit_path = Path(sys.argv[2]).resolve()
    output = Path(sys.argv[3]).resolve()
    output.mkdir(parents=True, exist_ok=True)

    replay_report = json.loads((replay_dir / "replay.json").read_text())
    audit = json.loads(audit_path.read_text())
    if replay_report.get("status") != "replayed":
        raise RuntimeError("GSAS-II project replay did not succeed")
    if replay_report.get("profile_review_flags"):
        raise RuntimeError(
            "GSAS-II replay has profile review flags: "
            + repr(replay_report["profile_review_flags"])
        )
    if replay_report.get("histogram") != audit.get("histogram"):
        raise RuntimeError("replay and final-project audit selected different histograms")

    prediction = np.load(replay_dir / "prediction.npz")
    x = np.asarray(prediction["x"], dtype=float)
    observed = np.asarray(prediction["observed"], dtype=float)
    calculated = np.asarray(prediction["predicted"], dtype=float)
    background = np.asarray(prediction["background"], dtype=float)
    if not all(len(item) == len(x) for item in (observed, calculated, background)):
        raise RuntimeError("inconsistent replay profile lengths")
    if not np.isfinite(calculated).all() or np.any(calculated < 0):
        raise RuntimeError("replayed calculated profile is nonphysical")
    difference = observed - calculated
    np.savetxt(
        output / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )

    replay_phases = replay_report.get("phases", [])
    if len(replay_phases) != len(PHASE_METADATA):
        raise RuntimeError("unexpected phase count in replay")
    total = sum(float(item["weight_fraction"]) for item in replay_phases)
    if total <= 0:
        raise RuntimeError("replay has no positive crystalline mass")
    phase_rows = []
    for item in replay_phases:
        project_name = str(item["name"])
        if project_name not in PHASE_METADATA:
            raise RuntimeError(f"unrecognized phase name: {project_name}")
        metadata = PHASE_METADATA[project_name]
        source_cif = replay_dir / str(item["cif"])
        destination = output / metadata["filename"]
        shutil.copy2(source_cif, destination)
        phase_rows.append({
            "name": metadata["name"],
            "project_phase_name": project_name,
            "space_group": metadata["space_group"],
            "cif_path": metadata["filename"],
            "weight_fraction": float(item["weight_fraction"]) / total,
        })

    weights = 1.0 / np.maximum(observed, 1.0)
    replay_rwp = 100.0 * np.sqrt(
        np.sum(weights * difference**2) / np.sum(weights * observed**2)
    )
    replay_rp = 100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))
    rvals = audit.get("Rvals", {})
    result = {
        "refinement_histogram": replay_report["histogram"],
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": float(audit["Rwp_percent"]),
            "replayed_full_grid_Rwp_percent": float(replay_rwp),
            "replayed_full_grid_Rp_percent": float(replay_rp),
            "chi_squared": float(rvals["chisq"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "observations_in_refinement": int(rvals["Nobs"]),
            "refined_variables": int(rvals["Nvars"]),
        },
        "fraction_basis": "normalized over the modeled crystalline phases",
        "difference_convention": "observed - calculated",
    }
    (output / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    manifest = {
        "project_sha256_at_replay": replay_report["project_sha256"],
        "histogram": replay_report["histogram"],
        "phase_count": len(phase_rows),
        "fit_bins": len(x),
        "minimum_calculated_count": float(np.min(calculated)),
        "minimum_background_count": float(np.min(background)),
        "replay_project_unchanged": bool(replay_report.get("project_unchanged")),
        "cif_sha256": {
            row["cif_path"]: sha256(output / row["cif_path"])
            for row in phase_rows
        },
    }
    (output / ".tmp" / "final_export_manifest.json").parent.mkdir(
        parents=True, exist_ok=True
    )
    (output / ".tmp" / "final_export_manifest.json").write_text(
        json.dumps(manifest, indent=2) + "\n"
    )
    print(json.dumps({"result": result, "manifest": manifest}, indent=2))


if __name__ == "__main__":
    main()
