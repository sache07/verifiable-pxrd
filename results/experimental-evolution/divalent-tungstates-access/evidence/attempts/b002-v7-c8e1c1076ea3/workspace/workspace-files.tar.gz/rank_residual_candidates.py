#!/usr/bin/env python3
"""Rank reaction-compatible frozen-library structures against a GSAS residual."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
import sys

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/index.json.gz"
)
CIFS = INDEX.parent / "cif"


def cif_path(cod_id: str) -> Path:
    return CIFS / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def profile(x: np.ndarray, peaks: np.ndarray, intensities: np.ndarray, fwhm: float, shift: float) -> np.ndarray:
    sigma = fwhm / 2.354820045
    out = np.zeros_like(x)
    for center, intensity in zip(peaks + shift, intensities):
        lo = np.searchsorted(x, center - 4.5 * sigma)
        hi = np.searchsorted(x, center + 4.5 * sigma)
        if hi > lo:
            out[lo:hi] += intensity * np.exp(-0.5 * ((x[lo:hi] - center) / sigma) ** 2)
    return out


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: rank_residual_candidates.py PROFILE.csv OUTPUT.json")
    table = np.loadtxt(sys.argv[1], delimiter=",", skiprows=1)
    x, observed, calculated, residual = table[:, :4].T
    weight = 1.0 / np.maximum(observed, 1.0)
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    records = []
    calculator = XRDCalculator(wavelength=1.540598)
    for system in ("O-W", "O-Zn"):
        for formula, cod_id, space_group, r_factor in index.get(system, []):
            record = {
                "system": system,
                "formula": formula,
                "cod_id": str(cod_id),
                "space_group_number": int(space_group),
                "reported_R": r_factor,
            }
            try:
                structure = Structure.from_file(cif_path(str(cod_id)), primitive=False)
                pattern = calculator.get_pattern(structure, two_theta_range=(float(x[0]), float(x[-1])))
                peaks = np.asarray(pattern.x, dtype=float)
                intensities = np.asarray(pattern.y, dtype=float)
                best = None
                for fwhm in (0.10, 0.16, 0.24, 0.36):
                    for shift in np.linspace(-0.30, 0.30, 61):
                        trial = profile(x, peaks, intensities, fwhm, float(shift))
                        denominator = float(np.sum(weight * trial * trial))
                        if denominator <= 0:
                            continue
                        amplitude = max(0.0, float(np.sum(weight * residual * trial)) / denominator)
                        improvement = float(
                            np.sum(weight * residual * residual)
                            - np.sum(weight * (residual - amplitude * trial) ** 2)
                        )
                        candidate = (improvement, amplitude, fwhm, float(shift))
                        if best is None or candidate[0] > best[0]:
                            best = candidate
                if best is None:
                    raise ValueError("empty simulated profile")
                improvement, amplitude, fwhm, shift = best
                record.update(
                    weighted_SSE_improvement=improvement,
                    amplitude=amplitude,
                    trial_fwhm_deg=fwhm,
                    trial_shift_deg=shift,
                    strongest_peaks_deg=[float(v) for v in peaks[np.argsort(intensities)[::-1][:12]]],
                )
            except Exception as exc:
                record["error"] = str(exc)
            records.append(record)
    records.sort(key=lambda item: item.get("weighted_SSE_improvement", -1.0), reverse=True)
    Path(sys.argv[2]).write_text(json.dumps(records, indent=2) + "\n")
    for item in records:
        if "error" not in item:
            print(json.dumps(item), flush=True)


if __name__ == "__main__":
    main()
