#!/usr/bin/env python3
"""Compare equally developed bounded ZnWO4 coordinate starts in the closed model."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


WINDOW_A = 0.10
STARTS = {
    "accepted_comoo4": None,
    # Preserve the physical geometry reached at the first CoMoO4 oxygen
    # adaptation bound. It becomes a new independent center, rather than a
    # bound-hit endpoint, for this equally developed comparison.
    "shifted_oxygen": {
        "O2": [0.2274703289, 0.0929832385, 0.5443300539],
        "O3": [0.2745807094, 0.3844439739, 0.0843621843],
    },
    "continued_shared_basin": {
        "Zn0": [0.5, 0.3183139135, 0.75],
        "W1": [0.0, 0.1873299779, 0.25],
        "O2": [0.2324282901, 0.1100383641, 0.5532201205],
        "O3": [0.2534853020, 0.3776978938, 0.0640921305],
    },
}


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        for key in ("Size", "Mustrain"):
            if isinstance(hap.get(key), list) and len(hap[key]) > 2:
                hap[key][2] = [False] * len(hap[key][2])
            if isinstance(hap.get(key), list) and len(hap[key]) > 5:
                hap[key][5] = [False] * len(hap[key][5])
        hap["Pref.Ori."][2] = False


def enable_base(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def snapshot(project: G2.G2Project, branch: str, stage: str) -> dict:
    hist = project.histogram(0)
    phase = project.phases()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    contacts = phase.ShortDistances(useAll=False)
    return {
        "branch": branch,
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "coordinates": {
            atom.label: [float(v) for v in atom.coordinates] for atom in phase.atoms()
        },
        "cells": {item.name: item.get_cell() for item in project.phases()},
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "short_contacts": [list(item) for item in contacts],
    }


def run(project: G2.G2Project, branch: str, stage: str, cycles: int) -> dict:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    item = snapshot(project, branch, stage)
    print(json.dumps(item), flush=True)
    return item


def main() -> None:
    if len(sys.argv) not in (3, 4):
        raise SystemExit(
            "usage: screen_main_coordinate_starts.py INPUT.gpx OUTPUT_DIR [BRANCH]"
        )
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    all_records = []

    requested = sys.argv[3] if len(sys.argv) == 4 else None
    starts = STARTS if requested is None else {requested: STARTS[requested]}
    for branch, replacements in starts.items():
        output = outdir / f"{branch}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        project.index_ids()
        controls = project.data["Controls"]["data"]
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        controls["parmFrozen"] = {"FrozenList": []}
        hist = project.histogram(0)
        phase = project.phases()[0]

        if replacements:
            for atom in phase.atoms():
                if atom.label in replacements:
                    atom.coordinates = replacements[atom.label]

        lengths = [
            phase.get_cell()["length_a"],
            phase.get_cell()["length_b"],
            phase.get_cell()["length_c"],
        ]
        pid = int(phase.data["pId"])
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                span = WINDOW_A / float(length)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - span, variable=variable)
                project.set_Controls("parmMax", float(value) + span, variable=variable)

        clear_flags(project)
        enable_base(project)
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element.strip().upper() != "O" else " "
        all_records.append(run(project, branch, "heavy", 10))

        clear_flags(project)
        enable_base(project)
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element.strip().upper() == "O" else " "
        all_records.append(run(project, branch, "oxygen", 14))

        clear_flags(project)
        enable_base(project)
        for atom in phase.atoms():
            atom.refinement_flags = "X"
        all_records.append(run(project, branch, "joint", 12))

        clear_flags(project)
        enable_base(project)
        for item in project.phases():
            item.set_refinements({"Cell": True})
        all_records.append(run(project, branch, "cell_scale_background", 10))

        clear_flags(project)
        project.save()

    (outdir / "screen.json").write_text(json.dumps(all_records, indent=2) + "\n")


if __name__ == "__main__":
    main()
