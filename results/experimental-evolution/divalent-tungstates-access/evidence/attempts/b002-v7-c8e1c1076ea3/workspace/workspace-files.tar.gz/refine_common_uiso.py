#!/usr/bin/env python3
"""Normalize and refine one common isotropic displacement value per phase."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def clear_nuisance_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_common_uiso.py INPUT.gpx OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.data["Constraints"]["data"]["Phase"] = []
    project.index_ids()
    hist = project.histogram(0)
    clear_nuisance_flags(project)
    hist.Background[0][1] = True

    for phase in project.phases():
        pid = int(phase.data["pId"])
        atoms = phase.atoms()
        for index, atom in enumerate(atoms):
            # Frozen source registration uses scalar Uiso=0.005 A^2.
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.005
            atom.refinement_flags = "U"
            variable = f"{pid}::AUiso:{index}"
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(atoms) > 1:
            project.add_EquivConstr(
                tuple(f"{pid}::AUiso:{index}" for index in range(len(atoms))),
                reloadIdx=False,
            )
        phase.data["Histograms"][hist.name]["Scale"][1] = True

    records = []
    for pass_index in range(3):
        controls["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "uiso_A2": {
                phase.name: [float(atom.uiso) for atom in phase.atoms()]
                for phase in project.phases()
            },
            "converged": rvals.get("converged"),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
        }
        records.append(record)
        print(json.dumps(record), flush=True)
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    clear_nuisance_flags(project)
    project.save()
    output.with_suffix(".uiso.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
