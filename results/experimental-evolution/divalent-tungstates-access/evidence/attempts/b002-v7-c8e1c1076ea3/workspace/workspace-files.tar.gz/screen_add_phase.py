#!/usr/bin/env python3
"""Test one ordinary candidate phase against an accepted main-phase checkpoint."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"].get(hist.name)
        if not hap:
            continue
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def enable_base(project: G2.G2Project) -> None:
    clear_flags(project)
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    try:
        return {name: float(value[0]) for name, value in hist.ComputeMassFracs().items()}
    except Exception:
        weighted = {}
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            weighted[phase.name] = max(0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
        total = sum(weighted.values())
        return {name: value / total for name, value in weighted.items()}


def run(project: G2.G2Project, label: str, cycles: int = 10) -> dict:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    candidate = project.phases()[-1]
    hap = candidate.data["Histograms"][hist.name]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project),
        "candidate_cell": candidate.get_cell(),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_size_um": float(hap["Size"][1][0]),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
    }
    print(json.dumps(record), flush=True)
    return record


def main() -> None:
    if len(sys.argv) != 5:
        raise SystemExit("usage: screen_add_phase.py INPUT.gpx CANDIDATE.cif NAME OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    candidate_cif = Path(sys.argv[2]).resolve()
    name = sys.argv[3]
    output = Path(sys.argv[4]).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(candidate_cif), phasename=name, histograms=[hist], fmthint="CIF"
    )
    project.index_ids()
    main_phase = project.phases()[0]
    main_hap = main_phase.data["Histograms"][hist.name]
    hap = candidate.data["Histograms"][hist.name]
    main_mass = float(main_phase.data["General"]["Mass"])
    cand_mass = float(candidate.data["General"]["Mass"])
    initial_fraction = 0.02
    hap["Scale"][0] = (
        float(main_hap["Scale"][0]) * main_mass / cand_mass
        * initial_fraction / (1.0 - initial_fraction)
    )
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

    pid = int(candidate.data["pId"])
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    project.set_Controls("parmMax", max(hap["Scale"][0] * 100.0, 10.0), variable=f"{pid}:0:Scale")
    project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
    cell = candidate.get_cell()
    reciprocal = G2lat.cell2A([
        cell["length_a"], cell["length_b"], cell["length_c"],
        cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
    ])
    for index, value in enumerate(reciprocal):
        span = max(0.01 * abs(float(value)), 0.0003)
        project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")

    records = []
    enable_base(project)
    records.append(run(project, "scale_only", 10))
    candidate.set_refinements({"Cell": True})
    hap["Size"][2][0] = True
    records.append(run(project, "cell_size", 12))
    records.append(run(project, "cell_size_settle", 12))
    clear_flags(project)
    project.save()
    output.with_suffix(".phase_screen.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
