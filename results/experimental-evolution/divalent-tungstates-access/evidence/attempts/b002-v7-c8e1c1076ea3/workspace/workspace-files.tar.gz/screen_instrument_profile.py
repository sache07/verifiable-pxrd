#!/usr/bin/env python3
"""Audit U/X against W, phase size and accepted WO3 microstrain."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


BRANCHES = {
    "baseline": (),
    "U": ("U",),
    "X": ("X",),
    "U_X": ("U", "X"),
}


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def largest_correlations(project: G2.G2Project, names: list[str]) -> dict:
    covariance = project.data.get("Covariance", {}).get("data", {})
    vary = covariance.get("varyList", [])
    matrix = np.asarray(covariance.get("covMatrix", []), dtype=float)
    if matrix.size == 0:
        return {}
    sigma = np.sqrt(np.diag(matrix))
    correlation = matrix / np.outer(sigma, sigma)
    result = {}
    for name in names:
        if name not in vary:
            continue
        index = vary.index(name)
        choices = sorted(
            (
                (abs(float(correlation[index, other])), float(correlation[index, other]), vary[other])
                for other in range(len(vary)) if other != index
            ),
            reverse=True,
        )[:5]
        result[name] = [
            {"parameter": item, "correlation": signed} for _, signed, item in choices
        ]
    return result


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: screen_instrument_profile.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    records = []
    for branch, extras in BRANCHES.items():
        output = outdir / f"{branch}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        project.index_ids()
        controls = project.data["Controls"]["data"]
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        controls["parmFrozen"] = {"FrozenList": []}
        hist = project.histogram(0)
        clear_flags(project)
        hist.Background[0][1] = True
        hist.InstrumentParameters["W"][2] = True
        project.set_Controls("parmMin", 2.0, variable=":0:W")
        project.set_Controls("parmMax", 40.0, variable=":0:W")
        for phase_index, phase in enumerate(project.phases()):
            hap = phase.data["Histograms"][hist.name]
            hap["Scale"][1] = True
            hap["Size"][2][0] = True
            project.set_Controls("parmMin", 0.04, variable=f"{phase_index}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{phase_index}:0:Size;i")
        wo3 = project.phases()[1].data["Histograms"][hist.name]
        wo3["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 300.0, variable="1:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable="1:0:Mustrain;i")
        if "U" in extras:
            hist.InstrumentParameters["U"][1] = 5.0
            hist.InstrumentParameters["U"][2] = True
            project.set_Controls("parmMin", 0.0, variable=":0:U")
            project.set_Controls("parmMax", 40.0, variable=":0:U")
        if "X" in extras:
            hist.InstrumentParameters["X"][1] = 1.0
            hist.InstrumentParameters["X"][2] = True
            project.set_Controls("parmMin", 0.1, variable=":0:X")
            project.set_Controls("parmMax", 6.0, variable=":0:X")
        for _ in range(3):
            controls["parmFrozen"] = {"FrozenList": []}
            project.set_Controls("cycles", 12)
            project.save()
            project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        watched = [":0:U", ":0:X", ":0:W", "0:0:Size;i", "1:0:Size;i", "1:0:Mustrain;i"]
        record = {
            "branch": branch,
            "Rwp_percent": float(hist.get_wR()),
            "U": float(hist.InstrumentParameters["U"][1]),
            "W": float(hist.InstrumentParameters["W"][1]),
            "X": float(hist.InstrumentParameters["X"][1]),
            "sizes_um": [
                float(phase.data["Histograms"][hist.name]["Size"][1][0])
                for phase in project.phases()
            ],
            "WO3_microstrain_ppm": float(wo3["Mustrain"][1][0]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "largest_correlations": largest_correlations(project, watched),
            "output": str(output),
        }
        records.append(record)
        print(json.dumps(record), flush=True)
    (outdir / "screen.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
