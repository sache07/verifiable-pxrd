#!/usr/bin/env python3
"""Compare no, isotropic and permitted uniaxial microstrain branches."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


BRANCHES = [
    ("none", None, None),
    ("isotropic", "isotropic", None),
    ("uniaxial_001", "uniaxial", [0, 0, 1]),
    ("uniaxial_100", "uniaxial", [1, 0, 0]),
    ("uniaxial_010", "uniaxial", [0, 1, 0]),
]


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def main() -> None:
    if len(sys.argv) not in (3, 4):
        raise SystemExit(
            "usage: screen_microstrain.py INPUT.gpx OUTPUT_DIR [PHASE_INDEX]"
        )
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    summaries = []
    for name, mode, axis in BRANCHES:
        output = outdir / f"{name}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        controls = project.data["Controls"]["data"]
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        controls["parmFrozen"] = {"FrozenList": []}
        project.index_ids()
        hist = project.histogram(0)
        phase_index = int(sys.argv[3]) if len(sys.argv) == 4 else 0
        phase = project.phases()[phase_index]
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        clear_flags(project)
        hist.Background[0][1] = True
        for item in project.phases():
            item.data["Histograms"][hist.name]["Scale"][1] = True
        if mode is not None:
            hap["Mustrain"][0] = mode
            hap["Mustrain"][1][0] = 1000.0
            if mode == "isotropic":
                hap["Mustrain"][2][0] = True
                variables = [f"{phase_index}:0:Mustrain;i"]
            else:
                hap["Mustrain"][1][1] = 1000.0
                hap["Mustrain"][2][0] = True
                hap["Mustrain"][2][1] = True
                hap["Mustrain"][3] = axis
                variables = [
                    f"{phase_index}:0:Mustrain;i",
                    f"{phase_index}:0:Mustrain;a",
                ]
            for variable in variables:
                project.set_Controls("parmMin", 300.0, variable=variable)
                project.set_Controls("parmMax", 8000.0, variable=variable)
        for _ in range(2):
            controls["parmFrozen"] = {"FrozenList": []}
            project.set_Controls("cycles", 12)
            project.save()
            project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        record = {
            "branch": name,
            "Rwp_percent": float(hist.get_wR()),
            "mustrain_type": hap["Mustrain"][0],
            "mustrain_values": list(map(float, hap["Mustrain"][1][:2])),
            "axis": hap["Mustrain"][3],
            "converged": rvals.get("converged"),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "output": str(output),
        }
        summaries.append(record)
        print(json.dumps(record), flush=True)
    (outdir / "screen.json").write_text(json.dumps(summaries, indent=2) + "\n")


if __name__ == "__main__":
    main()
