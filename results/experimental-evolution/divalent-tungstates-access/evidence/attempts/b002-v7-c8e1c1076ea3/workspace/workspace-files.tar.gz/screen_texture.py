#!/usr/bin/env python3
"""Screen permitted March-Dollase axes at equally developed checkpoints."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


AXES = [None, [0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit("usage: screen_texture.py INPUT.gpx OUTPUT_DIR LABEL")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    label = sys.argv[3]
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    summaries = []

    for axis in AXES:
        tag = "none" if axis is None else "".join(str(v) for v in axis)
        output = outdir / f"{label}_md_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        controls = project.data["Controls"]["data"]
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        controls["parmFrozen"] = {"FrozenList": []}
        project.index_ids()
        hist = project.histogram(0)
        phase = project.phase(0)
        hap = phase.data["Histograms"][hist.name]

        # Identical metric/profile/calibration adaptation for each basin and axis.
        cell = [4.7000, 5.7335, 4.9315, 90.0, 90.61, 90.0]
        phase.data["General"]["Cell"][1:7] = cell
        phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))
        hist.InstrumentParameters["Zero"][1] = 0.0
        hist.InstrumentParameters["Zero"][2] = False
        hist.InstrumentParameters["U"][1] = 10.0
        hist.InstrumentParameters["W"][1] = 10.0
        hist.SampleParameters["Scale"] = [1.0, False]
        hist.SampleParameters["Shift"] = [-600.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.060
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        if axis is not None:
            hap["Pref.Ori."][3] = axis

        bounds = {
            ":0:Shift": (-800.0, 800.0),
            ":0:U": (0.0, 40.0),
            ":0:W": (2.0, 40.0),
            "0:0:Scale": (0.0, 1000.0),
            "0:0:Size;i": (0.04, 1.5),
            "0:0:MD": (0.7, 1.4),
        }
        for variable, (low, high) in bounds.items():
            project.set_Controls("parmMin", low, variable=variable)
            project.set_Controls("parmMax", high, variable=variable)

        clear_flags(project)
        hist.Background[0][1] = True
        hist.SampleParameters["Shift"][1] = True
        hist.InstrumentParameters["U"][2] = True
        hist.InstrumentParameters["W"][2] = True
        phase.set_refinements({"Cell": True})
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        if axis is not None:
            hap["Pref.Ori."][2] = True

        for _ in range(2):
            controls["parmFrozen"] = {"FrozenList": []}
            project.set_Controls("cycles", 12)
            project.save()
            project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {})
        summary = {
            "label": label,
            "axis": axis,
            "Rwp_percent": float(hist.get_wR()),
            "MD_ratio": float(hap["Pref.Ori."][1]),
            "cell": phase.get_cell(),
            "shift_um": float(hist.SampleParameters["Shift"][0]),
            "U": float(hist.InstrumentParameters["U"][1]),
            "W": float(hist.InstrumentParameters["W"][1]),
            "size_um": float(hap["Size"][1][0]),
            "converged": cov.get("Rvals", {}).get("converged"),
            "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "project": str(output),
        }
        summaries.append(summary)
        print(json.dumps(summary), flush=True)

    (outdir / f"{label}_texture_screen.json").write_text(json.dumps(summaries, indent=2) + "\n")


if __name__ == "__main__":
    main()
