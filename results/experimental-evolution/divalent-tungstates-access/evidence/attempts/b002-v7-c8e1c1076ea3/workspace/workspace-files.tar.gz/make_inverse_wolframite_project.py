#!/usr/bin/env python3
"""Create the ordered cation-inverse ZnWO4 basin for an equal comparison."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: make_inverse_wolframite_project.py INPUT.gpx OUTPUT.gpx")
    project = G2.G2Project(
        gpxfile=str(Path(sys.argv[1]).resolve()),
        newgpx=str(Path(sys.argv[2]).resolve()),
    )
    phase = project.phases()[0]
    atoms = phase.atoms()
    if [atom.element for atom in atoms[:2]] != ["Zn", "W"]:
        raise ValueError("unexpected main-phase cation ordering")
    atoms[0].type = "W"
    atoms[0].label = "W0"
    atoms[1].type = "Zn"
    atoms[1].label = "Zn1"
    G2.SetupGeneral(phase.data, None)
    project.index_ids()
    project.update_ids()
    project.save()


if __name__ == "__main__":
    main()
