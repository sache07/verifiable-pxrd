#!/usr/bin/env python3
"""Build equal-cell ordered inverse-wolframite starts from adapted parents."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


COORDINATES = {
    "comoo4": [[0.5, 0.32662, 0.75], [0.0, 0.185, 0.25],
               [0.2179, 0.1072, 0.5646], [0.2551, 0.3772, 0.1021]],
    "fenbo4": [[0.5, 0.3313, 0.75], [0.0, 0.1824, 0.25],
               [0.233, 0.116, 0.581], [0.262, 0.384, 0.082]],
    "innbo4": [[0.5, 0.3175, 0.75], [0.0, 0.1779, 0.25],
               [0.217, 0.102, 0.562], [0.26, 0.382, 0.099]],
    "intao4": [[0.5, 0.32155, 0.75], [0.0, 0.17397, 0.25],
               [0.21518, 0.10299, 0.56319], [0.26023, 0.38092, 0.09863]],
    "mnreo4": [[0.5, 0.3189, 0.75], [0.0, 0.16966, 0.25],
               [0.2078, 0.1056, 0.5625], [0.2595, 0.3712, 0.1119]],
}


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit(
            "usage: make_inverse_parent_start.py INPUT.gpx PARENT OUTPUT.gpx"
        )
    source, parent, output = Path(sys.argv[1]), sys.argv[2], Path(sys.argv[3])
    output.resolve().parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source.resolve()), newgpx=str(output.resolve()))
    phase = project.phases()[0]
    atoms = phase.atoms()
    if len(atoms) != 4 or parent not in COORDINATES:
        raise ValueError("unexpected wolframite start")
    for atom, coordinates in zip(atoms, COORDINATES[parent]):
        atom.coordinates = coordinates
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.005
        atom.refinement_flags = " "
    atoms[0].type, atoms[0].label = "W", "W0"
    atoms[1].type, atoms[1].label = "Zn", "Zn1"
    G2.SetupGeneral(phase.data, None)
    project.index_ids()
    project.update_ids()
    project.save()


if __name__ == "__main__":
    main()
