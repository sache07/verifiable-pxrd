#!/usr/bin/env python3
"""Export a GSAS-II profile and compact parameter summary for diagnostics."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: gpx_profile.py INPUT.gpx OUTPUT_STEM")
    project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()))
    stem = Path(sys.argv[2]).resolve()
    hist = project.histogram(0)
    x, yobs, weight, ycalc, ybkg, diff = [np.asarray(v, dtype=float) for v in hist.data["data"][1][:6]]
    np.savetxt(
        stem.with_suffix(".csv"),
        np.column_stack((x, yobs, ycalc, diff, ybkg, weight)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background,weight",
        comments="",
    )
    info = {
        "Rwp_percent": float(hist.get_wR()),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "hap": phase.data["Histograms"].get(hist.name),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "uiso": atom.uiso,
                    }
                    for atom in phase.atoms()
                ],
            }
            for phase in project.phases()
        ],
        "covariance": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    stem.with_suffix(".json").write_text(json.dumps(info, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
