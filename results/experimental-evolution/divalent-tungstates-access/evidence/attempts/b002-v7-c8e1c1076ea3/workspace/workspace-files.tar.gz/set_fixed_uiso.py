#!/usr/bin/env python3
"""Apply physically supported fixed isotropic displacement values and settle scales."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


VALUES = [0.005, 0.0038535, 0.005]


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: set_fixed_uiso.py INPUT.gpx OUTPUT.gpx")
    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(Path(sys.argv[1]).resolve()), newgpx=str(Path(sys.argv[2]).resolve())
    )
    project.data["Constraints"]["data"]["Phase"] = []
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase, uiso in zip(project.phases(), VALUES):
        phase.clear_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(uiso)
            atom.refinement_flags = " "
    records = []
    for pass_index in range(2):
        controls["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        record = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "converged": rvals.get("converged"),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
        }
        records.append(record)
        print(json.dumps(record), flush=True)
    hist.Background[0][1] = False
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = False
    project.save()
    Path(sys.argv[2]).with_suffix(".fixed_uiso.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
