#!/usr/bin/env python3
"""Screen bounded instrument/specimen terms after phase closure."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


BRANCHES = {
    "baseline": (),
    "polarization": ("polarization",),
    "shl": ("shl",),
    "polarization_shl": ("polarization", "shl"),
    "roughness": ("roughness",),
    "all": ("polarization", "shl", "roughness"),
}


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: screen_specimen_terms.py INPUT.gpx OUTPUT_DIR")
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    records = []
    for name, terms in BRANCHES.items():
        output = outdir / f"{name}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        controls = project.data["Controls"]["data"]
        controls["parmMinDict"] = {}
        controls["parmMaxDict"] = {}
        controls["parmFrozen"] = {"FrozenList": []}
        project.index_ids()
        hist = project.histogram(0)
        clear_flags(project)
        hist.Background[0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
        hist.InstrumentParameters["Polariz."][1] = 0.8
        hist.InstrumentParameters["SH/L"][1] = 0.02
        # Zero is the physical "off" state. Merely clearing the refine flag
        # leaves nonzero roughness values active in the calculated pattern.
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
        if "polarization" in terms:
            hist.InstrumentParameters["Polariz."][2] = True
            project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
            project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        if "shl" in terms:
            hist.InstrumentParameters["SH/L"][2] = True
            project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
            project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
        if "roughness" in terms:
            hist.SampleParameters["SurfRoughA"][0] = 0.20
            hist.SampleParameters["SurfRoughB"][0] = 0.10
            hist.SampleParameters["SurfRoughA"][1] = True
            hist.SampleParameters["SurfRoughB"][1] = True
            project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
            project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
            project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
            project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
        for _ in range(2):
            controls["parmFrozen"] = {"FrozenList": []}
            project.set_Controls("cycles", 12)
            project.save()
            project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        record = {
            "branch": name,
            "Rwp_percent": float(hist.get_wR()),
            "polarization": float(hist.InstrumentParameters["Polariz."][1]),
            "SH_L": float(hist.InstrumentParameters["SH/L"][1]),
            "roughness_A": float(hist.SampleParameters["SurfRoughA"][0]),
            "roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
            "converged": rvals.get("converged"),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "output": str(output),
        }
        records.append(record)
        print(json.dumps(record), flush=True)
    (outdir / "screen.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
