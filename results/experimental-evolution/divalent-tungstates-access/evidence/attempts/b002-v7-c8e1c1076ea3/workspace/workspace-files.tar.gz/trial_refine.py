#!/usr/bin/env python3
"""Build and equally develop a one-phase GSAS-II trial refinement."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    record = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "cell": project.phase(0).get_cell(),
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": hist.SampleParameters,
        "hap": project.phase(0).data["Histograms"][hist.name],
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "vary_list": cov.get("varyList", []),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(record, default=str), flush=True)
    return record


def run(project: G2.G2Project, label: str, cycles: int = 8) -> dict:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    return state(project, label)


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: trial_refine.py START.cif OUTPUT.gpx")
    cif = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    work = cif.parent
    G2.SetPrintLevel("error")

    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(work / "pattern.xye"),
        str(work / "instrument.instprm"),
        fmthint="xye",
    )
    phase = project.add_phase(str(cif), phasename="ZnWO4_wolframite", histograms=[hist], fmthint="CIF")
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1000.0] + [0.0] * 11,
            "refine": True,
        }
    })
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    project.save()
    project.index_ids()

    # Physical bounds for the supplied laboratory and specimen ranges.
    bounds = {
        "0:0:Scale": (0.0, 1000.0),
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        "0:0:Size;i": (0.04, 1.5),
        "0:0:Mustrain;i": (300.0, 8000.0),
    }
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    records = []
    records.append(run(project, "scale_background", 8))

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    records.append(run(project, "cell_shift", 10))

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    records.append(run(project, "cell_shift_zero", 10))

    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.3, "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    records.append(run(project, "isotropic_sample_profile", 10))

    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    records.append(run(project, "instrument_UW", 10))

    output.with_suffix(".trial.json").write_text(json.dumps(records, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
