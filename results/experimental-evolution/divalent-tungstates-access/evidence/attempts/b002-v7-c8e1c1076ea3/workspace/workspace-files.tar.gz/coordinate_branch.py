#!/usr/bin/env python3
"""Apply the same bounded coordinate development to a GSAS-II trial basin."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


COORD_WINDOW_A = 0.10


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phase = project.phase(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    out = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "cell": phase.get_cell(),
        "coordinates": {
            atom.label: [float(v) for v in atom.coordinates] for atom in phase.atoms()
        },
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
    }
    print(json.dumps(out), flush=True)
    return out


def run(project: G2.G2Project, label: str, cycles: int) -> dict:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    return state(project, label)


def enable_base(project: G2.G2Project, with_cell: bool) -> None:
    clear_flags(project)
    hist = project.histogram(0)
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        if with_cell:
            phase.set_refinements({"Cell": True})


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: coordinate_branch.py INPUT.gpx OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.data["Controls"]["data"]["parmMinDict"] = {}
    project.data["Controls"]["data"]["parmMaxDict"] = {}
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hist = project.histogram(0)
    phase = project.phase(0)

    # Roll back terms that were pinned in the exploratory model.
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"][0] = -585.0
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.set_Controls("parmMin", 0.0, variable="0:0:Scale")
    project.set_Controls("parmMax", 1000.0, variable="0:0:Scale")
    cell = phase.get_cell()
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    for index, atom in enumerate(phase.atoms()):
        for axis, value, length in zip("xyz", atom.coordinates, lengths):
            span = COORD_WINDOW_A / float(length)
            project.set_Controls("parmMin", float(value) - span, variable=f"0::dA{axis}:{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"0::dA{axis}:{index}")

    records = []
    enable_base(project, with_cell=True)
    records.append(run(project, "physical_calibration_settle", 10))

    enable_base(project, with_cell=False)
    for atom in phase.atoms():
        if atom.element.strip().upper() != "O":
            atom.refinement_flags = "X"
    records.append(run(project, "heavy_coordinates", 8))

    enable_base(project, with_cell=False)
    for atom in phase.atoms():
        if atom.element.strip().upper() == "O":
            atom.refinement_flags = "X"
    records.append(run(project, "oxygen_coordinates", 10))

    enable_base(project, with_cell=False)
    for atom in phase.atoms():
        atom.refinement_flags = "X"
    records.append(run(project, "joint_coordinates", 10))

    enable_base(project, with_cell=True)
    records.append(run(project, "cell_scale_background_settle", 10))
    clear_flags(project)
    project.save()
    output.with_suffix(".coordinate.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
