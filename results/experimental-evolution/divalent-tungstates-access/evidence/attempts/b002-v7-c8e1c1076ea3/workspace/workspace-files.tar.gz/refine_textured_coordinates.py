#!/usr/bin/env python3
"""Refine supported coordinates in the accepted textured wolframite basin."""

from __future__ import annotations

import json
from pathlib import Path
import re
import sys

from GSASII import GSASIIscriptable as G2


WINDOW_A = 0.10
COORD_RE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def enable_scale_background(project: G2.G2Project) -> None:
    clear_flags(project)
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def run(project: G2.G2Project, label: str, cycles: int) -> dict:
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    phase = project.phase(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "coordinates": {a.label: list(map(float, a.coordinates)) for a in phase.atoms()},
        "cell": phase.get_cell(),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "MD_ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
    }
    print(json.dumps(record), flush=True)
    return record


def frozen_atoms(record: dict) -> set[int]:
    found = set()
    for variable in record["frozen"]:
        match = COORD_RE.match(str(variable))
        if match:
            found.add(int(match.group(2)))
    return found


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_textured_coordinates.py INPUT.gpx OUTPUT.gpx")
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]

    # Retain only interior terms from the equally developed texture screen.
    hist.InstrumentParameters["U"][1] = 0.0
    hist.InstrumentParameters["U"][2] = False
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["Zero"][2] = False
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][2] = False
    source_coordinates = {
        i: tuple(float(v) for v in atom.coordinates) for i, atom in enumerate(phase.atoms())
    }
    cell = phase.get_cell()
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    project.set_Controls("parmMin", 0.0, variable="0:0:Scale")
    project.set_Controls("parmMax", 1000.0, variable="0:0:Scale")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for index, atom in enumerate(phase.atoms()):
        for axis, value, length in zip("xyz", atom.coordinates, lengths):
            span = WINDOW_A / float(length)
            project.set_Controls("parmMin", float(value) - span, variable=f"0::dA{axis}:{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"0::dA{axis}:{index}")

    records = []
    excluded: set[int] = set()
    enable_scale_background(project)
    for index, atom in enumerate(phase.atoms()):
        if atom.element.strip().upper() != "O":
            atom.refinement_flags = "X"
    records.append(run(project, "heavy_coordinates", 10))
    excluded.update(frozen_atoms(records[-1]))

    enable_scale_background(project)
    for index, atom in enumerate(phase.atoms()):
        if atom.element.strip().upper() == "O" and index not in excluded:
            atom.refinement_flags = "X"
    records.append(run(project, "oxygen_coordinates", 12))
    excluded.update(frozen_atoms(records[-1]))

    # A bound-hit atom is unsupported: restore it to the physical checkpoint.
    for index in excluded:
        phase.atoms()[index].coordinates = source_coordinates[index]
    enable_scale_background(project)
    for index, atom in enumerate(phase.atoms()):
        if index not in excluded:
            atom.refinement_flags = "X"
    records.append(run(project, "interior_joint_coordinates", 12))
    excluded.update(frozen_atoms(records[-1]))
    for index in excluded:
        phase.atoms()[index].coordinates = source_coordinates[index]

    clear_flags(project)
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    phase.set_refinements({"Cell": True})
    hap["Scale"][1] = True
    records.append(run(project, "cell_scale_background_settle", 12))
    clear_flags(project)
    project.save()
    output.with_suffix(".textured_coordinates.json").write_text(
        json.dumps({"excluded_atoms": sorted(excluded), "stages": records}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
