#!/usr/bin/env python3
"""Combine accepted branches and settle the terminal physical PXRD model."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


TEXTURES = (
    ([1, 1, 1], 0.7047190),  # interior winner in the accepted inverse basin
    ([1, 1, 0], 1.3604971),  # interior winner from the final WO3 screen
    ([0, 0, 1], 0.8540241),  # physical wurtzite c-axis solution
)


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        for key in ("Size", "Mustrain"):
            if isinstance(hap.get(key), list) and len(hap[key]) > 2:
                hap[key][2] = [False] * len(hap[key][2])
            if isinstance(hap.get(key), list) and len(hap[key]) > 5:
                hap[key][5] = [False] * len(hap[key][5])
        hap["Pref.Ori."][2] = False


def enable_base(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    return {
        str(name): float(value[0])
        for name, value in project.histogram(0).ComputeMassFracs().items()
    }


def record(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": mass_fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "W": float(hist.InstrumentParameters["W"][1]),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "sizes_um": {},
        "textures": {},
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["sizes_um"][phase.name] = float(hap["Size"][1][0])
        result["textures"][phase.name] = {
            "axis": list(hap["Pref.Ori."][3]),
            "MD_ratio": float(hap["Pref.Ori."][1]),
        }
    return result


def run(project: G2.G2Project, stage: str, cycles: int = 12) -> dict:
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    result = record(project, stage)
    print(json.dumps(result), flush=True)
    return result


def main() -> None:
    if len(sys.argv) not in (3, 4):
        raise SystemExit(
            "usage: build_terminal_model.py INPUT.gpx OUTPUT.gpx [--wo3-strain]"
        )
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    with_wo3_strain = len(sys.argv) == 4 and sys.argv[3] == "--wo3-strain"
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)

    # Explicit fixed/off states for terms rejected during bounded screens.
    hist.InstrumentParameters["Zero"][1:] = [0.0, False]
    hist.InstrumentParameters["U"][1:] = [11.7137, False]
    hist.InstrumentParameters["X"][1:] = [1.0, False]
    hist.InstrumentParameters["SH/L"][1:] = [0.02, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    for phase_index, (phase, (axis, initial)) in enumerate(zip(project.phases(), TEXTURES)):
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][3] = axis
        if initial is not None:
            hap["Pref.Ori."][1] = initial
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 325.0 if with_wo3_strain and phase_index == 1 else 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

    # Laboratory and specimen bounds supplied with the case.
    for variable, low, high in (
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:Polariz.", 0.5, 1.0),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls(
            "parmMax", max(float(hap["Scale"][0]) * 20.0, 10.0),
            variable=f"{pid}:0:Scale",
        )
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        if with_wo3_strain and pid == 1:
            project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")

    records = []
    clear_flags(project)
    enable_base(project)
    records.append(run(project, "scale_background", 10))

    clear_flags(project)
    enable_base(project)
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    records.append(run(project, "cell_calibration", 12))

    clear_flags(project)
    enable_base(project)
    hist.InstrumentParameters["U"][2] = True
    hist.InstrumentParameters["W"][2] = True
    for phase_index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        if with_wo3_strain and phase_index == 1:
            hap["Mustrain"][2][0] = True
    records.append(run(project, "profile", 12))

    clear_flags(project)
    enable_base(project)
    hist.InstrumentParameters["Polariz."][2] = True
    # The dominant-phase MD ratio was already supported at 0.70472 in its
    # isolated family screen, but re-refining it jointly reaches 0.700. Keep
    # that interior checkpoint fixed and refine only the two secondary terms.
    for phase in project.phases()[1:]:
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    records.append(run(project, "specimen", 12))

    # Joint replay stability with only terms supported above enabled.
    for pass_index in range(4):
        clear_flags(project)
        enable_base(project)
        hist.SampleParameters["Shift"][1] = True
        hist.InstrumentParameters["U"][2] = True
        hist.InstrumentParameters["W"][2] = True
        hist.InstrumentParameters["Polariz."][2] = True
        for phase_index, phase in enumerate(project.phases()):
            phase.set_refinements({"Cell": True})
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][2][0] = True
            hap["Pref.Ori."][2] = phase_index > 0
            if with_wo3_strain and phase_index == 1:
                hap["Mustrain"][2][0] = True
        item = run(project, f"joint_settle_{pass_index + 1}", 12)
        records.append(item)
        if (
            item["converged"]
            and item["max_shift_esd"] is not None
            and float(item["max_shift_esd"]) <= 0.25
            and not item["frozen"]
        ):
            break

    clear_flags(project)
    project.save()
    output.with_suffix(".terminal.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
