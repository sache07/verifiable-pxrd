#!/usr/bin/env python3
"""Create the machine-readable outputs from the independent final replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "final_replay"
profile = np.load(REPLAY / "prediction.npz")
x = np.asarray(profile["x"], float)
observed = np.asarray(profile["observed"], float)
calculated = np.asarray(profile["predicted"], float)
difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(chi_square / denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
n_parameters = 33
dof = int(len(x) - n_parameters)
reduced_chi_square = float(chi_square / dof)

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt="%.8f",
)

replay = json.loads((REPLAY / "replay.json").read_text())
paths = {
    "CuWO4_P-1": ("copper(II) tungstate", "CuWO4", "P -1", "CuWO4.cif"),
    "Cu3WO6_Pa-3": ("tricopper tungsten hexoxide", "Cu3WO6", "P a -3", "Cu3WO6.cif"),
    "WO3_P21c": ("tungsten(VI) oxide", "WO3", "P 21/c", "WO3.cif"),
}
phases = []
for row in replay["phases"]:
    display_name, formula, space_group, cif_path = paths[row["name"]]
    phases.append({
        "name": display_name,
        "formula": formula,
        "space_group": space_group,
        "cif_path": cif_path,
        "weight_fraction": float(row["weight_fraction"]),
    })

result = {
    "phases": phases,
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "chi_square_poisson": chi_square,
        "reduced_chi_square": reduced_chi_square,
        "goodness_of_fit": float(np.sqrt(reduced_chi_square)),
        "number_of_points": int(len(x)),
        "number_of_refined_parameters": n_parameters,
        "zero_offset_deg": -0.47984020352644696,
    },
    "refinement_histogram": replay["histogram"],
    "fraction_basis": "normalized over the three modeled crystalline phases",
    "project_path": "final.gpx",
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
