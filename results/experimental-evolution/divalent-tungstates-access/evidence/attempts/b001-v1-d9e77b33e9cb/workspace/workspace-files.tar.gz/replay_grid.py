#!/usr/bin/env python3
"""Independently replay the fixed specimen-displacement diagnostic grid."""

from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
WORK = ROOT / ".tmp" / "shiftgrid"
WORK.mkdir(parents=True, exist_ok=True)
worker_path = ROOT / "learned" / "divalent-tungstates" / "scorer" / "runtime" / "replay_worker.py"
spec = importlib.util.spec_from_file_location("frozen_replay_worker", worker_path)
worker = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(worker)

rows = []
os.chdir(WORK)
for project in sorted((ROOT / ".tmp" / "gsas").glob("grid_*.gpx")):
    setup = json.loads(project.with_suffix(".json").read_text())
    report = worker.replay({
        "project": str(project.resolve()),
        "observed": str((ROOT / "inputs" / "pattern.csv").resolve()),
    })
    profile = np.load("prediction.npz")
    observed = profile["observed"]
    predicted = profile["predicted"]
    weights = 1.0 / np.maximum(observed, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(weights * (observed - predicted) ** 2) /
                           np.sum(weights * observed ** 2))
    rows.append({
        "project": project.name,
        "shift_um": setup["fixed_shift_um"],
        "zero_deg": setup["fixed_zero_deg"],
        "rwp_percent": float(rwp),
        "profile_review_flags": report["profile_review_flags"],
    })

(WORK / "grid_results.json").write_text(json.dumps(rows, indent=2) + "\n")
for row in sorted(rows, key=lambda item: item["rwp_percent"]):
    print(row)
