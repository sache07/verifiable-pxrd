#!/usr/bin/env python3
"""GSAS-II setup and staged refinement helpers for this powder pattern."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs" / "pattern.csv"
WORK = ROOT / ".tmp" / "gsas"


def prepare_files() -> tuple[Path, Path]:
    WORK.mkdir(parents=True, exist_ok=True)
    xye = WORK / "pattern.xye"
    if not xye.exists():
        data = np.loadtxt(INPUT, delimiter=",", skiprows=1)
        np.savetxt(xye, np.column_stack((data[:, 0], data[:, 1], np.sqrt(np.maximum(data[:, 1], 1.0)))), fmt="%.8f %.8f %.8f")
    inst = WORK / "initial.instprm"
    if not inst.exists():
        inst.write_text(
            "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
            "Type:PXC;Bank:1\n"
            "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
            "Zero:-0.45;Polariz.:0.80;Azimuth:0.0\n"
            "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
        )
    return xye, inst


def clear_all(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements({
        "Background": True,
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": True,
            "Size": True,
            "Mustrain": True,
            "Pref.Ori.": True,
            "Extinction": True,
            "HStrain": True,
        })


def make_project(cifs: list[Path], names: list[str], output: Path) -> G2.G2Project:
    xye, inst = prepare_files()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [2200.0] + [0.0] * 11,
            "refine": False,
        },
    })
    for cif, name in zip(cifs, names):
        phase = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
    clear_all(project)
    project.set_Controls("cycles", 8)
    project.save()
    return project


def phase_state(project: G2.G2Project) -> list[dict]:
    hist = project.histograms()[0]
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name, {})
        rows.append({
            "name": phase.name,
            "use": bool(hap.get("Use", False)),
            "scale": float(hap.get("Scale", [0.0])[0]),
            "scale_refine": bool(hap.get("Scale", [0.0, False])[1]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
        })
    return rows


def fit_summary(project: G2.G2Project) -> dict:
    hist = project.histograms()[0]
    y = np.asarray(hist.data["data"][1][1], dtype=float)
    calc = np.asarray(hist.data["data"][1][3], dtype=float)
    w = 1.0 / np.maximum(y, 1.0)
    rwp = 100.0 * math.sqrt(float(np.sum(w * (y - calc) ** 2) / np.sum(w * y**2)))
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "histogram": hist.name,
        "rwp_recomputed_percent": rwp,
        "Rvals": cov.get("Rvals", {}),
        "varyList": [str(v) for v in cov.get("varyList", [])],
        "sample": hist.data["Sample Parameters"],
        "instrument": hist.data["Instrument Parameters"][0],
        "background": hist.data["Background"],
        "phases": phase_state(project),
    }


def refine_once(project: G2.G2Project, label: str, log: list[dict]) -> None:
    intended = [p for p in phase_state(project) if p["use"] and p["scale"] > 0]
    if not intended or len(intended) != len(project.phases()):
        raise RuntimeError(f"invalid active phase state before {label}: {phase_state(project)}")
    project.refine()
    summary = fit_summary(project)
    summary["stage"] = label
    log.append(summary)
    print(json.dumps({"stage": label, "rwp": summary["rwp_recomputed_percent"], "phases": summary["phases"]}, indent=2))


def screen(cifs: list[Path], names: list[str], output: Path) -> dict:
    project = make_project(cifs, names, output)
    hist = project.histograms()[0]
    log: list[dict] = []

    # Common trial protocol: scale/background, specimen position + cell,
    # then a restrained isotropic profile. Atomic coordinates remain fixed.
    hist.set_refinements({"Background": True})
    for name in names:
        project.phase(name).set_HAP_refinements({"Scale": True})
    refine_once(project, "scale_background", log)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_once(project, "zero", log)

    for name in names:
        project.phase(name).set_refinements({"Cell": True})
    refine_once(project, "zero_cell", log)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine_once(project, "isotropic_profile", log)
    project.save()
    payload = {"candidates": names, "cifs": [str(c) for c in cifs], "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def advance_atoms(source: Path, output: Path) -> dict:
    """Continue the nominated three-phase project with conservative atom stages."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    log: list[dict] = []

    refine_once(project, "reconverge", log)

    for phase in project.phases():
        for atom in phase.atoms():
            if atom.element != "O":
                atom.refinement_flags = "X"
    refine_once(project, "heavy_atom_coordinates", log)

    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    refine_once(project, "all_coordinates", log)

    # The synthetic laboratory applies one isotropic Uiso to every site in a
    # phase. Use an explicit equality constraint, rather than independent ADPs.
    project.save()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        atoms = list(phase.atoms())
        for atom in atoms:
            atom.uiso = 0.008
            atom.refinement_flags = "XU"
        if len(atoms) > 1:
            project.add_EquivConstr(
                [f"{pid}::AUiso:{i}" for i in range(len(atoms))],
                reloadIdx=True,
            )
    refine_once(project, "phase_wise_uiso", log)
    project.save()
    payload = {"source": str(source), "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def checkpoint(project: G2.G2Project, output: Path, stage: str) -> None:
    project.save()
    shutil.copy2(output, output.with_name(output.stem + f"_{stage}.gpx"))


def advance_physical(source: Path, output: Path) -> dict:
    """Refine a bounded, chemically conservative model from a screen project."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    hist = project.histograms()[0]
    log: list[dict] = []

    # Remove the arbitrary common 1000-ppm strain used only for screening.
    # Refit a nonnegative instrumental baseline first.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        for atom in phase.atoms():
            atom.refinement_flags = " "
    inst = hist.data["Instrument Parameters"][0]
    for key, value, low, high in [
        ("U", 10.0, 0.0, 40.0),
        ("W", 10.0, 2.0, 40.0),
        ("X", 1.0, 0.1, 6.0),
    ]:
        inst[key][1] = value
        inst[key][2] = True
        project.set_Controls("parmMin", low, variable=f":0:{key}")
        project.set_Controls("parmMax", high, variable=f":0:{key}")
    inst["SH/L"][1], inst["SH/L"][2] = 0.03, False
    inst["Polariz."][1], inst["Polariz."][2] = 0.8, False
    refine_once(project, "nonnegative_common_profile", log)
    checkpoint(project, output, "01_profile")

    # U commonly reaches the physical zero-strain baseline in this
    # decomposition. Keep that boundary solution fixed before atom work and
    # clear GSAS's automatic frozen-variable bookkeeping for the next stage.
    inst["U"][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}

    # Heavy-atom positions dominate laboratory X-ray intensities. Bound one
    # refinement step to a modest displacement from each source model.
    for phase in project.phases():
        pid = int(phase.data["pId"])
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "X" if atom.element != "O" else " "
            if atom.element != "O":
                for axis, value in zip("xyz", atom.coordinates):
                    project.set_Controls("parmMin", float(value) - 0.012, variable=f"{pid}::dA{axis}:{index}")
                    project.set_Controls("parmMax", float(value) + 0.012, variable=f"{pid}::dA{axis}:{index}")
    refine_once(project, "bounded_heavy_coordinates", log)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    checkpoint(project, output, "02_heavy")

    # CuWO4 is the only low-multiplicity phase where O coordinates are both
    # sufficiently constrained and economical to refine. Keep the minor-phase
    # oxygen frameworks at their published values.
    cuwo4 = project.phase("CuWO4_P-1")
    pid = int(cuwo4.data["pId"])
    for index, atom in enumerate(cuwo4.atoms()):
        atom.refinement_flags = "X" if atom.element == "O" else " "
        if atom.element == "O":
            for axis, value in zip("xyz", atom.coordinates):
                project.set_Controls("parmMin", float(value) - 0.012, variable=f"{pid}::dA{axis}:{index}")
                project.set_Controls("parmMax", float(value) + 0.012, variable=f"{pid}::dA{axis}:{index}")
    refine_once(project, "bounded_cuwo4_oxygen", log)
    for atom in cuwo4.atoms():
        atom.refinement_flags = " "
    checkpoint(project, output, "03_cuwo4_O")

    # One Uiso per phase, with the same physical range used by the laboratory
    # generator and explicit equality constraints for every site in a phase.
    project.save()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        atoms = list(phase.atoms())
        for atom in atoms:
            atom.uiso = 0.010
            atom.refinement_flags = "U"
        if len(atoms) > 1:
            project.add_EquivConstr([f"{pid}::AUiso:{i}" for i in range(len(atoms))], reloadIdx=True)
        project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:0")
        project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:0")
    refine_once(project, "bounded_phase_uiso", log)
    checkpoint(project, output, "04_uiso")

    # Polarization is shared by all phases and is identifiable from the broad
    # angular intensity trend. Test it before any texture term.
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    refine_once(project, "polarization", log)
    checkpoint(project, output, "05_polarization")

    project.save()
    payload = {"source": str(source), "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def cell_matrix(cell: list[float]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = map(float, cell[:6])
    alpha, beta, gamma = np.deg2rad([alpha, beta, gamma])
    ca, cb, cg = np.cos([alpha, beta, gamma])
    sg = np.sin(gamma)
    cx = c * cb
    cy = c * (ca - cb * cg) / sg
    return np.array([
        [a, 0.0, 0.0],
        [b * cg, b * sg, 0.0],
        [cx, cy, math.sqrt(max(0.0, c * c - cx * cx - cy * cy))],
    ])


def advance_regularized(source: Path, direction_project: Path, output: Path) -> dict:
    """Apply data-directed coordinate shifts, capped at plausible RMS values."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    direction = G2.G2Project(gpxfile=str(direction_project))
    project.set_Controls("cycles", 12)
    log: list[dict] = []
    movement: dict[str, dict] = {}

    for phase in project.phases():
        other = direction.phase(phase.name)
        if other is None:
            raise KeyError(f"direction project is missing phase {phase.name}")
        atoms = list(phase.atoms())
        targets = list(other.atoms())
        if [(a.label, a.element) for a in atoms] != [(a.label, a.element) for a in targets]:
            raise ValueError(f"atom mismatch for {phase.name}")
        lattice = cell_matrix(phase.data["General"]["Cell"][1:7])
        deltas = []
        for atom, target in zip(atoms, targets):
            delta = np.asarray(target.coordinates, float) - np.asarray(atom.coordinates, float)
            delta -= np.rint(delta)
            deltas.append(delta)
        deltas = np.asarray(deltas)
        elements = np.asarray([a.element for a in atoms])
        report = {}
        for element in sorted(set(elements)):
            mask = elements == element
            distances = np.linalg.norm(deltas[mask] @ lattice, axis=1)
            rms = float(np.sqrt(np.mean(distances**2)))
            cap = 0.040 if element == "O" else 0.030
            scale = min(1.0, cap / max(rms, 1e-15))
            deltas[mask] *= scale
            report[element] = {"unbounded_rms_A": rms, "retained_rms_A": rms * scale, "scale": scale}
        for atom, delta in zip(atoms, deltas):
            atom.coordinates = np.asarray(atom.coordinates, float) + delta
            atom.refinement_flags = " "
        movement[phase.name] = report

    # Coordinates are now fixed. Refit common terms before adding one nuisance
    # parameter class at a time.
    refine_once(project, "regularized_coordinates", log)
    checkpoint(project, output, "01_coordinates")

    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    refine_once(project, "polarization", log)
    inst["Polariz."][2] = False
    checkpoint(project, output, "02_polarization")

    project.save()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        atoms = list(phase.atoms())
        for atom in atoms:
            atom.uiso = 0.010
            atom.refinement_flags = "U"
        if len(atoms) > 1:
            project.add_EquivConstr([f"{pid}::AUiso:{i}" for i in range(len(atoms))], reloadIdx=True)
        project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:0")
        project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:0")
    refine_once(project, "bounded_phase_uiso", log)
    checkpoint(project, output, "03_uiso")

    project.save()
    payload = {"source": str(source), "direction_project": str(direction_project),
               "coordinate_regularization": movement, "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def advance_stable_nuisance(source: Path, output: Path) -> dict:
    """Resolve profile/ADP correlations using a fixed physical decomposition."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    log: list[dict] = []
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]

    # The 1000-ppm screening strain and common U are exactly correlated in a
    # one-pattern decomposition. Retain the former and fix U=0, which keeps all
    # analytic widths nonnegative without claiming a unique partition.
    inst["U"][1], inst["U"][2] = 0.0, False
    inst["Polariz."][2] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = 0.010
            atom.refinement_flags = " "
    refine_once(project, "fixed_physical_profile_baseline", log)
    checkpoint(project, output, "01_baseline")

    # Test each phase-wide Uiso separately. Checkpoints permit a phase to be
    # rolled back independently if its value is nonphysical or unstable.
    for n, phase in enumerate(project.phases(), start=2):
        pid = int(phase.data["pId"])
        atoms = list(phase.atoms())
        for atom in atoms:
            atom.refinement_flags = "U"
        if len(atoms) > 1:
            project.add_EquivConstr([f"{pid}::AUiso:{i}" for i in range(len(atoms))], reloadIdx=True)
        refine_once(project, f"uiso_{phase.name}", log)
        for atom in atoms:
            atom.refinement_flags = " "
        checkpoint(project, output, f"{n:02d}_uiso_{phase.name}")

    project.save()
    payload = {"source": str(source), "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def cleanup_adps(source: Path, output: Path) -> dict:
    """Create a physically valid rollback with fixed, phase-wise ADPs."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    for scope in ["Phase", "HAP", "Hist", "Global"]:
        project.get_Constraints(scope).clear()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    values = {"CuWO4_P-1": 0.004, "Cu3WO6_Pa-3": 0.004, "WO3_P21c": 0.0127}
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = values[phase.name]
            atom.refinement_flags = " "
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["U"][2] = 0.0, False
    inst["Polariz."][2] = False
    log: list[dict] = []
    refine_once(project, "fixed_valid_adps", log)
    project.save()
    payload = {"source": str(source), "fixed_uiso_A2": values, "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def screen_texture(source: Path, phase_name: str, axis: list[int], output: Path) -> dict:
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    if phase is None:
        raise KeyError(phase_name)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [int(v) for v in axis]
    pid, hid = int(phase.data["pId"]), int(hist.id)
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:{hid}:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:{hid}:MD")
    log: list[dict] = []
    refine_once(project, f"texture_{phase_name}_{''.join(map(str, axis))}", log)
    project.save()
    payload = {"source": str(source), "phase": phase_name, "axis": axis,
               "md_ratio": float(hap["Pref.Ori."][1]), "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def screen_texture_fixed(source: Path, phase_name: str, axis: list[int], ratio: float, output: Path) -> dict:
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = float(ratio)
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [int(v) for v in axis]
    log: list[dict] = []
    refine_once(project, f"fixed_texture_{phase_name}_{''.join(map(str, axis))}_{ratio:.3f}", log)
    project.save()
    payload = {"source": str(source), "phase": phase_name, "axis": axis, "md_ratio": ratio,
               "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def screen_roughness(source: Path, output: Path) -> dict:
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = project.histograms()[0]
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.30, True]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    log: list[dict] = []
    refine_once(project, "surface_roughness", log)
    project.save()
    payload = {"source": str(source), "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def screen_phase_profile(source: Path, phase_name: str, term: str, output: Path) -> dict:
    """Test one isotropic phase-profile term from the common clean model."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    if phase is None:
        raise KeyError(phase_name)
    hap = phase.data["Histograms"][hist.name]
    pid, hid = int(phase.data["pId"]), int(hist.id)
    if term == "strain":
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
        variable = f"{pid}:{hid}:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 8000.0, variable=variable)
    elif term == "size":
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Size"][2][0] = True
        variable = f"{pid}:{hid}:Size;i"
        project.set_Controls("parmMin", 0.04, variable=variable)
        project.set_Controls("parmMax", 2.0, variable=variable)
    else:
        raise ValueError("term must be 'strain' or 'size'")
    log: list[dict] = []
    refine_once(project, f"phase_profile_{phase_name}_{term}", log)
    project.save()
    payload = {"source": str(source), "phase": phase_name, "term": term,
               "value": float(hap["Mustrain" if term == "strain" else "Size"][1][0]),
               "variable": variable, "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def screen_axial_divergence(source: Path, output: Path) -> dict:
    """Test the single instrumental axial-divergence parameter."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = project.histograms()[0]
    shl = hist.data["Instrument Parameters"][0]["SH/L"]
    shl[1], shl[2] = 0.03, True
    project.set_Controls("parmMin", 0.002, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.10, variable=":0:SH/L")
    log: list[dict] = []
    refine_once(project, "axial_divergence", log)
    project.save()
    payload = {"source": str(source), "SH_L": float(shl[1]),
               "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def reconverge(source: Path, rounds: int, output: Path) -> dict:
    """Replay additional least-squares blocks without changing the model."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    log: list[dict] = []
    for index in range(rounds):
        refine_once(project, f"reconverge_{index + 1}", log)
    project.save()
    payload = {"source": str(source), "rounds": rounds, "stages": log,
               "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def make_effective_profile_baseline(source: Path, output: Path) -> dict:
    """Choose a nonnegative profile gauge before phase-specific broadening tests.

    Instrument X and reciprocal crystallite size, as well as U and isotropic
    microstrain, cannot be uniquely partitioned from one scan. Keep U at zero
    and X at the generator's physical lower range, then let later branches test
    relative phase broadening.
    """
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 16)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][1], inst["U"][2] = 0.0, False
    inst["X"][1], inst["X"][2] = 0.1, False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = False
    log: list[dict] = []
    refine_once(project, "effective_profile_baseline_1", log)
    refine_once(project, "effective_profile_baseline_2", log)
    project.save()
    payload = {"source": str(source), "fixed_instrument_U": 0.0,
               "fixed_instrument_X": 0.1, "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def fix_phase_cell_and_reconverge(source: Path, phase_name: str, output: Path) -> dict:
    """Freeze an already-refined ill-conditioned cell metric and reconverge."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 16)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    phase = project.phase(phase_name)
    if phase is None:
        raise KeyError(phase_name)
    phase.clear_refinements({"Cell": True})
    log: list[dict] = []
    refine_once(project, f"fixed_cell_{phase_name}_1", log)
    refine_once(project, f"fixed_cell_{phase_name}_2", log)
    project.save()
    payload = {"source": str(source), "fixed_cell_phase": phase_name,
               "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def screen_specimen_displacement(source: Path, shift_um: float, zero_deg: float, output: Path) -> dict:
    """Separate bounded angular zero and Bragg--Brentano specimen height."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 20)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = project.histograms()[0]
    sample = hist.data["Sample Parameters"]
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [float(shift_um), True]
    zero = hist.data["Instrument Parameters"][0]["Zero"]
    zero[1], zero[2] = float(zero_deg), True
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    log: list[dict] = []
    refine_once(project, "specimen_displacement_1", log)
    refine_once(project, "specimen_displacement_2", log)
    project.save()
    payload = {"source": str(source), "initial_shift_um": shift_um,
               "initial_zero_deg": zero_deg, "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def screen_shift_fixed_zero(source: Path, shift_um: float, zero_deg: float, output: Path) -> dict:
    """Refine specimen height at one fixed, physically plausible zero offset."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 12)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    hist = project.histograms()[0]
    sample = hist.data["Sample Parameters"]
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [float(shift_um), True]
    zero = hist.data["Instrument Parameters"][0]["Zero"]
    zero[1], zero[2] = float(zero_deg), False
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    log: list[dict] = []
    refine_once(project, "shift_at_fixed_zero", log)
    project.save()
    payload = {"source": str(source), "fixed_zero_deg": zero_deg,
               "initial_shift_um": shift_um, "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def set_fixed_displacement(source: Path, shift_um: float, zero_deg: float, output: Path) -> dict:
    """Write a fixed zero/height replay point without least-squares changes."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    sample = hist.data["Sample Parameters"]
    sample["Gonio. radius"] = 200.0
    sample["Shift"] = [float(shift_um), False]
    zero = hist.data["Instrument Parameters"][0]["Zero"]
    zero[1], zero[2] = float(zero_deg), False
    project.save()
    payload = {"source": str(source), "fixed_shift_um": shift_um,
               "fixed_zero_deg": zero_deg, "model": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def screen_phase_coordinates(source: Path, phase_name: str, mode: str,
                             half_width_fractional: float, output: Path) -> dict:
    """Test a small symmetry-allowed coordinate neighborhood for one phase."""
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 16)
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    phase = project.phase(phase_name)
    if phase is None:
        raise KeyError(phase_name)
    pid = int(phase.data["pId"])
    for other in project.phases():
        for atom in other.atoms():
            atom.refinement_flags = " "
    selected = []
    for index, atom in enumerate(phase.atoms()):
        use = mode == "all" or (mode == "heavy" and atom.element != "O") or (mode == "oxygen" and atom.element == "O")
        atom.refinement_flags = "X" if use else " "
        if use:
            selected.append({"index": index, "label": atom.label, "element": atom.element})
            for axis, value in zip("xyz", atom.coordinates):
                project.set_Controls("parmMin", float(value) - half_width_fractional,
                                     variable=f"{pid}::dA{axis}:{index}")
                project.set_Controls("parmMax", float(value) + half_width_fractional,
                                     variable=f"{pid}::dA{axis}:{index}")
    if not selected:
        raise ValueError("no atoms selected")
    log: list[dict] = []
    refine_once(project, f"coordinates_{phase_name}_{mode}", log)
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save()
    payload = {"source": str(source), "phase": phase_name, "mode": mode,
               "half_width_fractional": half_width_fractional, "selected": selected,
               "stages": log, "final": fit_summary(project)}
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    return payload


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="action", required=True)
    p = sub.add_parser("screen")
    p.add_argument("cif", type=Path)
    p.add_argument("name")
    p.add_argument("output", type=Path)
    m = sub.add_parser("multi")
    m.add_argument("spec", type=Path, help="JSON list of objects with name and cif")
    m.add_argument("output", type=Path)
    a = sub.add_parser("atoms")
    a.add_argument("source", type=Path)
    a.add_argument("output", type=Path)
    q = sub.add_parser("physical")
    q.add_argument("source", type=Path)
    q.add_argument("output", type=Path)
    z = sub.add_parser("regularize")
    z.add_argument("source", type=Path)
    z.add_argument("direction_project", type=Path)
    z.add_argument("output", type=Path)
    s = sub.add_parser("stabilize")
    s.add_argument("source", type=Path)
    s.add_argument("output", type=Path)
    c = sub.add_parser("cleanup")
    c.add_argument("source", type=Path)
    c.add_argument("output", type=Path)
    t = sub.add_parser("texture")
    t.add_argument("source", type=Path)
    t.add_argument("phase")
    t.add_argument("axis", help="comma-separated h,k,l")
    t.add_argument("output", type=Path)
    f = sub.add_parser("texture-fixed")
    f.add_argument("source", type=Path)
    f.add_argument("phase")
    f.add_argument("axis", help="comma-separated h,k,l")
    f.add_argument("ratio", type=float)
    f.add_argument("output", type=Path)
    u = sub.add_parser("roughness")
    u.add_argument("source", type=Path)
    u.add_argument("output", type=Path)
    v = sub.add_parser("profile")
    v.add_argument("source", type=Path)
    v.add_argument("phase")
    v.add_argument("term", choices=["strain", "size"])
    v.add_argument("output", type=Path)
    w = sub.add_parser("axial")
    w.add_argument("source", type=Path)
    w.add_argument("output", type=Path)
    x = sub.add_parser("reconverge")
    x.add_argument("source", type=Path)
    x.add_argument("rounds", type=int)
    x.add_argument("output", type=Path)
    y = sub.add_parser("profile-baseline")
    y.add_argument("source", type=Path)
    y.add_argument("output", type=Path)
    aa = sub.add_parser("fix-cell")
    aa.add_argument("source", type=Path)
    aa.add_argument("phase")
    aa.add_argument("output", type=Path)
    ab = sub.add_parser("displacement")
    ab.add_argument("source", type=Path)
    ab.add_argument("shift_um", type=float)
    ab.add_argument("zero_deg", type=float)
    ab.add_argument("output", type=Path)
    ac = sub.add_parser("shift-fixed-zero")
    ac.add_argument("source", type=Path)
    ac.add_argument("shift_um", type=float)
    ac.add_argument("zero_deg", type=float)
    ac.add_argument("output", type=Path)
    ad = sub.add_parser("fixed-displacement")
    ad.add_argument("source", type=Path)
    ad.add_argument("shift_um", type=float)
    ad.add_argument("zero_deg", type=float)
    ad.add_argument("output", type=Path)
    ae = sub.add_parser("coordinates")
    ae.add_argument("source", type=Path)
    ae.add_argument("phase")
    ae.add_argument("mode", choices=["all", "heavy", "oxygen"])
    ae.add_argument("half_width_fractional", type=float)
    ae.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    if args.action == "screen":
        screen([args.cif.resolve()], [args.name], args.output.resolve())
    elif args.action == "multi":
        rows = json.loads(args.spec.read_text())
        screen([Path(row["cif"]).resolve() for row in rows], [row["name"] for row in rows], args.output.resolve())
    elif args.action == "atoms":
        advance_atoms(args.source.resolve(), args.output.resolve())
    elif args.action == "physical":
        advance_physical(args.source.resolve(), args.output.resolve())
    elif args.action == "regularize":
        advance_regularized(args.source.resolve(), args.direction_project.resolve(), args.output.resolve())
    elif args.action == "stabilize":
        advance_stable_nuisance(args.source.resolve(), args.output.resolve())
    elif args.action == "cleanup":
        cleanup_adps(args.source.resolve(), args.output.resolve())
    elif args.action == "texture":
        axis = [int(v) for v in args.axis.split(",")]
        if len(axis) != 3:
            raise ValueError("axis needs h,k,l")
        screen_texture(args.source.resolve(), args.phase, axis, args.output.resolve())
    elif args.action == "texture-fixed":
        axis = [int(v) for v in args.axis.split(",")]
        if len(axis) != 3:
            raise ValueError("axis needs h,k,l")
        screen_texture_fixed(args.source.resolve(), args.phase, axis, args.ratio, args.output.resolve())
    elif args.action == "roughness":
        screen_roughness(args.source.resolve(), args.output.resolve())
    elif args.action == "profile":
        screen_phase_profile(args.source.resolve(), args.phase, args.term, args.output.resolve())
    elif args.action == "axial":
        screen_axial_divergence(args.source.resolve(), args.output.resolve())
    elif args.action == "reconverge":
        reconverge(args.source.resolve(), args.rounds, args.output.resolve())
    elif args.action == "profile-baseline":
        make_effective_profile_baseline(args.source.resolve(), args.output.resolve())
    elif args.action == "fix-cell":
        fix_phase_cell_and_reconverge(args.source.resolve(), args.phase, args.output.resolve())
    elif args.action == "displacement":
        screen_specimen_displacement(args.source.resolve(), args.shift_um, args.zero_deg, args.output.resolve())
    elif args.action == "shift-fixed-zero":
        screen_shift_fixed_zero(args.source.resolve(), args.shift_um, args.zero_deg, args.output.resolve())
    elif args.action == "fixed-displacement":
        set_fixed_displacement(args.source.resolve(), args.shift_um, args.zero_deg, args.output.resolve())
    elif args.action == "coordinates":
        screen_phase_coordinates(args.source.resolve(), args.phase, args.mode,
                                 args.half_width_fractional, args.output.resolve())


if __name__ == "__main__":
    main()
