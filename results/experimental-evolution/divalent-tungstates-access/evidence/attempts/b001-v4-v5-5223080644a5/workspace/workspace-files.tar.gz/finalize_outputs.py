import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_checkpoint.gpx"
FINAL_GPX = ROOT / "final.gpx"

gpx = G2sc.G2Project(gpxfile=str(SOURCE), filename=str(FINAL_GPX))
h = gpx.histograms()[0]

# Remove diagnostic-only bookkeeping left by the replaced WO3 phase and
# obsolete trial parameter limits. Neither affects the retained calculation,
# but this keeps the submitted project clean and replayable.
for key in list(h.data["data"][0]):
    if key.startswith("3:"):
        del h.data["data"][0][key]
controls = gpx.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {}
gpx.save()

phase_specs = [
    ("MnWO4", "MnWO4", "MnWO4.cif"),
    ("Mn3WO6_R-3", "Mn3WO6", "Mn3WO6_R-3.cif"),
    ("WO3_2311041", "WO3", "WO3_monoclinic.cif"),
]

fractions = h.ComputeMassFracs()
phase_rows = []
for project_name, formula, filename in phase_specs:
    phase = gpx.phase(project_name)
    phase.export_CIF(str(ROOT / filename))
    fraction, fraction_esd = fractions[project_name]
    cell = phase.get_cell()
    phase_rows.append(
        {
            "name": formula,
            "project_phase": project_name,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(fraction_esd),
            "cell": {key: float(value) for key, value in cell.items()},
        }
    )

x = np.asarray(h.getdata("X"), dtype=float)
yobs = np.asarray(h.getdata("Yobs"), dtype=float)
ycalc = np.asarray(h.getdata("Ycalc"), dtype=float)
background = np.asarray(h.getdata("Background"), dtype=float)
difference = yobs - ycalc
with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference_intensity",
            "background_intensity",
        ]
    )
    writer.writerows(zip(x, yobs, ycalc, difference, background))

rvals = gpx.data["Covariance"]["data"]["Rvals"]
fit_statistics = {
    "Rwp_percent": float(h.get_wR()),
    "Rp_percent": float(h.residuals["R"]),
    "Rexp_percent": float(h.residuals["wRmin"]),
    "goodness_of_fit": float(rvals["GOF"]),
    "chi_square": float(rvals["chisq"]),
    "number_observations": int(rvals["Nobs"]),
    "number_refined_variables_final_stage": int(rvals["Nvars"]),
    "durbin_watson": float(h.data["data"][0]["Durbin-Watson"]),
    "converged": bool(rvals["converged"]),
    "max_shift_over_esd": float(rvals["Max shft/sig"]),
}

result = {
    "schema_version": 1,
    "project": "final.gpx",
    "refinement_histogram": h.name,
    "fit_profile": "fit.csv",
    "phases": phase_rows,
    "fit_statistics": fit_statistics,
    "weight_fraction_basis": "normalized over modeled crystalline phases",
}
with (ROOT / "result.json").open("w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
