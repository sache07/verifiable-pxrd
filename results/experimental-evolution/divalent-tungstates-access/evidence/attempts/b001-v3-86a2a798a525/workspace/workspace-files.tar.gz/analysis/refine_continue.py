#!/usr/bin/env python3
"""Continue a saved GSAS-II trial with one controlled refinement change."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def clear_flags(project: G2.G2Project) -> None:
    """Clear all refine flags without changing any parameter values."""
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) >= 3 and isinstance(item[2], (bool, np.bool_)):
            item[2] = False
    for key in (
        "Scale",
        "Absorption",
        "DisplaceX",
        "DisplaceY",
        "Shift",
        "Transparency",
        "SurfRoughA",
        "SurfRoughB",
    ):
        item = hist.SampleParameters.get(key)
        if isinstance(item, list) and len(item) >= 2 and isinstance(item[1], (bool, np.bool_)):
            item[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            }
        )
    project.set_Frozen()


def common_nuisance(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def bound_coordinate_shifts(project: G2.G2Project, phase_index: int, atom_indices: list[int], limit: float) -> None:
    phase = project.phases()[phase_index]
    for atom_index in atom_indices:
        center = phase.atoms()[atom_index].coordinates
        for coordinate, value in zip("xyz", center):
            variable = f"{phase_index}::dA{coordinate}:{atom_index}"
            # GSAS-II names the refined correction dA*, but parameter-limit
            # handling compares and clips the absolute A* coordinate.
            project.set_Controls("parmMin", value - limit, variable)
            project.set_Controls("parmMax", value + limit, variable)


def set_mode(project: G2.G2Project, args: argparse.Namespace) -> None:
    hist = project.histogram(0)
    phases = project.phases()
    common_nuisance(project)
    if args.mode == "scale":
        pass
    elif args.mode == "cells":
        for phase in phases:
            phase.set_refinements({"Cell": True})
    elif args.mode == "instrument":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    elif args.mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.mode == "ca_o":
        phases[0].set_refinements({"Atoms": {"O1": "X"}})
        indices = [i for i, atom in enumerate(phases[0].atoms()) if atom.label == "O1"]
        bound_coordinate_shifts(project, 0, indices, args.coordinate_limit)
    elif args.mode == "wo_w":
        labels = {a.label: "X" for a in phases[1].atoms() if a.element == "W"}
        phases[1].set_refinements({"Atoms": labels})
        indices = [i for i, atom in enumerate(phases[1].atoms()) if atom.element == "W"]
        bound_coordinate_shifts(project, 1, indices, args.coordinate_limit)
    elif args.mode == "wo_o":
        labels = {a.label: "X" for a in phases[1].atoms() if a.element == "O"}
        phases[1].set_refinements({"Atoms": labels})
        indices = [i for i, atom in enumerate(phases[1].atoms()) if atom.element == "O"]
        bound_coordinate_shifts(project, 1, indices, args.coordinate_limit)
    elif args.mode == "all_xyz":
        for pidx, phase in enumerate(phases):
            phase.set_refinements({"Atoms": {"all": "X"}})
            bound_coordinate_shifts(project, pidx, list(range(len(phase.atoms()))), args.coordinate_limit)
    elif args.mode == "uiso":
        for pidx, phase in enumerate(phases):
            for atom in phase.atoms():
                atom.uiso = args.uiso_start
                atom.refinement_flags = "U"
            variables = tuple(f"{pidx}::AUiso:{i}" for i, _ in enumerate(phase.atoms()))
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)
            for variable in variables:
                project.set_Controls("parmMin", 0.003, variable)
                project.set_Controls("parmMax", 0.020, variable)
    elif args.mode == "roughness":
        hist.SampleParameters["SurfRoughA"] = [args.rough_a, True]
        hist.SampleParameters["SurfRoughB"] = [args.rough_b, True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMax", 0.8, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 1.5, ":0:SurfRoughB")
    elif args.mode == "po":
        phase = phases[args.phase]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = args.po_start
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(args.axis)
        variable = f"{args.phase}:0:MD"
        project.set_Controls("parmMin", 0.5, variable)
        project.set_Controls("parmMax", 2.0, variable)
    elif args.mode in ("uniaxial", "uniaxial_continue"):
        phase = phases[args.phase]
        hap = phase.data["Histograms"][hist.name]
        if args.mode == "uniaxial":
            value = max(300.0, float(hap["Mustrain"][1][0]))
            phase.setSampleProfile(hist, "microstrain", "uniaxial", value, value, list(args.axis), LGmix=1.0)
        else:
            if hap["Mustrain"][0] != "uniaxial":
                raise ValueError("uniaxial_continue requires an existing uniaxial profile")
            args.axis = tuple(hap["Mustrain"][3])
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": list(args.axis), "refine": True}}
        )
        for suffix in ("i", "a"):
            variable = f"{args.phase}:0:Mustrain;{suffix}"
            project.set_Controls("parmMin", 0.0, variable)
            project.set_Controls("parmMax", 8000.0, variable)
    elif args.mode in ("phase_profile", "phase_size", "phase_strain"):
        phase = phases[args.phase]
        hist_name = hist.name
        hap = phase.data["Histograms"][hist_name]
        phase.set_refinements({"Cell": True})
        if args.mode in ("phase_profile", "phase_size"):
            phase.set_HAP_refinements(
                {"Size": {"type": hap["Size"][0], "refine": True}}
            )
        if args.mode in ("phase_profile", "phase_strain"):
            phase.set_HAP_refinements(
                {"Mustrain": {"type": hap["Mustrain"][0], "refine": True}}
            )
        pidx = args.phase
        project.set_Controls("parmMin", 0.04, f"{pidx}:0:Size;i")
        project.set_Controls("parmMax", 1.5, f"{pidx}:0:Size;i")
        project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{pidx}:0:Mustrain;i")
    elif args.mode == "phase_uiso":
        phase = phases[args.phase]
        for atom in phase.atoms():
            # GSASIIscriptable exposes the I/A flag read-only; the atom record
            # itself stores it at ``cia`` and supports the standard GSAS-II
            # conversion by changing that field before assigning Uiso.
            atom.data[atom.cia] = "I"
            atom.uiso = args.uiso_start
            atom.refinement_flags = "U"
        variables = tuple(f"{args.phase}::AUiso:{i}" for i, _ in enumerate(phase.atoms()))
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable)
            project.set_Controls("parmMax", 0.020, variable)
    elif args.mode == "phase_uiso_continue":
        phase = phases[args.phase]
        for atom in phase.atoms():
            if atom.adp_flag != "I":
                raise ValueError("phase_uiso_continue requires isotropic atoms")
            atom.refinement_flags = "U"
        variables = tuple(f"{args.phase}::AUiso:{i}" for i, _ in enumerate(phase.atoms()))
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable)
            project.set_Controls("parmMax", 0.020, variable)
    elif args.mode == "profile":
        for phase in phases:
            phase.set_refinements({"Cell": True})
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif args.mode == "zero_shift":
        for phase in phases:
            phase.set_refinements({"Cell": True})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    else:
        raise ValueError(args.mode)


def report(project: G2.G2Project, out: Path, mode: str) -> None:
    hist = project.histogram(0)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "mass_scale": mass_scale,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": atom.coordinates,
                        "adp_flag": atom.adp_flag,
                        "adp": atom.ADP,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / sum(masses)
    data = {
        "mode": mode,
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        "frozen": project.get_Frozen(),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    out.with_suffix(".json").write_text(json.dumps(data, indent=2, default=str) + "\n")
    print(json.dumps({"wR": hist.residuals.get("wR"), "fractions": [p["weight_fraction"] for p in phases], "frozen": data["frozen"]}))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument(
        "--mode",
        required=True,
        choices=("scale", "cells", "instrument", "polarization", "ca_o", "wo_w", "wo_o", "all_xyz", "uiso", "roughness", "po", "uniaxial", "uniaxial_continue", "phase_profile", "phase_size", "phase_strain", "phase_uiso", "phase_uiso_continue", "profile", "zero_shift"),
    )
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", type=int, nargs=3, default=(0, 0, 1))
    parser.add_argument("--po-start", type=float, default=1.0)
    parser.add_argument("--uiso-start", type=float, default=0.01)
    parser.add_argument("--rough-a", type=float, default=0.2)
    parser.add_argument("--rough-b", type=float, default=0.1)
    parser.add_argument("--coordinate-limit", type=float, default=0.015)
    parser.add_argument("--shift-factor", type=float, default=0.1)
    args = parser.parse_args()

    source = (ROOT / args.input).resolve()
    out = (ROOT / args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(out))
    clear_flags(project)
    set_mode(project, args)
    project.data["Controls"]["data"]["shift factor"] = args.shift_factor
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    report(project, out, args.mode)


if __name__ == "__main__":
    main()
