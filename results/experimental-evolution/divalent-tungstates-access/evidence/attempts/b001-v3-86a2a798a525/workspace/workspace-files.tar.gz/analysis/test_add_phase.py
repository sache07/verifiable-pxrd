#!/usr/bin/env python3
"""Test whether a candidate crystalline phase retains a stable positive scale."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_continue import clear_flags, common_nuisance


ROOT = Path(__file__).resolve().parents[1]


def snapshot(project: G2.G2Project, path: Path, stage: str) -> dict:
    hist = project.histogram(0)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total if total else 0.0
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": stage,
        "residuals": hist.residuals,
        "phases": phases,
        "varyList": cov.get("varyList", []),
        "depSigDict": cov.get("depSigDict", {}),
        "Rvals": cov.get("Rvals", {}),
    }
    path.with_suffix(f".{stage}.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    return result


def refine(project: G2.G2Project, output: Path, stage: str, cycles: int = 16) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    project.save()
    return snapshot(project, output, stage)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--scale", type=float, default=0.5)
    parser.add_argument("--size", type=float, default=0.2)
    parser.add_argument("--strain", type=float, default=1000.0)
    args = parser.parse_args()

    input_path = (ROOT / args.input).resolve()
    output = (ROOT / args.out).resolve()
    cif = Path(args.cif)
    if not cif.is_absolute():
        cif = (ROOT / cif).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(input_path), newgpx=str(output))
    clear_flags(project)
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(cif), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    candidate.setSampleProfile(hist, "size", "isotropic", args.size, LGmix=1.0)
    candidate.setSampleProfile(hist, "microstrain", "isotropic", args.strain, LGmix=1.0)
    candidate.data["Histograms"][hist.name]["Scale"] = [args.scale, False]

    pidx = len(project.phases()) - 1
    for i in range(len(project.phases())):
        project.set_Controls("parmMin", 0.0, f"{i}:0:Scale")
        project.set_Controls("parmMax", 1000.0, f"{i}:0:Scale")
    project.set_Controls("parmMin", 0.04, f"{pidx}:0:Size;i")
    project.set_Controls("parmMax", 1.5, f"{pidx}:0:Size;i")
    project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, f"{pidx}:0:Mustrain;i")
    project.data["Controls"]["data"]["shift factor"] = 0.2

    common_nuisance(project)
    project.save()
    result = refine(project, output, "scale")

    # If the candidate retains measurable intensity, give its cell and width
    # comparable relaxation before judging it. A scale at the non-negative
    # bound is already a stable collapse and cannot support these refinements.
    candidate_result = result["phases"][-1]
    if candidate_result["scale"] > 1e-8 and candidate_result["weight_fraction"] > 1e-7:
        candidate.set_refinements({"Cell": True})
        result = refine(project, output, "cell")
        candidate.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        result = refine(project, output, "profile", cycles=20)

    output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(
        json.dumps(
            {
                "candidate": args.name,
                "start_scale": args.scale,
                "rwp": result["residuals"].get("wR"),
                "scale": result["phases"][-1]["scale"],
                "weight_fraction": result["phases"][-1]["weight_fraction"],
                "stage": result["stage"],
            }
        )
    )


if __name__ == "__main__":
    main()
