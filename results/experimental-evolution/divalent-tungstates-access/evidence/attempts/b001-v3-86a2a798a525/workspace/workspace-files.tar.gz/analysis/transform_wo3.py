#!/usr/bin/env python3
"""Transform COD 2311041 WO3 to its equivalent near-orthogonal P21/n cell."""

from pathlib import Path
import re

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/2/31/10/2311041.cif"
)


def main() -> None:
    structure = Structure.from_file(SOURCE, primitive=False)
    # New basis in rows of the old basis:
    # a_n = a_c + c_c, b_n = b_c, c_n = -a_c.
    transform = np.array([[1, 0, 1], [0, 1, 0], [-1, 0, 0]], dtype=int)
    new_lattice = Lattice(transform @ structure.lattice.matrix)
    transformed = Structure(
        new_lattice,
        structure.species,
        structure.cart_coords,
        coords_are_cartesian=True,
        site_properties=structure.site_properties,
    )
    transformed.translate_sites(range(len(transformed)), [0, 0, 0], to_unit_cell=True)
    analyzer = SpacegroupAnalyzer(transformed, symprec=1e-3, angle_tolerance=0.1)
    refined = analyzer.get_refined_structure()
    out = ROOT / ".tmp/WO3_2311041_p21n.cif"
    # Keep the explicitly transformed near-orthogonal cell. Standardizing the
    # structure would rotate it back into the oblique conventional setting.
    CifWriter(transformed, symprec=1e-3, refine_struct=False).write_file(out)
    text = out.read_text().replace(
        "_symmetry_space_group_name_H-M   P2_1/c",
        "_symmetry_space_group_name_H-M   'P 1 21/n 1'\n"
        "_symmetry_space_group_name_Hall   '-P 2yn'",
    )
    text = re.sub(r"^_symmetry_Int_Tables_number.*\n", "", text, flags=re.MULTILINE)
    # Let GSAS-II generate the setting's operators from the Hermann-Mauguin
    # symbol. Its CIF importer otherwise rejects the valid noncanonical operator
    # listing before applying its own setting transform.
    text = re.sub(
        r"loop_\n _symmetry_equiv_pos_site_id\n _symmetry_equiv_pos_as_xyz\n"
        r"(?: .*\n)+?(?=loop_\n _atom_site_type_symbol)",
        "",
        text,
    )
    out.write_text(text)
    print("input", structure.lattice, structure.get_space_group_info())
    print("transformed", transformed.lattice, transformed.get_space_group_info(symprec=1e-3))
    print("refined", refined.lattice, refined.get_space_group_info(symprec=1e-3))
    print(out)


if __name__ == "__main__":
    main()
