#!/usr/bin/env python3
"""Project selected coordinate shifts onto physical Cartesian-RMS limits."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_continue import clear_flags, common_nuisance, report


ROOT = Path(__file__).resolve().parents[1]
REFERENCES = {
    0: {"O1": np.array([0.15202, 0.01135, 0.20864])},
    1: {
        "W2": np.array([0.247, 0.033, 0.781]),
        "W1": np.array([0.252, 0.026, 0.285]),
    },
}


def lattice_matrix(cell: dict) -> np.ndarray:
    """Fractional-to-Cartesian matrix for the orthogonal/monoclinic cells here."""
    beta = math.radians(cell["angle_beta"])
    return np.array(
        [
            [cell["length_a"], 0.0, cell["length_c"] * math.cos(beta)],
            [0.0, cell["length_b"], 0.0],
            [0.0, 0.0, cell["length_c"] * math.sin(beta)],
        ]
    )


def project_phase(phase: G2.G2Phase, phase_index: int, target_rms: float) -> dict:
    matrix = lattice_matrix(phase.get_cell())
    records = []
    for atom in phase.atoms():
        reference = REFERENCES[phase_index].get(atom.label)
        if reference is None:
            continue
        delta = np.asarray(atom.coordinates, dtype=float) - reference
        delta -= np.rint(delta)
        norm = float(np.linalg.norm(matrix @ delta))
        records.append((atom, reference, delta, norm))
    current_rms = float(np.sqrt(np.mean([record[3] ** 2 for record in records])))
    factor = target_rms / current_rms if current_rms else 0.0
    for atom, reference, delta, _ in records:
        atom.coordinates = ((reference + factor * delta) % 1.0).tolist()
    return {
        "phase": phase.name,
        "target_rms_A": target_rms,
        "starting_rms_A": current_rms,
        "scale_factor": factor,
        "coordinates": {atom.label: atom.coordinates for atom, *_ in records},
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--ca-o-rms", type=float, required=True)
    parser.add_argument("--wo-w-rms", type=float, required=True)
    parser.add_argument("--cycles", type=int, default=30)
    args = parser.parse_args()

    source = (ROOT / args.input).resolve()
    output = (ROOT / args.out).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(source), newgpx=str(output))
    clear_flags(project)
    changes = [
        project_phase(project.phases()[0], 0, args.ca_o_rms),
        project_phase(project.phases()[1], 1, args.wo_w_rms),
    ]
    common_nuisance(project)
    project.data["Controls"]["data"]["shift factor"] = 0.1
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    report(project, output, "coordinate_rollback")
    payload = json.loads(output.with_suffix(".json").read_text())
    payload["coordinate_projection"] = changes
    output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")
    print(json.dumps({"rwp": project.histogram(0).residuals.get("wR"), "changes": changes}))


if __name__ == "__main__":
    main()
