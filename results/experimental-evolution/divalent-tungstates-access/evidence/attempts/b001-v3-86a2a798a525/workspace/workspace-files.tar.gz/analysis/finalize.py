#!/usr/bin/env python3
"""Create the submission artifacts from the selected replay-stable GSAS-II project."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / ".tmp/final-stages/u0_final2.gpx"
FINAL = ROOT / "final.gpx"
REPLAY_WORKER = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
REPLAY_DIR = ROOT / ".tmp/final-deliverable-replay"

PHASE_INFO = [
    {
        "formula": "CaWO4",
        "name": "calcium tungstate (scheelite)",
        "cif_path": "phase_CaWO4.cif",
        "reference": "COD 7219229",
        "reliability": "phase and framework reliable; oxygen displacement is physically capped",
    },
    {
        "formula": "WO3",
        "name": "tungsten(VI) oxide (room-temperature monoclinic)",
        "cif_path": "phase_WO3.cif",
        "reference": "COD 1528915",
        "reliability": "phase and W framework reliable; exact O substructure is not independently reliable",
    },
    {
        "formula": "CaCO3",
        "name": "calcium carbonate (calcite)",
        "cif_path": "phase_CaCO3_calcite.cif",
        "reference": "COD 1547347",
        "reliability": "phase reliable; weak-phase size/strain and light-atom details are correlated",
    },
]


def replay_final() -> tuple[dict, dict[str, np.ndarray]]:
    REPLAY_DIR.mkdir(parents=True, exist_ok=True)
    spec = importlib.util.spec_from_file_location("frozen_replay_worker", REPLAY_WORKER)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    old = Path.cwd()
    try:
        os.chdir(REPLAY_DIR)
        result = module.replay(
            {"project": str(FINAL), "observed": str(ROOT / "inputs/pattern.csv")}
        )
        Path("replay.json").write_text(json.dumps(result, indent=2) + "\n")
        with np.load("prediction.npz", allow_pickle=False) as data:
            arrays = {key: data[key].copy() for key in data.files}
    finally:
        os.chdir(old)
    return result, arrays


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)
    shutil.copy2(SOURCE, FINAL)
    project = G2.G2Project(str(FINAL))
    histogram = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(PHASE_INFO):
        raise RuntimeError("Unexpected final phase count")

    for phase, info in zip(phases, PHASE_INFO):
        phase.export_CIF(str(ROOT / info["cif_path"]))

    replay, arrays = replay_final()
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError(f"Final replay did not pass cleanly: {replay}")
    x = arrays["x"]
    observed = arrays["observed"]
    calculated = arrays["predicted"]
    background = arrays["background"]
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.10f", "%.10f", "%.10f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(weighted_chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    rexp = float(histogram.residuals["wRmin"])
    native_gof = float(project.data["Covariance"]["data"]["Rvals"]["GOF"])
    dep_sig = project.data["Covariance"]["data"].get("depSigDict", {})

    replay_by_name = {row["name"]: row for row in replay["phases"]}
    phase_rows = []
    for phase, info in zip(phases, PHASE_INFO):
        replay_phase = replay_by_name[phase.name]
        key = f"{phase.data['pId']}:{histogram.id}:WgtFrac"
        esd = dep_sig.get(key, [None, None])[1]
        phase_rows.append(
            {
                "name": info["name"],
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": info["cif_path"],
                "weight_fraction": float(replay_phase["weight_fraction"]),
                "weight_fraction_esd": None if esd is None else float(esd),
                "reference_structure": info["reference"],
                "model_status": "resolved",
                "structure_reliability": info["reliability"],
                "cell": phase.get_cell(),
            }
        )

    result = {
        "method": "GSAS-II multiphase Rietveld refinement with independent full-grid atomic replay",
        "refinement_histogram": histogram.name,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_rows,
        "unresolved_components": [],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "r_exp_percent": rexp,
            "goodness_of_fit_native": native_gof,
            "rwp_over_rexp": rwp / rexp,
            "weighted_residual_sum": weighted_chi_square,
            "observations": int(len(x)),
            "evaluation_grid": "complete observed grid",
            "calculated_profile_source": "fresh independent replay of final.gpx",
        },
        "calibration": {
            "zero_deg": float(histogram.InstrumentParameters["Zero"][1]),
            "specimen_displacement_um": float(histogram.SampleParameters["Shift"][0]),
            "geometry": histogram.SampleParameters["Type"],
        },
        "verification": {
            "final_gpx_sha256": hashlib.sha256(FINAL.read_bytes()).hexdigest(),
            "replay_status": replay["status"],
            "profile_review_flags": replay["profile_review_flags"],
            "parameters_optimized_during_replay": replay["parameters_optimized"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    wt = [100.0 * row["weight_fraction"] for row in phase_rows]
    esd = [100.0 * row["weight_fraction_esd"] for row in phase_rows]
    residual_moles_wo3 = wt[1] / 231.84
    residual_moles_caco3 = wt[2] / 100.086
    mole_mismatch = abs(residual_moles_wo3 - residual_moles_caco3) / (
        0.5 * (residual_moles_wo3 + residual_moles_caco3)
    )
    report = f"""# Powder XRD phase analysis

The crystalline model contains three phases. Weight fractions are normalized over these modeled crystalline phases; parenthesized uncertainties below are conditional 1-sigma least-squares estimates and do not include model/background systematics.

| Phase | Space group | Weight fraction |
|---|---:|---:|
| CaWO4, scheelite | I 41/a | {wt[0]:.2f}({esd[0]*100:.0f}) wt% |
| WO3, monoclinic | P 21/n | {wt[1]:.2f}({esd[1]*100:.0f}) wt% |
| CaCO3, calcite | R -3 c | {wt[2]:.2f}({esd[2]*100:.0f}) wt% |

The independently regenerated full-grid profile gives Rwp = {rwp:.3f}%, Rp = {rp:.3f}%, Rexp = {rexp:.3f}%, and Rwp/Rexp = {rwp/rexp:.3f}. Replay made no parameter changes and raised no profile-review flags.

## Evidence

Scheelite CaWO4 accounts for the dominant broadened family, including reflections near 18.30, 28.43, 31.21, 33.87, 46.89, and 48.83 degrees 2theta. Monoclinic WO3 is fixed by the resolved 22.77/23.19/23.98 degree triplet and its companions around 32.88-33.78, 46.91-49.52, and 54.88-55.73 degrees. Calcite supplies a coherent weaker family at 29.08, 35.68, 42.88, 47.20, 48.22, 57.15, 64.43, and 65.32 degrees. Its refined scale is decisively nonzero, while explicit CaO and Ca3WO6 additions collapsed to the non-negative scale bound. No coherent residual family remained that justified another crystalline phase.

The result is also reaction-balanced: residual WO3 and CaCO3 correspond to {residual_moles_wo3:.4f} and {residual_moles_caco3:.4f} mol per 100 g of crystalline material (relative mismatch {100*mole_mismatch:.1f}%), consistent with incomplete CaCO3 + WO3 -> CaWO4 + CO2 conversion at the reported 650 C treatment.

## Remaining uncertainty

Phase identities and the three-phase inventory are reliable. The exact light-atom coordinates are less secure: CaWO4 oxygen and WO3 tungsten shifts were capped at the stated physical reference-perturbation limits, and the minor WO3 oxygen substructure was retained from the low-precision reference because free oxygen refinement was unstable. That WO3 reference also retains a short O-O contact (~1.58 A), so its oxygen coordinates should not be used as a definitive local-structure determination. A higher-precision monoclinic WO3 coordinate start was tested but did not reproduce the observed profile under fresh GSAS-II replay. Calcite size and microstrain are strongly correlated, so its coherent-domain/profile values are not interpreted quantitatively. Fractions may therefore have larger systematic uncertainty than the formal errors, especially for calcite, but the calcite phase itself is well supported.

The angular zero refined to the allowed -0.25 degree boundary together with a {histogram.SampleParameters['Shift'][0]:.1f} micrometre specimen displacement; their correlation is an additional source of lattice-parameter systematic uncertainty.
"""
    (ROOT / "report.md").write_text(report)
    print(json.dumps({"rwp_percent": rwp, "fractions": [row["weight_fraction"] for row in phase_rows]}))


if __name__ == "__main__":
    main()
