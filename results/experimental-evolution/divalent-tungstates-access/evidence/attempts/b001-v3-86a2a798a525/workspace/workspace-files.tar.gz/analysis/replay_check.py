#!/usr/bin/env python3
"""Run the frozen read-only GSAS-II replay and report observed-data Rwp."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
WORKER = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("out")
    args = parser.parse_args()
    project = (ROOT / args.project).resolve()
    out = (ROOT / args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    observed = (ROOT / "inputs/pattern.csv").resolve()

    spec = importlib.util.spec_from_file_location("frozen_replay_worker", WORKER)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    old = Path.cwd()
    try:
        os.chdir(out)
        result = module.replay({"project": str(project), "observed": str(observed)})
        Path("replay.json").write_text(json.dumps(result, indent=2) + "\n")
        prediction = np.load("prediction.npz")
        y = prediction["observed"]
        calc = prediction["predicted"]
        weights = 1.0 / np.maximum(y, 1.0)
        rwp = 100 * np.sqrt(np.sum(weights * (y - calc) ** 2) / np.sum(weights * y**2))
        rms_z = np.sqrt(np.mean((y - calc) ** 2 / np.maximum(y, 1.0)))
        print(
            json.dumps(
                {
                    "status": result["status"],
                    "rwp_percent": float(rwp),
                    "rms_standardized_residual": float(rms_z),
                    "fractions": [
                        [phase["name"], phase["weight_fraction"]]
                        for phase in result.get("phases", [])
                    ],
                    "profile_review_flags": result.get("profile_review_flags", []),
                }
            )
        )
    finally:
        os.chdir(old)


if __name__ == "__main__":
    main()
