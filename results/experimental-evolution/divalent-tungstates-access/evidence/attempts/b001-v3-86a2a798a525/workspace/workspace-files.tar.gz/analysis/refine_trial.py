#!/usr/bin/env python3
"""Build and stage a GSAS-II Rietveld trial for selected COD structures.

This is an exploratory driver. It keeps every stage as a separate GPX so that
unphysical or unstable steps can be rejected rather than silently retained.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import shutil

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs(out: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    out.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    # Counts are Poisson sampled. GSAS-II's xye importer expects sigma, not weight.
    sig = np.sqrt(np.maximum(y, 1.0))
    xye = out / "pattern.xye"
    np.savetxt(xye, np.column_stack([x, y, sig]), fmt="%.8f %.8f %.8f")
    inst = out / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst, x, y


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int = 18) -> list[float]:
    # Estimate only the broad baseline. A rolling minimum safely sits below the
    # crystallite-broadened Bragg maxima, and the Chebyshev fit supplies a smooth
    # starting point for GSAS-II.
    smooth = gaussian_filter1d(y, 8)
    baseline = minimum_filter1d(smooth, size=301, mode="nearest")
    baseline = gaussian_filter1d(baseline, 100)
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoef - 1).tolist()


def snapshot(project: G2.G2Project, out: Path, tag: str) -> dict:
    # Keep the active project filename fixed. Changing it at each checkpoint can
    # let the next refinement overwrite the previous checkpoint.
    project.save()
    checkpoint = out / f"{tag}.gpx"
    if Path(project.filename).resolve() != checkpoint.resolve():
        shutil.copy2(project.filename, checkpoint)
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "po": hap["Pref.Ori."],
            }
        )
    result = {
        "tag": tag,
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        "covariance": {
            k: project.data.get("Covariance", {}).get("data", {}).get(k)
            for k in ("Rvals", "varyList", "sig")
        },
    }
    (out / f"{tag}.json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(tag, json.dumps(hist.residuals, default=str), flush=True)
    return result


def refine(project: G2.G2Project, out: Path, tag: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    return snapshot(project, out, tag)


def clear_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Background": {},
            "Instrument Parameters": list(hist.InstrumentParameters),
            "Sample Parameters": [
                k for k, value in hist.SampleParameters.items() if isinstance(value, list)
            ],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            }
        )


def run(args: argparse.Namespace) -> None:
    G2.SetPrintLevel("warn")
    out = ROOT / args.out
    if out.exists():
        shutil.rmtree(out)
    xye, inst, x, y = prepare_inputs(out)

    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    phases = []
    for spec in args.phase:
        name, source = spec.split("=", 1)
        source_path = cod_path(source) if source.isdigit() else (ROOT / source).resolve()
        phases.append(
            project.add_phase(
                str(source_path), phasename=name, fmthint="CIF"
            )
        )
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    # The observed low-angle displacement is around -0.3 degrees. Positive
    # GSAS-II Shift moves Bragg peaks to lower recorded 2theta.
    hist.SampleParameters["Shift"] = [450.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 18,
                "coeffs": initial_background(x, y),
                "refine": False,
            },
        }
    )
    ip = hist.InstrumentParameters
    ip["U"][1] = 10.0
    ip["W"][1] = 8.0
    ip["X"][1] = 1.0
    ip["SH/L"][1] = 0.02
    ip["Polariz."][1] = 0.7
    # Conservative starting widths: let each phase acquire additional sample
    # broadening only after scales and cells are stable.
    for i, phase in enumerate(phases):
        phase.setSampleProfile(hist, "size", "isotropic", 0.15 if i == 0 else 0.8, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0 if i == 0 else 300.0, LGmix=1.0)
        phase.data["Histograms"][hist.name]["Scale"] = [1.0, False]

    # Keep all specimen/instrument parameters in the physically available
    # laboratory domain and prohibit negative phase scales or broadenings.
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }
    for i in range(len(phases)):
        bounds[f"{i}:0:Scale"] = (0.0, 1000.0)
        bounds[f"{i}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{i}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)

    project.save()
    snapshot(project, out, "s00_initial")

    # Stage 1: background + scales.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, out, "s01_scale_background")

    # Stage 2: cells with a fixed physically plausible displacement start.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, out, "s02_cells")

    # Stage 3: resolve angular offset versus specimen displacement over the full
    # angular range; both are whole-pattern effects.
    hist.set_refinements(
        {
            "Instrument Parameters": ["Zero"],
            "Sample Parameters": ["Shift"],
        }
    )
    refine(project, out, "s03_zero_shift")

    # Stage 4: fit phase broadening one phase at a time while the shared
    # instrument remains physical and fixed. This prevents the broad principal
    # phase from being mistaken for an implausibly broad instrument response.
    for i, phase in enumerate(phases):
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        refine(project, out, f"s04_profile_{i}", cycles=12)
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})

    # Stage 5: the sharper phase(s) now constrain the common instrument profile.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, out, "s05_instrument", cycles=12)
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    project.set_Frozen()
    refine(project, out, "s06_joint_profiles", cycles=12)

    # Stage 5: polarization and smooth background are common nuisance terms.
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, out, "s07_polarization", cycles=10)
    project.save(out / "trial.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        help="phase_name=seven_digit_COD_id_or_relative_CIF (repeatable)",
    )
    parser.add_argument("--out", required=True)
    run(parser.parse_args())


if __name__ == "__main__":
    main()
