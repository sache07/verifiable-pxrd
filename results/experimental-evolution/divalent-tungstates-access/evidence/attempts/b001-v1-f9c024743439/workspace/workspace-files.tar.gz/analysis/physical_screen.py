#!/usr/bin/env python3
"""Export and physically screen the currently nominated structures."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "analysis" / "refined_broad.gpx"
OUT = ROOT / "analysis" / "physical_screen_cifs"


def main():
    OUT.mkdir(exist_ok=True)
    project = G2sc.G2Project(str(PROJECT))
    result = {"project": str(PROJECT.relative_to(ROOT)), "phases": {}, "issues": []}
    for phase in project.phases():
        path = OUT / f"{phase.name}.cif"
        phase.export_CIF(str(path))
        atom_records = []
        for atom in phase.atoms():
            atom_records.append({
                "label": atom.label, "element": atom.element,
                "occupancy": float(atom.occupancy), "adp_flag": atom.adp_flag,
                "uiso": float(atom.ADP) if atom.adp_flag == "I" else None,
            })
            if not 0.0 <= atom.occupancy <= 1.0001:
                result["issues"].append(f"{phase.name}/{atom.label}: invalid occupancy")
            if atom.adp_flag == "I" and atom.ADP < 0:
                result["issues"].append(f"{phase.name}/{atom.label}: invalid Uiso")
        result["phases"][phase.name] = {
            "cif": str(path.relative_to(ROOT)),
            "cell": phase.get_cell(), "atoms": atom_records,
        }
    (ROOT / "analysis" / "physical_project.json").write_text(json.dumps(result, indent=2, default=float) + "\n")
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
