#!/usr/bin/env python3
"""Create a stable GSAS-II base project and compare secondary-phase branches.

Run with the GSAS-II Python interpreter. Every trial starts from the same
one-phase project and uses identical nuisance settings. Failed/diverged trials
are retained as unknown rather than treated as rejections.
"""

from __future__ import annotations

import argparse
import copy
import json
import math
import re
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


WORK = Path.cwd()
ANALYSIS = WORK / "analysis"
PATTERN = WORK / "inputs" / "pattern.csv"
DATA = ANALYSIS / "pattern.xye"
INST = ANALYSIS / "lab.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
MAIN_CIF = COD / "7/21/92/7219229.cif"


TRIALS = {
    "WO3_2311041_monoclinic": COD / "2/31/10/2311041.cif",
    "WO3_1528915_monoclinic": COD / "1/52/89/1528915.cif",
    "WO3_2106293_triclinic": COD / "2/10/62/2106293.cif",
    "WO3_2107312_orthorhombic": COD / "2/10/73/2107312.cif",
    "WO3_1010618_monoclinic_HT": COD / "1/01/06/1010618.cif",
    "WO3_1563541_monoclinic_smallcell": COD / "1/56/35/1563541.cif",
    "WO3_1521533_tetragonal": COD / "1/52/15/1521533.cif",
    "WO3_1004057_hexagonal": COD / "1/00/40/1004057.cif",
    "Ca4.26W10O30_4030741": COD / "4/03/07/4030741.cif",
    "Ca3WO6_1563081": COD / "1/56/30/1563081.cif",
    "CaCO3_1547347_calcite": COD / "1/54/73/1547347.cif",
    "CaCO3_5000085_aragonite": COD / "5/00/00/5000085.cif",
    "CaCO3_9013565_vaterite": COD / "9/01/35/9013565.cif",
    "CaCO3_1508970_HP_monoclinic": COD / "1/50/89/1508970.cif",
    "CaO_1563196": COD / "1/56/31/1563196.cif",
    "CaWO4_1546035_HP_monoclinic": COD / "1/54/60/1546035.cif",
}


def prepare_inputs() -> None:
    ANALYSIS.mkdir(exist_ok=True)
    frame = np.genfromtxt(PATTERN, delimiter=",", names=True)
    x = np.asarray(frame[frame.dtype.names[0]], float)
    y = np.asarray(frame[frame.dtype.names[1]], float)
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(DATA, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")
    INST.write_text(
        "#GSAS-II instrument parameter file for supplied Cu K-alpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.70;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.030\n"
    )


def set_positive_scale_limits(project: G2sc.G2Project) -> None:
    project.index_ids()
    for phase in project.phases():
        project.set_Controls("parmMin", 1e-12, variable=f"{phase.id}:0:Scale")


def normalize_candidate_scattering(phase, uiso: float = 0.01) -> None:
    """Repair charge-label parsing and make source ADPs positive/isotropic.

    This changes only nuisance scattering labels/ADPs; coordinates,
    occupancies, multiplicities and topology are preserved.
    """
    cia = phase.data["General"]["AtomPtrs"][3]
    allowed = ("Ca", "W", "O", "C", "H")
    for atom in phase.atoms():
        # Some COD charge labels are imported with a leading sign (for
        # example ``+W`` or ``-O``), after GSAS-II has provisionally mapped
        # them to H. Recover the neutral element from anywhere in the label.
        match = re.search(r"(?i)(Ca|W|O|C|H)", atom.label.strip())
        if match:
            raw = match.group(1).lower()
            element = "Ca" if raw == "ca" else raw.capitalize()
            atom.type = element
        else:
            try:
                if atom.element not in allowed:
                    raise ValueError(atom.element)
            except Exception as exc:
                raise ValueError(f"cannot infer element for atom {atom.label!r}") from exc
        atom.data[cia] = "I"
        atom.data[cia + 1] = float(uiso)
        atom.data[cia + 2 : cia + 8] = [0.0] * 6
    G2sc.SetupGeneral(phase.data, None)


def initialize_background(hist, ncoeff: int = 16) -> None:
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": ncoeff,
                "coeffs": [700.0] + [0.0] * (ncoeff - 1),
                "refine": True,
            }
        }
    )
    # Fit smooth baseline estimates only to initialize the analytic coefficients.
    try:
        hist.calc_autobkg(opt=0, logLam=7.2)
        hist.fit_fixed_points()
    except Exception:
        # The explicit 700-count constant remains a safe positive initialization.
        pass
    hist.set_refinements({"Background": {"refine": True}})


def reset_refinement_flags(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    # GSAS-II returns immediately when Background=True is processed, so clear
    # histogram/sample flags first and clear the background in a separate call.
    hist.clear_refinements(
        {
            "Sample Parameters": [
                key
                for key in (
                    "Scale",
                    "Shift",
                    "Transparency",
                    "SurfRoughA",
                    "SurfRoughB",
                    "Absorption",
                    "DisplaceX",
                    "DisplaceY",
                )
                if key in hist.SampleParameters
            ],
            "Instrument Parameters": [
                key
                for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
                if key in hist.InstrumentParameters
            ],
        }
    )
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    # A parameter that crossed a bound remains frozen in the GPX until it is
    # explicitly removed; carrying that state into a later branch makes the
    # intended refinement silently inactive.
    project.set_Frozen()


def project_summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    out = {
        "gpx": str(Path(project.filename).relative_to(WORK)),
        "histogram": hist.name,
        "residuals": hist.residuals,
        "sample_parameters": {},
        "instrument_parameters": {},
        "phases": {},
    }
    for key, val in hist.SampleParameters.items():
        if isinstance(val, list) and val and isinstance(val[0], (int, float)):
            out["sample_parameters"][key] = float(val[0])
    for key, val in hist.InstrumentParameters.items():
        if isinstance(val, list) and len(val) > 1 and isinstance(val[1], (int, float)):
            out["instrument_parameters"][key] = float(val[1])
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "id": phase.id,
            "ranId": phase.ranId,
            "composition": phase.composition,
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "use": bool(hap["Use"]),
            "mass_fraction": fractions.get(phase.name, [None, None])[0],
            "mass_fraction_esd": fractions.get(phase.name, [None, None])[1],
            "size": copy.deepcopy(hap["Size"]),
            "mustrain": copy.deepcopy(hap["Mustrain"]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        }
    return out


def valid_project(project: G2sc.G2Project) -> tuple[bool, str]:
    hist = project.histogram(0)
    w_r = hist.residuals.get("wR", float("nan"))
    if not np.isfinite(w_r):
        return False, "nonfinite Rwp"
    for phase in project.phases():
        cell = phase.get_cell()
        vals = list(cell.values())
        if not all(np.isfinite(vals)) or min(cell[k] for k in ("length_a", "length_b", "length_c")) <= 0:
            return False, f"invalid cell for {phase.name}"
        scale = phase.HAPvalue("Scale", targethistlist=[hist])
        if not np.isfinite(scale):
            return False, f"nonfinite scale for {phase.name}"
    return True, ""


def refine_checked(project: G2sc.G2Project, label: str) -> dict:
    before = project_summary(project)
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    listing = Path(project.filename).with_suffix(".lst")
    if not listing.exists() or "Final refinement wR" not in listing.read_text(errors="replace"):
        raise RuntimeError(f"{label}: GSAS-II did not complete the refinement")
    ok, message = valid_project(project)
    after = project_summary(project)
    if not ok:
        raise RuntimeError(f"{label}: {message}")
    return {"stage": label, "before": before, "after": after}


def make_base(output: Path) -> dict:
    prepare_inputs()
    if output.exists():
        output.unlink()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(DATA), str(INST), fmthint="xye")
    hist.set_refinements({"Limits": [9.90343322, 100.09455322]})
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"][0] = 600.0
    initialize_background(hist)
    main = project.add_phase(
        str(MAIN_CIF), phasename="CaWO4_scheelite", histograms=[hist], fmthint="CIF"
    )
    normalize_candidate_scattering(main)
    # Broad but physical starting profile for the dominant phase.
    main.setSampleProfile(hist, "size", "isotropic", 0.30, LGmix=0.5)
    main.setSampleProfile(hist, "microstrain", "isotropic", 1200.0, LGmix=0.5)
    main.HAPvalue("Scale", 1.0, targethistlist=[hist])
    set_positive_scale_limits(project)
    project.save()

    stages = []
    reset_refinement_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    main.set_HAP_refinements({"Scale": True})
    stages.append(refine_checked(project, "main_scale_background"))

    reset_refinement_flags(project)
    hist.set_refinements(
        {"Background": {"refine": True}, "Sample Parameters": ["Shift"]}
    )
    main.set_HAP_refinements({"Scale": True})
    main.set_refinements({"Cell": True})
    stages.append(refine_checked(project, "main_shift_cell"))

    reset_refinement_flags(project)
    project.save()
    result = {"status": "tested", "stages": stages, "final": project_summary(project)}
    (ANALYSIS / "base_summary.json").write_text(json.dumps(result, indent=2, default=float))
    return result


def run_trial(base: Path, name: str, cif: Path, outdir: Path) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    branch = outdir / f"{name}.gpx"
    if branch.exists():
        branch.unlink()
    project = G2sc.G2Project(str(base), newgpx=str(branch))
    hist = project.histogram(0)
    reset_refinement_flags(project)
    phase = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
    if project.phase(name) is None or phase.name != name:
        raise RuntimeError(f"candidate {name} was not imported by identity")
    if len(project.phases()) != 2:
        raise RuntimeError(f"candidate {name}: expected exactly two active phases")
    normalize_candidate_scattering(phase)
    for check in project.phases():
        check.HAPvalue("Use", True, targethistlist=[hist])
        if check.HAPvalue("Scale", targethistlist=[hist]) <= 0:
            check.HAPvalue("Scale", 1e-4, targethistlist=[hist])
    main = project.phase("CaWO4_scheelite")
    # Start essentially absent. This lets the common linear scale fit nominate
    # a candidate without a large mispositioned profile trapping the first LM step.
    initial_secondary_scale = max(main.HAPvalue("Scale", targethistlist=[hist]) * 1e-4, 1e-8)
    phase.HAPvalue("Scale", initial_secondary_scale, targethistlist=[hist])
    phase.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=0.5)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0, LGmix=0.5)
    project.save()

    stages = []
    reset_refinement_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    main.set_HAP_refinements({"Scale": True})
    phase.set_HAP_refinements({"Scale": True})
    stages.append(refine_checked(project, "candidate_scale_background"))

    scale_stage = phase.HAPvalue("Scale", targethistlist=[hist])
    if scale_stage <= 1e-10:
        reset_refinement_flags(project)
        project.save()
        return {
            "status": "rejected",
            "reason": "candidate scale collapsed during common scale/background fit",
            "cif": str(cif),
            "stages": stages,
            "final": project_summary(project),
        }

    reset_refinement_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    main.set_HAP_refinements({"Scale": True})
    phase.set_HAP_refinements({"Scale": True})
    phase.set_refinements({"Cell": True})
    stages.append(refine_checked(project, "candidate_cell"))

    reset_refinement_flags(project)
    project.save()

    final = project_summary(project)
    candidate = final["phases"][name]
    main_phase = final["phases"]["CaWO4_scheelite"]
    if candidate["scale"] <= 1e-10 or (candidate["mass_fraction"] is not None and candidate["mass_fraction"] < 1e-4):
        status = "rejected"
        reason = "candidate scale/fraction collapsed"
    else:
        status = "tested"
        reason = "stable positive contribution"
    return {
        "status": status,
        "reason": reason,
        "cif": str(cif),
        "stages": stages,
        "final": final,
    }


def run_trials(base: Path, outdir: Path, only: set[str] | None = None) -> dict:
    results = {}
    for name, cif in TRIALS.items():
        if only and name not in only:
            continue
        try:
            results[name] = run_trial(base, name, cif, outdir)
        except Exception as exc:
            results[name] = {
                "status": "unknown",
                "reason": repr(exc),
                "cif": str(cif),
                "traceback": traceback.format_exc(),
            }
        (ANALYSIS / "trial_results.json").write_text(
            json.dumps(results, indent=2, default=float)
        )
        summary = results[name].get("final", {}).get("residuals", {})
        phase_info = results[name].get("final", {}).get("phases", {}).get(name, {})
        print(
            name,
            results[name]["status"],
            results[name].get("reason", ""),
            "Rwp=", summary.get("wR"),
            "wt=", phase_info.get("mass_fraction"),
        )
    return results


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["base", "trials", "all"])
    parser.add_argument("--base", type=Path, default=ANALYSIS / "base.gpx")
    parser.add_argument("--outdir", type=Path, default=ANALYSIS / "trial_projects")
    parser.add_argument("--only", help="comma-separated trial names")
    args = parser.parse_args()
    if args.mode in ("base", "all"):
        result = make_base(args.base)
        print("base", result["final"]["residuals"])
    if args.mode in ("trials", "all"):
        if not args.base.exists():
            raise FileNotFoundError(args.base)
        only = set(args.only.split(",")) if args.only else None
        run_trials(args.base, args.outdir, only=only)


if __name__ == "__main__":
    main()
