#!/usr/bin/env python3
"""Compare replayable GSAS-II profiles and summarize coherent residual peaks."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CASES = {
    "simple": ROOT / "analysis" / "checkpoints" / "12_WO3_O_coordinates.gpx",
    "broad_CaWO4": ROOT / "analysis" / "checkpoints" / "05_CaWO4_size.gpx",
    "refined_broad": ROOT / "analysis" / "refined_broad.gpx",
}


def profile(path: Path):
    project = G2sc.G2Project(str(path))
    hist = project.histogram(0)
    data = hist.data["data"][1]
    return project, tuple(np.asarray(data[i], float) for i in (0, 1, 3, 4, 5))


def main() -> None:
    result = {}
    for label, path in CASES.items():
        project, (x, obs, calc, bkg, diff) = profile(path)
        sigma = np.sqrt(np.maximum(obs, 1.0))
        z = diff / sigma
        peaks, props = find_peaks(z, prominence=4.0, distance=5)
        order = peaks[np.argsort(props["prominences"])[::-1]]
        troughs, tprops = find_peaks(-z, prominence=4.0, distance=5)
        torder = troughs[np.argsort(tprops["prominences"])[::-1]]
        result[label] = {
            "path": str(path.relative_to(ROOT)),
            "rwp": float(project.histogram(0).get_wR()),
            "rms_residual_noise_units": float(np.sqrt(np.mean(z**2))),
            "positive_residual_peaks": [
                {"two_theta": float(x[i]), "z": float(z[i])} for i in order[:30]
            ],
            "negative_residual_peaks": [
                {"two_theta": float(x[i]), "z": float(z[i])} for i in torder[:30]
            ],
        }
    (ROOT / "analysis" / "profile_diagnostics.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
