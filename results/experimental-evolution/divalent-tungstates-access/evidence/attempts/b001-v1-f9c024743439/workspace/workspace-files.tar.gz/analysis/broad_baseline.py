#!/usr/bin/env python3
"""Rebuild a replayable broad-CaWO4 baseline after coordinate refinement."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import project_summary, reset_refinement_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "checkpoints" / "12_WO3_O_coordinates.gpx"
OUTPUT = ROOT / "analysis" / "broad_baseline.gpx"


def configure(project, geometry=False):
    reset_refinement_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if geometry:
            phase.set_refinements({"Cell": True})
    if geometry:
        hist.set_refinements({"Sample Parameters": ["Shift"]})


def main():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    ca = project.phase("CaWO4_scheelite")
    ca.data["Histograms"][hist.name]["Size"][1][0] = 0.04
    for geometry in (False, True):
        configure(project, geometry=geometry)
        project.set_Controls("cycles", 12)
        project.refine(makeBack=False)
        reset_refinement_flags(project)
        project.save()
        print("geometry" if geometry else "scale/background", project_summary(project))


if __name__ == "__main__":
    main()
