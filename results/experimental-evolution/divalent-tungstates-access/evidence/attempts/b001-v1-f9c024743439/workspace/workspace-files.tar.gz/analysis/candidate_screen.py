#!/usr/bin/env python3
"""Fast whole-pattern screening of chemically plausible COD structures.

This is only a nomination screen. Final acceptance/rejection is done with
common-setting GSAS-II refinements from a stable base project.
"""

from __future__ import annotations

import gzip
import json
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.optimize import differential_evolution


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INDEX = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/venv/"
    "lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz"
)
PATTERN = Path("inputs/pattern.csv")
LAM1 = 1.540598
LAM2 = 1.544426
RATIO = 0.5


def cif_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def stick_pattern(structure: Structure) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return d spacings and relative integrated intensities for both wavelengths."""
    pieces = []
    for wave, ratio in ((LAM1, 1.0), (LAM2, RATIO)):
        patt = XRDCalculator(wavelength=wave).get_pattern(
            structure, two_theta_range=(9.5, 101.0), scaled=False
        )
        theta = np.radians(np.asarray(patt.x) / 2.0)
        d = wave / (2.0 * np.sin(theta))
        pieces.append((d, np.asarray(patt.y, float) * ratio, np.full(len(d), wave)))
    return tuple(np.concatenate([p[i] for p in pieces]) for i in range(3))


def profile_from_sticks(
    x: np.ndarray,
    d: np.ndarray,
    intensity: np.ndarray,
    waves: np.ndarray,
    strain: float,
    zero: float,
    displacement_shift: float,
    fwhm: float,
) -> np.ndarray:
    arg = waves / (2.0 * d * (1.0 + strain))
    valid = (arg > 0) & (arg < 1)
    pos = np.degrees(2.0 * np.arcsin(arg[valid]))
    pos += zero + displacement_shift * np.cos(np.radians(pos / 2.0))
    inten = intensity[valid]
    grid = np.zeros_like(x)
    u = (pos - x[0]) / (x[1] - x[0])
    i0 = np.floor(u).astype(int)
    frac = u - i0
    good = (i0 >= 0) & (i0 < len(x) - 1)
    np.add.at(grid, i0[good], inten[good] * (1.0 - frac[good]))
    np.add.at(grid, i0[good] + 1, inten[good] * frac[good])
    sigma_bins = fwhm / (2.354820045 * (x[1] - x[0]))
    return gaussian_filter1d(grid, sigma_bins, mode="constant", truncate=5.0)


def screen_one(x: np.ndarray, signal: np.ndarray, structure: Structure) -> dict:
    d, intensity, waves = stick_pattern(structure)
    mask = (x >= 17.0) & (x <= 99.8)
    target = signal[mask]
    denom0 = float(np.dot(target, target))

    def objective(pars: np.ndarray) -> float:
        p = profile_from_sticks(x, d, intensity, waves, *pars)[mask]
        pp = float(np.dot(p, p))
        if pp <= 0:
            return 1.0
        amp = max(0.0, float(np.dot(target, p)) / pp)
        resid = target - amp * p
        return float(np.dot(resid, resid) / denom0)

    result = differential_evolution(
        objective,
        bounds=[(-0.012, 0.012), (-0.20, 0.20), (-0.65, 0.65), (0.055, 0.55)],
        seed=20261108,
        popsize=8,
        maxiter=28,
        polish=True,
        workers=1,
        updating="immediate",
        tol=2e-4,
    )
    return {
        "screen_explained_fraction": 1.0 - float(result.fun),
        "isotropic_cell_strain": float(result.x[0]),
        "zero_deg": float(result.x[1]),
        "displacement_shift_deg": float(result.x[2]),
        "fwhm_deg": float(result.x[3]),
    }


def fitted_profile(x: np.ndarray, signal: np.ndarray, structure: Structure, result: dict) -> np.ndarray:
    d, intensity, waves = stick_pattern(structure)
    p = profile_from_sticks(
        x,
        d,
        intensity,
        waves,
        result["isotropic_cell_strain"],
        result["zero_deg"],
        result["displacement_shift_deg"],
        result["fwhm_deg"],
    )
    mask = (x >= 17.0) & (x <= 99.8)
    amp = max(0.0, float(np.dot(signal[mask], p[mask])) / float(np.dot(p[mask], p[mask])))
    return amp * p


def main() -> None:
    warnings.filterwarnings("ignore")
    raw = pd.read_csv(PATTERN)
    x = raw.iloc[:, 0].to_numpy(float)
    y = raw.iloc[:, 1].to_numpy(float)
    baseline = percentile_filter(y, percentile=10, size=301, mode="nearest")
    signal = np.clip(y - baseline, 0.0, None)

    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)

    requested = {
        "Ca-O-W": {"CaWO4", "Ca3WO6", "Ca4.26W10O30"},
        "O-W": {"WO3"},
        "C-Ca-O": {"CaCO3"},
        "Ca-O": {"CaO"},
        "Ca-H-O": {"Ca(OH)2"},
    }

    primary_path = cif_path("7219229")
    primary_structure = Structure.from_file(primary_path, primitive=False)
    primary_result = screen_one(x, signal, primary_structure)
    residual_signal = np.clip(signal - fitted_profile(x, signal, primary_structure, primary_result), 0.0, None)
    rows = []
    for system, formulas in requested.items():
        for formula, cod_id, indexed_sg, r_factor in index.get(system, []):
            if formula not in formulas:
                continue
            path = cif_path(cod_id)
            row = {
                "system": system,
                "formula": formula,
                "cod_id": cod_id,
                "indexed_space_group_number": indexed_sg,
                "r_factor": r_factor,
                "cif_path": str(path),
            }
            try:
                structure = Structure.from_file(path, primitive=False)
                symbol, number = structure.get_space_group_info(symprec=0.05)
                row.update(
                    {
                        "parsed_formula": structure.composition.reduced_formula,
                        "parsed_space_group": symbol,
                        "parsed_space_group_number": number,
                        "a": structure.lattice.a,
                        "b": structure.lattice.b,
                        "c": structure.lattice.c,
                        "alpha": structure.lattice.alpha,
                        "beta": structure.lattice.beta,
                        "gamma": structure.lattice.gamma,
                        "volume": structure.volume,
                        "n_sites": len(structure),
                    }
                )
                row.update(screen_one(x, signal, structure))
                residual_result = screen_one(x, residual_signal, structure)
                row["residual_screen_explained_fraction"] = residual_result[
                    "screen_explained_fraction"
                ]
                row["residual_isotropic_cell_strain"] = residual_result[
                    "isotropic_cell_strain"
                ]
                row["residual_zero_deg"] = residual_result["zero_deg"]
                row["residual_displacement_shift_deg"] = residual_result[
                    "displacement_shift_deg"
                ]
                row["residual_fwhm_deg"] = residual_result["fwhm_deg"]
                row["status"] = "screened"
                row["error"] = ""
            except Exception as exc:  # invalid source remains unknown, never rejected
                row["status"] = "unknown"
                row["error"] = repr(exc)
            rows.append(row)

    result = pd.DataFrame(rows)
    result = result.sort_values(
        ["formula", "screen_explained_fraction"], ascending=[True, False], na_position="last"
    )
    Path("analysis").mkdir(exist_ok=True)
    result.to_csv("analysis/candidate_screen.csv", index=False)
    cols = [
        "formula",
        "cod_id",
        "indexed_space_group_number",
        "parsed_space_group",
        "screen_explained_fraction",
        "isotropic_cell_strain",
        "zero_deg",
        "displacement_shift_deg",
        "fwhm_deg",
        "residual_screen_explained_fraction",
        "residual_isotropic_cell_strain",
        "residual_zero_deg",
        "residual_displacement_shift_deg",
        "residual_fwhm_deg",
        "status",
        "error",
    ]
    print(result.reindex(columns=cols).to_string(index=False))


if __name__ == "__main__":
    main()
