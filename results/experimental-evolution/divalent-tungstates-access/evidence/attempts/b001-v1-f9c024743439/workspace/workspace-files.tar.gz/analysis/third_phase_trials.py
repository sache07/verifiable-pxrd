#!/usr/bin/env python3
"""Test chemically plausible third phases against the stable two-phase model."""

from __future__ import annotations

import json
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from gsas_trials import normalize_candidate_scattering, project_summary, reset_refinement_flags


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "refined_broad.gpx"
OUT = ANALYSIS / "third_phase_trials"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "CaCO3_calcite_1547371": COD / "1/54/73/1547371.cif",
    "CaCO3_aragonite_5000085": COD / "5/00/00/5000085.cif",
    "CaCO3_vaterite_9013565": COD / "9/01/35/9013565.cif",
    "CaO_1563196": COD / "1/56/31/1563196.cif",
    "Ca3WO6_1563081": COD / "1/56/30/1563081.cif",
    "Ca4.26W10O30_4030741": COD / "4/03/07/4030741.cif",
    "CaWO4_HP_1546035": COD / "1/54/60/1546035.cif",
}


def common(project, candidate, *, cells=False, size=False):
    reset_refinement_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    if cells:
        candidate.set_refinements({"Cell": True})
    if size:
        candidate.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})


def candidate_fraction(project, name):
    summary = project_summary(project)
    return float(summary["phases"][name]["mass_fraction"]), summary


def complete(project):
    listing = Path(project.filename).with_suffix(".lst")
    return listing.exists() and "Final refinement wR" in listing.read_text(errors="replace")


def main():
    OUT.mkdir(exist_ok=True)
    baseline = float(project_summary(G2sc.G2Project(str(SOURCE)))["residuals"]["wR"])
    rows = []
    for name, cif in CANDIDATES.items():
        row = {"name": name, "cif": str(cif), "status": "pending", "baseline_rwp": baseline}
        try:
            branch = OUT / f"{name}.gpx"
            project = G2sc.G2Project(str(SOURCE), newgpx=str(branch))
            hist = project.histogram(0)
            candidate = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
            normalize_candidate_scattering(candidate)
            hap = candidate.data["Histograms"][hist.name]
            hap["Use"] = True
            hap["Scale"] = [0.10, False]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 0.30
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 1000.0
            project.set_Controls("parmMin", 1e-10, variable=f"{candidate.id}:0:Scale")
            project.set_Controls("parmMax", 1e5, variable=f"{candidate.id}:0:Scale")
            project.set_Controls("parmMin", 0.04, variable=f"{candidate.id}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{candidate.id}:0:Size;i")
            start_cell = candidate.get_cell()
            stages = []

            common(project, candidate)
            project.set_Controls("cycles", 10)
            project.refine(makeBack=False)
            if not complete(project):
                raise RuntimeError("scale/background refinement did not complete")
            fraction, summary = candidate_fraction(project, name)
            stages.append({"stage": "scale_background", "fraction": fraction, "summary": summary})
            if fraction < 0.003:
                reset_refinement_flags(project)
                project.save()
                row.update(status="tested", decision="rejected_scale_collapse", stages=stages,
                           final_rwp=float(summary["residuals"]["wR"]), fraction=fraction)
                rows.append(row)
                print(name, row["decision"], fraction, row["final_rwp"])
                continue

            common(project, candidate, cells=True)
            project.set_Controls("cycles", 10)
            project.refine(makeBack=False)
            if not complete(project) or project.get_Frozen():
                raise RuntimeError("cell refinement failed or froze at a limit")
            end_cell = candidate.get_cell()
            ratio = end_cell["volume"] / start_cell["volume"]
            if not np.isfinite(ratio) or not 0.90 <= ratio <= 1.10:
                raise RuntimeError(f"implausible cell-volume ratio {ratio}")
            fraction, summary = candidate_fraction(project, name)
            stages.append({"stage": "candidate_cell", "fraction": fraction, "summary": summary})

            common(project, candidate, size=True)
            project.set_Controls("cycles", 10)
            project.refine(makeBack=False)
            if not complete(project) or project.get_Frozen():
                raise RuntimeError("size refinement failed or froze at a limit")
            fraction, summary = candidate_fraction(project, name)
            stages.append({"stage": "candidate_size", "fraction": fraction, "summary": summary})
            reset_refinement_flags(project)
            project.save()
            replay_path = OUT / f"{name}_replay.gpx"
            replay = G2sc.G2Project(str(branch), newgpx=str(replay_path))
            reset_refinement_flags(replay)
            replay.set_Controls("cycles", 0)
            replay.refine(makeBack=False)
            replay_rwp = float(project_summary(replay)["residuals"]["wR"])
            stored = float(summary["residuals"]["wR"])
            if abs(stored - replay_rwp) > 0.02:
                raise RuntimeError(f"stored/replay mismatch {stored:.5f}/{replay_rwp:.5f}")
            gain = baseline - replay_rwp
            decision = "supported" if fraction >= 0.005 and gain >= 0.02 else "rejected"
            row.update(status="tested", decision=decision, stages=stages, fraction=fraction,
                       final_rwp=replay_rwp, gain=gain, start_cell=start_cell, final_cell=end_cell)
        except Exception as exc:
            row.update(status="unknown", reason=repr(exc), traceback=traceback.format_exc())
        print(name, row["status"], row.get("decision"), row.get("fraction"), row.get("final_rwp"), row.get("reason", ""))
        rows.append(row)
    (ANALYSIS / "third_phase_trials.json").write_text(json.dumps(rows, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
