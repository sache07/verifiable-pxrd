#!/usr/bin/env python3
"""Staged, replay-checked refinement of the nominated two-phase model."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from gsas_trials import project_summary, reset_refinement_flags, valid_project


WORK = Path.cwd()
ANALYSIS = WORK / "analysis"
SOURCE = ANALYSIS / "trial_projects" / "WO3_2311041_monoclinic.gpx"
PROJECT = ANALYSIS / "final_work.gpx"
CHECKPOINTS = ANALYSIS / "checkpoints"
HISTORY = ANALYSIS / "final_history.json"


def set_bound(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def apply_global_bounds(project) -> None:
    hist = project.histogram(0)
    bounds = {
        ":0:Shift": (-800.0, 800.0),
        ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }
    for variable, (low, high) in bounds.items():
        set_bound(project, variable, low, high)
    for phase in project.phases():
        set_bound(project, f"{phase.id}:0:Scale", 1e-10, 1e5)
        set_bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase.id}:0:Mustrain;a", 0.0, 8000.0)


def common_flags(project, *, cells=False, shift=False, zero=False, instrument=()) -> None:
    reset_refinement_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    sample = []
    if shift:
        sample.append("Shift")
    if sample:
        hist.set_refinements({"Sample Parameters": sample})
    if zero or instrument:
        values = list(instrument)
        if zero:
            values.append("Zero")
        hist.set_refinements({"Instrument Parameters": values})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if cells:
            phase.set_refinements({"Cell": True})


def profile_values(project) -> dict:
    hist = project.histogram(0)
    out = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out[phase.name] = {
            "size_type": hap["Size"][0],
            "size": [float(v) for v in hap["Size"][1]],
            "mustrain_type": hap["Mustrain"][0],
            "mustrain": [float(v) for v in hap["Mustrain"][1]],
            "mustrain_axis": list(hap["Mustrain"][3]),
            "preferred_orientation": [
                hap["Pref.Ori."][0],
                float(hap["Pref.Ori."][1]),
                bool(hap["Pref.Ori."][2]),
                list(hap["Pref.Ori."][3]),
            ],
        }
    return out


def physical_screen(project) -> tuple[bool, list[str]]:
    issues = []
    ok, message = valid_project(project)
    if not ok:
        issues.append(message)
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    for key, low, high in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
    ):
        value = float(inst[key][1])
        if not np.isfinite(value) or value < low - 1e-8 or value > high + 1e-8:
            issues.append(f"instrument {key}={value} outside [{low},{high}]")
        elif abs(value - low) < 1e-7 or abs(value - high) < 1e-7:
            issues.append(f"instrument {key}={value} is boundary-hitting")
    shift = float(hist.SampleParameters["Shift"][0])
    zero = float(inst["Zero"][1])
    if abs(abs(shift) - 800.0) < 1e-6:
        issues.append(f"sample Shift={shift} is boundary-hitting")
    if abs(abs(zero) - 0.25) < 1e-7:
        issues.append(f"instrument Zero={zero} is boundary-hitting")
    arrays = hist.data["data"][1]
    for idx, name in ((3, "calculated profile"), (4, "background")):
        arr = np.asarray(arrays[idx], float)
        if not np.all(np.isfinite(arr)):
            issues.append(f"nonfinite {name}")
        if np.min(arr) < -1e-6:
            issues.append(f"negative {name}: min={np.min(arr):.6g}")
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        size = float(hap["Size"][1][0])
        strain = float(hap["Mustrain"][1][0])
        if not 0.04 - 1e-7 <= size <= 1.5 + 1e-7:
            issues.append(f"{phase.name} size {size} outside physical range")
        elif abs(size - 0.04) < 1e-7 or abs(size - 1.5) < 1e-7:
            issues.append(f"{phase.name} size {size} is boundary-hitting")
        if not 0.0 <= strain <= 8000.0 + 1e-6:
            issues.append(f"{phase.name} microstrain {strain} outside range")
        elif abs(strain - 8000.0) < 1e-5:
            issues.append(f"{phase.name} microstrain {strain} is boundary-hitting")
        if phase.HAPvalue("Scale", targethistlist=[hist]) <= 0:
            issues.append(f"{phase.name} has nonpositive scale")
        for atom in phase.atoms():
            if not 0.0 <= atom.occupancy <= 1.0001:
                issues.append(f"{phase.name}/{atom.label} occupancy {atom.occupancy}")
            if atom.adp_flag == "I" and (not np.isfinite(atom.ADP) or atom.ADP < 0):
                issues.append(f"{phase.name}/{atom.label} Uiso {atom.ADP}")
    return not issues, issues


def replay_rwp(source: Path, tag: str) -> tuple[float, dict]:
    replay = ANALYSIS / f"replay_{tag}.gpx"
    if replay.exists():
        replay.unlink()
    project = G2sc.G2Project(str(source), newgpx=str(replay))
    reset_refinement_flags(project)
    project.set_Controls("cycles", 0)
    project.save()
    project.refine(makeBack=False)
    summary = project_summary(project)
    if not np.isfinite(float(summary["residuals"].get("wR", np.nan))):
        raise RuntimeError("replay calculation did not produce finite Rwp")
    return float(summary["residuals"]["wR"]), summary


def run_stage(project: G2sc.G2Project, index: int, name: str, configure) -> tuple[G2sc.G2Project, dict]:
    before_file = CHECKPOINTS / f"{index:02d}_{name}_before.gpx"
    project.save(str(PROJECT))
    shutil.copy2(PROJECT, before_file)
    before = project_summary(project)
    entry = {"index": index, "name": name, "before": before, "before_profiles": profile_values(project)}
    try:
        configure(project)
        apply_global_bounds(project)
        project.set_Controls("cycles", 12)
        project.refine(makeBack=False)
        listing = Path(project.filename).with_suffix(".lst")
        if not listing.exists() or "Final refinement wR" not in listing.read_text(errors="replace"):
            raise RuntimeError("GSAS-II refinement did not complete")
        reset_refinement_flags(project)
        stage_file = CHECKPOINTS / f"{index:02d}_{name}.gpx"
        project.save(str(PROJECT))
        shutil.copy2(PROJECT, stage_file)
        after = project_summary(project)
        ok, issues = physical_screen(project)
        replay, replay_summary = replay_rwp(stage_file, f"{index:02d}_{name}")
        stored = float(after["residuals"]["wR"])
        if abs(replay - stored) > 0.02:
            issues.append(f"stored/replay Rwp mismatch {stored:.5f}/{replay:.5f}")
            ok = False
        if replay > float(before["residuals"]["wR"]) + 0.02:
            issues.append("Rwp worsened")
            ok = False
        entry.update(
            status="accepted" if ok else "rejected",
            after=after,
            after_profiles=profile_values(project),
            replay_rwp=replay,
            issues=issues,
            checkpoint=str(stage_file.relative_to(WORK)),
        )
        if ok:
            return project, entry
        rollback = G2sc.G2Project(str(before_file), newgpx=str(PROJECT))
        rollback.save()
        return rollback, entry
    except Exception as exc:
        entry.update(status="unknown", reason=repr(exc), traceback=traceback.format_exc())
        rollback = G2sc.G2Project(str(before_file), newgpx=str(PROJECT))
        rollback.save()
        return rollback, entry


def set_phase_profile(project, phase_name: str, kind: str) -> None:
    phase = project.phase(phase_name)
    if kind == "size":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif kind == "mustrain":
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    else:
        raise ValueError(kind)


def coordinate_bounds(project, phase_name: str, elements: set[str], delta: float) -> None:
    phase = project.phase(phase_name)
    for idx, atom in enumerate(phase.atoms()):
        if atom.element not in elements:
            continue
        atom.refinement_flags = "X"
        for axis, value in zip("xyz", atom.coordinates):
            set_bound(project, f"{phase.id}::A{axis}:{idx}", value - delta, value + delta)


def main() -> None:
    if not SOURCE.exists():
        raise FileNotFoundError(SOURCE)
    CHECKPOINTS.mkdir(exist_ok=True)
    if PROJECT.exists():
        PROJECT.unlink()
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    required = {"CaWO4_scheelite", "WO3_2311041_monoclinic"}
    if {p.name for p in project.phases()} != required:
        raise RuntimeError("unexpected phase inventory")
    apply_global_bounds(project)
    reset_refinement_flags(project)
    project.save()

    stages = []
    recipes = [
        (
            "geometry_cells",
            lambda p: common_flags(p, cells=True, shift=True),
        ),
        (
            "geometry_zero_cells",
            lambda p: common_flags(p, cells=True, shift=True, zero=True),
        ),
        (
            "instrument_W_X",
            lambda p: common_flags(p, instrument=("W", "X")),
        ),
        (
            "instrument_U_W_X_SHL",
            lambda p: common_flags(
                p, instrument=("U", "W", "X", "SH/L")
            ),
        ),
        (
            "CaWO4_size",
            lambda p: (common_flags(p), set_phase_profile(p, "CaWO4_scheelite", "size")),
        ),
        (
            "CaWO4_mustrain",
            lambda p: (common_flags(p), set_phase_profile(p, "CaWO4_scheelite", "mustrain")),
        ),
        (
            "WO3_size",
            lambda p: (common_flags(p), set_phase_profile(p, "WO3_2311041_monoclinic", "size")),
        ),
        (
            "WO3_mustrain",
            lambda p: (common_flags(p), set_phase_profile(p, "WO3_2311041_monoclinic", "mustrain")),
        ),
        (
            "polarization",
            lambda p: common_flags(p, instrument=("Polariz.",)),
        ),
        (
            "CaWO4_O_coordinates",
            lambda p: (common_flags(p), coordinate_bounds(p, "CaWO4_scheelite", {"O"}, 0.025)),
        ),
        (
            "WO3_W_coordinates",
            lambda p: (common_flags(p), coordinate_bounds(p, "WO3_2311041_monoclinic", {"W"}, 0.020)),
        ),
        (
            "WO3_O_coordinates",
            lambda p: (common_flags(p), coordinate_bounds(p, "WO3_2311041_monoclinic", {"O"}, 0.030)),
        ),
        (
            "joint_nuisance",
            lambda p: (
                common_flags(p, cells=True, shift=True, zero=True, instrument=("U", "W", "X", "SH/L", "Polariz.")),
                set_phase_profile(p, "CaWO4_scheelite", "size"),
                set_phase_profile(p, "CaWO4_scheelite", "mustrain"),
                set_phase_profile(p, "WO3_2311041_monoclinic", "size"),
                set_phase_profile(p, "WO3_2311041_monoclinic", "mustrain"),
            ),
        ),
    ]
    for index, (name, configure) in enumerate(recipes, start=1):
        project, result = run_stage(project, index, name, configure)
        stages.append(result)
        HISTORY.write_text(json.dumps(stages, indent=2, default=float))
        print(name, result["status"], "Rwp", result.get("replay_rwp"), result.get("issues", result.get("reason", "")))

    reset_refinement_flags(project)
    project.save(str(PROJECT))
    print(json.dumps(project_summary(project), indent=2, default=float))


if __name__ == "__main__":
    main()
