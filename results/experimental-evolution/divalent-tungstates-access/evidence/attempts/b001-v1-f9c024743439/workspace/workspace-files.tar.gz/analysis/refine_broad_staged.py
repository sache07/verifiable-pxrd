#!/usr/bin/env python3
"""Replay-checked staged refinement from the broad-CaWO4 two-phase model."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from gsas_trials import project_summary, reset_refinement_flags, valid_project


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "broad_trials" / "WO3_size.gpx"
PROJECT = ANALYSIS / "refined_broad.gpx"
CHECKPOINTS = ANALYSIS / "broad_checkpoints"
HISTORY = ANALYSIS / "refined_broad_history.json"


def set_bound(project, name, low, high):
    project.set_Controls("parmMin", low, variable=name)
    project.set_Controls("parmMax", high, variable=name)


def bounds(project):
    for name, limits in {
        ":0:Shift": (-800.0, 800.0), ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0), ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }.items():
        set_bound(project, name, *limits)
    for phase in project.phases():
        set_bound(project, f"{phase.id}:0:Scale", 1e-10, 1e5)
        set_bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase.id}:0:Mustrain;a", 0.0, 8000.0)


def common(project, *, cells=False, shift=False, zero=False, instrument=()):
    reset_refinement_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    if shift:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    names = list(instrument)
    if zero:
        names.append("Zero")
    if names:
        hist.set_refinements({"Instrument Parameters": names})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if cells:
            phase.set_refinements({"Cell": True})


def phase_term(project, phase_name, term):
    phase = project.phase(phase_name)
    if term == "size":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif term == "strain":
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    else:
        raise KeyError(term)


def coordinate_term(project, phase_name, elements, displacement_A):
    phase = project.phase(phase_name)
    cell = phase.get_cell()
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    for index, atom in enumerate(phase.atoms()):
        if atom.element not in elements:
            continue
        atom.refinement_flags = "X"
        for axis, value, length in zip("xyz", atom.coordinates, lengths):
            delta = displacement_A / length
            set_bound(project, f"{phase.id}::A{axis}:{index}", value - delta, value + delta)


def snapshot(project):
    summary = project_summary(project)
    hist = project.histogram(0)
    summary["frozen"] = project.get_Frozen()
    summary["profiles"] = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        summary["profiles"][phase.name] = {
            "size_type": hap["Size"][0], "size": list(map(float, hap["Size"][1])),
            "strain_type": hap["Mustrain"][0], "strain": list(map(float, hap["Mustrain"][1])),
            "strain_axis": list(hap["Mustrain"][3]),
            "md": [hap["Pref.Ori."][0], float(hap["Pref.Ori."][1]), list(hap["Pref.Ori."][3])],
        }
    return summary


def screen(project, frozen):
    issues = []
    ok, message = valid_project(project)
    if not ok:
        issues.append(message)
    if frozen:
        issues.append("parameters frozen at limits: " + ", ".join(frozen))
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    for i, name in ((3, "calculated"), (4, "background")):
        arr = np.asarray(arrays[i], float)
        if not np.all(np.isfinite(arr)) or np.min(arr) < -1e-6:
            issues.append(f"invalid {name} profile")
    for phase in project.phases():
        if phase.HAPvalue("Scale", targethistlist=[hist]) <= 0:
            issues.append(f"{phase.name} nonpositive scale")
        hap = phase.data["Histograms"][hist.name]
        size = float(hap["Size"][1][0])
        strain = float(hap["Mustrain"][1][0])
        if not 0.04 - 1e-8 <= size <= 1.5 + 1e-8:
            issues.append(f"{phase.name} size outside physical range: {size}")
        if not 0.0 <= strain <= 8000.0 + 1e-8:
            issues.append(f"{phase.name} strain outside physical range: {strain}")
    return issues


def replay(path, tag):
    target = ANALYSIS / f"broad_replay_{tag}.gpx"
    project = G2sc.G2Project(str(path), newgpx=str(target))
    reset_refinement_flags(project)
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    return float(project_summary(project)["residuals"]["wR"])


def stage(project, index, name, configure, min_gain=0.002):
    before_path = CHECKPOINTS / f"{index:02d}_{name}_before.gpx"
    project.save(str(PROJECT))
    shutil.copy2(PROJECT, before_path)
    before = snapshot(project)
    entry = {"index": index, "name": name, "before": before}
    try:
        configure(project)
        bounds(project)
        project.set_Controls("cycles", 10)
        project.refine(makeBack=False)
        frozen = project.get_Frozen()
        after_active = snapshot(project)
        issues = screen(project, frozen)
        reset_refinement_flags(project)
        accepted_path = CHECKPOINTS / f"{index:02d}_{name}.gpx"
        project.save(str(PROJECT))
        shutil.copy2(PROJECT, accepted_path)
        after = snapshot(project)
        replay_rwp = replay(accepted_path, f"{index:02d}_{name}")
        stored = float(after["residuals"]["wR"])
        gain = float(before["residuals"]["wR"]) - replay_rwp
        if abs(stored - replay_rwp) > 0.02:
            issues.append(f"stored/replay mismatch {stored:.5f}/{replay_rwp:.5f}")
        if gain < min_gain:
            issues.append(f"unsupported gain {gain:.5f} < {min_gain:.5f}")
        entry.update(after_active=after_active, after=after, replay_rwp=replay_rwp,
                     gain=gain, issues=issues, checkpoint=str(accepted_path.relative_to(ROOT)))
        if not issues:
            entry["status"] = "accepted"
            return project, entry
        entry["status"] = "rejected"
    except Exception as exc:
        entry.update(status="unknown", reason=repr(exc), traceback=traceback.format_exc())
    rollback = G2sc.G2Project(str(before_path), newgpx=str(PROJECT))
    reset_refinement_flags(rollback)
    rollback.save()
    return rollback, entry


def main():
    CHECKPOINTS.mkdir(exist_ok=True)
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    reset_refinement_flags(project)
    bounds(project)
    project.save()
    recipes = [
        ("shift_cells", lambda p: common(p, cells=True, shift=True), 0.002),
        ("zero_cells", lambda p: common(p, cells=True, zero=True), 0.002),
        ("instrument_X", lambda p: common(p, instrument=("X",)), 0.003),
        ("instrument_W", lambda p: common(p, instrument=("W",)), 0.003),
        ("instrument_U", lambda p: common(p, instrument=("U",)), 0.003),
        ("instrument_SHL", lambda p: common(p, instrument=("SH/L",)), 0.003),
        ("Ca_strain", lambda p: (common(p), phase_term(p, "CaWO4_scheelite", "strain")), 0.003),
        ("WO3_strain", lambda p: (common(p), phase_term(p, "WO3_2311041_monoclinic", "strain")), 0.003),
        ("WO3_size", lambda p: (common(p), phase_term(p, "WO3_2311041_monoclinic", "size")), 0.003),
        ("polarization", lambda p: common(p, instrument=("Polariz.",)), 0.003),
        ("shift_cells_2", lambda p: common(p, cells=True, shift=True), 0.002),
        ("zero_cells_2", lambda p: common(p, cells=True, zero=True), 0.002),
        ("Ca_O_coordinates", lambda p: (common(p), coordinate_term(p, "CaWO4_scheelite", {"O"}, 0.055)), 0.003),
        ("WO3_W_coordinates", lambda p: (common(p), coordinate_term(p, "WO3_2311041_monoclinic", {"W"}, 0.045)), 0.003),
        ("WO3_O_coordinates", lambda p: (common(p), coordinate_term(p, "WO3_2311041_monoclinic", {"O"}, 0.060)), 0.003),
    ]
    history = []
    for index, (name, configure, gain) in enumerate(recipes, 1):
        project, result = stage(project, index, name, configure, gain)
        history.append(result)
        HISTORY.write_text(json.dumps(history, indent=2, default=float) + "\n")
        print(name, result["status"], result.get("replay_rwp"), result.get("issues", result.get("reason")))
    reset_refinement_flags(project)
    project.save(str(PROJECT))
    print(json.dumps(snapshot(project), indent=2, default=float))


if __name__ == "__main__":
    main()
