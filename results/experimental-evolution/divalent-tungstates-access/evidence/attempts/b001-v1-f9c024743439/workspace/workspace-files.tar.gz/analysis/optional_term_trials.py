#!/usr/bin/env python3
"""One-at-a-time anisotropy, texture and roughness trials."""

from __future__ import annotations

import json
import traceback
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import project_summary, reset_refinement_flags


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "refined_broad.gpx"
OUT = ANALYSIS / "optional_trials"
PHASES = ("CaWO4_scheelite", "WO3_2311041_monoclinic")
AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0))
MD_AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1))


def common(project):
    reset_refinement_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def configure_strain(project, phase_name, axis):
    phase = project.phase(phase_name)
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][1][1] = float(hap["Mustrain"][1][0])
    phase.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": list(axis), "refine": "axial"}
    })
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Mustrain;a")
    project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:0:Mustrain;a")


def configure_md(project, phase_name, axis):
    phase = project.phase(phase_name)
    hist = project.histogram(0)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[1], po[3] = "MD", 1.0, list(axis)
    phase.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:0:MD")


def configure_roughness(project):
    hist = project.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [0.20, False]
    hist.SampleParameters["SurfRoughB"] = [0.10, False]
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for key, low, high in (("SurfRoughA", 0.05, 0.60), ("SurfRoughB", 0.02, 0.50)):
        project.set_Controls("parmMin", low, variable=f":0:{key}")
        project.set_Controls("parmMax", high, variable=f":0:{key}")


def values(project):
    hist = project.histogram(0)
    result = {
        "sample": {
            "SurfRoughA": float(hist.SampleParameters["SurfRoughA"][0]),
            "SurfRoughB": float(hist.SampleParameters["SurfRoughB"][0]),
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "strain_type": hap["Mustrain"][0],
            "strain": list(map(float, hap["Mustrain"][1])),
            "strain_axis": list(hap["Mustrain"][3]),
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(hap["Pref.Ori."][3]),
        }
    return result


def main():
    OUT.mkdir(exist_ok=True)
    trials = []
    for phase in PHASES:
        short = "Ca" if phase.startswith("Ca") else "WO3"
        for axis in AXES:
            trials.append((f"{short}_uniaxial_{axis[0]}{axis[1]}{axis[2]}",
                           lambda p, ph=phase, ax=axis: configure_strain(p, ph, ax)))
        for axis in MD_AXES:
            trials.append((f"{short}_MD_{axis[0]}{axis[1]}{axis[2]}",
                           lambda p, ph=phase, ax=axis: configure_md(p, ph, ax)))
    trials.append(("surface_roughness", configure_roughness))
    baseline = float(project_summary(G2sc.G2Project(str(SOURCE)))["residuals"]["wR"])
    results = []
    for name, configure in trials:
        branch = OUT / f"{name}.gpx"
        row = {"name": name, "status": "pending", "baseline_rwp": baseline}
        try:
            project = G2sc.G2Project(str(SOURCE), newgpx=str(branch))
            common(project)
            configure(project)
            project.set_Controls("cycles", 10)
            project.refine(makeBack=False)
            listing = Path(project.filename).with_suffix(".lst")
            if (not listing.exists() or
                    "Final refinement wR" not in listing.read_text(errors="replace")):
                raise RuntimeError("GSAS-II refinement did not complete")
            frozen = project.get_Frozen()
            if frozen:
                raise RuntimeError("frozen at parameter limits: " + ", ".join(frozen))
            active_values = values(project)
            reset_refinement_flags(project)
            project.save()
            replay_path = OUT / f"{name}_replay.gpx"
            replay = G2sc.G2Project(str(branch), newgpx=str(replay_path))
            reset_refinement_flags(replay)
            replay.set_Controls("cycles", 0)
            replay.refine(makeBack=False)
            stored = float(project_summary(project)["residuals"]["wR"])
            replay_rwp = float(project_summary(replay)["residuals"]["wR"])
            if abs(stored - replay_rwp) > 0.02:
                raise RuntimeError(f"stored/replay mismatch {stored:.5f}/{replay_rwp:.5f}")
            row.update(status="tested", stored_rwp=stored, replay_rwp=replay_rwp,
                       gain=baseline-replay_rwp, values=active_values)
            row["decision"] = "supported" if row["gain"] >= 0.01 else "rejected"
        except Exception as exc:
            row.update(status="unknown", reason=repr(exc), traceback=traceback.format_exc())
        print(name, row["status"], row.get("replay_rwp"), row.get("decision", row.get("reason", "")))
        results.append(row)
    (ANALYSIS / "optional_term_trials.json").write_text(json.dumps(results, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
