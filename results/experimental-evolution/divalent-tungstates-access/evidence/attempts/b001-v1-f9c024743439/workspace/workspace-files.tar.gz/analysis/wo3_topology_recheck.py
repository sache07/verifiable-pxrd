#!/usr/bin/env python3
"""Recheck symmetry-diverse WO3 structures against one stable nuisance model."""

from __future__ import annotations

import json
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from gsas_trials import normalize_candidate_scattering, project_summary, reset_refinement_flags


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "broad_checkpoints" / "13_Ca_O_coordinates.gpx"
OUT = ANALYSIS / "wo3_recheck"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = {
    "2311041_monoclinic_P21c": COD / "2/31/10/2311041.cif",
    "1528915_monoclinic_P21c": COD / "1/52/89/1528915.cif",
    "2106293_triclinic_P-1": COD / "2/10/62/2106293.cif",
    "2107312_orthorhombic_Pnma": COD / "2/10/73/2107312.cif",
    "1010618_monoclinic_P21m": COD / "1/01/06/1010618.cif",
    "1563541_monoclinic_small_P21c": COD / "1/56/35/1563541.cif",
}


def common(project, candidate, cells=False):
    reset_refinement_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    project.phase("CaWO4_scheelite").set_HAP_refinements({"Scale": True})
    candidate.set_HAP_refinements({"Scale": True})
    if cells:
        candidate.set_refinements({"Cell": True})


def active(project):
    hist = project.histogram(0)
    return [p.name for p in project.phases() if p.data["Histograms"].get(hist.name, {}).get("Use")]


def valid_cell(start, end):
    lengths = ("length_a", "length_b", "length_c")
    if any(not np.isfinite(end[k]) or end[k] <= 0 for k in lengths):
        return False, "nonfinite/negative cell"
    vratio = end["volume"] / start["volume"]
    if not 0.90 <= vratio <= 1.10:
        return False, f"cell volume ratio {vratio:.4f} outside [0.90,1.10]"
    return True, ""


def main():
    OUT.mkdir(exist_ok=True)
    results = []
    for name, cif in CANDIDATES.items():
        branch = OUT / f"{name}.gpx"
        row = {"name": name, "cif": str(cif), "status": "pending"}
        try:
            project = G2sc.G2Project(str(SOURCE), newgpx=str(branch))
            hist = project.histogram(0)
            old = project.phase("WO3_2311041_monoclinic")
            if name.startswith("2311041"):
                candidate = old
            else:
                old.data["Histograms"][hist.name]["Use"] = False
                old.data["Histograms"][hist.name]["Scale"] = [1e-8, False]
                candidate = project.add_phase(str(cif), phasename=f"WO3_{name}", histograms=[hist], fmthint="CIF")
                normalize_candidate_scattering(candidate)
                hap = candidate.data["Histograms"][hist.name]
                hap["Use"] = True
                hap["Scale"] = [1.8, False]
                hap["Size"][0] = "isotropic"
                hap["Size"][1][0] = 0.12037831618646282
                hap["Mustrain"][0] = "isotropic"
                hap["Mustrain"][1][0] = 1228.215146967813
                hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
            if active(project) != ["CaWO4_scheelite", candidate.name]:
                raise RuntimeError(f"unexpected active phases: {active(project)}")
            start_cell = candidate.get_cell()
            stages = []
            for label, refine_cell in (("scale_background", False), ("candidate_cell", True)):
                common(project, candidate, cells=refine_cell)
                project.set_Controls("cycles", 10)
                project.refine(makeBack=False)
                listing = Path(project.filename).with_suffix(".lst")
                if (not listing.exists() or
                        "Final refinement wR" not in listing.read_text(errors="replace")):
                    raise RuntimeError(f"{label}: GSAS-II refinement did not complete")
                if project.get_Frozen():
                    raise RuntimeError(f"{label}: frozen parameters {project.get_Frozen()}")
                stages.append({"stage": label, "summary": project_summary(project)})
            ok, reason = valid_cell(start_cell, candidate.get_cell())
            if not ok:
                raise RuntimeError(reason)
            reset_refinement_flags(project)
            project.save()
            replay_path = OUT / f"{name}_replay.gpx"
            replay = G2sc.G2Project(str(branch), newgpx=str(replay_path))
            reset_refinement_flags(replay)
            replay.set_Controls("cycles", 0)
            replay.refine(makeBack=False)
            replay_listing = Path(replay.filename).with_suffix(".lst")
            text = replay_listing.read_text(errors="replace") if replay_listing.exists() else ""
            if "Refinement error" in text or "unable to evaluate" in text:
                raise RuntimeError("replay calculation failed")
            stored = float(project_summary(project)["residuals"]["wR"])
            replay_rwp = float(project_summary(replay)["residuals"]["wR"])
            if abs(stored - replay_rwp) > 0.02:
                raise RuntimeError(f"stored/replay mismatch {stored:.5f}/{replay_rwp:.5f}")
            row.update(status="tested", stages=stages, stored_rwp=stored,
                       replay_rwp=replay_rwp, start_cell=start_cell,
                       final_cell=candidate.get_cell(), active_phases=active(project))
        except Exception as exc:
            row.update(status="unknown", reason=repr(exc), traceback=traceback.format_exc())
        print(name, row["status"], row.get("replay_rwp"), row.get("reason", ""))
        results.append(row)
    tested = [r for r in results if r["status"] == "tested"]
    if tested:
        best = min(r["replay_rwp"] for r in tested)
        for row in tested:
            row["decision"] = "nominated" if row["replay_rwp"] <= best + 0.02 else "rejected"
    (ANALYSIS / "wo3_topology_recheck.json").write_text(json.dumps(results, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
