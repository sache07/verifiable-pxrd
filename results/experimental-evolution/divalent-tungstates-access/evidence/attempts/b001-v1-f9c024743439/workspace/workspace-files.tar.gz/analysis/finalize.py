#!/usr/bin/env python3
"""Create the requested deliverables directly from the accepted GSAS-II model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from gsas_trials import reset_refinement_flags


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "refined_broad.gpx"
FINAL = ROOT / "final.gpx"


def main():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL))
    if [p.name for p in project.phases()] != ["CaWO4_scheelite", "WO3_2311041_monoclinic"]:
        raise RuntimeError("accepted phase inventory changed")
    source_cov = project.data.get("Covariance", {}).get("data", {})
    refined_parameter_count = len(source_cov.get("varyList", []))
    project.save()
    source_fractions = project.histogram(0).ComputeMassFracs()
    reset_refinement_flags(project)
    if project.get_Frozen():
        raise RuntimeError("final project retains frozen variables")
    project.set_Controls("cycles", 0)
    project.save()
    project.refine(makeBack=False)
    reset_refinement_flags(project)
    project.save()

    hist = project.histogram(0)
    data = hist.data["data"][1]
    x, observed, calculated, background = [np.asarray(data[i], float) for i in (0, 1, 3, 4)]
    difference = observed - calculated
    if len(x) != 8301 or not np.all(np.isfinite(calculated)) or np.min(calculated) < 0:
        raise RuntimeError("invalid final calculated profile")
    supplied = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    sx = np.asarray(supplied[supplied.dtype.names[0]], float)
    sy = np.asarray(supplied[supplied.dtype.names[1]], float)
    if not (np.allclose(x, sx, rtol=0, atol=1e-8) and np.allclose(observed, sy, rtol=0, atol=1e-8)):
        raise RuntimeError("final histogram does not reproduce the supplied observation grid")

    cif_paths = {
        "CaWO4_scheelite": ROOT / "CaWO4_scheelite.cif",
        "WO3_2311041_monoclinic": ROOT / "WO3_monoclinic.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(cif_paths[phase.name]))

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
    )

    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    fractions = np.asarray(masses, float) / np.sum(masses)
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    dof = int(len(observed) - refined_parameter_count)
    reduced_chi_square = chi_square / dof
    residuals = dict(hist.residuals)

    phase_rows = []
    names = {
        "CaWO4_scheelite": ("Calcium tungstate (scheelite)", "CaWO4", "I41/a"),
        "WO3_2311041_monoclinic": ("Tungsten trioxide (monoclinic)", "WO3", "P21/c"),
    }
    for phase, fraction in zip(project.phases(), fractions):
        formal = source_fractions.get(phase.name, [None, None])
        phase_rows.append({
            "name": names[phase.name][0],
            "formula": names[phase.name][1],
            "space_group": names[phase.name][2],
            "cif_path": cif_paths[phase.name].name,
            "weight_fraction": float(fraction),
            "formal_weight_fraction_esd": None if formal[1] is None else float(formal[1]),
            "estimated_absolute_fraction_uncertainty": 0.015,
            "project_phase_name": phase.name,
        })

    result = {
        "phases": phase_rows,
        "fraction_basis": "Normalized over the two modeled crystalline phases; sum = 1.",
        "unresolved_components": [],
        "refinement_project": "final.gpx",
        "refinement_histogram": hist.name,
        "fit_profile": "fit.csv",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals.get("R", np.nan)),
            "R_expected_percent": float(residuals.get("wRmin", np.nan)),
            "goodness_of_fit_Rwp_over_Rexpected": rwp / float(residuals.get("wRmin", np.nan)),
            "chi_square": chi_square,
            "reduced_chi_square": reduced_chi_square,
            "data_points": int(len(observed)),
            "refined_parameter_count_last_structural_stage": refined_parameter_count,
            "degrees_of_freedom": dof,
            "phase_R_Bragg_percent": {
                "CaWO4_scheelite": float(residuals.get("0:0:Rf", np.nan)),
                "WO3_2311041_monoclinic": float(residuals.get("1:0:Rf", np.nan)),
            },
        },
        "calibration": {
            "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
            "sample_displacement_um": float(hist.SampleParameters["Shift"][0]),
            "goniometer_radius_mm": float(hist.SampleParameters["Gonio. radius"]),
        },
        "profile_notes": {
            "CaWO4_isotropic_domain_size_um": 0.04,
            "CaWO4_size_status": "lower-limit estimate; not reliably resolved below 0.04 um",
            "WO3_isotropic_domain_size_um": 0.12037831618646282,
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    ledger = {
        "full_enumeration": "analysis/candidate_screen.csv",
        "branches": [
            {"candidate": "CaWO4 COD 7219229, I41/a", "status": "nominated"},
            {"candidate": "CaWO4 COD 1546035, C2/c high-pressure", "status": "rejected", "reason": "peak-family mismatch"},
            {"candidate": "CaWO4 COD 5910088", "status": "unknown", "reason": "source CIF has no parseable atomic structure"},
            {"candidate": "WO3 COD 2311041, P21/c", "status": "nominated", "common_Rwp_percent": 4.0640},
            {"candidate": "WO3 COD 2106293, P-1", "status": "rejected", "common_Rwp_percent": 4.5180},
            {"candidate": "WO3 COD 1528915, P21/c", "status": "rejected", "common_Rwp_percent": 4.6806},
            {"candidate": "WO3 COD 2107312, Pnma", "status": "rejected", "common_Rwp_percent": 7.2666},
            {"candidate": "WO3 COD 1010618, P21/m", "status": "unknown", "reason": "cell trial failed; no valid refined cell"},
            {"candidate": "WO3 COD 1563541, P21/c small-cell", "status": "unknown", "reason": "GSAS-II objective could not be evaluated after import"},
            {"candidate": "remaining screened WO3 polymorphs (hexagonal/tetragonal)", "status": "rejected", "reason": "coherent peak-family mismatch in the nomination screen"},
            {"candidate": "CaCO3 calcite", "status": "rejected", "reason": "only 0.0047 percentage-point Rwp gain at fixed profile; further size trial hit 0.04 um boundary and worsened replay"},
            {"candidate": "CaCO3 aragonite/vaterite, CaO, Ca3WO6, Ca4.26W10O30, high-pressure CaWO4", "status": "rejected", "reason": "scale collapsed below 0.05 wt% or to numerical zero"},
        ],
    }
    (ROOT / "analysis" / "candidate_ledger.json").write_text(json.dumps(ledger, indent=2) + "\n")

    ca_pct, wo_pct = 100 * fractions
    report = f"""# Powder XRD phase analysis

The accepted crystalline model contains **scheelite CaWO4 ({ca_pct:.2f} wt%)** and **monoclinic WO3 ({wo_pct:.2f} wt%)**, normalized over the modeled crystalline phases. The final replayed fit has Rwp = {rwp:.3f}%, Rp = {residuals.get('R', float('nan')):.3f}%, and Rexp = {residuals.get('wRmin', float('nan')):.3f}% for {len(observed)} points.

## Evidence

The dominant broad family (including the strong features near 18.27, 28.42, 33.85, 38.91, 46.88, 54.16 and 57.65 degrees 2theta) is indexed by I41/a scheelite CaWO4. The narrower family near 22.76, 23.18, 23.98, 26.19, 28.77, 32.9–33.2 and 49.47 degrees is accounted for by P21/c WO3. The CaWO4 structure is physically conventional after refinement (W–O 1.797 A; Ca–O 2.413–2.455 A). The WO3 model retains distorted WO6 octahedra with W–O 1.735–2.152 A; all occupancies are 1 and no short-contact or negative-ADP issue was found.

All available same-formula CaWO4 and WO3 entries were enumerated before nomination. Under the same stable nuisance model, the shortlisted WO3 alternatives gave Rwp 4.518% (P-1, COD 2106293), 4.681% (alternative P21/c, COD 1528915), and 7.267% (Pnma, COD 2107312), versus 4.064% for COD 2311041 before its limited W-coordinate stage. The P21/m and small-cell P21/c trials failed to produce valid replayable refinements and remain unknown rather than rejected. The complete screen is in `analysis/candidate_screen.csv`, with the branch decisions in `analysis/candidate_ledger.json`.

Phase-closure trials covered calcite/aragonite/vaterite CaCO3, CaO, Ca3WO6, Ca4.26W10O30 and the high-pressure CaWO4 polymorph. Their scales collapsed or their gain was unsupported. Calcite gave only a 0.0047 percentage-point Rwp decrease with a fixed profile; attempting to broaden it drove size to the 0.04 um boundary and worsened the replay, so it was omitted. The remaining positive residuals are concentrated on flanks of existing CaWO4/WO3 peaks, not a separate coherent peak family. Trace material below roughly 0.5–1 wt% cannot be excluded.

## Refinement and uncertainty

The refinement was staged through scale/background, displacement and cells, isotropic instrument/phase profiles, then limited symmetry-allowed coordinates. One-at-a-time uniaxial-strain and March–Dollase trials were unsupported (largest Rwp gain 0.0044 percentage points); roughness was singular and boundary-hitting, so all were rolled back. Exported CIF geometry was screened after replay.

The CaWO4 coherent-domain size is only a lower-limit estimate: the diagnostic optimum was 0.0392 um, just below the allowed 0.04 um range, so 0.04 um was fixed. This peak-width limit and correlations with background/profile terms make the formal fraction errors optimistic; a practical uncertainty is about ±1.5 wt% absolute for each phase. CaWO4 oxygen and WO3 tungsten coordinates are supported by limited refinement, while WO3 oxygen coordinates were unstable and were retained from the nominated reference. Thus the phase identities and approximate fractions are reliable, but crystallite size and fine WO3 oxygen geometry are not determined reliably from this pattern alone.
"""
    (ROOT / "report.md").write_text(report)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
