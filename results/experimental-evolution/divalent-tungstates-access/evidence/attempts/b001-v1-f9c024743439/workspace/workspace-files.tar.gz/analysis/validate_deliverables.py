#!/usr/bin/env python3
"""Independent consistency checks for all submitted deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.structure_matcher import StructureMatcher
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parents[1]


def main():
    result = json.loads((ROOT / "result.json").read_text())
    fit = np.loadtxt(ROOT / "fit.csv", delimiter=",", skiprows=1)
    supplied = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    replay = np.load(ROOT / ".tmp" / "replaycheck" / "prediction.npz")
    weight = 1.0 / np.maximum(fit[:, 1], 1.0)
    rwp = float(100 * np.sqrt(np.sum(weight * (fit[:, 1] - fit[:, 2])**2) /
                              np.sum(weight * fit[:, 1]**2)))
    checks = {
        "all_required_files_exist": all((ROOT / name).is_file() for name in (
            "final.gpx", "CaWO4_scheelite.cif", "WO3_monoclinic.cif",
            "fit.csv", "result.json", "report.md")),
        "fit_rows": int(len(fit)),
        "observed_grid_exact": bool(np.allclose(fit[:, :2], supplied, atol=1e-8, rtol=0)),
        "difference_exact": bool(np.allclose(fit[:, 3], fit[:, 1] - fit[:, 2], atol=1e-7, rtol=0)),
        "calculated_nonnegative": bool(np.min(fit[:, 2]) >= 0),
        "fit_rwp_percent": rwp,
        "reported_rwp_percent": float(result["fit_statistics"]["Rwp_percent"]),
        "fit_replay_max_abs_difference_counts": float(np.max(np.abs(fit[:, 2] - replay["predicted"]))),
        "fraction_sum": float(sum(p["weight_fraction"] for p in result["phases"])),
    }
    matcher = StructureMatcher(ltol=1e-5, stol=1e-5, angle_tol=1e-4,
                               primitive_cell=False, scale=False, attempt_supercell=False)
    comparisons = []
    for submitted, replayed in (
        ("CaWO4_scheelite.cif", ".tmp/replaycheck/phase_0.cif"),
        ("WO3_monoclinic.cif", ".tmp/replaycheck/phase_1.cif"),
    ):
        a = Structure.from_file(ROOT / submitted, primitive=False)
        b = Structure.from_file(ROOT / replayed, primitive=False)
        comparisons.append({
            "submitted": submitted,
            "replayed": replayed,
            "formula_submitted": a.composition.reduced_formula,
            "formula_replayed": b.composition.reduced_formula,
            "strict_structure_match": bool(matcher.fit(a, b)),
            "minimum_distance_A": float(a.distance_matrix[np.triu_indices(len(a), 1)].min()),
        })
    checks["cif_project_comparisons"] = comparisons
    checks["pass"] = bool(
        checks["all_required_files_exist"] and checks["fit_rows"] == 8301 and
        checks["observed_grid_exact"] and checks["difference_exact"] and
        checks["calculated_nonnegative"] and abs(checks["fit_rwp_percent"] - checks["reported_rwp_percent"]) < 1e-8 and
        checks["fit_replay_max_abs_difference_counts"] < 1e-4 and
        abs(checks["fraction_sum"] - 1.0) < 1e-12 and
        all(c["strict_structure_match"] and c["minimum_distance_A"] > 1.4 for c in comparisons)
    )
    (ROOT / "analysis" / "final_validation.json").write_text(json.dumps(checks, indent=2) + "\n")
    print(json.dumps(checks, indent=2))
    if not checks["pass"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
