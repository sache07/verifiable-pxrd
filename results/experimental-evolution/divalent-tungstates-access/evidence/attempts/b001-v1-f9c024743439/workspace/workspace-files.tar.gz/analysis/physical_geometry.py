#!/usr/bin/env python3
"""Check exported CIF geometry with pymatgen."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parents[1]


def pair_summary(structure):
    distances = []
    for i, site in enumerate(structure):
        for j in range(i + 1, len(structure)):
            d = float(structure.get_distance(i, j))
            distances.append((d, site.specie.symbol, structure[j].specie.symbol))
    distances.sort()
    by_pair = {}
    for distance, a, b in distances:
        key = "-".join(sorted((a, b)))
        by_pair.setdefault(key, []).append(distance)
    return {
        "minimum_distance_A": distances[0][0],
        "minimum_pair": [distances[0][1], distances[0][2]],
        "pair_ranges_A": {
            key: {"minimum": min(vals), "maximum_below_3A": max([v for v in vals if v < 3.0], default=None)}
            for key, vals in by_pair.items()
        },
    }


def coordination(structure, center, neighbor, cutoff):
    records = []
    for index, site in enumerate(structure):
        if site.specie.symbol != center:
            continue
        ds = sorted(float(n.nn_distance) for n in structure.get_neighbors(site, cutoff)
                    if n.specie.symbol == neighbor)
        records.append({"site": index, "coordination": len(ds), "distances_A": ds})
    return records


def main():
    result = json.loads((ROOT / "analysis" / "physical_project.json").read_text())
    for name, record in result["phases"].items():
        structure = Structure.from_file(ROOT / record["cif"], primitive=False)
        symbol, number = structure.get_space_group_info(symprec=0.05)
        pairs = pair_summary(structure)
        if pairs["minimum_distance_A"] < 1.4:
            result["issues"].append(f"{name}: implausibly short interatomic distance")
        record.update(
            formula=structure.composition.reduced_formula,
            space_group=symbol,
            space_group_number=number,
            pairs=pairs,
            W_O_coordination_within_2_45A=coordination(structure, "W", "O", 2.45),
            Ca_O_coordination_within_2_90A=coordination(structure, "Ca", "O", 2.90),
        )
    (ROOT / "analysis" / "physical_screen.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
