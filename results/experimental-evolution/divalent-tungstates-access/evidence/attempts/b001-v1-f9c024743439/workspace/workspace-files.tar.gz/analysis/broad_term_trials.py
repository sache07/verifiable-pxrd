#!/usr/bin/env python3
"""Independent one-term profile trials from the broad-CaWO4 checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from gsas_trials import project_summary, reset_refinement_flags


ROOT = Path(__file__).resolve().parents[1]
ANALYSIS = ROOT / "analysis"
SOURCE = ANALYSIS / "checkpoints" / "05_CaWO4_size.gpx"
OUT = ANALYSIS / "broad_trials"


def bound(project, name, low, high):
    project.set_Controls("parmMin", low, variable=name)
    project.set_Controls("parmMax", high, variable=name)


def common(project):
    reset_refinement_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def term(project, name):
    hist = project.histogram(0)
    if name == "Ca_size_diagnostic":
        phase = project.phase("CaWO4_scheelite")
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        bound(project, f"{phase.id}:0:Size;i", 0.015, 0.15)
    elif name == "Ca_strain":
        phase = project.phase("CaWO4_scheelite")
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
    elif name == "WO3_size":
        phase = project.phase("WO3_2311041_monoclinic")
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
    elif name == "WO3_strain":
        phase = project.phase("WO3_2311041_monoclinic")
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
    elif name in {"U", "W", "X", "SH/L", "Polariz."}:
        hist.set_refinements({"Instrument Parameters": [name]})
        limits = {
            "U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
            "SH/L": (0.005, 0.1), "Polariz.": (0.5, 1.0),
        }
        bound(project, f":0:{name}", *limits[name])
    else:
        raise KeyError(name)


def profiles(project):
    hist = project.histogram(0)
    result = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result[phase.name] = {
            "size": hap["Size"][1][0],
            "strain": hap["Mustrain"][1][0],
        }
    return result


def main():
    OUT.mkdir(exist_ok=True)
    names = ["Ca_size_diagnostic", "Ca_strain", "WO3_size", "WO3_strain",
             "U", "W", "X", "SH/L", "Polariz."]
    results = []
    for name in names:
        target = OUT / f"{name.replace('/', '_')}.gpx"
        project = G2sc.G2Project(str(SOURCE), newgpx=str(target))
        common(project)
        term(project, name)
        project.set_Controls("cycles", 10)
        project.refine(makeBack=False)
        reset_refinement_flags(project)
        project.save()
        stored = project_summary(project)
        replay_path = OUT / f"{name.replace('/', '_')}_replay.gpx"
        replay = G2sc.G2Project(str(target), newgpx=str(replay_path))
        reset_refinement_flags(replay)
        replay.set_Controls("cycles", 0)
        replay.refine(makeBack=False)
        row = {
            "name": name,
            "stored_rwp": stored["residuals"]["wR"],
            "replay_rwp": project_summary(replay)["residuals"]["wR"],
            "instrument": stored["instrument_parameters"],
            "profiles": profiles(project),
            "fractions": {k: v["mass_fraction"] for k, v in stored["phases"].items()},
        }
        print(json.dumps(row))
        results.append(row)
    (ANALYSIS / "broad_term_trials.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
