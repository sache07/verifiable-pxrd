#!/usr/bin/env python3
"""Export the accepted full-grid GSAS-II checkpoint and submission artifacts."""

from pathlib import Path
import argparse
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent.parent
EXPORTS = {
    "CuWO4_triclinic": ("CuWO4", "phase_CuWO4.cif"),
    "WO3_monoclinic": ("WO3", "phase_WO3.cif"),
    "CuO_monoclinic": ("CuO", "phase_CuO.cif"),
    "Cu3WO6_cubic": ("Cu3WO6", "phase_Cu3WO6.cif"),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    args = parser.parse_args()

    final_path = ROOT / "final.gpx"
    project = G2sc.G2Project(args.input, newgpx=str(final_path))
    project.save()
    histogram = project.histogram(0)
    arrays = np.asarray(histogram.data["data"][1], dtype=float)
    x, observed, weights, calculated = arrays[:4]
    difference = observed - calculated

    source = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if source.shape != (len(x), 2):
        raise ValueError("GSAS-II and source profile lengths differ")
    if not np.allclose(x, source[:, 0], atol=1e-9, rtol=0):
        raise ValueError("GSAS-II angle grid differs from the supplied pattern")
    if not np.allclose(observed, source[:, 1], atol=1e-9, rtol=0):
        raise ValueError("GSAS-II observations differ from the supplied pattern")
    if not np.isfinite(calculated).all() or np.any(calculated < 0):
        raise ValueError("calculated profile is nonfinite or negative")
    if np.any(calculated == 0):
        raise ValueError("calculated profile does not cover the full supplied grid")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    phase_rows = []
    unnormalized = []
    for phase in project.phases():
        if phase.name not in EXPORTS:
            raise ValueError(f"unexpected phase in accepted project: {phase.name}")
        formula, filename = EXPORTS[phase.name]
        scale = float(phase.getHAPvalues(histogram.name)["Scale"][0])
        mass_scale = float(phase.data["General"]["Mass"]) * scale
        if mass_scale <= 0:
            raise ValueError(f"non-positive crystalline mass scale for {phase.name}")
        unnormalized.append(mass_scale)
        phase_rows.append(
            {
                "name": phase.name,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": filename,
            }
        )

    total = float(sum(unnormalized))
    for row, mass_scale in zip(phase_rows, unnormalized):
        row["weight_fraction"] = mass_scale / total

    # Export the saved phase dictionaries, without allowing covariance values to
    # substitute for the full-precision coordinates stored in final.gpx.
    project.data["Covariance"]["data"] = {}
    for phase in project.phases():
        phase.export_CIF(str(ROOT / EXPORTS[phase.name][1]))

    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100 * np.sqrt(chi_square / denominator))
    rp = float(100 * np.sum(np.abs(difference)) / np.sum(observed))
    covariance = G2sc.G2Project(str(final_path)).data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    n_observations = int(rvals.get("Nobs", len(x)))
    n_parameters = int(rvals.get("Nvars", len(covariance.get("varyList", []))))
    gof = float(np.sqrt(chi_square / (n_observations - n_parameters)))

    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "refinement_histogram": histogram.name,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "goodness_of_fit": gof,
            "n_observations": n_observations,
            "n_refined_parameters": n_parameters,
        },
        "calibration": {
            "zero_deg": float(histogram.data["Instrument Parameters"][0]["Zero"][1]),
            "sample_displacement_micrometers": float(
                histogram.data["Sample Parameters"]["Shift"][0]
            ),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    print("final_project", final_path)
    print("histogram", histogram.name, "points", len(x))
    print("fit", result["fit_statistics"])
    for row in phase_rows:
        print(row["name"], row["space_group"], row["weight_fraction"], row["cif_path"])


if __name__ == "__main__":
    main()
