#!/usr/bin/env python3
"""Build and stage-refine an initial CuWO4 + WO3 + CuO GSAS-II model."""

from pathlib import Path
import csv
import math

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_xye() -> Path:
    out = HERE / "pattern.xye"
    with (ROOT / "inputs/pattern.csv").open(newline="") as src, out.open("w") as dst:
        rows = csv.DictReader(src)
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return out


def log_state(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(f"STATE {label} wR={hist.get_wR()}")
    print(
        "INST",
        {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
    )
    print(
        "SAMPLE",
        {k: sample[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
    )
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        print(
            "PHASE",
            phase.name,
            "cell",
            phase.get_cell(),
            "scale",
            hap["Scale"][0],
            "size",
            hap["Size"],
            "mustrain",
            hap["Mustrain"],
            "pref",
            hap["Pref.Ori."],
        )


def refine(project: G2sc.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    project.save(HERE / f"initial_{label}.gpx")
    log_state(project, label)


def main() -> None:
    xye = make_xye()
    project = G2sc.G2Project(newgpx=str(HERE / "initial.gpx"))
    hist = project.add_powder_histogram(
        str(xye), str(HERE / "instrument.instprm"), fmthint="xye"
    )
    phase_specs = [
        ("CuWO4_triclinic", "4000806"),
        ("WO3_triclinic", "2106293"),
        ("CuO_monoclinic", "9016057"),
    ]
    for name, cod_id in phase_specs:
        project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )

    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["shift factor"] = 0.5
    hist.data["Limits"][1] = [10.0, 100.0]
    sample = hist.data["Sample Parameters"]
    sample["Gonio. radius"] = 200.0
    sample["Shift"][0] = 700.0
    sample["SurfRoughA"][0] = 0.0
    sample["SurfRoughB"][0] = 0.0
    hist.set_refinements({"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 16}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})

    project.save()
    refine(project, "01_scales_background")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "02_shift_zero")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "03_cells")

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    refine(project, "04_instrument_profile")

    project.save(HERE / "initial_final.gpx")


if __name__ == "__main__":
    main()
