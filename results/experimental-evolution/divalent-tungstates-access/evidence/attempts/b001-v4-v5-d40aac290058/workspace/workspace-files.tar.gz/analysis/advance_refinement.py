#!/usr/bin/env python3
"""Apply one controlled refinement stage to an existing GSAS-II project."""

from pathlib import Path
import argparse

from GSASII import GSASIIscriptable as G2sc


def show(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(f"SUMMARY {label} wR={hist.get_wR():.6f}")
    print("INST", {k: inst[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("SAMPLE", {k: sample[k][0] for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")})
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        print("PHASE", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"][0])
        print("PROFILE", phase.name, "size", hap["Size"], "mustrain", hap["Mustrain"], "pref", hap["Pref.Ori."])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument(
        "stage",
        choices=[
            "cells",
            "calibration-cells",
            "profile-wx",
            "profile-uw",
            "profile-x",
            "profile-shl",
            "polarization",
            "profile-uvwy",
            "profile-all",
            "shift-only",
            "zero-only",
            "roughness",
            "texture",
            "size",
            "mustrain",
            "size-mustrain",
            "positions-heavy",
            "positions-oxygen",
            "positions-all",
            "uiso",
            "scale-background",
            "none",
        ],
    )
    ap.add_argument("--cycles", type=int, default=6)
    ap.add_argument("--set-shift", type=float)
    ap.add_argument("--set-zero", type=float)
    ap.add_argument("--set-x", type=float)
    ap.add_argument("--set-u", type=float)
    ap.add_argument("--set-polarization", type=float)
    ap.add_argument("--set-shl", type=float)
    ap.add_argument("--fix-shift", action="store_true")
    ap.add_argument("--fix-zero", action="store_true")
    ap.add_argument("--fix-cells", action="store_true")
    ap.add_argument("--fix-profile", action="store_true")
    ap.add_argument("--fix-u", action="store_true")
    ap.add_argument("--fix-polarization", action="store_true")
    ap.add_argument("--fix-shl", action="store_true")
    ap.add_argument("--phase", action="append", default=[])
    ap.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    ap.add_argument("--set-size", type=float)
    ap.add_argument("--fix-size", action="store_true")
    ap.add_argument("--set-mustrain", type=float)
    ap.add_argument("--fix-mustrain", action="store_true")
    args = ap.parse_args()

    project = G2sc.G2Project(args.input, newgpx=args.output)
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    selected_phases = (
        [project.phase(name) for name in args.phase] if args.phase else project.phases()
    )
    if args.set_size is not None:
        for phase in selected_phases:
            phase.getHAPvalues(hist.name)["Size"][1][0] = args.set_size
    if args.fix_size:
        for phase in selected_phases:
            phase.clear_HAP_refinements({"Size": True})
    if args.set_mustrain is not None:
        for phase in selected_phases:
            phase.getHAPvalues(hist.name)["Mustrain"][1][0] = args.set_mustrain
    if args.fix_mustrain:
        for phase in selected_phases:
            phase.clear_HAP_refinements({"Mustrain": True})

    if args.set_shift is not None:
        hist.data["Sample Parameters"]["Shift"][0] = args.set_shift
    if args.set_zero is not None:
        hist.data["Instrument Parameters"][0]["Zero"][1] = args.set_zero
    if args.set_x is not None:
        hist.data["Instrument Parameters"][0]["X"][1] = args.set_x
    if args.set_u is not None:
        hist.data["Instrument Parameters"][0]["U"][1] = args.set_u
    if args.set_polarization is not None:
        hist.data["Instrument Parameters"][0]["Polariz."][1] = args.set_polarization
    if args.set_shl is not None:
        hist.data["Instrument Parameters"][0]["SH/L"][1] = args.set_shl
    if args.fix_shift:
        hist.clear_refinements({"Sample Parameters": ["Shift"]})
    if args.fix_zero:
        hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    if args.fix_cells:
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
    if args.fix_profile:
        hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    if args.fix_u:
        hist.clear_refinements({"Instrument Parameters": ["U"]})
    if args.fix_polarization:
        hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    if args.fix_shl:
        hist.clear_refinements({"Instrument Parameters": ["SH/L"]})

    if args.stage == "cells":
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    elif args.stage == "calibration-cells":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    elif args.stage == "profile-wx":
        hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    elif args.stage == "profile-uw":
        hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    elif args.stage == "profile-x":
        hist.set_refinements({"Instrument Parameters": ["X"]})
    elif args.stage == "profile-shl":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif args.stage == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.stage == "profile-uvwy":
        hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "Y"]})
    elif args.stage == "profile-all":
        hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"]})
    elif args.stage == "shift-only":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    elif args.stage == "zero-only":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        hist.clear_refinements({"Sample Parameters": ["Shift"]})
    elif args.stage == "roughness":
        hist.data["Sample Parameters"]["SurfRoughA"][0] = 0.2
        hist.data["Sample Parameters"]["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    elif args.stage == "texture":
        for phase in selected_phases:
            hap = phase.getHAPvalues(hist.name)
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(args.axis)
            phase.set_HAP_refinements({"Pref.Ori.": True})
    elif args.stage == "size":
        for phase in selected_phases:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True, "value": 0.5}})
    elif args.stage == "mustrain":
        for phase in selected_phases:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    elif args.stage == "size-mustrain":
        for phase in selected_phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True, "value": 0.5},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
    elif args.stage == "positions-heavy":
        for phase in selected_phases:
            refs = {}
            for atom in phase.atoms():
                if atom.element.upper() != "O":
                    refs[atom.label] = "X"
            phase.set_refinements({"Atoms": refs})
    elif args.stage == "positions-oxygen":
        for phase in selected_phases:
            refs = {}
            for atom in phase.atoms():
                if atom.element.upper() == "O":
                    refs[atom.label] = "X"
            phase.set_refinements({"Atoms": refs})
    elif args.stage == "positions-all":
        for phase in selected_phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
    elif args.stage == "uiso":
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": "U"}})
    elif args.stage == "scale-background":
        hist.set_refinements({"Background": True})
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True})

    project.save()
    project.refine(makeBack=False)
    project.save()
    show(project, args.stage)


if __name__ == "__main__":
    main()
