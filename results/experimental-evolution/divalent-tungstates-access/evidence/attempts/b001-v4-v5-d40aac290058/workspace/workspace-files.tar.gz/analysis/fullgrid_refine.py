#!/usr/bin/env python3
"""Refine an accepted GSAS-II model on the complete supplied pattern grid."""

from pathlib import Path
import argparse

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent.parent


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--fix-histogram-scale", action="store_true")
    args = parser.parse_args()

    x = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1, usecols=0)
    project = G2sc.G2Project(args.input, newgpx=args.output)
    histogram = project.histogram(0)
    histogram.data["Limits"][1] = [float(x[0]), float(x[-1])]
    if args.fix_histogram_scale:
        histogram.clear_refinements({"Sample Parameters": ["Scale"]})
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()

    print("histogram", histogram.name)
    print("limits", histogram.data["Limits"])
    print("Rwp_percent", histogram.get_wR())
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        print(phase.name, "scale", hap["Scale"][0], "cell", phase.get_cell())


if __name__ == "__main__":
    main()
