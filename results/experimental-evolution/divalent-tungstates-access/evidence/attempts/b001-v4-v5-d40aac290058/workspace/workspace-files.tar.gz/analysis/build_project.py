#!/usr/bin/env python3
"""Create a physical three-phase GSAS-II starting project and fit scale/background."""

from pathlib import Path
import argparse
import csv
import math

from GSASII import GSASIIscriptable as G2sc


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def ensure_xye() -> Path:
    out = HERE / "pattern.xye"
    if out.exists():
        return out
    with (ROOT / "inputs/pattern.csv").open(newline="") as src, out.open("w") as dst:
        for row in csv.DictReader(src):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return out


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("output")
    ap.add_argument("--cuwo4", default="4000806")
    ap.add_argument("--wo3", default="2311041")
    ap.add_argument("--cuo", default="1011194")
    ap.add_argument("--cu3wo6", default="1527404")
    ap.add_argument("--shift", type=float, default=800.0)
    ap.add_argument("--zero", type=float, default=-0.02)
    ap.add_argument("--cycles", type=int, default=6)
    args = ap.parse_args()

    project = G2sc.G2Project(newgpx=args.output)
    hist = project.add_powder_histogram(
        str(ensure_xye()), str(HERE / "instrument.instprm"), fmthint="xye"
    )
    hist.data["Limits"][1] = [10.0, 100.0]
    sample = hist.data["Sample Parameters"]
    sample["Gonio. radius"] = 200.0
    sample["Shift"][0] = args.shift
    hist.data["Instrument Parameters"][0]["Zero"][1] = args.zero

    for name, cod_id in [
        ("CuWO4_triclinic", args.cuwo4),
        ("WO3_monoclinic", args.wo3),
        ("CuO_monoclinic", args.cuo),
        ("Cu3WO6_cubic", args.cu3wo6),
    ]:
        project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )

    project.set_Controls("cycles", args.cycles)
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 16}}
    )
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.save()
    project.refine(makeBack=False)
    project.save()
    print(f"SUMMARY wR={hist.get_wR():.6f}")
    for phase in project.phases():
        print(phase.name, phase.get_cell(), phase.getHAPvalues(hist.name)["Scale"][0])


if __name__ == "__main__":
    main()
