#!/usr/bin/env python3
"""Add one COD phase to a GSAS-II project and refine only scales/background."""

from pathlib import Path
import argparse

from GSASII import GSASIIscriptable as G2sc


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("name")
    ap.add_argument("cod_id")
    ap.add_argument("--cycles", type=int, default=6)
    args = ap.parse_args()

    project = G2sc.G2Project(args.input, newgpx=args.output)
    hist = project.histogram(0)
    phase = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    project.set_Controls("cycles", args.cycles)

    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L"],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.set_refinements({"Background": True})
    for item in project.phases():
        item.clear_refinements({"Cell": True})
        item.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        item.set_HAP_refinements({"Scale": True})

    project.save()
    project.refine(makeBack=False)
    project.save()
    print(f"SUMMARY wR={hist.get_wR():.6f}")
    for item in project.phases():
        print(item.name, item.getHAPvalues(hist.name)["Scale"][0], item.get_cell())


if __name__ == "__main__":
    main()
