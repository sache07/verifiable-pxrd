#!/usr/bin/env python3
"""Normalize selected COD models exactly as the synthetic-case runtime does."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parents[1]
RUNTIME = ROOT / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)

CANDIDATES = {
    "cawo4_scheelite_7219229": "7219229",
    "cawo4_wolframite_1546035": "1546035",
    "ca3wo6_1563081": "1563081",
    "ca_w_bronze_4030741": "4030741",
    "wo3_p21m_1010618": "1010618",
    "wo3_p21n_1528915": "1528915",
    "wo3_p21c_1563541": "1563541",
    "wo3_p21c_2311041": "2311041",
    "wo3_p1_2106293": "2106293",
    "wo3_pnma_2107312": "2107312",
    "cao_1563196": "1563196",
    "caco3_calcite_1547347": "1547347",
}


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    output = ROOT / "analysis" / "candidates"
    output.mkdir(parents=True, exist_ok=True)
    records = []
    for name, cod_id in CANDIDATES.items():
        source = cod_path(cod_id)
        structure = Structure.from_file(source, primitive=False)
        structure.remove_oxidation_states()
        destination = output / f"{name}.cif"
        write_synthetic_model(structure, destination)
        normalized = Structure.from_file(destination, primitive=False)
        records.append(
            {
                "name": name,
                "cod_id": cod_id,
                "source": str(source),
                "normalized_cif": str(destination.relative_to(ROOT)),
                "formula": normalized.composition.reduced_formula,
                "space_group": list(normalized.get_space_group_info()),
                "sites": len(normalized),
                "cell": [*normalized.lattice.abc, *normalized.lattice.angles],
            }
        )
    (output / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
