#!/usr/bin/env python3
"""Grid-screen physical instrument profiles with fixed refined structures."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "atomic_physical_w2" / "atomic.gpx"
OUTPUT = ROOT / "analysis" / "instrument_scan"
U_VALUES = [0.0, 10.0, 20.0, 30.0, 40.0]
X_VALUES = [0.1, 1.0, 2.0, 4.0, 6.0]


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda x: np.asarray(x, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def fractions(phases, histogram):
    raw = np.array([p.data["General"]["Mass"] * p.data["Histograms"][histogram]["Scale"][0] for p in phases])
    return (raw / raw.sum()).tolist()


def run(u, x):
    label = f"u{u:g}_x{x:g}".replace(".", "p")
    folder = OUTPUT / label
    folder.mkdir(parents=True, exist_ok=True)
    gpx = folder / "profile.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(gpx))
    hist = project.histograms()[0]
    phases = project.phases()
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": u, "V": 0.0, "W": 2.0, "X": x, "Y": 0.0, "Z": 0.0, "SH/L": 0.005}.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["Polariz."][2] = False
    inst["Zero"][2] = False
    hist.SampleParameters["Shift"][1] = False
    for phase in phases:
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    row = {
        "label": label,
        "U": u,
        "W": 2.0,
        "X": x,
        "SH_L": 0.005,
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "sizes_um": [p.data["Histograms"][hist.name]["Size"][1][0] for p in phases],
        "gpx": str(gpx.relative_to(ROOT)),
    }
    (folder / "result.json").write_text(json.dumps(row, indent=2) + "\n")
    print(label, row["rwp_percent"], row["fractions"], row["sizes_um"], flush=True)
    return row


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    results = [run(u, x) for u in U_VALUES for x in X_VALUES]
    results.sort(key=lambda row: row["rwp_percent"])
    (OUTPUT / "comparison.json").write_text(json.dumps(results, indent=2) + "\n")
    print("ranking", [(r["label"], r["rwp_percent"]) for r in results[:10]])


if __name__ == "__main__":
    main()
