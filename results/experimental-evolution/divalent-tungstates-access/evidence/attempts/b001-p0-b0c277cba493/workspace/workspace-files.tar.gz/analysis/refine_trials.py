#!/usr/bin/env python3
"""Run matched GSAS-II screening refinements for candidate WO3 models.

This script is intended for the GSAS-II Python environment. It keeps the
refinement sequence identical between candidate structures so that profile
agreement, rather than hand tuning, selects the WO3 polymorph.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "analysis" / "candidates"
OBSERVED = ROOT / "inputs" / "pattern.csv"

CAWO4 = "cawo4_scheelite_7219229"
WO3_MODELS = [
    "wo3_p21m_1010618",
    "wo3_p21n_1528915",
    "wo3_p21c_1563541",
    "wo3_p21c_2311041",
    "wo3_p1_2106293",
    "wo3_pnma_2107312",
]


def instrument_text() -> str:
    return (
        "# Synthetic laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.20;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:20.0;X:0.8;Y:0.0;Z:0.0;SH/L:0.022\n"
    )


def plain(value):
    if isinstance(value, dict):
        return {str(key): plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def external_rwp(hist) -> float:
    _, observed, weights, calculated = hist.data["data"][1][:4]
    observed = np.asarray(observed, float)
    calculated = np.asarray(calculated, float)
    weights = np.asarray(weights, float)
    return float(
        100
        * np.sqrt(
            np.sum(weights * (observed - calculated) ** 2)
            / np.sum(weights * observed**2)
        )
    )


def phase_fractions(phases, hist_name: str) -> list[float]:
    masses = np.array(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][hist_name]["Scale"][0]
            for phase in phases
        ],
        float,
    )
    return (masses / masses.sum()).tolist()


def snapshot(project, hist, phases, step: str) -> dict:
    return {
        "step": step,
        "gpx_rwp_percent": hist.get_wR(),
        "external_rwp_percent": external_rwp(hist),
        "fractions": phase_fractions(phases, hist.name),
        "cells": {
            phase.name: plain(phase.data["General"]["Cell"][1:])
            for phase in phases
        },
        "instrument": {
            key: plain(value)
            for key, value in hist.data["Instrument Parameters"][0].items()
        },
        "sample": {
            key: plain(hist.SampleParameters[key])
            for key in [
                "Scale",
                "Shift",
                "Transparency",
                "SurfRoughA",
                "SurfRoughB",
                "Gonio. radius",
            ]
        },
        "hap": {
            phase.name: {
                key: plain(phase.data["Histograms"][hist.name][key])
                for key in ["Scale", "Size", "Mustrain", "Pref.Ori."]
            }
            for phase in phases
        },
        "vary_list": [str(item) for item in (project.get_VaryList() or [])],
    }


def refine_step(project, hist, phases, label: str, log: list[dict]) -> None:
    project.set_Controls("cycles", 8)
    project.refine()
    project.save()
    row = snapshot(project, hist, phases, label)
    log.append(row)
    print(
        f"{label:24s} Rwp={row['external_rwp_percent']:.4f}% "
        f"fractions={row['fractions']}",
        flush=True,
    )


def run_trial(wo3_name: str, output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    gpx_path = output / "trial.gpx"
    inst_path = output / "instrument.instprm"
    inst_path.write_text(instrument_text())
    if gpx_path.exists():
        gpx_path.unlink()

    project = G2.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(str(OBSERVED), str(inst_path))
    phases = [
        project.add_phase(
            str(CANDIDATES / f"{name}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        for name in [CAWO4, wo3_name]
    ]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0

    # A smooth empirical baseline is flexible enough for the supplied
    # exponential/power-law background without adding unphysical broad peaks.
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    for phase, fraction in zip(phases, [0.8, 0.2]):
        mass = float(phase.data["General"]["Mass"])
        phase.data["Histograms"][hist.name]["Scale"] = [
            10000.0 * fraction / mass,
            True,
        ]

    log: list[dict] = []
    refine_step(project, hist, phases, "scales_background", log)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_step(project, hist, phases, "angular_zero", log)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_step(project, hist, phases, "phase_cells", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_step(project, hist, phases, "zero_displacement", log)

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_step(project, hist, phases, "profile_W_X", log)

    hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    refine_step(project, hist, phases, "instrument_profile", log)

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    refine_step(project, hist, phases, "phase_broadening", log)
    refine_step(project, hist, phases, "settle", log)

    result = {
        "status": "ok",
        "wo3_model": wo3_name,
        "project": str(gpx_path.relative_to(ROOT)),
        "steps": log,
        "final": log[-1],
    }
    (output / "summary.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--models", nargs="*", default=WO3_MODELS)
    parser.add_argument(
        "--output", type=Path, default=ROOT / "analysis" / "trials"
    )
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    args.output.mkdir(parents=True, exist_ok=True)
    results = []
    for model in args.models:
        print(f"\n=== {model} ===", flush=True)
        try:
            results.append(run_trial(model, args.output / model))
        except Exception as exc:
            traceback.print_exc()
            results.append(
                {
                    "status": "error",
                    "wo3_model": model,
                    "error": repr(exc),
                    "traceback": traceback.format_exc(),
                }
            )
    results.sort(
        key=lambda row: (
            row["status"] != "ok",
            row.get("final", {}).get("external_rwp_percent", math.inf),
        )
    )
    destination = args.output / "comparison.json"
    destination.write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")
    print("\n=== ranking ===")
    for row in results:
        value = row.get("final", {}).get("external_rwp_percent")
        print(row["wo3_model"], row["status"], value)


if __name__ == "__main__":
    main()
