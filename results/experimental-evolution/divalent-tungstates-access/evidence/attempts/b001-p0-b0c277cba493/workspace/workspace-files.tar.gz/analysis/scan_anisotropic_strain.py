#!/usr/bin/env python3
"""Screen allowed uniaxial microstrain axes from a common refined seed."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "atomic_physical_w2" / "atomic.gpx"
OUTPUT = ROOT / "analysis" / "strain_scan"
AXES = [[0, 0, 1], [1, 0, 0], [0, 1, 0]]


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda x: np.asarray(x, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def fractions(phases, histogram):
    raw = np.array([p.data["General"]["Mass"] * p.data["Histograms"][histogram]["Scale"][0] for p in phases])
    return (raw / raw.sum()).tolist()


def run(phase_index, axis):
    label = "none" if phase_index is None else f"p{phase_index}_{''.join(map(str, axis))}"
    folder = OUTPUT / label
    folder.mkdir(parents=True, exist_ok=True)
    gpx = folder / "strain.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(gpx))
    hist = project.histograms()[0]
    phases = project.phases()
    for index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        if index == 1:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2][0] = False
    if phase_index is not None:
        hap = phases[phase_index].data["Histograms"][hist.name]
        start = max(300.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = start
        hap["Mustrain"][1][1] = start
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis
    project.set_Controls("cycles", 16)
    project.refine()
    project.save()
    profiles = []
    for phase in phases:
        strain = phase.data["Histograms"][hist.name]["Mustrain"]
        profiles.append({"type": strain[0], "values": strain[1], "axis": strain[3]})
    row = {
        "label": label,
        "phase_index": phase_index,
        "axis": axis,
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "profiles": profiles,
        "gpx": str(gpx.relative_to(ROOT)),
    }
    (folder / "result.json").write_text(json.dumps(row, indent=2) + "\n")
    print(label, row["rwp_percent"], row["fractions"], profiles, flush=True)
    return row


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    results = [run(None, None)]
    for phase_index in [0, 1]:
        for axis in AXES:
            results.append(run(phase_index, axis))
    results.sort(key=lambda row: row["rwp_percent"])
    (OUTPUT / "comparison.json").write_text(json.dumps(results, indent=2) + "\n")
    print("ranking", [(row["label"], row["rwp_percent"]) for row in results])


if __name__ == "__main__":
    main()
