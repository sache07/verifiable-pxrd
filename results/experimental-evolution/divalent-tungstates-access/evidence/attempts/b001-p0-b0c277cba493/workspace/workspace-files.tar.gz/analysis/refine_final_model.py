#!/usr/bin/env python3
"""Settle the selected physical profile and structural model in stages."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "instrument_scan" / "u30_x1" / "profile.gpx"
OUTPUT = ROOT / "analysis" / "final_model_work"


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda x: np.asarray(x, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def fractions(phases, histogram):
    raw = np.array([p.data["General"]["Mass"] * p.data["Histograms"][histogram]["Scale"][0] for p in phases])
    return (raw / raw.sum()).tolist()


def refine(project, hist, phases, label, history, cycles=14):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    row = {
        "step": label,
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "vary_list": [str(v) for v in (project.get_VaryList() or [])],
    }
    history.append(row)
    shutil.copy2(project.filename, OUTPUT / f"{label}.gpx")
    print(label, row["rwp_percent"], row["fractions"], flush=True)


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT / "model.gpx"))
    hist = project.histograms()[0]
    phases = project.phases()
    inst = hist.data["Instrument Parameters"][0]
    history = []

    # Refine the sole nondegenerate shared Gaussian angle term. Lorentzian X
    # and isotropic size are exactly correlated here, so X remains fixed.
    inst["U"][2] = True
    refine(project, hist, phases, "instrument_U", history)
    inst["U"][2] = False

    # Refine positions with ADPs and polarization held at their prior values.
    for atom in phases[0].atoms():
        atom.refinement_flags = "X" if atom.element == "O" else " "
    for atom in phases[1].atoms():
        atom.refinement_flags = "X"
    inst["Polariz."][2] = False
    refine(project, hist, phases, "coordinates", history, cycles=18)
    refine(project, hist, phases, "coordinates_settle", history, cycles=18)

    # Existing equality constraints tie all Uiso values within each phase.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    refine(project, hist, phases, "phase_uiso", history, cycles=16)
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "

    inst["Polariz."][2] = True
    refine(project, hist, phases, "polarization", history, cycles=14)
    inst["Polariz."][2] = False
    refine(project, hist, phases, "final_settle", history, cycles=14)

    arrays = hist.data["data"][1]
    np.savetxt(
        OUTPUT / "fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]]),
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
    )
    details = {
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "history": history,
        "instrument": inst,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": [],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        details["phases"].append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:],
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "coordinates": list(a.coordinates),
                        "uiso": a.uiso,
                        "flags": a.refinement_flags,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    (OUTPUT / "details.json").write_text(json.dumps(details, indent=2) + "\n")
    print(json.dumps({"rwp_percent": details["rwp_percent"], "fractions": details["fractions"]}))


if __name__ == "__main__":
    main()
