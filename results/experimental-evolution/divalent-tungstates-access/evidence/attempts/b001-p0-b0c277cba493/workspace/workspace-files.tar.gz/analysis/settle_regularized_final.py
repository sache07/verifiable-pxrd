#!/usr/bin/env python3
"""Settle profile, phase ADPs and polarization for the regularized model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "local_tungsten_scan" / "0p04" / "model.gpx"
OUTPUT = ROOT / "analysis" / "regularized_final"


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda values: np.asarray(values, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def snapshot(project, label, history):
    project.save()
    shutil.copy2(project.filename, OUTPUT / f"{label}.gpx")
    hist = project.histograms()[0]
    phases = project.phases()
    raw = np.asarray(
        [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0] for phase in phases]
    )
    row = {
        "step": label,
        "rwp_percent": rwp(hist),
        "fractions": (raw / raw.sum()).tolist(),
        "polarization": hist.data["Instrument Parameters"][0]["Polariz."][1],
        "uiso_A2": {
            phase.name: [float(atom.uiso) for atom in phase.atoms()] for phase in phases
        },
    }
    history.append(row)
    print(json.dumps(row), flush=True)


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT / "model.gpx"))
    hist = project.histograms()[0]
    phases = project.phases()
    instrument = hist.data["Instrument Parameters"][0]
    history = []

    for phase in phases:
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    instrument["Polariz."][2] = False
    project.set_Controls("cycles", 16)
    project.refine()
    snapshot(project, "phase_uiso", history)

    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "
    instrument["Polariz."][2] = True
    project.set_Controls("cycles", 14)
    project.refine()
    snapshot(project, "polarization", history)

    instrument["Polariz."][2] = False
    project.set_Controls("cycles", 14)
    project.refine()
    snapshot(project, "final_settle", history)
    (OUTPUT / "details.json").write_text(json.dumps({"history": history, "final": history[-1]}, indent=2) + "\n")


if __name__ == "__main__":
    main()
