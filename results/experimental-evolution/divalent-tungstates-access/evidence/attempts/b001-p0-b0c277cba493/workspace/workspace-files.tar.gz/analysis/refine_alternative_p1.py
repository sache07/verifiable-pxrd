#!/usr/bin/env python3
"""Matched physical refinement of the near-degenerate triclinic WO3 model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "trials" / "wo3_p1_2106293" / "trial.gpx"
OUTPUT = ROOT / "analysis" / "alternative_p1"


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda x: np.asarray(x, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def fractions(phases, histogram):
    raw = np.array([p.data["General"]["Mass"] * p.data["Histograms"][histogram]["Scale"][0] for p in phases])
    return (raw / raw.sum()).tolist()


def refine(project, hist, phases, label, history, cycles=16):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    row = {"step": label, "rwp_percent": rwp(hist), "fractions": fractions(phases, hist.name)}
    history.append(row)
    shutil.copy2(project.filename, OUTPUT / f"{label}.gpx")
    print(label, row["rwp_percent"], row["fractions"], flush=True)


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT / "model.gpx"))
    hist = project.histograms()[0]
    phases = project.phases()
    inst = hist.data["Instrument Parameters"][0]
    history = []

    for key, value in {"U": 30.0, "V": 0.0, "W": 2.0, "X": 1.0, "Y": 0.0, "Z": 0.0, "SH/L": 0.005}.items():
        inst[key][1] = value
        inst[key][2] = False
    inst["Polariz."][2] = False
    inst["Zero"][2] = False
    hist.SampleParameters["Shift"][1] = False
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase, size in zip(phases, [0.055, 0.13]):
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
            atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    refine(project, hist, phases, "physical_profile", history, cycles=16)

    for atom in phases[0].atoms():
        atom.refinement_flags = "X" if atom.element == "O" else " "
    for atom in phases[1].atoms():
        atom.refinement_flags = "X" if atom.element == "W" else " "
    refine(project, hist, phases, "heavy_coordinates", history, cycles=18)
    for atom in phases[1].atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine(project, hist, phases, "oxygen_coordinates", history, cycles=20)
    refine(project, hist, phases, "coordinate_settle", history, cycles=20)

    project.index_ids()
    for phase in phases:
        pid = phase.data["pId"]
        variables = [f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    refine(project, hist, phases, "phase_uiso", history, cycles=18)
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "
    inst["Polariz."][2] = True
    refine(project, hist, phases, "polarization", history, cycles=16)
    inst["Polariz."][2] = False
    refine(project, hist, phases, "final_settle", history, cycles=14)

    details = {
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "history": history,
        "instrument": inst,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": [],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        details["phases"].append({
            "name": phase.name,
            "cell": phase.data["General"]["Cell"][1:],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "scale": hap["Scale"],
            "atoms": [{"label": a.label, "element": a.element, "coordinates": list(a.coordinates), "uiso": a.uiso} for a in phase.atoms()],
        })
    (OUTPUT / "details.json").write_text(json.dumps(details, indent=2) + "\n")
    print(json.dumps({"rwp_percent": details["rwp_percent"], "fractions": details["fractions"]}))


if __name__ == "__main__":
    main()
