#!/usr/bin/env python3
"""Test a locally refined WO3 tungsten direction inside the mismatch envelope."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "local_oxygen_scan" / "0p05" / "model.gpx"
PARENT = ROOT / "analysis" / "trials" / "wo3_p21c_2311041" / "trial.gpx"
OUTPUT = ROOT / "analysis" / "local_tungsten_scan"
TARGET_RMS = [0.0, 0.01, 0.02, 0.03, 0.04]


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda values: np.asarray(values, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def lattice_matrix(cell):
    a, b, c, _, beta, _ = cell
    angle = np.deg2rad(beta)
    return np.asarray([[a, 0.0, 0.0], [0.0, b, 0.0], [c * np.cos(angle), 0.0, c * np.sin(angle)]])


def set_profile_flags(project, enabled):
    hist = project.histograms()[0]
    hist.Background[0][1] = enabled
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = enabled
        hap["Size"][2][0] = enabled
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    parent = G2.G2Project(gpxfile=str(PARENT)).phase("wo3_p21c_2311041")
    parent_atoms = list(parent.atoms())

    base = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT / "parent_w.gpx"))
    set_profile_flags(base, True)
    phase = base.phase("wo3_p21c_2311041")
    for atom, parent_atom in zip(phase.atoms(), parent_atoms):
        if atom.element == "W":
            atom.coordinates = list(parent_atom.coordinates)
    base.set_Controls("cycles", 12)
    base.refine()
    base.save()

    direction_project = G2.G2Project(gpxfile=str(OUTPUT / "parent_w.gpx"), newgpx=str(OUTPUT / "tungsten_step.gpx"))
    set_profile_flags(direction_project, False)
    phase = direction_project.phase("wo3_p21c_2311041")
    start = np.asarray([atom.coordinates for atom in phase.atoms()], float)
    for atom in phase.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    direction_project.set_Controls("cycles", 1)
    direction_project.refine()
    direction_project.save()
    phase = direction_project.phase("wo3_p21c_2311041")
    target = np.asarray([atom.coordinates for atom in phase.atoms()], float)
    delta = target - start
    delta -= np.rint(delta)
    mask = np.asarray([atom.element == "W" for atom in phase.atoms()])
    matrix = lattice_matrix(phase.data["General"]["Cell"][1:7])
    step_rms = float(np.sqrt(np.mean(np.sum((delta[mask] @ matrix) ** 2, axis=1))))
    print(json.dumps({"parent_w_rwp_percent": rwp(base.histograms()[0]), "one_step_rwp_percent": rwp(direction_project.histograms()[0]), "one_step_w_rms_A": step_rms}), flush=True)

    rows = []
    for target_rms in TARGET_RMS:
        folder = OUTPUT / str(target_rms).replace(".", "p")
        folder.mkdir(parents=True, exist_ok=True)
        project = G2.G2Project(gpxfile=str(OUTPUT / "parent_w.gpx"), newgpx=str(folder / "model.gpx"))
        set_profile_flags(project, True)
        phase = project.phase("wo3_p21c_2311041")
        factor = 0.0 if target_rms == 0 else target_rms / step_rms
        for index, atom in enumerate(phase.atoms()):
            if atom.element == "W":
                atom.coordinates = ((start[index] + factor * delta[index]) % 1).tolist()
            atom.refinement_flags = " "
        project.set_Controls("cycles", 12)
        project.refine()
        project.save()
        hist = project.histograms()[0]
        raw = np.asarray(
            [item.data["General"]["Mass"] * item.data["Histograms"][hist.name]["Scale"][0] for item in project.phases()]
        )
        row = {"target_w_rms_A": target_rms, "direction_factor": factor, "rwp_percent": rwp(hist), "fractions": (raw / raw.sum()).tolist(), "project": str(project.filename)}
        rows.append(row)
        print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["rwp_percent"])
    (OUTPUT / "comparison.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("BEST", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
