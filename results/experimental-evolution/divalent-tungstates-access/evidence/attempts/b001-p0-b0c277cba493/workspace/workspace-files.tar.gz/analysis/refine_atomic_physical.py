#!/usr/bin/env python3
"""Refine symmetry-allowed atomic parameters from a physical profile seed."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_SOURCE = ROOT / "analysis" / "physical_scan" / "u10_w10_x1" / "profile.gpx"
DEFAULT_OUTPUT = ROOT / "analysis" / "atomic_physical"


def rwp(hist) -> float:
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda x: np.asarray(x, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def fractions(phases, histogram: str) -> list[float]:
    raw = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][histogram]["Scale"][0] for p in phases]
    )
    return (raw / raw.sum()).tolist()


def refine(project, hist, phases, label: str, history: list[dict], output: Path, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    row = {
        "step": label,
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "vary_list": [str(item) for item in (project.get_VaryList() or [])],
    }
    history.append(row)
    print(label, row["rwp_percent"], row["fractions"], flush=True)
    shutil.copy2(project.filename, output / f"{label}.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--fix-wo3-strain-zero", action="store_true")
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    G2.SetPrintLevel("warn")
    output.mkdir(parents=True, exist_ok=True)
    final = output / "atomic.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(final))
    hist = project.histograms()[0]
    phases = project.phases()
    history = []

    # Keep calibration, cells and the selected physical instrument profile fixed.
    hist.data["Instrument Parameters"][0]["Polariz."][2] = False
    for phase in phases:
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    if args.fix_wo3_strain_zero:
        hap = phases[1].data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False

    # In scheelite only O has a positional degree of freedom. Refine the heavy
    # W framework of WO3 before its oxygen sublattice for numerical stability.
    for atom in phases[0].atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    for atom in phases[1].atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    refine(project, hist, phases, "heavy_coordinates", history, output, cycles=16)

    for atom in phases[1].atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine(project, hist, phases, "oxygen_coordinates", history, output, cycles=18)
    refine(project, hist, phases, "coordinate_settle", history, output, cycles=18)

    # One Uiso per phase matches the specimen model; equality constraints avoid
    # replacing structural information with unconstrained atom-by-atom damping.
    project.index_ids()
    for phase in phases:
        pid = phase.data["pId"]
        variables = [f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for atom in phase.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = "XU" if "X" in atom.refinement_flags else "U"
    refine(project, hist, phases, "phase_uiso", history, output, cycles=18)
    refine(project, hist, phases, "atomic_settle", history, output, cycles=18)

    # Polarization is an instrument-level intensity correction and is unknown
    # in the public metadata. Refine it only after structural intensities settle.
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    refine(project, hist, phases, "polarization", history, output, cycles=12)

    arrays = hist.data["data"][1]
    np.savetxt(
        output / "fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]]),
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
    )
    details = {
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "history": history,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": [],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        details["phases"].append(
            {
                "name": phase.name,
                "cell": phase.data["General"]["Cell"][1:],
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    (output / "details.json").write_text(json.dumps(details, indent=2) + "\n")
    print(json.dumps({"rwp_percent": details["rwp_percent"], "fractions": details["fractions"]}))


if __name__ == "__main__":
    main()
