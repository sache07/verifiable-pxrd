#!/usr/bin/env python3
"""Refine a staged, physically bounded calibration alternative."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "final_model_work" / "cell_test.gpx"
OUTPUT = ROOT / "analysis" / "physical_calibration"


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda values: np.asarray(values, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def snapshot(project, label):
    project.save()
    shutil.copy2(project.filename, OUTPUT / f"{label}.gpx")
    hist = project.histograms()[0]
    print(label, rwp(hist), [phase.get_cell() for phase in project.phases()], flush=True)


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT / "physical.gpx"))
    hist = project.histograms()[0]
    phases = project.phases()
    hist.data["Instrument Parameters"][0]["Zero"][1:] = [-0.25, False]
    hist.SampleParameters["Shift"][:] = [0.0, False]
    hist.Background[0][1] = False
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2][0] = False
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 10)
    project.refine()
    snapshot(project, "cells_only")

    hist.Background[0][1] = True
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
    project.set_Controls("cycles", 14)
    project.refine()
    snapshot(project, "profile_settle")

    # With a near-reference cell in place, estimate the two calibration terms
    # without allowing lattice/calibration compensation in the same cycle.
    for phase in phases:
        phase.data["General"]["Cell"][0] = False
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    hist.SampleParameters["Shift"][1] = True
    project.set_Controls("cycles", 12)
    project.refine()
    snapshot(project, "calibration_only")

    hist.data["Instrument Parameters"][0]["Zero"][2] = False
    hist.SampleParameters["Shift"][1] = False
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    project.set_Controls("cycles", 14)
    project.refine()
    snapshot(project, "final_settle")

    # Project the highly correlated calibration pair back to the physical
    # generator bounds, then let only lattice/profile terms readjust.
    hist.data["Instrument Parameters"][0]["Zero"][1:] = [0.25, False]
    hist.SampleParameters["Shift"][:] = [800.0, False]
    project.set_Controls("cycles", 18)
    project.refine()
    snapshot(project, "bounded_settle")

    raw = np.asarray(
        [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0] for phase in phases]
    )
    result = {
        "rwp_percent": rwp(hist),
        "fractions": (raw / raw.sum()).tolist(),
        "zero_degrees": hist.data["Instrument Parameters"][0]["Zero"][1],
        "shift_micrometres": hist.SampleParameters["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in phases},
    }
    (OUTPUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
