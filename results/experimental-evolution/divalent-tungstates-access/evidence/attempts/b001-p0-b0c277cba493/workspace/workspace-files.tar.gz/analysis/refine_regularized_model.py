#!/usr/bin/env python3
"""Build a physically bounded model with chemically regularized coordinates."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "final_model_work" / "cell_test.gpx"
PARENT = ROOT / "analysis" / "trials" / "wo3_p21c_2311041" / "trial.gpx"
OUTPUT = ROOT / "analysis" / "regularized_model"

# Bounded least-squares solution that reproduces the selected model's
# reflection positions while respecting LAB.md's calibration/cell envelope.
CELL_VALUES = {
    "cawo4_scheelite_7219229": [5.23629531, 5.23629531, 11.33093146, 90.0, 90.0, 90.0],
    "wo3_p21c_2311041": [7.31025673, 7.55233442, 10.51171202, 90.0, 132.99948126, 90.0],
}
ZERO_DEGREES = -0.25
SHIFT_MICROMETRES = 205.58053283


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda values: np.asarray(values, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def fractions(phases, histogram):
    raw = np.asarray(
        [phase.data["General"]["Mass"] * phase.data["Histograms"][histogram]["Scale"][0] for phase in phases]
    )
    return (raw / raw.sum()).tolist()


def set_cell(phase, values):
    reciprocal = G2lat.cell2A(values)
    phase.data["General"]["Cell"][1:8] = [*values, G2lat.calc_V(reciprocal)]


def snapshot(project, label, history):
    project.save()
    shutil.copy2(project.filename, OUTPUT / f"{label}.gpx")
    hist = project.histograms()[0]
    phases = project.phases()
    row = {
        "step": label,
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "zero_degrees": hist.data["Instrument Parameters"][0]["Zero"][1],
        "shift_micrometres": hist.SampleParameters["Shift"][0],
    }
    history.append(row)
    print(json.dumps(row), flush=True)


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT / "regularized.gpx"))
    parent = G2.G2Project(gpxfile=str(PARENT))
    hist = project.histograms()[0]
    phases = project.phases()
    parent_phases = {phase.name: phase for phase in parent.phases()}
    history = []

    instrument = hist.data["Instrument Parameters"][0]
    instrument["Zero"][1:] = [ZERO_DEGREES, False]
    hist.SampleParameters["Shift"][:] = [SHIFT_MICROMETRES, False]
    for value in instrument.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], (bool, np.bool_)):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False

    for phase in phases:
        set_cell(phase, CELL_VALUES[phase.name])
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # The unconstrained oxygen coordinates were overfit (minimum W--O 1.31 A).
    # Restore the WO3 parent framework; the true synthetic mismatch is bounded
    # to 0.01--0.05 A RMS, so the parent is a better regularized estimate than
    # the large unconstrained shifts. Keep the modest scheelite O refinement.
    phase = next(phase for phase in phases if phase.name == "wo3_p21c_2311041")
    parent_phase = parent_phases[phase.name]
    for atom, parent_atom in zip(phase.atoms(), parent_phase.atoms()):
        if atom.label != parent_atom.label or atom.element != parent_atom.element:
            raise RuntimeError("Parent/current atom ordering mismatch")
        atom.coordinates = list(parent_atom.coordinates)

    hist.Background[0][1] = True
    project.set_Controls("cycles", 16)
    project.refine()
    snapshot(project, "bounded_profile", history)

    # Refine lattice metrics from the bounded geometric start, with the common
    # calibration now fixed. This should only make a local correction.
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    project.set_Controls("cycles", 18)
    project.refine()
    snapshot(project, "bounded_cells", history)

    for phase in phases:
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    project.set_Controls("cycles", 14)
    project.refine()
    snapshot(project, "phase_uiso", history)
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 14)
    project.refine()
    snapshot(project, "final_settle", history)

    result = {"history": history, "final": history[-1]}
    (OUTPUT / "details.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
