#!/usr/bin/env python3
"""Replace the screening fit's clamped profile with physical trial profiles."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "trials" / "wo3_p21c_2311041" / "trial.gpx"
OUTPUT = ROOT / "analysis" / "physical_scan"

TRIALS = [
    {"name": "u20_w2_x1", "U": 20.0, "W": 2.0, "X": 1.0, "SH/L": 0.02},
    {"name": "u10_w10_x1", "U": 10.0, "W": 10.0, "X": 1.0, "SH/L": 0.02},
    {"name": "u20_w10_x2", "U": 20.0, "W": 10.0, "X": 2.0, "SH/L": 0.02},
    {"name": "u0_w20_x3", "U": 0.0, "W": 20.0, "X": 3.0, "SH/L": 0.02},
    {"name": "u30_w20_x1", "U": 30.0, "W": 20.0, "X": 1.0, "SH/L": 0.02},
]


def rwp(hist) -> float:
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda x: np.asarray(x, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def fractions(phases, histogram: str) -> list[float]:
    raw = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][histogram]["Scale"][0] for p in phases]
    )
    return (raw / raw.sum()).tolist()


def run_trial(spec: dict) -> dict:
    folder = OUTPUT / spec["name"]
    folder.mkdir(parents=True, exist_ok=True)
    gpx = folder / "profile.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(gpx))
    hist = project.histograms()[0]
    phases = project.phases()

    instrument = hist.data["Instrument Parameters"][0]
    for key in ["U", "W", "X", "SH/L"]:
        instrument[key][1] = spec[key]
        instrument[key][2] = False
    for key in ["V", "Y", "Z"]:
        instrument[key][1] = 0.0
        instrument[key][2] = False
    instrument["Zero"][2] = False
    hist.SampleParameters["Shift"][1] = False
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]

    for phase, size in zip(phases, [0.08, 0.15]):
        phase.set_refinements({"Cell": False})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2] = [True, False, False]
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = False

    project.set_Frozen()
    project.set_Controls("cycles", 10)
    project.refine()
    project.refine()
    project.save()
    row = {
        **spec,
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "phase_profiles": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in phases
        },
        "gpx": str(gpx.relative_to(ROOT)),
    }
    (folder / "result.json").write_text(json.dumps(row, indent=2) + "\n")
    print(
        spec["name"],
        f"Rwp={row['rwp_percent']:.5f}",
        "fractions=", row["fractions"],
        "profiles=", {
            name: [values["size"][1][0], values["mustrain"][1][0]]
            for name, values in row["phase_profiles"].items()
        },
        flush=True,
    )
    return row


def main() -> None:
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    results = [run_trial(spec) for spec in TRIALS]
    results.sort(key=lambda row: row["rwp_percent"])
    (OUTPUT / "comparison.json").write_text(json.dumps(results, indent=2) + "\n")
    print("ranking", [(row["name"], row["rwp_percent"]) for row in results])


if __name__ == "__main__":
    main()
