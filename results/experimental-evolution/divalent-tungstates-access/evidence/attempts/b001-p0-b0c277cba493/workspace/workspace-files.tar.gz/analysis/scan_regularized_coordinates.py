#!/usr/bin/env python3
"""Scan bounded parent-to-refined coordinate displacements for monoclinic WO3."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "regularized_model" / "bounded_cells.gpx"
PARENT = ROOT / "analysis" / "trials" / "wo3_p21c_2311041" / "trial.gpx"
TARGET = ROOT / "analysis" / "final_model_work" / "cell_test.gpx"
OUTPUT = ROOT / "analysis" / "regularized_coordinate_scan"
W_FACTORS = [0.0, 0.135, 0.27, 0.405, 0.535]
O_FACTORS = [0.0, 0.025, 0.05, 0.075, 0.094]


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda values: np.asarray(values, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def tag(value):
    return str(value).replace(".", "p")


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    parent_project = G2.G2Project(gpxfile=str(PARENT))
    target_project = G2.G2Project(gpxfile=str(TARGET))
    parent = parent_project.phase("wo3_p21c_2311041")
    target = target_project.phase("wo3_p21c_2311041")
    parent_atoms = list(parent.atoms())
    target_atoms = list(target.atoms())
    rows = []
    for w_factor in W_FACTORS:
        for o_factor in O_FACTORS:
            folder = OUTPUT / f"w{tag(w_factor)}_o{tag(o_factor)}"
            folder.mkdir(parents=True, exist_ok=True)
            project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(folder / "model.gpx"))
            hist = project.histograms()[0]
            phases = project.phases()
            phase = project.phase("wo3_p21c_2311041")
            for atom, parent_atom, target_atom in zip(phase.atoms(), parent_atoms, target_atoms):
                if atom.label != parent_atom.label or atom.label != target_atom.label:
                    raise RuntimeError("Atom ordering mismatch")
                factor = w_factor if atom.element == "W" else o_factor
                start = np.asarray(parent_atom.coordinates, float)
                delta = np.asarray(target_atom.coordinates, float) - start
                delta -= np.rint(delta)
                atom.coordinates = ((start + factor * delta) % 1).tolist()
                atom.refinement_flags = " "
            for item in phases:
                item.data["General"]["Cell"][0] = False
                hap = item.data["Histograms"][hist.name]
                hap["Scale"][1] = True
                hap["Size"][2][0] = True
            hist.Background[0][1] = True
            project.set_Controls("cycles", 10)
            project.refine()
            project.save()
            masses = np.asarray(
                [item.data["General"]["Mass"] * item.data["Histograms"][hist.name]["Scale"][0] for item in phases]
            )
            row = {
                "w_factor": w_factor,
                "o_factor": o_factor,
                "w_rms_from_parent_A": 0.0745258888509724 * w_factor,
                "o_rms_from_parent_A": 0.5315255167569796 * o_factor,
                "rwp_percent": rwp(hist),
                "fractions": (masses / masses.sum()).tolist(),
                "project": str(project.filename),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["rwp_percent"])
    (OUTPUT / "comparison.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("BEST", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
