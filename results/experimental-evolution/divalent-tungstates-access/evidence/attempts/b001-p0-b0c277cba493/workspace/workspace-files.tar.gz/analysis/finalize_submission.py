#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export its structural deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "regularized_final" / "final_settle.gpx"
FINAL = ROOT / "final.gpx"
CIF_NAMES = {
    "cawo4_scheelite_7219229": "CaWO4_scheelite.cif",
    "wo3_p21c_2311041": "WO3_monoclinic.cif",
}


def freeze_project(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], (bool, np.bool_)):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        for value in hap["Babinet"].values():
            value[1] = False
    return hist


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    freeze_project(project)
    project.save()

    # Reload what was actually serialized, then export the submitted CIFs.
    project = G2.G2Project(gpxfile=str(FINAL))
    hist = project.histograms()[0]
    phases = project.phases()
    for phase in phases:
        phase.export_CIF(str(ROOT / CIF_NAMES[phase.name]))

    x, observed, weight, calculated, background = map(np.asarray, hist.data["data"][1][:5])
    rwp = float(100 * np.sqrt(np.sum(weight * (observed - calculated) ** 2) / np.sum(weight * observed**2)))
    rp = float(100 * np.sum(np.abs(observed - calculated)) / np.sum(observed))
    masses = np.asarray(
        [phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0] for phase in phases],
        dtype=float,
    )
    covariance = project.data["Covariance"]["data"]
    summary = {
        "histogram": hist.name,
        "rwp_percent": rwp,
        "rp_percent": rp,
        "goodness_of_fit": covariance.get("Rvals", {}).get("GOF"),
        "expected_rwp_percent": rwp / covariance.get("Rvals", {}).get("GOF", np.nan),
        "fractions": {
            phase.name: float(value) for phase, value in zip(phases, masses / masses.sum())
        },
        "cifs": CIF_NAMES,
        "cells": {phase.name: phase.get_cell() for phase in phases},
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.SampleParameters,
        "profile_sizes_micrometres": {
            phase.name: float(phase.data["Histograms"][hist.name]["Size"][1][0]) for phase in phases
        },
    }
    (ROOT / "analysis" / "finalization_summary.json").write_text(
        json.dumps(summary, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(summary, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
