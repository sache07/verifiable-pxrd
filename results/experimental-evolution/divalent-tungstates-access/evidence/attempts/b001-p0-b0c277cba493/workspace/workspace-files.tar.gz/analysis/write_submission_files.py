#!/usr/bin/env python3
"""Write fit.csv, result.json and report.md from the verified final replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPLAY_DIR = ROOT / ".tmp" / "final_replay"


def main():
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    summary = json.loads((ROOT / "analysis" / "finalization_summary.json").read_text())
    if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
        raise RuntimeError(f"Final replay did not pass cleanly: {replay}")
    prediction = np.load(REPLAY_DIR / "prediction.npz")
    observed = prediction["observed"]
    calculated = prediction["predicted"]
    background = prediction["background"]
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack(
            [prediction["x"], observed, calculated, background, observed - calculated]
        ),
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
        fmt="%.12g",
    )

    ca_fraction = replay["phases"][0]["weight_fraction"]
    wo_fraction = replay["phases"][1]["weight_fraction"]
    result = {
        "phases": [
            {
                "name": "CaWO4 (scheelite)",
                "formula": "CaWO4",
                "space_group": "I41/a (No. 88)",
                "cif_path": "CaWO4_scheelite.cif",
                "weight_fraction": ca_fraction,
                "weight_percent": 100 * ca_fraction,
            },
            {
                "name": "WO3 (monoclinic)",
                "formula": "WO3",
                "space_group": "P21/c (No. 14)",
                "cif_path": "WO3_monoclinic.cif",
                "weight_fraction": wo_fraction,
                "weight_percent": 100 * wo_fraction,
            },
        ],
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "rwp_percent": summary["rwp_percent"],
            "rp_percent": summary["rp_percent"],
            "goodness_of_fit": summary["goodness_of_fit"],
            "expected_rwp_percent": summary["expected_rwp_percent"],
            "points": int(len(observed)),
        },
        "refinement_histogram": replay["histogram"],
        "gsas_project": "final.gpx",
        "profile_source": "independent forward replay of final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    ca = summary["cells"]["cawo4_scheelite_7219229"]
    wo = summary["cells"]["wo3_p21c_2311041"]
    report = f"""# Powder XRD phase analysis

## Result

The crystalline portion is **CaWO4 scheelite (I41/a), {100*ca_fraction:.2f} wt%**, plus **monoclinic WO3 (P21/c), {100*wo_fraction:.2f} wt%**. Fractions are normalized only over the modeled crystalline phases; this experiment does not determine any amorphous fraction.

The submitted atomic-model fit has Rwp = {summary['rwp_percent']:.3f}%, Rp = {summary['rp_percent']:.3f}% and goodness-of-fit = {summary['goodness_of_fit']:.3f} (counting-statistical Rwp expectation {summary['expected_rwp_percent']:.3f}%). The refined cells are CaWO4 a = {ca['length_a']:.5f}, c = {ca['length_c']:.5f} A, and WO3 a = {wo['length_a']:.5f}, b = {wo['length_b']:.5f}, c = {wo['length_c']:.5f} A, beta = {wo['angle_beta']:.5f} degrees.

## Evidence

The dominant 18.28, 28.43, 33.85, 46.89 and 57.64 degree peaks and the remaining scheelite series are reproduced by CaWO4. The resolved 22.77/23.18/23.99 degree triplet and its higher-angle companions require low-symmetry WO3. This agrees with the WO3 + CaCO3 precursor context at 650 degrees C: CaWO4 formed as the main product while some WO3 remained. Models for CaCO3, CaO and alternate calcium tungstates did not account for an additional peak family, and the final residual contains no coherent set requiring a third crystalline phase.

Matched candidate screening favored the P21/c WO3 parent; triclinic P-1 was the closest alternative, so the WO3 identity is secure but the exact low-symmetry polymorph is less certain than the CaWO4 assignment. The final profile was regenerated directly from the saved atomic GSAS-II model over all {len(observed)} observations; cached calculated intensities were not used, and no negative-width, negative-background or displacement-parameter flags were found.

## Uncertainty

A practical model spread is about 1--2 wt% absolute for either phase; the reported values are the exact scale-derived fractions in `final.gpx`. Absolute cell metrics correlate with zero/specimen displacement, so calibration-bounded values were used. Scheelite's oxygen coordinate is supported only at modest precision. WO3 oxygen coordinates cannot be determined reliably from this mixture pattern: unconstrained refinement produced implausibly short W--O contacts, so the submitted P21/c coordinates are regularized to remain within 0.05 A RMS (O) and 0.04 A RMS (W) of the published parent. The CIF therefore identifies the phase and provides a physically credible diffraction model, but should not be interpreted as a precise determination of WO3 local octahedral distortions.
"""
    (ROOT / "report.md").write_text(report)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
