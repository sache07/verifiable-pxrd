#!/usr/bin/env python3
"""Physically bounded Rietveld refinement for CaWO4 + low-symmetry WO3."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
CANDIDATES = ROOT / "analysis" / "candidates"
OBSERVED = ROOT / "inputs" / "pattern.csv"
CAWO4 = "cawo4_scheelite_7219229"


def instrument_text() -> str:
    return (
        "# Synthetic laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.15;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:20.0;X:0.8;Y:0.0;Z:0.0;SH/L:0.022\n"
    )


def set_limit(project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", float(lower), variable=variable)
    project.set_Controls("parmMax", float(upper), variable=variable)


def set_physical_limits(project, phases) -> None:
    for variable, lower, upper in [
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:SurfRoughA", 0.0, 0.65),
        (":0:SurfRoughB", 0.0, 0.55),
    ]:
        set_limit(project, variable, lower, upper)
    for phase in phases:
        pid = phase.data["pId"]
        for suffix, lower, upper in [
            ("Size;i", 0.04, 1.5),
            ("Mustrain;i", 1.0, 8000.0),
            ("Mustrain;a", 1.0, 12000.0),
            ("MD", 0.65, 1.5),
        ]:
            set_limit(project, f"{pid}:0:{suffix}", lower, upper)
        for atom_index, _ in enumerate(phase.atoms()):
            set_limit(project, f"{pid}::AUiso:{atom_index}", 0.001, 0.03)
            for axis in "xyz":
                set_limit(
                    project,
                    f"{pid}::dA{axis}:{atom_index}",
                    -0.05,
                    0.05,
                )


def set_cell_limits(project, phases, relative_half_width: float = 0.012) -> None:
    for phase in phases:
        pid = phase.data["pId"]
        cell = phase.data["General"]["Cell"][1:7]
        for index, value in enumerate(G2lat.cell2A(cell)):
            if abs(value) < 1e-12:
                continue
            delta = max(abs(value) * relative_half_width, 1e-6)
            set_limit(project, f"{pid}::A{index}", value - delta, value + delta)


def rwp(hist) -> float:
    _, observed, weights, calculated = hist.data["data"][1][:4]
    observed = np.asarray(observed, float)
    weights = np.asarray(weights, float)
    calculated = np.asarray(calculated, float)
    return float(
        100
        * np.sqrt(
            np.sum(weights * (observed - calculated) ** 2)
            / np.sum(weights * observed**2)
        )
    )


def fractions(phases, histogram: str) -> list[float]:
    values = np.array(
        [
            phase.data["General"]["Mass"]
            * phase.data["Histograms"][histogram]["Scale"][0]
            for phase in phases
        ]
    )
    return (values / values.sum()).tolist()


def refine(project, hist, phases, label: str, history: list[dict], cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    row = {
        "step": label,
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "frozen": project.get_Frozen(),
        "vary_list": [str(item) for item in (project.get_VaryList() or [])],
    }
    history.append(row)
    print(
        f"{label:28s} Rwp={row['rwp_percent']:.5f}% "
        f"fractions={row['fractions']} frozen={row['frozen']}",
        flush=True,
    )
    return row


def checkpoint(project, output: Path, name: str) -> None:
    project.save()
    shutil.copy2(project.filename, output / f"{name}.gpx")


def phase_details(phase, histogram: str) -> dict:
    hap = phase.data["Histograms"][histogram]
    return {
        "name": phase.name,
        "p_id": phase.data["pId"],
        "cell": phase.data["General"]["Cell"][1:],
        "mass": phase.data["General"]["Mass"],
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "refinement_flags": atom.refinement_flags,
                "uiso": atom.uiso,
            }
            for atom in phase.atoms()
        ],
    }


def run(wo3_model: str, output: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    inst = output / "instrument.instprm"
    inst.write_text(instrument_text())
    project_path = output / "bounded.gpx"
    project_path.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(project_path))
    hist = project.add_powder_histogram(str(OBSERVED), str(inst))
    phases = [
        project.add_phase(
            str(CANDIDATES / f"{name}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        for name in [CAWO4, wo3_model]
    ]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    set_physical_limits(project, phases)
    set_cell_limits(project, phases)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    for phase, fraction in zip(phases, [0.85, 0.15]):
        mass = phase.data["General"]["Mass"]
        phase.data["Histograms"][hist.name]["Scale"] = [
            10000.0 * fraction / mass,
            True,
        ]

    history: list[dict] = []
    refine(project, hist, phases, "scales_background", history)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, hist, phases, "angular_zero", history)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.set_Frozen(variable=":0:Zero")
    refine(project, hist, phases, "phase_cells", history)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.set_Frozen(variable=":0:Zero")
    refine(project, hist, phases, "zero_displacement", history)

    # Let phase-specific broadening absorb specimen effects before refining
    # the shared instrumental profile; otherwise W/X can be driven to a
    # nonphysical local minimum while compensating for crystallite breadth.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    refine(project, hist, phases, "phase_broadening", history)
    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, hist, phases, "profile_W_X", history)
    hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    refine(project, hist, phases, "instrument_profile", history)
    refine(project, hist, phases, "profile_settle", history)
    checkpoint(project, output, "profile_only")

    # The scheelite heavy-atom sites are symmetry-fixed; only oxygen has
    # positional freedom. Refine W first in WO3, followed by oxygen sites.
    for atom in phases[0].atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    for atom in phases[1].atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    refine(project, hist, phases, "heavy_coordinates", history)
    for atom in phases[1].atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine(project, hist, phases, "oxygen_coordinates", history, cycles=16)
    refine(project, hist, phases, "coordinate_settle", history, cycles=16)
    checkpoint(project, output, "coordinates")

    # Generation assigns one isotropic displacement value per phase. Tie all
    # independent sites within each phase to preserve that physical model.
    project.index_ids()
    for phase in phases:
        pid = phase.data["pId"]
        variables = [f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for atom in phase.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = (
                "XU" if "X" in atom.refinement_flags else "U"
            )
    refine(project, hist, phases, "phase_uiso", history, cycles=16)
    refine(project, hist, phases, "atomic_settle", history, cycles=16)
    checkpoint(project, output, "atomic")

    arrays = hist.data["data"][1]
    np.savetxt(
        output / "fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[4], arrays[5]]),
        delimiter=",",
        header="two_theta,observed,calculated,background,difference",
        comments="",
    )
    details = {
        "wo3_model": wo3_model,
        "rwp_percent": rwp(hist),
        "fractions": fractions(phases, hist.name),
        "history": history,
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": [phase_details(phase, hist.name) for phase in phases],
        "frozen": project.get_Frozen(),
    }
    (output / "details.json").write_text(
        json.dumps(details, indent=2, default=lambda value: value.tolist()) + "\n"
    )
    print(json.dumps({k: details[k] for k in ["rwp_percent", "fractions"]}))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="wo3_p21c_2311041")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    output = args.output or ROOT / "analysis" / "bounded" / args.wo3
    G2.SetPrintLevel("warn")
    run(args.wo3, output)


if __name__ == "__main__":
    main()
