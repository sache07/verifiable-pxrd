#!/usr/bin/env python3
"""Scan the bounded scheelite oxygen displacement."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "regularized_coordinate_scan" / "w0p535_o0p0" / "model.gpx"
PARENT = ROOT / "analysis" / "trials" / "wo3_p21c_2311041" / "trial.gpx"
TARGET = ROOT / "analysis" / "final_model_work" / "cell_test.gpx"
OUTPUT = ROOT / "analysis" / "cawo4_coordinate_scan"
FACTORS = [0.0, 0.25, 0.5, 0.75, 0.87]


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda values: np.asarray(values, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    parent = G2.G2Project(gpxfile=str(PARENT)).phase("cawo4_scheelite_7219229")
    target = G2.G2Project(gpxfile=str(TARGET)).phase("cawo4_scheelite_7219229")
    parent_atoms, target_atoms = list(parent.atoms()), list(target.atoms())
    rows = []
    for factor in FACTORS:
        folder = OUTPUT / str(factor).replace(".", "p")
        folder.mkdir(parents=True, exist_ok=True)
        project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(folder / "model.gpx"))
        hist = project.histograms()[0]
        phase = project.phase("cawo4_scheelite_7219229")
        for atom, parent_atom, target_atom in zip(phase.atoms(), parent_atoms, target_atoms):
            start = np.asarray(parent_atom.coordinates, float)
            delta = np.asarray(target_atom.coordinates, float) - start
            delta -= np.rint(delta)
            atom.coordinates = ((start + factor * delta) % 1).tolist()
            atom.refinement_flags = " "
        for item in project.phases():
            item.data["General"]["Cell"][0] = False
            hap = item.data["Histograms"][hist.name]
            hap["Scale"][1] = True
            hap["Size"][2][0] = True
        hist.Background[0][1] = True
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        masses = np.asarray(
            [item.data["General"]["Mass"] * item.data["Histograms"][hist.name]["Scale"][0] for item in project.phases()]
        )
        row = {
            "factor": factor,
            "oxygen_displacement_A": 0.05747173451975108 * factor,
            "rwp_percent": rwp(hist),
            "fractions": (masses / masses.sum()).tolist(),
            "project": str(project.filename),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["rwp_percent"])
    (OUTPUT / "comparison.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("BEST", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
