#!/usr/bin/env python3
"""Test physically bounded zero/height calibrations with cells re-refined."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "final_model_work" / "cell_test.gpx"
OUTPUT = ROOT / "analysis" / "calibration_scan"


def rwp(hist):
    _, obs, weight, calc = hist.data["data"][1][:4]
    obs, weight, calc = map(lambda values: np.asarray(values, float), (obs, weight, calc))
    return float(100 * np.sqrt(np.sum(weight * (obs - calc) ** 2) / np.sum(weight * obs**2)))


def fractions(phases, histogram):
    raw = np.asarray(
        [phase.data["General"]["Mass"] * phase.data["Histograms"][histogram]["Scale"][0] for phase in phases]
    )
    return (raw / raw.sum()).tolist()


def tag(value):
    return str(value).replace("-", "m").replace(".", "p")


def main():
    G2.SetPrintLevel("warn")
    OUTPUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for zero in (-0.25, -0.125, 0.0, 0.125, 0.25):
        for shift in (-800.0, -400.0, 0.0, 400.0, 800.0):
            trial_dir = OUTPUT / f"z{tag(zero)}_s{tag(shift)}"
            trial_dir.mkdir(parents=True, exist_ok=True)
            project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(trial_dir / "calibration.gpx"))
            hist = project.histograms()[0]
            phases = project.phases()
            hist.data["Instrument Parameters"][0]["Zero"][1:] = [zero, False]
            hist.SampleParameters["Shift"][:] = [shift, False]
            for phase in phases:
                phase.data["General"]["Cell"][0] = True
                for atom in phase.atoms():
                    atom.refinement_flags = " "
            project.set_Controls("cycles", 20)
            project.refine()
            project.save()
            row = {
                "zero_degrees": zero,
                "shift_micrometres": shift,
                "rwp_percent": rwp(hist),
                "fractions": fractions(phases, hist.name),
                "cells": {phase.name: phase.get_cell() for phase in phases},
                "project": str(project.filename.relative_to(ROOT)),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["rwp_percent"])
    (OUTPUT / "comparison.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("BEST", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
