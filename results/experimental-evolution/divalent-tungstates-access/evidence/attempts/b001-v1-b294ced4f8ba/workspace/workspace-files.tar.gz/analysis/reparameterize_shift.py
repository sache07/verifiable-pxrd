#!/usr/bin/env python3
"""Set a fixed instrumental zero and sample-displacement seed in a GSAS-II project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--zero", type=float, required=True)
    parser.add_argument("--shift", type=float, required=True)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.out))
    histogram = project.histograms()[0]
    histogram.InstrumentParameters["Zero"][1] = args.zero
    histogram.InstrumentParameters["Zero"][2] = False
    histogram.SampleParameters["Shift"] = [args.shift, False]
    project.save(str(args.out))


if __name__ == "__main__":
    main()
