#!/usr/bin/env python3
"""Seed an analogue-derived CIF at an indexed metric without changing topology."""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cell", type=float, nargs=6, metavar=("A", "B", "C", "ALPHA", "BETA", "GAMMA"), required=True)
    parser.add_argument("--symprec", type=float, default=0.001)
    parser.add_argument("--basis", required=True)
    args = parser.parse_args()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        source = Structure.from_file(args.source, primitive=False)
    lattice = Lattice.from_parameters(*args.cell)
    seeded = Structure(
        lattice,
        [site.species for site in source],
        source.frac_coords,
        coords_are_cartesian=False,
        site_properties=source.site_properties,
    )
    analyzer = SpacegroupAnalyzer(seeded, symprec=args.symprec, angle_tolerance=5.0)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(seeded, symprec=args.symprec).write_file(args.output)
    distances = seeded.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    report = {
        "source": str(args.source),
        "output": str(args.output),
        "transformation": "replace only the lattice metric; preserve species, occupancies, fractional coordinates and topology",
        "basis": args.basis,
        "source_cell": list(source.lattice.parameters),
        "seeded_cell": list(seeded.lattice.parameters),
        "composition": str(seeded.composition),
        "reduced_formula": seeded.composition.reduced_formula,
        "detected_space_group": [analyzer.get_space_group_symbol(), analyzer.get_space_group_number()],
        "minimum_interatomic_distance_A": float(np.min(distances)),
        "maximum_nearest_neighbor_distance_A": float(np.max(np.min(distances, axis=1))),
    }
    args.output.with_suffix(".provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
