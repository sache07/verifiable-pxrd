#!/usr/bin/env python3
"""Set selected GSAS-II sample parameter values without refining them."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--rough-a", type=float)
    parser.add_argument("--rough-b", type=float)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.out))
    sample = project.histograms()[0].SampleParameters
    if args.rough_a is not None:
        sample["SurfRoughA"] = [args.rough_a, False]
    if args.rough_b is not None:
        sample["SurfRoughB"] = [args.rough_b, False]
    project.save(str(args.out))


if __name__ == "__main__":
    main()
