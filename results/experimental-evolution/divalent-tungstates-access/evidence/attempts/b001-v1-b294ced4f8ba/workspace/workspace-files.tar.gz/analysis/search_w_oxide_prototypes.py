#!/usr/bin/env python3
"""Coarse whole-library search of X-W-O parents after X -> Mn substitution."""

from __future__ import annotations

import argparse
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Element, Structure
from scipy.ndimage import gaussian_filter1d


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06"
)
INDEX = RESOURCE / "index.json.gz"
CIF_ROOT = RESOURCE / "cif"


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def replace_cation(structure: Structure) -> Structure:
    transformed = structure.copy()
    for index, site in enumerate(structure):
        species = {}
        mn = 0.0
        for specie, occupancy in site.species.items():
            symbol = specie.element.symbol if hasattr(specie, "element") else specie.symbol
            if symbol in {"O", "W"}:
                element = Element(symbol)
                species[element] = species.get(element, 0.0) + float(occupancy)
            else:
                mn += float(occupancy)
        if mn:
            species[Element("Mn")] = species.get(Element("Mn"), 0.0) + mn
        transformed.replace(index, species)
    return transformed


def transformed_positions(two_theta: np.ndarray, cell_scale: float, offset: float) -> np.ndarray:
    theta = np.deg2rad(two_theta / 2.0)
    return 2.0 * np.rad2deg(np.arcsin(np.clip(np.sin(theta) / cell_scale, -1.0, 1.0))) + offset


def coarse_score(pattern, x: np.ndarray, standardized_residual: np.ndarray) -> dict:
    px = np.asarray(pattern.x, dtype=float)
    py = np.asarray(pattern.y, dtype=float)
    keep = py >= 2.0
    px, py = px[keep], py[keep]
    if len(px) > 80:
        order = np.argsort(py)[::-1][:80]
        px, py = px[order], py[order]
    norm = float(np.sqrt(np.sum(py * py)))
    best = {"score": -np.inf}
    for scale in np.linspace(0.85, 1.15, 61):
        base = transformed_positions(px, scale, 0.0)
        for offset in np.linspace(0.05, 0.65, 25):
            positions = base + offset
            values = np.interp(positions, x, standardized_residual, left=-20.0, right=-20.0)
            score = float(np.dot(py, values) / norm)
            if score > best["score"]:
                best = {"score": score, "cell_scale": float(scale), "offset_deg": float(offset)}
    return best


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile_csv", type=Path)
    parser.add_argument("--limit", type=int, default=80)
    args = parser.parse_args()
    data = np.genfromtxt(args.profile_csv, delimiter=",", names=True)
    x = data["two_theta_deg"]
    step = float(np.median(np.diff(x)))
    smooth = gaussian_filter1d(data["difference"], 0.25 / 2.35482 / step)
    standardized = smooth / np.sqrt(np.maximum(data["observed"], 1.0))
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    calculator = XRDCalculator(wavelength="CuKa")
    rows = []
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "O" not in elements or "W" not in elements:
            continue
        parent_cation = next(element for element in elements if element not in {"O", "W"})
        for formula, cod_id, sg, cod_residual in records:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    parent = Structure.from_file(cif_path(cod_id), primitive=False)
                    target = replace_cation(parent)
                    composition = target.composition.get_el_amt_dict()
                    w = composition.get("W", 0.0)
                    mn_w = composition.get("Mn", 0.0) / w
                    o_w = composition.get("O", 0.0) / w
                    if w <= 0 or not (0.05 <= mn_w <= 4.0 and 1.0 <= o_w <= 8.0):
                        continue
                    pattern = calculator.get_pattern(target, two_theta_range=(9.5, 101.0))
                    result = coarse_score(pattern, x, standardized)
                rows.append(
                    {
                        "parent_formula": formula,
                        "parent_cation": parent_cation,
                        "parent_id": cod_id,
                        "parent_space_group": sg,
                        "target_formula": target.composition.reduced_formula,
                        "mn_per_w": mn_w,
                        "o_per_w": o_w,
                        "cod_residual": cod_residual,
                        **result,
                    }
                )
            except Exception as exc:
                rows.append({"parent_formula": formula, "parent_id": cod_id, "status": repr(exc), "score": -1e30})
    rows.sort(key=lambda row: row["score"], reverse=True)
    print(json.dumps(rows[: args.limit], indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
