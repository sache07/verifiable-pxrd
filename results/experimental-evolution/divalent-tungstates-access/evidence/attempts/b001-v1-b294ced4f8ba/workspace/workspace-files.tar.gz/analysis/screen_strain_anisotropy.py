#!/usr/bin/env python3
"""Screen one physically allowed uniaxial microstrain term at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from branch_candidate import clear_nuisance_flags
from rietveld_trials import snapshot, validate


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    reference = G2.G2Project(gpxfile=str(args.base))
    phase_names = [phase.name for phase in reference.phases()]
    rows = []
    for phase_name in phase_names:
        for axis in AXES:
            label = phase_name + "_" + "".join(str(v) for v in axis)
            trial_dir = args.out / label
            trial_dir.mkdir(parents=True, exist_ok=True)
            row = {"phase": phase_name, "axis": axis, "status": "unknown"}
            try:
                project = G2.G2Project(
                    gpxfile=str(args.base), newgpx=str(trial_dir / "trial.gpx")
                )
                clear_nuisance_flags(project)
                hist = project.histograms()[0]
                phase = next(item for item in project.phases() if item.name == phase_name)
                hap = phase.data["Histograms"][hist.name]
                strain = abs(float(hap["Mustrain"][1][0]))
                hap["Mustrain"][1][0] = strain
                hap["Mustrain"][1][1] = strain
                phase.set_HAP_refinements(
                    {
                        "Mustrain": {
                            "type": "uniaxial",
                            "direction": list(axis),
                            "refine": True,
                        }
                    }
                )
                project.set_Controls("cycles", args.cycles)
                listing = trial_dir / "trial.lst"
                project.refine(printFile=str(listing))
                log = listing.read_text(errors="replace") if listing.exists() else ""
                if "Refinement failed" in log or "Refinement error" in log:
                    raise RuntimeError("GSAS-II reported refinement failure")
                validate(project)
                state = snapshot(project, trial_dir, "final")
                values = [float(v) for v in hap["Mustrain"][1][:2]]
                if any(not 0 < abs(v) < 50000 for v in values):
                    raise ValueError(f"invalid uniaxial strain values {values}")
                row.update(
                    status="tested",
                    rwp_percent=state["rwp_percent"],
                    fractions=state["fractions"],
                    strain_ppm=values,
                    ratio=abs(values[1] / values[0]),
                    gpx=str(trial_dir / "trial.gpx"),
                )
                project.save(str(trial_dir / "trial.gpx"))
            except Exception as exc:
                row["error"] = repr(exc)
            rows.append(row)
            print(row)
    rows.sort(key=lambda row: row.get("rwp_percent", 1e30))
    (args.out / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
