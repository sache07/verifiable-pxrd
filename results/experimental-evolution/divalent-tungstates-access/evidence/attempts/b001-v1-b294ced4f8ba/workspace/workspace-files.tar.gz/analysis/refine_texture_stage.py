#!/usr/bin/env python3
"""Refine one explicitly selected March-Dollase term from a stable project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from branch_candidate import clear_nuisance_flags
from rietveld_trials import snapshot, validate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--cycles", type=int, default=20)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    result = {"status": "unknown", "base": str(args.base), "phase": args.phase, "axis": args.axis}
    try:
        project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.out / "stage.gpx"))
        clear_nuisance_flags(project)
        histogram = project.histograms()[0]
        phase = next(item for item in project.phases() if item.name == args.phase)
        preferred = phase.data["Histograms"][histogram.name]["Pref.Ori."]
        preferred[0] = "MD"
        preferred[2] = True
        preferred[3] = list(args.axis)
        project.set_Controls("cycles", args.cycles)
        listing = args.out / "texture.lst"
        project.refine(printFile=str(listing))
        text = listing.read_text(errors="replace") if listing.exists() else ""
        if "Refinement failed" in text or "Refinement error" in text:
            raise RuntimeError("GSAS-II reported refinement failure")
        validate(project)
        ratio = float(preferred[1])
        if not 0.2 < ratio < 5.0:
            raise ValueError(f"invalid March-Dollase ratio {ratio}")
        state = snapshot(project, args.out, "texture")
        project.save(str(args.out / "stage.gpx"))
        for index, item in enumerate(project.phases(), start=1):
            item.export_CIF(str(args.out / f"phase_{index}_{item.name}.cif"))
        result.update(status="tested", md_ratio=ratio, final=state)
        print(json.dumps({"rwp_percent": state["rwp_percent"], "md_ratio": ratio, "fractions": state["fractions"]}, indent=2))
    except Exception as exc:
        result["error"] = repr(exc)
        raise
    finally:
        (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
