#!/usr/bin/env python3
"""Add one candidate to a stable GSAS-II project and test it reproducibly."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from rietveld_trials import snapshot, validate


def clear_nuisance_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def run_refinement(project: G2.G2Project, outdir: Path, label: str, stages: list[dict]) -> None:
    listing = outdir / f"{label}.lst"
    project.set_Controls("cycles", 8)
    project.refine(printFile=str(listing))
    text = listing.read_text(errors="replace") if listing.exists() else ""
    if "Refinement failed" in text or "Refinement error" in text:
        raise RuntimeError(f"GSAS-II failure in {label}")
    validate(project)
    stages.append(snapshot(project, outdir, label))
    print(label, stages[-1]["rwp_percent"], stages[-1]["fractions"])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    result = {
        "base": str(args.base),
        "candidate": str(args.candidate),
        "name": args.name,
        "status": "unknown",
        "stages": [],
    }
    try:
        project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.out / "trial.gpx"))
        if any(phase.name == args.name for phase in project.phases()):
            raise ValueError(f"duplicate phase name {args.name}")
        clear_nuisance_flags(project)
        hist = project.histograms()[0]
        baseline_mass_scale = sum(
            phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        )
        candidate = project.add_phase(
            str(args.candidate.resolve()),
            phasename=args.name,
            histograms=[hist],
            fmthint="CIF",
        )
        hap = candidate.data["Histograms"][hist.name]
        hap["Use"] = True
        # Explicit 5 wt% positive start; this is reset by the linear scale fit.
        initial_mass_scale = baseline_mass_scale * 0.05 / 0.95
        hap["Scale"] = [float(initial_mass_scale / candidate.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        project.save()
        result["stages"].append(snapshot(project, args.out, "00_initialized"))

        # Common baseline: only phase scales and the existing background move.
        run_refinement(project, args.out, "01_scales_background", result["stages"])
        scale = float(candidate.data["Histograms"][hist.name]["Scale"][0])
        if not math.isfinite(scale) or scale <= 0:
            result["status"] = "rejected"
            result["reason"] = "candidate scale collapsed under the common nuisance model"
        else:
            # Then release only this candidate's symmetry-independent cell terms.
            candidate.set_refinements({"Cell": True})
            run_refinement(project, args.out, "02_candidate_cell", result["stages"])
            result["status"] = "tested"
        result["final"] = result["stages"][-1]
        project.save(str(args.out / "trial.gpx"))
    except Exception as exc:
        result["status"] = "unknown"
        result["error"] = repr(exc)
        raise
    finally:
        (args.out / "summary.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
