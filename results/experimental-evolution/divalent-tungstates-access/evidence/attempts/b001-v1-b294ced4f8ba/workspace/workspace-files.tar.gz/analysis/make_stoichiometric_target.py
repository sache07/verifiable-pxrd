#!/usr/bin/env python3
"""Map a two-cation oxide prototype onto a target by cation multiplicity."""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--major", default="Mn", help="target element for the more abundant cation")
    parser.add_argument("--minor", default="W", help="target element for the less abundant cation")
    parser.add_argument("--symprec", type=float, default=0.001)
    args = parser.parse_args()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        parent = Structure.from_file(args.parent, primitive=False)
    amounts = parent.composition.get_el_amt_dict()
    cations = [(element, amount) for element, amount in amounts.items() if element != "O"]
    if len(cations) != 2:
        raise ValueError(f"expected exactly two non-oxygen elements, got {cations}")
    cations.sort(key=lambda item: item[1], reverse=True)
    mapping = {cations[0][0]: args.major, cations[1][0]: args.minor}
    target = parent.copy()
    for index, site in enumerate(parent):
        species = {}
        for specie, occupancy in site.species.items():
            symbol = specie.element.symbol if hasattr(specie, "element") else specie.symbol
            mapped = mapping.get(symbol, symbol)
            element = Element(mapped)
            species[element] = species.get(element, 0.0) + float(occupancy)
        target.replace(index, species)
    analyzer = SpacegroupAnalyzer(target, symprec=args.symprec, angle_tolerance=5.0)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(target, symprec=args.symprec).write_file(args.output)
    distances = target.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    report = {
        "parent": str(args.parent),
        "output": str(args.output),
        "transformation": "map the more abundant cation species to Mn and the less abundant cation species to W; preserve occupancies, fractional coordinates, lattice and topology",
        "mapping": mapping,
        "parent_composition": str(parent.composition),
        "target_composition": str(target.composition),
        "target_reduced_formula": target.composition.reduced_formula,
        "detected_space_group": [analyzer.get_space_group_symbol(), analyzer.get_space_group_number()],
        "minimum_interatomic_distance_A": float(np.min(distances)),
        "maximum_nearest_neighbor_distance_A": float(np.max(np.min(distances, axis=1))),
    }
    args.output.with_suffix(".provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
