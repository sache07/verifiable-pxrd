#!/usr/bin/env python3
"""Apply one explicitly selected GSAS-II refinement stage to a stable project."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from branch_candidate import clear_nuisance_flags
from rietveld_trials import snapshot, validate


def names(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def selected_phases(project: G2.G2Project, value: str) -> list:
    if value == "all":
        return project.phases()
    requested = set(names(value))
    found = [phase for phase in project.phases() if phase.name in requested]
    missing = requested - {phase.name for phase in found}
    if missing:
        raise ValueError(f"phase names not found: {sorted(missing)}")
    return found


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--label", required=True)
    parser.add_argument("--cells", default="")
    parser.add_argument("--instrument", default="")
    parser.add_argument("--sample", default="")
    parser.add_argument("--mustrain", default="")
    parser.add_argument("--size", default="")
    parser.add_argument("--coordinates", action="append", default=[], metavar="PHASE:E1,E2")
    parser.add_argument("--cycles", type=int, default=12)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    result = {"base": str(args.base), "label": args.label, "status": "unknown"}
    try:
        project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.out / "stage.gpx"))
        clear_nuisance_flags(project)
        hist = project.histograms()[0]
        if args.cells:
            for phase in selected_phases(project, args.cells):
                phase.set_refinements({"Cell": True})
        if args.instrument:
            hist.set_refinements({"Instrument Parameters": names(args.instrument)})
        for parameter in names(args.sample):
            value = hist.SampleParameters.get(parameter)
            if not isinstance(value, list) or len(value) < 2:
                raise ValueError(f"sample parameter is not refinable: {parameter}")
            value[1] = True
        if args.mustrain:
            for phase in selected_phases(project, args.mustrain):
                phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        if args.size:
            for phase in selected_phases(project, args.size):
                phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        refined_atoms = {}
        for specification in args.coordinates:
            phase_name, separator, element_text = specification.partition(":")
            if not separator:
                raise ValueError("--coordinates requires PHASE:E1,E2 (empty element list means all)")
            phase = next(item for item in project.phases() if item.name == phase_name)
            elements = set(names(element_text))
            labels = []
            for atom in phase.atoms():
                if not elements or atom.element in elements:
                    atom.refinement_flags = "X"
                    labels.append(atom.label)
            refined_atoms[phase_name] = labels
        project.set_Controls("cycles", args.cycles)
        listing = args.out / f"{args.label}.lst"
        project.refine(printFile=str(listing))
        log = listing.read_text(errors="replace") if listing.exists() else ""
        if "Refinement failed" in log or "Refinement error" in log:
            raise RuntimeError("GSAS-II reported refinement failure")
        validate(project)
        state = snapshot(project, args.out, args.label)
        project.save(str(args.out / "stage.gpx"))
        for index, phase in enumerate(project.phases(), start=1):
            phase.export_CIF(str(args.out / f"phase_{index}_{phase.name}.cif"))
        shifts = [float(value) for value in re.findall(r"Maximum shift/esd = ([0-9.eE+-]+)", log)]
        result.update(
            status="tested",
            selections={
                "cells": args.cells,
                "instrument": names(args.instrument),
                "sample": names(args.sample),
                "mustrain": args.mustrain,
                "size": args.size,
                "refined_atoms": refined_atoms,
            },
            maximum_shift_over_esd=shifts[-1] if shifts else None,
            final=state,
        )
        print(json.dumps({"rwp_percent": state["rwp_percent"], "fractions": state["fractions"], "maximum_shift_over_esd": result["maximum_shift_over_esd"]}, indent=2))
    except Exception as exc:
        result["error"] = repr(exc)
        raise
    finally:
        (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
