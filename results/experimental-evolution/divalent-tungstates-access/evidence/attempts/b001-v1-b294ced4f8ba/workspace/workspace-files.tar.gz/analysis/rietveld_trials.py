#!/usr/bin/env python3
"""Build reproducible GSAS-II candidate trials for the supplied PXRD scan.

Run this with the GSAS-II Python interpreter. Each invocation starts from the
same nuisance model and activates only the phases named on the command line.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


WAVELENGTH_1 = 1.540598
WAVELENGTH_2 = 1.544426


def write_inputs(pattern: Path, outdir: Path) -> tuple[Path, Path]:
    data = np.genfromtxt(pattern, delimiter=",", skip_header=1)
    x, y = data.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = outdir / "observed.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "# Candidate-screen GSAS-II instrument model\n"
        "Type:PXC;Bank:1\n"
        f"Lam1:{WAVELENGTH_1};Lam2:{WAVELENGTH_2};I(L2)/I(L1):0.5\n"
        "Zero:0.30;Polariz.:0.70;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:15.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def phase_fraction(project: G2.G2Project, histogram_name: str) -> dict[str, float]:
    weights = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram_name]
        weights[phase.name] = float(phase.data["General"]["Mass"] * hap["Scale"][0])
    total = sum(max(value, 0.0) for value in weights.values())
    if total <= 0:
        return {name: 0.0 for name in weights}
    return {name: max(value, 0.0) / total for name, value in weights.items()}


def snapshot(project: G2.G2Project, outdir: Path, label: str) -> dict:
    project.save()
    target = outdir / f"{label}.gpx"
    shutil.copy2(project.filename, target)
    hist = project.histograms()[0]
    cells = {phase.name: phase.get_cell() for phase in project.phases()}
    scales = {
        phase.name: float(phase.data["Histograms"][hist.name]["Scale"][0])
        for phase in project.phases()
    }
    return {
        "stage": label,
        "rwp_percent": None if hist.get_wR() is None else float(hist.get_wR()),
        "residuals": {
            key: float(value)
            for key, value in hist.residuals.items()
            if isinstance(value, (int, float, np.floating)) and math.isfinite(float(value))
        },
        "fractions": phase_fraction(project, hist.name),
        "scales": scales,
        "cells": cells,
        "instrument": {
            key: list(value) if isinstance(value, (list, tuple)) else value
            for key, value in hist.InstrumentParameters.items()
        },
        "sample": {
            key: list(value) if isinstance(value, (list, tuple)) else value
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale", "Type", "Gonio. radius"}
        },
    }


def validate(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    for phase in project.phases():
        cell = phase.get_cell()
        if not all(math.isfinite(float(value)) for value in cell.values()):
            raise ValueError(f"nonfinite cell for {phase.name}")
        if min(cell[axis] for axis in ("length_a", "length_b", "length_c")) <= 1.0:
            raise ValueError(f"invalid cell length for {phase.name}: {cell}")
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        if not math.isfinite(scale) or scale < 0:
            raise ValueError(f"invalid scale for {phase.name}: {scale}")


def refine(project: G2.G2Project, outdir: Path, label: str, stages: list[dict]) -> None:
    project.set_Controls("cycles", 8)
    project.refine(printFile=str(outdir / f"{label}.lst"))
    validate(project)
    stages.append(snapshot(project, outdir, label))
    print(label, "Rwp", stages[-1]["rwp_percent"], "fractions", stages[-1]["fractions"])


def build_trial(
    pattern: Path,
    outdir: Path,
    phase_specs: list[tuple[str, Path]],
    profile: bool,
    phase_profile: bool,
) -> dict:
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(pattern, outdir)
    project = G2.G2Project(newgpx=str(outdir / "trial.gpx"))
    phases = []
    for name, path in phase_specs:
        phases.append(project.add_phase(str(path.resolve()), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(str(xye), str(inst), phases="all", fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(np.min(hist.data["data"][1][0])), float(np.max(hist.data["data"][1][0]))],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1500.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    # Every candidate is explicitly active, positive and independently scaled.
    for index, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"] = [5.0 if index == 0 else 1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
    stages: list[dict] = []
    project.save()
    stages.append(snapshot(project, outdir, "00_initialized"))

    # Common nuisance baseline: scales/background and a physically shared angular correction.
    # A single angular correction is identifiable here; simultaneous Zero and
    # specimen Shift are nearly singular on this range, so Shift stays fixed.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, outdir, "01_scale_background_shift", stages)

    # Symmetry-independent cell terms are released for all active candidates.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, outdir, "02_cells", stages)

    if profile:
        # Instrument terms common to all phases, followed by one isotropic specimen term at a time.
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        refine(project, outdir, "03_instrument_profile", stages)
    if phase_profile:
        if not profile:
            raise ValueError("--phase-profile requires --profile")
        for phase in phases:
            phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        refine(project, outdir, "04_isotropic_strain", stages)
        for phase in phases:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.5, "refine": True}})
        refine(project, outdir, "05_isotropic_size", stages)

    project.save(str(outdir / "trial.gpx"))
    summary = {
        "status": "tested",
        "pattern": str(pattern),
        "phases": [{"name": name, "cif": str(path)} for name, path in phase_specs],
        "stages": stages,
        "final": stages[-1],
    }
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    return summary


def parse_phase(value: str) -> tuple[str, Path]:
    if "=" not in value:
        raise argparse.ArgumentTypeError("phase must be NAME=PATH")
    name, path = value.split("=", 1)
    if not name or not Path(path).is_file():
        raise argparse.ArgumentTypeError(f"invalid phase specification: {value}")
    return name, Path(path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--phase", action="append", type=parse_phase, required=True)
    parser.add_argument("--profile", action="store_true")
    parser.add_argument("--phase-profile", action="store_true")
    args = parser.parse_args()
    try:
        build_trial(args.pattern, args.out, args.phase, args.profile, args.phase_profile)
    except Exception as exc:
        args.out.mkdir(parents=True, exist_ok=True)
        (args.out / "failure.json").write_text(
            json.dumps({"status": "unknown", "error": repr(exc)}, indent=2) + "\n"
        )
        raise


if __name__ == "__main__":
    main()
