#!/usr/bin/env python3
"""Rank two-cation oxide frameworks after chemically allowed Mn/W mapping.

The frozen library is searched without requiring either target element in the
parent.  Both cation assignments are considered, but a candidate is retained
only when W(VI) gives a plausible mean Mn oxidation state and the mapped
structure has no hard contact or isolated site.
"""

from __future__ import annotations

import argparse
import gzip
import json
import warnings
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure
from scipy.ndimage import gaussian_filter1d

from search_w_oxide_prototypes import coarse_score


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06"
)
INDEX = RESOURCE / "index.json.gz"
CIF_ROOT = RESOURCE / "cif"


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def map_structure(parent: Structure, mapping: dict[str, str]) -> Structure:
    target = parent.copy()
    for index, site in enumerate(parent):
        species = {}
        for specie, occupancy in site.species.items():
            symbol = specie.element.symbol if hasattr(specie, "element") else specie.symbol
            mapped = Element(mapping.get(symbol, symbol))
            species[mapped] = species.get(mapped, 0.0) + float(occupancy)
        target.replace(index, species)
    return target


def worker(task: tuple) -> list[dict]:
    formula, cod_id, sg, cod_residual, assignments, x, standardized = task
    rows = []
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            parent = Structure.from_file(cif_path(cod_id), primitive=False)
        if len(parent) > 180:
            return rows
        for mapping, mean_mn_oxidation in assignments:
            try:
                target = map_structure(parent, mapping)
                distances = target.distance_matrix.copy()
                np.fill_diagonal(distances, np.inf)
                nearest = np.min(distances, axis=1)
                minimum = float(np.min(nearest))
                maximum_nearest = float(np.max(nearest))
                if minimum < 1.45 or maximum_nearest > 3.15:
                    continue
                pattern = XRDCalculator(wavelength="CuKa").get_pattern(
                    target, two_theta_range=(9.5, 101.0)
                )
                result = coarse_score(pattern, x, standardized)
                rows.append(
                    {
                        "parent_formula": formula,
                        "parent_id": cod_id,
                        "parent_space_group": sg,
                        "mapping": mapping,
                        "target_formula": target.composition.reduced_formula,
                        "mean_mn_oxidation": mean_mn_oxidation,
                        "cell": list(parent.lattice.parameters),
                        "minimum_distance_A": minimum,
                        "maximum_nearest_neighbor_A": maximum_nearest,
                        "cod_residual": cod_residual,
                        **result,
                    }
                )
            except Exception:
                continue
    except Exception:
        return rows
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile_csv", type=Path)
    parser.add_argument("--limit", type=int, default=200)
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()

    data = np.genfromtxt(args.profile_csv, delimiter=",", names=True)
    x = np.asarray(data["two_theta_deg"], dtype=float)
    step = float(np.median(np.diff(x)))
    smooth = gaussian_filter1d(data["difference"], 0.25 / 2.35482 / step)
    standardized = smooth / np.sqrt(np.maximum(data["observed"], 1.0))

    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)

    tasks = []
    seen = set()
    for key, records in index.items():
        elements = key.split("-")
        cations = [element for element in elements if element != "O"]
        if "O" not in elements or len(cations) != 2:
            continue
        for formula, cod_id, sg, cod_residual in records:
            if cod_id in seen:
                continue
            seen.add(cod_id)
            try:
                amounts = Composition(formula).get_el_amt_dict()
                oxygen = float(amounts.get("O", 0.0))
                actual_cations = [e for e, n in amounts.items() if e != "O" and n > 1e-6]
                if oxygen <= 0 or len(actual_cations) != 2:
                    continue
                assignments = []
                for mn_parent, w_parent in (
                    (actual_cations[0], actual_cations[1]),
                    (actual_cations[1], actual_cations[0]),
                ):
                    mn = float(amounts[mn_parent])
                    tungsten = float(amounts[w_parent])
                    if mn <= 0 or tungsten <= 0:
                        continue
                    mean_mn_oxidation = (2.0 * oxygen - 6.0 * tungsten) / mn
                    if not 1.5 <= mean_mn_oxidation <= 4.25:
                        continue
                    # Exclude extreme, chemically uninformative ratios.
                    if not 0.10 <= mn / tungsten <= 6.0:
                        continue
                    assignments.append(
                        ({mn_parent: "Mn", w_parent: "W"}, float(mean_mn_oxidation))
                    )
                if not assignments:
                    continue
                tasks.append((formula, cod_id, sg, cod_residual, assignments, x, standardized))
            except Exception:
                continue

    rows = []
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        for result in executor.map(worker, tasks, chunksize=8):
            rows.extend(result)
    rows.sort(key=lambda row: row["score"], reverse=True)
    print(json.dumps({"screened_records": len(tasks), "results": rows[: args.limit]}, indent=2))


if __name__ == "__main__":
    main()
