#!/usr/bin/env python3
"""Search binary oxide parents after cation -> Mn substitution."""

from __future__ import annotations

import argparse
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Element, Structure
from scipy.ndimage import gaussian_filter1d

from search_w_oxide_prototypes import coarse_score


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06"
)
INDEX = RESOURCE / "index.json.gz"
CIF_ROOT = RESOURCE / "cif"


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def replace_with_mn(structure: Structure) -> Structure:
    transformed = structure.copy()
    for index, site in enumerate(structure):
        species = {}
        mn = 0.0
        for specie, occupancy in site.species.items():
            symbol = specie.element.symbol if hasattr(specie, "element") else specie.symbol
            if symbol == "O":
                species[Element("O")] = species.get(Element("O"), 0.0) + float(occupancy)
            else:
                mn += float(occupancy)
        if mn:
            species[Element("Mn")] = species.get(Element("Mn"), 0.0) + mn
        transformed.replace(index, species)
    return transformed


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile_csv", type=Path)
    parser.add_argument("--limit", type=int, default=100)
    args = parser.parse_args()
    data = np.genfromtxt(args.profile_csv, delimiter=",", names=True)
    x = data["two_theta_deg"]
    step = float(np.median(np.diff(x)))
    smooth = gaussian_filter1d(data["difference"], 0.25 / 2.35482 / step)
    standardized = smooth / np.sqrt(np.maximum(data["observed"], 1.0))
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    calculator = XRDCalculator(wavelength="CuKa")
    rows = []
    target_ratios = [1.0, 4.0 / 3.0, 1.5, 2.0]
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 2 or "O" not in elements:
            continue
        parent_cation = next(element for element in elements if element != "O")
        for formula, cod_id, sg, cod_residual in records:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    parent = Structure.from_file(cif_path(cod_id), primitive=False)
                    target = replace_with_mn(parent)
                    composition = target.composition.get_el_amt_dict()
                    ratio = composition.get("O", 0.0) / composition.get("Mn", 1.0)
                    if min(abs(ratio - value) for value in target_ratios) > 0.03:
                        continue
                    pattern = calculator.get_pattern(target, two_theta_range=(9.5, 101.0))
                    result = coarse_score(pattern, x, standardized)
                rows.append(
                    {
                        "parent_formula": formula,
                        "parent_cation": parent_cation,
                        "parent_id": cod_id,
                        "parent_space_group": sg,
                        "target_formula": target.composition.reduced_formula,
                        "oxygen_per_mn": ratio,
                        "cod_residual": cod_residual,
                        **result,
                    }
                )
            except Exception as exc:
                rows.append({"parent_formula": formula, "parent_id": cod_id, "status": repr(exc), "score": -1e30})
    rows.sort(key=lambda row: row["score"], reverse=True)
    print(json.dumps(rows[: args.limit], indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
