#!/usr/bin/env python3
"""Search all two-cation A2BO6 oxide prototypes after mapping A -> Mn, B -> W."""

from __future__ import annotations

import argparse
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Element, Structure
from scipy.ndimage import gaussian_filter1d

from search_w_oxide_prototypes import coarse_score


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06"
)
INDEX = RESOURCE / "index.json.gz"
CIF_ROOT = RESOURCE / "cif"


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def mapped_target(parent: Structure) -> tuple[Structure, dict[str, str]] | None:
    amounts = parent.composition.get_el_amt_dict()
    if "O" not in amounts:
        return None
    cations = [(name, value) for name, value in amounts.items() if name != "O"]
    if len(cations) != 2:
        return None
    cations.sort(key=lambda item: item[1], reverse=True)
    major, minor = cations
    scale = minor[1]
    ratios = (major[1] / scale, amounts["O"] / scale)
    if abs(ratios[0] - 2.0) > 0.08 or abs(ratios[1] - 6.0) > 0.15:
        return None
    mapping = {major[0]: "Mn", minor[0]: "W"}
    target = parent.copy()
    for index, site in enumerate(parent):
        species = {}
        for specie, occupancy in site.species.items():
            symbol = specie.element.symbol if hasattr(specie, "element") else specie.symbol
            mapped = mapping.get(symbol, symbol)
            element = Element(mapped)
            species[element] = species.get(element, 0.0) + float(occupancy)
        target.replace(index, species)
    return target, mapping


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile_csv", type=Path)
    parser.add_argument("--limit", type=int, default=100)
    args = parser.parse_args()
    data = np.genfromtxt(args.profile_csv, delimiter=",", names=True)
    x = data["two_theta_deg"]
    step = float(np.median(np.diff(x)))
    smooth = gaussian_filter1d(data["difference"], 0.25 / 2.35482 / step)
    standardized = smooth / np.sqrt(np.maximum(data["observed"], 1.0))
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    calculator = XRDCalculator(wavelength="CuKa")
    rows = []
    seen = set()
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "O" not in elements:
            continue
        for formula, cod_id, sg, cod_residual in records:
            if cod_id in seen:
                continue
            seen.add(cod_id)
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    parent = Structure.from_file(cif_path(cod_id), primitive=False)
                    mapped = mapped_target(parent)
                    if mapped is None:
                        continue
                    target, mapping = mapped
                    distances = target.distance_matrix.copy()
                    np.fill_diagonal(distances, np.inf)
                    minimum_distance = float(np.min(distances))
                    if minimum_distance < 1.45:
                        continue
                    pattern = calculator.get_pattern(target, two_theta_range=(9.5, 101.0))
                    result = coarse_score(pattern, x, standardized)
                rows.append(
                    {
                        "parent_formula": formula,
                        "parent_id": cod_id,
                        "parent_space_group": sg,
                        "mapping": mapping,
                        "target_formula": target.composition.reduced_formula,
                        "cell": list(parent.lattice.parameters),
                        "minimum_distance_A": minimum_distance,
                        "cod_residual": cod_residual,
                        **result,
                    }
                )
            except Exception as exc:
                rows.append({"parent_formula": formula, "parent_id": cod_id, "status": repr(exc), "score": -1e30})
    rows.sort(key=lambda row: row["score"], reverse=True)
    print(json.dumps(rows[: args.limit], indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
