#!/usr/bin/env python3
"""Inspect a GSAS-II powder histogram and map coherent residual peaks."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks


def serial(value):
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--prominence", type=float, default=250.0)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.gpx))
    hist = project.histograms()[0]
    arrays = [np.asarray(a, dtype=float) for a in hist.data["data"][1][:6]]
    x, observed, weight, calculated, background, residual = arrays
    # GSAS stores observed-calculated in the sixth row; recompute to make the
    # sign convention explicit and guard against stale plotting arrays.
    residual = observed - calculated
    smooth = gaussian_filter1d(residual, 2.0)
    positive, pprop = find_peaks(smooth, prominence=args.prominence, distance=5)
    negative, nprop = find_peaks(-smooth, prominence=args.prominence, distance=5)
    porder = np.argsort(pprop["prominences"])[::-1]
    norder = np.argsort(nprop["prominences"])[::-1]
    positive_rows = [
        {"two_theta_deg": float(x[positive[i]]), "residual_counts": float(smooth[positive[i]]),
         "prominence_counts": float(pprop["prominences"][i])}
        for i in porder
    ]
    negative_rows = [
        {"two_theta_deg": float(x[negative[i]]), "residual_counts": float(smooth[negative[i]]),
         "prominence_counts": float(nprop["prominences"][i])}
        for i in norder
    ]
    phase_rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if not hap or not hap.get("Use", True):
            continue
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass_scale)
        phase_rows.append(
            {
                "name": phase.name,
                "mass_scale": mass_scale,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size": serial(hap["Size"]),
                "microstrain": serial(hap["Mustrain"]),
                "preferred_orientation": serial(hap["Pref.Ori."]),
            }
        )
    total = sum(masses)
    for row in phase_rows:
        row["weight_fraction"] = row["mass_scale"] / total
    q = 1.0 / np.maximum(observed, 1.0)
    rwp = 100.0 * np.sqrt(np.sum(q * residual**2) / np.sum(q * observed**2))
    report = {
        "gpx": str(args.gpx),
        "histogram": hist.name,
        "rwp_percent_recomputed": float(rwp),
        "gsas_residuals": serial(hist.residuals),
        "instrument": serial(hist.InstrumentParameters),
        "sample": serial(hist.SampleParameters),
        "background": serial(hist.Background),
        "phases": phase_rows,
        "positive_residual_peaks": positive_rows,
        "negative_residual_peaks": negative_rows,
    }
    (args.out / "inspection.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    np.savetxt(
        args.out / "profile.csv",
        np.column_stack((x, observed, calculated, residual, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    print("Rwp", rwp)
    print("positive", positive_rows[:30])
    print("negative", negative_rows[:20])


if __name__ == "__main__":
    main()
