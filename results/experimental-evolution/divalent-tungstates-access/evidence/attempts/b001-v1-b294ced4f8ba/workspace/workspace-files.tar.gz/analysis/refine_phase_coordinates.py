#!/usr/bin/env python3
"""Release symmetry-allowed coordinates for one named phase only."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from branch_candidate import clear_nuisance_flags
from rietveld_trials import snapshot, validate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--elements", default="", help="comma-separated subset; empty means all atoms")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    selected = {item.strip() for item in args.elements.split(",") if item.strip()}
    result = {"base": str(args.base), "phase": args.phase, "status": "unknown", "stages": []}
    try:
        project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.out / "trial.gpx"))
        clear_nuisance_flags(project)
        phase = next(item for item in project.phases() if item.name == args.phase)
        refined_atoms = []
        for atom in phase.atoms():
            if not selected or atom.element in selected:
                atom.refinement_flags = "X"
                refined_atoms.append(atom.label)
        if not refined_atoms:
            raise ValueError("no atoms selected")
        project.set_Controls("cycles", 12)
        listing = args.out / "coordinates.lst"
        project.refine(printFile=str(listing))
        log = listing.read_text(errors="replace") if listing.exists() else ""
        if "Refinement failed" in log or "Refinement error" in log:
            raise RuntimeError("GSAS-II reported refinement failure")
        validate(project)
        state = snapshot(project, args.out, "coordinates")
        project.save(str(args.out / "trial.gpx"))
        phase.export_CIF(str(args.out / "phase.cif"))
        result.update(status="tested", refined_atoms=refined_atoms, final=state)
        print(state["rwp_percent"], state["fractions"])
    except Exception as exc:
        result["error"] = repr(exc)
        raise
    finally:
        (args.out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
