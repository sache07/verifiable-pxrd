#!/usr/bin/env python3
"""Set an identifiable, physical common-profile baseline in a GSAS project."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--u", type=float, default=15.0)
    parser.add_argument("--x", type=float, default=2.0)
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.out))
    hist = project.histograms()[0]
    for name, value in (("U", args.u), ("X", args.x)):
        item = hist.InstrumentParameters[name]
        item[1] = float(value)
        item[2] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = abs(float(hap["Mustrain"][1][0]))
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Size"][1][0] = abs(float(hap["Size"][1][0]))
        hap["Size"][2] = [False for _ in hap["Size"][2]]
    project.save(str(args.out))
    print("saved", args.out)
    print("U", hist.InstrumentParameters["U"][1], "X", hist.InstrumentParameters["X"][1])


if __name__ == "__main__":
    main()
