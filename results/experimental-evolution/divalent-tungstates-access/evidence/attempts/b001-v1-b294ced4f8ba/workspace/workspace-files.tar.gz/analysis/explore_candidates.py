#!/usr/bin/env python3
"""Small, read-only helpers for screening COD candidates against the scan."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06"
)
CIF_ROOT = RESOURCE / "cif"
INDEX = RESOURCE / "index.json.gz"


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def describe(cod_ids: list[str], npeaks: int = 20) -> None:
    calc = XRDCalculator(wavelength="CuKa")
    for cod_id in cod_ids:
        path = cif_path(cod_id)
        try:
            structure = Structure.from_file(path)
            pattern = calc.get_pattern(structure, two_theta_range=(9.5, 100.2))
            order = np.argsort(pattern.y)[::-1][:npeaks]
            print(
                cod_id,
                structure.composition.reduced_formula,
                "SG",
                structure.get_space_group_info(),
                "lattice",
                tuple(round(v, 4) for v in structure.lattice.abc),
                tuple(round(v, 3) for v in structure.lattice.angles),
            )
            print(" ".join(f"{pattern.x[i]:.3f}:{pattern.y[i]:.0f}" for i in order))
        except Exception as exc:
            print("ERROR", cod_id, path, repr(exc))


def list_keys(elements: set[str]) -> None:
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    for key in sorted(index):
        key_elements = set(key.split("-"))
        if key_elements <= elements and {"O", "W"} <= key_elements:
            print(key, len(index[key]))
            for record in index[key]:
                print(" ", record)


def ternary_prototypes(max_cation_w: float, max_o_w: float) -> None:
    """List simple X-W-O entries as possible Mn-substitution parents."""
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    rows = []
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "O" not in elements or "W" not in elements:
            continue
        cation = next(e for e in elements if e not in {"O", "W"})
        for formula, cod_id, sg, residual in records:
            try:
                composition = Composition(formula).get_el_amt_dict()
                w = composition.get("W", 0.0)
                x_w = composition.get(cation, 0.0) / w
                o_w = composition.get("O", 0.0) / w
            except Exception:
                continue
            if w > 0 and 0 < x_w <= max_cation_w and 0 < o_w <= max_o_w:
                rows.append((round(x_w, 6), round(o_w, 6), cation, sg, cod_id, formula, residual))
    rows.sort()
    for row in rows:
        print("\t".join(map(str, row)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("ids", nargs="*")
    parser.add_argument("--keys", action="store_true")
    parser.add_argument("--ternary-prototypes", action="store_true")
    parser.add_argument("--elements", default="Mn,W,O,C,H")
    parser.add_argument("--max-cation-w", type=float, default=6.0)
    parser.add_argument("--max-o-w", type=float, default=12.0)
    parser.add_argument("--npeaks", type=int, default=20)
    args = parser.parse_args()
    if args.keys:
        list_keys(set(args.elements.split(",")))
    if args.ternary_prototypes:
        ternary_prototypes(args.max_cation_w, args.max_o_w)
    if args.ids:
        describe(args.ids, args.npeaks)


if __name__ == "__main__":
    main()
