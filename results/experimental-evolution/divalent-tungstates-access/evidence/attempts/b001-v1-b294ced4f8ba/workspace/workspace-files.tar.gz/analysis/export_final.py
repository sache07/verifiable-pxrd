#!/usr/bin/env python3
"""Export the exact accepted GSAS-II project, CIFs, fit profile and result record."""

from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "analysis/final_true/27_polarization_final/stage.gpx"

PHASE_SPECS = {
    "MnWO4_1520200": {
        "display_name": "MnWO4",
        "formula": "MnWO4",
        "space_group": "P 2/c",
        "space_group_number": 13,
        "cif_path": "phase_1_MnWO4.cif",
        "model_origin": "COD 1520200; refined wolframite model",
    },
    "WO3_2311041": {
        "display_name": "WO3",
        "formula": "WO3",
        "space_group": "P 21/c",
        "space_group_number": 14,
        "cif_path": "phase_2_WO3.cif",
        "model_origin": "COD 2311041; refined monoclinic model",
    },
    "Mn3WO6_R3bar_2211528_analogue": {
        "display_name": "Mn3WO6",
        "formula": "Mn3WO6",
        "space_group": "R -3",
        "space_group_number": 148,
        "cif_path": "phase_3_Mn3WO6.cif",
        "model_origin": "Mn3TeO6 COD 2211528 topology with Te->W substitution; refined target-composition model",
    },
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    destination = ROOT / "final.gpx"
    shutil.copy2(SOURCE, destination)
    project = G2.G2Project(gpxfile=str(destination))
    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError(f"expected one histogram, found {len(histograms)}")
    histogram = histograms[0]
    phases = project.phases()
    if [phase.name for phase in phases] != list(PHASE_SPECS):
        raise RuntimeError(f"unexpected phase inventory: {[phase.name for phase in phases]}")

    arrays = [np.asarray(row, dtype=float) for row in histogram.data["data"][1][:6]]
    two_theta, observed, weights, calculated = arrays[:4]
    difference = observed - calculated
    public = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    if public.shape != (len(two_theta), 2):
        raise RuntimeError("saved histogram and public pattern have different shapes")
    if not np.allclose(two_theta, public[:, 0], atol=1e-9, rtol=0):
        raise RuntimeError("saved histogram grid differs from the public pattern")
    if not np.allclose(observed, public[:, 1], atol=1e-9, rtol=0):
        raise RuntimeError("saved observations differ from the public pattern")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("invalid calculated profile")
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((two_theta, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt="%.17g",
    )

    mass_scales = np.asarray(
        [phase.data["General"]["Mass"] * phase.data["Histograms"][histogram.name]["Scale"][0]
         for phase in phases],
        dtype=float,
    )
    fractions = mass_scales / mass_scales.sum()

    covariance = project.data["Covariance"]["data"]
    cov_matrix = np.asarray(covariance["covMatrix"], dtype=float)
    vary_list = [str(item) for item in covariance["varyList"]]
    scale_indices = [vary_list.index(f"{index}:0:Scale") for index in range(len(phases))]
    scale_covariance = cov_matrix[np.ix_(scale_indices, scale_indices)]
    masses = np.asarray([phase.data["General"]["Mass"] for phase in phases], dtype=float)
    scales = np.asarray(
        [phase.data["Histograms"][histogram.name]["Scale"][0] for phase in phases], dtype=float
    )
    total = float(np.sum(masses * scales))
    jacobian = np.empty((len(phases), len(phases)), dtype=float)
    for i in range(len(phases)):
        for j in range(len(phases)):
            if i == j:
                jacobian[i, j] = masses[i] * (total - masses[i] * scales[i]) / total**2
            else:
                jacobian[i, j] = -(masses[i] * scales[i]) * masses[j] / total**2
    fraction_esd = np.sqrt(np.clip(np.diag(jacobian @ scale_covariance @ jacobian.T), 0, None))

    phase_rows = []
    for index, (phase, fraction, esd) in enumerate(zip(phases, fractions, fraction_esd), start=1):
        spec = PHASE_SPECS[phase.name]
        cif = ROOT / spec["cif_path"]
        phase.export_CIF(str(cif))
        phase_rows.append(
            {
                "name": spec["display_name"],
                "formula": spec["formula"],
                "space_group": spec["space_group"],
                "space_group_number": spec["space_group_number"],
                "cif_path": spec["cif_path"],
                "weight_fraction": float(fraction),
                "formal_weight_fraction_esd": float(esd),
                "cell": {key: float(value) for key, value in phase.get_cell().items()},
                "model_origin": spec["model_origin"],
            }
        )

    rvals = covariance["Rvals"]
    residuals = histogram.residuals
    fit_stats = {
        "rwp_percent": float(rvals["Rwp"]),
        "rp_percent": float(residuals["R"]),
        "rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(rvals["GOF"]),
        "chi_square": float(rvals["chisq"]),
        "n_points": int(rvals["Nobs"]),
        "n_refined_variables_last_cycle": int(rvals["Nvars"]),
    }
    result = {
        "schema_version": 1,
        "project_path": "final.gpx",
        "project_sha256": sha256(destination),
        "refinement_histogram": histogram.name,
        "phase_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_rows,
        "unresolved_components": [],
        "fit_statistics": fit_stats,
        "fit_profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
