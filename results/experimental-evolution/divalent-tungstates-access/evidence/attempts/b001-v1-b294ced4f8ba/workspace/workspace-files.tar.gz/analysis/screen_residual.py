#!/usr/bin/env python3
"""Rank library structures by nonnegative fit to a saved positive residual."""

from __future__ import annotations

import argparse
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06"
)
INDEX = RESOURCE / "index.json.gz"
CIF_ROOT = RESOURCE / "cif"


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def transformed_positions(two_theta: np.ndarray, cell_scale: float, offset: float) -> np.ndarray:
    theta = np.deg2rad(two_theta / 2.0)
    argument = np.clip(np.sin(theta) / cell_scale, -1.0, 1.0)
    return 2.0 * np.rad2deg(np.arcsin(argument)) + offset


def profile(x: np.ndarray, positions: np.ndarray, intensities: np.ndarray, fwhm: float) -> np.ndarray:
    sigma = fwhm / 2.354820045
    result = np.zeros_like(x)
    half_window = max(4.0 * sigma, 0.15)
    for position, intensity in zip(positions, intensities):
        lo = np.searchsorted(x, position - half_window)
        hi = np.searchsorted(x, position + half_window)
        if hi <= lo:
            continue
        z = (x[lo:hi] - position) / sigma
        result[lo:hi] += intensity * np.exp(-0.5 * z * z)
    return result


def score_structure(
    structure: Structure,
    x: np.ndarray,
    difference: np.ndarray,
    weight: np.ndarray,
    cell_scale_min: float,
    cell_scale_max: float,
    offset_min: float,
    offset_max: float,
) -> dict:
    calc = XRDCalculator(wavelength="CuKa")
    pattern = calc.get_pattern(structure, two_theta_range=(float(x[0]) - 1, float(x[-1]) + 1))
    best = {"delta_chi2": 0.0}
    offsets = np.linspace(offset_min, offset_max, 19)
    cell_scales = np.linspace(cell_scale_min, cell_scale_max, 33)
    widths = [0.18, 0.25, 0.35, 0.50]
    px = np.asarray(pattern.x, dtype=float)
    py = np.asarray(pattern.y, dtype=float)
    for cell_scale in cell_scales:
        base = transformed_positions(px, cell_scale, 0.0)
        for offset in offsets:
            positions = base + offset
            for fwhm in widths:
                trial = profile(x, positions, py, fwhm)
                tt = float(np.sum(weight * trial * trial))
                if tt <= 0:
                    continue
                td = float(np.sum(weight * trial * difference))
                amplitude = max(td / tt, 0.0)
                improvement = 2.0 * amplitude * td - amplitude * amplitude * tt
                if improvement > best["delta_chi2"]:
                    best = {
                        "delta_chi2": improvement,
                        "amplitude": amplitude,
                        "offset_deg": float(offset),
                        "cell_scale": float(cell_scale),
                        "fwhm_deg": float(fwhm),
                    }
    return best


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile_csv", type=Path)
    parser.add_argument("--key", action="append", default=[])
    parser.add_argument("--cif", action="append", type=Path, default=[])
    parser.add_argument("--cell-scale-min", type=float, default=0.992)
    parser.add_argument("--cell-scale-max", type=float, default=1.008)
    parser.add_argument("--offset-min", type=float, default=0.10)
    parser.add_argument("--offset-max", type=float, default=0.55)
    parser.add_argument("--limit", type=int, default=100)
    args = parser.parse_args()
    data = np.genfromtxt(args.profile_csv, delimiter=",", names=True)
    x = data["two_theta_deg"]
    difference = data["difference"]
    weight = 1.0 / np.maximum(data["observed"], 1.0)
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    rows = []
    for key in args.key:
        for formula, cod_id, sg, residual in index.get(key, []):
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = Structure.from_file(cif_path(cod_id))
                    result = score_structure(
                        structure, x, difference, weight,
                        args.cell_scale_min, args.cell_scale_max,
                        args.offset_min, args.offset_max,
                    )
                rows.append(
                    {
                        "key": key,
                        "formula": formula,
                        "cod_id": cod_id,
                        "space_group": sg,
                        "cod_residual": residual,
                        **result,
                    }
                )
            except Exception as exc:
                rows.append({"key": key, "formula": formula, "cod_id": cod_id, "status": repr(exc), "delta_chi2": -1.0})
    for path in args.cif:
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = Structure.from_file(path)
                result = score_structure(
                    structure, x, difference, weight,
                    args.cell_scale_min, args.cell_scale_max,
                    args.offset_min, args.offset_max,
                )
            rows.append(
                {
                    "key": "custom",
                    "formula": structure.composition.reduced_formula,
                    "cod_id": str(path),
                    "space_group": structure.get_space_group_info()[1],
                    **result,
                }
            )
        except Exception as exc:
            rows.append({"key": "custom", "formula": "?", "cod_id": str(path), "status": repr(exc), "delta_chi2": -1.0})
    rows.sort(key=lambda row: row["delta_chi2"], reverse=True)
    print(json.dumps(rows[: args.limit], indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
