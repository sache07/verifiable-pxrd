#!/usr/bin/env python3
"""Create a target-composition analogue CIF while preserving parent topology."""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("parent", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--target", default="Mn")
    parser.add_argument("--keep", default="O,W")
    parser.add_argument("--symprec", type=float, default=0.001)
    args = parser.parse_args()
    keep = set(args.keep.split(","))
    target = Element(args.target)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(args.parent, primitive=False)
    parent_composition = structure.composition
    transformed = structure.copy()
    for index, site in enumerate(structure):
        species = {}
        replacement_occupancy = 0.0
        for specie, occupancy in site.species.items():
            symbol = specie.element.symbol if hasattr(specie, "element") else specie.symbol
            if symbol in keep:
                species[Element(symbol)] = species.get(Element(symbol), 0.0) + float(occupancy)
            else:
                replacement_occupancy += float(occupancy)
        if replacement_occupancy:
            species[target] = species.get(target, 0.0) + replacement_occupancy
        transformed.replace(index, species)
    analyzer = SpacegroupAnalyzer(transformed, symprec=args.symprec, angle_tolerance=5.0)
    sg_symbol = analyzer.get_space_group_symbol()
    sg_number = analyzer.get_space_group_number()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(transformed, symprec=args.symprec).write_file(args.output)
    distances = transformed.distance_matrix
    np.fill_diagonal(distances, np.inf)
    nearest = np.min(distances, axis=1)
    report = {
        "parent": str(args.parent),
        "output": str(args.output),
        "transformation": f"replace every non-{','.join(sorted(keep))} occupied species with {args.target}; preserve occupancies, fractional coordinates, lattice and topology",
        "parent_composition": str(parent_composition),
        "target_composition": str(transformed.composition),
        "target_reduced_formula": transformed.composition.reduced_formula,
        "detected_space_group": [sg_symbol, sg_number],
        "site_count": len(transformed),
        "minimum_interatomic_distance_A": float(np.min(nearest)),
        "maximum_nearest_neighbor_distance_A": float(np.max(nearest)),
    }
    args.output.with_suffix(".provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
