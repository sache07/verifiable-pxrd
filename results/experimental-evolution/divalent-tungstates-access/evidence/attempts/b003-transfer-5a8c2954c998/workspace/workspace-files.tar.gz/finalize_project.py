#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export its phase structures."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("polished15.gpx").resolve()
OUTPUT = Path("final.gpx").resolve()
EXPORTS = {
    "MnWO4": Path("phase_MnWO4.cif").resolve(),
    "WO3": Path("phase_WO3.cif").resolve(),
    "Mn3WO6": Path("phase_Mn3WO6.cif").resolve(),
}


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    project.update_ids()
    assert [phase.name for phase in project.phases()] == list(EXPORTS)
    assert len(project.histograms()) == 1
    assert project.histogram(0).name == "PWDR pattern.csv"

    # Keep the completed model values but leave no frozen failed variables.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save(str(OUTPUT))

    # CIF exports must use the saved atom values, not uncertainty values cached
    # in the covariance block from an earlier refinement stage.
    project.data["Covariance"]["data"] = {}
    for name, path in EXPORTS.items():
        project.phase(name).export_CIF(str(path))

    print(OUTPUT)
    for path in EXPORTS.values():
        print(path)


if __name__ == "__main__":
    main()
