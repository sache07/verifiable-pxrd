#!/usr/bin/env python3
"""Test one uniaxial microstrain axis while holding the rest fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist):
    x, yo, wt, yc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return float(100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("phase")
    parser.add_argument("axis")
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(Path(args.output).resolve()))
    project.update_ids()
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    selected = project.phase(args.phase)
    hap = selected.data["Histograms"][hist.name]
    start = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = start
    hap["Mustrain"][1][1] = start
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = axis
    for suffix, upper in (("Mustrain;i", 8000.0), ("Mustrain;a", 32000.0)):
        project.set_Controls("parmMin", 0.0, variable=f"{selected.id}:{hist.id}:{suffix}")
        project.set_Controls("parmMax", upper, variable=f"{selected.id}:{hist.id}:{suffix}")
    project.save()
    before = rwp(hist)
    project.refine()
    hist = project.histogram(0)
    selected = project.phase(args.phase)
    hap = selected.data["Histograms"][hist.name]
    result = {
        "phase": args.phase,
        "axis": axis,
        "equatorial_ppm": float(hap["Mustrain"][1][0]),
        "axial_ppm": float(hap["Mustrain"][1][1]),
        "rwp_before": before,
        "rwp_percent": rwp(hist),
    }
    project.save()
    Path(str(args.output) + ".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
