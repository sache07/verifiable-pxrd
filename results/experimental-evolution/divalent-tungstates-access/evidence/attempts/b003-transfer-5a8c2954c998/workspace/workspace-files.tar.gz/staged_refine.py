#!/usr/bin/env python3
"""Perform a stable, physically bounded refinement of the selected model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist):
    x, yo, wt, yc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return float(100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2)))


def fractions(project, hist):
    values = np.array([
        phase.data["General"]["Mass"] * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ], float)
    values = np.maximum(values, 0)
    values /= values.sum()
    return {phase.name: float(value) for phase, value in zip(project.phases(), values)}


def state(project, label):
    hist = project.histogram(0)
    return {
        "stage": label,
        "rwp_percent": rwp(hist),
        "fractions": fractions(project, hist),
        "instrument": {key: float(value[1]) for key, value in hist.InstrumentParameters.items() if key in {"Zero", "U", "V", "W", "X", "SH/L", "Polariz."}},
        "sample": {key: float(value[0]) for key, value in hist.SampleParameters.items() if key in {"Shift", "SurfRoughA", "SurfRoughB", "Transparency"}},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "hap": {
            phase.name: {
                "size": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "strain": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "texture_ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "texture_axis": list(phase.data["Histograms"][hist.name]["Pref.Ori."][3]),
            }
            for phase in project.phases()
        },
    }


def run(project, label, history, prefix):
    project.refine()
    item = state(project, label)
    history.append(item)
    print(json.dumps(item, sort_keys=True))
    project.save(str(prefix.with_name(prefix.name + "_" + label + ".gpx")))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--oxygen", action="store_true")
    args = parser.parse_args()
    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    prefix = output.with_suffix("")

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.update_ids()
    hist = project.histogram(0)
    hid = hist.id
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 16)

    # Start from a stable flag set. Scales and the smooth background remain
    # active throughout; all other groups are released in small blocks.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    hist.set_refinements({"Background": True})

    # Physical bounds from the public laboratory envelope.
    for name, lower, upper in (
        ("Zero", -0.25, 0.25), ("U", 0.0, 40.0), ("W", 2.0, 40.0),
        ("X", 0.1, 6.0), ("SH/L", 0.005, 0.10), ("Polariz.", 0.5, 1.0),
    ):
        project.set_Controls("parmMin", lower, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", upper, variable=f":{hid}:{name}")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    for phase in project.phases():
        for suffix, lower, upper in (("Size;i", 0.04, 1.5), ("Mustrain;i", 0.0, 8000.0)):
            project.set_Controls("parmMin", lower, variable=f"{phase.id}:{hid}:{suffix}")
            project.set_Controls("parmMax", upper, variable=f"{phase.id}:{hid}:{suffix}")

    # Choose a non-boundary calibration parameterization equivalent to the
    # preceding fit, then determine cells and specimen displacement.
    hist.InstrumentParameters["Zero"][1] = -0.10
    hist.SampleParameters["Shift"][0] = 320.0
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.save()
    history = []
    run(project, "cells_shift", history, prefix)
    hist = project.histogram(0)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "cells_zero", history, prefix)

    # Common instrumental profile and polarization with cells/calibration held.
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    run(project, "instrument", history, prefix)
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})

    # Phase-specific isotropic size and strain, one phase at a time.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        run(project, "size_" + phase.name, history, prefix)
        phase = project.phase(phase.name)
        phase.clear_HAP_refinements({"Size": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        run(project, "strain_" + phase.name, history, prefix)
        phase = project.phase(phase.name)
        phase.clear_HAP_refinements({"Mustrain": True})

    # Revisit the common instrument after phase widths have settled.
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run(project, "instrument_final", history, prefix)
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})

    # Refit the two texture ratios whose axis scans gave unambiguous minima.
    for name in ("MnWO4", "WO3"):
        phase = project.phase(name)
        if phase is None:
            continue
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hid}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hid}:MD")
        run(project, "texture_" + name, history, prefix)
        phase = project.phase(name)
        phase.clear_HAP_refinements({"Pref.Ori.": True})

    # One common isotropic U per phase. Constraints already present in the
    # input project from uiso_trial.py.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
        project.set_Controls("parmMin", 0.003, variable=f"{phase.id}::AUiso:0")
        project.set_Controls("parmMax", 0.020, variable=f"{phase.id}::AUiso:0")
    run(project, "uiso", history, prefix)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Heavy-atom coordinates carry most X-ray structural sensitivity. Limit
    # each fractional coordinate to a modest neighborhood around its parent.
    for phase in project.phases():
        for i, atom in enumerate(phase.atoms()):
            if atom.element == "O":
                continue
            atom.refinement_flags = "X"
            for axis, value in zip("xyz", atom.coordinates):
                project.set_Controls("parmMin", float(value) - 0.012, variable=f"{phase.id}::dA{axis}:{i}")
                project.set_Controls("parmMax", float(value) + 0.012, variable=f"{phase.id}::dA{axis}:{i}")
        run(project, "heavy_coordinates_" + phase.name, history, prefix)
        phase = project.phase(phase.name)
        for atom in phase.atoms():
            atom.refinement_flags = " "

    if args.oxygen:
        for phase in project.phases():
            for i, atom in enumerate(phase.atoms()):
                if atom.element != "O":
                    continue
                atom.refinement_flags = "X"
                for axis, value in zip("xyz", atom.coordinates):
                    project.set_Controls("parmMin", float(value) - 0.012, variable=f"{phase.id}::dA{axis}:{i}")
                    project.set_Controls("parmMax", float(value) + 0.012, variable=f"{phase.id}::dA{axis}:{i}")
            run(project, "oxygen_coordinates_" + phase.name, history, prefix)
            phase = project.phase(phase.name)
            for atom in phase.atoms():
                atom.refinement_flags = " "

    project.save(str(output))
    Path(str(output) + ".json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
