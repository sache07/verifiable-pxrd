#!/usr/bin/env python3
"""Explore atomic and specimen refinements from a trial GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    x, obs, wt, calc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return float(100 * np.sqrt(np.sum(wt[use] * (obs[use] - calc[use]) ** 2) / np.sum(wt[use] * obs[use] ** 2)))


def phase_fractions(project, histname):
    terms = np.array([
        phase.data["General"]["Mass"] * phase.data["Histograms"][histname]["Scale"][0]
        for phase in project.phases()
    ], float)
    terms = np.maximum(terms, 0)
    terms /= terms.sum()
    return {phase.name: float(value) for phase, value in zip(project.phases(), terms)}


def record(project, label, history):
    hist = project.histogram(0)
    item = {
        "stage": label,
        "rwp_percent": rwp(hist),
        "fractions": phase_fractions(project, hist.name),
        "uiso": {
            phase.name: [
                float(atom.data[phase.data["General"]["AtomPtrs"][3] + 1])
                for atom in phase.atoms()
            ]
            for phase in project.phases()
        },
        "coordinates": {
            phase.name: {atom.label: list(map(float, atom.coordinates)) for atom in phase.atoms()}
            for phase in project.phases()
        },
    }
    history.append(item)
    print(json.dumps(item, sort_keys=True))


def refine(project, label, history):
    project.refine()
    record(project, label, history)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--no-uiso", action="store_true")
    parser.add_argument("--no-positions", action="store_true")
    args = parser.parse_args()

    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.update_ids()
    hist = project.histogram(0)
    histname = hist.name
    hid = hist.id
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 16)

    # Return the unstable trial broadening step to the preceding bounded common
    # profile and use modest fixed phase contributions while coordinates are fit.
    for key, value in {"U": 12.9, "W": 10.55, "X": 6.0, "SH/L": 0.005}.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False
    for phase in project.phases():
        hap = phase.data["Histograms"][histname]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [False, False, False]

    # Convert imported ADPs to a common isotropic starting point per phase.
    # The synthetic laboratory varies one isotropic U value for all sites.
    if not args.no_uiso:
        project.data["Constraints"]["data"]["Phase"] = []
        for phase in project.phases():
            cia = phase.data["General"]["AtomPtrs"][3]
            for atom in phase.atoms():
                atom.data[cia] = "I"
                atom.data[cia + 1] = 0.01
                atom.refinement_flags = "U"
            variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)
            for variable in variables:
                project.set_Controls("parmMin", 0.001, variable=variable)
                project.set_Controls("parmMax", 0.03, variable=variable)

    if not args.no_positions:
        for phase in project.phases():
            for i, atom in enumerate(phase.atoms()):
                for axis, value in zip("xyz", atom.coordinates):
                    variable = f"{phase.id}::dA{axis}:{i}"
                    project.set_Controls("parmMin", float(value) - 0.03, variable=variable)
                    project.set_Controls("parmMax", float(value) + 0.03, variable=variable)

    project.save()
    history = []
    record(project, "reset", history)
    refine(project, "profile_reset", history)
    if not args.no_uiso:
        refine(project, "common_uiso", history)

    if not args.no_positions:
        # The order starts with the dominant phase, then the oxide, then the
        # weaker Mn-rich tungstate, preserving all preceding coordinate flags.
        preferred_order = ["MnWO4", "WO3", "Mn3WO6"]
        ordered = sorted(project.phases(), key=lambda p: preferred_order.index(p.name) if p.name in preferred_order else 99)
        for phase in ordered:
            for atom in phase.atoms():
                atom.refinement_flags = "XU" if not args.no_uiso else "X"
            refine(project, f"positions_{phase.name}", history)

    project.save()
    Path(str(output) + ".json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
