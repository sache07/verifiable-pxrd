#!/usr/bin/env python3
"""Write the submitted profile from the independently replayed final project."""

from pathlib import Path

import numpy as np


def main():
    replay = np.load(Path(".tmp/replay_final/prediction.npz"))
    x = replay["x"]
    observed = replay["observed"]
    calculated = replay["predicted"]
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.12g",
    )


if __name__ == "__main__":
    main()
