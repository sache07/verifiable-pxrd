#!/usr/bin/env python3
"""Test whether residual intensity supports crystalline Mn3O4."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_MN3O4 = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/9/00/19/9001963.cif")


def stats(project):
    hist = project.histogram(0)
    x, yo, wt, yc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    masses = [float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()]
    total = sum(max(0.0, value) for value in masses)
    return {
        "rwp_percent": float(100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2))),
        "fractions": {p.name: max(0.0, value) / total for p, value in zip(project.phases(), masses)},
    }


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def run(project, label, history):
    project.refine()
    history.append({"stage": label, **stats(project)})
    print(json.dumps(history[-1]))
    clear_flags(project)


def main():
    output = Path("fourth_mn3o4.gpx").resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path("polished2.gpx").resolve()), newgpx=str(output))
    hist = project.histogram(0)
    phase = project.add_phase(str(COD_MN3O4), phasename="Mn3O4", histograms=[hist], fmthint="CIF")
    project.update_ids()
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    clear_flags(project)
    hist = project.histogram(0)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.4, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    for suffix, lo, hi in (("Scale", 0.0, 1e6), ("Size;i", 0.04, 1.5), ("Mustrain;i", 0.0, 8000.0)):
        project.set_Controls("parmMin", lo, variable=f"{phase.id}:{hist.id}:{suffix}")
        project.set_Controls("parmMax", hi, variable=f"{phase.id}:{hist.id}:{suffix}")
    history = [{"stage": "initial", **stats(project)}]
    run(project, "scale_background", history)
    phase = project.phase("Mn3O4")
    phase.set_refinements({"Cell": True})
    run(project, "cell", history)
    phase = project.phase("Mn3O4")
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run(project, "size", history)
    phase = project.phase("Mn3O4")
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run(project, "strain", history)
    project.save(str(output))
    Path("fourth_mn3o4.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
