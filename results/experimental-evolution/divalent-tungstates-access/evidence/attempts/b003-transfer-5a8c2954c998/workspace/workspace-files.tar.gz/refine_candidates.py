#!/usr/bin/env python3
"""Build and refine trial GSAS-II models for the supplied powder pattern.

This is an exploratory helper. The final export is performed separately after
the phase inventory and profile model have been selected.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(record_id: str) -> Path:
    return COD / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def instrument_text() -> str:
    return (
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.20;Polariz.:0.8;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:15.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def fractions(project: G2.G2Project, histname: str) -> dict[str, float]:
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histname]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(max(0.0, value) for value in masses)
    return {
        phase.name: max(0.0, value) / total if total > 0 else float("nan")
        for phase, value in zip(project.phases(), masses)
    }


def snapshot(project: G2.G2Project, hist, label: str) -> dict:
    arr = hist.data["data"][1]
    x, obs, wt, calc = (np.asarray(arr[i], float) for i in (0, 1, 2, 3))
    limits = hist.data["Limits"][1]
    use = (x >= limits[0]) & (x <= limits[1])
    loss = float(np.sum(wt[use] * (obs[use] - calc[use]) ** 2))
    denom = float(np.sum(wt[use] * obs[use] ** 2))
    return {
        "stage": label,
        "rwp_percent_recomputed": 100.0 * np.sqrt(loss / denom),
        "rwp_percent_gsas": hist.get_wR(),
        "fractions": fractions(project, hist.name),
        "instrument": {
            key: float(hist.InstrumentParameters[key][1])
            for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")
            if key in hist.InstrumentParameters
        },
        "sample": {
            key: float(hist.SampleParameters[key][0])
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in hist.SampleParameters
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def refine_once(project, hist, history, label):
    project.refine()
    hist = project.histogram(hist.name)
    history.append(snapshot(project, hist, label))
    print(json.dumps(history[-1], sort_keys=True))
    return hist


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("tag")
    parser.add_argument(
        "phases",
        nargs="+",
        help="phase specifications as NAME=COD_ID",
    )
    parser.add_argument("--background", type=int, default=5)
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()

    phase_specs = []
    for item in args.phases:
        name, record_id = item.split("=", 1)
        path = cod_path(record_id)
        if not path.is_file():
            raise FileNotFoundError(path)
        phase_specs.append((name, record_id, path))

    out = ROOT / f"trial_{args.tag}.gpx"
    inst = ROOT / f"trial_{args.tag}.instprm"
    inst.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(out))
    phases = [
        project.add_phase(str(path), phasename=name, fmthint="CIF")
        for name, _, path in phase_specs
    ]
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(inst),
        phases=phases,
        fmthint="comma/tab/semicolon separated",
    )
    hist.set_refinements({"Limits": [9.90343322, 100.09455322]})
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # Start with a physically neutral roughness model.
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]

    nback = args.background
    coeffs = [3600.0, 150.0, 0.0] + [0.0] * max(0, nback - 3)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": nback,
                "coeffs": coeffs[:nback],
                "refine": True,
            }
        }
    )

    # GSAS phase scales are refined independently; weight fractions are
    # proportional to scale times unit-cell mass.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    project.set_Controls("cycles", 12)
    project.save()
    # Bounds match the stated laboratory envelope and prevent correlated
    # broadening terms from wandering into nonphysical regions.
    h_id = hist.id
    for variable, lower, upper in (
        (f":{h_id}:Zero", -0.25, 0.25),
        (f":{h_id}:Shift", -800.0, 800.0),
        (f":{h_id}:U", 0.0, 40.0),
        (f":{h_id}:W", 2.0, 40.0),
        (f":{h_id}:X", 0.1, 6.0),
        (f":{h_id}:SH/L", 0.005, 0.10),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in project.phases():
        for suffix, lower, upper in (
            ("Scale", 0.0, 1.0e6),
            ("Size;i", 0.04, 1.5),
            ("Mustrain;i", 0.0, 8000.0),
        ):
            variable = f"{phase.id}:{h_id}:{suffix}"
            project.set_Controls("parmMin", lower, variable=variable)
            project.set_Controls("parmMax", upper, variable=variable)
    history = [snapshot(project, hist, "initial")]

    # Scale/background, then lattice and angular calibration.
    hist = refine_once(project, hist, history, "scale_background")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist = refine_once(project, hist, history, "cell_zero_shift")

    if args.profile:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        hist = refine_once(project, hist, history, "instrument_profile")
        # Hold the common instrument profile while determining phase-specific
        # broadening. This avoids the worst initial correlations.
        hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        for phase in project.phases():
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "value": 0.5, "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
        hist = refine_once(project, hist, history, "phase_broadening")

    project.save()
    result = {
        "tag": args.tag,
        "phase_specs": [
            {"name": name, "cod_id": record_id, "path": str(path)}
            for name, record_id, path in phase_specs
        ],
        "histogram": hist.name,
        "history": history,
        "final": history[-1],
    }
    (ROOT / f"trial_{args.tag}.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
