#!/usr/bin/env python3
"""Refine bounded oxygen coordinates after enforcing physical common Uiso."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist):
    x, yo, wt, yc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return float(100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("output")
    p.add_argument("--bound", type=float, default=0.012)
    p.add_argument("--stop-after", choices=["MnWO4", "WO3", "Mn3WO6"])
    args = p.parse_args()
    output = Path(args.output).resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.update_ids()
    hist = project.histogram(0)
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Constraints"]["data"]["Phase"] = []
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    chosen_u = {"MnWO4": 0.0078, "WO3": 0.0030, "Mn3WO6": 0.0030}
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        cia = phase.data["General"]["AtomPtrs"][3]
        for atom in phase.atoms():
            atom.data[cia] = "I"
            atom.data[cia + 1] = chosen_u.get(phase.name, 0.005)
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    hist.set_refinements({"Background": True})
    project.save()
    project.refine()  # recalculate after Uiso normalization
    history = [{"stage": "common_uiso_recalc", "rwp_percent": rwp(project.histogram(0))}]
    print(json.dumps(history[-1]))

    names = ["MnWO4", "WO3", "Mn3WO6"]
    for name in names:
        phase = project.phase(name)
        if phase is None:
            continue
        for i, atom in enumerate(phase.atoms()):
            if atom.element != "O":
                continue
            atom.refinement_flags = "X"
            for axis, value in zip("xyz", atom.coordinates):
                variable = f"{phase.id}::dA{axis}:{i}"
                project.set_Controls("parmMin", float(value) - args.bound, variable=variable)
                project.set_Controls("parmMax", float(value) + args.bound, variable=variable)
        project.refine()
        hist = project.histogram(0)
        phase = project.phase(name)
        item = {
            "stage": "oxygen_" + name,
            "rwp_percent": rwp(hist),
            "coordinates": {atom.label: list(map(float, atom.coordinates)) for atom in phase.atoms() if atom.element == "O"},
        }
        history.append(item)
        print(json.dumps(item))
        for atom in phase.atoms():
            atom.refinement_flags = " "
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.save(str(output.with_name(output.stem + "_" + name + ".gpx")))
        if args.stop_after == name:
            break

    project.save(str(output))
    Path(str(output) + ".json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
