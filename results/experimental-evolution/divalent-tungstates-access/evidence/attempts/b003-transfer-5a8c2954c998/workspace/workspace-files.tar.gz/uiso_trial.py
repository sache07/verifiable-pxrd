#!/usr/bin/env python3
"""Refine one constrained isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist):
    x, yo, wt, yc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return float(100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2)))


def main():
    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("output")
    args = p.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(Path(args.output).resolve()))
    project.update_ids()
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Constraints"]["data"]["Phase"] = []
    project.set_Controls("cycles", 20)

    # Keep profile, calibration, lattice and texture fixed during this test.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        cia = phase.data["General"]["AtomPtrs"][3]
        variables = []
        for i, atom in enumerate(phase.atoms()):
            atom.data[cia] = "I"
            atom.data[cia + 1] = 0.01
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{i}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        # Only the independent/master parameter receives limits. Applying
        # limits separately to dependent variables can break an equivalence.
        project.set_Controls("parmMin", 0.001, variable=variables[0])
        project.set_Controls("parmMax", 0.03, variable=variables[0])
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        hap["Scale"][1] = True
    project.save()
    before = rwp(hist)
    project.refine()
    hist = project.histogram(0)
    result = {"rwp_before_stale": before, "rwp_percent": rwp(hist), "phases": {}}
    for phase in project.phases():
        cia = phase.data["General"]["AtomPtrs"][3]
        result["phases"][phase.name] = [float(a.data[cia + 1]) for a in phase.atoms()]
    project.save()
    Path(str(args.output) + ".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
