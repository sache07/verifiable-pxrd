#!/usr/bin/env python3
"""Trial the GSAS-II Suortti surface-roughness correction from fixed starts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist):
    x, yo, wt, yc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return float(100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2)))


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main():
    source = Path("polished2.gpx").resolve()
    starts = ((0.10, 0.03), (0.25, 0.10), (0.50, 0.30))
    results = []
    G2.SetPrintLevel("warn")
    for index, (a, b) in enumerate(starts, 1):
        output = Path(f"surface_{index}.gpx").resolve()
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        project.update_ids()
        project.set_Controls("cycles", 25)
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        clear_flags(project)
        hist = project.histogram(0)
        hist.SampleParameters["SurfRoughA"] = [a, False]
        hist.SampleParameters["SurfRoughB"] = [b, False]
        project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMax", 0.6, variable=f":{hist.id}:SurfRoughA")
        project.set_Controls("parmMin", 0.001, variable=f":{hist.id}:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=f":{hist.id}:SurfRoughB")
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        project.refine()
        clear_flags(project)
        project.save(str(output))
        results.append({
            "project": output.name,
            "start": [a, b],
            "final": [float(hist.SampleParameters["SurfRoughA"][0]), float(hist.SampleParameters["SurfRoughB"][0])],
            "rwp_percent": rwp(hist),
        })
    Path("surface_trials.json").write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
