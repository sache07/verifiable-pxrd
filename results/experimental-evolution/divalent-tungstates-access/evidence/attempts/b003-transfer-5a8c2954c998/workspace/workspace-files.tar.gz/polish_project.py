#!/usr/bin/env python3
"""Polish lattice, profile and texture terms without changing structures."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist):
    x, yo, wt, yc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return float(100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2)))


def snapshot(project, label, history, output):
    hist = project.histogram(0)
    item = {
        "stage": label,
        "rwp_percent": rwp(hist),
        "instrument": {k: float(v[1]) for k, v in hist.InstrumentParameters.items() if k in {"Zero", "U", "W", "X", "SH/L", "Polariz."}},
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "hap": {p.name: {"size": p.data["Histograms"][hist.name]["Size"], "strain": p.data["Histograms"][hist.name]["Mustrain"], "texture": p.data["Histograms"][hist.name]["Pref.Ori."][:4]} for p in project.phases()},
    }
    history.append(item)
    print(json.dumps(item, default=lambda o: o.tolist() if hasattr(o, "tolist") else o))
    project.save(str(output))
    shutil.copy2(output, output.with_name(output.stem + "_" + label + ".gpx"))


def run(project, label, history, output):
    project.refine()
    snapshot(project, label, history, output)


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    hist.set_refinements({"Background": True})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    output = Path(args.output).resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(output))
    project.update_ids()
    project.set_Controls("cycles", 20)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    clear_flags(project)
    hist = project.histogram(0)
    hid = hist.id
    for name, lo, hi in (("Zero", -0.25, 0.25), ("U", 0.0, 40.0), ("W", 2.0, 40.0), ("X", 0.1, 6.0), ("SH/L", 0.005, 0.10), ("Polariz.", 0.5, 1.0)):
        project.set_Controls("parmMin", lo, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", hi, variable=f":{hid}:{name}")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    for phase in project.phases():
        for suffix, lo, hi in (("Size;i", 0.04, 1.5), ("Mustrain;i", 0.0, 8000.0), ("Mustrain;a", 0.0, 32000.0), ("MD", 0.7, 1.4)):
            project.set_Controls("parmMin", lo, variable=f"{phase.id}:{hid}:{suffix}")
            project.set_Controls("parmMax", hi, variable=f"{phase.id}:{hid}:{suffix}")
    project.save()
    history = []

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "cells_shift", history, output)
    clear_flags(project)

    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    run(project, "instrument", history, output)
    clear_flags(project)

    for name in ("MnWO4", "WO3", "Mn3WO6"):
        phase = project.phase(name)
        phase.set_HAP_refinements({"Size": {"type": phase.data["Histograms"][project.histogram(0).name]["Size"][0], "refine": True}})
        run(project, "size_" + name, history, output)
        clear_flags(project)
        phase = project.phase(name)
        current_type = phase.data["Histograms"][project.histogram(0).name]["Mustrain"][0]
        refine = True
        phase.set_HAP_refinements({"Mustrain": {"type": current_type, "refine": refine}})
        run(project, "strain_" + name, history, output)
        clear_flags(project)

    for name in ("MnWO4", "WO3"):
        phase = project.phase(name)
        phase.set_HAP_refinements({"Pref.Ori.": True})
        run(project, "texture_" + name, history, output)
        clear_flags(project)

    hist = project.histogram(0)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "cells_shift_final", history, output)
    clear_flags(project)

    project.save(str(output))
    Path(str(output) + ".json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
