#!/usr/bin/env python3
"""Refine one March-Dollase texture direction from an existing project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def profile_rwp(hist):
    x, yo, wt, yc = (np.asarray(hist.data["data"][1][i], float) for i in (0, 1, 2, 3))
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    return float(100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("phase")
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("--preserve", action="store_true", help="retain fixed texture values for other phases")
    args = parser.parse_args()
    axis = [int(value) for value in args.axis.split(",")]

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(Path(args.output).resolve()))
    project.update_ids()
    hist = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)

    # Hold profile, calibration, cells and coordinates. Refine only the phase
    # scales, smooth background and the selected MD ratio.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        if not args.preserve:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Pref.Ori."][2] = False
        hap["Scale"][1] = True

    selected = project.phase(args.phase)
    if selected is None:
        raise ValueError(f"Unknown phase {args.phase}")
    selected_hap = selected.data["Histograms"][hist.name]
    selected_hap["Pref.Ori."][1] = 1.0
    selected_hap["Pref.Ori."][3] = axis
    selected_hap["Pref.Ori."][2] = True
    variable = f"{selected.id}:{hist.id}:MD"
    project.set_Controls("parmMin", 0.7, variable=variable)
    project.set_Controls("parmMax", 1.4, variable=variable)
    project.save()
    before = profile_rwp(hist)
    project.refine()
    hist = project.histogram(0)
    selected = project.phase(args.phase)
    selected_hap = selected.data["Histograms"][hist.name]
    result = {
        "input": args.input,
        "output": args.output,
        "phase": args.phase,
        "axis": axis,
        "ratio": float(selected_hap["Pref.Ori."][1]),
        "rwp_before_stale": before,
        "rwp_percent": profile_rwp(hist),
    }
    project.save()
    Path(str(args.output) + ".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
