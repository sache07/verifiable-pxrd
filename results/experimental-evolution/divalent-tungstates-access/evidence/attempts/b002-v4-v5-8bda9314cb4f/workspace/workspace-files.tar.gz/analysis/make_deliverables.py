from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent


def fraction_uncertainties(project: G2.G2Project) -> np.ndarray:
    covariance = project.data["Covariance"]["data"]
    vary = list(covariance["varyList"])
    matrix = np.asarray(covariance["covMatrix"], dtype=float)
    histogram = project.histogram(0)
    phases = project.phases()
    masses = np.asarray([p.data["General"]["Mass"] for p in phases], dtype=float)
    scales = np.asarray(
        [p.getHAPvalues(histogram.name)["Scale"][0] for p in phases], dtype=float
    )
    indices = [vary.index(f"{p.id}:0:Scale") for p in phases]
    scale_covariance = matrix[np.ix_(indices, indices)]
    products = masses * scales
    total = float(products.sum())
    jacobian = np.empty((len(phases), len(phases)), dtype=float)
    for i in range(len(phases)):
        for j in range(len(phases)):
            jacobian[i, j] = masses[j] * (
                (total if i == j else 0.0) - products[i]
            ) / total**2
    return np.sqrt(np.diag(jacobian @ scale_covariance @ jacobian.T))


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(WORKSPACE / "final.gpx"))
    replay = json.loads((HERE / "replay" / "replay.json").read_text())
    prediction = np.load(HERE / "replay" / "prediction.npz")
    x = np.asarray(prediction["x"], dtype=float)
    observed = np.asarray(prediction["observed"], dtype=float)
    calculated = np.asarray(prediction["predicted"], dtype=float)
    difference = observed - calculated

    np.savetxt(
        WORKSPACE / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.8f",
    )

    cif_names = {
        "ZnWO4": "phase_ZnWO4.cif",
        "WO3": "phase_WO3.cif",
        "ZnO": "phase_ZnO.cif",
    }
    formulas = {"ZnWO4": "ZnWO4", "WO3": "WO3", "ZnO": "ZnO"}
    descriptions = {
        "ZnWO4": "wolframite-type zinc tungstate",
        "WO3": "monoclinic tungsten(VI) oxide",
        "ZnO": "wurtzite zinc oxide",
    }
    space_groups = {"ZnWO4": "P 2/c", "WO3": "P 21/c", "ZnO": "P 63 m c"}
    replay_phases = {row["name"]: row for row in replay["phases"]}
    formal_sigma = fraction_uncertainties(project)

    phase_rows = []
    for phase, sigma in zip(project.phases(), formal_sigma):
        filename = cif_names[phase.name]
        phase.export_CIF(str(WORKSPACE / filename))
        phase_rows.append(
            {
                "name": phase.name,
                "description": descriptions[phase.name],
                "formula": formulas[phase.name],
                "space_group": space_groups[phase.name],
                "cif_path": filename,
                "weight_fraction": replay_phases[phase.name]["weight_fraction"],
                "weight_fraction_formal_standard_uncertainty": float(sigma),
            }
        )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": float(chi_square / (len(x) - rvals["Nvars"])),
            "goodness_of_fit": float(np.sqrt(chi_square / (len(x) - rvals["Nvars"]))),
            "n_points": int(len(x)),
            "n_refined_parameters": int(rvals["Nvars"]),
            "maximum_shift_over_esd": float(rvals["Max shft/sig"]),
            "evaluation_grid": "entire observed scan",
            "calculation": "fresh GSAS-II atomic forward replay",
        },
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (WORKSPACE / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
