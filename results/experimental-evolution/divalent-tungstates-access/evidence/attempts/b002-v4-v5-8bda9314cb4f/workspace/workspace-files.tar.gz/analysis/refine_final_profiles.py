from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_inventory import run_refinement


def bounds(project: G2.G2Project, name: str, low: float, high: float) -> None:
    project.set_Controls('parmMin', low, name)
    project.set_Controls('parmMax', high, name)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--outdir', type=Path, required=True)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel('warn')

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.outdir / 'working.gpx'))
    histogram = project.histogram(0)

    for phase in project.phases():
        bounds(project, f'{phase.id}:0:Size;i', 0.020, 2.0)
        phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, [histogram])
    run_refinement(project, args.outdir, '01_sizes', cycles=10)
    run_refinement(project, args.outdir, '02_sizes_settled', cycles=8)

    for phase in project.phases():
        bounds(project, f'{phase.id}:0:Mustrain;i', 0.0, 20000.0)
        phase.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, [histogram])
    run_refinement(project, args.outdir, '03_sizes_microstrain', cycles=10)
    run_refinement(project, args.outdir, '04_sizes_microstrain_settled', cycles=8)


if __name__ == '__main__':
    main()
