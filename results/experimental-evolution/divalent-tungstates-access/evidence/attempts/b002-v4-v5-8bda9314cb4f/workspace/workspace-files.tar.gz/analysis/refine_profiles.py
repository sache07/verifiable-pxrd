from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_inventory import run_refinement


def set_bound(project: G2.G2Project, name: str, low: float, high: float) -> None:
    project.set_Controls('parmMin', low, name)
    project.set_Controls('parmMax', high, name)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--outdir', type=Path, required=True)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel('warn')
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.outdir / 'working.gpx'))
    histogram = project.histogram(0)

    for phase in project.phases():
        pid = phase.id
        set_bound(project, f'{pid}:0:Scale', 0.0, 1000.0)
        set_bound(project, f'{pid}:0:Size;i', 0.005, 10.0)
        set_bound(project, f'{pid}:0:Mustrain;i', 0.0, 50000.0)
    set_bound(project, ':0:Shift', -2000.0, 2000.0)

    # Peak shapes in the cell-only checkpoint are much narrower than the data.
    # Start from Scherrer sizes estimated from isolated reflections, then refine.
    size_starts = {'ZnWO4': 0.08, 'WO3': 0.20, 'ZnO': 0.12}
    for phase in project.phases():
        phase.setSampleProfile(histogram.name, 'size', 'isotropic', size_starts[phase.name])
        phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}}, [histogram])
    run_refinement(project, args.outdir, '03_isotropic_size', cycles=10)

    # Add one isotropic microstrain term per phase only after size is established.
    strain_starts = {'ZnWO4': 1500.0, 'WO3': 1000.0, 'ZnO': 1000.0}
    for phase in project.phases():
        phase.setSampleProfile(histogram.name, 'microstrain', 'isotropic', strain_starts[phase.name])
        phase.set_HAP_refinements({'Mustrain': {'type': 'isotropic', 'refine': True}}, [histogram])
    run_refinement(project, args.outdir, '04_size_microstrain', cycles=10)


if __name__ == '__main__':
    main()
