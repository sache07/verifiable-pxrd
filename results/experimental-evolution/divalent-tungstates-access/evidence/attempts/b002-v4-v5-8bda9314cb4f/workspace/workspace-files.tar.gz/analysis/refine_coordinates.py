from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_inventory import run_refinement


def bound_coordinates(project: G2.G2Project, phase_id: int, atom_id: int, atom, delta: float) -> None:
    # GSAS-II keys coordinate variables as dAx/dAy/dAz, but its min/max
    # controller compares the resulting absolute Ax/Ay/Az coordinate.
    for axis, value in zip('xyz', atom.coordinates):
        variable = f'{phase_id}::dA{axis}:{atom_id}'
        project.set_Controls('parmMin', float(value) - delta, variable)
        project.set_Controls('parmMax', float(value) + delta, variable)


def clear_atom_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = ' '


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--outdir', type=Path, required=True)
    parser.add_argument('--zn-y', type=float, default=0.68)
    parser.add_argument('--w-y', type=float, default=0.18)
    parser.add_argument('--light', action='store_true')
    parser.add_argument('--refine-wo3-heavy', action='store_true')
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel('warn')
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.outdir / 'working.gpx'))
    histogram = project.histogram(0)
    clear_atom_flags(project)

    # Use finite, line-supported profile values while the structure factors are
    # adjusted. These remain fixed during the coordinate stages.
    size_values = {'ZnWO4': 0.060, 'WO3': 0.100, 'ZnO': 0.100}
    strain_values = {'ZnWO4': 1000.0, 'WO3': 1000.0, 'ZnO': 1000.0}
    for phase in project.phases():
        phase.setSampleProfile(histogram.name, 'size', 'isotropic', size_values[phase.name])
        phase.setSampleProfile(histogram.name, 'microstrain', 'isotropic', strain_values[phase.name])
        hap = phase.getHAPvalues(histogram.name)
        hap['Size'][2] = [False] * len(hap['Size'][2])
        hap['Mustrain'][2] = [False] * len(hap['Mustrain'][2])

    # Alternative starts are bounded to the same P2/c wolframite topology.
    znwo4 = project.phase('ZnWO4')
    zn = znwo4.atom('Zn1')
    tungsten = znwo4.atom('W1')
    zn.coordinates = (zn.coordinates[0], args.zn_y, zn.coordinates[2])
    tungsten.coordinates = (tungsten.coordinates[0], args.w_y, tungsten.coordinates[2])

    run_refinement(project, args.outdir, '03_fixed_physical_profiles', cycles=8)

    # Refine the strongly scattering sublattices first.
    for atom_id, atom in enumerate(znwo4.atoms()):
        if atom.element in {'Zn', 'W'}:
            atom.refinement_flags = 'X'
            bound_coordinates(project, znwo4.id, atom_id, atom, 0.035)
    wo3 = project.phase('WO3')
    if args.refine_wo3_heavy:
        for atom_id, atom in enumerate(wo3.atoms()):
            if atom.element == 'W':
                atom.refinement_flags = 'X'
                bound_coordinates(project, wo3.id, atom_id, atom, 0.020)
    run_refinement(project, args.outdir, '04_heavy_coordinates', cycles=10)

    if not args.light:
        return

    # Oxygen in the major phase is supported by its broad intensity family.
    # Keep the minor WO3 oxygen framework at its physical neutron reference.
    for atom_id, atom in enumerate(znwo4.atoms()):
        if atom.element == 'O':
            atom.refinement_flags = 'X'
            bound_coordinates(project, znwo4.id, atom_id, atom, 0.010)
    run_refinement(project, args.outdir, '05_major_oxygen_coordinates', cycles=10)


if __name__ == '__main__':
    main()
