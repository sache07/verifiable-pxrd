from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_inventory import run_refinement


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    project = G2.G2Project(
        gpxfile=str(args.input), newgpx=str(args.outdir / "working.gpx")
    )
    histogram = project.histogram(0)
    omitted = project.phase(args.phase)
    hap = omitted.getHAPvalues(histogram.name)
    hap["Use"] = False
    hap["Scale"] = [0.0, False]
    omitted.set_refinements({"Cell": False})
    for atom in omitted.atoms():
        atom.refinement_flags = ""

    run_refinement(project, args.outdir, "01_omitted", cycles=12)
    run_refinement(project, args.outdir, "02_omitted_settled", cycles=8)
    audit = {
        "omitted_phase": args.phase,
        "wR_percent": histogram.get_wR(),
        "Rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    with (args.outdir / "audit.json").open("w") as stream:
        json.dump(audit, stream, indent=2, default=str)
        stream.write("\n")


if __name__ == "__main__":
    main()
