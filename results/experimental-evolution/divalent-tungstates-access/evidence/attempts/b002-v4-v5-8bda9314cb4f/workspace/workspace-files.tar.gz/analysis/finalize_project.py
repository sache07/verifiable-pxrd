from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_inventory import run_refinement


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
SOURCE = HERE / "wo3_texture_scan" / "axis_100" / "texture_settled.gpx"
OUTDIR = HERE / "final_checkpoint"


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(SOURCE), newgpx=str(WORKSPACE / "final.gpx")
    )
    histogram = project.histogram(0)

    # Lock the accepted, geometry-audited coordinates. Two O z coordinates
    # reached their deliberately tight physical bounds; the values are kept,
    # but they are not left as active/frozen variables in the submission.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Zero isotropic strain is the supported endpoint for ZnWO4 and ZnO.
    # Preserve those endpoints as fixed values; retain the positive WO3 term.
    for phase_name in ("ZnWO4", "ZnO"):
        hap = project.phase(phase_name).getHAPvalues(histogram.name)
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])

    project.set_Frozen()
    project.save()
    run_refinement(project, OUTDIR, "01_final", cycles=10)
    run_refinement(project, OUTDIR, "02_final_settled", cycles=8)


if __name__ == "__main__":
    main()
