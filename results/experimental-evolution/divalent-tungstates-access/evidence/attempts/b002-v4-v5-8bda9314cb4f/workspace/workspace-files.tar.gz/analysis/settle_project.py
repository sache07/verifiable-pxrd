from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_inventory import run_refinement


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--prefix", default="settled")
    parser.add_argument("--passes", type=int, default=2)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(args.input), newgpx=str(args.outdir / "working.gpx")
    )
    for index in range(1, args.passes + 1):
        run_refinement(
            project,
            args.outdir,
            f"{args.prefix}_{index:02d}",
            cycles=args.cycles,
        )


if __name__ == "__main__":
    main()
