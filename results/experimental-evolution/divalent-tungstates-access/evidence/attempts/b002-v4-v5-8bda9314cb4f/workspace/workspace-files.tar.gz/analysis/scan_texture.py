from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_inventory import run_refinement


AXES = [
    (1, 1, 1),
    (1, 1, -1),
    (1, 0, 0),
    (0, 1, 0),
    (0, 0, 1),
    (1, 0, 1),
    (1, 0, -1),
    (0, 1, 1),
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--outdir', type=Path, required=True)
    parser.add_argument('--phase', default='ZnWO4')
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel('warn')

    for axis in AXES:
        tag = ''.join('m' + str(abs(v)) if v < 0 else str(v) for v in axis)
        branch = args.outdir / f'axis_{tag}'
        branch.mkdir(parents=True, exist_ok=True)
        project = G2.G2Project(
            gpxfile=str(args.input), newgpx=str(branch / 'working.gpx')
        )
        phase = project.phase(args.phase)
        hap = phase.getHAPvalues(project.histogram(0).name)
        hap['Pref.Ori.'][0] = 'MD'
        hap['Pref.Ori.'][1] = 1.0
        hap['Pref.Ori.'][2] = True
        hap['Pref.Ori.'][3] = list(axis)
        project.set_Controls('parmMin', 0.2, f'{phase.id}:0:MD')
        project.set_Controls('parmMax', 5.0, f'{phase.id}:0:MD')
        run_refinement(project, branch, 'texture', cycles=10)
        if project.get_Frozen():
            run_refinement(project, branch, 'texture_settled', cycles=8)


if __name__ == '__main__':
    main()
