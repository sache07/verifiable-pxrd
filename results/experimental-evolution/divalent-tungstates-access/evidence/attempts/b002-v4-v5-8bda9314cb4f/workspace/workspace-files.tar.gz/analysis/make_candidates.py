from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif')


def cod_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


# COD 2311041 is a physical room-temperature P21/c WO3 refinement. Reduce its
# highly skewed published setting while retaining the same structure.
wo3 = CifParser(str(cod_path('2311041')), frac_tolerance=0).parse_structures(primitive=False)[0]
wo3_niggli = wo3.get_reduced_structure(reduction_algo='niggli')
wo3_lll = wo3.get_reduced_structure(reduction_algo='LLL')
CifWriter(wo3_niggli, symprec=0.01, refine_struct=False).write_file(ROOT / 'wo3_2311041_reduced.cif')
CifWriter(wo3_lll, symprec=0.01, refine_struct=False).write_file(ROOT / 'wo3_2311041_lll.cif')

# Copy the chemically plausible ZnO precursor candidate into a normalized CIF.
zno = CifParser(str(cod_path('9004178')), frac_tolerance=0).parse_structures(primitive=False)[0]
CifWriter(zno, symprec=0.01, refine_struct=True).write_file(ROOT / 'zno_9004178.cif')
