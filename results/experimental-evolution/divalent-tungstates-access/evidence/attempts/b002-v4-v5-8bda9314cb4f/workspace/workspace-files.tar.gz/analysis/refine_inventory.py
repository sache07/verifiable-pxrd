from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parent
RESOURCE = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif')


def cod_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f'{cod_id}.cif'


def weights(project: G2.G2Project, histogram) -> dict[str, float]:
    terms = {
        phase.name: float(phase.data['General']['Mass'])
        * float(phase.getHAPvalues(histogram.name)['Scale'][0])
        for phase in project.phases()
    }
    total = sum(max(0.0, value) for value in terms.values())
    return {name: max(0.0, value) / total for name, value in terms.items()}


def snapshot(project: G2.G2Project, outdir: Path, label: str) -> None:
    histogram = project.histogram(0)
    profile = {
        key: np.asarray(histogram.getdata(key), dtype=float)
        for key in ['X', 'Yobs', 'Ycalc', 'Background', 'Residual', 'Yweight']
    }
    residual = profile['Residual']
    peaks, props = find_peaks(residual, prominence=80.0, distance=5)
    order = np.argsort(props['prominences'])[::-1]
    report = {
        'label': label,
        'wR_percent': histogram.get_wR(),
        'Rvals': project.data.get('Covariance', {}).get('data', {}).get('Rvals', {}),
        'sample_parameters': histogram.SampleParameters,
        'instrument_parameters': histogram.InstrumentParameters,
        'weight_fractions': weights(project, histogram),
        'phases': {},
        'largest_positive_residual_peaks': [
            {
                'two_theta_deg': float(profile['X'][peaks[index]]),
                'prominence_counts': float(props['prominences'][index]),
                'residual_counts': float(residual[peaks[index]]),
            }
            for index in order[:40]
        ],
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram.name)
        report['phases'][phase.name] = {
            'cell': phase.get_cell(),
            'mass': phase.data['General']['Mass'],
            'scale': hap['Scale'],
            'size': hap['Size'],
            'microstrain': hap['Mustrain'],
            'preferred_orientation': hap['Pref.Ori.'],
            'atoms': [
                {
                    'label': atom.label,
                    'type': atom.element,
                    'xyz': [float(x) for x in atom.coordinates],
                    'occupancy': float(atom.occupancy),
                    'uiso': float(atom.uiso),
                    'refinement_flags': atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    with (outdir / f'{label}.json').open('w') as stream:
        json.dump(report, stream, indent=2, default=lambda value: value.item() if isinstance(value, np.generic) else str(value))
        stream.write('\n')
    shutil.copy2(project.filename, outdir / f'{label}.gpx')
    print(json.dumps({
        'label': label,
        'wR_percent': report['wR_percent'],
        'weight_fractions': report['weight_fractions'],
        'shift_um': histogram.SampleParameters['Shift'][0],
        'cells': {name: data['cell'] for name, data in report['phases'].items()},
        'scales': {name: data['scale'][0] for name, data in report['phases'].items()},
        'residual_peaks': report['largest_positive_residual_peaks'][:12],
    }, indent=2))


def run_refinement(project: G2.G2Project, outdir: Path, label: str, cycles: int = 6) -> None:
    project.set_Controls('cycles', cycles)
    project.refine()
    snapshot(project, outdir, label)


def build(outdir: Path, include_zno: bool) -> G2.G2Project:
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(outdir / 'working.gpx'))
    histogram = project.add_powder_histogram(
        str(HERE / 'pattern.xye'), str(HERE / 'instrument.instprm'), fmthint='xye'
    )
    phase_files = [
        ('ZnWO4', HERE / 'znwo4_start.cif', 60.0),
        ('WO3', cod_path('2311041'), 2.0),
    ]
    if include_zno:
        phase_files.append(('ZnO', HERE / 'zno_9004178.cif', 0.2))
    for phase_name, filename, scale in phase_files:
        phase = project.add_phase(
            str(filename), phasename=phase_name, histograms=[histogram], fmthint='CIF'
        )
        phase.getHAPvalues(histogram.name)['Scale'] = [scale, False]

    histogram.SampleParameters['Scale'] = [1.0, False]
    histogram.SampleParameters['Type'] = 'Bragg-Brentano'
    histogram.SampleParameters['Gonio. radius'] = 200.0
    histogram.SampleParameters['Shift'] = [-500.0, False]
    histogram.set_refinements({
        'Background': {
            'type': 'chebyschev-1',
            'no. coeffs': 10,
            'coeffs': [900.0, -200.0, 100.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            'refine': False,
        }
    })
    project.save()
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--outdir', type=Path, required=True)
    parser.add_argument('--zno', action='store_true')
    args = parser.parse_args()

    G2.SetPrintLevel('warn')
    project = build(args.outdir, args.zno)
    histogram = project.histogram(0)

    # The two peak families are already aligned by the physically expected
    # specimen displacement. Establish positive scales and the smooth baseline.
    histogram.set_refinements({'Background': {'refine': True}})
    for phase in project.phases():
        phase.set_HAP_refinements({'Scale': True}, [histogram])
    run_refinement(project, args.outdir, '01_scales_background', cycles=6)

    # Refine the common Bragg-Brentano displacement and each symmetry-constrained cell.
    histogram.set_refinements({'Sample Parameters': ['Shift']})
    for phase in project.phases():
        phase.set_refinements({'Cell': True})
    run_refinement(project, args.outdir, '02_cells_shift', cycles=8)


if __name__ == '__main__':
    main()
