from pathlib import Path
import sys

import numpy as np
from pymatgen.io.cif import CifParser


for name in sys.argv[1:]:
    path = Path(name)
    structure = CifParser(str(path), frac_tolerance=0).parse_structures(primitive=False)[0]
    distances = structure.distance_matrix.copy()
    distances[distances < 1e-8] = np.inf
    print(path)
    print(' composition:', structure.composition.formula)
    print(' symmetry:', structure.get_space_group_info())
    print(' lattice:', tuple(round(x, 6) for x in (*structure.lattice.abc, *structure.lattice.angles)))
    print(' volume/density:', structure.volume, structure.density)
    print(' sites/minimum distance:', len(structure), distances.min())
