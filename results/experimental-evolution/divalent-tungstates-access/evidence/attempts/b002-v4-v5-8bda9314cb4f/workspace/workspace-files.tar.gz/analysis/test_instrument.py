from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_inventory import run_refinement


def set_bounds(project: G2.G2Project, name: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, name)
    project.set_Controls("parmMax", high, name)


def width_audit(project: G2.G2Project) -> dict[str, object]:
    histogram = project.histogram(0)
    params = histogram.InstrumentParameters
    u = float(params["U"][1])
    v = float(params["V"][1])
    w = float(params["W"][1])
    two_theta = np.asarray(histogram.getdata("X"), dtype=float)
    tangent = np.tan(np.deg2rad(two_theta / 2.0))
    gaussian_sq = u * tangent**2 + v * tangent + w
    return {
        "U": u,
        "V": v,
        "W": w,
        "minimum_Gaussian_FWHM_squared": float(np.min(gaussian_sq)),
        "maximum_Gaussian_FWHM_squared": float(np.max(gaussian_sq)),
        "minimum_at_two_theta_deg": float(two_theta[np.argmin(gaussian_sq)]),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--mode", choices=("w", "uvw"), required=True)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    project = G2.G2Project(
        gpxfile=str(args.input), newgpx=str(args.outdir / "working.gpx")
    )
    histogram = project.histogram(0)
    terms = ["W"] if args.mode == "w" else ["U", "V", "W"]
    set_bounds(project, ":0:U", 0.0, 50.0)
    set_bounds(project, ":0:V", -50.0, 50.0)
    set_bounds(project, ":0:W", 0.05, 50.0)
    histogram.set_refinements({"Instrument Parameters": terms})

    run_refinement(project, args.outdir, f"01_{args.mode}", cycles=10)
    run_refinement(project, args.outdir, f"02_{args.mode}_settled", cycles=8)
    with (args.outdir / "width_audit.json").open("w") as stream:
        json.dump(width_audit(project), stream, indent=2)
        stream.write("\n")
    print(json.dumps(width_audit(project), indent=2))


if __name__ == "__main__":
    main()
