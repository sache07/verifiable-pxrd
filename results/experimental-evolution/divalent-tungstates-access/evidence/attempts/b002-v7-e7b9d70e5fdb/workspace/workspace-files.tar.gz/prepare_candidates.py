#!/usr/bin/env python3
"""Prepare composition-adapted structural starts from the frozen COD index."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif")
OUT = Path("work/candidates")
COMMON_WOLFRAMITE_LATTICE = Lattice.monoclinic(4.6598, 5.6862, 4.9159, 90.521)
COMMON_VOLUME_PER_FORMULA = COMMON_WOLFRAMITE_LATTICE.volume / 2.0


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


RECORDS = [
    {
        "name": "ZnWO4_from_CoMoO4_II",
        "cod_id": "7205001",
        "substitutions": {"Co": "Zn", "Mo": "W"},
        "role": "wolframite P2/c start A",
    },
    {
        "name": "ZnWO4_from_ScNbO4",
        "cod_id": "5910338",
        "substitutions": {"Sc": "Zn", "Nb": "W"},
        "role": "wolframite P2/c start B",
    },
    {
        "name": "ZnWO4_from_FeNbO4",
        "cod_id": "2002235",
        "substitutions": {"Fe": "Zn", "Nb": "W"},
        "role": "wolframite P2/c start C (basis/origin control)",
    },
    {
        "name": "ZnWO4_from_ZnMoO4",
        "cod_id": "1528282",
        "substitutions": {"Mo": "W"},
        "role": "triclinic P-1 composition-near control",
    },
    {
        "name": "ZnWO4_from_CaWO4_scheelite",
        "cod_id": "7219229",
        "substitutions": {"Ca": "Zn"},
        "role": "scheelite I41/a symmetry control",
    },
]


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    provenance = []
    for record in RECORDS:
        source = cod_path(record["cod_id"])
        # A few old COD records enumerate symmetry-equivalent atoms explicitly.
        # Pymatgen reports their summed multiplicity as an occupancy; accepting
        # and normalizing it recovers the stated fully occupied structure.
        structure = CifParser(source, occupancy_tolerance=10).parse_structures(
            primitive=False
        )[0]
        structure.remove_oxidation_states()
        structure.replace_species(record["substitutions"])
        destination = OUT / f"{record['name']}.cif"
        CifWriter(structure, symprec=0.01, write_site_properties=True).write_file(destination)
        if record["cod_id"] in {"7205001", "5910338", "2002235"}:
            comparison_lattice = COMMON_WOLFRAMITE_LATTICE
        else:
            _, formula_units = structure.composition.get_reduced_composition_and_factor()
            target_volume = COMMON_VOLUME_PER_FORMULA * float(formula_units)
            comparison_lattice = Lattice(
                structure.lattice.matrix
                * (target_volume / structure.volume) ** (1.0 / 3.0)
            )
        comparison = Structure(
            comparison_lattice,
            structure.species,
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
        comparison_destination = OUT / f"{record['name']}_comparison.cif"
        CifWriter(
            comparison, symprec=0.01, write_site_properties=True
        ).write_file(comparison_destination)
        provenance.append(
            {
                **record,
                "source": str(source),
                "output": str(destination),
                "comparison_output": str(comparison_destination),
                "formula": structure.composition.reduced_formula,
                "sites": len(structure),
                "cell": {
                    "a": structure.lattice.a,
                    "b": structure.lattice.b,
                    "c": structure.lattice.c,
                    "alpha": structure.lattice.alpha,
                    "beta": structure.lattice.beta,
                    "gamma": structure.lattice.gamma,
                },
            }
        )
    (OUT / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
