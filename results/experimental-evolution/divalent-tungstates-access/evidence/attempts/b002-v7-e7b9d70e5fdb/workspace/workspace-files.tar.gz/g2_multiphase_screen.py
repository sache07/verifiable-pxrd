#!/usr/bin/env python3
"""Build and equally screen a ZnWO4/WO3/ZnO Rietveld model in GSAS-II."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def instrument_text() -> str:
    return (
        "# Synthetic laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.10;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def background_coefficients(pattern: Path, degree: int = 8) -> list[float]:
    x, y = np.loadtxt(pattern, delimiter=",", skiprows=1).T
    baseline = percentile_filter(y, percentile=15, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, degree).tolist()


def clear_frozen(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def covariance_state(project: G2.G2Project) -> dict:
    data = project.data.get("Covariance", {}).get("data", {})
    rvals = data.get("Rvals", {})
    return {
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "vary_list": [str(v) for v in data.get("varyList", [])],
    }


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    weighted = {}
    for phase_number, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()} if total else weighted


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    phases = []
    for phase_number, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    return {
        "stage": label,
        "Rwp_percent": None if hist.get_wR() is None else float(hist.get_wR()),
        "fractions": mass_fractions(project),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phases,
        **covariance_state(project),
    }


def run_stage(
    project: G2.G2Project,
    output: Path,
    records: list[dict],
    label: str,
    cycles: int = 10,
) -> None:
    clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = snapshot(project, label)
    records.append(record)
    print(json.dumps(record, default=str), flush=True)
    shutil.copy2(
        output, output.with_name(output.stem + f"_{len(records):02d}_{label}.gpx")
    )


def clear_coordinate_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def set_isotropic_adp(atom, value: float) -> None:
    """Normalize imported anisotropic source ADPs to the lab's scalar-U model."""
    atom.data[atom.cia] = "I"
    atom.data[atom.cia + 1] = float(value)


def install_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histograms()[0]
    hid = hist.data["data"][0]["hId"]
    for name, low, high in [
        ("Zero", -0.25, 0.25),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
        ("Shift", -800.0, 800.0),
        ("SurfRoughA", 0.0, 0.6),
        ("SurfRoughB", 0.0, 0.5),
    ]:
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    for phase_number, phase in enumerate(project.phases()):
        pid = phase.data["pId"]
        cell = phase.get_cell()
        lengths = [float(cell[f"length_{axis}"]) for axis in "abc"]
        # Cell limits are added only after a stable metric is established.
        # Early reciprocal-metric bounds can make GSAS-II's trial step
        # singular when only one cell is active in a multiphase model.
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", 1.0e8, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")
        for atom_index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half_width = 0.12 / max(length, 1.0e-6)
                variable = f"{pid}::dA{axis}:{atom_index}"
                project.set_Controls("parmMin", float(value) - half_width, variable=variable)
                project.set_Controls("parmMax", float(value) + half_width, variable=variable)


def set_instrument_flags(hist, names: list[str], value: bool) -> None:
    for name in names:
        hist.InstrumentParameters[name][2] = value


def refresh(project: G2.G2Project):
    """Get wrappers backed by the dictionary reloaded after a refinement."""
    return project.phases(), project.histograms()[0]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("primary", type=Path)
    parser.add_argument("wo3", type=Path)
    parser.add_argument("zno", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument(
        "--coordinates", choices=("none", "primary", "all"), default="none"
    )
    parser.add_argument("--stop-after", choices=("zero", "complete"), default="complete")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    inst = args.output.parent / f"{args.output.stem}.instprm"
    inst.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output))
    inputs = [
        (args.primary, "ZnWO4_wolframite"),
        (args.wo3, "WO3"),
        (args.zno, "ZnO_wurtzite"),
    ]
    phases = [
        project.add_phase(str(path.resolve()), phasename=name, fmthint="CIF")
        for path, name in inputs
    ]
    hist = project.add_powder_histogram(
        str(args.pattern.resolve()), str(inst.resolve()), phases="all", fmthint="comma"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    coeffs = background_coefficients(args.pattern)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": False,
            }
        }
    )
    initial_scales = [80.0, 12.0, 12.0]
    for phase, scale in zip(phases, initial_scales):
        for atom in phase.atoms():
            set_isotropic_adp(atom, 0.01)
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        phase.set_HAP_refinements({"Scale": True})

    install_bounds(project)
    records: list[dict] = []
    project.set_Controls("cycles", 0)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(snapshot(project, "initial"))

    hist.set_refinements({"Background": True})
    run_stage(project, args.output, records, "scales_background", 10)
    phases, hist = refresh(project)

    phase_names = [phase.name for phase in phases]
    for phase_name in phase_names:
        for phase in project.phases():
            phase.set_refinements({"Cell": False})
        phase = project.phase(phase_name)
        phase.set_refinements({"Cell": True})
        run_stage(project, args.output, records, f"{phase_name}_cell", 4)
        phases, hist = refresh(project)
    for phase in phases:
        phase.set_refinements({"Cell": False})

    set_instrument_flags(hist, ["Zero"], True)
    run_stage(project, args.output, records, "zero", 10)
    phases, hist = refresh(project)
    if args.stop_after == "zero":
        project.save()
        (args.output.with_suffix(".json")).write_text(
            json.dumps(records, indent=2, default=str) + "\n"
        )
        return
    set_instrument_flags(hist, ["Zero"], False)
    hist.SampleParameters["Shift"][1] = True
    run_stage(project, args.output, records, "shift", 10)
    phases, hist = refresh(project)
    set_instrument_flags(hist, ["Zero"], True)
    run_stage(project, args.output, records, "zero_shift_joint", 12)
    phases, hist = refresh(project)

    if args.coordinates != "none":
        selected_names = [p.name for p in (phases[:1] if args.coordinates == "primary" else phases)]
        for phase_name in selected_names:
            phase = project.phase(phase_name)
            clear_coordinate_flags(project)
            for atom in phase.atoms():
                if atom.element.strip().upper() != "O":
                    atom.refinement_flags = "X"
            run_stage(project, args.output, records, f"{phase.name}_heavy_coords", 10)
            phases, hist = refresh(project)
            phase = project.phase(phase_name)
            clear_coordinate_flags(project)
            for atom in phase.atoms():
                if atom.element.strip().upper() == "O":
                    atom.refinement_flags = "X"
            run_stage(project, args.output, records, f"{phase.name}_oxygen_coords", 12)
            phases, hist = refresh(project)
        clear_coordinate_flags(project)

    set_instrument_flags(hist, ["U", "W", "X"], True)
    run_stage(project, args.output, records, "instrument_profile", 12)
    phases, hist = refresh(project)
    set_instrument_flags(hist, ["U", "W", "X"], False)

    phase_names = [phase.name for phase in phases]
    for phase_name in phase_names:
        phase = project.phase(phase_name)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.3, "refine": True}}
        )
        run_stage(project, args.output, records, f"{phase.name}_size", 10)
        phases, hist = refresh(project)
        phase = project.phase(phase_name)
        phase.clear_HAP_refinements({"Size": True})
    for phase_name in phase_names:
        phase = project.phase(phase_name)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        run_stage(project, args.output, records, f"{phase.name}_mustrain", 10)
        phases, hist = refresh(project)
        phase = project.phase(phase_name)
        phase.clear_HAP_refinements({"Mustrain": True})

    set_instrument_flags(hist, ["U", "W", "X"], True)
    phases, hist = refresh(project)
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_stage(project, args.output, records, "profile_settle", 12)
    phases, hist = refresh(project)

    clear_coordinate_flags(project)
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Scale": True})
    set_instrument_flags(hist, ["Zero", "U", "W", "X"], False)
    hist.SampleParameters["Shift"][1] = False
    hist.clear_refinements({"Background": True})
    clear_frozen(project)
    project.save()
    (args.output.with_suffix(".json")).write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
