#!/usr/bin/env python3
"""Run an equally developed, bounded GSAS-II checkpoint for one phase start."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "# Synthetic laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def initial_background(pattern: Path, degree: int = 8) -> list[float]:
    x, y = np.loadtxt(pattern, delimiter=",", skiprows=1).T
    baseline = percentile_filter(y, percentile=15, size=401, mode="nearest")
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, degree).tolist()


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    return {
        "stage": label,
        "Rwp_percent": None if hist.get_wR() is None else float(hist.get_wR()),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "phases": phases,
        "vary_list": [str(v) for v in covariance.get("varyList", [])],
    }


def clear_coordinate_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def run_stage(project: G2.G2Project, output: Path, records: list[dict], label: str, cycles: int = 8) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rec = state(project, label)
    records.append(rec)
    print(json.dumps(rec, default=str), flush=True)
    shutil.copy2(output, output.with_name(output.stem + f"_{len(records):02d}_{label}.gpx"))


def install_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    hist = project.histograms()[0]
    hid = hist.data["data"][0]["hId"]
    for name, low, high in [
        ("Zero", -0.25, 0.25),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
    ]:
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    for phase in project.phases():
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", 1.0e8, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")
        cell = phase.get_cell()
        lengths = [float(cell[f"length_{axis}"]) for axis in "abc"]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                width = 0.10 / max(length, 1.0e-6)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - width, variable=variable)
                project.set_Controls("parmMax", float(value) + width, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cif", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    inst = args.output.parent / "candidate.instprm"
    inst.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output))
    phase = project.add_phase(str(args.cif.resolve()), phasename=args.cif.stem, fmthint="CIF")
    hist = project.add_powder_histogram(
        str(args.pattern.resolve()), str(inst.resolve()), phases="all", fmthint="comma"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    coeffs = initial_background(args.pattern)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": False,
            }
        }
    )
    for atom in phase.atoms():
        atom.uiso = 0.01
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [10.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    install_bounds(project)
    records: list[dict] = []
    project.set_Controls("cycles", 0)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(state(project, "initial"))

    hist.set_refinements({"Background": True})
    phase.set_HAP_refinements({"Scale": True})
    run_stage(project, args.output, records, "scale_background", 10)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_stage(project, args.output, records, "cell_zero", 10)

    clear_coordinate_flags(project)
    for atom in phase.atoms():
        if atom.element.strip().upper() != "O":
            atom.refinement_flags = "X"
    run_stage(project, args.output, records, "heavy_coordinates", 10)

    clear_coordinate_flags(project)
    for atom in phase.atoms():
        if atom.element.strip().upper() == "O":
            atom.refinement_flags = "X"
    run_stage(project, args.output, records, "oxygen_coordinates", 12)
    clear_coordinate_flags(project)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.3, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    run_stage(project, args.output, records, "bounded_profile", 12)
    clear_coordinate_flags(project)
    phase.clear_refinements({"Cell": True})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X"]})
    project.save()

    (args.output.with_suffix(".json")).write_text(json.dumps(records, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
