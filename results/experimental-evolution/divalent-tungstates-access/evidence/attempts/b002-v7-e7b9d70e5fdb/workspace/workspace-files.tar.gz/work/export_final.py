from __future__ import annotations

import hashlib
import json
import shutil
from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parents[1]
replay_dir = root / "work" / "replay_final"
project = root / "final.gpx"

replay = json.loads((replay_dir / "replay.json").read_text())
if replay.get("status") != "replayed":
    raise RuntimeError("The locked final project did not replay successfully")

project_sha256 = hashlib.sha256(project.read_bytes()).hexdigest()
if project_sha256 != replay["project_sha256"] or not replay.get("project_unchanged"):
    raise RuntimeError("The project hash does not match the successful replay")

exports = {
    "ZnWO4_wolframite": {
        "filename": "ZnWO4_wolframite.cif",
        "formula": "ZnWO4",
        "space_group": "P 2/c",
        "phase_description": "wolframite-type zinc tungstate",
    },
    "WO3": {
        "filename": "WO3_monoclinic.cif",
        "formula": "WO3",
        "space_group": "P 21/n",
        "phase_description": "monoclinic tungsten trioxide",
    },
    "ZnO_wurtzite": {
        "filename": "ZnO_wurtzite.cif",
        "formula": "ZnO",
        "space_group": "P 63 m c",
        "phase_description": "wurtzite zinc oxide",
    },
}

phase_rows = []
for phase in replay["phases"]:
    name = phase["name"]
    if name not in exports:
        raise RuntimeError(f"Unexpected replay phase: {name}")
    info = exports[name]
    source = replay_dir / phase["cif"]
    destination = root / info["filename"]
    shutil.copyfile(source, destination)
    phase_rows.append(
        {
            "name": name,
            "phase": info["phase_description"],
            "formula": info["formula"],
            "space_group": info["space_group"],
            "cif_path": info["filename"],
            "weight_fraction": float(phase["weight_fraction"]),
            "weight_percent": 100.0 * float(phase["weight_fraction"]),
        }
    )

fraction_sum = sum(row["weight_fraction"] for row in phase_rows)
if not np.isclose(fraction_sum, 1.0, rtol=0, atol=1e-12):
    raise RuntimeError("Replayed crystalline fractions do not sum to one")

with np.load(replay_dir / "prediction.npz", allow_pickle=False) as profile:
    x = profile["x"].copy()
    observed = profile["observed"].copy()
    calculated = profile["predicted"].copy()

public = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
    raise RuntimeError("Replay grid or observed intensities differ from pattern.csv")
if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
    raise RuntimeError("Replay contains invalid calculated intensities")

difference = observed - calculated
profile_table = np.column_stack((x, observed, calculated, difference))
np.savetxt(
    root / "fit.csv",
    profile_table,
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.10g", "%.10f", "%.10f"],
)

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
n_observations = int(len(observed))
n_refined_parameters = 12
rwp_percent = float(100.0 * np.sqrt(chi_square / denominator))
rp_percent = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
gof = float(np.sqrt(chi_square / (n_observations - n_refined_parameters)))

result = {
    "schema_version": 1,
    "refinement_histogram": replay["histogram"],
    "crystalline_fraction_basis": (
        "Normalized over the three modeled crystalline phases; amorphous or "
        "unmodeled material is not quantified."
    ),
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": rwp_percent,
        "Rp_percent": rp_percent,
        "goodness_of_fit": gof,
        "chi_square": chi_square,
        "n_observations": n_observations,
        "n_refined_parameters": n_refined_parameters,
        "weighting": "w = 1/max(observed_counts, 1)",
        "profile_range_two_theta_deg": [float(x[0]), float(x[-1])],
    },
    "project": {
        "path": "final.gpx",
        "sha256": project_sha256,
        "replay_status": replay["status"],
        "project_unchanged_during_replay": bool(replay["project_unchanged"]),
        "profile_regeneration": replay["regeneration"],
    },
}
(root / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

print(json.dumps(result, indent=2))
