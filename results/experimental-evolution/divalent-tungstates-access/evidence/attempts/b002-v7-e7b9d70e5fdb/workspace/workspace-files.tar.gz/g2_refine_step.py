#!/usr/bin/env python3
"""Apply one controlled GSAS-II refinement step to a saved powder project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


INSTRUMENT_LIMITS = {
    "Zero": (-0.25, 0.25),
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.1, 6.0),
    "SH/L": (0.005, 0.10),
    "Polariz.": (0.5, 1.0),
}
SAMPLE_LIMITS = {
    "Shift": (-800.0, 800.0),
    "SurfRoughA": (0.0, 0.6),
    "SurfRoughB": (0.0, 0.5),
}


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def install_bounds(project: G2.G2Project, coordinate_window_A: float = 0.10) -> None:
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    hist = project.histograms()[0]
    hid = hist.data["data"][0]["hId"]
    for name, (low, high) in {**INSTRUMENT_LIMITS, **SAMPLE_LIMITS}.items():
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    for phase in project.phases():
        pid = phase.data["pId"]
        cell = phase.get_cell()
        lengths = [float(cell[f"length_{axis}"]) for axis in "abc"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", 1.0e8, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:{hid}:MD")
        for atom_index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half_width = coordinate_window_A / max(length, 1.0e-6)
                variable = f"{pid}::dA{axis}:{atom_index}"
                project.set_Controls("parmMin", float(value) - half_width, variable=variable)
                project.set_Controls("parmMax", float(value) + half_width, variable=variable)


def select_phase(project: G2.G2Project, token: str):
    try:
        return project.phase(int(token))
    except (ValueError, KeyError):
        phase = project.phase(token)
        if phase is None:
            raise ValueError(f"unknown phase {token!r}")
        return phase


def enable_base(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def apply_action(project: G2.G2Project, args) -> None:
    hist = project.histograms()[0]
    phase = select_phase(project, args.phase) if args.phase is not None else None
    if args.action == "cell":
        phase.set_refinements({"Cell": True})
    elif args.action == "zero":
        hist.InstrumentParameters["Zero"][2] = True
    elif args.action == "shift":
        hist.SampleParameters["Shift"][1] = True
    elif args.action == "calibration":
        hist.InstrumentParameters["Zero"][2] = True
        hist.SampleParameters["Shift"][1] = True
    elif args.action == "instrument":
        for name in args.parameters.split(","):
            hist.InstrumentParameters[name][2] = True
    elif args.action == "sample":
        for name in args.parameters.split(","):
            hist.SampleParameters[name][1] = True
    elif args.action == "size":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif args.action == "strain":
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    elif args.action == "profile-joint":
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        hist.InstrumentParameters["W"][2] = True
    elif args.action == "texture":
        axis = [int(value) for value in args.axis.split(",")]
        if len(axis) != 3 or axis == [0, 0, 0]:
            raise ValueError("--axis must be a nonzero h,k,l triplet")
        preferred_orientation = phase.data["Histograms"][hist.name]["Pref.Ori."]
        preserve_ratio = (
            preferred_orientation[0] == "MD"
            and list(preferred_orientation[3]) == axis
        )
        preferred_orientation[0] = "MD"
        if not preserve_ratio:
            preferred_orientation[1] = 1.0
        preferred_orientation[2] = True
        preferred_orientation[3] = axis
    elif args.action == "coordinates-heavy":
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element.strip().upper() != "O" else " "
    elif args.action == "coordinates-oxygen":
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element.strip().upper() == "O" else " "
    elif args.action == "coordinates-all":
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    elif args.action == "base":
        pass
    else:
        raise ValueError(args.action)


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    values = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        values[phase.name] = max(
            0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        )
    total = sum(values.values())
    return {name: value / total for name, value in values.items()} if total else values


def report(project: G2.G2Project, action: str) -> dict:
    hist = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return {
        "action": action,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": mass_fractions(project),
        "instrument": {
            name: float(value[1])
            for name, value in hist.InstrumentParameters.items()
            if name in INSTRUMENT_LIMITS
        },
        "sample": {
            name: float(hist.SampleParameters[name][0]) for name in SAMPLE_LIMITS
        },
        "background_min": float(min(hist.data["data"][1][4])),
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "strain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "texture": {
                    "model": phase.data["Histograms"][hist.name]["Pref.Ori."][0],
                    "ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                    "axis": phase.data["Histograms"][hist.name]["Pref.Ori."][3],
                },
            }
            for phase in project.phases()
        ],
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "vary_list": [str(v) for v in covariance.get("varyList", [])],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--action",
        required=True,
        choices=(
            "base", "cell", "zero", "shift", "calibration", "instrument", "sample",
            "size", "strain", "profile-joint", "texture", "coordinates-heavy", "coordinates-oxygen",
            "coordinates-all",
        ),
    )
    parser.add_argument("--phase")
    parser.add_argument("--parameters", default="U,W,X")
    parser.add_argument("--axis", default="0,0,1")
    parser.add_argument("--coordinate-window-A", type=float, default=0.10)
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--no-base", action="store_true")
    args = parser.parse_args()
    if args.action in {
        "cell", "size", "strain", "profile-joint", "texture", "coordinates-heavy", "coordinates-oxygen",
        "coordinates-all",
    } and args.phase is None:
        parser.error(f"--phase is required for {args.action}")

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    clear_flags(project)
    install_bounds(project, coordinate_window_A=args.coordinate_window_A)
    if not args.no_base:
        enable_base(project)
    apply_action(project, args)
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    result = report(project, args.action)
    args.output.with_suffix(".step.json").write_text(
        json.dumps(result, indent=2, default=str) + "\n"
    )
    print(json.dumps(result, default=str), flush=True)


if __name__ == "__main__":
    main()
