#!/usr/bin/env python3
"""Project the refined coordinates onto the known mismatch bounds and replay."""

from __future__ import annotations

import argparse
from pathlib import Path
import math
import numpy as np

from GSASII import GSASIIscriptable as G2


SOURCE = {
    "CaWO4_scheelite": {
        "O1": np.array([0.15202, 0.01135, 0.20864]),
    },
    "WO3_2311041": {
        "W1": np.array([0.028, 0.037, 0.746]),
        "W2": np.array([0.534, 0.023, 0.750]),
    },
}


def lattice_matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    alpha = math.radians(cell["angle_alpha"])
    beta = math.radians(cell["angle_beta"])
    gamma = math.radians(cell["angle_gamma"])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    cz = math.sqrt(max(0.0, c * c - cx * cx - cy * cy))
    return np.vstack((va, vb, [cx, cy, cz]))


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}


def project_group(phase: G2.G2Phase, labels: list[str], maximum_rms_A: float) -> None:
    matrix = lattice_matrix(phase.get_cell())
    deltas = []
    for label in labels:
        current = np.array(phase.atom(label).coordinates)
        delta = current - SOURCE[phase.name][label]
        delta -= np.rint(delta)
        deltas.append(delta)
    rms = float(np.sqrt(np.mean([np.dot(d @ matrix, d @ matrix) for d in deltas])))
    factor = min(1.0, maximum_rms_A / max(rms, 1e-15))
    for label, delta in zip(labels, deltas):
        phase.atom(label).coordinates = tuple((SOURCE[phase.name][label] + factor * delta).tolist())
    print(f"{phase.name} {labels}: preprojection RMS={rms:.8f} A, factor={factor:.8f}")


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"{label}: {hist.residuals}")
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        print(phase.name, phase.get_cell(), "scale", hap["Scale"][0])
        for atom in phase.atoms():
            print(" ", atom.label, atom.coordinates, atom.uiso)
    total = sum(masses)
    print("weight fractions", [v / total for v in masses])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()))
    project.save(str(args.outdir / "physical_projected.gpx"))
    clear_flags(project)
    ca, wo = project.phases()
    project_group(ca, ["O1"], 0.050)
    project_group(wo, ["W1", "W2"], 0.040)

    project.set_Controls("cycles", 0)
    project.refine()
    report(project, "projected replay")
    project.save(str(args.outdir / "projected_replay.gpx"))

    hist = project.histogram(0)
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 6)
    project.refine()
    report(project, "scale-background")
    project.save(str(args.outdir / "physical_refined.gpx"))


if __name__ == "__main__":
    main()
