#!/usr/bin/env python3
"""Common-state tests for isotropic and allowed uniaxial microstrain."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def run(base: Path, destination: Path, pidx: int, axis: tuple[int, int, int] | None) -> None:
    project = G2.G2Project(gpxfile=str(base.resolve()))
    project.save(str(destination.resolve()))
    clear_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    phase = project.phases()[pidx]
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 500.0
    if axis is None:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    else:
        hap["Mustrain"][1][1] = 500.0
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": list(axis), "refine": True}}
        )
        bound(project, f"{pidx}:0:Mustrain;a", 0.0, 8000.0)
    bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)
    project.set_Controls("cycles", 8)
    project.refine()
    project.save()
    hap = phase.data["Histograms"][hist.name]
    print(destination.stem, hist.residuals, "Mustrain", hap["Mustrain"][:4], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    phase_count = len(G2.G2Project(gpxfile=str(args.base.resolve())).phases())
    for pidx in range(phase_count):
        run(args.base, args.outdir / f"strain_p{pidx}_iso.gpx", pidx, None)
        for axis in [(0, 0, 1), (1, 0, 0), (0, 1, 0)]:
            tag = "".join(str(v) for v in axis)
            run(args.base, args.outdir / f"strain_p{pidx}_{tag}.gpx", pidx, axis)


if __name__ == "__main__":
    main()
