#!/usr/bin/env python3
"""Continue the best CaWO4 + WO3 project with bounded, staged refinement."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False


def reset_limits(project: G2.G2Project) -> None:
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def set_physical_bounds(project: G2.G2Project) -> None:
    for var, low, high in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:Shift", -800.0, 800.0),
        ("0:0:Scale", 0.0, 100.0),
        ("1:0:Scale", 0.0, 100.0),
        ("0:0:Size;i", 0.04, 1.5),
        ("1:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0),
        ("1:0:Mustrain;i", 0.0, 8000.0),
    ]:
        bound(project, var, low, high)


def summary(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(f"\nSTAGE {label}: {hist.residuals}", flush=True)
    print(
        "  instrument "
        + " ".join(f"{k}={inst[k][1]:.8g}" for k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."])
        + f" Shift={sample['Shift'][0]:.8g}",
        flush=True,
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        atom_text = ", ".join(
            f"{a.label}:{a.element} xyz=({a.coordinates[0]:.7f},{a.coordinates[1]:.7f},{a.coordinates[2]:.7f}) U={a.uiso:.6f}"
            for a in phase.atoms()
        )
        print(
            f"  {phase.name} cell={phase.get_cell()} scale={hap['Scale'][0]:.9g} "
            f"size={hap['Size'][1][0]:.7g} strain={hap['Mustrain'][1][0]:.7g} "
            f"MD={hap['Pref.Ori.'][1]:.7g} axis={hap['Pref.Ori.'][3]}",
            flush=True,
        )
        print("   " + atom_text, flush=True)


def run_stage(project: G2.G2Project, outdir: Path, number: int, label: str, cycles: int = 6) -> Path:
    project.set_Controls("cycles", cycles)
    project.refine()
    summary(project, label)
    destination = outdir / f"stage_{number:02d}_{label}.gpx"
    project.save(str(destination))
    return destination


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    project = G2.G2Project(gpxfile=str(args.base.resolve()))
    project.save(str((args.outdir / "stage_00_loaded.gpx").resolve()))
    clear_flags(project)
    reset_limits(project)
    set_physical_bounds(project)
    hist = project.histogram(0)
    ca, wo = project.phases()

    # Replace the weakly identifiable values at the previous unconstrained
    # boundary with settings inside the known physical ranges. Keep the common
    # angular displacement approximately unchanged while fixing Zero to break
    # its near-perfect correlation with sample height.
    hist.data["Instrument Parameters"][0]["Zero"][1] = -0.20
    hist.data["Sample Parameters"]["Shift"][0] = 250.0
    wo.data["Histograms"][hist.name]["Size"][1][0] = 1.5
    for phase in (ca, wo):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = min(1.5, max(0.04, float(hap["Size"][1][0])))
        hap["Mustrain"][1][0] = min(8000.0, max(0.0, float(hap["Mustrain"][1][0])))
    project.save(str(args.outdir / "stage_01_physical_start.gpx"))

    # Fresh full-grid calculation of the manually adjusted physical state.
    project.set_Controls("cycles", 0)
    project.refine()
    summary(project, "physical-start-replay")
    project.save(str(args.outdir / "stage_02_physical_replay.gpx"))

    hist.set_refinements({"Background": True, "Sample Parameters": ["Shift"]})
    for phase in (ca, wo):
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
    run_stage(project, args.outdir, 3, "positions-scales-background", 7)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in (ca, wo):
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}},
                "Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}},
            }
        )
    run_stage(project, args.outdir, 4, "bounded-profiles", 8)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_stage(project, args.outdir, 5, "polarization", 6)

    # The generator assigns one isotropic displacement value to every atom in
    # a phase. Impose that exact model with one independent Uiso per phase.
    for pidx, phase in enumerate((ca, wo)):
        for atom in phase.atoms():
            atom.uiso = 0.010
            atom.refinement_flags = "U"
        variables = tuple(f"{pidx}::AUiso:{i}" for i in range(len(phase.atoms())))
        project.add_EquivConstr(variables, reloadIdx=True)
        bound(project, variables[0], 0.003, 0.020)
    run_stage(project, args.outdir, 6, "common-uiso", 6)

    ca.set_refinements({"Atoms": {"O1": "XU"}})
    run_stage(project, args.outdir, 7, "cawo4-oxygen", 6)

    wo.set_refinements({"Atoms": {"W1": "XU", "W2": "XU"}})
    run_stage(project, args.outdir, 8, "wo3-tungsten", 6)

    wo.set_refinements({"Atoms": {"all": "XU"}})
    run_stage(project, args.outdir, 9, "all-coordinates", 8)

    project.save(str(args.outdir / "best_candidate.gpx"))


if __name__ == "__main__":
    main()
