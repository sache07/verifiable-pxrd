#!/usr/bin/env python3
"""Create fit.csv and result.json from the final read-only replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
REPLAY = ROOT / "analysis/replays/submission_final/final"


def main() -> None:
    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as data:
        x = data["x"]
        observed = data["observed"]
        calculated = data["predicted"]
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    n_parameters = 31
    reduced = chi_square / (len(x) - n_parameters)

    result = {
        "analysis": "three-phase GSAS-II Rietveld refinement",
        "project_path": "final.gpx",
        "fit_profile_path": "fit.csv",
        "refinement_histogram": "PWDR pattern.xye",
        "fraction_normalization": "modeled crystalline phases only",
        "phases": [
            {
                "name": "calcium tungstate (scheelite)",
                "formula": "CaWO4",
                "space_group": "I 41/a",
                "cif_path": "CaWO4_scheelite.cif",
                "weight_fraction": 0.7981751782358876,
                "weight_fraction_standard_uncertainty": 0.002420425188499283,
            },
            {
                "name": "tungsten(VI) oxide (monoclinic)",
                "formula": "WO3",
                "space_group": "P 21/c",
                "cif_path": "WO3_monoclinic.cif",
                "weight_fraction": 0.13637768140631493,
                "weight_fraction_standard_uncertainty": 0.0005892935164943632,
            },
            {
                "name": "calcium carbonate (calcite)",
                "formula": "CaCO3",
                "space_group": "R -3 c",
                "cif_path": "CaCO3_calcite.cif",
                "weight_fraction": 0.06544714035779745,
                "weight_fraction_standard_uncertainty": 0.0027022609639033215,
            },
        ],
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "chi_square": chi_square,
            "reduced_chi_square": reduced,
            "goodness_of_fit": float(np.sqrt(reduced)),
            "r_expected_percent": 3.138245897500178,
            "data_points": int(len(x)),
            "refined_parameters": n_parameters,
            "weighting": "1/max(observed,1)",
            "evaluation_grid": "entire original observed grid",
        },
        "unresolved_components": [],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
