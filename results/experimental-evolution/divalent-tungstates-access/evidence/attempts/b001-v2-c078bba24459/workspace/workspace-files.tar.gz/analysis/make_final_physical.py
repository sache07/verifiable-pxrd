#!/usr/bin/env python3
"""Project refined atoms to synthesis bounds, then resume ordinary refinement."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

from make_physical_branch import SOURCE, lattice_matrix
from refine_three_phase import clear_flags, report, set_bounds


CALCITE_SOURCE = {"O1": np.array([0.2553, 0.0, 0.25])}


def project_group(
    phase: G2.G2Phase,
    labels: list[str],
    source: dict[str, np.ndarray],
    maximum_rms_A: float,
) -> None:
    matrix = lattice_matrix(phase.get_cell())
    deltas = []
    lengths = []
    for label in labels:
        delta = np.asarray(phase.atom(label).coordinates) - source[label]
        delta -= np.rint(delta)
        deltas.append(delta)
        lengths.append(float(np.linalg.norm(delta @ matrix)))
    rms = float(np.sqrt(np.mean(np.square(lengths))))
    factor = min(1.0, maximum_rms_A / max(rms, 1e-15))
    for label, delta in zip(labels, deltas):
        phase.atom(label).coordinates = tuple((source[label] + factor * delta).tolist())
    print(
        f"project {phase.name} {labels}: individual={lengths} "
        f"RMS={rms:.9g} A factor={factor:.9g}",
        flush=True,
    )


def snapshot(project: G2.G2Project, working: Path, destination: Path) -> None:
    project.save(str(working.resolve()))
    shutil.copy2(working, destination)


def run(
    project: G2.G2Project,
    working: Path,
    outdir: Path,
    number: int,
    label: str,
    cycles: int,
) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)
    snapshot(project, working, outdir / f"stage_{number:02d}_{label}.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    working = args.outdir / "working.gpx"
    shutil.copy2(args.base.resolve(), working)
    project = G2.G2Project(gpxfile=str(working.resolve()))
    clear_flags(project)
    set_bounds(project)
    ca, wo, calcite = project.phases()
    project_group(ca, ["O1"], SOURCE["CaWO4_scheelite"], 0.050)
    project_group(wo, ["W1", "W2"], SOURCE["WO3_2311041"], 0.040)
    project_group(calcite, ["O1"], CALCITE_SOURCE, 0.050)

    # Full-grid replay of the physical projection before any further fit.
    run(project, working, args.outdir, 0, "projected-replay", 0)

    hist = project.histogram(0)
    phases = project.phases()
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run(project, working, args.outdir, 1, "scales-background", 10)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run(project, working, args.outdir, 2, "cells", 10)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
    run(project, working, args.outdir, 3, "profiles", 12)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(project, working, args.outdir, 4, "polarization", 10)


if __name__ == "__main__":
    main()
