#!/usr/bin/env python3
"""Add and stage-refine a trace calcite phase in the fixed two-phase state."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


CALCITE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/54/73/1547347.cif"
)


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    weighted = []
    print(f"{label}: {hist.residuals}", flush=True)
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        weighted.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        print(
            f"  {index} {phase.name}: mass={phase.data['General']['Mass']:.8g} "
            f"scale={hap['Scale'][0]:.10g} cell={phase.get_cell()} "
            f"size={hap['Size'][1][0]:.8g} strain={hap['Mustrain'][1][0]:.8g}",
            flush=True,
        )
    total = sum(weighted)
    print("  fractions", [value / total for value in weighted], flush=True)


def run_stage(
    project: G2.G2Project, outdir: Path, number: int, label: str, cycles: int
) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)
    project.save(str((outdir / f"stage_{number:02d}_{label}.gpx").resolve()))


def set_isotropic_adps(phase: G2.G2Phase, value: float) -> None:
    """Use the synthesis model's one common isotropic ADP for this phase."""
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(value)
        atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    working = args.outdir / "working.gpx"
    shutil.copy2(args.base.resolve(), working)
    project = G2.G2Project(gpxfile=str(working.resolve()))
    clear_flags(project)
    hist = project.histogram(0)
    calcite = project.add_phase(
        str(CALCITE),
        phasename="CaCO3_calcite_1547347",
        histograms=[hist],
        fmthint="CIF",
    )
    set_isotropic_adps(calcite, 0.010)
    hap = calcite.data["Histograms"][hist.name]
    hap["Scale"] = [0.50, False]
    calcite.setSampleProfile(hist, "size", "isotropic", 0.20, LGmix=1.0)
    calcite.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    project.save(str((args.outdir / "stage_00_added.gpx").resolve()))
    project.index_ids()
    clear_flags(project)
    bound(project, "2:0:Scale", 0.0, 100.0)
    bound(project, "2:0:Size;i", 0.04, 1.5)
    bound(project, "2:0:Mustrain;i", 0.0, 8000.0)

    run_stage(project, args.outdir, 1, "fixed-replay", 0)

    calcite.set_HAP_refinements({"Scale": True})
    run_stage(project, args.outdir, 2, "scale-only-a", 6)
    run_stage(project, args.outdir, 3, "scale-only-b", 6)

    calcite.set_refinements({"Cell": True})
    run_stage(project, args.outdir, 4, "scale-cell", 7)

    calcite.set_HAP_refinements(
        {
            "Size": {
                "type": "isotropic",
                "refine": True,
                "LGmix": {"value": 1.0, "refine": False},
            }
        }
    )
    run_stage(project, args.outdir, 5, "scale-cell-size", 8)


if __name__ == "__main__":
    main()
