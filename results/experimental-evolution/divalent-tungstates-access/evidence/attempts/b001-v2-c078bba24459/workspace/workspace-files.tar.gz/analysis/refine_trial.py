#!/usr/bin/env python3
"""Build and refine a two-phase CaWO4 + WO3 GSAS-II trial project."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

import numpy as np
from scipy.ndimage import percentile_filter, gaussian_filter1d

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(pattern: Path, out: Path) -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(pattern, delimiter=",", skiprows=1)
    x, y = data.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(out / "pattern.xye", np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    (out / "instrument.instprm").write_text(
        "# GSAS-II Cu Kalpha laboratory instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:8.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return x, y


def initial_background(x: np.ndarray, y: np.ndarray, ncoef: int = 12) -> list[float]:
    # A broad lower envelope is only a stable starting point; GSAS refines it.
    base = percentile_filter(y, percentile=12, size=151, mode="nearest")
    base = gaussian_filter1d(base, 80)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, base, ncoef - 1).tolist()


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(f"STAGE {label} residuals={hist.residuals}", flush=True)
    print(
        "  instrument "
        + " ".join(f"{k}={inst[k][1]:.7g}" for k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]),
        flush=True,
    )
    print(f"  Shift={sample['Shift'][0]:.7g} Surf=({sample['SurfRoughA'][0]:.6g},{sample['SurfRoughB'][0]:.6g})", flush=True)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            f"  {phase.name} cell={phase.get_cell()} scale={hap['Scale'][0]:.8g} "
            f"size={hap['Size'][0:3]} mustrain={hap['Mustrain'][0:4]} PO={hap['Pref.Ori.'][0:4]}",
            flush=True,
        )


def refine(project: G2.G2Project, label: str, cycles: int = 5) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3_id")
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--atoms", action="store_true", help="refine atomic coordinates in the final stages")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.outdir.mkdir(parents=True, exist_ok=True)
    pattern = Path(__file__).resolve().parents[1] / "inputs" / "pattern.csv"
    x, y = write_inputs(pattern, args.outdir)

    ca_source = cod_path("7219229")
    wo_source = cod_path(args.wo3_id)
    shutil.copy2(ca_source, args.outdir / "source_CaWO4_7219229.cif")
    shutil.copy2(wo_source, args.outdir / f"source_WO3_{args.wo3_id}.cif")

    project = G2.G2Project(newgpx=str(args.outdir / "trial.gpx"))
    ca = project.add_phase(str(ca_source), phasename="CaWO4_scheelite", fmthint="CIF")
    wo = project.add_phase(str(wo_source), phasename=f"WO3_{args.wo3_id}", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(args.outdir / "pattern.xye"),
        str(args.outdir / "instrument.instprm"),
        phases=[ca, wo],
        fmthint="xye",
    )
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [550.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": initial_background(x, y, 12),
                "refine": True,
            }
        }
    )

    # Start with finite, moderately broad phase profiles. The two phases are
    # allowed independent size and strain as in the supplied laboratory model.
    for phase, scale, size, strain in [(ca, 1.0, 0.25, 1500.0), (wo, 0.35, 0.6, 600.0)]:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, False]
        phase.setSampleProfile(hist, "size", "isotropic", size, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", strain, LGmix=1.0)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    # Ensure the arrays/reflection lists exist before the first least-squares step.
    project.save()
    project.set_Controls("cycles", 0)
    project.refine()
    report(project, "initial")

    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "scale-background-shift-zero", 6)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "cells", 6)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}},
                "Mustrain": {"type": "isotropic", "refine": True, "LGmix": {"value": 1.0, "refine": False}},
            }
        )
    refine(project, "profiles", 8)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization", 6)

    if args.atoms:
        ca.set_refinements({"Atoms": {"all": "X"}})
        refine(project, "CaWO4-coordinates", 6)
        wo.set_refinements({"Atoms": {"all": "X"}})
        refine(project, "all-coordinates", 8)

    project.save(str(args.outdir / "trial.gpx"))
    for phase in project.phases():
        phase.export_CIF(str(args.outdir / f"{phase.name}.cif"))
    report(project, "final")


if __name__ == "__main__":
    main()
