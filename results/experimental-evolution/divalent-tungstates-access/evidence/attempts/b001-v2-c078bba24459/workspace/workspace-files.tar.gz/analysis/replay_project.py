#!/usr/bin/env python3
"""Run the scorer's read-only full-grid GSAS-II replay for one or more GPX files."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import subprocess


WORKER = Path("learned/divalent-tungstates/scorer/runtime/replay_worker.py")
PYTHON = Path("<HOME>/.local/share/characterizagent/backends/gsas2/venv/bin/python")


def rwp(npz: Path) -> tuple[float, float, float]:
    import numpy as np

    with np.load(npz, allow_pickle=False) as data:
        observed = data["observed"]
        calculated = data["predicted"]
    weights = 1.0 / np.maximum(observed, 1.0)
    loss = float(np.sum(weights * (observed - calculated) ** 2))
    denominator = float(np.sum(weights * observed**2))
    rp = float(100.0 * np.sum(np.abs(observed - calculated)) / np.sum(observed))
    return 100.0 * (loss / denominator) ** 0.5, loss, rp


def replay(project: Path, output: Path, observed: Path) -> None:
    output.mkdir(parents=True, exist_ok=True)
    request = {
        "project": str(project.resolve()),
        "observed": str(observed.resolve()),
    }
    request_path = output / "request.json"
    request_path.write_text(json.dumps(request, indent=2) + "\n")
    completed = subprocess.run(
        [str(PYTHON), str(WORKER.resolve()), str(request_path.resolve())],
        cwd=output,
        text=True,
        capture_output=True,
        check=False,
    )
    (output / "stdout.log").write_text(completed.stdout)
    (output / "stderr.log").write_text(completed.stderr)
    report = json.loads((output / "replay.json").read_text())
    if completed.returncode or report["status"] != "replayed":
        raise RuntimeError(f"Replay failed for {project}: {report}")
    value, loss, rp = rwp(output / "prediction.npz")
    fractions = [
        (phase["name"], phase["weight_fraction"]) for phase in report["phases"]
    ]
    print(
        f"{project}: Rwp={value:.9f}% Rp={rp:.9f}% chi2={loss:.6f} "
        f"fractions={fractions} flags={report['profile_review_flags']}",
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", nargs="+", type=Path)
    parser.add_argument("--outdir", required=True, type=Path)
    parser.add_argument("--observed", type=Path, default=Path("inputs/pattern.csv"))
    args = parser.parse_args()
    for project in args.projects:
        replay(project, args.outdir / project.stem, args.observed)


if __name__ == "__main__":
    main()
