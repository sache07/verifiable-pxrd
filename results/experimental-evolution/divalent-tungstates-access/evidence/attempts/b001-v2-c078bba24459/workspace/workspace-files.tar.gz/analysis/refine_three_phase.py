#!/usr/bin/env python3
"""Jointly refine the accepted CaWO4 + WO3 + calcite physical model."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def set_bounds(project: G2.G2Project) -> None:
    for variable, low, high in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
    ]:
        bound(project, variable, low, high)
    for index in range(len(project.phases())):
        bound(project, f"{index}:0:Scale", 0.0, 100.0)
        bound(project, f"{index}:0:Size;i", 0.04, 1.5)
        bound(project, f"{index}:0:Mustrain;i", 0.0, 8000.0)


def snapshot(project: G2.G2Project, working: Path, destination: Path) -> None:
    project.save(str(working.resolve()))
    shutil.copy2(working, destination)


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    weighted = []
    print(
        f"{label}: {hist.residuals} "
        + " ".join(
            f"{key}={inst[key][1]:.9g}"
            for key in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]
        ),
        flush=True,
    )
    for index, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        weighted.append(phase.data["General"]["Mass"] * hap["Scale"][0])
        print(
            f"  {index} {phase.name}: scale={hap['Scale'][0]:.10g} "
            f"cell={phase.get_cell()} size={hap['Size'][1][0]:.9g} "
            f"strain={hap['Mustrain'][1][0]:.9g}",
            flush=True,
        )
    total = sum(weighted)
    print("  fractions", [value / total for value in weighted], flush=True)


def run_stage(
    project: G2.G2Project,
    working: Path,
    outdir: Path,
    number: int,
    label: str,
    cycles: int,
) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)
    snapshot(project, working, outdir / f"stage_{number:02d}_{label}.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    working = args.outdir / "working.gpx"
    shutil.copy2(args.base.resolve(), working)
    project = G2.G2Project(gpxfile=str(working.resolve()))
    if len(project.phases()) != 3:
        raise ValueError("Expected the accepted three-phase project")
    clear_flags(project)
    set_bounds(project)
    hist = project.histogram(0)
    phases = project.phases()

    run_stage(project, working, args.outdir, 0, "fresh-start", 0)

    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run_stage(project, working, args.outdir, 1, "joint-scales-background", 8)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_stage(project, working, args.outdir, 2, "joint-cells", 8)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {
                    "type": "isotropic",
                    "refine": True,
                    "LGmix": {"value": 1.0, "refine": False},
                }
            }
        )
    run_stage(project, working, args.outdir, 3, "joint-profiles", 10)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_stage(project, working, args.outdir, 4, "joint-polarization", 8)


if __name__ == "__main__":
    main()
