#!/usr/bin/env python3
"""Test common ADPs and limited coordinate refinement in the three-phase model."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from refine_three_phase import clear_flags, report, set_bounds


def snapshot(project: G2.G2Project, working: Path, destination: Path) -> None:
    project.save(str(working.resolve()))
    shutil.copy2(working, destination)


def run(
    project: G2.G2Project,
    working: Path,
    outdir: Path,
    number: int,
    label: str,
    cycles: int = 8,
) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)
    for phase in project.phases():
        print(
            "  atoms",
            phase.name,
            [
                (atom.label, atom.coordinates, atom.uiso, atom.refinement_flags)
                for atom in phase.atoms()
            ],
            flush=True,
        )
    snapshot(project, working, outdir / f"stage_{number:02d}_{label}.gpx")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    working = args.outdir / "working.gpx"
    shutil.copy2(args.base.resolve(), working)
    project = G2.G2Project(gpxfile=str(working.resolve()))
    clear_flags(project)
    set_bounds(project)
    hist = project.histogram(0)
    phases = project.phases()
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})

    # Existing equivalence constraints impose a common Uiso for phases 0 and
    # 1. Add the same synthesis-model constraint for calcite.
    for atom in phases[0].atoms() + phases[1].atoms() + phases[2].atoms():
        atom.refinement_flags = "U"
    project.index_ids()
    variables = tuple(f"2::AUiso:{i}" for i in range(len(phases[2].atoms())))
    project.add_EquivConstr(variables, reloadIdx=True)
    for index in range(3):
        project.set_Controls("parmMin", 0.003, variable=f"{index}::AUiso:0")
        project.set_Controls("parmMax", 0.020, variable=f"{index}::AUiso:0")
    run(project, working, args.outdir, 1, "common-uiso")

    phases[2].set_refinements({"Atoms": {"O1": "XU"}})
    run(project, working, args.outdir, 2, "calcite-oxygen")

    phases[0].set_refinements({"Atoms": {"O1": "XU"}})
    run(project, working, args.outdir, 3, "cawo4-oxygen")

    phases[1].set_refinements({"Atoms": {"W1": "XU", "W2": "XU"}})
    run(project, working, args.outdir, 4, "wo3-tungsten")


if __name__ == "__main__":
    main()
