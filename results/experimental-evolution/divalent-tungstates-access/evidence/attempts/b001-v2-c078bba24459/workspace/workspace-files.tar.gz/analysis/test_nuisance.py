#!/usr/bin/env python3
"""Common-state trials for optional roughness and March-Dollase texture."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {}


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def common_linear_flags(project: G2.G2Project) -> None:
    project.histogram(0).set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def run(base: Path, destination: Path, setup) -> None:
    project = G2.G2Project(gpxfile=str(base.resolve()))
    project.save(str(destination.resolve()))
    clear_flags(project)
    common_linear_flags(project)
    setup(project)
    project.set_Controls("cycles", 7)
    project.refine()
    project.save()
    hist = project.histogram(0)
    print(destination.stem, hist.residuals, flush=True)
    print(" sample", hist.data["Sample Parameters"], flush=True)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(" ", phase.name, "scale", hap["Scale"][0], "PO", hap["Pref.Ori."][:4], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--phase", type=int, help="test texture only for this phase index")
    parser.add_argument("--skip-roughness", action="store_true")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    roughness_starts = [] if args.skip_roughness else [(0.15, 0.03), (0.30, 0.10), (0.50, 0.30)]
    for aval, bval in roughness_starts:
        def rough(project, a=aval, b=bval):
            sample = project.histogram(0).data["Sample Parameters"]
            sample["SurfRoughA"] = [a, False]
            sample["SurfRoughB"] = [b, False]
            project.histogram(0).set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
            bound(project, ":0:SurfRoughA", 0.05, 0.60)
            bound(project, ":0:SurfRoughB", 0.02, 0.50)
        run(args.base, args.outdir / f"rough_A{aval:.2f}_B{bval:.2f}.gpx", rough)

    axes = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]
    if args.phase is None:
        phase_indices = range(len(G2.G2Project(gpxfile=str(args.base.resolve())).phases()))
    else:
        phase_indices = [args.phase]
    for pidx in phase_indices:
        for axis in axes:
            def texture(project, p=pidx, hkl=axis):
                phase = project.phases()[p]
                hap = phase.data["Histograms"][project.histogram(0).name]
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 0.90
                hap["Pref.Ori."][3] = list(hkl)
                phase.set_HAP_refinements({"Pref.Ori.": True})
                bound(project, f"{p}:0:MD", 0.70, 1.40)
            tag = "".join(str(v) for v in axis)
            run(args.base, args.outdir / f"texture_p{pidx}_{tag}.gpx", texture)


if __name__ == "__main__":
    main()
