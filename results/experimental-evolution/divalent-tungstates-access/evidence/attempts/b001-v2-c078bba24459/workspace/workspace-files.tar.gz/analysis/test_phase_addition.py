#!/usr/bin/env python3
"""Test one candidate phase by repeated scale refinement in a common state."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) == 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}


def set_isotropic_adps(phase: G2.G2Phase, value: float) -> None:
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(value)
        atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6


def snapshot(project: G2.G2Project, working: Path, destination: Path) -> None:
    project.save(str(working.resolve()))
    shutil.copy2(working, destination)


def report(project: G2.G2Project, label: str, index: int) -> None:
    hist = project.histogram(0)
    phase = project.phases()[index]
    hap = phase.data["Histograms"][hist.name]
    covariance = project.data.get("Covariance", {}).get("data", {})
    variable = f"{index}:0:Scale"
    sigma = None
    if variable in covariance.get("varyList", []):
        sigma = covariance.get("sig", [])[covariance["varyList"].index(variable)]
    weighted = [
        item.data["General"]["Mass"]
        * item.data["Histograms"][hist.name]["Scale"][0]
        for item in project.phases()
    ]
    print(
        f"{label}: wR={hist.residuals.get('wR')} candidate={phase.name} "
        f"scale={hap['Scale'][0]:.12g} sigma={sigma} "
        f"fraction={weighted[index] / sum(weighted):.12g}",
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("cod_id")
    parser.add_argument("name")
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--initial-scale", type=float, default=0.30)
    parser.add_argument("--size", type=float, default=0.20)
    parser.add_argument(
        "--unbounded",
        action="store_true",
        help="allow a diagnostic negative scale; a stable negative optimum implies a zero NNLS scale",
    )
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    # GSAS-II may save while rebuilding phase/atom indices. Work only on a
    # private copy so the common-state source project remains byte-for-byte
    # unchanged for every candidate trial.
    working = args.outdir / "working.gpx"
    shutil.copy2(args.base.resolve(), working)
    project = G2.G2Project(gpxfile=str(working.resolve()))
    clear_flags(project)
    hist = project.histogram(0)
    index = len(project.phases())
    phase = project.add_phase(
        str(cod_path(args.cod_id)),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    set_isotropic_adps(phase, 0.010)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [args.initial_scale, False]
    phase.setSampleProfile(hist, "size", "isotropic", args.size, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 0.0, LGmix=1.0)
    hap["Pref.Ori."][0:3] = ["MD", 1.0, False]
    hap["Extinction"] = [0.0, False]
    snapshot(project, working, args.outdir / "stage_00_added.gpx")
    project.index_ids()
    clear_flags(project)
    if not args.unbounded:
        project.set_Controls("parmMin", 0.0, variable=f"{index}:0:Scale")
        project.set_Controls("parmMax", 100.0, variable=f"{index}:0:Scale")

    project.set_Controls("cycles", 0)
    project.refine()
    report(project, "fixed replay", index)
    snapshot(project, working, args.outdir / "stage_01_fixed.gpx")

    phase.set_HAP_refinements({"Scale": True})
    for number, label in [(2, "scale-a"), (3, "scale-b")]:
        project.set_Controls("cycles", 6)
        project.refine()
        report(project, label, index)
        snapshot(project, working, args.outdir / f"stage_{number:02d}_{label}.gpx")


if __name__ == "__main__":
    main()
