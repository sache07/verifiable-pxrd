#!/usr/bin/env python3
"""List coherent positive residual peaks and map them to phase reflections."""

from __future__ import annotations

import argparse

import numpy as np
from GSASII import GSASIIscriptable as G2
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("--prominence", type=float, default=250.0)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=args.project)
    hist = project.histograms()[0]
    x, yo, wt, yc, yb, yd = [np.asarray(a, float) for a in hist.data["data"][1][:6]]
    step = np.median(np.diff(x))
    residual = gaussian_filter1d(yo - yc, 1.5)
    idx, props = find_peaks(residual, prominence=args.prominence, distance=max(2, round(0.08 / step)))
    widths = peak_widths(residual, idx, rel_height=0.5)[0] * step
    order = np.argsort(props["prominences"])[::-1]

    refs = []
    for phase, data in hist.data["Reflection Lists"].items():
        for row in data["RefList"]:
            refs.append((float(row[5]), phase, tuple(int(v) for v in row[:3]), float(row[8]), float(row[9])))
    refs.sort()

    print(f"project={args.project} histogram={hist.name} residual_peaks={len(idx)}")
    print("rank two_theta residual prominence fwhm nearest_delta phase hkl Icorr Icalc")
    for rank, j in enumerate(order, 1):
        i = idx[j]
        nearest = min(refs, key=lambda r: abs(r[0] - x[i]))
        pos, phase, hkl, icorr, icalc = nearest
        print(
            f"{rank:3d} {x[i]:10.5f} {residual[i]:11.2f} {props['prominences'][j]:11.2f} "
            f"{widths[j]:8.4f} {x[i]-pos:+10.5f} {phase:16s} {str(hkl):>14s} {icorr:10.2f} {icalc:10.2f}"
        )


if __name__ == "__main__":
    main()
