#!/usr/bin/env python3
"""Build a staged, geometry-preserving three-phase GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


def parse_phase(value: str) -> tuple[str, Path]:
    name, path = value.split("=", 1)
    return name, Path(path)


def stats(project, hist) -> dict:
    x, yo, wt, yc = [np.asarray(a, float) for a in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    residual = yo - yc
    rwp = 100 * np.sqrt(np.sum(wt[use] * residual[use] ** 2) / np.sum(wt[use] * yo[use] ** 2))
    rp = 100 * np.sum(np.abs(residual[use])) / np.sum(np.abs(yo[use]))
    return {"Rwp": float(rwp), "Rp": float(rp)}


def save(project, hist, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    print(label, json.dumps(stats(project, hist), sort_keys=True), flush=True)


def refine(project, hist, outdir: Path, label: str) -> None:
    project.set_Controls("cycles", 12)
    project.refine()
    save(project, hist, outdir, label)


parser = argparse.ArgumentParser()
parser.add_argument("--phase", action="append", type=parse_phase, required=True)
parser.add_argument("--outdir", required=True, type=Path)
parser.add_argument("--freeze-coordinates", action="append", default=[])
args = parser.parse_args()

G2.SetPrintLevel("warn")
outdir = args.outdir.resolve()
outdir.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
phases = [
    project.add_phase(str(path.resolve()), phasename=name, fmthint="CIF")
    for name, path in args.phase
]
hist = project.add_powder_histogram(
    str(Path("inputs/pattern.csv").resolve()),
    str(Path("analysis/instrument_zero0.instprm").resolve()),
    phases=phases,
    fmthint="comma",
)
hist.SampleParameters["Type"] = "Bragg-Brentano"
hist.SampleParameters["Gonio. radius"] = 200.0
hist.SampleParameters["Scale"] = [1.0, False]
hist.set_refinements(
    {
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1800.0] + [0.0] * 11,
            "refine": True,
        },
    }
)
for phase in phases:
    phase.HAPvalue("Scale", 1.0 / len(phases))
    phase.set_HAP_refinements({"Scale": True})
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.5, "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 1500.0
    hap["Mustrain"][1][1] = 1500.0

save(project, hist, outdir, "00_initial")
refine(project, hist, outdir, "01_background_scales")

for phase in phases:
    phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
refine(project, hist, outdir, "02_cells_zero")

for phase in phases:
    if phase.name in args.freeze_coordinates:
        continue
    for atom in phase.atoms():
        if atom.element.upper() != "O":
            atom.refinement_flags = "X"
refine(project, hist, outdir, "03_heavy_coordinates")

for phase in phases:
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
refine(project, hist, outdir, "04_phase_size")

for phase in phases:
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
refine(project, hist, outdir, "05_phase_size_strain")

project.save(str(outdir / "physical_checkpoint.gpx"))
print("INSTRUMENT", json.dumps(hist.data["Instrument Parameters"][0], default=str, sort_keys=True))
for phase in phases:
    hap = phase.data["Histograms"][hist.name]
    print(
        "PHASE",
        phase.name,
        json.dumps(
            {
                "cell": phase.data["General"]["Cell"],
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            },
            default=str,
            sort_keys=True,
        ),
    )
