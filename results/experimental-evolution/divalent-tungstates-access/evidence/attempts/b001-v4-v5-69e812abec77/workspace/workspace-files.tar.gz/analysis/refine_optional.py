#!/usr/bin/env python3
"""Run one controlled optional refinement from a preserved physical project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path)
parser.add_argument("outdir", type=Path)
parser.add_argument("--instrument", nargs="*", default=[])
parser.add_argument("--sample", nargs="*", default=[])
parser.add_argument("--instrument-set", nargs=2, action="append", default=[])
parser.add_argument("--sample-set", nargs=2, action="append", default=[])
parser.add_argument("--fix-zero", type=float)
parser.add_argument("--oxygen", action="append", default=[])
parser.add_argument("--texture-phase")
parser.add_argument("--texture-axis", nargs=3, type=int)
parser.add_argument("--uniaxial-phase")
parser.add_argument("--uniaxial-axis", nargs=3, type=int)
parser.add_argument("--passes", type=int, default=1)
args = parser.parse_args()

G2.SetPrintLevel("warn")
args.outdir.mkdir(parents=True, exist_ok=True)
working = args.outdir / "working.gpx"
shutil.copy2(args.base, working)
project = G2.G2Project(gpxfile=str(working))
hist = project.histograms()[0]

# Optional tests start with accepted phase profiles fixed. Keep the calibrated
# zero parameter and any previously accepted cell/scale/background/coordinate flags.
instrument = hist.data["Instrument Parameters"][0]
for value in instrument.values():
    if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
        value[2] = False
instrument["Zero"][2] = args.fix_zero is None
if args.fix_zero is not None:
    instrument["Zero"][1] = args.fix_zero
for name, value in args.instrument_set:
    instrument[name][1] = float(value)
for name in args.instrument:
    instrument[name][2] = True

sample = hist.data["Sample Parameters"]
for value in sample.values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
for name in args.sample:
    sample[name][1] = True
for name, value in args.sample_set:
    sample[name][0] = float(value)

for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    if len(hap["Size"]) > 5:
        hap["Size"][5] = [False] * len(hap["Size"][5])
    if len(hap["Mustrain"]) > 5:
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False

for phase_name in args.oxygen:
    for atom in project.phase(phase_name).atoms():
        if atom.element.upper() == "O":
            atom.refinement_flags = atom.refinement_flags.replace("X", "") + "X"

if args.texture_phase:
    hap = project.phase(args.texture_phase).data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(args.texture_axis)

if args.uniaxial_phase:
    hap = project.phase(args.uniaxial_phase).data["Histograms"][hist.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][3] = list(args.uniaxial_axis)

project.set_Controls("cycles", 12)
for _ in range(args.passes):
    project.refine()
project.save(str(args.outdir / "result.gpx"))

x, yo, wt, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
lo, hi = hist.data["Limits"][1]
use = (x >= lo) & (x <= hi)
diff = yo - yc
amounts = [
    float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0])
    for p in project.phases()
]
print(
    json.dumps(
        {
            "Rwp": float(100 * np.sqrt(np.sum(wt[use] * diff[use] ** 2) / np.sum(wt[use] * yo[use] ** 2))),
            "Rp": float(100 * np.sum(np.abs(diff[use])) / np.sum(np.abs(yo[use]))),
            "instrument": instrument,
            "sample": sample,
            "weight_fractions": {
                p.name: amount / sum(amounts) for p, amount in zip(project.phases(), amounts)
            },
            "textures": {
                p.name: p.data["Histograms"][hist.name]["Pref.Ori."][:4]
                for p in project.phases()
            },
            "profiles": {
                p.name: {
                    "size": p.data["Histograms"][hist.name]["Size"],
                    "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
                }
                for p in project.phases()
            },
        },
        default=str,
        sort_keys=True,
    )
)
