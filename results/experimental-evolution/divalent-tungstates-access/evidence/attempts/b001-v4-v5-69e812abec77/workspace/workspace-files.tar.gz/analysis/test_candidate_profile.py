#!/usr/bin/env python3
"""Test physical fixed-strain starts while re-optimizing one phase size."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("base", type=Path)
parser.add_argument("outdir", type=Path)
parser.add_argument("--phase", default="Mn3WO6")
parser.add_argument("--strain", type=float, required=True)
parser.add_argument("--size", type=float, default=None)
args = parser.parse_args()

G2.SetPrintLevel("warn")
args.outdir.mkdir(parents=True, exist_ok=True)
working = args.outdir / "working.gpx"
shutil.copy2(args.base, working)
project = G2.G2Project(gpxfile=str(working))
hist = project.histograms()[0]
target = project.phase(args.phase)
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2][0] = False
    hap["Mustrain"][2][0] = False
hap = target.data["Histograms"][hist.name]
hap["Mustrain"][1][0] = args.strain
if args.size is not None:
    hap["Size"][1][0] = args.size
hap["Size"][2][0] = True
project.set_Controls("cycles", 12)
project.refine()
project.save(str(args.outdir / "result.gpx"))

x, yo, wt, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
lo, hi = hist.data["Limits"][1]
use = (x >= lo) & (x <= hi)
diff = yo - yc
amounts = [
    float(p.data["General"]["Mass"]) * float(p.data["Histograms"][hist.name]["Scale"][0])
    for p in project.phases()
]
print(
    json.dumps(
        {
            "Rwp": float(100 * np.sqrt(np.sum(wt[use] * diff[use] ** 2) / np.sum(wt[use] * yo[use] ** 2))),
            "Rp": float(100 * np.sum(np.abs(diff[use])) / np.sum(np.abs(yo[use]))),
            "target_size": hap["Size"][1][0],
            "target_strain": hap["Mustrain"][1][0],
            "weight_fractions": {
                p.name: amount / sum(amounts) for p, amount in zip(project.phases(), amounts)
            },
        },
        sort_keys=True,
    )
)
