#!/usr/bin/env python3
"""Build a geometry-preserving three-phase checkpoint with staged line profiles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


def parse_phase(value: str) -> tuple[str, str]:
    name, path = value.split("=", 1)
    return name, path


def stats(project, hist) -> dict:
    x, yo, wt, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    diff = yo - yc
    return {
        "Rwp": float(100 * np.sqrt(np.sum(wt[use] * diff[use] ** 2) / np.sum(wt[use] * yo[use] ** 2))),
        "Rp": float(100 * np.sum(np.abs(diff[use])) / np.sum(np.abs(yo[use]))),
    }


def save(project, hist, outdir, label):
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    details = stats(project, hist)
    details["phases"] = {
        p.name: {
            "scale": p.data["Histograms"][hist.name]["Scale"][0],
            "size": p.data["Histograms"][hist.name]["Size"][1][0],
            "mustrain": p.data["Histograms"][hist.name]["Mustrain"][1][0],
            "cell": p.data["General"]["Cell"][1:],
        }
        for p in project.phases()
    }
    details["zero"] = hist.data["Instrument Parameters"][0]["Zero"][1]
    print(label, json.dumps(details, default=str, sort_keys=True), flush=True)


def refine(project, hist, outdir, label):
    project.set_Controls("cycles", 10)
    project.refine()
    save(project, hist, outdir, label)


parser = argparse.ArgumentParser()
parser.add_argument("--phase", action="append", type=parse_phase, required=True)
parser.add_argument("--outdir", type=Path, required=True)
parser.add_argument("--framework-phase", default="Mn3WO6")
args = parser.parse_args()

G2.SetPrintLevel("warn")
outdir = args.outdir.resolve()
outdir.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
phases = [
    project.add_phase(str(Path(path).resolve()), phasename=name, fmthint="CIF")
    for name, path in args.phase
]
hist = project.add_powder_histogram(
    str(Path("inputs/pattern.csv").resolve()),
    str(Path("analysis/instrument.instprm").resolve()),
    phases=phases,
    fmthint="comma",
)
hist.SampleParameters["Type"] = "Bragg-Brentano"
hist.SampleParameters["Gonio. radius"] = 200.0
hist.set_refinements(
    {
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1800.0] + [0.0] * 11,
            "refine": True,
        },
    }
)
for phase in phases:
    phase.HAPvalue("Scale", 1.0 / len(phases))
    phase.set_HAP_refinements({"Scale": True})
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.08, "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
        }
    )
    phase.data["Histograms"][hist.name]["Mustrain"][1][0] = 3000.0

save(project, hist, outdir, "00_initial")
refine(project, hist, outdir, "01_background_scales")

for phase in phases:
    if phase.name != args.framework_phase:
        phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
refine(project, hist, outdir, "02_main_cells_zero")

for phase in phases:
    if phase.name == args.framework_phase:
        phase.set_refinements({"Cell": True})
refine(project, hist, outdir, "03_all_cells_zero")

for phase in phases:
    if phase.name == args.framework_phase:
        continue
    for atom in phase.atoms():
        if atom.element.upper() != "O":
            atom.refinement_flags = "X"
refine(project, hist, outdir, "04_main_heavy_coordinates")

for index, phase in enumerate(phases, 1):
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    refine(project, hist, outdir, f"{4 + index:02d}_size_{phase.name.lower()}")
    hap["Size"][2][0] = False

for index, phase in enumerate(phases, 1):
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][2][0] = True
    refine(project, hist, outdir, f"{7 + index:02d}_strain_{phase.name.lower()}")
    hap["Mustrain"][2][0] = False

project.save(str(outdir / "physical_checkpoint.gpx"))
