#!/usr/bin/env python3
"""Rapid full-profile screening of chemically relevant frozen COD entries."""

from __future__ import annotations

import gzip
import json
import argparse
from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.signal import correlate, correlation_lags


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06")
INDEX = ROOT / "index.json.gz"
CIF_ROOT = ROOT / "cif"
KEYS = ("Mn-O-W", "Mn-O", "O-W")


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def observed_signal(signal_csv: str | None = None) -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(signal_csv or "inputs/pattern.csv", delimiter=",", skiprows=1)
    if signal_csv:
        x, y = data[:, 0], data[:, -1]
        return x, np.maximum(gaussian_filter1d(y, 1.2), 0.0)
    x, y = data.T
    baseline = gaussian_filter1d(minimum_filter1d(y, size=301, mode="nearest"), 60)
    signal = np.maximum(gaussian_filter1d(y - baseline, 1.2), 0.0)
    # Downweight the broad, intense high-angle envelope and retain full range.
    signal /= np.sqrt(np.maximum(1.0, gaussian_filter1d(y, 50)))
    return x, signal


def add_stick(profile: np.ndarray, x: np.ndarray, position: float, intensity: float) -> None:
    q = (position - x[0]) / (x[1] - x[0])
    i = int(np.floor(q))
    if 0 <= i < len(profile) - 1:
        f = q - i
        profile[i] += intensity * (1.0 - f)
        profile[i + 1] += intensity * f


def profile_for_pattern(x: np.ndarray, pattern, d_scale: float, fwhm: float) -> np.ndarray:
    sticks = np.zeros_like(x)
    lam1, lam2 = 1.540598, 1.544426
    for pos0, inten in zip(pattern.x, pattern.y):
        theta0 = np.deg2rad(pos0 / 2.0)
        d = lam1 / (2.0 * np.sin(theta0)) * d_scale
        for lam, ratio in ((lam1, 1.0), (lam2, 0.5)):
            arg = lam / (2.0 * d)
            if arg < 1.0:
                add_stick(sticks, x, np.rad2deg(2.0 * np.arcsin(arg)), inten * ratio)
    sigma_points = fwhm / (2.35482 * (x[1] - x[0]))
    return gaussian_filter1d(sticks, sigma_points, mode="constant")


def best_score(
    x: np.ndarray,
    observed: np.ndarray,
    pattern,
    scales=None,
    fwhms=(0.18, 0.28, 0.42, 0.65),
    max_shift=0.75,
) -> tuple[float, float, float, float]:
    mask = (x >= 11.0) & (x <= 85.0)
    obs = observed[mask]
    obs_norm = float(np.linalg.norm(obs))
    best = (-np.inf, 1.0, 0.0, 0.0)
    max_lag = round(max_shift / (x[1] - x[0]))
    if scales is None:
        scales = np.linspace(0.992, 1.008, 9)
    for scale in scales:
        for fwhm in fwhms:
            calc = profile_for_pattern(x, pattern, scale, fwhm)[mask]
            calc_norm = float(np.linalg.norm(calc))
            if calc_norm == 0:
                continue
            corr = correlate(obs, calc, mode="full", method="fft")
            lags = correlation_lags(len(obs), len(calc), mode="full")
            keep = np.abs(lags) <= max_lag
            k = np.argmax(corr[keep])
            selected_lags = lags[keep]
            score = float(corr[keep][k] / (obs_norm * calc_norm))
            shift = float(selected_lags[k] * (x[1] - x[0]))
            if score > best[0]:
                best = (score, float(scale), shift, float(fwhm))
    return best


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--signal-csv")
    args = parser.parse_args()
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    x, observed = observed_signal(args.signal_csv)
    calculator = XRDCalculator(wavelength=1.540598, symprec=0.01)
    rows = []
    for key in KEYS:
        for formula, cod_id, sg, residual in index.get(key, []):
            path = cif_path(cod_id)
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = Structure.from_file(path, primitive=False)
                    pattern = calculator.get_pattern(structure, two_theta_range=(9.0, 102.0))
                score, scale, shift, fwhm = best_score(x, observed, pattern)
                rows.append((score, key, formula, cod_id, sg, residual, scale, shift, fwhm, len(pattern.x)))
            except Exception as exc:
                print(f"ERROR {key} {formula} {cod_id}: {exc}")
    rows.sort(reverse=True)
    print("score key formula COD sg residual d_scale shift_deg fwhm_deg reflections")
    for row in rows:
        score, key, formula, cod_id, sg, residual, scale, shift, fwhm, npeaks = row
        print(
            f"{score:7.4f} {key:7s} {formula:16s} {cod_id} {sg:3d} {str(residual):>7s} "
            f"{scale:8.5f} {shift:9.5f} {fwhm:8.3f} {npeaks:4d}"
        )


if __name__ == "__main__":
    main()
