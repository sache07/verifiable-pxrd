#!/usr/bin/env python3
"""Apply an isotropic lattice scale to an analogue-derived CIF."""

import argparse

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("scale", type=float)
args = parser.parse_args()

structure = Structure.from_file(args.input, primitive=False)
structure.scale_lattice(structure.volume * args.scale**3)
CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(args.output)
