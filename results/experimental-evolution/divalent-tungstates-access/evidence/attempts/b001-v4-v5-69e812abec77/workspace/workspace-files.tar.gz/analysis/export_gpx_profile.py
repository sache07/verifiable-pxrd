#!/usr/bin/env python3
"""Export observed, calculated, background, difference, and positive residual."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("output")
args = parser.parse_args()

G2.SetPrintLevel("error")
project = G2.G2Project(gpxfile=args.project)
hist = project.histograms()[0]
x, yo, wt, yc, yb, yd = [np.asarray(a, float) for a in hist.data["data"][1][:6]]
arr = np.column_stack((x, yo, yc, yo - yc, yb, np.maximum(yo - yc, 0.0)))
np.savetxt(
    Path(args.output),
    arr,
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference,background,positive_residual",
    comments="",
)
