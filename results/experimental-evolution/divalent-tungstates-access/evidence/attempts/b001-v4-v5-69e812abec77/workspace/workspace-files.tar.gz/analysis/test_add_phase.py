#!/usr/bin/env python3
"""Add one candidate to a saved project and perform a stable scales-only test."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_flags(project, hist) -> None:
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"].get(hist.name)
        if not hap:
            continue
        hap["Scale"][1] = False
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False


def stats(project, hist) -> dict:
    x, yo, wt, yc = [np.asarray(a, float) for a in hist.data["data"][1][:4]]
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    rwp = 100 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / np.sum(wt[use] * yo[use] ** 2))
    masses = [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    total = sum(masses)
    return {
        "Rwp": float(rwp),
        "phases": [
            {
                "name": p.name,
                "scale": float(p.data["Histograms"][hist.name]["Scale"][0]),
                "weight_fraction": float(m / total),
            }
            for p, m in zip(project.phases(), masses)
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("candidate")
    parser.add_argument("output")
    parser.add_argument("--name", default="candidate")
    parser.add_argument("--initial-scale", type=float, default=1.0)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    shutil.copy2(args.base, args.output)
    project = G2.G2Project(gpxfile=args.output)
    hist = project.histograms()[0]
    clear_flags(project, hist)
    print("BEFORE", json.dumps(stats(project, hist), sort_keys=True))
    phase = project.add_phase(args.candidate, phasename=args.name, histograms=[hist], fmthint="CIF")
    phase.HAPvalue("Scale", args.initial_scale)
    clear_flags(project, hist)
    for p in project.phases():
        p.set_HAP_refinements({"Scale": True}, histograms=[hist])
    project.set_Controls("cycles", 8)
    project.refine()
    project.save(args.output)
    print("AFTER", json.dumps(stats(project, hist), sort_keys=True))


if __name__ == "__main__":
    main()
