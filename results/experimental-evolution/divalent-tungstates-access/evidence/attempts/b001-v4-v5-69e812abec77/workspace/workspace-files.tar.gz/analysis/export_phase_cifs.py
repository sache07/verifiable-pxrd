#!/usr/bin/env python3
"""Export every phase in a GSAS-II project as a CIF."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


parser = argparse.ArgumentParser()
parser.add_argument("project", type=Path)
parser.add_argument("output_dir", type=Path)
args = parser.parse_args()

G2.SetPrintLevel("error")
args.output_dir.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(gpxfile=str(args.project.resolve()))
for number, phase in enumerate(project.phases(), 1):
    output = args.output_dir / f"{number:02d}_{slug(phase.name)}.cif"
    phase.export_CIF(str(output.resolve()))
    print(output)
