#!/usr/bin/env python3
"""Screen analogue-derived structures against the unresolved profile."""

from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d

from screen_references import best_score


PROFILE = Path("analysis/branches/wo3_mono/final_profile.csv")
data = np.loadtxt(PROFILE, delimiter=",", skiprows=1)
x = data[:, 0]
signals = {
    "positive_residual": np.maximum(gaussian_filter1d(data[:, -1], 1.2), 0.0),
    "observed_minus_background": np.maximum(gaussian_filter1d(data[:, 1] - data[:, 4], 1.2), 0.0),
}
calculator = XRDCalculator(wavelength=1.540598, symprec=0.01)

for label, signal in signals.items():
    rows = []
    for path in sorted(Path("analysis/candidates").glob("*.cif")):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(path, primitive=False)
            pattern = calculator.get_pattern(structure, two_theta_range=(8.0, 105.0))
        score, scale, shift, fwhm = best_score(
            x,
            signal,
            pattern,
            scales=np.linspace(0.78, 1.22, 45),
            fwhms=(0.20, 0.35, 0.55, 0.80),
            max_shift=0.75,
        )
        rows.append((score, path.stem, scale, shift, fwhm, len(pattern.x)))
    rows.sort(reverse=True)
    print(f"\n{label}")
    print("score candidate d_scale shift_deg fwhm_deg reflections")
    for score, name, scale, shift, fwhm, npeaks in rows:
        print(f"{score:7.4f} {name:34s} {scale:8.4f} {shift:9.5f} {fwhm:8.3f} {npeaks:5d}")
