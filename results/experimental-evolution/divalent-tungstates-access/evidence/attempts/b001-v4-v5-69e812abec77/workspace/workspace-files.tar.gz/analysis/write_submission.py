#!/usr/bin/env python3
"""Export the final phase CIFs, profile, and structured refinement summary."""

from __future__ import annotations

import argparse
import json
import math
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def slug(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")


def finite(value):
    return float(value) if value is not None and math.isfinite(float(value)) else None


parser = argparse.ArgumentParser()
parser.add_argument("project", type=Path)
parser.add_argument("--output-dir", type=Path, default=Path("."))
args = parser.parse_args()

G2.SetPrintLevel("error")
output = args.output_dir.resolve()
project = G2.G2Project(gpxfile=str(args.project.resolve()))
hist = project.histograms()[0]
x, observed, weights, calculated, background, _ = [
    np.asarray(v, float) for v in hist.data["data"][1][:6]
]
lo, hi = hist.data["Limits"][1]
use = (x >= lo) & (x <= hi)
difference = observed - calculated
rwp = 100.0 * np.sqrt(
    np.sum(weights[use] * difference[use] ** 2)
    / np.sum(weights[use] * observed[use] ** 2)
)
rp = 100.0 * np.sum(np.abs(difference[use])) / np.sum(np.abs(observed[use]))
covariance = project.data.get("Covariance", {}).get("data", {})
rvals = covariance.get("Rvals", {})

profile = np.column_stack((x, observed, calculated, difference, background))
np.savetxt(
    output / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta,observed,calculated,difference,background",
    comments="",
    fmt="%.10g",
)

try:
    mass_fraction_sus = hist.ComputeMassFracs()
except Exception:
    mass_fraction_sus = {}

amounts = []
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    amounts.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
total = sum(amounts)

phase_rows = []
for phase, amount in zip(project.phases(), amounts):
    cif_name = f"phase_{slug(phase.name)}.cif"
    phase.export_CIF(str(output / cif_name))
    fraction_su = mass_fraction_sus.get(phase.name, (None, None))[1]
    general = phase.data["General"]
    phase_rows.append(
        {
            "name": phase.name,
            "cif_path": cif_name,
            "weight_fraction": amount / total,
            "weight_fraction_su": finite(fraction_su),
            "space_group": general["SGData"].get("SpGrp", ""),
            "cell_angstrom_degrees": [float(v) for v in general["Cell"][1:7]],
        }
    )

instrument = hist.data["Instrument Parameters"][0]
sample = hist.data["Sample Parameters"]
result = {
    "refinement_histogram": hist.name,
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": float(rwp),
        "Rp_percent": float(rp),
        "GOF": finite(rvals.get("GOF")),
        "chi_squared": finite(rvals.get("chisq")),
        "n_points": int(np.sum(use)),
        "n_variables": int(rvals.get("Nvars", len(covariance.get("varyList", [])))),
    },
    "calibration": {
        "zero_deg": float(instrument["Zero"][1]),
        "sample_displacement_um": float(sample["Shift"][0]),
        "instrument_U": float(instrument["U"][1]),
        "instrument_W": float(instrument["W"][1]),
        "instrument_X": float(instrument["X"][1]),
        "SH_over_L": float(instrument["SH/L"][1]),
        "polarization": float(instrument["Polariz."][1]),
    },
    "fraction_basis": "Normalized over the modeled crystalline phases; amorphous material is not quantified.",
}
(output / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps(result, indent=2, allow_nan=False))
