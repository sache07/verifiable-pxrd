#!/usr/bin/env python3
"""Build traceable analogue-derived Mn-W-O candidate structures."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif")
OUT = Path("analysis/candidates")

CANDIDATES = {
    # Mn3WO6: balance-closing 3:1 cation ratio, one parent per topology.
    "mn3wo6_mn3teo6_sg148": ("2211528", {"Te": "W"}),
    "mn3wo6_co3teo6_sg15": ("2015468", {"Co": "Mn", "Te": "W"}),
    "mn3wo6_ni3teo6_sg146": ("2211031", {"Ni": "Mn", "Te": "W"}),
    "mn3wo6_cu3wo6_sg205": ("1527404", {"Cu": "Mn"}),
    "mn3wo6_ca3wo6_sg14": ("1563081", {"Ca": "Mn"}),
    # Mn2WO6: 2:1 alternative, transition-metal parents in distinct topologies.
    "mn2wo6_fe2wo6_sg60": ("2310464", {"Fe": "Mn"}),
    "mn2wo6_cr2wo6_sg136": ("1530909", {"Cr": "Mn"}),
    "mn2wo6_cu2teo6_sg14": ("9004359", {"Cu": "Mn", "Te": "W"}),
    # Mn3W2O9: 3:2 alternative, same stoichiometry transition-metal parents.
    "mn3w2o9_cu3mo2o9_sg62": ("2006589", {"Cu": "Mn", "Mo": "W"}),
    "mn3w2o9_zn3mo2o9_sg11": ("1534971", {"Zn": "Mn", "Mo": "W"}),
    "mn3w2o9_ba3w2o9_sg167": ("1533878", {"Ba": "Mn"}),
}


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


OUT.mkdir(parents=True, exist_ok=True)
records = []
for name, (cod_id, substitutions) in CANDIDATES.items():
    source = cod_path(cod_id)
    structure = Structure.from_file(source, primitive=False)
    structure.replace_species(substitutions)
    target = OUT / f"{name}.cif"
    CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(target)
    records.append(
        {
            "name": name,
            "cif": str(target),
            "parent_cod_id": cod_id,
            "parent_cif": str(source),
            "substitutions": substitutions,
            "target_formula": structure.composition.reduced_formula,
            "space_group": structure.get_space_group_info(),
            "volume_A3": structure.volume,
            "sites": len(structure),
        }
    )

(OUT / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")
for record in records:
    print(json.dumps(record, sort_keys=True))
