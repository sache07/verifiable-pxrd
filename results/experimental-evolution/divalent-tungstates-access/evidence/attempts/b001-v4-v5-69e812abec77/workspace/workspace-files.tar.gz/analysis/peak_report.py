#!/usr/bin/env python3
"""Report robust peak positions and approximate integrated intensities."""

from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.signal import find_peaks, peak_widths


data = np.loadtxt(Path("inputs/pattern.csv"), delimiter=",", skiprows=1)
x, y = data.T
step = float(np.median(np.diff(x)))

# A broad rolling minimum follows the slowly varying background without
# removing narrow Bragg peaks. Smooth only enough to suppress count noise.
baseline = gaussian_filter1d(minimum_filter1d(y, size=301, mode="nearest"), 60)
signal = gaussian_filter1d(y - baseline, 1.2)
noise = np.sqrt(np.maximum(gaussian_filter1d(y, 20), 1.0))
prominence = max(8.0 * float(np.median(noise)), 0.002 * float(signal.max()))
idx, props = find_peaks(signal, prominence=prominence, distance=max(2, round(0.06 / step)))
width_pts = peak_widths(signal, idx, rel_height=0.5)[0]

order = np.argsort(props["prominences"])[::-1]
print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={step:.7f}")
print(
    f"counts min/median/max={y.min():.3f}/{np.median(y):.3f}/{y.max():.3f}; "
    f"detected_peaks={len(idx)} prominence_cutoff={prominence:.2f}"
)
print("rank two_theta intensity baseline net prominence fwhm_deg")
for rank, j in enumerate(order, 1):
    i = idx[j]
    print(
        f"{rank:3d} {x[i]:10.5f} {y[i]:11.3f} {baseline[i]:10.3f} "
        f"{signal[i]:11.3f} {props['prominences'][j]:11.3f} {width_pts[j] * step:9.5f}"
    )
