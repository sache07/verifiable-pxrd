#!/usr/bin/env python3
"""Compact local-geometry screen for Mn-W-O CIF models."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from pymatgen.core import Structure


parser = argparse.ArgumentParser()
parser.add_argument("paths", nargs="+")
args = parser.parse_args()

for pattern in args.paths:
    matches = sorted(Path().glob(pattern)) if any(c in pattern for c in "*?[") else [Path(pattern)]
    for path in matches:
        structure = Structure.from_file(path, primitive=False)
        summary = {}
        for center in ("Mn", "W"):
            records = []
            for i, site in enumerate(structure):
                if site.specie.symbol != center:
                    continue
                distances = sorted(
                    structure.get_distance(i, j)
                    for j, other in enumerate(structure)
                    if other.specie.symbol == "O"
                )
                records.append(distances[:8])
            arr = np.asarray(records, float)
            if len(arr):
                summary[center] = {
                    "sites": len(arr),
                    "nearest_range": (float(arr[:, 0].min()), float(arr[:, 0].max())),
                    "sixth_range": (float(arr[:, 5].min()), float(arr[:, 5].max())),
                    "mean_first6": float(arr[:, :6].mean()),
                    "coord_lt_2p6": (int((arr < 2.6).sum(axis=1).min()), int((arr < 2.6).sum(axis=1).max())),
                }
        oxygen = [i for i, s in enumerate(structure) if s.specie.symbol == "O"]
        oo = min(structure.get_distance(i, j) for n, i in enumerate(oxygen) for j in oxygen[n + 1 :])
        print(path, structure.composition.reduced_formula, structure.get_space_group_info(), f"V={structure.volume:.4f}", f"O-Omin={oo:.4f}", summary)
