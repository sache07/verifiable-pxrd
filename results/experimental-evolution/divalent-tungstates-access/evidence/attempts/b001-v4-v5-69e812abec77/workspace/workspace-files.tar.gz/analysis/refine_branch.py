#!/usr/bin/env python3
"""Create and stage a GSAS-II Rietveld branch for one or more CIF models."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


def parse_phase(value: str) -> tuple[str, str]:
    try:
        name, path = value.split("=", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("phase must be NAME=CIF") from exc
    return name, path


def rvals(project: G2.G2Project) -> dict:
    return dict(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}))


def useful_stats(project: G2.G2Project, hist) -> dict:
    rv = rvals(project)
    x, yo, wt, yc, yb, yd = [np.asarray(a, dtype=float) for a in hist.data["data"][1][:6]]
    limits = hist.data["Limits"][1]
    use = (x >= limits[0]) & (x <= limits[1])
    denom = np.sum(wt[use] * yo[use] ** 2)
    rwp = 100.0 * np.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) / denom)
    rp = 100.0 * np.sum(np.abs(yo[use] - yc[use])) / np.sum(np.abs(yo[use]))
    return {
        "Rwp_calc": float(rwp),
        "Rp_calc": float(rp),
        "GOF": float(rv.get("GOF", np.nan)),
        "Nobs": int(np.sum(use)),
        "Nvars": int(rv.get("Nvars", -1)),
        "Rvals": rv,
    }


def checkpoint(project: G2.G2Project, hist, outdir: Path, label: str) -> dict:
    project.save()
    target = outdir / f"{label}.gpx"
    shutil.copy2(project.filename, target)
    stats = useful_stats(project, hist)
    print(label, json.dumps(stats, default=str, sort_keys=True))
    return stats


def run_refinement(project: G2.G2Project, hist, outdir: Path, label: str) -> dict:
    project.set_Controls("cycles", 8)
    project.refine()
    return checkpoint(project, hist, outdir, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", action="append", type=parse_phase, required=True)
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--oxygen", action="store_true")
    parser.add_argument("--uiso", action="store_true")
    parser.add_argument("--fixed-cell", action="append", default=[])
    parser.add_argument("--fixed-coordinates", action="append", default=[])
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    phases = [
        project.add_phase(str(Path(path).resolve()), phasename=name, fmthint="CIF")
        for name, path in args.phase
    ]
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("analysis/instrument.instprm").resolve()),
        phases=phases,
        fmthint="comma",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1800.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    for i, phase in enumerate(phases):
        phase.HAPvalue("Scale", 1.0 / len(phases))
        phase.set_HAP_refinements({"Scale": True})
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.5, "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            }
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 1500.0
        hap["Mustrain"][1][1] = 1500.0

    checkpoint(project, hist, outdir, "00_initial")
    run_refinement(project, hist, outdir, "01_background_scales")

    for phase in phases:
        if phase.name not in args.fixed_cell:
            phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, hist, outdir, "02_cells_zero")

    if args.coordinates:
        for phase in phases:
            if phase.name in args.fixed_coordinates:
                continue
            for atom in phase.atoms():
                if atom.element.upper() != "O":
                    atom.refinement_flags = "X"
        run_refinement(project, hist, outdir, "03_heavy_coordinates")

    if args.oxygen:
        for phase in phases:
            if phase.name in args.fixed_coordinates:
                continue
            for atom in phase.atoms():
                if atom.element.upper() == "O":
                    atom.refinement_flags = "X"
        run_refinement(project, hist, outdir, "04_oxygen_coordinates")

    # Resolve phase-dependent width before the common profile. Generator physics
    # uses V=0; crystallite size remains fixed to avoid the X/size degeneracy.
    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run_refinement(project, hist, outdir, "05_phase_microstrain")

    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    run_refinement(project, hist, outdir, "06_instrument_UW")
    hist.set_refinements({"Instrument Parameters": ["X"]})
    run_refinement(project, hist, outdir, "07_instrument_X")

    hist.set_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})
    run_refinement(project, hist, outdir, "08_axial_polarization")

    if args.uiso:
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
        run_refinement(project, hist, outdir, "09_uiso")

    project.save(str(outdir / "final.gpx"))
    print("HISTOGRAM", hist.name)
    print("INSTRUMENT", json.dumps(hist.data["Instrument Parameters"][0], default=str, sort_keys=True))
    print("SAMPLE", json.dumps(hist.data["Sample Parameters"], default=str, sort_keys=True))
    for phase in phases:
        print("PHASE", phase.name, json.dumps({
            "cell": phase.data["General"]["Cell"],
            "mass": phase.data["General"]["Mass"],
            "scale": phase.data["Histograms"][hist.name]["Scale"],
            "size": phase.data["Histograms"][hist.name]["Size"],
            "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
        }, default=str, sort_keys=True))


if __name__ == "__main__":
    main()
