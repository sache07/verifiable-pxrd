#!/usr/bin/env python3
"""Print compact, machine-readable diagnostics from one or more GSAS-II projects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


def inspect(path: Path) -> dict:
    project = G2.G2Project(gpxfile=str(path))
    hist = project.histograms()[0]
    x, yo, wt, yc, yb, yd = [
        np.asarray(a, dtype=float) for a in hist.data["data"][1][:6]
    ]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    residual = yo - yc
    denom = np.sum(wt[use] * yo[use] ** 2)
    rwp = 100.0 * np.sqrt(np.sum(wt[use] * residual[use] ** 2) / denom)
    rp = 100.0 * np.sum(np.abs(residual[use])) / np.sum(np.abs(yo[use]))
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "path": str(path),
        "histogram": hist.name,
        "limits": [float(lo), float(hi)],
        "Rwp": float(rwp),
        "Rp": float(rp),
        "GOF": float(covariance.get("Rvals", {}).get("GOF", np.nan)),
        "Nvars": int(covariance.get("Rvals", {}).get("Nvars", -1)),
        "instrument": plain(hist.data["Instrument Parameters"][0]),
        "sample": plain(hist.data["Sample Parameters"]),
        "background": plain(hist.data["Background"]),
        "phases": [],
    }
    amounts = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        amount = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        amounts.append(amount)
        atoms = []
        for atom in phase.atoms():
            atoms.append(
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": [float(v) for v in atom.coordinates],
                    "flags": atom.refinement_flags,
                }
            )
        result["phases"].append(
            {
                "name": phase.name,
                "space_group": phase.data["General"]["SGData"].get("SpGrp"),
                "cell": plain(phase.data["General"]["Cell"]),
                "mass": float(phase.data["General"]["Mass"]),
                "scale": plain(hap["Scale"]),
                "size": plain(hap["Size"]),
                "mustrain": plain(hap["Mustrain"]),
                "pref_orient": plain(hap["Pref.Ori."]),
                "atoms": atoms,
            }
        )
    total = sum(amounts)
    for phase, amount in zip(result["phases"], amounts):
        phase["weight_fraction"] = amount / total
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", nargs="+", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("none")
    for path in args.gpx:
        print(json.dumps(inspect(path.resolve()), sort_keys=True))


if __name__ == "__main__":
    main()
