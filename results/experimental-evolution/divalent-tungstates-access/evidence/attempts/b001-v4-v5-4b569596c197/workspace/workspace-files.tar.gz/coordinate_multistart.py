#!/usr/bin/env python
"""Independent bounded starts for the accepted CaWO4 oxygen coordinate."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/final_tests/base_full_grid.gpx"
OUT = ROOT / ".tmp/coordinate_multistart"
REFERENCE = (0.15202, 0.01135, 0.20864)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    records = []
    starts = {
        "start_low_y": (0.15702, 0.00635, 0.21164),
        "start_high_y": (0.14702, 0.01635, 0.20564),
    }
    for name, start in starts.items():
        gpx = G2sc.G2Project(
            gpxfile=str(SOURCE), newgpx=str(OUT / f"{name}.gpx")
        )
        gpx.data["Controls"]["data"].setdefault("parmFrozen", {})[
            "FrozenList"
        ] = []
        for p in gpx.phases():
            for a in p.atoms():
                a.refinement_flags = a.refinement_flags.replace("X", "")
        atom = list(gpx.phase(0).atoms())[2]
        atom.coordinates = start
        atom.refinement_flags += "X"
        for axis, center in zip("xyz", REFERENCE):
            var = f"0::dA{axis}:2"
            gpx.set_Controls("parmMin", center - 0.015, variable=var)
            gpx.set_Controls("parmMax", center + 0.015, variable=var)
        gpx.set_Controls("cycles", 8)
        gpx.refine()
        gpx.refine()
        gpx.save()
        cov = gpx.data["Covariance"]["data"]
        rec = {
            "name": name,
            "start": start,
            "final": list(atom.coordinates),
            "Rwp": gpx.histogram(0).get_wR(),
            "GOF": cov.get("Rvals", {}).get("GOF"),
            "message": cov.get("Rvals", {}).get("msg"),
            "mass_fractions": gpx.histogram(0).ComputeMassFracs(),
        }
        records.append(rec)
        print(json.dumps(rec, indent=2))
    with (OUT / "summary.json").open("w") as fp:
        json.dump(records, fp, indent=2)


if __name__ == "__main__":
    main()
