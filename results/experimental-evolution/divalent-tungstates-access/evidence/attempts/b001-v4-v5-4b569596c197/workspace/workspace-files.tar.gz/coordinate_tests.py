#!/usr/bin/env python
"""Bounded coordinate-release checks from the converged physical profile."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/final_tests/base_full_grid.gpx"
OUT = ROOT / ".tmp/coordinate_tests"


def clear_frozen(gpx) -> None:
    gpx.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def bound(gpx, name: str, center: float, amount: float) -> None:
    # Despite the historical ``dA`` name, GSAS-II applies these limits to the
    # absolute fractional coordinate value, not to a coordinate increment.
    gpx.set_Controls("parmMin", center - amount, variable=name)
    gpx.set_Controls("parmMax", center + amount, variable=name)


def selected_atoms(gpx, phase_index: int, kind: str):
    atoms = list(gpx.phase(phase_index).atoms())
    if kind == "heavy":
        return [(i, a) for i, a in enumerate(atoms) if a.element != "O"]
    if kind == "oxygen":
        return [(i, a) for i, a in enumerate(atoms) if a.element == "O"]
    raise ValueError(kind)


def run(name: str, selections: list[tuple[int, str, float]]) -> dict:
    target = OUT / f"{name}.gpx"
    gpx = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(target))
    clear_frozen(gpx)

    # Preserve common-Uiso refinement while changing only the selected atomic
    # positions. Coordinate limits act on symmetry-adapted coordinate shifts.
    for p in gpx.phases():
        for a in p.atoms():
            a.refinement_flags = a.refinement_flags.replace("X", "")
    chosen = []
    for phase_index, kind, limit in selections:
        for atom_index, atom in selected_atoms(gpx, phase_index, kind):
            atom.refinement_flags = atom.refinement_flags.replace("X", "") + "X"
            chosen.append((phase_index, atom_index, atom.label, atom.element, limit))
            for axis, center in zip("xyz", atom.coordinates):
                bound(
                    gpx,
                    f"{phase_index}::dA{axis}:{atom_index}",
                    float(center),
                    limit,
                )

    before = {
        p.name: [list(a.coordinates) for a in p.atoms()] for p in gpx.phases()
    }
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    gpx.save()
    for p in gpx.phases():
        p.export_CIF(str(OUT / f"{name}_{p.name}.cif"))

    cov = gpx.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    rec = {
        "name": name,
        "file": str(target.relative_to(ROOT)),
        "chosen": chosen,
        "Rwp": gpx.histogram(0).get_wR(),
        "GOF": rvals.get("GOF"),
        "message": rvals.get("msg"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "frozen": [
            str(x)
            for x in gpx.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "before": before,
        "after": {
            p.name: [list(a.coordinates) for a in p.atoms()] for p in gpx.phases()
        },
        "mass_fractions": gpx.histogram(0).ComputeMassFracs(),
        "vary": {
            str(v): s
            for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
            if "dA" in str(v)
        },
    }
    print(json.dumps(rec, indent=2))
    return rec


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    records = []
    branches = (
        ("heavy_all", [(0, "heavy", 0.006), (1, "heavy", 0.006)]),
        ("heavy_all_wide", [(0, "heavy", 0.012), (1, "heavy", 0.012)]),
        ("cawo4_oxygen", [(0, "oxygen", 0.008)]),
        ("cawo4_oxygen_wide", [(0, "oxygen", 0.015)]),
        ("wo3_oxygen", [(1, "oxygen", 0.008)]),
    )
    for name, selections in branches:
        try:
            records.append(run(name, selections))
        except Exception as exc:
            records.append({"name": name, "error": repr(exc)})
            print(name, repr(exc))
    with (OUT / "summary.json").open("w") as fp:
        json.dump(records, fp, indent=2)


if __name__ == "__main__":
    main()
