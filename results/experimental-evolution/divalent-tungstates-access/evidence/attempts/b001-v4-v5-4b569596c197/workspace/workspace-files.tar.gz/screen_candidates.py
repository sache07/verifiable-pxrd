#!/usr/bin/env python
"""Rietveld screening of plausible secondary phase topologies.

Run with the GSAS-II Python interpreter. The script builds independent
two-phase projects so that candidate WO3 / Ca-W-O models can be compared on
the same observed grid and refinement schedule.
"""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_xye() -> Path:
    out = ROOT / ".tmp" / "pattern.xye"
    out.parent.mkdir(exist_ok=True)
    if out.exists():
        return out
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as src, out.open("w") as dst:
        reader = csv.DictReader(src)
        for row in reader:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return out


def summarize(gpx: G2sc.G2Project, stage: str, out: list[dict]) -> None:
    hist = gpx.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rec = {
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "shift_um": sample.get("Shift", [None])[0],
        "instrument": {k: inst[k][1] for k in ["U", "V", "W", "X", "Y", "SH/L"] if k in inst},
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        rec["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][1],
            "mustrain": hap["Mustrain"][1],
        }
    try:
        rec["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        rec["mass_fraction_error"] = repr(exc)
    out.append(rec)
    print(json.dumps(rec, indent=2, default=float))


def refine(gpx: G2sc.G2Project, stage: str, log: list[dict]) -> None:
    gpx.set_Controls("cycles", 8)
    gpx.refine()
    summarize(gpx, stage, log)


def run(candidate: str, quick: bool = False) -> None:
    tag = candidate
    outdir = ROOT / ".tmp" / "screens"
    outdir.mkdir(parents=True, exist_ok=True)
    gpx_path = outdir / f"screen_{tag}.gpx"
    if gpx_path.exists():
        gpx_path.unlink()

    gpx = G2sc.G2Project(newgpx=str(gpx_path))
    hist = gpx.add_powder_histogram(
        str(prepare_xye()), str(ROOT / "instrument.instprm"), fmthint="xye"
    )
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Shift"] = [500.0, False]
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements({"Limits": [10.0, 100.0]})

    main = gpx.add_phase(
        str(cif_path("7219229")), phasename="CaWO4_scheelite", histograms=[hist], fmthint="CIF"
    )
    sec = gpx.add_phase(
        str(cif_path(candidate)), phasename=f"candidate_{candidate}", histograms=[hist], fmthint="CIF"
    )

    # Initial profile values separate the visibly broad product from the
    # sharper residual phase while leaving both positive and physical.
    main.setSampleProfile(hist, "size", "isotropic", 0.20, LGmix=1.0)
    main.setSampleProfile(hist, "microstrain", "isotropic", 1200.0, LGmix=0.5)
    sec.setSampleProfile(hist, "size", "isotropic", 1.0, LGmix=1.0)
    sec.setSampleProfile(hist, "microstrain", "isotropic", 300.0, LGmix=0.5)
    main.HAPvalue("Scale", 0.1)
    sec.HAPvalue("Scale", 0.03)

    # Establish a smooth empirical baseline from peak-clipped raw counts,
    # then fit it with GSAS-II's replayable Chebyshev background.
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 30}})
    raw_x = np.asarray(hist.getdata("X"), float)
    raw_y = np.asarray(hist.getdata("Yobs"), float)
    # A local lower quantile rejects Bragg peaks without assuming a particular
    # generator background family. Add back the expected lower-quantile bias
    # for Poisson counts and smooth before sampling fixed points.
    baseline = percentile_filter(raw_y, percentile=12, size=101, mode="nearest")
    baseline = gaussian_filter1d(baseline + 1.15 * np.sqrt(np.maximum(baseline, 1.0)), 22)
    hist.data["Background"][1]["FixedPoints"] = [
        (float(x), float(y)) for x, y in zip(raw_x[::40], baseline[::40])
    ]
    hist.fit_fixed_points()
    hist.set_refinements({"Background": {"refine": True}})
    main.set_HAP_refinements({"Scale": True}, [hist])
    sec.set_HAP_refinements({"Scale": True}, [hist])

    log: list[dict] = []
    refine(gpx, "scale_background", log)

    # Refine cells against the common specimen displacement.
    main.set_refinements({"Cell": True})
    sec.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(gpx, "cells_shift", log)

    if quick:
        gpx.save()
        with (outdir / f"screen_{tag}.json").open("w") as fp:
            json.dump(log, fp, indent=2, default=float)
        return

    # Common instrumental width, followed by phase-specific broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(gpx, "instrument_profile", log)
    main.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    sec.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    refine(gpx, "isotropic_size", log)
    main.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    sec.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    refine(gpx, "isotropic_size_strain", log)

    gpx.save()
    with (outdir / f"screen_{tag}.json").open("w") as fp:
        json.dump(log, fp, indent=2, default=float)


if __name__ == "__main__":
    if len(sys.argv) not in (2, 3):
        raise SystemExit("usage: screen_candidates.py COD_ID [quick]")
    run(sys.argv[1], quick=len(sys.argv) == 3 and sys.argv[2].lower() == "quick")
