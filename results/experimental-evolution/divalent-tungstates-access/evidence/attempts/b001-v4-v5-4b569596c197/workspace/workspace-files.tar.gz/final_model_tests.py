#!/usr/bin/env python
"""Build and compare physically constrained final-model branches."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = (
    ROOT
    / ".tmp/physical_branches/2311041/checkpoints/08_instrument_UW.gpx"
)
OUT = ROOT / ".tmp/final_tests"


def plain(v):
    if isinstance(v, (np.integer, np.floating)):
        return v.item()
    if isinstance(v, np.ndarray):
        return v.tolist()
    if isinstance(v, dict):
        return {str(k): plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [plain(x) for x in v]
    return v


def set_bound(gpx, variable: str, low: float, high: float) -> None:
    gpx.set_Controls("parmMin", low, variable=variable)
    gpx.set_Controls("parmMax", high, variable=variable)


def clear_frozen(gpx) -> None:
    controls = gpx.data["Controls"]["data"]
    controls.setdefault("parmFrozen", {})["FrozenList"] = []


def summary(gpx, label: str) -> dict:
    h = gpx.histogram(0)
    cov = gpx.data.get("Covariance", {}).get("data", {})
    rv = cov.get("Rvals", {})
    sigmas = {
        str(var): float(sig)
        for var, sig in zip(cov.get("varyList", []), cov.get("sig", []))
    }
    rec = {
        "label": label,
        "file": str(Path(gpx.filename).relative_to(ROOT)),
        "limits": plain(h.data["Limits"]),
        "residuals": plain(h.residuals),
        "Rvals": {
            k: plain(rv.get(k))
            for k in (
                "Rwp",
                "GOF",
                "Nobs",
                "Nvars",
                "Max shft/sig",
                "SVD0",
                "converged",
                "DelChi2",
                "msg",
            )
        },
        "mass_fractions": plain(h.ComputeMassFracs()),
        "sample": {
            k: plain(h.SampleParameters[k])
            for k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "instrument": {
            k: plain(h.InstrumentParameters[k])
            for k in ("Polariz.", "U", "V", "W", "X", "Y", "SH/L")
        },
        "phases": {},
        "sigmas": sigmas,
        "frozen": [
            str(x)
            for x in gpx.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
    }
    for p in gpx.phases():
        hap = p.data["Histograms"][h.name]
        rec["phases"][p.name] = {
            "cell": plain(p.get_cell()),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
        }
    return rec


def run(gpx, label: str, repeats: int = 3) -> dict:
    gpx.set_Controls("cycles", 8)
    prior = float(gpx.histogram(0).get_wR() or math.inf)
    for _ in range(repeats):
        gpx.refine()
        current = float(gpx.histogram(0).get_wR())
        if not math.isfinite(current) or current > prior + 0.08:
            raise RuntimeError(f"{label} diverged: {prior:.5f} -> {current:.5f}")
        prior = current
    gpx.save()
    rec = summary(gpx, label)
    print(
        json.dumps(
            {
                "label": label,
                "Rwp": rec["residuals"].get("wR"),
                "GOF": rec["Rvals"].get("GOF"),
                "fractions": rec["mass_fractions"],
                "sample": rec["sample"],
                "phases": {
                    k: {
                        "size": v["size"],
                        "po": v["preferred_orientation"],
                    }
                    for k, v in rec["phases"].items()
                },
                "message": rec["Rvals"].get("msg"),
            },
            indent=2,
        )
    )
    return rec


def clone(source: Path, name: str) -> G2sc.G2Project:
    target = OUT / f"{name}.gpx"
    return G2sc.G2Project(gpxfile=str(source), newgpx=str(target))


def prepare_base() -> tuple[G2sc.G2Project, dict]:
    gpx = clone(SOURCE, "base_full_grid")
    h = gpx.histogram(0)
    clear_frozen(gpx)

    # Use all supplied measurements. Keep the weakly identified polarization
    # and Lorentzian X width at their calibrated Cu-instrument values.
    h.set_refinements({"Limits": list(h.data["Limits"][0])})
    h.InstrumentParameters["X"][1:] = [0.5, False]
    h.InstrumentParameters["Polariz."][1:] = [0.7, False]
    h.InstrumentParameters["SH/L"][2] = True

    # The isotropic microstrains refined to zero. Remove them rather than
    # retaining boundary-frozen variables in the final covariance matrix.
    for phase in gpx.phases():
        hap = phase.data["Histograms"][h.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

    set_bound(gpx, ":0:SH/L", 0.002, 0.2)
    rec = run(gpx, "base_full_grid", repeats=4)
    return gpx, rec


def test_surface(base: Path, name: str, a: float, b: float) -> dict:
    gpx = clone(base, name)
    h = gpx.histogram(0)
    clear_frozen(gpx)
    h.SampleParameters["SurfRoughA"] = [a, True]
    h.SampleParameters["SurfRoughB"] = [b, True]
    set_bound(gpx, ":0:SurfRoughA", 0.001, 0.999)
    set_bound(gpx, ":0:SurfRoughB", 0.0001, 2.0)
    return run(gpx, name, repeats=3)


def test_po(base: Path, phase_index: int, axis: tuple[int, int, int]) -> dict:
    tag = "".join(str(x).replace("-", "m") for x in axis)
    name = f"po_p{phase_index}_{tag}"
    gpx = clone(base, name)
    h = gpx.histogram(0)
    clear_frozen(gpx)
    p = gpx.phase(phase_index)
    po = p.data["Histograms"][h.name]["Pref.Ori."]
    po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
    set_bound(gpx, f"{phase_index}:0:MD", 0.5, 2.0)
    return run(gpx, name, repeats=3)


def test_uniaxial_size(
    base: Path, phase_index: int, axis: tuple[int, int, int]
) -> dict:
    tag = "".join(str(x).replace("-", "m") for x in axis)
    name = f"usize_p{phase_index}_{tag}"
    gpx = clone(base, name)
    h = gpx.histogram(0)
    clear_frozen(gpx)
    p = gpx.phase(phase_index)
    hap = p.data["Histograms"][h.name]
    size = float(hap["Size"][1][0])
    p.setSampleProfile(h, "size", "uniaxial", size, size, axis, LGmix=1.0)
    p.set_HAP_refinements(
        {"Size": {"type": "uniaxial", "refine": True, "direction": axis}},
        [h],
    )
    set_bound(gpx, f"{phase_index}:0:Size;i", 0.01, 10.0)
    set_bound(gpx, f"{phase_index}:0:Size;a", 0.01, 10.0)
    return run(gpx, name, repeats=3)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    base, base_rec = prepare_base()
    base_path = Path(base.filename)
    records = [base_rec]

    for name, a, b in (
        ("surface_start_lowA", 0.2, 0.05),
        ("surface_start_highA", 0.8, 0.05),
    ):
        try:
            records.append(test_surface(base_path, name, a, b))
        except Exception as exc:
            records.append({"label": name, "error": repr(exc)})

    for phase_index, axes in (
        (0, ((0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 1, 1))),
        (1, ((0, 1, 0), (1, 0, 0), (0, 0, 1), (1, 1, 0))),
    ):
        for axis in axes:
            try:
                records.append(test_po(base_path, phase_index, axis))
            except Exception as exc:
                records.append(
                    {
                        "label": f"po_p{phase_index}_{axis}",
                        "error": repr(exc),
                    }
                )

    for phase_index, axis in ((0, (0, 0, 1)), (1, (0, 1, 0))):
        try:
            records.append(test_uniaxial_size(base_path, phase_index, axis))
        except Exception as exc:
            records.append(
                {
                    "label": f"usize_p{phase_index}_{axis}",
                    "error": repr(exc),
                }
            )

    with (OUT / "branch_summary.json").open("w") as fp:
        json.dump(plain(records), fp, indent=2)


if __name__ == "__main__":
    main()
