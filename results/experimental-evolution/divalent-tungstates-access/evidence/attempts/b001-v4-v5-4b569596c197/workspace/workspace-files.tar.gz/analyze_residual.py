#!/usr/bin/env python
"""Plot and summarize residuals from a selected GSAS-II branch."""

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths


src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(".tmp/physical_branches/2311041/fit.csv")
df = pd.read_csv(src)
x = df["two_theta_deg"].to_numpy(float)


def column(*names):
    for name in names:
        if name in df:
            return df[name].to_numpy(float)
    raise KeyError(names)


yo = column("observed", "observed_counts")
yc = column("calculated", "calculated_counts")
bg = column("background", "background_counts")
dy = yo - yc
z = dy / np.sqrt(np.maximum(yo, 1.0))

smooth = gaussian_filter1d(dy, 2.0)
peaks, props = find_peaks(smooth, prominence=20, height=12, distance=5)
widths = peak_widths(smooth, peaks, rel_height=0.5)[0] * np.median(np.diff(x))
order = np.argsort(props["prominences"])[::-1]
print("rank two_theta residual prominence width_deg standardized")
for rank, j in enumerate(order[:80], 1):
    i = peaks[j]
    print(
        f"{rank:3d} {x[i]:10.5f} {dy[i]:9.2f} {props['prominences'][j]:9.2f} "
        f"{widths[j]:8.4f} {z[i]:8.3f}"
    )
print(
    "z mean/std/rms/q01/q99",
    np.mean(z),
    np.std(z),
    np.sqrt(np.mean(z**2)),
    np.quantile(z, 0.01),
    np.quantile(z, 0.99),
)

fig, axes = plt.subplots(6, 1, figsize=(16, 13), sharex=False)
for pair, (lo, hi) in enumerate(((9.9, 40), (38, 70), (68, 100.1))):
    ax = axes[2 * pair]
    rz = axes[2 * pair + 1]
    sel = (x >= lo) & (x <= hi)
    ax.plot(x[sel], yo[sel], color="black", lw=0.55, label="observed")
    ax.plot(x[sel], yc[sel], color="tab:red", lw=0.7, label="calculated")
    ax.plot(x[sel], bg[sel], color="tab:blue", lw=0.5, label="background")
    rz.plot(x[sel], dy[sel], color="tab:green", lw=0.55)
    rz.axhline(0, color="black", lw=0.4)
    rz.fill_between(x[sel], -2 * np.sqrt(np.maximum(yo[sel], 1)), 2 * np.sqrt(np.maximum(yo[sel], 1)), color="0.85")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
    rz.set_ylabel("obs-calc")
    rz.set_xlabel(r"$2\theta$ (deg)")
axes[0].legend(loc="upper right", frameon=False, ncol=3)
fig.tight_layout()
out = src.with_name("residual_plot.png")
fig.savefig(out, dpi=180)
print(out)
