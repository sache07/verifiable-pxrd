#!/usr/bin/env python
"""Check supported specimen terms after accepting the CaWO4 oxygen site."""

from __future__ import annotations

import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/coordinate_tests/cawo4_oxygen_wide.gpx"
OUT = ROOT / ".tmp/post_coordinate_tests"


def clear_frozen(gpx):
    gpx.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def bound(gpx, variable, low, high):
    gpx.set_Controls("parmMin", low, variable=variable)
    gpx.set_Controls("parmMax", high, variable=variable)


def collect(gpx, name):
    h = gpx.histogram(0)
    cov = gpx.data["Covariance"]["data"]
    rv = cov.get("Rvals", {})
    return {
        "name": name,
        "file": str(Path(gpx.filename).relative_to(ROOT)),
        "Rwp": h.get_wR(),
        "Rp": h.residuals.get("R"),
        "GOF": rv.get("GOF"),
        "message": rv.get("msg"),
        "max_shift_over_sigma": rv.get("Max shft/sig"),
        "mass_fractions": h.ComputeMassFracs(),
        "sample": {
            k: h.SampleParameters[k] for k in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "po": {
            p.name: p.data["Histograms"][h.name]["Pref.Ori."]
            for p in gpx.phases()
        },
        "coordinates": {
            p.name: [
                [a.label, a.element, list(a.coordinates), a.refinement_flags]
                for a in p.atoms()
            ]
            for p in gpx.phases()
        },
        "sigmas": {
            str(v): s
            for v, s in zip(cov.get("varyList", []), cov.get("sig", []))
            if any(x in str(v) for x in ("SurfRough", "MD", "dA"))
        },
        "frozen": [
            str(x)
            for x in gpx.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
    }


def refine(gpx, name, repeats=2):
    previous = float(gpx.histogram(0).get_wR() or math.inf)
    gpx.set_Controls("cycles", 8)
    for _ in range(repeats):
        gpx.refine()
        current = float(gpx.histogram(0).get_wR())
        if not math.isfinite(current) or current > previous + 0.05:
            raise RuntimeError(f"{name} diverged: {previous} -> {current}")
        previous = current
    gpx.save()
    rec = collect(gpx, name)
    print(json.dumps(rec, indent=2))
    return rec


def clone(source, name):
    return G2sc.G2Project(
        gpxfile=str(source), newgpx=str(OUT / f"{name}.gpx")
    )


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    base = clone(SOURCE, "postcoord_base")
    clear_frozen(base)
    records = [refine(base, "postcoord_base", repeats=2)]
    basefile = Path(base.filename)

    # A and B are nearly collinear if varied together. Test one-dimensional
    # corrections at several fixed A values to assess whether the correction
    # itself, rather than either individual parameter, is reproducible.
    for aval in (0.2, 0.5, 0.8):
        name = f"surface_A{str(aval).replace('.', 'p')}"
        gpx = clone(basefile, name)
        clear_frozen(gpx)
        h = gpx.histogram(0)
        h.SampleParameters["SurfRoughA"] = [aval, False]
        h.SampleParameters["SurfRoughB"] = [0.05, True]
        bound(gpx, ":0:SurfRoughB", 0.0001, 2.0)
        try:
            records.append(refine(gpx, name, repeats=3))
        except Exception as exc:
            records.append({"name": name, "error": repr(exc)})

    for axis in ((0, 0, 1), (1, 1, 1)):
        name = "po_" + "".join(map(str, axis))
        gpx = clone(basefile, name)
        clear_frozen(gpx)
        h = gpx.histogram(0)
        po = gpx.phase(0).data["Histograms"][h.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
        bound(gpx, "0:0:MD", 0.5, 2.0)
        try:
            records.append(refine(gpx, name, repeats=3))
        except Exception as exc:
            records.append({"name": name, "error": repr(exc)})

    with (OUT / "summary.json").open("w") as fp:
        json.dump(records, fp, indent=2)


if __name__ == "__main__":
    main()
