#!/usr/bin/env python
"""Develop a bounded, physical refinement for one screened phase model."""

from __future__ import annotations

import csv
import json
import math
import shutil
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent


def plain(value):
    if isinstance(value, (np.floating, np.integer)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


def state(gpx: G2sc.G2Project, stage: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    rec = {
        "stage": stage,
        "residuals": plain(hist.residuals),
        "shift_um": sample.get("Shift", [None])[0],
        "surface_roughness": {
            k: sample.get(k, [None])[0] for k in ("SurfRoughA", "SurfRoughB")
        },
        "instrument": {
            k: inst[k][1]
            for k in ("Polariz.", "U", "V", "W", "X", "Y", "SH/L")
            if k in inst
        },
        "phases": {},
    }
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        rec["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": atom.coordinates,
                    "uiso": atom.uiso,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    try:
        rec["mass_fractions"] = plain(hist.ComputeMassFracs())
    except Exception as exc:
        rec["mass_fraction_error"] = repr(exc)
    return plain(rec)


def rwp(gpx: G2sc.G2Project) -> float:
    val = gpx.histogram(0).get_wR()
    return float(val) if val is not None else math.inf


def set_bound(gpx: G2sc.G2Project, variable: str, lo: float, hi: float) -> None:
    gpx.set_Controls("parmMin", lo, variable=variable)
    gpx.set_Controls("parmMax", hi, variable=variable)


def run_refinement(
    gpx: G2sc.G2Project,
    stage: str,
    log: list[dict],
    checkpoint_dir: Path,
    repeats: int = 1,
) -> G2sc.G2Project:
    """Run a stage and preserve both the stage and last physical checkpoint."""
    previous = rwp(gpx)
    gpx.set_Controls("cycles", 8)
    for _ in range(repeats):
        gpx.refine()
        current = rwp(gpx)
        if not math.isfinite(current) or current > previous + 0.05:
            raise RuntimeError(f"{stage} diverged: Rwp {previous:.4f} -> {current:.4f}")
        previous = current
    rec = state(gpx, stage)
    log.append(rec)
    gpx.save()
    shutil.copy2(gpx.filename, checkpoint_dir / f"{len(log):02d}_{stage}.gpx")
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp": rec["residuals"].get("wR"),
                "shift_um": rec["shift_um"],
                "instrument": rec["instrument"],
                "fractions": rec.get("mass_fractions"),
                "cells": {k: v["cell"] for k, v in rec["phases"].items()},
            },
            indent=2,
        )
    )
    return gpx


def export_profile(gpx: G2sc.G2Project, path: Path) -> None:
    hist = gpx.histogram(0)
    cols = [
        np.asarray(hist.getdata(k), float)
        for k in ("X", "Yobs", "Ycalc", "Background", "Residual")
    ]
    with path.open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
        writer.writerows(zip(*cols))


def main(cod_id: str) -> None:
    source = ROOT / ".tmp" / "screens" / f"screen_{cod_id}.gpx"
    outdir = ROOT / ".tmp" / "physical_branches" / cod_id
    checkpoints = outdir / "checkpoints"
    checkpoints.mkdir(parents=True, exist_ok=True)
    output = outdir / "refined.gpx"
    gpx = G2sc.G2Project(gpxfile=str(source), newgpx=str(output))
    gpx.save()
    hist = gpx.histogram(0)
    main_phase, secondary = gpx.phases()
    for phase in (main_phase, secondary):
        for atom in phase.atoms():
            atom.refinement_flags = " "

    # Explicit broad bounds prevent numerical gains from nonphysical negative
    # widths, scales or displacement parameters.
    set_bound(gpx, "0:0:Scale", 1e-8, 1000.0)
    set_bound(gpx, "1:0:Scale", 1e-8, 1000.0)
    set_bound(gpx, ":0:Shift", -2000.0, 2000.0)
    set_bound(gpx, ":0:U", 0.0, 120.0)
    set_bound(gpx, ":0:W", 0.05, 120.0)
    set_bound(gpx, ":0:X", 0.0, 25.0)
    set_bound(gpx, ":0:SH/L", 0.002, 0.2)
    set_bound(gpx, ":0:Polariz.", 0.45, 1.0)
    for pid in (0, 1):
        set_bound(gpx, f"{pid}:0:Size;i", 0.01, 10.0)
        set_bound(gpx, f"{pid}:0:Mustrain;i", 0.0, 20000.0)

    log: list[dict] = []
    run_refinement(gpx, "converged_cells_scales", log, checkpoints, repeats=3)

    # One common Uiso per phase is identifiable without assigning a separate
    # thermal parameter to every crystallographic site.
    for pid, phase in enumerate((main_phase, secondary)):
        for atom in phase.atoms():
            atom.uiso = 0.01
            atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
        variables = tuple(f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms()))
        if len(variables) > 1:
            gpx.add_EquivConstr(variables, reloadIdx=True)
        set_bound(gpx, f"{pid}::AUiso:0", 0.0001, 0.05)
    run_refinement(gpx, "phase_uiso", log, checkpoints, repeats=2)

    # Phase-specific broadening is introduced before changing the common
    # instrument response, which is anchored by the sharper WO3 reflections.
    main_phase.setSampleProfile(hist, "size", "isotropic", 0.10, LGmix=1.0)
    secondary.setSampleProfile(hist, "size", "isotropic", 0.8, LGmix=1.0)
    main_phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    run_refinement(gpx, "main_size", log, checkpoints, repeats=2)
    secondary.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}}, [hist])
    run_refinement(gpx, "both_sizes", log, checkpoints, repeats=2)

    main_phase.setSampleProfile(hist, "microstrain", "isotropic", 1500.0, LGmix=0.5)
    secondary.setSampleProfile(hist, "microstrain", "isotropic", 300.0, LGmix=0.5)
    main_phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    run_refinement(gpx, "main_microstrain", log, checkpoints, repeats=2)
    secondary.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    run_refinement(gpx, "both_microstrains", log, checkpoints, repeats=2)

    for parameter, stage in (
        ("W", "instrument_W"),
        ("U", "instrument_UW"),
        ("X", "instrument_UWX"),
        ("SH/L", "axial_divergence"),
        ("Polariz.", "polarization"),
    ):
        hist.set_refinements({"Instrument Parameters": [parameter]})
        run_refinement(gpx, stage, log, checkpoints, repeats=2)

    gpx.save()
    for phase in gpx.phases():
        phase.export_CIF(str(outdir / f"{phase.name}.cif"))
    export_profile(gpx, outdir / "fit.csv")
    with (outdir / "refinement_log.json").open("w") as fp:
        json.dump(log, fp, indent=2)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: refine_candidate.py COD_ID")
    main(sys.argv[1])
