#!/usr/bin/env python
"""Create all submitted outputs from the selected GSAS-II checkpoint."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/post_coordinate_tests/postcoord_base.gpx"


def native(value):
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): native(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [native(v) for v in value]
    return value


def sanitize(gpx):
    """Explicitly remove all rejected/boundary-frozen branch parameters."""
    h = gpx.histogram(0)
    gpx.data["Controls"]["data"].setdefault("parmFrozen", {})[
        "FrozenList"
    ] = []
    h.set_refinements({"Limits": list(h.data["Limits"][0])})
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    h.InstrumentParameters["X"][1:] = [0.5, False]
    h.InstrumentParameters["Polariz."][1:] = [0.7, False]

    for phase in gpx.phases():
        hap = phase.data["Histograms"][h.name]
        hap["Pref.Ori."][0:4] = ["MD", 1.0, False, [0, 0, 1]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]

    # Only the well-determined scheelite oxygen coordinate remains active.
    for ip, phase in enumerate(gpx.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = atom.refinement_flags.replace("X", "")
        if ip == 0:
            oxygen = [a for a in phase.atoms() if a.element == "O"]
            if len(oxygen) != 1:
                raise RuntimeError("unexpected CaWO4 asymmetric unit")
            oxygen[0].refinement_flags += "X"


def refine_final(gpx):
    gpx.set_Controls("cycles", 8)
    previous = float(gpx.histogram(0).get_wR() or math.inf)
    for _ in range(2):
        gpx.refine()
        current = float(gpx.histogram(0).get_wR())
        if not math.isfinite(current) or current > previous + 0.01:
            raise RuntimeError(f"final refinement diverged: {previous} -> {current}")
        previous = current
    gpx.save()
    rv = gpx.data["Covariance"]["data"].get("Rvals", {})
    frozen = (
        gpx.data["Controls"]["data"]
        .get("parmFrozen", {})
        .get("FrozenList", [])
    )
    if rv.get("SVD0", 0) or frozen or not rv.get("converged", False):
        raise RuntimeError(
            f"non-replayable final covariance: SVD0={rv.get('SVD0')}, "
            f"frozen={frozen}, converged={rv.get('converged')}"
        )


def export_profile(gpx):
    h = gpx.histogram(0)
    columns = [
        np.asarray(h.getdata(key), dtype=float)
        for key in ("X", "Yobs", "Ycalc", "Background", "Residual")
    ]
    with (ROOT / "fit.csv").open("w", newline="") as fp:
        writer = csv.writer(fp)
        writer.writerow(
            [
                "two_theta_deg",
                "observed",
                "calculated",
                "background",
                "difference",
            ]
        )
        writer.writerows(zip(*columns))


def build_result(gpx):
    h = gpx.histogram(0)
    phases = gpx.phases()
    fractions = h.ComputeMassFracs()
    cov = gpx.data["Covariance"]["data"]
    rv = cov.get("Rvals", {})
    resid = h.residuals
    specs = (
        (
            phases[0],
            "CaWO4 (scheelite)",
            "CaWO4",
            "COD 7219229",
            "CaWO4_scheelite.cif",
        ),
        (
            phases[1],
            "WO3 (monoclinic)",
            "WO3",
            "COD 2311041",
            "WO3_monoclinic.cif",
        ),
    )
    phase_records = []
    for phase, label, formula, reference, cifname in specs:
        frac, sigma = fractions[phase.name]
        cell = phase.get_cell()
        phase_records.append(
            {
                "name": label,
                "formula": formula,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "reference": reference,
                "cif_path": cifname,
                "weight_fraction": float(frac),
                "weight_fraction_esd": float(sigma),
                "weight_percent": 100.0 * float(frac),
                "weight_percent_esd": 100.0 * float(sigma),
                "cell": {
                    "a_angstrom": cell["length_a"],
                    "b_angstrom": cell["length_b"],
                    "c_angstrom": cell["length_c"],
                    "alpha_deg": cell["angle_alpha"],
                    "beta_deg": cell["angle_beta"],
                    "gamma_deg": cell["angle_gamma"],
                    "volume_angstrom3": cell["volume"],
                },
            }
        )

    rwp = float(resid["wR"])
    gof = float(rv["GOF"])
    result = {
        "phases": phase_records,
        "normalization": (
            "Weight fractions sum to one over the modeled crystalline phases; "
            "no amorphous fraction or external-standard correction was determined."
        ),
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(resid["R"]),
            "Rexp_percent": rwp / gof,
            "goodness_of_fit": gof,
            "chi_square": float(rv["chisq"]),
            "reduced_chi_square": gof * gof,
            "n_observations": int(rv["Nobs"]),
            "n_variables": int(rv["Nvars"]),
            "max_shift_over_esd": float(rv["Max shft/sig"]),
            "converged": bool(rv["converged"]),
            "CaWO4_Rf_percent": float(resid["0:0:Rf"]),
            "WO3_Rf_percent": float(resid["1:0:Rf"]),
        },
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "measurement_range_two_theta_deg": list(h.data["Limits"][1]),
    }
    with (ROOT / "result.json").open("w") as fp:
        json.dump(native(result), fp, indent=2)
        fp.write("\n")
    return result


def write_report(result):
    ca, wo = result["phases"]
    stats = result["fit_statistics"]
    report = f"""# Quantitative crystalline-phase analysis

## Result

The pattern is described by two crystalline phases:

| Phase | Space group | Refined cell (Å, °) | Crystalline weight fraction |
|---|---|---|---:|
| CaWO₄, scheelite | I 4₁/a (No. 88) | a = {ca['cell']['a_angstrom']:.5f}, c = {ca['cell']['c_angstrom']:.5f} | {ca['weight_percent']:.2f} wt% |
| WO₃, monoclinic | P 2₁/c (No. 14) | a = {wo['cell']['a_angstrom']:.5f}, b = {wo['cell']['b_angstrom']:.5f}, c = {wo['cell']['c_angstrom']:.5f}, β = {wo['cell']['beta_deg']:.4f}° | {wo['weight_percent']:.2f} wt% |

The full-range GSAS-II refinement (9.9034–100.0946° 2θ, all 8,301 points) converged at Rwp = {stats['Rwp_percent']:.3f}%, Rp = {stats['Rp_percent']:.3f}%, Rexp = {stats['Rexp_percent']:.3f}%, and goodness of fit = {stats['goodness_of_fit']:.3f}. The submitted `final.gpx`, CIFs, fractions, and `fit.csv` all come from this same final replay.

## Evidence and model choice

The dominant family (including peaks near 18.27, 28.43, 31.21, 33.85, 38.91, 46.89, 54.15, and 57.65°) is indexed by scheelite CaWO₄ (COD 7219229). After fitting it, the coherent residual family near 22.76, 23.18, 23.98, 26.19, 28.77, 32.88/33.13, 49.48, and 55.49° is indexed by monoclinic WO₃ (COD 2311041). This is chemically consistent with incomplete conversion of the WO₃ + CaCO₃ charge at 650 °C. No coherent reflection family remains that warrants a third crystalline phase; CaO, CaCO₃, other Ca–W–O products, and alternative WO₃ cells did not obtain broad-family support with a stable positive contribution.

The closest alternative was a triclinic WO₃ description with essentially the same Rwp, but its refined angles collapsed toward a monoclinic metric. The simpler P 2₁/c model was therefore retained. A second monoclinic reference and an orthorhombic WO₃ model fit less well. The CaWO₄ oxygen site refined reproducibly from three bounded starts and retained normal geometry (W–O ≈ 1.798 Å; Ca–O ≈ 2.420–2.454 Å). Releasing WO₃ W coordinates drove several shifts to bounds, and its oxygen coordinates were underdetermined; the physical reference coordinates were restored. Surface roughness refined to zero after this correction, while texture and anisotropic-size tests gave negligible, axis-dependent gains and were omitted.

## Uncertainty

Fractions are normalized only over the modeled crystalline phases. The covariance-matrix e.s.d. is about {ca['weight_percent_esd']:.2f} wt% for either fraction, but it excludes structural/profile-model choice; an absolute uncertainty of roughly 1 wt% is more realistic. An amorphous fraction cannot be measured without an internal or external standard. The WO₃ phase identity, cell, and amount are reliable at this level, but its individual light-atom coordinates are not independently determined by this powder pattern and remain reference-based.
"""
    (ROOT / "report.md").write_text(report)


def main():
    gpx = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(ROOT / "final.gpx"))
    sanitize(gpx)
    refine_final(gpx)
    gpx.phases()[0].export_CIF(str(ROOT / "CaWO4_scheelite.cif"))
    gpx.phases()[1].export_CIF(str(ROOT / "WO3_monoclinic.cif"))
    export_profile(gpx)
    result = build_result(gpx)
    write_report(result)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
