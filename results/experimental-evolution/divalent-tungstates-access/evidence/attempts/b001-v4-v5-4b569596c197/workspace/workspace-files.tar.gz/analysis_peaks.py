#!/usr/bin/env python
"""Exploratory peak picking and plotting for the supplied powder pattern."""

import numpy as np
import pandas as pd
from scipy.ndimage import minimum_filter1d, gaussian_filter1d
from scipy.signal import find_peaks, peak_widths
import matplotlib.pyplot as plt


data = pd.read_csv("inputs/pattern.csv")
x = data.iloc[:, 0].to_numpy(float)
y = data.iloc[:, 1].to_numpy(float)

# Broad rolling-minimum baseline followed by light smoothing. This is only for
# peak discovery; quantitative fitting is done later against the raw counts.
base = gaussian_filter1d(minimum_filter1d(y, size=401, mode="nearest"), 120)
ys = gaussian_filter1d(y - base, 1.2)
peaks, props = find_peaks(ys, prominence=45, distance=5, height=30)
width_pts = peak_widths(ys, peaks, rel_height=0.5)[0]

rows = sorted(
    zip(peaks, props["prominences"], props["peak_heights"], width_pts),
    key=lambda z: z[1],
    reverse=True,
)
print(f"points={len(x)} range={x[0]:.6f}..{x[-1]:.6f} step={np.median(np.diff(x)):.7f}")
print("rank  2theta       intensity  baseline  net_height prominence FWHM_deg")
for rank, (i, prom, height, w) in enumerate(rows[:180], 1):
    print(f"{rank:3d} {x[i]:10.5f} {y[i]:10.1f} {base[i]:9.1f} {height:10.1f} {prom:10.1f} {w*np.median(np.diff(x)):8.4f}")

fig, axes = plt.subplots(3, 1, figsize=(15, 10), sharey=False)
for ax, (lo, hi) in zip(axes, [(9.9, 40), (38, 70), (68, 100.1)]):
    sel = (x >= lo) & (x <= hi)
    ax.plot(x[sel], y[sel], lw=0.65, color="black")
    ax.plot(x[sel], base[sel], lw=0.8, color="tab:orange")
    pp = peaks[(x[peaks] >= lo) & (x[peaks] <= hi)]
    ax.scatter(x[pp], y[pp], s=8, color="tab:red")
    ax.set_xlim(lo, hi)
    ax.set_ylabel("counts")
axes[-1].set_xlabel(r"$2\theta$ (deg)")
fig.tight_layout()
fig.savefig("pattern_peaks.png", dpi=180)
