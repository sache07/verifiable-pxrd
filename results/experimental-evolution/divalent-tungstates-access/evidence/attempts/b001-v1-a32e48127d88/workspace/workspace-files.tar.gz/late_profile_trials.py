#!/usr/bin/env python
"""Late one-at-a-time profile sensitivity checks on the selected model."""

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path("final.gpx")
WORK = Path(".tmp/late_profile_trials")
WORK.mkdir(parents=True, exist_ok=True)
HIST = "PWDR pattern.csv"
PHASES = ["ZnWO4_wolframite", "WO3_monoclinic_2311041", "ZnO_wurtzite_9004178"]


def high_correlations(project, threshold=0.85):
    c = project.data.get("Covariance", {}).get("data", {})
    matrix = np.asarray(c.get("covMatrix"), dtype=float)
    vary = [str(value) for value in c.get("varyList", [])]
    if matrix.ndim != 2 or not vary:
        return []
    sig = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    den = sig[:, None] * sig[None, :]
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = np.where(den > 0, matrix / den, 0.0)
    result = []
    for i in range(len(vary)):
        for j in range(i + 1, len(vary)):
            if abs(corr[i, j]) >= threshold:
                result.append([vary[i], vary[j], float(corr[i, j])])
    return sorted(result, key=lambda item: -abs(item[2]))[:20]


def execute(name, mutate):
    filename = WORK / f"{name}.gpx"
    shutil.copy2(BASE, filename)
    project = G2.G2Project(gpxfile=str(filename))
    mutate(project)
    project.set_Controls("cycles", 50)
    project.save(str(filename))
    project.refine()
    project = G2.G2Project(gpxfile=str(filename))
    hist = project.histogram(HIST)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "trial": name,
        "rwp_percent": float(hist.get_wR()),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg", ""),
        "sample": hist.SampleParameters,
        "sizes": {
            phase: project.phase(phase).data["Histograms"][hist.name]["Size"]
            for phase in PHASES
        },
        "high_correlations": high_correlations(project),
    }
    print(json.dumps(result, sort_keys=True), flush=True)
    return result


G2.SetPrintLevel("warn")
results = []
for phase in PHASES:
    name = "size_" + phase
    try:
        results.append(
            execute(
                name,
                lambda project, phase=phase: project.phase(phase).set_HAP_refinements(
                    {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
                    histograms=[project.histogram(HIST)],
                ),
            )
        )
    except Exception as exc:
        results.append({"trial": name, "status": "unknown", "error": f"{type(exc).__name__}: {exc}"})

try:
    results.append(
        execute(
            "sample_shift",
            lambda project: project.histogram(HIST).set_refinements(
                {"Sample Parameters": ["Shift"]}
            ),
        )
    )
except Exception as exc:
    results.append({"trial": "sample_shift", "status": "unknown", "error": f"{type(exc).__name__}: {exc}"})


def roughness(project):
    hist = project.histogram(HIST)
    hist.SampleParameters["SurfRoughA"] = [0.3, True]
    hist.SampleParameters["SurfRoughB"] = [0.1, True]


try:
    results.append(execute("surface_roughness", roughness))
except Exception as exc:
    results.append({"trial": "surface_roughness", "status": "unknown", "error": f"{type(exc).__name__}: {exc}"})

(WORK / "results.json").write_text(json.dumps(results, indent=2) + "\n")
