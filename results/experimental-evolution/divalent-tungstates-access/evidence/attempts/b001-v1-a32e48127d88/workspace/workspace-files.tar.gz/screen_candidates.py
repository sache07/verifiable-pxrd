#!/usr/bin/env python
"""Coarse, background-subtracted profile screen for structural prototypes."""

import csv
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, minimum_filter1d
from scipy.optimize import differential_evolution


CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c05/cif"
)
RECORDS = [
    ("BaWO4", "1527204"),
    ("CdWO4", "1549132"),
    ("CuWO4", "4000806"),
    ("CaWO4", "7219229"),
    ("CaWO4", "5910088"),
    ("CaWO4", "1546035"),
    ("AlWO4", "1544388"),
    ("PbWO4", "1527935"),
    ("PbWO4", "9009811"),
    ("PbWO4", "9007617"),
    ("SrWO4", "1546036"),
    ("SrWO4", "1546037"),
    ("EuWO4", "1561850"),
    ("FeWO4", "1567215"),
    ("HgWO4", "2012578"),
    ("ZnMoO4", "1528282", {"Mo": "W"}),
    ("CoMoO4", "7205001", {"Co": "Zn", "Mo": "W"}),
    ("MnMoO4", "1527061", {"Mn": "Zn", "Mo": "W"}),
    ("MgMoO4", "2300504", {"Mg": "Zn", "Mo": "W"}),
    ("CuMoO4-a", "1535336", {"Cu": "Zn", "Mo": "W"}),
    ("CuMoO4-b", "1539674", {"Cu": "Zn", "Mo": "W"}),
    ("NbInO4", "1524100", {"In": "Zn", "Nb": "W"}),
    ("NbFeO4", "2002235", {"Fe": "Zn", "Nb": "W"}),
    ("LuTaO4", "1530904", {"Lu": "Zn", "Ta": "W"}),
    ("ErTaO4", "1530905", {"Er": "Zn", "Ta": "W"}),
    ("DyTaO4", "1530906", {"Dy": "Zn", "Ta": "W"}),
    ("GdTaO4", "1530907", {"Gd": "Zn", "Ta": "W"}),
    ("YTaO4", "9011071", {"Y": "Zn", "Ta": "W"}),
    ("YbTaO4", "1531746", {"Yb": "Zn", "Ta": "W"}),
    ("TaInO4", "4329321", {"In": "Zn", "Ta": "W"}),
    ("HoTaO4", "7707608", {"Ho": "Zn", "Ta": "W"}),
]


def cif_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


with Path("inputs/pattern.csv").open(newline="") as stream:
    rows = list(csv.DictReader(stream))
x_all = np.array([float(row["two_theta_deg"]) for row in rows])
y_all = np.array([float(row["intensity"]) for row in rows])
background = gaussian_filter1d(
    minimum_filter1d(y_all, size=301, mode="nearest"), sigma=120
)
select = (x_all >= 12.0) & (x_all <= 75.0)
x = x_all[select]
y = np.maximum(y_all[select] - background[select], 0.0)
step = x[1] - x[0]
denom = np.dot(y, y)
calculator = XRDCalculator(wavelength=1.540598, symprec=0)


def make_profile(ds, intensities, linear_scale, shift, fwhm):
    sticks = np.zeros_like(x)
    for wavelength, ratio in ((1.540598, 1.0), (1.544426, 0.5)):
        sine = wavelength / (2.0 * ds * linear_scale)
        valid = sine < 1.0
        positions = np.degrees(2.0 * np.arcsin(sine[valid])) + shift
        amplitudes = ratio * intensities[valid]
        bins = (positions - x[0]) / step
        inside = (bins >= 0.0) & (bins < len(x) - 1)
        bins = bins[inside]
        amplitudes = amplitudes[inside]
        lower = bins.astype(int)
        fraction = bins - lower
        np.add.at(sticks, lower, amplitudes * (1.0 - fraction))
        np.add.at(sticks, lower + 1, amplitudes * fraction)
    return gaussian_filter1d(sticks, fwhm / (2.35482 * step), mode="constant")


for record in RECORDS:
    formula, cod_id = record[:2]
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(cif_path(cod_id), primitive=False)
        if len(record) == 3:
            structure.replace_species(record[2])
        else:
            other = [
                element
                for element in structure.composition.elements
                if element.symbol not in ("O", "W")
            ]
            if len(other) != 1:
                raise ValueError("not a ternary A-W-O structure")
            structure.replace_species({other[0]: "Zn"})
        pattern = calculator.get_pattern(
            structure, two_theta_range=(8.0, 105.0), scaled=False
        )
        ds = np.asarray(pattern.d_hkls)
        intensities = np.asarray(pattern.y)

        def objective(values):
            profile = make_profile(ds, intensities, *values)
            scale = max(0.0, np.dot(y, profile) / (np.dot(profile, profile) + 1e-30))
            return np.dot(y - scale * profile, y - scale * profile) / denom

        optimum = differential_evolution(
            objective,
            [(0.72, 1.18), (-0.5, 0.5), (0.10, 0.45)],
            seed=123,
            popsize=5,
            maxiter=24,
            tol=1e-5,
            polish=True,
        )
        linear_scale, shift, fwhm = optimum.x
        distances = structure.distance_matrix
        minimum_distance = distances[distances > 1e-6].min() * linear_scale
        density = structure.density / linear_scale**3
        sg = structure.get_space_group_info(symprec=0.05)
        print(
            f"{1.0-optimum.fun:8.5f} {formula:7s} {cod_id} "
            f"s={linear_scale:7.4f} shift={shift:7.4f} fwhm={fwhm:6.3f} "
            f"mind={minimum_distance:5.3f} rho={density:6.3f} sg={sg}",
            flush=True,
        )
    except Exception as exc:
        print(f"UNKNOWN {formula:7s} {cod_id}: {type(exc).__name__}: {exc}", flush=True)
