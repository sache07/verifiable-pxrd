#!/usr/bin/env python
"""Write the submitted profile from the independent final-project replay."""

from pathlib import Path

import numpy as np


with np.load(".tmp/replay_final/prediction.npz", allow_pickle=False) as replay:
    x = replay["x"]
    observed = replay["observed"]
    calculated = replay["predicted"]

difference = observed - calculated
profile = np.column_stack((x, observed, calculated, difference))
np.savetxt(
    Path("fit.csv"),
    profile,
    delimiter=",",
    header="two_theta,observed,calculated,difference_observed_minus_calculated",
    comments="",
    fmt=("%.8f", "%.8f", "%.10f", "%.10f"),
)
