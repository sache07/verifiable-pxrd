#!/usr/bin/env python
"""One-at-a-time late-stage nuisance and WO3 coordinate trials."""

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/model3_combined_wo3W1_2.gpx")
WORK = Path(".tmp/final_parameter_trials")
WORK.mkdir(parents=True, exist_ok=True)
HISTOGRAM = "PWDR pattern.csv"
WO3 = "WO3_monoclinic_2311041"


def correlations(project, threshold=0.85):
    covariance = project.data.get("Covariance", {}).get("data", {})
    matrix = covariance.get("covMatrix")
    vary = [str(value) for value in covariance.get("varyList", [])]
    if matrix is None or not len(vary):
        return []
    matrix = np.asarray(matrix, dtype=float)
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denominator = sigma[:, None] * sigma[None, :]
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = np.where(denominator > 0, matrix / denominator, 0.0)
    pairs = []
    for i in range(len(vary)):
        for j in range(i + 1, len(vary)):
            if abs(corr[i, j]) >= threshold:
                pairs.append([vary[i], vary[j], float(corr[i, j])])
    return sorted(pairs, key=lambda item: -abs(item[2]))[:20]


def atom_state(project):
    phase = project.phase(WO3)
    return {
        atom.label: {
            "coordinates": [float(value) for value in atom.coordinates],
            "refinement_flags": atom.refinement_flags,
        }
        for atom in phase.atoms()
    }


def collect(project, trial):
    hist = project.histogram(HISTOGRAM)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    result = {
        "trial": trial,
        "rwp_percent": float(hist.get_wR()),
        "gof": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg", ""),
        "instrument_U": inst["U"],
        "background": hist.data["Background"][0],
        "wo3_atoms": atom_state(project),
        "high_correlations": correlations(project),
        "vary_list": [
            str(value)
            for value in project.data.get("Covariance", {})
            .get("data", {})
            .get("varyList", [])
        ],
    }
    print(json.dumps(result, sort_keys=True), flush=True)
    return result


def run(name, mutate, cycles=24):
    filename = WORK / f"{name}.gpx"
    shutil.copy2(BASE, filename)
    project = G2.G2Project(gpxfile=str(filename))
    mutate(project)
    project.set_Controls("cycles", cycles)
    project.save(str(filename))
    project.refine()
    project = G2.G2Project(gpxfile=str(filename))
    return collect(project, name)


G2.SetPrintLevel("warn")
results = []


def set_u(project):
    project.histogram(HISTOGRAM).set_refinements({"Instrument Parameters": ["U"]})


def set_background(project, count):
    project.histogram(HISTOGRAM).set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": count, "refine": True}}
    )


for name, mutation in (
    ("instrument_U", set_u),
    ("background_10", lambda project: set_background(project, 10)),
    ("background_12", lambda project: set_background(project, 12)),
):
    try:
        results.append(run(name, mutation))
    except Exception as exc:
        item = {"trial": name, "status": "unknown", "error": f"{type(exc).__name__}: {exc}"}
        results.append(item)
        print(json.dumps(item, sort_keys=True), flush=True)

for atom in ("W0", "O2", "O3", "O4", "O5", "O6", "O7"):
    name = f"wo3_{atom}_coordinates"
    try:
        results.append(
            run(
                name,
                lambda project, atom=atom: project.phase(WO3).set_refinements(
                    {"Atoms": {atom: "X"}}
                ),
            )
        )
    except Exception as exc:
        item = {"trial": name, "status": "unknown", "error": f"{type(exc).__name__}: {exc}"}
        results.append(item)
        print(json.dumps(item, sort_keys=True), flush=True)

(WORK / "results.json").write_text(json.dumps(results, indent=2) + "\n")
