#!/usr/bin/env python
"""Controlled GSAS-II replacement trials for a diverse ZnWO4 shortlist."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/final_candidate_bg14.gpx")
WORK = Path(".tmp/major_shortlist_trials")
WORK.mkdir(parents=True, exist_ok=True)
HISTOGRAM = "PWDR pattern.csv"
OLD_PHASE = "ZnWO4_wolframite"
CANDIDATES = [
    "CoMoO4_wolframite",
    "FeWO4_wolframite",
    "CuWO4_triclinic",
    "CaWO4_scheelite",
    "HgWO4_C2c",
]
AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 1, 1])


def reset_flags(project):
    hist = project.histogram(HISTOGRAM)
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
            ],
            "Sample Parameters": [
                "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
            ],
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            }
        )
    return hist


def refine(project, filename, cycles=24):
    project.set_Controls("cycles", cycles)
    project.save(str(filename))
    project.refine()
    return G2.G2Project(gpxfile=str(filename))


def collect(project, candidate, stage):
    hist = project.histogram(HISTOGRAM)
    phase = project.phase(candidate)
    active = [
        item for item in project.phases()
        if item.data["Histograms"][hist.name].get("Use", True)
    ]
    products = {
        item.name: float(item.data["General"]["Mass"])
        * float(item.data["Histograms"][hist.name]["Scale"][0])
        for item in active
    }
    total = sum(products.values())
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    hap = phase.data["Histograms"][hist.name]
    result = {
        "candidate": candidate,
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg", ""),
        "cell": phase.get_cell(),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_weight_fraction": products[candidate] / total,
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "weight_fractions": {key: value / total for key, value in products.items()},
        "vary_list": [
            str(value)
            for value in project.data.get("Covariance", {})
            .get("data", {})
            .get("varyList", [])
        ],
    }
    print(json.dumps(result, sort_keys=True), flush=True)
    return result


G2.SetPrintLevel("warn")
results = []
for candidate in CANDIDATES:
    try:
        start = WORK / f"{candidate}_start.gpx"
        shutil.copy2(BASE, start)
        project = G2.G2Project(gpxfile=str(start))
        hist = reset_flags(project)
        old = project.phase(OLD_PHASE)
        old_hap = old.data["Histograms"][hist.name]
        old_product = float(old.data["General"]["Mass"]) * float(old_hap["Scale"][0])
        old_hap["Use"] = False
        old_hap["Scale"][1] = False

        phase = project.add_phase(
            str(Path(".tmp/major_shortlist") / f"{candidate}.cif"),
            phasename=candidate,
            histograms=[hist],
            fmthint="CIF",
        )
        phase = project.phase(candidate)
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"] = [old_product / float(phase.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 240.0
        hap["Mustrain"][1][1] = 240.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for other in ("WO3_monoclinic_2311041", "ZnO_wurtzite_9004178"):
            project.phase(other).set_HAP_refinements({"Scale": True}, histograms=[hist])
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])

        scale_file = WORK / f"{candidate}_scale.gpx"
        project = refine(project, scale_file)
        result = collect(project, candidate, "scale_background")
        results.append(result)
        if not result["converged"] or result["candidate_scale"] <= 1e-8:
            continue

        project.phase(candidate).set_refinements({"Cell": True})
        cell_file = WORK / f"{candidate}_cell.gpx"
        project = refine(project, cell_file, cycles=36)
        result = collect(project, candidate, "candidate_cell")
        results.append(result)
        if not result["converged"] or result["rwp_percent"] >= 15.0:
            continue

        project.phase(candidate).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, histograms=[hist]
        )
        strain_file = WORK / f"{candidate}_strain.gpx"
        project = refine(project, strain_file)
        result = collect(project, candidate, "isotropic_strain")
        results.append(result)
        if not result["converged"]:
            continue

        for axis in AXES:
            tag = "".join(str(value) for value in axis)
            trial_file = WORK / f"{candidate}_texture_{tag}.gpx"
            shutil.copy2(strain_file, trial_file)
            trial = G2.G2Project(gpxfile=str(trial_file))
            trial_phase = trial.phase(candidate)
            trial_hap = trial_phase.data["Histograms"][hist.name]
            trial_hap["Pref.Ori."][1] = 1.0
            trial_hap["Pref.Ori."][3] = list(axis)
            trial_phase.set_HAP_refinements({"Pref.Ori.": True}, histograms=[hist])
            trial = refine(trial, trial_file)
            results.append(collect(trial, candidate, f"texture_{tag}"))
    except Exception as exc:
        item = {
            "candidate": candidate,
            "stage": "unknown",
            "error": f"{type(exc).__name__}: {exc}",
        }
        results.append(item)
        print(json.dumps(item, sort_keys=True), flush=True)

(WORK / "results.json").write_text(json.dumps(results, indent=2) + "\n")
