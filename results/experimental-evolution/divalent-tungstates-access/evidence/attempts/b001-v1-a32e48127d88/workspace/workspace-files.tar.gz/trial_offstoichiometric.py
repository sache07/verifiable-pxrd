#!/usr/bin/env python
"""Common-project GSAS-II trials for off-stoichiometric residual candidates."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/model3_combined_wo3W1_2.gpx")
WORK = Path(".tmp/offstoich_trials")
WORK.mkdir(parents=True, exist_ok=True)
HISTOGRAM = "PWDR pattern.csv"
CANDIDATES = [
    "Zn3WO6_from_Zn3TeO6",
    "Zn3WO6_from_Mn3TeO6",
    "Zn3WO6_from_Mn3WO6",
    "Zn2WO5_from_MoPb2O5",
    "ZnxWO3_cubic_bronze",
]


def reset_flags(project):
    hist = project.histogram(HISTOGRAM)
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
            ],
            "Sample Parameters": [
                "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
            ],
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            }
        )
        if phase.data["Histograms"][hist.name].get("Use", True):
            phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    return hist


def run_refinement(project, filename, cycles=18):
    project.set_Controls("cycles", cycles)
    project.save(str(filename))
    project.refine()
    return G2.G2Project(gpxfile=str(filename))


def collect(project, candidate, stage, starting_volume):
    hist = project.histogram(HISTOGRAM)
    phase = project.phase(candidate)
    active = [
        item for item in project.phases()
        if item.data["Histograms"][hist.name].get("Use", True)
    ]
    products = {
        item.name: float(item.data["General"]["Mass"])
        * float(item.data["Histograms"][hist.name]["Scale"][0])
        for item in active
    }
    total = sum(products.values())
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    cell = phase.get_cell()
    result = {
        "candidate": candidate,
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg", ""),
        "candidate_scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
        "candidate_weight_fraction": products[candidate] / total,
        "all_weight_fractions": {key: value / total for key, value in products.items()},
        "cell": cell,
        "relative_volume_change": float(cell["volume"] / starting_volume - 1.0),
        "vary_list": [
            str(item)
            for item in project.data.get("Covariance", {})
            .get("data", {})
            .get("varyList", [])
        ],
    }
    print(json.dumps(result, sort_keys=True), flush=True)
    return result


G2.SetPrintLevel("warn")
results = []
for name in CANDIDATES:
    try:
        start = WORK / f"{name}_start.gpx"
        shutil.copy2(BASE, start)
        project = G2.G2Project(gpxfile=str(start))
        hist = reset_flags(project)
        phase = project.add_phase(
            str(Path(".tmp/offstoich_candidates_sym") / f"{name}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        active_product = sum(
            float(item.data["General"]["Mass"])
            * float(item.data["Histograms"][hist.name]["Scale"][0])
            for item in project.phases()
            if item.name != name and item.data["Histograms"][hist.name].get("Use", True)
        )
        # Explicitly initialize at 1 wt% and verify a positive scale.
        hap["Scale"] = [
            0.01 * active_product / (0.99 * float(phase.data["General"]["Mass"])),
            True,
        ]
        if hap["Scale"][0] <= 0:
            raise RuntimeError("candidate did not receive a positive initialized scale")
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 3000.0
        hap["Mustrain"][1][1] = 3000.0
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        starting_volume = float(phase.get_cell()["volume"])

        scale_file = WORK / f"{name}_scale.gpx"
        project = run_refinement(project, scale_file)
        result = collect(project, name, "scale_background", starting_volume)
        results.append(result)
        if (
            not result["converged"]
            or result["candidate_scale"] <= 1e-8
            or result["candidate_weight_fraction"] < 0.0005
        ):
            continue

        project.phase(name).set_refinements({"Cell": True})
        cell_file = WORK / f"{name}_cell.gpx"
        project = run_refinement(project, cell_file, cycles=28)
        result = collect(project, name, "candidate_cell", starting_volume)
        results.append(result)
    except Exception as exc:
        result = {
            "candidate": name,
            "stage": "unknown",
            "error": f"{type(exc).__name__}: {exc}",
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)

(WORK / "results.json").write_text(json.dumps(results, indent=2) + "\n")
