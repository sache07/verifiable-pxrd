#!/usr/bin/env python
"""Residual screen for Zn-rich and fractional tungsten-oxide prototypes."""

import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import differential_evolution


CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c05/cif"
)
OUT = Path(".tmp/offstoich_candidates")
OUT.mkdir(parents=True, exist_ok=True)

# The first groups test charge-balanced Zn3WO6 and Zn2WO5 compositions. The
# final group explicitly tests fractional-occupancy tungsten-bronze topologies.
CANDIDATES = [
    ("Zn3WO6_from_Ba3WO6", "1534803", {"Ba": "Zn"}, "Zn3WO6"),
    ("Zn3WO6_from_Cu3WO6", "1527404", {"Cu": "Zn"}, "Zn3WO6"),
    ("Zn3WO6_from_Ca3WO6", "1563081", {"Ca": "Zn"}, "Zn3WO6"),
    ("Zn3WO6_from_Mn3WO6", "2002703", {"Mn": "Zn"}, "Zn3WO6"),
    ("Zn3WO6_from_Sc3WO6", "1563543", {"Sc": "Zn"}, "Zn3WO6"),
    ("Zn3WO6_from_Zn3TeO6", "2211529", {"Te": "W"}, "Zn3WO6"),
    ("Zn3WO6_from_Ni3TeO6", "2211031", {"Ni": "Zn", "Te": "W"}, "Zn3WO6"),
    ("Zn3WO6_from_Mn3TeO6", "2211528", {"Mn": "Zn", "Te": "W"}, "Zn3WO6"),
    ("Zn3WO6_from_Cu3TeO6", "1557963", {"Cu": "Zn", "Te": "W"}, "Zn3WO6"),
    ("Zn2WO5_from_MoPb2O5", "7220560", {"Mo": "W", "Pb": "Zn"}, "Zn2WO5"),
    ("Zn2WO5_from_Ba2ReO5", "1529756", {"Ba": "Zn", "Re": "W"}, "Zn2WO5"),
    ("Zn2WO5_from_Eu2ReO5", "1521235", {"Eu": "Zn", "Re": "W"}, "Zn2WO5"),
    ("Zn2WO5_from_Gd2ReO5", "1521237", {"Gd": "Zn", "Re": "W"}, "Zn2WO5"),
    ("Zn2WO5_from_Bi2AuO5", "1510605", {"Bi": "Zn", "Au": "W"}, "Zn2WO5"),
    ("Zn2WO5_from_TePb2O5a", "9015570", {"Te": "W", "Pb": "Zn"}, "Zn2WO5"),
    ("Zn2WO5_from_TePb2O5b", "2002145", {"Te": "W", "Pb": "Zn"}, "Zn2WO5"),
    ("ZnxWO3_cubic_bronze", "1010420", {"Na": "Zn"}, "fractional_bronze"),
    ("ZnxWO3_hex_bronze", "1524710", {"K": "Zn"}, "fractional_bronze"),
    ("ZnxWO3_ortho_bronze", "1001273", {"Ba": "Zn"}, "fractional_bronze"),
    ("ZnxWO3_tetr_bronze", "4030741", {"Ca": "Zn"}, "fractional_bronze"),
]


def cif_path(cod_id):
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


arrays = np.load(".tmp/current_fit_arrays.npz")
x_all = arrays["x"]
observed_all = arrays["obs"]
residual_all = observed_all - arrays["calc"]
select = (x_all >= 10.0) & (x_all <= 90.0)
x = x_all[select]
observed = observed_all[select]
residual = residual_all[select]
weights = 1.0 / np.maximum(observed, 1.0)
baseline = float(np.dot(weights, residual * residual))
step = float(np.median(np.diff(x)))
calculator = XRDCalculator(wavelength=1.540598, symprec=0)


def profile_from_pattern(ds, intensities, linear_scale, shift, fwhm):
    sticks = np.zeros_like(x)
    for wavelength, ratio in ((1.540598, 1.0), (1.544426, 0.5)):
        sine = wavelength / (2.0 * ds * linear_scale)
        valid = sine < 1.0
        positions = np.degrees(2.0 * np.arcsin(sine[valid])) + shift
        amplitudes = ratio * intensities[valid]
        bins = (positions - x[0]) / step
        inside = (bins >= 0.0) & (bins < len(x) - 1)
        bins = bins[inside]
        amplitudes = amplitudes[inside]
        lower = bins.astype(int)
        fraction = bins - lower
        np.add.at(sticks, lower, amplitudes * (1.0 - fraction))
        np.add.at(sticks, lower + 1, amplitudes * fraction)
    return gaussian_filter1d(sticks, fwhm / (2.35482 * step), mode="constant")


def fit_profile(ds, intensities, values):
    profile = profile_from_pattern(ds, intensities, *values)
    denominator = float(np.dot(weights, profile * profile)) + 1e-30
    amplitude = max(0.0, float(np.dot(weights, residual * profile)) / denominator)
    new_residual = residual - amplitude * profile
    loss = float(np.dot(weights, new_residual * new_residual))
    return loss, amplitude


def pair_minima(structure):
    result = {}
    matrix = structure.distance_matrix
    species = [site.specie.symbol if site.is_ordered else "/".join(sorted(str(e) for e in site.species)) for site in structure]
    for i, first in enumerate(species):
        for j in range(i + 1, len(species)):
            distance = float(matrix[i, j])
            if distance <= 1e-8:
                continue
            key = "-".join(sorted((first, species[j])))
            result[key] = min(result.get(key, np.inf), distance)
    return result


results = []
for name, cod_id, substitutions, family in CANDIDATES:
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(cif_path(cod_id), primitive=False)
        try:
            structure.remove_oxidation_states()
        except Exception:
            pass
        structure.replace_species(substitutions)
        pattern = calculator.get_pattern(structure, two_theta_range=(7.0, 105.0), scaled=False)
        ds = np.asarray(pattern.d_hkls, dtype=float)
        intensities = np.asarray(pattern.y, dtype=float)

        optimum = differential_evolution(
            lambda values: fit_profile(ds, intensities, values)[0],
            [(0.65, 1.35), (-0.30, 0.30), (0.10, 0.55)],
            seed=731,
            popsize=6,
            maxiter=35,
            tol=1e-6,
            polish=True,
        )
        loss, amplitude = fit_profile(ds, intensities, optimum.x)
        linear_scale, shift, fwhm = [float(value) for value in optimum.x]
        scaled = structure.copy()
        scaled.scale_lattice(float(structure.volume) * linear_scale**3)
        minima = pair_minima(scaled)
        minimum_distance = min(minima.values()) if minima else None
        geometry_ok = bool(
            minimum_distance is not None
            and minimum_distance >= 1.35
            and minima.get("O-O", 99.0) >= 1.55
            and minima.get("O-W", 99.0) >= 1.40
            and minima.get("O-Zn", 99.0) >= 1.50
            and 3.0 <= float(scaled.density) <= 12.0
        )
        output = OUT / f"{name}.cif"
        CifWriter(scaled, symprec=None, refine_struct=False).write_file(output)
        result = {
            "candidate": name,
            "family": family,
            "source_cod_id": cod_id,
            "substitutions": substitutions,
            "cif": str(output),
            "residual_weighted_sse_gain_fraction": (baseline - loss) / baseline,
            "positive_amplitude": amplitude,
            "linear_cell_scale": linear_scale,
            "shift_deg": shift,
            "fwhm_deg": fwhm,
            "formula": scaled.composition.formula,
            "density_g_cm3": float(scaled.density),
            "minimum_distance_A": minimum_distance,
            "pair_minima_A": minima,
            "geometry_ok": geometry_ok,
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
    except Exception as exc:
        result = {
            "candidate": name,
            "family": family,
            "source_cod_id": cod_id,
            "status": "unknown",
            "error": f"{type(exc).__name__}: {exc}",
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)

(OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
