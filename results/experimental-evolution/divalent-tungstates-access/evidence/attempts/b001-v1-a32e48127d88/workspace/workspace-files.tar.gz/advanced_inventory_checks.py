#!/usr/bin/env python
"""Controlled replacement trials for the WO3 phase in the advanced model."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/model3_combined_wo3W1_2.gpx")
WORK = Path(".tmp/advanced_wo3_trials")
WORK.mkdir(parents=True, exist_ok=True)
HISTOGRAM = "PWDR pattern.csv"
OLD_PHASE = "WO3_monoclinic_2311041"
CANDIDATES = [
    ("WO3_1563541", "1563541"),
    ("WO3_2311041_fresh", "2311041"),
    ("WO3_2106293", "2106293"),
    ("WO3_2107312", "2107312"),
]
AXES = ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 1, 1])


def clear_flags(project):
    hist = project.histogram(HISTOGRAM)
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
            ],
            "Sample Parameters": [
                "Shift", "Transparency", "SurfRoughA", "SurfRoughB"
            ],
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            }
        )
    return hist


def refine_to(project, path, cycles=16):
    project.set_Controls("cycles", cycles)
    project.save(str(path))
    project.refine()
    return G2.G2Project(gpxfile=str(path))


def collect(project, candidate, stage):
    hist = project.histogram(HISTOGRAM)
    phase = project.phase(candidate)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    active = [
        item
        for item in project.phases()
        if item.data["Histograms"][hist.name].get("Use", True)
    ]
    products = {
        item.name: float(item.data["General"]["Mass"])
        * float(item.data["Histograms"][hist.name]["Scale"][0])
        for item in active
    }
    total = sum(products.values())
    hap = phase.data["Histograms"][hist.name]
    result = {
        "candidate": candidate,
        "stage": stage,
        "rwp_percent": float(hist.get_wR()),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg", ""),
        "cell": phase.get_cell(),
        "weight_fractions": {key: value / total for key, value in products.items()},
        "scale": float(hap["Scale"][0]),
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "vary_list": [
            str(item)
            for item in project.data.get("Covariance", {})
            .get("data", {})
            .get("varyList", [])
        ],
    }
    print(json.dumps(result, sort_keys=True), flush=True)
    return result


G2.SetPrintLevel("warn")
results = []
for name, cod_id in CANDIDATES:
    try:
        start = WORK / f"{name}_start.gpx"
        shutil.copy2(BASE, start)
        project = G2.G2Project(gpxfile=str(start))
        hist = clear_flags(project)
        old = project.phase(OLD_PHASE)
        old_hap = old.data["Histograms"][hist.name]
        old_product = float(old.data["General"]["Mass"]) * float(old_hap["Scale"][0])
        old_hap["Use"] = False
        old_hap["Scale"][1] = False

        phase = project.add_phase(
            str(Path(".tmp/clean_candidates") / f"{cod_id}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Use"] = True
        hap["Scale"] = [old_product / float(phase.data["General"]["Mass"]), True]
        # Apply the same fixed profile starting values used for the selected WO3 phase.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1800.0
        hap["Mustrain"][1][1] = 1800.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

        for active_name in ("ZnWO4_wolframite", "ZnO_wurtzite_9004178"):
            project.phase(active_name).set_HAP_refinements(
                {"Scale": True}, histograms=[hist]
            )
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
        project = refine_to(project, WORK / f"{name}_scale.gpx")
        result = collect(project, name, "scale_background")
        results.append(result)
        if not result["converged"] or result["scale"] <= 1e-8:
            continue

        project.phase(name).set_refinements({"Cell": True})
        project = refine_to(project, WORK / f"{name}_cell.gpx", cycles=24)
        result = collect(project, name, "candidate_cell")
        results.append(result)
        if not result["converged"]:
            continue

        phase = project.phase(name)
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic"}}, histograms=[hist])
        project = refine_to(project, WORK / f"{name}_isostrain.gpx", cycles=20)
        result = collect(project, name, "isotropic_strain")
        results.append(result)
        if not result["converged"]:
            continue

        texture_base = WORK / f"{name}_isostrain.gpx"
        texture_results = []
        for axis in AXES:
            axis_tag = "".join(str(value) for value in axis)
            trial_file = WORK / f"{name}_texture_{axis_tag}.gpx"
            shutil.copy2(texture_base, trial_file)
            trial = G2.G2Project(gpxfile=str(trial_file))
            trial_phase = trial.phase(name)
            trial_hap = trial_phase.data["Histograms"][hist.name]
            trial_hap["Pref.Ori."][0] = "MD"
            trial_hap["Pref.Ori."][1] = 1.0
            trial_hap["Pref.Ori."][3] = list(axis)
            trial_phase.set_HAP_refinements({"Pref.Ori.": True}, histograms=[hist])
            trial = refine_to(trial, trial_file, cycles=20)
            item = collect(trial, name, f"texture_{axis_tag}")
            results.append(item)
            texture_results.append((item["rwp_percent"], trial_file, item))

        viable = [item for item in texture_results if item[2]["converged"]]
        if not viable:
            continue
        _, best_texture, _ = min(viable, key=lambda item: item[0])
        for axis in AXES[:3]:
            axis_tag = "".join(str(value) for value in axis)
            trial_file = WORK / f"{name}_strain_{axis_tag}.gpx"
            shutil.copy2(best_texture, trial_file)
            trial = G2.G2Project(gpxfile=str(trial_file))
            trial_phase = trial.phase(name)
            trial_hap = trial_phase.data["Histograms"][hist.name]
            equatorial = float(trial_hap["Mustrain"][1][0])
            trial_hap["Mustrain"][0] = "uniaxial"
            trial_hap["Mustrain"][1][0] = equatorial
            trial_hap["Mustrain"][1][1] = equatorial
            trial_hap["Mustrain"][3] = list(axis)
            trial_phase.set_HAP_refinements(
                {"Mustrain": {"type": "uniaxial", "refine": "both"}},
                histograms=[hist],
            )
            trial = refine_to(trial, trial_file, cycles=24)
            result = collect(trial, name, f"uniaxial_strain_{axis_tag}")
            results.append(result)
    except Exception as exc:
        result = {
            "candidate": name,
            "stage": "unknown",
            "error": f"{type(exc).__name__}: {exc}",
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)

(WORK / "results.json").write_text(json.dumps(results, indent=2) + "\n")
