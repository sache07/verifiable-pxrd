#!/usr/bin/env python
"""Common-project scale and cell trials for precursor polymorph candidates."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


WORK = Path(".tmp/candidate_trials_clean")
WORK.mkdir(parents=True, exist_ok=True)
BASE_PROJECT = Path(".tmp/stage2.gpx")
CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c05/cif"
)
CANDIDATES = [
    ("ZnO_wurtzite_9004178", "9004178"),
    ("ZnO_rocksalt_1534836", "1534836"),
    ("ZnO_zincblende_1537875", "1537875"),
    ("WO3_hexagonal_1004057", "1004057"),
    ("WO3_monoclinic_1010618", "1010618"),
    ("WO3_tetragonal_1521532", "1521532"),
    ("WO3_tetragonal_1521533", "1521533"),
    ("WO3_monoclinic_1528915", "1528915"),
    ("WO3_monoclinic_1563541", "1563541"),
    ("WO3_monoclinic_2311041", "2311041"),
    ("WO3_triclinic_2106293", "2106293"),
    ("WO3_orthorhombic_2107312", "2107312"),
]


def cif_path(cod_id):
    clean = Path(".tmp/clean_candidates") / f"{cod_id}.cif"
    if clean.exists():
        return clean
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def clear_all_except_scales_and_background(project):
    hist = project.histogram("PWDR pattern.csv")
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
                "Polariz.",
            ],
            "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            }
        )
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    return hist


def summary(project, candidate_name, stage):
    hist = project.histogram("PWDR pattern.csv")
    phase = project.phase(candidate_name)
    masses = []
    scales = []
    for item in project.phases():
        masses.append(float(item.data["General"]["Mass"]))
        scales.append(float(item.data["Histograms"][hist.name]["Scale"][0]))
    products = [mass * scale for mass, scale in zip(masses, scales)]
    total = sum(products)
    index = [item.name for item in project.phases()].index(candidate_name)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    vary_list = project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
    return {
        "candidate": candidate_name,
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "candidate_scale": scales[index],
        "candidate_weight_fraction": products[index] / total if total > 0 else None,
        "cell": phase.get_cell(),
        "all_scales": dict(zip([p.name for p in project.phases()], scales)),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "message": rvals.get("msg", ""),
        "vary_list": [str(item) for item in vary_list],
    }


G2.SetPrintLevel("warn")
results = []
for candidate_name, cod_id in CANDIDATES:
    start = WORK / f"{candidate_name}_start.gpx"
    shutil.copy2(BASE_PROJECT, start)
    try:
        project = G2.G2Project(gpxfile=str(start))
        hist = clear_all_except_scales_and_background(project)
        candidate = project.add_phase(
            str(cif_path(cod_id)),
            phasename=candidate_name,
            histograms=[hist],
            fmthint="CIF",
        )
        # Verify identity and initialize a small positive scale before fitting.
        candidate = project.phase(candidate_name)
        candidate.data["Histograms"][hist.name]["Scale"] = [1.0, True]
        major = project.phase("ZnWO4_wolframite")
        if major.data["Histograms"][hist.name]["Scale"][0] <= 0:
            raise RuntimeError("major-phase scale is not positive")
        project.set_Controls("cycles", 8)
        scale_project = WORK / f"{candidate_name}_scale.gpx"
        project.save(str(scale_project))
        project.refine()
        project = G2.G2Project(gpxfile=str(scale_project))
        candidate = project.phase(candidate_name)
        scale_variable = f"{candidate.id}:{hist.id}:Scale"
        vary_list = [str(item) for item in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])]
        if scale_variable not in vary_list:
            raise RuntimeError("scale/background refinement did not complete")
        scale_result = summary(project, candidate_name, "scale_background")
        results.append(scale_result)
        print(json.dumps(scale_result, sort_keys=True), flush=True)

        if scale_result["candidate_scale"] <= 1e-8 or not scale_result["converged"]:
            continue
        candidate = project.phase(candidate_name)
        candidate.set_refinements({"Cell": True})
        project.set_Controls("cycles", 12)
        cell_project = WORK / f"{candidate_name}_cell.gpx"
        project.save(str(cell_project))
        project.refine()
        project = G2.G2Project(gpxfile=str(cell_project))
        candidate = project.phase(candidate_name)
        vary_list = [str(item) for item in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])]
        if not any(item.startswith(f"{candidate.id}::A") for item in vary_list):
            raise RuntimeError("candidate-cell refinement did not complete")
        cell_result = summary(project, candidate_name, "candidate_cell")
        results.append(cell_result)
        print(json.dumps(cell_result, sort_keys=True), flush=True)
    except Exception as exc:
        result = {
            "candidate": candidate_name,
            "stage": "unknown",
            "error": f"{type(exc).__name__}: {exc}",
        }
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)

(WORK / "results.json").write_text(json.dumps(results, indent=2) + "\n")
