#!/usr/bin/env python
"""Test ZnO polymorphs as a third phase against the accepted ZnWO4+WO3 inventory."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BASE = Path(".tmp/candidate_trials_clean/WO3_monoclinic_2311041_cell.gpx")
WORK = Path(".tmp/third_phase_trials")
WORK.mkdir(parents=True, exist_ok=True)
CANDIDATES = [
    ("ZnO_wurtzite_9004178", "9004178"),
    ("ZnO_rocksalt_1534836", "1534836"),
    ("ZnO_zincblende_1537875", "1537875"),
]


def reset_flags(project):
    hist = project.histogram("PWDR pattern.csv")
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    return hist


def collect(project, name, stage):
    hist = project.histogram("PWDR pattern.csv")
    names = [p.name for p in project.phases()]
    scales = [float(p.data["Histograms"][hist.name]["Scale"][0]) for p in project.phases()]
    masses = [float(p.data["General"]["Mass"]) for p in project.phases()]
    products = [a * b for a, b in zip(scales, masses)]
    total = sum(products)
    phase = project.phase(name)
    rvals = project.data["Covariance"]["data"].get("Rvals", {})
    return {
        "candidate": name,
        "stage": stage,
        "rwp_percent": hist.get_wR(),
        "candidate_scale": scales[names.index(name)],
        "candidate_weight_fraction": products[names.index(name)] / total if total > 0 else None,
        "all_weight_fractions": dict(zip(names, [value / total for value in products])),
        "cell": phase.get_cell(),
        "converged": rvals.get("converged"),
        "max_shift_over_esd": rvals.get("Max shft/sig"),
        "vary_list": [str(item) for item in project.data["Covariance"]["data"].get("varyList", [])],
    }


G2.SetPrintLevel("warn")
results = []
for name, cod_id in CANDIDATES:
    start = WORK / f"{name}_start.gpx"
    shutil.copy2(BASE, start)
    try:
        project = G2.G2Project(gpxfile=str(start))
        hist = reset_flags(project)
        candidate = project.add_phase(
            str(Path(".tmp/clean_candidates") / f"{cod_id}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        candidate = project.phase(name)
        candidate.data["Histograms"][hist.name]["Scale"] = [0.25, True]
        project.set_Controls("cycles", 12)
        scale_file = WORK / f"{name}_scale.gpx"
        project.save(str(scale_file))
        project.refine()
        project = G2.G2Project(gpxfile=str(scale_file))
        result = collect(project, name, "scale_background")
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
        if not result["converged"] or result["candidate_scale"] <= 1e-8:
            continue
        project.phase(name).set_refinements({"Cell": True})
        project.set_Controls("cycles", 20)
        cell_file = WORK / f"{name}_cell.gpx"
        project.save(str(cell_file))
        project.refine()
        project = G2.G2Project(gpxfile=str(cell_file))
        result = collect(project, name, "candidate_cell")
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
    except Exception as exc:
        result = {"candidate": name, "stage": "unknown", "error": f"{type(exc).__name__}: {exc}"}
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)

(WORK / "results.json").write_text(json.dumps(results, indent=2) + "\n")
