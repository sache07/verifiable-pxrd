#!/usr/bin/env python
"""Save the selected GSAS-II project and export phase CIFs and native summary."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path(".tmp/final_candidate_bg14.gpx")
FINAL = Path("final.gpx")
HISTOGRAM = "PWDR pattern.csv"
EXPORTS = {
    "ZnWO4_wolframite": Path("phase_1_ZnWO4.cif"),
    "WO3_monoclinic_2311041": Path("phase_2_WO3.cif"),
    "ZnO_wurtzite_9004178": Path("phase_3_ZnO.cif"),
}


G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(SOURCE))
project.save(str(FINAL))
project = G2.G2Project(gpxfile=str(FINAL))
histogram = project.histogram(HISTOGRAM)

phases = []
products = []
for phase in project.phases():
    if phase.name not in EXPORTS:
        raise RuntimeError(f"Unexpected phase in final project: {phase.name}")
    hap = phase.data["Histograms"][histogram.name]
    if not hap.get("Use", True):
        raise RuntimeError(f"Final phase is disabled: {phase.name}")
    if float(hap["Scale"][0]) <= 0:
        raise RuntimeError(f"Final phase scale is not positive: {phase.name}")
    phase.export_CIF(str(EXPORTS[phase.name]))
    product = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
    products.append(product)
    phases.append(
        {
            "project_name": phase.name,
            "cif": str(EXPORTS[phase.name]),
            "cell": phase.get_cell(),
            "cell_mass_amu": float(phase.data["General"]["Mass"]),
            "scale": float(hap["Scale"][0]),
        }
    )

total = sum(products)
for phase, product in zip(phases, products):
    phase["weight_fraction"] = product / total

rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
summary = {
    "histogram": histogram.name,
    "rwp_percent": float(histogram.get_wR()),
    "rp_percent": rvals.get("Rp"),
    "gof": rvals.get("GOF"),
    "chi_square": rvals.get("chisq"),
    "n_observations": rvals.get("Nobs"),
    "n_variables": rvals.get("Nvars"),
    "converged": rvals.get("converged"),
    "max_shift_over_esd": rvals.get("Max shft/sig"),
    "phases": phases,
}
Path(".tmp/final_native_summary.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
