from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
root = Path('.').resolve()
gpx = G2.G2Project(newgpx=str(root / 'trial_initial.gpx'))
phase = gpx.add_phase(str(root / 'znwo4_start.cif'), phasename='ZnWO4_wolframite', fmthint='CIF')
hist = gpx.add_powder_histogram(str(root / 'observed.xye'), str(root / 'instrument_start.instprm'),
                                phases=[phase], fmthint='xye')
hist.SampleParameters['Type'] = 'Bragg-Brentano'
hist.SampleParameters['Gonio. radius'] = 200.0
hist.set_refinements({'Limits': [10.0, 100.0],
                      'Background': {'type': 'chebyschev-1', 'no. coeffs': 10,
                                     'coeffs': [700.0] + [0.0] * 9, 'refine': True}})
phase.set_HAP_refinements({'Scale': True})
gpx.set_Controls('cycles', 8)

steps = [
    ('scale_background', {}),
    ('zero_cell', {'set': {'hist': {'Instrument Parameters': ['Zero']}, 'phase': {'Cell': True}}}),
    ('profile1', {'set': {'hist': {'Instrument Parameters': ['U', 'W', 'X', 'SH/L']}}}),
]

def apply(step):
    spec = step.get('set', {})
    if 'hist' in spec:
        hist.set_refinements(spec['hist'])
    if 'phase' in spec:
        phase.set_refinements(spec['phase'])

rows = []
for name, spec in steps:
    apply(spec)
    try:
        gpx.refine()
        ok = True
        err = ''
    except Exception as exc:
        ok = False
        err = repr(exc)
    rows.append({'step': name, 'ok': ok, 'error': err, 'wR': hist.get_wR(),
                 'cell': phase.get_cell(),
                 'inst': {k: v[:3] for k, v in hist.data['Instrument Parameters'][0].items()
                          if isinstance(v, list) and k in ['Zero', 'U', 'V', 'W', 'X', 'Y', 'Z', 'SH/L', 'Polariz.']},
                 'scale': phase.data['Histograms'][hist.name]['Scale']})
    print(json.dumps(rows[-1], default=float))
    if not ok:
        break
gpx.save()
np.savetxt('trial_initial_fit.csv', np.column_stack([hist.getdata(k) for k in ['X','Yobs','Ycalc','Residual','Background']]),
           delimiter=',', header='two_theta,observed,calculated,difference,background', comments='')
(root / 'trial_initial_summary.json').write_text(json.dumps(rows, indent=2, default=float) + '\n')
