from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_isotropic_sizes'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_converged_texture/converged.gpx'

project = G2.G2Project(gpxfile=str(BASE))
project.save(str(OUT / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
project.set_Controls('cycles', 12)
for pid in range(2):
    project.set_Controls('parmMin', 0.04, f'{pid}:0:Size;i')
    project.set_Controls('parmMax', 1.5, f'{pid}:0:Size;i')

hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L']})
for phase in phases:
    phase.clear_refinements({'Cell': False})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
    for atom in phase.atoms():
        atom.refinement_flags = ' '

history = []
for pid, label in [(0, '01_product_size'), (1, '02_wo3_size')]:
    phases[pid].set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
    project.set_Frozen()
    project.refine()
    phases[pid].clear_HAP_refinements({'Size': False})
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'label': label,
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'sizes_um': [p.data['Histograms'][hist.name]['Size'][1][0] for p in phases],
        'frozen': project.get_Frozen(),
    }
    history.append(result)
    print(json.dumps(result), flush=True)
    project.save()
    shutil.copy2(project.filename, OUT / f'{label}.gpx')
    np.savetxt(
        OUT / f'{label}.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'history.json').write_text(json.dumps(history, indent=2) + '\n')

project.save(str(OUT / 'sizes.gpx'))
