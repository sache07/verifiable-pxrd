from pathlib import Path
import copy
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_refine'
OUT.mkdir(exist_ok=True)


def plain(v):
    if isinstance(v, dict):
        return {str(k): plain(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [plain(x) for x in v]
    if isinstance(v, np.ndarray):
        return v.tolist()
    if isinstance(v, np.generic):
        return v.item()
    return v


def summary(gpx, hist, phase, label, ok=True, error=''):
    inst = hist.data['Instrument Parameters'][0]
    hap = phase.data['Histograms'][hist.name]
    rec = {
        'label': label,
        'ok': ok,
        'error': error,
        'wR_percent': hist.get_wR(),
        'cell': phase.get_cell(),
        'instrument': {k: v[1] for k, v in inst.items()
                       if isinstance(v, list) and k in ['Zero','U','V','W','X','Y','Z','SH/L','Polariz.']},
        'sample': {k: (v[0] if isinstance(v, list) else v)
                   for k, v in hist.SampleParameters.items()
                   if k in ['Scale','Shift','Transparency','SurfRoughA','SurfRoughB','Gonio. radius']},
        'hap': {k: copy.deepcopy(hap[k]) for k in ['Scale','Size','Mustrain','Pref.Ori.']},
        'atoms': [{'label': a.label, 'element': a.element, 'xyz': list(a.coordinates),
                   'uiso': a.uiso, 'flags': a.refinement_flags} for a in phase.atoms()],
        'vary_list': [str(x) for x in gpx.data.get('Covariance',{}).get('data',{}).get('varyList',[])],
        'frozen': gpx.get_Frozen(),
    }
    print(json.dumps(plain(rec)))
    return plain(rec)


def save_checkpoint(gpx, hist, phase, label, records):
    gpx.save()
    target = OUT / f'{label}.gpx'
    shutil.copy2(gpx.filename, target)
    data = np.column_stack([hist.getdata(k) for k in ['X','Yobs','Ycalc','Residual','Background']])
    np.savetxt(OUT / f'{label}.csv', data, delimiter=',',
               header='two_theta,observed,calculated,difference,background', comments='')
    records.append(summary(gpx, hist, phase, label))
    (OUT / 'history.json').write_text(json.dumps(records, indent=2) + '\n')


def run(gpx, hist, phase, label, records):
    try:
        gpx.set_Frozen()
        gpx.refine()
        save_checkpoint(gpx, hist, phase, label, records)
        return True
    except Exception as exc:
        records.append(summary(gpx, hist, phase, label, False, repr(exc)))
        (OUT / 'history.json').write_text(json.dumps(records, indent=2) + '\n')
        return False


gpx = G2.G2Project(newgpx=str(OUT / 'active.gpx'))
phase = gpx.add_phase(str(ROOT / 'znwo4_start.cif'), phasename='ZnWO4_wolframite', fmthint='CIF')
hist = gpx.add_powder_histogram(str(ROOT / 'observed.xye'), str(ROOT / 'instrument_start.instprm'),
                                phases=[phase], fmthint='xye')
hist.SampleParameters['Type'] = 'Bragg-Brentano'
hist.SampleParameters['Gonio. radius'] = 200.0
hist.SampleParameters['Scale'] = [1.0, False]
hist.SampleParameters['Shift'] = [0.0, False]
hist.SampleParameters['SurfRoughA'] = [0.0, False]
hist.SampleParameters['SurfRoughB'] = [0.0, False]
hist.set_refinements({'Limits': [10.0, 100.0],
                      'Background': {'type': 'chebyschev-1', 'no. coeffs': 12,
                                     'coeffs': [700.0] + [0.0] * 11, 'refine': True}})
phase.data['Histograms'][hist.name]['Scale'] = [80.0, True]
gpx.set_Controls('cycles', 8)
gpx.save()

# Physical bounds. GSAS-II clamps and freezes only a parameter that exits its interval.
bounds = {
    ':0:Zero': (-0.30, 0.30), ':0:Shift': (-900.0, 900.0),
    ':0:U': (0.0, 60.0), ':0:V': (-20.0, 20.0), ':0:W': (1.0, 60.0),
    ':0:X': (0.05, 10.0), ':0:SH/L': (0.003, 0.15), ':0:Polariz.': (0.45, 1.0),
    '0:0:Size;i': (0.02, 3.0), '0:0:Mustrain;i': (0.0, 12000.0),
    '0:0:MD': (0.55, 1.8), ':0:SurfRoughA': (0.0, 0.8), ':0:SurfRoughB': (0.001, 0.8),
}
for var, (lo, hi) in bounds.items():
    gpx.set_Controls('parmMin', lo, var)
    gpx.set_Controls('parmMax', hi, var)

records = []
run(gpx, hist, phase, '01_scale_background', records)

hist.set_refinements({'Instrument Parameters': ['Zero'], 'Sample Parameters': ['Shift']})
phase.set_refinements({'Cell': True})
run(gpx, hist, phase, '02_cell_zero_shift', records)

# Reset to a low physical instrumental contribution so specimen broadening remains positive.
inst = hist.data['Instrument Parameters'][0]
for key, val in [('U', 5.0), ('V', 0.0), ('W', 5.0), ('X', 0.5), ('SH/L', 0.03)]:
    inst[key][1] = val
hap = phase.data['Histograms'][hist.name]
hap['Size'][0] = 'isotropic'; hap['Size'][1][0] = hap['Size'][1][1] = 0.30
hap['Mustrain'][0] = 'isotropic'; hap['Mustrain'][1][0] = hap['Mustrain'][1][1] = 1000.0
hist.set_refinements({'Instrument Parameters': ['W','X','SH/L']})
phase.set_HAP_refinements({'Size': {'type':'isotropic','value':0.30,'refine':True},
                           'Mustrain': {'type':'isotropic','refine':True}})
run(gpx, hist, phase, '03_profile_basic', records)

hist.set_refinements({'Instrument Parameters': ['U']})
run(gpx, hist, phase, '04_profile_u', records)

# Heavy-atom coordinates first; special-position constraints leave only allowed coordinates.
phase.set_refinements({'Atoms': {'W1':'X', 'Zn1':'X'}})
run(gpx, hist, phase, '05_heavy_coordinates', records)

# Oxygen positions are then released from the analogue start.
phase.set_refinements({'Atoms': {'O1':'X', 'O2':'X'}})
run(gpx, hist, phase, '06_all_coordinates', records)

# Heavy-atom isotropic displacement factors affect the high-angle intensities.
phase.set_refinements({'Atoms': {'W1':'XU', 'Zn1':'XU'}})
for i in [0, 1]:
    gpx.set_Controls('parmMin', 0.001, f'0::AUiso:{i}')
    gpx.set_Controls('parmMax', 0.04, f'0::AUiso:{i}')
run(gpx, hist, phase, '07_heavy_uiso', records)

# Save the active endpoint; optional texture/roughness/anisotropy are tested in separate branches.
gpx.save(str(OUT / 'base_refined.gpx'))
