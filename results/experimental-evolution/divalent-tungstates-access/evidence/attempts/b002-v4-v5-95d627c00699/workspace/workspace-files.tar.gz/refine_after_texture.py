from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_coordinates_lowuiso'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'screen_common_uiso/wo3_0.014/result.gpx'


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def record(project, hist, phases, label):
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = plain({
        'label': label,
        'wR_percent': hist.get_wR(),
        'fractions': fractions,
        'texture': [p.data['Histograms'][hist.name]['Pref.Ori.'] for p in phases],
        'atoms': [[{'label': a.label, 'xyz': a.coordinates, 'uiso': a.uiso,
                    'flags': a.refinement_flags} for a in p.atoms()] for p in phases],
        'vary': project.data.get('Covariance', {}).get('data', {}).get('varyList', []),
        'frozen': project.get_Frozen(),
    })
    print(json.dumps(result), flush=True)
    return result


def save(project, hist, phases, label, history):
    project.save()
    shutil.copy2(project.filename, OUT / f'{label}.gpx')
    np.savetxt(
        OUT / f'{label}.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    for i, phase in enumerate(phases):
        phase.export_CIF(str(OUT / f'{label}_phase{i + 1}.cif'))
    history.append(record(project, hist, phases, label))
    (OUT / 'history.json').write_text(json.dumps(history, indent=2) + '\n')


project = G2.G2Project(gpxfile=str(BASE))
project.save(str(OUT / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
product = phases[0]
history = []

# Hold peak positions and widths fixed while the intensity model is tested.
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L']})
for phase in phases:
    phase.clear_refinements({'Cell': False})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False})
    for atom in phase.atoms():
        atom.refinement_flags = ' '
phases[0].data['Histograms'][hist.name]['Pref.Ori.'][2] = True
phases[1].data['Histograms'][hist.name]['Pref.Ori.'][2] = False
project.set_Controls('cycles', 10)

# Despite the dA label in GSAS-II's vary list, these controls are absolute
# fractional-coordinate limits. Center them on the accepted checkpoint.
starting_coordinates = [list(atom.coordinates) for atom in product.atoms()]
for atom_index in [0, 1]:
    for axis_index, axis in enumerate('xyz'):
        variable = f'0::dA{axis}:{atom_index}'
        center = starting_coordinates[atom_index][axis_index]
        project.set_Controls('parmMin', center - 0.015, variable)
        project.set_Controls('parmMax', center + 0.015, variable)
for atom_index in [2, 3]:
    for axis_index, axis in enumerate('xyz'):
        variable = f'0::dA{axis}:{atom_index}'
        center = starting_coordinates[atom_index][axis_index]
        project.set_Controls('parmMin', center - 0.025, variable)
        project.set_Controls('parmMax', center + 0.025, variable)

product.set_refinements({'Atoms': {'W1': 'X', 'Zn1': 'X'}})
project.set_Frozen()
project.refine()
save(project, hist, phases, '01_heavy', history)

for atom in product.atoms():
    atom.refinement_flags = ' '
product.set_refinements({'Atoms': {'O1': 'X', 'O2': 'X'}})
project.set_Frozen()
project.refine()
save(project, hist, phases, '02_oxygen', history)

for atom in product.atoms():
    atom.refinement_flags = ' '
project.save(str(OUT / 'base_coordinates.gpx'))
