from pathlib import Path
import sys
import numpy as np
from pymatgen.core import Structure

for arg in sys.argv[1:]:
    p=Path(arg);s=Structure.from_file(p,primitive=False)
    d=s.distance_matrix
    pairs={}
    for i in range(len(s)):
        for j in range(i+1,len(s)):
            key='-'.join(sorted([s[i].specie.symbol,s[j].specie.symbol]))
            pairs.setdefault(key,[]).append(float(d[i,j]))
    print(p, s.composition.reduced_formula, s.get_space_group_info(symprec=1e-3))
    for k,v in sorted(pairs.items()): print(' ',k,'min',min(v),'smallest',sorted(v)[:12])
