from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_wo3_coordinates'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'screen_common_uiso_profile/wo3_0.020/result.gpx'

project = G2.G2Project(gpxfile=str(BASE))
project.save(str(OUT / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
wo3 = phases[1]
project.set_Controls('cycles', 15)

hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.'],
                        'Sample Parameters': ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']})
for phase in phases:
    phase.clear_refinements({'Cell': False})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
    for atom in phase.atoms():
        atom.refinement_flags = ' '

starting = [list(atom.coordinates) for atom in wo3.atoms()]
heavy_indices = [i for i, atom in enumerate(wo3.atoms()) if atom.element == 'W']
oxygen_indices = [i for i, atom in enumerate(wo3.atoms()) if atom.element == 'O']
for atom_index in heavy_indices:
    for axis_index, axis in enumerate('xyz'):
        variable = f'1::dA{axis}:{atom_index}'
        center = starting[atom_index][axis_index]
        project.set_Controls('parmMin', center - 0.008, variable)
        project.set_Controls('parmMax', center + 0.008, variable)
for atom_index in oxygen_indices:
    for axis_index, axis in enumerate('xyz'):
        variable = f'1::dA{axis}:{atom_index}'
        center = starting[atom_index][axis_index]
        project.set_Controls('parmMin', center - 0.012, variable)
        project.set_Controls('parmMax', center + 0.012, variable)

history = []


def save(label):
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'label': label,
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'wo3_atoms': [{'label': a.label, 'xyz': list(a.coordinates)} for a in wo3.atoms()],
        'frozen': project.get_Frozen(),
    }
    history.append(result)
    print(json.dumps(result), flush=True)
    project.save()
    shutil.copy2(project.filename, OUT / f'{label}.gpx')
    for phase_index, phase in enumerate(phases):
        phase.export_CIF(str(OUT / f'{label}_phase{phase_index + 1}.cif'))
    np.savetxt(
        OUT / f'{label}.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'history.json').write_text(json.dumps(history, indent=2) + '\n')


wo3.set_refinements({'Atoms': {wo3.atoms()[i].label: 'X' for i in heavy_indices}})
project.set_Frozen()
project.refine()
save('01_tungsten')

for atom in wo3.atoms():
    atom.refinement_flags = ' '
wo3.set_refinements({'Atoms': {wo3.atoms()[i].label: 'X' for i in oxygen_indices}})
project.set_Frozen()
project.refine()
save('02_oxygen')

for atom in wo3.atoms():
    atom.refinement_flags = ' '
project.save(str(OUT / 'coordinates.gpx'))
