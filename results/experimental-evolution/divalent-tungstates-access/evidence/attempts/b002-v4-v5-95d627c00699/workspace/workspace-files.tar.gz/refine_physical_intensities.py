from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_physical_final'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_reparameterized_cells/cells.gpx'

project = G2.G2Project(gpxfile=str(BASE))
project.save(str(OUT / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.'],
                        'Sample Parameters': ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']})
hist.data['Background'][0][1] = True
for phase in phases:
    phase.clear_refinements({'Cell': False})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
    phase.data['Histograms'][hist.name]['Scale'][1] = True
    for atom in phase.atoms():
        atom.refinement_flags = ' '
project.set_Controls('cycles', 12)
history = []


def save(label):
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {'label': label, 'wR_percent': hist.get_wR(), 'fractions': fractions.tolist(),
              'textures': [p.data['Histograms'][hist.name]['Pref.Ori.'][1:4] for p in phases],
              'frozen': project.get_Frozen()}
    history.append(result)
    print(json.dumps(result), flush=True)
    project.save()
    shutil.copy2(project.filename, OUT / f'{label}.gpx')
    np.savetxt(OUT / f'{label}.csv',
               np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
               delimiter=',', header='two_theta,observed,calculated,difference,background', comments='')
    (OUT / 'history.json').write_text(json.dumps(history, indent=2) + '\n')


project.set_Frozen()
project.refine()
save('01_scales_background')

for phase_index, phase in enumerate(phases):
    phase.data['Histograms'][hist.name]['Pref.Ori.'][2] = True
    project.set_Controls('parmMin', 0.70, f'{phase_index}:0:MD')
    project.set_Controls('parmMax', 1.40, f'{phase_index}:0:MD')
project.set_Frozen()
project.refine()
save('02_textures')

project.set_Frozen()
project.refine()
save('03_textures_repeat')

for phase in phases:
    phase.data['Histograms'][hist.name]['Pref.Ori.'][2] = False
project.save(str(OUT / 'intensities.gpx'))
