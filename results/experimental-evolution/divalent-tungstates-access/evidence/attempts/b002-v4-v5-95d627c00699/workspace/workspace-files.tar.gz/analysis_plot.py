import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import minimum_filter1d, gaussian_filter1d
from scipy.signal import find_peaks, peak_widths

x, y = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1).T
base = gaussian_filter1d(minimum_filter1d(y, size=401), 120)
signal = y - base
smooth = gaussian_filter1d(signal, 2.0)
peaks, props = find_peaks(smooth, prominence=120, distance=8)
order = peaks[np.argsort(props['prominences'])[::-1]]
print('range', x[0], x[-1], 'step', np.median(np.diff(x)), 'y', y.min(), y.max())
print('Top peaks:')
for i in order[:100]:
    pidx = np.where(peaks == i)[0][0]
    print(f'{x[i]:10.5f} {y[i]:10.1f} net={signal[i]:10.1f} prom={props["prominences"][pidx]:10.1f}')

fig, ax = plt.subplots(3, 1, figsize=(15, 10), sharey=False)
for a, lo, hi in zip(ax, [9.9, 39.9, 69.9], [40.2, 70.2, 100.1]):
    m = (x >= lo) & (x <= hi)
    a.plot(x[m], y[m], lw=.6, color='black')
    a.plot(x[m], base[m], lw=1, color='tab:orange')
    a.set_xlim(lo, hi)
    a.set_ylabel('counts')
ax[-1].set_xlabel(r'$2\theta$ (deg)')
fig.tight_layout()
fig.savefig('pattern_overview.png', dpi=180)
