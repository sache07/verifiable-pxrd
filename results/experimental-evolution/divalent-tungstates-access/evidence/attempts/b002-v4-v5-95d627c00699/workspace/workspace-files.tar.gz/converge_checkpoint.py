from pathlib import Path
import json
import shutil
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
source = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(exist_ok=True)
project = G2.G2Project(gpxfile=str(source))
project.save(str(out / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
history = []
project.set_Controls('cycles', 12)

for cycle in range(1, 4):
    project.set_Frozen()
    project.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'cycle': cycle,
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'md': [p.data['Histograms'][hist.name]['Pref.Ori.'][1:4] for p in phases],
        'frozen': project.get_Frozen(),
    }
    history.append(result)
    print(json.dumps(result), flush=True)
    project.save()
    shutil.copy2(project.filename, out / f'{cycle:02d}.gpx')
    np.savetxt(
        out / f'{cycle:02d}.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (out / 'history.json').write_text(json.dumps(history, indent=2) + '\n')

project.save(str(out / 'converged.gpx'))
