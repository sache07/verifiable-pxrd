from pathlib import Path
import sys
import numpy as np
from pymatgen.core import Structure

for arg in sys.argv[1:]:
    p = Path(arg)
    s = Structure.from_file(p, primitive=False)
    print('\n', p, s.composition, s.get_space_group_info(symprec=1e-3), s.lattice)
    for i, site in enumerate(s):
        # Distances to atoms in the represented cell; detailed periodic bonds are checked below.
        dmat = s.distance_matrix[i]
        near = sorted([(float(d), j, str(s[j].specie)) for j, d in enumerate(dmat) if j != i and d < 3.2])
        print(i, str(site.specie), np.round(site.frac_coords,6).tolist(), near[:10])
    d = s.distance_matrix.copy()
    d[d < 1e-8] = np.inf
    print('minimum pair distance in represented cell', d.min())
