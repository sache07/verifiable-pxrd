from pathlib import Path
import json
import shutil
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT=Path('.').resolve()
RID=sys.argv[1] if len(sys.argv)>1 else '1528915'
OUT=ROOT/('work_two_phase' if RID=='1528915' else f'work_two_phase_{RID}');OUT.mkdir(exist_ok=True)
SRC=ROOT/f'screen_wo3/{RID}/screened.gpx'

def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v

def record(g,h,ps,label):
    masses=np.array([p.data['General']['Mass'] for p in ps]);scales=np.array([p.data['Histograms'][h.name]['Scale'][0] for p in ps]);fr=masses*scales/np.dot(masses,scales)
    r={'label':label,'wR_percent':h.get_wR(),'fractions':fr.tolist(),'scales':scales.tolist(),
       'cells':[p.get_cell() for p in ps],
       'instrument':{k:h.data['Instrument Parameters'][0][k][1] for k in ['Zero','U','V','W','X','SH/L','Polariz.']},
       'profiles':[{k:p.data['Histograms'][h.name][k] for k in ['Size','Mustrain','Pref.Ori.']} for p in ps],
       'atoms':[[{'label':a.label,'element':a.element,'xyz':list(a.coordinates),'uiso':a.uiso,'flags':a.refinement_flags} for a in p.atoms()] for p in ps],
       'frozen':g.get_Frozen(), 'vary':[str(x) for x in g.data.get('Covariance',{}).get('data',{}).get('varyList',[])]}
    return plain(r)

history=[]
def checkpoint(g,h,ps,label):
    g.save();shutil.copy2(g.filename,OUT/f'{label}.gpx')
    np.savetxt(OUT/f'{label}.csv',np.column_stack([h.getdata(k) for k in ['X','Yobs','Ycalc','Residual','Background']]),delimiter=',',header='two_theta,observed,calculated,difference,background',comments='')
    r=record(g,h,ps,label);history.append(r);print(json.dumps(r),flush=True);(OUT/'history.json').write_text(json.dumps(history,indent=2)+'\n')

g=G2.G2Project(gpxfile=str(SRC));g.save(str(OUT/'active.gpx'))
h=g.histogram(0);ps=g.phases();prod,wo3=ps
g.set_Controls('cycles',10);g.set_Frozen()
g.set_Controls('parmMax',500.,'0:0:Scale');g.set_Controls('parmMax',100.,'1:0:Scale')
# Keep all profile terms positive; broadened phases can absorb the profile decomposition.
for var,lo,hi in [(':0:U',0.,100.),(':0:W',.5,100.),(':0:X',.02,20.),(':0:SH/L',.002,.2),
                  ('0:0:Size;i',.015,5.),('1:0:Size;i',.015,5.),('0:0:Mustrain;i',0.,15000.),('1:0:Mustrain;i',0.,15000.)]:
    g.set_Controls('parmMin',lo,var);g.set_Controls('parmMax',hi,var)

g.refine();checkpoint(g,h,ps,'01_unbound_scales')

# Product heavy atoms (special-position y coordinates only).
prod.set_refinements({'Atoms':{'W1':'X','Zn1':'X'}})
g.set_Frozen();g.refine();checkpoint(g,h,ps,'02_product_heavy')

# Product oxygen coordinates.
prod.set_refinements({'Atoms':{'O1':'X','O2':'X'}})
g.set_Frozen();g.refine();checkpoint(g,h,ps,'03_product_oxygen')

# Two independent W sites in monoclinic WO3; oxygen remains at the reference checkpoint here.
wo3.set_refinements({'Atoms':{'W1':'X','W2':'X'}})
g.set_Frozen();g.refine();checkpoint(g,h,ps,'04_wo3_heavy')

g.save(str(OUT/'coordinates_refined.gpx'))
