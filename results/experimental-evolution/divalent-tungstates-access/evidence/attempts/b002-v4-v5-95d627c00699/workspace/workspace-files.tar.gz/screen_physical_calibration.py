from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_physical_calibration'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_wo3_coordinates/01_tungsten.gpx'
starts = [(0.25, -800.0), (0.20, -700.0), (0.15, -800.0), (0.25, -500.0)]
results = []

for index, (zero, shift) in enumerate(starts, 1):
    folder = OUT / f'start_{index}'
    folder.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(folder / 'active.gpx'))
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.'],
                            'Sample Parameters': ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']})
    for phase in phases:
        phase.clear_refinements({'Cell': False})
        phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
        for atom in phase.atoms():
            atom.refinement_flags = ' '
    hist.data['Instrument Parameters'][0]['Zero'][1] = zero
    hist.SampleParameters['Shift'] = [shift, True]
    hist.set_refinements({'Instrument Parameters': ['Zero']})
    for phase in phases:
        phase.set_refinements({'Cell': True})
    project.set_Controls('parmMin', -0.25, ':0:Zero')
    project.set_Controls('parmMax', 0.25, ':0:Zero')
    project.set_Controls('parmMin', -800.0, ':0:Shift')
    project.set_Controls('parmMax', 800.0, ':0:Shift')
    project.set_Controls('cycles', 15)
    project.set_Frozen()
    project.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'start': [zero, shift],
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'zero_deg': hist.data['Instrument Parameters'][0]['Zero'][1],
        'shift_um': hist.SampleParameters['Shift'][0],
        'cells': [p.get_cell() for p in phases],
        'frozen': project.get_Frozen(),
    }
    results.append(result)
    print(json.dumps(result), flush=True)
    project.save(str(folder / 'result.gpx'))
    np.savetxt(
        folder / 'fit.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
