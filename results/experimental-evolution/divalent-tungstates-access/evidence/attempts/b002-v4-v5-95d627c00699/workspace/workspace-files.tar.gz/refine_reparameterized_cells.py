from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_reparameterized_cells'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'screen_calibration_reparameterization/01_z0.25_s-320.gpx'

project = G2.G2Project(gpxfile=str(BASE))
project.save(str(OUT / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.'],
                        'Sample Parameters': ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']})
hist.data['Instrument Parameters'][0]['Zero'][1] = 0.25
hist.SampleParameters['Shift'] = [-320.0, False]
for phase in phases:
    phase.clear_refinements({'Cell': False})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
    for atom in phase.atoms():
        atom.refinement_flags = ' '
project.set_Controls('cycles', 8)
history = []


def run(phase_index, label):
    phases[phase_index].set_refinements({'Cell': True})
    project.set_Frozen()
    project.refine()
    phases[phase_index].clear_refinements({'Cell': False})
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {'label': label, 'wR_percent': hist.get_wR(),
              'fractions': fractions.tolist(), 'cells': [p.get_cell() for p in phases],
              'frozen': project.get_Frozen()}
    history.append(result)
    print(json.dumps(result), flush=True)
    project.save()
    shutil.copy2(project.filename, OUT / f'{label}.gpx')
    np.savetxt(OUT / f'{label}.csv',
               np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
               delimiter=',', header='two_theta,observed,calculated,difference,background', comments='')
    (OUT / 'history.json').write_text(json.dumps(history, indent=2) + '\n')


run(0, '01_product_cell')
run(1, '02_wo3_cell')
run(0, '03_product_cell_repeat')
run(1, '04_wo3_cell_repeat')
project.save(str(OUT / 'cells.gpx'))
