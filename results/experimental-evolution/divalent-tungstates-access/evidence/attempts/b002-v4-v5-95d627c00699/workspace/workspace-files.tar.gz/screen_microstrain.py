from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_microstrain'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_isotropic_sizes/sizes.gpx'
models = [('isotropic', [0, 0, 1]), ('uniaxial_001', [0, 0, 1]),
          ('uniaxial_100', [1, 0, 0]), ('uniaxial_010', [0, 1, 0])]
results = []

for phase_index in [0, 1]:
    for model, axis in models:
        tag = f'p{phase_index}_{model}'
        folder = OUT / tag
        folder.mkdir(exist_ok=True)
        project = G2.G2Project(gpxfile=str(BASE))
        project.save(str(folder / 'active.gpx'))
        hist = project.histogram(0)
        phases = project.phases()
        hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L']})
        for phase in phases:
            phase.clear_refinements({'Cell': False})
            phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
            for atom in phase.atoms():
                atom.refinement_flags = ' '
        hap = phases[phase_index].data['Histograms'][hist.name]
        if model == 'isotropic':
            hap['Mustrain'][0] = 'isotropic'
            hap['Mustrain'][1][0] = 500.0
            hap['Mustrain'][1][1] = 500.0
            hap['Mustrain'][2] = [True, False, False]
        else:
            hap['Mustrain'][0] = 'uniaxial'
            hap['Mustrain'][1][0] = 500.0
            hap['Mustrain'][1][1] = 1000.0
            hap['Mustrain'][2] = [True, True, False]
            hap['Mustrain'][3] = axis
        hap['Size'][0] = 'isotropic'
        hap['Size'][2] = [True, False, False]
        project.set_Controls('parmMin', 0.0, f'{phase_index}:0:Mustrain;i')
        project.set_Controls('parmMax', 8000.0, f'{phase_index}:0:Mustrain;i')
        project.set_Controls('parmMin', 0.0, f'{phase_index}:0:Mustrain;a')
        project.set_Controls('parmMax', 8000.0, f'{phase_index}:0:Mustrain;a')
        project.set_Controls('parmMin', 0.04, f'{phase_index}:0:Size;i')
        project.set_Controls('parmMax', 1.5, f'{phase_index}:0:Size;i')
        project.set_Controls('cycles', 12)
        project.set_Frozen()
        project.refine()
        masses = np.array([p.data['General']['Mass'] for p in phases])
        scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
        fractions = masses * scales / np.dot(masses, scales)
        result = {
            'tag': tag,
            'phase': phases[phase_index].name,
            'model': model,
            'axis': axis,
            'wR_percent': hist.get_wR(),
            'fractions': fractions.tolist(),
            'size_um': hap['Size'][1][0],
            'microstrain_perpendicular_ppm': hap['Mustrain'][1][0],
            'microstrain_axial_ppm': hap['Mustrain'][1][1],
            'frozen': project.get_Frozen(),
        }
        results.append(result)
        print(json.dumps(result), flush=True)
        project.save(str(folder / 'result.gpx'))
        np.savetxt(
            folder / 'fit.csv',
            np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
            delimiter=',',
            header='two_theta,observed,calculated,difference,background',
            comments='',
        )
        (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
