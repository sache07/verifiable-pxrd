from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_common_uiso_profile'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_global_profile_converged/profile_converged.gpx'
product_grid = [0.003, 0.004, 0.005, 0.007, 0.010]
wo3_grid = [0.006, 0.010, 0.012, 0.014, 0.016, 0.018, 0.020]


def run(base, phase_index, value, tag):
    folder = OUT / tag
    folder.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(base))
    project.save(str(folder / 'active.gpx'))
    hist = project.histogram(0)
    phases = project.phases()
    for atom in phases[phase_index].atoms():
        atom.uiso = value
    hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L']})
    for phase in phases:
        phase.clear_refinements({'Cell': False})
        phase.clear_HAP_refinements({'Size': False, 'Mustrain': False})
        for atom in phase.atoms():
            atom.refinement_flags = ' '
    phases[0].data['Histograms'][hist.name]['Pref.Ori.'][2] = True
    phases[1].data['Histograms'][hist.name]['Pref.Ori.'][2] = False
    project.set_Controls('cycles', 8)
    project.set_Frozen()
    project.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'tag': tag,
        'phase_index': phase_index,
        'uiso': value,
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'md_ratio': phases[0].data['Histograms'][hist.name]['Pref.Ori.'][1],
        'frozen': project.get_Frozen(),
    }
    print(json.dumps(result), flush=True)
    project.save(str(folder / 'result.gpx'))
    np.savetxt(
        folder / 'fit.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    return result, folder / 'result.gpx'


results = []
product_runs = []
for value in product_grid:
    result, path = run(BASE, 0, value, f'product_{value:.3f}')
    results.append(result)
    product_runs.append((result['wR_percent'], path))
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')

best_product = min(product_runs)[1]
for value in wo3_grid:
    result, _ = run(best_product, 1, value, f'wo3_{value:.3f}')
    results.append(result)
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
