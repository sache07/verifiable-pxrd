from pathlib import Path
import json
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT=Path('.').resolve(); OUT=ROOT/'screen_wo3'; OUT.mkdir(exist_ok=True)
CIFROOT=Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif')
IDS=sys.argv[1:] or ['1010618','1528915','2106293','2107312','1563541','2311041']

def cod(r): return CIFROOT/r[0]/r[1:3]/r[3:5]/f'{r}.cif'
def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v
def fit(g): g.set_Frozen(); g.refine()

results=[]
for rid in IDS:
    d=OUT/rid; d.mkdir(exist_ok=True)
    try:
        g=G2.G2Project(newgpx=str(d/'active.gpx'))
        p0=g.add_phase(str(ROOT/'znwo4_start.cif'),phasename='ZnWO4_wolframite',fmthint='CIF')
        p1=g.add_phase(str(cod(rid)),phasename=f'WO3_{rid}',fmthint='CIF')
        ps=[p0,p1]
        # Several old COD WO3 files omit displacement parameters (imported as exact zero),
        # which causes numerical underflow in GSAS-II. Use the specimen's neutral start.
        cia=p1.data['General']['AtomPtrs'][3]
        for atom in p1.data['Atoms']:
            atom[cia]='I'; atom[cia+1]=0.01
            for j in range(cia+2,cia+8): atom[j]=0.0
        # Avoid a singular monoclinic metric derivative for a historical beta=90.000 entry.
        if p1.data['General']['SGData']['SGSys']=='monoclinic' and abs(p1.data['General']['Cell'][5]-90)<1e-8:
            p1.data['General']['Cell'][5]=90.1
        h=g.add_powder_histogram(str(ROOT/'observed.xye'),str(ROOT/'instrument_start.instprm'),phases=ps,fmthint='xye')
        h.SampleParameters['Type']='Bragg-Brentano';h.SampleParameters['Gonio. radius']=200.;h.SampleParameters['Scale']=[1.,False]
        h.set_refinements({'Limits':[10.,100.], 'Background':{'type':'chebyschev-1','no. coeffs':12,'coeffs':[700.]+[0.]*11,'refine':True}})
        p0.data['Histograms'][h.name]['Scale']=[15.,True];p1.data['Histograms'][h.name]['Scale']=[.5,True]
        g.set_Controls('cycles',8);g.save()
        for var,lo,hi in [(':0:Zero',-.8,.8),(':0:U',0,100),(':0:W',.5,100),(':0:X',.02,20),(':0:SH/L',.002,.2),
                          ('0:0:Scale',1e-6,100),('1:0:Scale',1e-6,100)]:
            g.set_Controls('parmMin',lo,var);g.set_Controls('parmMax',hi,var)
        for pid in range(2):
            for term,lo,hi in [('Size;i',.015,5.),('Mustrain;i',0.,15000.)]:
                g.set_Controls('parmMin',lo,f'{pid}:0:{term}');g.set_Controls('parmMax',hi,f'{pid}:0:{term}')
        fit(g); ck=[['scale_bg',h.get_wR()]]
        h.set_refinements({'Instrument Parameters':['Zero']})
        p0.set_refinements({'Cell':True});p1.set_refinements({'Cell':True})
        fit(g);ck.append(['cells_zero',h.get_wR()])
        inst=h.data['Instrument Parameters'][0]
        for k,v in [('U',10.),('W',10.),('X',1.),('SH/L',.03)]:inst[k][1]=v
        h.set_refinements({'Instrument Parameters':['U','W','X','SH/L']})
        fit(g);ck.append(['instrument',h.get_wR()])
        for p in ps:
            p.data['Histograms'][h.name]['Size'][1][0]=.3;p.data['Histograms'][h.name]['Mustrain'][1][0]=1000.
            p.set_HAP_refinements({'Size':{'type':'isotropic','value':.3,'refine':True},'Mustrain':{'type':'isotropic','refine':True}})
        fit(g);ck.append(['phase_profiles',h.get_wR()])
        masses=np.array([p.data['General']['Mass'] for p in ps]);scales=np.array([p.data['Histograms'][h.name]['Scale'][0] for p in ps]);fr=masses*scales/np.dot(masses,scales)
        rec={'wo3_id':rid,'ok':h.get_wR() is not None and h.get_wR()<99,'checkpoints':ck,'wR_percent':h.get_wR(),
             'cells':[p.get_cell() for p in ps],'scales':scales.tolist(),'masses':masses.tolist(),'fractions':fr.tolist(),
             'instrument':{k:inst[k][1] for k in ['Zero','U','V','W','X','SH/L']},
             'profiles':[{k:p.data['Histograms'][h.name][k] for k in ['Size','Mustrain']} for p in ps], 'frozen':g.get_Frozen()}
        g.save(str(d/'screened.gpx'))
        np.savetxt(d/'fit.csv',np.column_stack([h.getdata(k) for k in ['X','Yobs','Ycalc','Residual','Background']]),delimiter=',',header='two_theta,observed,calculated,difference,background',comments='')
    except Exception as e: rec={'wo3_id':rid,'ok':False,'error':repr(e)}
    rec=plain(rec);results.append(rec);print(json.dumps(rec),flush=True);(OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
