from pathlib import Path
import sys
from GSASII import GSASIIscriptable as G2

src = Path(sys.argv[1])
out = Path(sys.argv[2])
p = G2.G2Project(gpxfile=str(src))
for i, ph in enumerate(p.phases()):
    ph.export_CIF(str(out if len(p.phases()) == 1 else out.with_stem(out.stem + f'_{i}')))
