import numpy as np

x, y = np.loadtxt('inputs/pattern.csv', delimiter=',', skiprows=1).T
sigma = np.sqrt(np.maximum(y, 1.0))
np.savetxt('observed.xye', np.column_stack([x, y, sigma]), fmt='%.8f %.8f %.8f')
