from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_coordinate_starts'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'screen_texture/p0_111/result.gpx'

standard = {
    'W1': [0.0, 0.1850, 0.25],
    'Zn1': [0.5, 0.67338, 0.25],
    'O1': [0.2179, -0.1072, 0.0646],
    'O2': [0.2551, 0.3772, 0.1021],
}

results = []
for tag, blend in [('current', 0.0), ('half_standard', 0.5), ('standard', 1.0)]:
    folder = OUT / tag
    folder.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(folder / 'active.gpx'))
    hist = project.histogram(0)
    phases = project.phases()
    product = phases[0]
    for atom in product.atoms():
        atom.coordinates = [
            (1.0 - blend) * old + blend * new
            for old, new in zip(atom.coordinates, standard[atom.label])
        ]
        atom.refinement_flags = ' '
    hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L']})
    for phase in phases:
        phase.clear_refinements({'Cell': False})
        phase.clear_HAP_refinements({'Size': False, 'Mustrain': False})
        for atom in phase.atoms():
            atom.refinement_flags = ' '
    phases[0].data['Histograms'][hist.name]['Pref.Ori.'][2] = True
    phases[1].data['Histograms'][hist.name]['Pref.Ori.'][2] = False
    project.set_Controls('cycles', 10)
    project.set_Frozen()
    project.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'tag': tag,
        'blend': blend,
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'md_ratio': phases[0].data['Histograms'][hist.name]['Pref.Ori.'][1],
        'coordinates': {a.label: list(a.coordinates) for a in product.atoms()},
        'frozen': project.get_Frozen(),
    }
    results.append(result)
    print(json.dumps(result), flush=True)
    project.save(str(folder / 'result.gpx'))
    for i, phase in enumerate(phases):
        phase.export_CIF(str(folder / f'phase{i + 1}.cif'))
    np.savetxt(
        folder / 'fit.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
