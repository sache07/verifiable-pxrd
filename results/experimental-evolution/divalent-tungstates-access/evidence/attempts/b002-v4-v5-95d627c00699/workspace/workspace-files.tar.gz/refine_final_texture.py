from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_final_texture'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_wo3_coordinates/01_tungsten.gpx'

project = G2.G2Project(gpxfile=str(BASE))
project.save(str(OUT / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.'],
                        'Sample Parameters': ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']})
for phase_index, phase in enumerate(phases):
    phase.clear_refinements({'Cell': False})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
    phase.data['Histograms'][hist.name]['Pref.Ori.'][2] = True
    for atom in phase.atoms():
        atom.refinement_flags = ' '
    project.set_Controls('parmMin', 0.70, f'{phase_index}:0:MD')
    project.set_Controls('parmMax', 1.40, f'{phase_index}:0:MD')
project.set_Controls('cycles', 15)

project.set_Frozen()
project.refine()
masses = np.array([p.data['General']['Mass'] for p in phases])
scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
fractions = masses * scales / np.dot(masses, scales)
result = {
    'wR_percent': hist.get_wR(),
    'fractions': fractions.tolist(),
    'textures': [p.data['Histograms'][hist.name]['Pref.Ori.'][1:4] for p in phases],
    'frozen': project.get_Frozen(),
}
print(json.dumps(result), flush=True)
project.save()
shutil.copy2(project.filename, OUT / 'texture.gpx')
np.savetxt(
    OUT / 'texture.csv',
    np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
    delimiter=',',
    header='two_theta,observed,calculated,difference,background',
    comments='',
)
(OUT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
