from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_surface_roughness'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'screen_common_uiso_profile/wo3_0.020/result.gpx'
starts = [(0.10, 0.05), (0.20, 0.10), (0.40, 0.05), (0.40, 0.30)]
results = []

for index, (start_a, start_b) in enumerate(starts, 1):
    folder = OUT / f'start_{index}'
    folder.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(folder / 'active.gpx'))
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.'],
                            'Sample Parameters': ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']})
    for phase in phases:
        phase.clear_refinements({'Cell': False})
        phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
        for atom in phase.atoms():
            atom.refinement_flags = ' '
    hist.SampleParameters['SurfRoughA'] = [start_a, True]
    hist.SampleParameters['SurfRoughB'] = [start_b, True]
    project.set_Controls('parmMin', 0.05, ':0:SurfRoughA')
    project.set_Controls('parmMax', 0.60, ':0:SurfRoughA')
    project.set_Controls('parmMin', 0.02, ':0:SurfRoughB')
    project.set_Controls('parmMax', 0.50, ':0:SurfRoughB')
    project.set_Controls('cycles', 15)
    project.set_Frozen()
    project.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'start': [start_a, start_b],
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'SurfRoughA': hist.SampleParameters['SurfRoughA'][0],
        'SurfRoughB': hist.SampleParameters['SurfRoughB'][0],
        'frozen': project.get_Frozen(),
    }
    results.append(result)
    print(json.dumps(result), flush=True)
    project.save(str(folder / 'result.gpx'))
    np.savetxt(
        folder / 'fit.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
