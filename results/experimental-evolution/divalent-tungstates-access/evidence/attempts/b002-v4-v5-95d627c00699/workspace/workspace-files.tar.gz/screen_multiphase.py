from pathlib import Path
import json
import shutil
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_multiphase'
OUT.mkdir(exist_ok=True)
CIFROOT = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif')
WO3_IDS = sys.argv[1:] or ['1010618','1528915','2106293','2107312','1563541','2311041']


def cod_path(rid):
    return CIFROOT / rid[0] / rid[1:3] / rid[3:5] / f'{rid}.cif'


def plain(v):
    if isinstance(v, dict): return {str(k): plain(x) for k,x in v.items()}
    if isinstance(v, (list, tuple)): return [plain(x) for x in v]
    if isinstance(v, np.ndarray): return v.tolist()
    if isinstance(v, np.generic): return v.item()
    return v


def refine(gpx):
    gpx.set_Frozen()
    gpx.refine()


all_results = []
for rid in WO3_IDS:
    folder = OUT / rid
    folder.mkdir(exist_ok=True)
    try:
        gpx = G2.G2Project(newgpx=str(folder / 'active.gpx'))
        p_prod = gpx.add_phase(str(ROOT/'znwo4_start.cif'), phasename='ZnWO4_wolframite', fmthint='CIF')
        p_zno = gpx.add_phase(str(cod_path('9004178')), phasename='ZnO_wurtzite', fmthint='CIF')
        p_wo3 = gpx.add_phase(str(cod_path(rid)), phasename=f'WO3_{rid}', fmthint='CIF')
        phases = [p_prod,p_zno,p_wo3]
        hist = gpx.add_powder_histogram(str(ROOT/'observed.xye'), str(ROOT/'instrument_start.instprm'),
                                        phases=phases, fmthint='xye')
        hist.SampleParameters['Type'] = 'Bragg-Brentano'
        hist.SampleParameters['Gonio. radius'] = 200.0
        hist.SampleParameters['Scale'] = [1.0,False]
        hist.SampleParameters['Shift'] = [0.0,False]
        hist.set_refinements({'Limits':[10.0,100.0],
                              'Background':{'type':'chebyschev-1','no. coeffs':12,
                                            'coeffs':[700.0]+[0.0]*11,'refine':True}})
        for p,scale in zip(phases,[70.0,50.0,10.0]):
            p.data['Histograms'][hist.name]['Scale']=[scale,True]
        gpx.set_Controls('cycles',6)
        gpx.save()
        for var,lo,hi in [(':0:Zero',-0.8,0.8),(':0:U',0,100),(':0:W',0.5,100),
                          (':0:X',0.02,20),(':0:SH/L',0.002,0.2)]:
            gpx.set_Controls('parmMin',lo,var); gpx.set_Controls('parmMax',hi,var)
        for pid in range(3):
            for term,lo,hi in [('Size;i',0.015,5.0),('Mustrain;i',0,15000)]:
                gpx.set_Controls('parmMin',lo,f'{pid}:0:{term}')
                gpx.set_Controls('parmMax',hi,f'{pid}:0:{term}')

        refine(gpx)
        checkpoints=[('scale_bg',hist.get_wR())]
        hist.set_refinements({'Instrument Parameters':['Zero']})
        for p in phases: p.set_refinements({'Cell':True})
        refine(gpx); checkpoints.append(('cells_zero',hist.get_wR()))

        # Fit a common physical instrument profile first.
        inst=hist.data['Instrument Parameters'][0]
        for key,val in [('U',10.),('W',10.),('X',1.),('SH/L',.03)]:inst[key][1]=val
        hist.set_refinements({'Instrument Parameters':['U','W','X','SH/L']})
        refine(gpx); checkpoints.append(('instrument',hist.get_wR()))

        # Add positive isotropic specimen broadening for each phase.
        for p in phases:
            hap=p.data['Histograms'][hist.name]
            hap['Size'][1][0]=0.3; hap['Mustrain'][1][0]=1000.
            p.set_HAP_refinements({'Size':{'type':'isotropic','value':.3,'refine':True},
                                   'Mustrain':{'type':'isotropic','refine':True}})
        refine(gpx); checkpoints.append(('phase_profiles',hist.get_wR()))

        masses=np.array([p.data['General']['Mass'] for p in phases])
        scales=np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
        fractions=masses*scales/np.dot(masses,scales)
        result={'wo3_id':rid,'ok':True,'checkpoints':checkpoints,'wR_percent':hist.get_wR(),
                'cells':[p.get_cell() for p in phases],
                'scales':scales.tolist(),'masses':masses.tolist(),'fractions':fractions.tolist(),
                'instrument':{k:hist.data['Instrument Parameters'][0][k][1] for k in ['Zero','U','V','W','X','SH/L']},
                'profiles':[{k:p.data['Histograms'][hist.name][k] for k in ['Size','Mustrain']} for p in phases],
                'frozen':gpx.get_Frozen()}
        gpx.save(str(folder/'screened.gpx'))
        np.savetxt(folder/'fit.csv',np.column_stack([hist.getdata(k) for k in ['X','Yobs','Ycalc','Residual','Background']]),
                   delimiter=',',header='two_theta,observed,calculated,difference,background',comments='')
    except Exception as exc:
        result={'wo3_id':rid,'ok':False,'error':repr(exc)}
    all_results.append(plain(result))
    print(json.dumps(plain(result)),flush=True)
    (OUT/'results.json').write_text(json.dumps(all_results,indent=2)+'\n')
