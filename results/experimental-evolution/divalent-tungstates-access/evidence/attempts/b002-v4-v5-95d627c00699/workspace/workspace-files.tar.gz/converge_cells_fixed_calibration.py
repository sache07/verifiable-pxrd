from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_cells_fixed_calibration'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'screen_physical_calibration/start_3/result.gpx'

project = G2.G2Project(gpxfile=str(BASE))
project.save(str(OUT / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.'],
                        'Sample Parameters': ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']})
hist.data['Instrument Parameters'][0]['Zero'][1] = -0.25
hist.SampleParameters['Shift'] = [-800.0, False]
for phase in phases:
    phase.set_refinements({'Cell': True})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
    for atom in phase.atoms():
        atom.refinement_flags = ' '
project.set_Controls('cycles', 15)
history = []

for iteration in range(1, 4):
    project.set_Frozen()
    project.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'iteration': iteration,
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'cells': [p.get_cell() for p in phases],
        'frozen': project.get_Frozen(),
    }
    history.append(result)
    print(json.dumps(result), flush=True)
    project.save()
    shutil.copy2(project.filename, OUT / f'{iteration:02d}.gpx')
    np.savetxt(
        OUT / f'{iteration:02d}.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'history.json').write_text(json.dumps(history, indent=2) + '\n')

for phase in phases:
    phase.clear_refinements({'Cell': False})
project.save(str(OUT / 'cells.gpx'))
