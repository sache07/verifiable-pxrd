from pathlib import Path
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_calibration_reparameterization'
OUT.mkdir(exist_ok=True)
pairs = [(0.25, -320.0), (0.20, -400.0), (0.15, -500.0),
         (0.10, -580.0), (0.00, -755.0)]

for index, (zero, shift) in enumerate(pairs, 1):
    project = G2.G2Project(gpxfile=str(ROOT / 'final.gpx'))
    hist = project.histogram(0)
    hist.data['Instrument Parameters'][0]['Zero'][1] = zero
    hist.data['Instrument Parameters'][0]['Zero'][2] = False
    hist.SampleParameters['Shift'] = [shift, False]
    project.data.setdefault('Covariance', {})['data'] = {}
    project.save(str(OUT / f'{index:02d}_z{zero:.2f}_s{shift:.0f}.gpx'))
