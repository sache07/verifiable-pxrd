from pathlib import Path
import json
import numpy as np

ROOT = Path('.').resolve()
data = np.load(ROOT / 'final_replay/prediction.npz')
x = np.asarray(data['x'], float)
observed = np.asarray(data['observed'], float)
calculated = np.asarray(data['predicted'], float)
background = np.asarray(data['background'], float)
difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
weighted_denominator = float(np.sum(weights * observed**2))

np.savetxt(
    ROOT / 'fit.csv',
    np.column_stack([x, observed, calculated, difference, background]),
    delimiter=',',
    header='two_theta,observed,calculated,difference,background',
    comments='',
    fmt=['%.8f', '%.10f', '%.10f', '%.10f', '%.10f'],
)

statistics = {
    'Rwp_percent': 100.0 * (chi_square / weighted_denominator) ** 0.5,
    'Rp_percent': 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(observed))),
    'weighted_chi_square': chi_square,
    'RMSE_counts': float(np.sqrt(np.mean(difference**2))),
    'MAE_counts': float(np.mean(np.abs(difference))),
    'n_points': int(x.size),
    'two_theta_min_deg': float(x[0]),
    'two_theta_max_deg': float(x[-1]),
    'minimum_background_counts': float(np.min(background)),
}
print(json.dumps(statistics, indent=2))
