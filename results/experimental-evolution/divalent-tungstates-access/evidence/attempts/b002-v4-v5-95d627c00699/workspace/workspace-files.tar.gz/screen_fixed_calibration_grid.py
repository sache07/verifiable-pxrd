from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_fixed_calibration_grid'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_wo3_coordinates/01_tungsten.gpx'
starts = [(zero, shift) for zero in [-0.25, 0.0, 0.15, 0.25]
          for shift in [-800.0, 0.0, 400.0, 800.0]]
results = []

for zero, shift in starts:
    tag = f'z{zero:+.2f}_s{shift:+.0f}'.replace('+', 'p').replace('-', 'm')
    folder = OUT / tag
    folder.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(folder / 'active.gpx'))
    hist = project.histogram(0)
    phases = project.phases()
    hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.'],
                            'Sample Parameters': ['Shift', 'Transparency', 'SurfRoughA', 'SurfRoughB']})
    hist.data['Instrument Parameters'][0]['Zero'][1] = zero
    hist.SampleParameters['Shift'] = [shift, False]
    for phase in phases:
        phase.set_refinements({'Cell': True})
        phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
        for atom in phase.atoms():
            atom.refinement_flags = ' '
    project.set_Controls('cycles', 15)
    project.set_Frozen()
    project.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'zero_deg': zero,
        'shift_um': shift,
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'cells': [p.get_cell() for p in phases],
        'frozen': project.get_Frozen(),
    }
    results.append(result)
    print(json.dumps(result), flush=True)
    project.save(str(folder / 'result.gpx'))
    np.savetxt(
        folder / 'fit.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
