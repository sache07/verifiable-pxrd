from pathlib import Path
import json
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'screen_wo3_texture_lowuiso_coords'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_coordinates_lowuiso/base_coordinates.gpx'
axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]
results = []

for axis in axes:
    tag = ''.join(map(str, axis))
    folder = OUT / tag
    folder.mkdir(exist_ok=True)
    g = G2.G2Project(gpxfile=str(BASE))
    g.save(str(folder / 'active.gpx'))
    h = g.histogram(0)
    phases = g.phases()
    h.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'W', 'X', 'SH/L']})
    for phase in phases:
        phase.clear_refinements({'Cell': False})
        phase.clear_HAP_refinements({'Size': False, 'Mustrain': False})
        for atom in phase.atoms():
            atom.refinement_flags = ' '
    # Keep the accepted ZnWO4 [111] term, and add one WO3 trial term.
    phases[0].data['Histograms'][h.name]['Pref.Ori.'][2] = False
    hap = phases[1].data['Histograms'][h.name]
    hap['Pref.Ori.'][0] = 'MD'
    hap['Pref.Ori.'][1] = 1.0
    hap['Pref.Ori.'][2] = True
    hap['Pref.Ori.'][3] = axis
    g.set_Controls('parmMin', 0.70, '1:0:MD')
    g.set_Controls('parmMax', 1.40, '1:0:MD')
    g.set_Controls('cycles', 10)
    g.set_Frozen()
    g.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][h.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    result = {
        'axis': axis,
        'ratio': hap['Pref.Ori.'][1],
        'wR_percent': h.get_wR(),
        'fractions': fractions.tolist(),
        'frozen': g.get_Frozen(),
    }
    results.append(result)
    print(json.dumps(result), flush=True)
    g.save(str(folder / 'result.gpx'))
    np.savetxt(
        folder / 'fit.csv',
        np.column_stack([h.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
