from pathlib import Path
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
SOURCE = ROOT / 'work_physical_texture_final/02.gpx'

project = G2.G2Project(gpxfile=str(SOURCE))
hist = project.histogram(0)
phases = project.phases()

# Freeze the accepted model so final.gpx opens as the submitted checkpoint,
# not as an invitation to repeat a branch refinement.
for value in hist.data['Instrument Parameters'][0].values():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = False
for value in hist.SampleParameters.values():
    if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
        value[1] = False
hist.SampleParameters['Scale'] = [1.0, False]

for phase in phases:
    phase.clear_refinements({'Cell': False})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
    hap = phase.data['Histograms'][hist.name]
    hap['Scale'][1] = False
    hap['Pref.Ori.'][2] = False
    hap['Size'][2] = [False] * len(hap['Size'][2])
    hap['Mustrain'][2] = [False] * len(hap['Mustrain'][2])
    for atom in phase.atoms():
        atom.refinement_flags = ' '

# Covariance values are not part of the forward model and can contain stale
# trial-step information. Removing them also makes CIF exports deterministic.
project.data.setdefault('Covariance', {})['data'] = {}
project.save(str(ROOT / 'final.gpx'))

project = G2.G2Project(gpxfile=str(ROOT / 'final.gpx'))
project.data.setdefault('Covariance', {})['data'] = {}
project.phase(0).export_CIF(str(ROOT / 'phase_1_ZnWO4.cif'))
project.phase(1).export_CIF(str(ROOT / 'phase_2_WO3.cif'))
