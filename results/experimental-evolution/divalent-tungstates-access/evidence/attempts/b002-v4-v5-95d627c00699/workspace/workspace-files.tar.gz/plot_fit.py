import sys
import numpy as np
import matplotlib.pyplot as plt

path = sys.argv[1] if len(sys.argv) > 1 else 'trial_initial_fit.csv'
out = sys.argv[2] if len(sys.argv) > 2 else 'trial_initial_fit.png'
d = np.loadtxt(path, delimiter=',', skiprows=1)
x, obs, calc, diff, back = d.T[:5]
fig, axes = plt.subplots(3, 1, figsize=(15, 10))
for ax, lo, hi in zip(axes, [9.9, 39.9, 69.9], [40.2, 70.2, 100.1]):
    m = (x >= lo) & (x <= hi)
    ax.plot(x[m], obs[m], color='black', lw=.55, label='observed')
    ax.plot(x[m], calc[m], color='tab:red', lw=.75, label='calculated')
    ax.plot(x[m], diff[m], color='tab:blue', lw=.5, label='difference')
    ax.plot(x[m], back[m], color='tab:orange', lw=.6, label='background')
    ax.set_xlim(lo, hi)
    ax.set_ylabel('counts')
axes[0].legend(ncol=4)
axes[-1].set_xlabel(r'$2\theta$ (deg)')
fig.tight_layout()
fig.savefig(out, dpi=180)
