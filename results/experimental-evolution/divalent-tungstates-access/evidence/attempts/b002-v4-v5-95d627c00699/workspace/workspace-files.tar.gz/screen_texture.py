from pathlib import Path
import json
import shutil
import sys
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT=Path('.').resolve();OUT=ROOT/'screen_texture';OUT.mkdir(exist_ok=True)
BASE=ROOT/'work_physical/06_registered.gpx'
axes=[[0,0,1],[1,0,0],[0,1,0],[1,1,0],[1,1,1]]
results=[]
for pid in [0,1]:
  for axis in axes:
    tag=f'p{pid}_'+''.join(map(str,axis));folder=OUT/tag;folder.mkdir(exist_ok=True)
    g=G2.G2Project(gpxfile=str(BASE));g.save(str(folder/'active.gpx'));h=g.histogram(0);ps=g.phases()
    h.clear_refinements({'Instrument Parameters':['Zero','U','W','X','SH/L']})
    for p in ps:
      p.clear_refinements({'Cell':False});p.clear_HAP_refinements({'Size':False,'Mustrain':False,'Pref.Ori.':False})
      for a in p.atoms():a.refinement_flags=' '
    hap=ps[pid].data['Histograms'][h.name];hap['Pref.Ori.'][0]='MD';hap['Pref.Ori.'][1]=1.;hap['Pref.Ori.'][2]=True;hap['Pref.Ori.'][3]=axis
    g.set_Controls('parmMin',.65,f'{pid}:0:MD');g.set_Controls('parmMax',1.5,f'{pid}:0:MD');g.set_Controls('cycles',8);g.set_Frozen();g.refine()
    masses=np.array([p.data['General']['Mass'] for p in ps]);scales=np.array([p.data['Histograms'][h.name]['Scale'][0] for p in ps]);fr=masses*scales/np.dot(masses,scales)
    r={'tag':tag,'phase':ps[pid].name,'axis':axis,'ratio':hap['Pref.Ori.'][1],'wR_percent':h.get_wR(),'fractions':fr.tolist(),'frozen':g.get_Frozen()}
    results.append(r);print(json.dumps(r),flush=True)
    g.save(str(folder/'result.gpx'));np.savetxt(folder/'fit.csv',np.column_stack([h.getdata(k) for k in ['X','Yobs','Ycalc','Residual','Background']]),delimiter=',',header='two_theta,observed,calculated,difference,background',comments='')
    (OUT/'results.json').write_text(json.dumps(results,indent=2)+'\n')
