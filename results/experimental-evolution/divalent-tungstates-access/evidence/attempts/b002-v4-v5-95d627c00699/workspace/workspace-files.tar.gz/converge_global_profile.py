from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT = Path('.').resolve()
OUT = ROOT / 'work_global_profile_converged'
OUT.mkdir(exist_ok=True)
BASE = ROOT / 'work_global_profile/profile.gpx'

project = G2.G2Project(gpxfile=str(BASE))
project.save(str(OUT / 'active.gpx'))
hist = project.histogram(0)
phases = project.phases()
hist.clear_refinements({'Instrument Parameters': ['Zero', 'U', 'V', 'W', 'X', 'SH/L', 'Polariz.']})
hist.set_refinements({'Instrument Parameters': ['U', 'W', 'SH/L', 'Polariz.']})
for phase in phases:
    phase.clear_refinements({'Cell': False})
    phase.clear_HAP_refinements({'Size': False, 'Mustrain': False, 'Pref.Ori.': False})
    phase.set_HAP_refinements({'Size': {'type': 'isotropic', 'refine': True}})
    for atom in phase.atoms():
        atom.refinement_flags = ' '

for phase_index in range(2):
    project.set_Controls('parmMin', 0.04, f'{phase_index}:0:Size;i')
    project.set_Controls('parmMax', 1.5, f'{phase_index}:0:Size;i')
for variable, low, high in [(':0:U', 0.0, 40.0), (':0:W', 2.0, 40.0),
                            (':0:SH/L', 0.005, 0.10), (':0:Polariz.', 0.5, 1.0)]:
    project.set_Controls('parmMin', low, variable)
    project.set_Controls('parmMax', high, variable)
project.set_Controls('cycles', 15)
history = []

for iteration in range(1, 4):
    project.set_Frozen()
    project.refine()
    masses = np.array([p.data['General']['Mass'] for p in phases])
    scales = np.array([p.data['Histograms'][hist.name]['Scale'][0] for p in phases])
    fractions = masses * scales / np.dot(masses, scales)
    inst = hist.data['Instrument Parameters'][0]
    result = {
        'iteration': iteration,
        'wR_percent': hist.get_wR(),
        'fractions': fractions.tolist(),
        'sizes_um': [p.data['Histograms'][hist.name]['Size'][1][0] for p in phases],
        'instrument': {k: inst[k][1] for k in ['U', 'W', 'X', 'SH/L', 'Polariz.']},
        'frozen': project.get_Frozen(),
    }
    history.append(result)
    print(json.dumps(result), flush=True)
    project.save()
    shutil.copy2(project.filename, OUT / f'{iteration:02d}.gpx')
    np.savetxt(
        OUT / f'{iteration:02d}.csv',
        np.column_stack([hist.getdata(k) for k in ['X', 'Yobs', 'Ycalc', 'Residual', 'Background']]),
        delimiter=',',
        header='two_theta,observed,calculated,difference,background',
        comments='',
    )
    (OUT / 'history.json').write_text(json.dumps(history, indent=2) + '\n')

hist.clear_refinements({'Instrument Parameters': ['U', 'W', 'SH/L', 'Polariz.']})
for phase in phases:
    phase.clear_HAP_refinements({'Size': False})
project.save(str(OUT / 'profile_converged.gpx'))
