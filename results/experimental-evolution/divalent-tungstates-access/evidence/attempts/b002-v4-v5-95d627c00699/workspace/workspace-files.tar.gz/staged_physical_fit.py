from pathlib import Path
import json
import shutil
import numpy as np
from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel('warn')
ROOT=Path('.').resolve();OUT=ROOT/'work_physical';OUT.mkdir(exist_ok=True)
BASE=ROOT/'work_two_phase_2311041/01_unbound_scales.gpx'
DONOR=ROOT/'work_two_phase/04_wo3_heavy.gpx'

def plain(v):
    if isinstance(v,dict):return {str(k):plain(x) for k,x in v.items()}
    if isinstance(v,(list,tuple)):return [plain(x) for x in v]
    if isinstance(v,np.ndarray):return v.tolist()
    if isinstance(v,np.generic):return v.item()
    return v

def rec(g,h,ps,label):
    masses=np.array([p.data['General']['Mass'] for p in ps]);scales=np.array([p.data['Histograms'][h.name]['Scale'][0] for p in ps]);fr=masses*scales/np.dot(masses,scales)
    return plain({'label':label,'wR_percent':h.get_wR(),'fractions':fr.tolist(),'scales':scales.tolist(),
      'cells':[p.get_cell() for p in ps], 'instrument':{k:h.data['Instrument Parameters'][0][k][1] for k in ['Zero','U','V','W','X','SH/L','Polariz.']},
      'profiles':[{k:p.data['Histograms'][h.name][k] for k in ['Size','Mustrain','Pref.Ori.']} for p in ps],
      'atoms':[[{'label':a.label,'xyz':list(a.coordinates),'uiso':a.uiso,'flags':a.refinement_flags} for a in p.atoms()] for p in ps],
      'frozen':g.get_Frozen(),'vary':[str(x) for x in g.data.get('Covariance',{}).get('data',{}).get('varyList',[])]})

hist=[]
def save(g,h,ps,label):
    g.save();shutil.copy2(g.filename,OUT/f'{label}.gpx')
    np.savetxt(OUT/f'{label}.csv',np.column_stack([h.getdata(k) for k in ['X','Yobs','Ycalc','Residual','Background']]),delimiter=',',header='two_theta,observed,calculated,difference,background',comments='')
    r=rec(g,h,ps,label);hist.append(r);print(json.dumps(r),flush=True);(OUT/'history.json').write_text(json.dumps(hist,indent=2)+'\n')

g=G2.G2Project(gpxfile=str(BASE));g.save(str(OUT/'active.gpx'));h=g.histogram(0);ps=g.phases();prod,wo3=ps
don=G2.G2Project(gpxfile=str(DONOR)).phase(0)
cx=prod.data['General']['AtomPtrs'][0]
for a in prod.data['Atoms']:
    src=next(x for x in don.data['Atoms'] if x[0]==a[0])
    a[cx:cx+3]=src[cx:cx+3]

# First assess the transferred product coordinates with only scale/background active.
h.clear_refinements({'Instrument Parameters':['Zero','U','W','X','SH/L']})
for p in ps:
    p.clear_refinements({'Cell':False})
    for a in p.atoms():a.refinement_flags=' '
    p.clear_HAP_refinements({'Size':False,'Mustrain':False})
g.set_Controls('cycles',8);g.set_Frozen();g.refine();save(g,h,ps,'01_transfer_scale_bg')

# Re-register peak positions with cells and the effective common angular correction.
h.set_refinements({'Instrument Parameters':['Zero']})
for p in ps:p.set_refinements({'Cell':True})
g.set_Frozen();g.refine();save(g,h,ps,'02_transfer_cells')

# Refine only the strong product coordinates while nuisance profile terms are fixed.
h.clear_refinements({'Instrument Parameters':['Zero']})
for p in ps:p.clear_refinements({'Cell':False})
prod.set_refinements({'Atoms':{'W1':'X','Zn1':'X','O1':'X','O2':'X'}})
g.set_Frozen();g.refine();save(g,h,ps,'03_product_coordinates')
for a in prod.atoms():a.refinement_flags=' '

# Rebuild a physical profile decomposition within the stated laboratory ranges.
inst=h.data['Instrument Parameters'][0]
for k,v in [('U',20.),('W',10.),('X',3.),('SH/L',.04)]:inst[k][1]=v
for var,lo,hi in [(':0:U',0.,40.),(':0:W',2.,40.),(':0:X',.1,6.),(':0:SH/L',.005,.1)]:
    g.set_Controls('parmMin',lo,var);g.set_Controls('parmMax',hi,var)
h.set_refinements({'Instrument Parameters':['U','W','X','SH/L']})
g.set_Frozen();g.refine();save(g,h,ps,'04_instrument_profile')
h.clear_refinements({'Instrument Parameters':['U','W','X','SH/L']})

for pid,p in enumerate(ps):
    for term,lo,hi in [('Size;i',.04,1.5),('Mustrain;i',0.,8000.)]:
        g.set_Controls('parmMin',lo,f'{pid}:0:{term}');g.set_Controls('parmMax',hi,f'{pid}:0:{term}')
    p.set_HAP_refinements({'Size':{'type':'isotropic','refine':True},'Mustrain':{'type':'isotropic','refine':True}})
g.set_Frozen();g.refine();save(g,h,ps,'05_phase_profiles')

# Final common registration while coordinates and profile decomposition are fixed.
for p in ps:p.clear_HAP_refinements({'Size':False,'Mustrain':False})
h.set_refinements({'Instrument Parameters':['Zero']})
for p in ps:p.set_refinements({'Cell':True})
g.set_Frozen();g.refine();save(g,h,ps,'06_registered')
g.save(str(OUT/'base_physical.gpx'))
