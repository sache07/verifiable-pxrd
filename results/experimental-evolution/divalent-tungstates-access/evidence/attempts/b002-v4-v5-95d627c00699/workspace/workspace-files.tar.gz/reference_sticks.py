from pathlib import Path
import numpy as np
from pymatgen.core import Structure
from pymatgen.analysis.diffraction.xrd import XRDCalculator

ROOT = Path('<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c01/cif')
ids = ['9004178','1534836','1537875','1004057','1010618','1521532','1521533','1528915','1563541','2311041','2106293','2107312']
calc = XRDCalculator(wavelength='CuKa')
for rid in ids:
    p = ROOT / rid[0] / rid[1:3] / rid[3:5] / f'{rid}.cif'
    try:
        s = Structure.from_file(p, primitive=False)
        pattern = calc.get_pattern(s, two_theta_range=(10,100), scaled=True)
    except Exception as exc:
        print(rid, 'ERROR', repr(exc)); continue
    print('\n', rid, s.composition.reduced_formula, s.get_space_group_info(symprec=1e-3), s.lattice.abc, s.lattice.angles)
    peaks = sorted(zip(pattern.x, pattern.y, pattern.hkls), key=lambda z:z[1], reverse=True)
    for x,y,h in peaks[:25]:
        print(f'{x:8.3f} {y:7.2f} {h[0]["hkl"]}')
