#!/usr/bin/env python
"""Freeze the selected GSAS-II model and export its deliverables."""

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "finalstages" / "05_instrument_continue.gpx"


def freeze(project):
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    hist.Background[0][1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["LeBail"] = False
        phase.data["General"]["doPawley"] = False
    # ZnO's stored uniaxial trial has equal axial/equatorial values and is
    # exactly isotropic. Canonicalize it before submission.
    zno_hap = project.phase("ZnO").data["Histograms"][hist.name]
    zno_hap["Mustrain"][0] = "isotropic"
    zno_hap["Mustrain"][1][1] = zno_hap["Mustrain"][1][0]
    zno_hap["Mustrain"][2] = [False, False, False]
    # Refined common Uiso values are already propagated to every atom. Remove
    # duplicate trial constraints from the frozen, no-refinement project.
    constraints = project.data["Constraints"]["data"]
    for key in ["Hist", "HAP", "Phase", "Global"]:
        constraints[key] = []
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def weight_fractions(project, hist):
    amounts = [
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    return {
        phase.name: value / sum(amounts)
        for phase, value in zip(project.phases(), amounts)
    }


def main():
    project = G2.G2Project(gpxfile=str(BASE))
    freeze(project)
    project.save(str(ROOT / "final.gpx"))

    project = G2.G2Project(gpxfile=str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    cif_names = {
        "ZnWO4": "phase_ZnWO4.cif",
        "WO3": "phase_WO3.cif",
        "ZnO": "phase_ZnO.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(ROOT / cif_names[phase.name]))

    profile = np.asarray(hist.data["data"][1], dtype=float)
    output = np.column_stack((profile[0], profile[1], profile[3], profile[5]))
    np.savetxt(
        ROOT / "fit.csv",
        output,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )

    summary = {
        "histogram": hist.name,
        "rwp_percent": hist.residuals.get("wR"),
        "rp_percent": hist.residuals.get("R"),
        "gof": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "chi_square": project.data["Covariance"]["data"].get("Rvals", {}).get("chisq"),
        "weight_fractions": weight_fractions(project, hist),
        "phases": {},
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]
        },
        "sample_shift_um": hist.SampleParameters["Shift"][0],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        summary["phases"][phase.name] = {
            "cif": cif_names[phase.name],
            "cell": phase.get_cell(),
            "size_um": hap["Size"][1][0],
            "microstrain": hap["Mustrain"],
            "march_dollase": hap["Pref.Ori."],
            "uiso_A2": [atom.uiso for atom in phase.atoms()],
            "coordinates": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(atom.coordinates),
                }
                for atom in phase.atoms()
            ],
        }
    (ROOT / ".tmp" / "final_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
