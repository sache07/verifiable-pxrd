#!/usr/bin/env python
"""Staged, bounded coordinate adaptation from a common GSAS-II project."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    # A parameter touching a trial bound is frozen by GSAS-II. Each staged
    # refinement below has explicit physical bounds, so stale trial freezes are
    # discarded before proceeding.
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    return hist


def fractions(project, hist):
    masses = [
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ]
    return {p.name: m / sum(masses) for p, m in zip(project.phases(), masses)}


def set_coordinate_bounds(project, phase, atom_indices, half_width):
    for i in atom_indices:
        for axis, value in zip("xyz", phase.atoms()[i].coordinates):
            variable = f"{phase.id}::dA{axis}:{i}"
            project.set_Controls("parmMin", value - half_width, variable)
            project.set_Controls("parmMax", value + half_width, variable)


def stage(project, out, number, label, phase_name, atom_indices, half_width):
    hist = clear_flags(project)
    phase = project.phase(phase_name)
    set_coordinate_bounds(project, phase, atom_indices, half_width)
    for i in atom_indices:
        phase.atoms()[i].refinement_flags = "X"
    project.set_Controls("cycles", 12)
    target = out / f"{number:02d}_{label}.gpx"
    project.save(str(target))
    project.refine(printFile=str(out / f"{number:02d}_{label}.lst"))
    hist = project.histogram(0)
    record = {
        "stage": label,
        "rwp": hist.residuals.get("wR"),
        "fractions": fractions(project, hist),
        "coordinates": {
            p.name: [
                {"label": a.label, "element": a.element, "xyz": list(a.coordinates)}
                for a in p.atoms()
            ]
            for p in project.phases()
        },
        "project": str(target),
    }
    print(json.dumps(record), flush=True)
    return record


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    out = ROOT / ".tmp" / "coords" / args.tag
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    records = []
    # Heavy-atom sites first, then light-atom substructures, one phase at a
    # time. Bounds are deliberately wider than the documented reference
    # perturbations but prevent a wrong coordinate branch.
    records.append(stage(project, out, 1, "znwo4_heavy", "ZnWO4", [0, 1], 0.04))
    records.append(stage(project, out, 2, "znwo4_oxygen", "ZnWO4", [2, 3], 0.04))
    records.append(stage(project, out, 3, "wo3_heavy", "WO3", [0, 1], 0.025))
    records.append(stage(project, out, 4, "wo3_oxygen", "WO3", list(range(2, 8)), 0.025))
    # Zn fixes the polar origin of wurtzite; refine only the internal oxygen z.
    records.append(stage(project, out, 5, "zno_oxygen", "ZnO", [1], 0.025))
    (out / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
