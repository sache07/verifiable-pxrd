#!/usr/bin/env python
"""Bounded staged instrument and phase-profile refinement."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    return hist


def fractions(project, hist):
    masses = [
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ]
    return {p.name: m / sum(masses) for p, m in zip(project.phases(), masses)}


def state(project, label, path):
    hist = project.histogram(0)
    return {
        "stage": label,
        "rwp": hist.residuals.get("wR"),
        "fractions": fractions(project, hist),
        "instrument": {
            k: v[1]
            for k, v in hist.InstrumentParameters.items()
            if k in ["Zero", "Polariz.", "U", "W", "X", "SH/L"]
        },
        "shift_um": hist.SampleParameters["Shift"][0],
        "profiles": {
            p.name: {
                "size_um": p.data["Histograms"][hist.name]["Size"][1][0],
                "mustrain_ppm": p.data["Histograms"][hist.name]["Mustrain"][1][0],
            }
            for p in project.phases()
        },
        "project": str(path),
    }


def refine_to(project, out, number, label):
    target = out / f"{number:02d}_{label}.gpx"
    project.set_Controls("cycles", 12)
    project.save(str(target))
    project.refine(printFile=str(out / f"{number:02d}_{label}.lst"))
    record = state(project, label, target)
    print(json.dumps(record), flush=True)
    return record


def set_common_limits(project):
    hist = project.histogram(0)
    for phase in project.phases():
        pid, hid = phase.id, hist.id
        for variable, low, high in [
            (f"{pid}:{hid}:Size;i", 0.04, 1.5),
            (f"{pid}:{hid}:Mustrain;i", 0.0, 8000.0),
            (f"{pid}:{hid}:Scale", 0.0, 1.0e6),
        ]:
            project.set_Controls("parmMin", low, variable)
            project.set_Controls("parmMax", high, variable)
    for variable, low, high in [
        (f":{hist.id}:U", 0.0, 40.0),
        (f":{hist.id}:W", 2.0, 40.0),
        (f":{hist.id}:X", 0.1, 6.0),
        (f":{hist.id}:SH/L", 0.005, 0.1),
    ]:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)


def profile_pass(project, out, start_number, records):
    number = start_number
    for phase in project.phases():
        clear_flags(project)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
        records.append(refine_to(project, out, number, f"{phase.name.lower()}_size"))
        number += 1
        clear_flags(project)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        records.append(refine_to(project, out, number, f"{phase.name.lower()}_strain"))
        number += 1
    clear_flags(project)
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    records.append(refine_to(project, out, number, "instrument"))
    return number + 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    out = ROOT / ".tmp" / "profiles" / args.tag
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    clear_flags(project)
    set_common_limits(project)
    records = []
    number = profile_pass(project, out, 1, records)
    profile_pass(project, out, number, records)
    (out / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
