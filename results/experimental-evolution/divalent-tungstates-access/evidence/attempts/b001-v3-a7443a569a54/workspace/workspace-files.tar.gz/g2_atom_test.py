#!/usr/bin/env python
"""Refine selected atomic coordinates with bounded shifts from a saved model."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    return hist


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("target")
    parser.add_argument("--phase", required=True)
    parser.add_argument("--atoms", required=True, help="comma-separated zero-based indices")
    parser.add_argument("--half-width", type=float, default=0.012)
    parser.add_argument("--cycles", type=int, default=36)
    args = parser.parse_args()

    target = Path(args.target).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    clear_flags(project)
    phase = project.phase(args.phase)
    indices = [int(value) for value in args.atoms.split(",")]
    for index in indices:
        atom = phase.atoms()[index]
        # GSAS-II names coordinate variables dAx/dAy/dAz, but their bounded
        # values are the absolute fractional coordinates.
        for axis, value in zip("xyz", atom.coordinates):
            variable = f"{phase.id}::dA{axis}:{index}"
            project.set_Controls("parmMin", value - args.half_width, variable)
            project.set_Controls("parmMax", value + args.half_width, variable)
        atom.refinement_flags = "X"
    project.set_Controls("cycles", args.cycles)
    project.save(str(target))
    project.refine(printFile=str(target.with_suffix(".lst")))
    project = G2.G2Project(gpxfile=str(target))
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "rwp": hist.residuals.get("wR"),
                "coordinates": {
                    item.name: [
                        {
                            "label": atom.label,
                            "element": atom.element,
                            "xyz": list(atom.coordinates),
                        }
                        for atom in item.atoms()
                    ]
                    for item in project.phases()
                },
                "project": str(target),
            }
        )
    )


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
