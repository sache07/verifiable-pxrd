#!/usr/bin/env python
"""Continue the active refinement flags in a GSAS-II project."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("target")
    parser.add_argument("--cycles", type=int, default=24)
    args = parser.parse_args()

    base = Path(args.base).resolve()
    target = Path(args.target).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base))
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.set_Controls("cycles", args.cycles)
    project.save(str(target))
    project.refine(printFile=str(target.with_suffix(".lst")))
    project = G2.G2Project(gpxfile=str(target))
    hist = project.histogram(0)
    output = {
        "rwp": hist.residuals.get("wR"),
        "gof": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "project": str(target),
        "strains": {
            phase.name: phase.data["Histograms"][hist.name]["Mustrain"]
            for phase in project.phases()
        },
    }
    print(json.dumps(output))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
