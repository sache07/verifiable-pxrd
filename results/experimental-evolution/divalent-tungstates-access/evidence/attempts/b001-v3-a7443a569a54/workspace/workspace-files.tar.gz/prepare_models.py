#!/usr/bin/env python
"""Prepare chemically allowed starting models for the ZnO/WO3 reaction scan."""

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c05/cif"
)
OUT = ROOT / ".tmp" / "models"


def cod_path(record_id: str) -> Path:
    return RESOURCE / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def write_model(structure: Structure, path: Path) -> None:
    structure = structure.copy()
    structure.remove_oxidation_states()
    CifWriter(structure, symprec=0.001, significant_figures=10).write_file(path)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    # Wolframite FeWO4 (COD 1567215) is the closest physically complete
    # available AWO4 parent. Replace Fe with Zn and place it near the cell
    # inferred from the isolated (010), (100), (020), and (200) families.
    parser = CifParser(cod_path("1567215"), occupancy_tolerance=1.0, frac_tolerance=0)
    fe_parent = parser.parse_structures(primitive=False, on_error="raise")[0]
    fe_parent.replace_species({"Fe": "Zn"})
    zn_lattice = Lattice.monoclinic(4.690, 5.720, 4.930, 90.65)
    zn_fe = Structure(
        zn_lattice,
        fe_parent.species,
        fe_parent.frac_coords,
        site_properties=fe_parent.site_properties,
    )
    write_model(zn_fe, OUT / "znwo4_fe_parent.cif")

    # Independent coordinate start from the complete asymmetric subset in the
    # historical NiWO4 wolframite entry COD 5910277. The source redundantly
    # lists symmetry equivalents and is not directly importable, so construct
    # the four independent sites explicitly before the Ni -> Zn transfer.
    zn_ni = Structure.from_spacegroup(
        "P 2/c",
        zn_lattice,
        ["Zn", "W", "O", "O"],
        [
            [0.5, 0.653, 0.25],
            [0.0, 0.180, 0.25],
            [0.220, 0.110, -0.040],
            [0.260, 0.380, 0.390],
        ],
    )
    write_model(zn_ni, OUT / "znwo4_ni_parent.cif")

    # Copy candidate residual phases through pymatgen so all starts use a
    # neutral-element, single-block CIF representation accepted identically by
    # GSAS-II. Two monoclinic WO3 coordinate starts and one lower-symmetry start
    # are retained for comparable testing.
    for record_id, name in [
        ("1528915", "wo3_p21n_1528915"),
        ("2311041", "wo3_p21c_2311041"),
        ("2106293", "wo3_p1_2106293"),
        ("9004178", "zno_wurtzite_9004178"),
    ]:
        structure = CifParser(
            cod_path(record_id), occupancy_tolerance=1.0, frac_tolerance=0
        ).parse_structures(primitive=False, on_error="raise")[0]
        write_model(structure, OUT / f"{name}.cif")

    # GSAS-II powder input with Poisson standard uncertainties. Keeping all
    # original x/y values is required for project replay.
    data = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(data[:, 1], 1.0))
    np.savetxt(
        ROOT / ".tmp" / "pattern.xye",
        np.column_stack((data, sigma)),
        fmt=["%.8f", "%.8f", "%.8f"],
    )

    # Starting values lie near the center of the documented instrument ranges;
    # they are refined from the observed profile.
    (ROOT / ".tmp" / "instrument.instprm").write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )

    for path in sorted(OUT.glob("*.cif")):
        structure = Structure.from_file(path, primitive=False)
        distances = structure.distance_matrix.copy()
        np.fill_diagonal(distances, np.inf)
        print(
            path.name,
            structure.composition.reduced_formula,
            structure.get_space_group_info(symprec=0.01),
            tuple(round(v, 5) for v in (*structure.lattice.abc, *structure.lattice.angles)),
            "dmin=", round(float(distances.min()), 4),
        )


if __name__ == "__main__":
    main()
