#!/usr/bin/env python
"""Apply one bounded specimen/structure refinement stage to a GSAS-II project."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


INSTRUMENT_KEYS = ["Zero", "U", "W", "X", "SH/L", "Polariz."]
SAMPLE_KEYS = ["Shift", "SurfRoughA", "SurfRoughB"]


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": INSTRUMENT_KEYS,
            "Sample Parameters": SAMPLE_KEYS,
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    return hist


def fractions(project, hist):
    raw = [
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ]
    return {p.name: value / sum(raw) for p, value in zip(project.phases(), raw)}


def set_bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable)
    project.set_Controls("parmMax", high, variable)


def configure(project, mode, phase_name):
    hist = clear_flags(project)
    phase = project.phase(phase_name) if phase_name else None
    if mode == "uiso":
        variables = [f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        for atom, variable in zip(phase.atoms(), variables):
            atom.refinement_flags = "U"
            set_bound(project, variable, 0.003, 0.020)
        if len(variables) > 1:
            project.add_EquivConstr(variables)
    elif mode == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        set_bound(project, f":{hist.id}:Polariz.", 0.5, 1.0)
    elif mode == "roughness":
        hist.SampleParameters["SurfRoughA"] = [0.3, False]
        hist.SampleParameters["SurfRoughB"] = [0.1, False]
        hist.set_refinements(
            {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
        )
        set_bound(project, f":{hist.id}:SurfRoughA", 0.05, 0.6)
        set_bound(project, f":{hist.id}:SurfRoughB", 0.02, 0.5)
    elif mode == "cell":
        phase.set_refinements({"Cell": True})
    elif mode == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        set_bound(project, f":{hist.id}:Zero", -0.25, 0.25)
    elif mode == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        set_bound(project, f":{hist.id}:Shift", -800.0, 800.0)
    elif mode == "profile":
        hist.set_refinements(
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
        )
        for variable, low, high in [
            (f":{hist.id}:U", 0.0, 40.0),
            (f":{hist.id}:W", 2.0, 40.0),
            (f":{hist.id}:X", 0.1, 6.0),
            (f":{hist.id}:SH/L", 0.005, 0.1),
        ]:
            set_bound(project, variable, low, high)
    elif mode == "size":
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        set_bound(project, f"{phase.id}:{hist.id}:Size;i", 0.04, 1.5)
    elif mode == "strain":
        hap = phase.data["Histograms"][hist.name]
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2] = [True, True, False]
            set_bound(project, f"{phase.id}:{hist.id}:Mustrain;a", 0.0, 8000.0)
        else:
            hap["Mustrain"][2] = [True, False, False]
        set_bound(project, f"{phase.id}:{hist.id}:Mustrain;i", 0.0, 8000.0)
    elif mode == "texture":
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][2] = True
        set_bound(project, f"{phase.id}:{hist.id}:MD", 0.7, 1.4)
    else:
        raise ValueError(mode)


def state(project, target):
    hist = project.histogram(0)
    return {
        "rwp": hist.residuals.get("wR"),
        "gof": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "fractions": fractions(project, hist),
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in INSTRUMENT_KEYS
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in SAMPLE_KEYS
        },
        "uiso": {
            phase.name: [atom.uiso for atom in phase.atoms()]
            for phase in project.phases()
        },
        "cells": {
            phase.name: phase.get_cell()
            for phase in project.phases()
        },
        "project": str(target),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("target")
    parser.add_argument(
        "--mode",
        required=True,
        choices=[
            "uiso", "polarization", "roughness", "cell", "zero", "shift",
            "profile", "size", "strain", "texture",
        ],
    )
    parser.add_argument("--phase")
    parser.add_argument("--cycles", type=int, default=18)
    args = parser.parse_args()
    if args.mode in {"uiso", "cell", "size", "strain", "texture"} and not args.phase:
        parser.error("--phase is required for this mode")

    target = Path(args.target).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
    clear_flags(project)
    project.save(str(target))
    project = G2.G2Project(gpxfile=str(target))
    configure(project, args.mode, args.phase)
    project.set_Controls("cycles", args.cycles)
    project.save(str(target))
    project.refine(printFile=str(target.with_suffix(".lst")))
    project = G2.G2Project(gpxfile=str(target))
    print(json.dumps(state(project, target)))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
