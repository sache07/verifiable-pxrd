#!/usr/bin/env python
"""Test the allowed uniaxial microstrain axes from a common project."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    return hist


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("--phase", required=True)
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    out = ROOT / ".tmp" / "strain" / args.tag
    out.mkdir(parents=True, exist_ok=True)
    records = []
    for axis in AXES:
        project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
        hist = clear_flags(project)
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        initial = max(0.0, float(hap["Mustrain"][1][0]))
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = initial
        hap["Mustrain"][1][1] = initial
        hap["Mustrain"][2] = [True, True, False]
        hap["Mustrain"][3] = list(axis)
        for suffix in ["i", "a"]:
            variable = f"{phase.id}:{hist.id}:Mustrain;{suffix}"
            project.set_Controls("parmMin", 0.0, variable)
            project.set_Controls("parmMax", 8000.0, variable)
        name = "".join(map(str, axis))
        target = out / f"axis_{name}.gpx"
        project.set_Controls("cycles", 12)
        project.save(str(target))
        project.refine(printFile=str(out / f"axis_{name}.lst"))
        project = G2.G2Project(gpxfile=str(target))
        hist = project.histogram(0)
        phase = project.phase(args.phase)
        profile = phase.data["Histograms"][hist.name]["Mustrain"]
        record = {
            "axis": axis,
            "equatorial_ppm": profile[1][0],
            "axial_ppm": profile[1][1],
            "ratio": profile[1][1] / profile[1][0] if profile[1][0] else None,
            "rwp": hist.residuals.get("wR"),
            "project": str(target),
        }
        records.append(record)
        print(json.dumps(record), flush=True)
    (out / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
