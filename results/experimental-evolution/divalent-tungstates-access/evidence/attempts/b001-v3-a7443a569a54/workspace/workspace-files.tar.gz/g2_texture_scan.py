#!/usr/bin/env python
"""Compare allowed March-Dollase axes from a common refined project."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def clear_nonintensity_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    return hist


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base")
    parser.add_argument("--phase", default="ZnWO4")
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    out = ROOT / ".tmp" / "texture" / args.tag
    out.mkdir(parents=True, exist_ok=True)
    records = []
    for axis in AXES:
        name = "".join(map(str, axis))
        project = G2.G2Project(gpxfile=str(Path(args.base).resolve()))
        hist = clear_nonintensity_flags(project)
        phase = project.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.set_Controls("cycles", 10)
        project.set_Controls("parmMin", 0.7, f"{phase.id}:{hist.id}:MD")
        project.set_Controls("parmMax", 1.4, f"{phase.id}:{hist.id}:MD")
        target = out / f"axis_{name}.gpx"
        project.save(str(target))
        project.refine(printFile=str(out / f"axis_{name}.lst"))
        project = G2.G2Project(gpxfile=str(target))
        hist = project.histogram(0)
        phase = project.phase(args.phase)
        record = {
            "axis": axis,
            "md": phase.data["Histograms"][hist.name]["Pref.Ori."][1],
            "rwp": hist.residuals.get("wR"),
            "project": str(target),
        }
        records.append(record)
        print(json.dumps(record), flush=True)
    (out / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
