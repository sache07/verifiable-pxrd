#!/usr/bin/env python
"""Staged GSAS-II Rietveld trial for candidate Zn-W-O phase sets.

Run with the GSAS-II Python interpreter. This script intentionally keeps the
model-selection stages conservative; deeper coordinate/profile adaptation is
performed only after a candidate phase inventory gives a stable scale.
"""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
MODELS = ROOT / ".tmp" / "models"


def finite(value) -> float | None:
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def phase_fractions(project: G2.G2Project, hist: G2.G2PwdrData) -> dict[str, float]:
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"]))
    total = sum(masses)
    if total <= 0:
        return {p.name: 0.0 for p in project.phases()}
    return {p.name: m / total for p, m in zip(project.phases(), masses)}


def snapshot(project: G2.G2Project, outdir: Path, label: str) -> dict:
    hist = project.histogram(0)
    # Save the active working project, then make an immutable checkpoint copy.
    # Calling save(checkpoint) would change the active filename and the next
    # refinement would silently overwrite that checkpoint.
    project.save()
    checkpoint = outdir / f"{label}.gpx"
    shutil.copy2(project.filename, checkpoint)
    record = {
        "stage": label,
        "project": str(checkpoint),
        "residuals": {k: finite(v) for k, v in hist.residuals.items()},
        "fractions": phase_fractions(project, hist),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "instrument": {
            k: finite(v[1])
            for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) > 1
        },
        "sample": {
            k: finite(v[0])
            for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and v
        },
        "hap": {
            p.name: {
                "Scale": finite(p.data["Histograms"][hist.name]["Scale"][0]),
                "Size": p.data["Histograms"][hist.name]["Size"],
                "Mustrain": p.data["Histograms"][hist.name]["Mustrain"],
                "Pref.Ori.": p.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for p in project.phases()
        },
    }
    print(json.dumps(record, default=str))
    return record


def refine(project: G2.G2Project, outdir: Path, label: str, log: list[dict]) -> None:
    project.set_Controls("cycles", 8)
    project.refine(printFile=str(outdir / f"{label}.lst"), makeBack=False)
    log.append(snapshot(project, outdir, label))


def initialize(args: argparse.Namespace, outdir: Path) -> tuple[G2.G2Project, G2.G2PwdrData]:
    gpx = outdir / "working.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(ROOT / ".tmp" / "pattern.xye"),
        str(ROOT / ".tmp" / "instrument.instprm"),
        fmthint="xye",
    )
    phase_files = [
        (args.znwo4, "ZnWO4"),
        (args.wo3, "WO3"),
    ]
    if args.zno:
        phase_files.append((args.zno, "ZnO"))
    for model, name in phase_files:
        project.add_phase(
            str(MODELS / f"{model}.cif"),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    # The histogram and HAP scales are exactly redundant. Fix the former so
    # the phase scales alone carry the crystalline mass fractions.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1200.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    for index, phase in enumerate(project.phases()):
        # Put all phases in a numerically comparable scale range. The first
        # stage immediately refines these values.
        hap = phase.data["Histograms"][hist.name]
        starting_fraction = {"ZnWO4": 0.75, "WO3": 0.20, "ZnO": 0.05}[phase.name]
        hap["Scale"] = [
            2.0e-8 * starting_fraction / float(phase.data["General"]["Mass"]),
            True,
        ]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.01
    project.save()
    # Keep refined phase scales physical.
    project.update_ids()
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, f"{phase.id}:{hist.id}:Scale")
    return project, hist


def run(args: argparse.Namespace) -> dict:
    outdir = (ROOT / ".tmp" / "trials" / args.tag).resolve()
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    project, hist = initialize(args, outdir)
    log: list[dict] = [snapshot(project, outdir, "00_initial")]

    # Establish positive phase scales and a smooth empirical background.
    refine(project, outdir, "01_scale_background", log)

    # Adapt all candidate cells to their own coherent reflection families,
    # while estimating the common angular zero.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, outdir, "02_cells_zero", log)

    # Separate specimen displacement from constant zero using the full angular
    # range, then fit only instrument terms known to vary in this laboratory.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, outdir, "03_shift", log)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, outdir, "04_instrument", log)

    # Give each accepted component its own isotropic size and microstrain.
    # This is deliberately after scale/cell stabilization so a weak phase must
    # retain a stable scale before receiving profile freedom.
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.4, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, outdir, "05_phase_profiles", log)

    summary = {
        "tag": args.tag,
        "models": {"ZnWO4": args.znwo4, "WO3": args.wo3, "ZnO": args.zno},
        "stages": log,
        "final_project": str(outdir / "05_phase_profiles.gpx"),
    }
    (outdir / "summary.json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
    return summary


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tag", required=True)
    parser.add_argument(
        "--znwo4", choices=["znwo4_fe_parent", "znwo4_ni_parent"], required=True
    )
    parser.add_argument(
        "--wo3",
        choices=["wo3_p21n_1528915", "wo3_p21c_2311041", "wo3_p1_2106293"],
        required=True,
    )
    parser.add_argument("--zno", default="zno_wurtzite_9004178")
    parser.add_argument("--no-zno", action="store_true")
    args = parser.parse_args()
    if args.no_zno:
        args.zno = None
    return args


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    result = run(parse_args())
    print(json.dumps(result["stages"][-1], indent=2, default=str))
