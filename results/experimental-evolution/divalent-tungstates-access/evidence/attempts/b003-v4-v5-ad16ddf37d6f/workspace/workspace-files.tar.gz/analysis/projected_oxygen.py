#!/usr/bin/env python3
"""Refine oxygen directions, then project each displacement to a physical radius."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    al, be, ga = np.deg2rad([cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(ga), b * np.sin(ga), 0.0])
    cx = c * np.cos(be)
    cy = c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga)
    return np.vstack((va, vb, [cx, cy, np.sqrt(max(c*c-cx*cx-cy*cy, 0.0))]))


def freeze_atoms(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def prep(project: G2sc.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 8)
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["U"][2] = False
    for phase in project.phases()[:2]:
        phase.data["Histograms"][hist.name]["Mustrain"][2][0] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=ROOT / ".tmp" / "gsas" / "clipped_004.gpx")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--max-shift", type=float, default=0.05)
    args = parser.parse_args()
    out = args.out.resolve()
    shutil.copy2(args.base.resolve(), out)
    project = G2sc.G2Project(str(out))
    prep(project)
    freeze_atoms(project)
    project.save()

    for phase_name in ("MnWO4", "Mn3WO6", "WO3"):
        current = G2sc.G2Project(str(out))
        prep(current)
        freeze_atoms(current)
        phase = current.phase(phase_name)
        ref = {a.label: np.array(a.coordinates, dtype=float) for a in phase.atoms()}
        oxygen = [a.label for a in phase.atoms() if a.element.split("-")[0] == "O"]
        trial_path = out.with_name(out.stem + f"_trial_{phase_name}.gpx")
        current.save(str(trial_path))
        trial = G2sc.G2Project(str(trial_path))
        trial.phase(phase_name).set_refinements({"Atoms": {label: "X" for label in oxygen}})
        before = trial.histograms()[0].get_wR()
        trial.refine()
        after_trial = trial.histograms()[0].get_wR()
        tphase = trial.phase(phase_name)
        target = {a.label: np.array(a.coordinates, dtype=float) for a in tphase.atoms()}
        mat = matrix(current.phase(phase_name).get_cell())
        print(f"{phase_name} unbounded Rwp {before:.6f} -> {after_trial:.6f}")
        for atom in current.phase(phase_name).atoms():
            if atom.label not in oxygen:
                continue
            delta = (target[atom.label] - ref[atom.label] + 0.5) % 1.0 - 0.5
            dist = float(np.linalg.norm(delta @ mat))
            applied = min(dist, args.max_shift)
            if dist > args.max_shift:
                delta *= args.max_shift / dist
            atom.coordinates = tuple(ref[atom.label] + delta)
            print(" ", atom.label, "unbounded_A", dist, "applied_A", applied)
        freeze_atoms(current)
        current.save(str(out))
        current.refine()
        print(f"{phase_name} projected Rwp {current.histograms()[0].get_wR():.6f}")
        print(" fractions", current.histograms()[0].ComputeMassFracs())
        current.save(str(out))

    final = G2sc.G2Project(str(out))
    print("final Rwp", final.histograms()[0].get_wR())
    print("final fractions", final.histograms()[0].ComputeMassFracs())


if __name__ == "__main__":
    main()
