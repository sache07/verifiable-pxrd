#!/usr/bin/env python3
"""Bounded symmetry-preserving coordinate refinement for the accepted phases."""

from __future__ import annotations

import argparse
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def lattice_matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    al, be, ga = np.deg2rad([cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(ga), b * np.sin(ga), 0.0])
    cx = c * np.cos(be)
    cy = c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga)
    cz = np.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.vstack((va, vb, np.array([cx, cy, cz])))


def reference_atoms(project: G2sc.G2Project) -> dict[tuple[str, str], np.ndarray]:
    return {(p.name, a.label): np.array(a.coordinates, dtype=float)
            for p in project.phases() for a in p.atoms()}


def shifts(project: G2sc.G2Project,
           refs: dict[tuple[str, str], np.ndarray]) -> dict[tuple[str, str], float]:
    out: dict[tuple[str, str], float] = {}
    for phase in project.phases():
        mat = lattice_matrix(phase.get_cell())
        for atom in phase.atoms():
            delta = (np.array(atom.coordinates) - refs[(phase.name, atom.label)] + 0.5) % 1.0 - 0.5
            out[(phase.name, atom.label)] = float(np.linalg.norm(delta @ mat))
    return out


def report(project: G2sc.G2Project, label: str,
           refs: dict[tuple[str, str], np.ndarray]) -> None:
    hist = project.histograms()[0]
    print(f"[{label}] Rwp={hist.get_wR():.6f} fractions={hist.ComputeMassFracs()}")
    ds = shifts(project, refs)
    for phase in project.phases():
        print(" ", phase.name, ", ".join(f"{a.label}={ds[(phase.name, a.label)]:.4f} A"
                                          for a in phase.atoms()))


def set_limits(project: G2sc.G2Project, names: list[str], bound: float) -> None:
    for name in names:
        project.set_Controls("parmMin", -bound, variable=name)
        project.set_Controls("parmMax", bound, variable=name)


def freeze_atoms(project: G2sc.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def run_step(project: G2sc.G2Project, out: Path, label: str,
             refs: dict[tuple[str, str], np.ndarray]) -> G2sc.G2Project:
    previous = float(project.histograms()[0].get_wR())
    pre = out.with_name(out.stem + f"_pre_{label}.gpx")
    project.save()
    shutil.copy2(out, pre)
    project.refine()
    now = float(project.histograms()[0].get_wR())
    max_shift = max(shifts(project, refs).values())
    if not math.isfinite(now) or now > previous + 0.02 or max_shift > 0.12:
        print(f"[{label}] rollback previous={previous:.6f} attempted={now:.6f} max_shift={max_shift:.4f} A")
        shutil.copy2(pre, out)
        return G2sc.G2Project(str(out))
    report(project, label, refs)
    project.save()
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=ROOT / ".tmp" / "gsas" / "profile_w20.gpx")
    parser.add_argument("--out", type=Path, default=ROOT / ".tmp" / "gsas" / "bounded_coordinates.gpx")
    parser.add_argument("--oxygen", action="store_true")
    args = parser.parse_args()
    out = args.out.resolve()
    shutil.copy2(args.base.resolve(), out)
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["U"][2] = False
    for phase in project.phases()[:2]:
        phase.data["Histograms"][hist.name]["Mustrain"][2][0] = False
    freeze_atoms(project)
    refs = reference_atoms(project)
    report(project, "start", refs)

    heavy = {
        "MnWO4": ["Mn1", "W1"],
        "Mn3WO6": ["Mn1"],
        "WO3": ["W1", "W2"],
    }
    for phase_name, labels in heavy.items():
        project.phase(phase_name).set_refinements({"Atoms": {label: "X" for label in labels}})
    set_limits(project, ["0::dAy:0", "0::dAy:1"], 0.010)
    set_limits(project, [f"1::dA{axis}:0" for axis in "xyz"], 0.006)
    set_limits(project, [f"2::dA{axis}:{idx}" for idx in (1, 7) for axis in "xyz"], 0.007)
    project = run_step(project, out, "heavy", refs)
    freeze_atoms(project)
    project.data["Controls"]["data"]["parmFrozen"] = {}

    if args.oxygen:
        oxygen_specs = [
            ("MnWO4", 0, [2, 3], 0.010),
            ("Mn3WO6", 1, [3, 4], 0.006),
            ("WO3", 2, [0, 2, 3, 4, 5, 6], 0.007),
        ]
        for phase_name, pidx, indices, bound in oxygen_specs:
            phase = project.phase(phase_name)
            labels = [phase.atoms()[idx].label for idx in indices]
            phase.set_refinements({"Atoms": {label: "X" for label in labels}})
            set_limits(project, [f"{pidx}::dA{axis}:{idx}" for idx in indices for axis in "xyz"], bound)
            project = run_step(project, out, "oxygen-" + phase_name, refs)
            freeze_atoms(project)
            project.data["Controls"]["data"]["parmFrozen"] = {}

    report(project, "final", refs)
    project.save()


if __name__ == "__main__":
    main()
