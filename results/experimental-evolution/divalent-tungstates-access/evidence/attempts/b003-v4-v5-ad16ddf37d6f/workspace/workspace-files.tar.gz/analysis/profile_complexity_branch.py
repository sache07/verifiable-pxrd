#!/usr/bin/env python3
"""Test one additional, physically bounded profile term in an isolated branch."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def prepare(project: G2sc.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 8)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--mode", choices=("instrument", "mustrain"), required=True)
    parser.add_argument("--parameter", choices=("U", "V", "X", "Y", "SH/L"))
    parser.add_argument("--phase")
    parser.add_argument("--strain-type", choices=("isotropic", "uniaxial"), default="isotropic")
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--strain-start", type=float, default=500.0)
    parser.add_argument("--strain-ratio", type=float,
                        help="fix axial/equatorial strain to this ratio")
    args = parser.parse_args()

    shutil.copy2(args.base.resolve(), args.out.resolve())
    project = G2sc.G2Project(str(args.out.resolve()))
    prepare(project)
    hist = project.histograms()[0]

    if args.mode == "instrument":
        if args.parameter is None:
            parser.error("--mode instrument requires --parameter")
        item = hist.data["Instrument Parameters"][0][args.parameter]
        if args.parameter == "U" and item[1] <= 0:
            item[1] = 1.0
        item[2] = True
    else:
        if args.phase is None:
            parser.error("--mode mustrain requires --phase")
        if args.strain_type == "uniaxial" and args.axis is None:
            parser.error("uniaxial mustrain requires --axis h k l")
        mustrain = project.phase(args.phase).data["Histograms"][hist.name]["Mustrain"]
        mustrain[0] = args.strain_type
        mustrain[1][0] = args.strain_start
        mustrain[2][0] = True
        mustrain[2][1] = False
        mustrain[2][2] = False
        if args.strain_type == "uniaxial":
            ratio = args.strain_ratio if args.strain_ratio is not None else 1.0
            mustrain[1][1] = args.strain_start * ratio
            mustrain[2][1] = True
            mustrain[3] = list(args.axis)

    project.save()
    if args.mode == "mustrain" and args.strain_type == "uniaxial" \
            and args.strain_ratio is not None:
        project.update_ids()
        phase = project.phase(args.phase)
        project.add_EquivConstr(
            (f"{phase.id}:{hist.id}:Mustrain;i", f"{phase.id}:{hist.id}:Mustrain;a"),
            [args.strain_ratio, 1.0], override=True
        )

    before = hist.get_wR()
    project.save()
    project.refine()
    hist = project.histograms()[0]
    print("Rwp", before, "->", hist.get_wR())
    print("fractions", hist.ComputeMassFracs())
    print("instrument", hist.data["Instrument Parameters"][0])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("profile", phase.name, "size", hap["Size"][:4],
              "mustrain", hap["Mustrain"][:4])
    print("frozen", project.data["Controls"]["data"].get("parmFrozen"))
    project.save()


if __name__ == "__main__":
    main()
