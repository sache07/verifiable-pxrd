#!/usr/bin/env python3
"""Print compact diagnostics and plot a GSAS-II powder fit."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


def main() -> None:
    path = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve() if len(sys.argv) > 2 else path.with_suffix(".fit.csv")
    project = G2sc.G2Project(str(path))
    hist = project.histograms()[0]
    arr = hist.data["data"][1]
    x = np.asarray(arr[0], dtype=float)
    yobs = np.asarray(arr[1], dtype=float)
    wt = np.asarray(arr[2], dtype=float)
    ycalc = np.asarray(arr[3], dtype=float)
    ybkg = np.asarray(arr[4], dtype=float)
    diff = yobs - ycalc
    print("project", path)
    print("histogram", hist.name, "Rwp", hist.get_wR(), "residuals", hist.data["data"][0])
    print("mass fractions", hist.ComputeMassFracs())
    print("background", hist.data["Background"])
    print("instrument", hist.data["Instrument Parameters"][0])
    print("sample", hist.data["Sample Parameters"])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print("phase", phase.name, "cell", phase.get_cell(), "scale", hap["Scale"])
        print("  size", hap["Size"], "mustrain", hap["Mustrain"], "PO", hap["Pref.Ori."])

    mag = np.abs(diff)
    pk = np.flatnonzero((mag[1:-1] > mag[:-2]) & (mag[1:-1] >= mag[2:])) + 1
    order = pk[np.argsort(mag[pk])[::-1]]
    print("largest residual extrema")
    for i in order[:60]:
        print(f"{x[i]:9.4f} obs={yobs[i]:9.1f} calc={ycalc[i]:9.1f} diff={diff[i]:+9.1f}")

    np.savetxt(out, np.column_stack((x, yobs, ycalc, ybkg, diff, wt)), delimiter=",",
               header="two_theta_deg,observed,calculated,background,difference,weight",
               comments="", fmt="%.10g")
    print("profile", out)


if __name__ == "__main__":
    main()
