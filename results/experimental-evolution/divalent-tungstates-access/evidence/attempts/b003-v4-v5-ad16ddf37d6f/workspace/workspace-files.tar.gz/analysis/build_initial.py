#!/usr/bin/env python3
"""Build and lightly refine a chemically constrained initial GSAS-II model."""

from __future__ import annotations

import argparse
import os
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / ".tmp" / "gsas"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def report(project: G2sc.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    print(f"\n[{label}] Rwp={hist.get_wR()!r}")
    print("instrument", {k: v for k, v in hist.data["Instrument Parameters"][0].items()
                         if k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")})
    print("sample", hist.data["Sample Parameters"])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.name, "cell", phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"], "mustrain", hap["Mustrain"])


def main(wo3_id: str = "1528915", output: Path | None = None) -> None:
    WORK.mkdir(parents=True, exist_ok=True)
    data = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    xye = WORK / "pattern.xye"
    np.savetxt(xye, np.column_stack((data[:, 0], data[:, 1], np.sqrt(np.maximum(data[:, 1], 1.0)))),
               fmt=("%.8f", "%.8f", "%.8f"))

    instprm = WORK / "cu_ka.instprm"
    instprm.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )

    gpx = output.resolve() if output is not None else WORK / "initial_3phase.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(xye), str(instprm), fmthint="xye")
    candidates = [
        ("MnWO4", "1520200"),
        ("Mn3WO6", "2002703"),
        ("WO3", wo3_id),
    ]
    for name, cod_id in candidates:
        project.add_phase(str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF")

    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 10,
            "coeffs": [3600.0] + [0.0] * 9,
            "refine": True,
        },
    })
    hist.data["Sample Parameters"]["Scale"][1] = False
    # The coherent families are displaced by about -0.23 deg at low angle,
    # corresponding to roughly +0.40 mm specimen height at R=200 mm.
    hist.data["Sample Parameters"]["Shift"][0] = 400.0
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.set_Controls("cycles", 8)
    project.save()
    report(project, "start")
    project.refine()
    report(project, "background+scales")
    hist = project.histograms()[0]
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    report(project, "shift")
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.refine()
    report(project, "cells")
    project.save()
    shutil.copy2(gpx, WORK / f"base_cells_{wo3_id}.gpx")
    if wo3_id == "1528915":
        shutil.copy2(gpx, WORK / "base_cells.gpx")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3-id", default="1528915")
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    os.chdir(ROOT)
    main(args.wo3_id, args.out)
