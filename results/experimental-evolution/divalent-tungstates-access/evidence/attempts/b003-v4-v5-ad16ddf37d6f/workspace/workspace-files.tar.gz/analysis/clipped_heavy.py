#!/usr/bin/env python3
"""Project an unconstrained coordinate direction onto a physical displacement radius."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    al, be, ga = np.deg2rad([cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(ga), b * np.sin(ga), 0.0])
    cx = c * np.cos(be)
    cy = c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga)
    return np.vstack((va, vb, [cx, cy, np.sqrt(max(c*c-cx*cx-cy*cy, 0.0))]))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=ROOT / ".tmp" / "gsas" / "profile_w20.gpx")
    parser.add_argument("--direction", type=Path, default=ROOT / ".tmp" / "gsas" / "coordinates_heavy.gpx")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--max-shift", type=float, required=True, help="maximum heavy-atom displacement in angstrom")
    args = parser.parse_args()
    out = args.out.resolve()
    shutil.copy2(args.base.resolve(), out)
    project = G2sc.G2Project(str(out))
    target = G2sc.G2Project(str(args.direction.resolve()))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 8)
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["U"][2] = False
    for phase in project.phases()[:2]:
        phase.data["Histograms"][hist.name]["Mustrain"][2][0] = False

    selected = {"MnWO4": {"Mn1", "W1"}, "Mn3WO6": {"Mn1"}, "WO3": {"W1", "W2"}}
    for phase in project.phases():
        tphase = target.phase(phase.name)
        tcoords = {a.label: np.array(a.coordinates, dtype=float) for a in tphase.atoms()}
        mat = matrix(phase.get_cell())
        for atom in phase.atoms():
            atom.refinement_flags = " "
            if atom.label not in selected[phase.name]:
                continue
            ref = np.array(atom.coordinates, dtype=float)
            delta = (tcoords[atom.label] - ref + 0.5) % 1.0 - 0.5
            dist = float(np.linalg.norm(delta @ mat))
            if dist > args.max_shift:
                delta *= args.max_shift / dist
                dist = args.max_shift
            atom.coordinates = tuple(ref + delta)
            print(phase.name, atom.label, "applied_shift_A", dist)

    project.save()
    before = project.histograms()[0].get_wR()
    project.refine()
    after = project.histograms()[0].get_wR()
    print("Rwp", before, "->", after)
    print("fractions", project.histograms()[0].ComputeMassFracs())
    project.save()


if __name__ == "__main__":
    main()
