#!/usr/bin/env python3
"""Make one isolated specimen/intensity-correction refinement branch."""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def prepare(project: G2sc.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 8)
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["U"][2] = False
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
        if mustrain[0] == "isotropic" and mustrain[1][0] <= 0:
            mustrain[2][0] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument(
        "--mode", choices=("surface", "polarization", "po", "shl"), required=True
    )
    parser.add_argument("--phase")
    parser.add_argument("--axis", nargs=3, type=int)
    parser.add_argument("--surface-start", nargs=2, type=float, default=(0.2, 0.1))
    args = parser.parse_args()

    shutil.copy2(args.base.resolve(), args.out.resolve())
    project = G2sc.G2Project(str(args.out.resolve()))
    prepare(project)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    if args.mode == "surface":
        sample["SurfRoughA"] = [float(args.surface_start[0]), True]
        sample["SurfRoughB"] = [float(args.surface_start[1]), True]
    elif args.mode == "polarization":
        inst["Polariz."][2] = True
    elif args.mode == "shl":
        inst["SH/L"][2] = True
    elif args.mode == "po":
        if not args.phase or args.axis is None:
            parser.error("--mode po requires --phase and --axis h k l")
        po = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(args.axis)

    before = hist.get_wR()
    project.save()
    project.refine()
    hist = project.histograms()[0]
    print("Rwp", before, "->", hist.get_wR())
    print("fractions", hist.ComputeMassFracs())
    print("surface", hist.data["Sample Parameters"]["SurfRoughA"],
          hist.data["Sample Parameters"]["SurfRoughB"])
    print("polarization", hist.data["Instrument Parameters"][0]["Polariz."])
    print("SH/L", hist.data["Instrument Parameters"][0]["SH/L"])
    for phase in project.phases():
        print("PO", phase.name,
              phase.data["Histograms"][hist.name]["Pref.Ori."][:4])
    project.save()


if __name__ == "__main__":
    main()
