#!/usr/bin/env python3
"""Create the full-grid final GSAS-II project and all requested deliverables."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / ".tmp" / "gsas" / "prof_aniso_WO3_001.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = {
    "MnWO4": {"formula": "MnWO4", "cod_id": "1520200", "cif": "phase_MnWO4.cif"},
    "Mn3WO6": {"formula": "Mn3WO6", "cod_id": "2002703", "cif": "phase_Mn3WO6.cif"},
    "WO3": {"formula": "WO3", "cod_id": "2311041", "cif": "phase_WO3.cif"},
}


def main() -> None:
    pattern = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    shutil.copy2(BASE, FINAL)
    project = G2sc.G2Project(str(FINAL))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 8)
    hist = project.histograms()[0]
    hist.set_refinements({"Limits": [float(pattern[0, 0]), float(pattern[-1, 0])]})
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.save()
    before = hist.get_wR()
    project.refine()
    project.save()

    # Reopen from disk: all exported values therefore come from the submitted GPX.
    project = G2sc.G2Project(str(FINAL))
    hist = project.histograms()[0]
    profile = hist.data["data"][1]
    x = np.asarray(profile[0], dtype=float)
    yobs = np.asarray(profile[1], dtype=float)
    ycalc = np.asarray(profile[3], dtype=float)
    if len(x) != len(pattern) or not np.allclose(x, pattern[:, 0], atol=2e-7, rtol=0):
        raise RuntimeError("GSAS-II profile grid does not match inputs/pattern.csv")
    if not np.allclose(yobs, pattern[:, 1], atol=1e-6, rtol=0):
        raise RuntimeError("GSAS-II observed profile does not match inputs/pattern.csv")
    if np.any(~np.isfinite(ycalc)) or ycalc[0] == 0 or ycalc[-1] == 0:
        raise RuntimeError("calculated profile is incomplete on the requested full grid")
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((pattern[:, 0], pattern[:, 1], ycalc, pattern[:, 1] - ycalc)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )

    mass = hist.ComputeMassFracs()
    total = sum(value for value, _ in mass.values())
    phases = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        phase.export_CIF(str(ROOT / info["cif"]))
        value, sigma = mass[phase.name]
        phases.append({
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "reference_cod_id": info["cod_id"],
            "cif_path": info["cif"],
            "weight_fraction": value / total,
            "formal_weight_fraction_standard_uncertainty": sigma / total,
        })

    residuals = hist.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    fit_stats = {
        "rwp_percent": rwp,
        "rp_percent": float(residuals["R"]),
        "weighted_background_r_percent": float(residuals["wRb"]),
        "expected_r_percent": rexp,
        "goodness_of_fit": rwp / rexp,
        "reduced_chi_squared": (rwp / rexp) ** 2,
        "durbin_watson": float(hist.data["data"][0]["Durbin-Watson"]),
        "n_observations": int(hist.data["data"][0]["Nobs"]),
    }
    result = {
        "phases": phases,
        "weight_fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": fit_stats,
        "gsasii_project": "final.gpx",
        "profile": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    by_name = {item["name"]: item for item in phases}
    report = f"""# Powder XRD phase analysis

## Result

The crystalline pattern is modeled by three phases: MnWO4, Mn3WO6, and WO3. Their crystalline-normalized weight fractions are {100*by_name['MnWO4']['weight_fraction']:.2f}%, {100*by_name['Mn3WO6']['weight_fraction']:.2f}%, and {100*by_name['WO3']['weight_fraction']:.2f}%, respectively. The full-grid fit has Rwp = {fit_stats['rwp_percent']:.3f}%, Rp = {fit_stats['rp_percent']:.3f}%, Rexp = {fit_stats['expected_r_percent']:.3f}%, and goodness of fit = {fit_stats['goodness_of_fit']:.3f}.

## Evidence and model

Peak positions and whole-family intensity support were obtained with MnWO4 (wolframite, P2/c; COD 1520200), Mn3WO6 (rhombohedral, R-3; COD 2002703), and monoclinic WO3 (P21/c; COD 2311041). Together these phases index the coherent low- and high-angle reflection families; after the three-phase refinement there is no residual family requiring Mn3O4 or another crystalline phase. The phase assemblage is chemically consistent with firing WO3 and Mn3O4 at 800 C, and the refined assemblage has an overall Mn:W molar ratio near 1.03.

The refinement used the reported Cu Kalpha1/Kalpha2 wavelengths and 0.5 intensity ratio, Poisson counting weights, a ten-term smooth background, specimen displacement, lattice parameters, phase scales, isotropic crystallite sizes, polarization, and physically supported March-Dollase texture. MnWO4 required [010] uniaxial microstrain; the axial/equatorial ratio was held at the physical upper bound of 4. WO3 and Mn3WO6 retained smaller strain terms. Heavy-atom shifts were accepted only where stable and small, and MnWO4 oxygen shifts were capped at 0.03 A. Exported structures retain normal coordination: W-O spans approximately 1.80-2.10 A in MnWO4, 1.90-1.94 A in Mn3WO6, and 1.71-2.16 A in WO3, with no short O-O contacts.

For WO3, an older exact-composition P21/n reference (COD 1528915) gave a slightly smaller preliminary Rwp but contains an approximately 1.57 A O-O contact and an under-coordinated W site. It was rejected in favor of the physical COD 2311041 model. A triclinic WO3 alternative (COD 2106293) also fit slightly worse. No further prototype search was made after all coherent families were assigned.

## Uncertainty

Phase identities are high confidence. The listed GSAS-II fraction standard uncertainties are counting-statistical only and are too optimistic for texture/profile/reference-model uncertainty; a realistic uncertainty is about 1-2 weight-percentage points per phase. Fractions are normalized only over the modeled crystalline material, so this analysis does not measure amorphous content. The topology and coordination of each structure are reliable, but the small refined atomic displacements should not be interpreted as high-precision independent structure determinations from this powder pattern.
"""
    (ROOT / "report.md").write_text(report)
    print("Rwp", before, "->", hist.get_wR())
    print("fractions", mass)
    print("statistics", fit_stats)


if __name__ == "__main__":
    main()
