#!/usr/bin/env python3
"""Refine heavy- then light-atom coordinates with physical rollback checks."""

from __future__ import annotations

import argparse
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def lattice_matrix(cell: dict[str, float]) -> np.ndarray:
    a, b, c = cell["length_a"], cell["length_b"], cell["length_c"]
    al, be, ga = np.deg2rad([cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(ga), b * np.sin(ga), 0.0])
    cx = c * np.cos(be)
    cy = c * (np.cos(al) - np.cos(be) * np.cos(ga)) / np.sin(ga)
    cz = np.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.vstack((va, vb, np.array([cx, cy, cz])))


def reference_atoms(project: G2sc.G2Project) -> dict[tuple[str, str], tuple[str, np.ndarray]]:
    return {(phase.name, atom.label): (atom.element.split("+")[0].split("-")[0],
                                       np.array(atom.coordinates, dtype=float))
            for phase in project.phases() for atom in phase.atoms()}


def atom_shifts(project: G2sc.G2Project,
                refs: dict[tuple[str, str], tuple[str, np.ndarray]]) -> dict[tuple[str, str], float]:
    shifts: dict[tuple[str, str], float] = {}
    for phase in project.phases():
        mat = lattice_matrix(phase.get_cell())
        for atom in phase.atoms():
            _, old = refs[(phase.name, atom.label)]
            new = np.array(atom.coordinates, dtype=float)
            delta = (new - old + 0.5) % 1.0 - 0.5
            shifts[(phase.name, atom.label)] = float(np.linalg.norm(delta @ mat))
    return shifts


def is_physical(project: G2sc.G2Project,
                refs: dict[tuple[str, str], tuple[str, np.ndarray]]) -> bool:
    for (phase_name, label), shift in atom_shifts(project, refs).items():
        element = refs[(phase_name, label)][0]
        limit = 0.20 if element != "O" else 0.35
        if not math.isfinite(shift) or shift > limit:
            return False
    hist = project.histograms()[0]
    return all(0.015 <= p.data["Histograms"][hist.name]["Size"][1][0] <= 2.0
               for p in project.phases())


def summary(project: G2sc.G2Project, label: str,
            refs: dict[tuple[str, str], tuple[str, np.ndarray]]) -> None:
    hist = project.histograms()[0]
    print(f"[{label}] Rwp={hist.get_wR():.6f} fractions={hist.ComputeMassFracs()}")
    shifts = atom_shifts(project, refs)
    for phase in project.phases():
        vals = ", ".join(f"{a.label}:{shifts[(phase.name, a.label)]:.4f}A"
                         for a in phase.atoms())
        print(f"  {phase.name} shifts {vals}")


def refine_keep(project: G2sc.G2Project, out: Path, label: str,
                refs: dict[tuple[str, str], tuple[str, np.ndarray]]) -> G2sc.G2Project:
    previous = float(project.histograms()[0].get_wR())
    checkpoint = out.with_name(out.stem + f"_pre_{label}.gpx")
    project.save()
    shutil.copy2(out, checkpoint)
    project.refine()
    current = float(project.histograms()[0].get_wR())
    ok = math.isfinite(current) and current <= previous + 0.02 and is_physical(project, refs)
    if not ok:
        print(f"[{label}] rollback previous={previous:.6f} attempted={current:.6f} "
              f"physical={is_physical(project, refs)}")
        shutil.copy2(checkpoint, out)
        return G2sc.G2Project(str(out))
    summary(project, label, refs)
    project.save()
    return project


def set_coordinate_flags(phase: G2sc.G2Phase, labels: list[str]) -> None:
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=ROOT / ".tmp" / "gsas" / "profile_w20.gpx")
    parser.add_argument("--out", type=Path, default=ROOT / ".tmp" / "gsas" / "coordinates.gpx")
    parser.add_argument("--oxygen", action="store_true")
    args = parser.parse_args()
    out = args.out.resolve()
    shutil.copy2(args.base.resolve(), out)
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 8)
    # Frozen-at-bound variables from exploratory profile fits should not remain
    # in Controls when entering coordinate refinement.
    project.data["Controls"]["data"]["parmFrozen"] = {}
    refs = reference_atoms(project)
    summary(project, "start", refs)

    heavy_by_phase = {
        "MnWO4": ["Mn1", "W1"],
        "Mn3WO6": ["Mn1"],
        "WO3": ["W1", "W2"],
    }
    for phase_name in ("MnWO4", "Mn3WO6", "WO3"):
        set_coordinate_flags(project.phase(phase_name), heavy_by_phase[phase_name])
        project = refine_keep(project, out, "heavy-" + phase_name, refs)

    if args.oxygen:
        for phase_name in ("MnWO4", "Mn3WO6", "WO3"):
            phase = project.phase(phase_name)
            labels = [atom.label for atom in phase.atoms() if atom.element.split("-")[0] == "O"]
            set_coordinate_flags(phase, labels)
            project = refine_keep(project, out, "oxygen-" + phase_name, refs)

    summary(project, "final", refs)
    project.save()


if __name__ == "__main__":
    main()
