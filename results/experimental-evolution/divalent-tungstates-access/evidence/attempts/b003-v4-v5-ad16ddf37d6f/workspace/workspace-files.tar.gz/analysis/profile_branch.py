#!/usr/bin/env python3
"""Explore bounded, physical profile refinements from the 3-phase cell fit."""

from __future__ import annotations

import argparse
import math
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def summary(project: G2sc.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    print(f"[{label}] Rwp={hist.get_wR():.6f} U={inst['U'][1]:.5g} W={inst['W'][1]:.5g} "
          f"X={inst['X'][1]:.5g} SH/L={inst['SH/L'][1]:.5g}")
    print("  fractions", hist.ComputeMassFracs())
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(f"  {phase.name}: size={hap['Size'][1][0]:.6g} um "
              f"strain={hap['Mustrain'][1][0]:.6g} ppm scale={hap['Scale'][0]:.6g}")


def physical(project: G2sc.G2Project) -> bool:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    if not (0.0 <= inst["U"][1] <= 50.0 and 1.0 <= inst["W"][1] <= 50.0):
        return False
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if not (0.02 <= hap["Size"][1][0] <= 2.0):
            return False
        if not (0.0 <= hap["Mustrain"][1][0] <= 12000.0):
            return False
    return True


def refine_keep(project: G2sc.G2Project, out: Path, label: str) -> G2sc.G2Project:
    hist = project.histograms()[0]
    previous = float(hist.get_wR())
    checkpoint = out.with_name(out.stem + f"_pre_{label}.gpx")
    project.save()
    shutil.copy2(out, checkpoint)
    project.refine()
    current = float(project.histograms()[0].get_wR())
    if (not math.isfinite(current)) or current > previous + 0.02 or not physical(project):
        print(f"[{label}] rollback: previous Rwp={previous:.6f}, attempted={current:.6f}, "
              f"physical={physical(project)}")
        shutil.copy2(checkpoint, out)
        project = G2sc.G2Project(str(out))
    else:
        summary(project, label)
        project.save()
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=ROOT / ".tmp" / "gsas" / "base_cells.gpx")
    parser.add_argument("--out", type=Path, default=ROOT / ".tmp" / "gsas" / "profile_w20.gpx")
    parser.add_argument("--w", type=float, default=20.0)
    parser.add_argument("--u", type=float, default=10.0)
    parser.add_argument("--size", type=float, default=0.12)
    args = parser.parse_args()
    out = args.out.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.base.resolve(), out)
    project = G2sc.G2Project(str(out))
    project.set_Controls("cycles", 8)
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key in ("U", "W", "X", "SH/L"):
        inst[key][2] = False
    inst["U"][1] = args.u
    inst["W"][1] = args.w
    for pidx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = args.size
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        project.set_Controls("parmMin", 0.02, variable=f"{pidx}:0:Size;i")
        project.set_Controls("parmMax", 2.0, variable=f"{pidx}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
        project.set_Controls("parmMax", 12000.0, variable=f"{pidx}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 50.0, variable=":0:U")
    project.set_Controls("parmMin", 1.0, variable=":0:W")
    project.set_Controls("parmMax", 50.0, variable=":0:W")
    project.save()
    summary(project, "profile-start")
    project = refine_keep(project, out, "fixed-profile")

    for pidx in range(len(project.phases())):
        phase = project.phases()[pidx]
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}},
                                  [project.histograms()[0]])
        project = refine_keep(project, out, f"size-{pidx}")

    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    project = refine_keep(project, out, "instrument-UW")

    for pidx in range(len(project.phases())):
        phase = project.phases()[pidx]
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}},
                                  [project.histograms()[0]])
        project = refine_keep(project, out, f"strain-{pidx}")

    summary(project, "final-profile")
    project.save()


if __name__ == "__main__":
    main()
