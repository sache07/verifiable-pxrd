#!/usr/bin/env python3
"""Screen March-Dollase axes one phase at a time in a common project state."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_structure import clear_all_flags, enable_scales, mass_fractions


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--cycles", type=int, default=5)
    args = ap.parse_args()
    base = args.base.resolve()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []
    for pidx in range(4):
        for axis in AXES:
            token = f"p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            project = G2.G2Project(gpxfile=str(base))
            project.filename = str(out / f"{token}.gpx")
            project.set_Controls("cycles", args.cycles)
            project.set_Frozen()
            clear_all_flags(project)
            enable_scales(project)
            phase = project.phases()[pidx]
            hap = phase.data["Histograms"][project.histograms()[0].name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(axis)
            phase.set_HAP_refinements({"Pref.Ori.": True})
            project.set_Controls("parmMin", 0.70, f"{pidx}:0:MD")
            project.set_Controls("parmMax", 1.40, f"{pidx}:0:MD")
            project.refine(makeBack=False)
            project.save(str(out / f"{token}.gpx"))
            hist = project.histograms()[0]
            row = {
                "token": token, "phase_index": pidx, "phase": phase.name,
                "axis": list(axis), "ratio": hap["Pref.Ori."][1],
                "rwp_percent": hist.get_wR(),
                "fractions": mass_fractions(project, hist),
                "frozen": project.get_Frozen(),
            }
            results.append(row)
            print(json.dumps(row))
    (out / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
