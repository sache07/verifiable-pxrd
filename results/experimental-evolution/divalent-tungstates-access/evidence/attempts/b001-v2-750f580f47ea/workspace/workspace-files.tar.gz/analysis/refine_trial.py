#!/usr/bin/env python3
"""Create and stage a shared multiphase GSAS-II Rietveld trial.

Run with the GSAS-II Python interpreter. This is intentionally a small,
transparent driver so every candidate is evaluated against the same scan,
instrument model and refinement sequence.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


ROOT = Path(__file__).resolve().parents[1]
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    return (
        "# Cu Kalpha laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def fractions(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        raw[phase.name] = max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"])
    total = sum(raw.values())
    return {name: value / total if total else 0.0 for name, value in raw.items()}


def snapshot(project: G2.G2Project, out: Path, label: str) -> None:
    # Keep each stage immutable. G2Project.save(new_name) changes the active
    # project filename, so later refinements would otherwise overwrite the
    # nominally earlier snapshot.
    current = out / "trial.gpx"
    project.save(str(current))
    shutil.copy2(current, out / f"{label}.gpx")
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "gof": hist.data["data"][0].get("GOF"),
        "fractions": fractions(project, hist.name),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()},
        "size": {p.name: p.data["Histograms"][hist.name]["Size"] for p in project.phases()},
        "mustrain": {p.name: p.data["Histograms"][hist.name]["Mustrain"] for p in project.phases()},
        "instrument": {k: v for k, v in inst.items() if k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]},
        "sample": {k: v for k, v in sample.items() if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"]},
    }
    (out / f"{label}.json").write_text(json.dumps(row, indent=2, default=str) + "\n")
    print(json.dumps({"label": label, "rwp": row["rwp_percent"], "fractions": row["fractions"]}))


def refine(project: G2.G2Project, out: Path, label: str) -> None:
    project.refine(makeBack=False)
    snapshot(project, out, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("outdir", type=Path)
    parser.add_argument("ids", nargs="+", help="COD IDs, in phase order")
    parser.add_argument("--names", nargs="*", default=None)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--pool", type=Path, default=None,
                        help="Optional registered-model pool (uses models/cod<ID>.cif)")
    parser.add_argument("--stop-after-nuisance", action="store_true")
    parser.add_argument("--fixed-shift", type=float, default=None)
    parser.add_argument("--fixed-zero", type=float, default=None)
    parser.add_argument("--no-roughness", action="store_true")
    args = parser.parse_args()

    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    inst_path = out / "instrument.instprm"
    inst_path.write_text(instrument_text())
    project = G2.G2Project(newgpx=str(out / "trial.gpx"))
    G2.SetPrintLevel("warn")

    names = args.names if args.names else args.ids
    if len(names) != len(args.ids):
        raise ValueError("--names must match number of IDs")
    phases = []
    for name, cod_id in zip(names, args.ids):
        source = ((args.pool.resolve() / "models" / f"cod{cod_id}.cif")
                  if args.pool else cod_path(cod_id))
        if not source.is_file():
            raise FileNotFoundError(source)
        phases.append(project.add_phase(str(source), phasename=name, fmthint="CIF"))

    hist = project.add_powder_histogram(
        str((ROOT / "inputs" / "pattern.csv").resolve()),
        str(inst_path), phases=phases, fmthint="comma/tab/semicolon separated"
    )
    hist.set_refinements({"Limits": [9.90343322, 100.09455322]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [
        780.0 if args.fixed_shift is None else args.fixed_shift, False
    ]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.2, False]
    hist.SampleParameters["SurfRoughB"] = [0.1, False]
    if args.no_roughness:
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
    if args.fixed_zero is not None:
        hist.data["Instrument Parameters"][0]["Zero"][1] = args.fixed_zero
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 12,
            "coeffs": [2200.0] + [0.0] * 11, "refine": False,
        }
    })
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Size"][1][1] = 0.20
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    project.set_Controls("cycles", args.cycles)
    # Keep all refinable nuisance/profile quantities inside the generator's
    # stated laboratory domain. GSAS-II freezes a parameter if it reaches a
    # bound, which also prevents negative analytic peak widths.
    bounds = {
        ":0:Shift": (-800.0, 800.0), ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0), ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        ":0:SurfRoughA": (0.0, 0.60), ":0:SurfRoughB": (0.0, 0.50),
    }
    for i, _phase in enumerate(phases):
        bounds[f"{i}:0:Scale"] = (0.0, 1.0e6)
        bounds[f"{i}:0:Size;i"] = (0.04, 1.50)
        bounds[f"{i}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    snapshot(project, out, "00_initial")

    # First place the intensity scale and smooth background with all peak
    # positions/profile terms held at physically plausible starting values.
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine(project, out, "01_scale_background")

    # The large common displacement is already close. Refine it together with
    # zero and all phase cells so phase-specific reference mismatch is absorbed.
    if args.fixed_shift is None:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    if args.fixed_zero is None:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, out, "02_positions")

    # Instrumental and phase-specific broadening are refined in one common
    # state; this avoids judging phases from isolated peak-only fits.
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    refine(project, out, "03a_instrument_gaussian")

    hist.clear_refinements({"Instrument Parameters": ["U", "W"]})
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": 0.20, "refine": True},
        })
    refine(project, out, "03b_size")

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, out, "03c_strain")

    for phase in phases:
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.set_refinements({"Instrument Parameters": ["X", "SH/L"]})
    refine(project, out, "03d_instrument_lorentzian")

    # One joint bounded recycle allows the staged estimates to equilibrate.
    project.set_Frozen()
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine(project, out, "03e_profile_joint")

    # Low-angle attenuation and angle-dependent intensities.
    if not args.no_roughness:
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, out, "04_nuisance")

    if args.stop_after_nuisance:
        project.save(str(out / "trial.gpx"))
        print(f"GSAS-II revision {GSASIIpath.GetVersionNumber()}")
        return

    # Recycle the complete physically motivated state once more after the
    # nuisance parameters settle.
    refine(project, out, "05_recycle")
    project.save(str(out / "trial.gpx"))
    print(f"GSAS-II revision {GSASIIpath.GetVersionNumber()}")


if __name__ == "__main__":
    main()
