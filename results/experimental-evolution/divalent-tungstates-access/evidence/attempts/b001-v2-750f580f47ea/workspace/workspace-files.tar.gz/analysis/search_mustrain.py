#!/usr/bin/env python3
"""Screen generator-supported uniaxial microstrain axes in a common state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_structure import clear_all_flags, enable_scales, mass_fractions


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--cycles", type=int, default=6)
    ap.add_argument("--phases", type=int, nargs="+", default=[0, 1, 2, 3])
    args = ap.parse_args()
    base = args.base.resolve()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    results = []

    for pidx in args.phases:
        for axis in AXES:
            token = f"p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            row = {"token": token, "phase_index": pidx, "axis": list(axis)}
            try:
                project = G2.G2Project(gpxfile=str(base))
                project.filename = str(out / f"{token}.gpx")
                project.set_Controls("cycles", args.cycles)
                project.set_Frozen()
                clear_all_flags(project)
                enable_scales(project)
                hist = project.histograms()[0]
                phase = project.phases()[pidx]
                row["phase"] = phase.name
                hap = phase.data["Histograms"][hist.name]
                isotropic = float(hap["Mustrain"][1][0])
                phase.setSampleProfile(hist.name, "microstrain", "uniaxial",
                                       isotropic, isotropic, list(axis), 1.0)
                phase.set_HAP_refinements({
                    "Mustrain": {
                        "type": "uniaxial",
                        "direction": list(axis),
                        "refine": True,
                    }
                })
                project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;i")
                project.set_Controls("parmMax", 8000.0, f"{pidx}:0:Mustrain;i")
                project.set_Controls("parmMin", 0.0, f"{pidx}:0:Mustrain;a")
                project.set_Controls("parmMax", 32000.0, f"{pidx}:0:Mustrain;a")
                project.refine(makeBack=False)
                project.save(str(out / f"{token}.gpx"))
                row.update({
                    "status": "refined",
                    "equatorial_ppm": hap["Mustrain"][1][0],
                    "axial_ppm": hap["Mustrain"][1][1],
                    "rwp_percent": hist.get_wR(),
                    "fractions": mass_fractions(project, hist),
                    "frozen": project.get_Frozen(),
                })
            except Exception as exc:
                # A failed numerical trial is deliberately recorded as unknown.
                row.update({"status": "unknown", "error": repr(exc)})
            results.append(row)
            print(json.dumps(row))

    (out / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
