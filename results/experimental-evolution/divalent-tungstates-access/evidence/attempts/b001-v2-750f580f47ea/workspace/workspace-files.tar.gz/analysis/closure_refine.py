#!/usr/bin/env python3
"""Ordinary closure refinement from the selected physical four-phase state."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_structure import clear_all_flags, enable_scales, mass_fractions


def save(project: G2.G2Project, out: Path, label: str) -> None:
    active = out / "closure.gpx"
    project.save(str(active))
    shutil.copy2(active, out / f"{label}.gpx")
    hist = project.histograms()[0]
    row = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "fractions": mass_fractions(project, hist),
        "uiso": {p.name: [a.uiso for a in p.atoms()] for p in project.phases()},
        "frozen": project.get_Frozen(),
    }
    (out / f"{label}.json").write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row))


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--cycles", type=int, default=12)
    args = ap.parse_args()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()))
    project.filename = str(out / "closure.gpx")
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    clear_all_flags(project)
    enable_scales(project)
    save(project, out, "00_selected")

    hist = project.histograms()[0]
    hist.set_refinements({"Background": {"refine": True}})
    project.refine(makeBack=False)
    save(project, out, "01_background_scales")

    hist.clear_refinements({"Background": False})
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    project.refine(makeBack=False)
    save(project, out, "02_uiso_scales")

    hist.set_refinements({"Background": {"refine": True}})
    project.refine(makeBack=False)
    save(project, out, "03_joint_closure")

    clear_all_flags(project)
    project.save(str(out / "closure.gpx"))


if __name__ == "__main__":
    main()
