#!/usr/bin/env python3
"""Refine symmetry-allowed coordinates and one isotropic U per phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def mass_fractions(project, hist):
    raw = {
        p.name: max(0.0, float(p.data["Histograms"][hist.name]["Scale"][0]))
        * float(p.data["General"]["Mass"])
        for p in project.phases()
    }
    total = sum(raw.values())
    return {k: v / total for k, v in raw.items()}


def snapshot(project, out, label):
    current = out / "structural.gpx"
    project.save(str(current))
    shutil.copy2(current, out / f"{label}.gpx")
    hist = project.histograms()[0]
    row = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "fractions": mass_fractions(project, hist),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "uiso": {p.name: [a.uiso for a in p.atoms()] for p in project.phases()},
        "coordinates": {
            p.name: {a.label: list(a.coordinates) for a in p.atoms()}
            for p in project.phases()
        },
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    (out / f"{label}.json").write_text(json.dumps(row, indent=2, default=str) + "\n")
    print(json.dumps({"label": label, "rwp": row["rwp_percent"], "fractions": row["fractions"]}))


def clear_all_flags(project):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hist.clear_refinements({"Background": False})
    hist.clear_refinements({
        "Instrument Parameters": [k for k, v in inst.items() if isinstance(v, list) and len(v) > 2]
    })
    hist.clear_refinements({
        "Sample Parameters": [k for k, v in sample.items() if isinstance(v, list) and len(v) > 1]
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True
        })


def enable_scales(project):
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def add_uiso_model(project):
    for pidx, phase in enumerate(project.phases()):
        for aidx, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            variable = f"{pidx}::AUiso:{aidx}"
            project.set_Controls("parmMin", 0.003, variable)
            project.set_Controls("parmMax", 0.020, variable)
        variables = [f"{pidx}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables)


def clear_atom_flags(project):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def enable_coordinates(project, pidx, elements=None, half_width=0.020):
    phase = project.phases()[pidx]
    for aidx, atom in enumerate(phase.atoms()):
        if elements is not None and atom.element not in elements:
            atom.refinement_flags = " "
            continue
        atom.refinement_flags = "X"
        for axis, value in zip("xyz", atom.coordinates):
            variable = f"{pidx}::dA{axis}:{aidx}"
            project.set_Controls("parmMin", float(value) - half_width, variable)
            project.set_Controls("parmMax", float(value) + half_width, variable)


def do_refine(project, out, label):
    project.set_Frozen()
    project.refine(makeBack=False)
    snapshot(project, out, label)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--cycles", type=int, default=6)
    args = ap.parse_args()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.base.resolve()))
    project.filename = str(out / "structural.gpx")
    project.set_Controls("cycles", args.cycles)
    G2.SetPrintLevel("warn")
    clear_all_flags(project)
    enable_scales(project)
    snapshot(project, out, "00_base")

    # The generator assigns one Uiso to every site in a phase. Equivalence
    # constraints reproduce that model exactly while allowing four values.
    add_uiso_model(project)
    do_refine(project, out, "01_uiso")
    clear_atom_flags(project)

    # Refine coordinates phase by phase so a weak phase cannot destabilize the
    # major-phase model. The bounds are deliberately wider than the stated
    # reference perturbations but keep each optimization in the parent basin.
    enable_coordinates(project, 0)
    do_refine(project, out, "02_cuwo4_xyz")
    clear_atom_flags(project)

    enable_coordinates(project, 1)
    do_refine(project, out, "03_cu3wo6_xyz")
    clear_atom_flags(project)

    enable_coordinates(project, 2, {"W"})
    do_refine(project, out, "04_wo3_w_xyz")
    clear_atom_flags(project)

    enable_coordinates(project, 2, {"O"})
    do_refine(project, out, "05_wo3_o_xyz")
    clear_atom_flags(project)

    enable_coordinates(project, 3)
    do_refine(project, out, "06_cuo_xyz")
    clear_atom_flags(project)

    # Re-equilibrate the common Uiso values after coordinates settle.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    do_refine(project, out, "07_uiso_recycle")
    clear_atom_flags(project)
    project.save(str(out / "structural.gpx"))


if __name__ == "__main__":
    main()
