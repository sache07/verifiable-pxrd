#!/usr/bin/env python3
"""Test a candidate addition by its scale in an otherwise fixed common state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_structure import clear_all_flags, enable_scales, mass_fractions


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("cif", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--name", default="candidate")
    ap.add_argument("--starts", nargs="+", type=float, default=[0.005, 0.02, 0.05])
    ap.add_argument("--cycles", type=int, default=12)
    ap.add_argument("--refine-cell", action="store_true")
    args = ap.parse_args()
    base = args.base.resolve()
    cif = args.cif.resolve()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []

    for start_fraction in args.starts:
        token = f"start_{start_fraction:.4f}".replace(".", "p")
        row = {"start_weight_fraction": start_fraction}
        try:
            project = G2.G2Project(gpxfile=str(base))
            project.filename = str(out / f"{token}.gpx")
            project.set_Controls("cycles", args.cycles)
            project.set_Frozen()
            clear_all_flags(project)
            hist = project.histograms()[0]
            total_raw = sum(
                max(0.0, float(p.data["Histograms"][hist.name]["Scale"][0]))
                * float(p.data["General"]["Mass"])
                for p in project.phases()
            )
            candidate = project.add_phase(
                str(cif), phasename=args.name, histograms=[hist], fmthint="CIF"
            )
            hap = candidate.data["Histograms"][hist.name]
            mass = float(candidate.data["General"]["Mass"])
            hap["Scale"] = [start_fraction / (1.0 - start_fraction) * total_raw / mass, False]
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 0.20
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 1000.0
            hap["Mustrain"][2] = [False, False, False]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            enable_scales(project)
            if args.refine_cell:
                candidate.set_refinements({"Cell": True})
            for pidx, _phase in enumerate(project.phases()):
                project.set_Controls("parmMin", 0.0, f"{pidx}:0:Scale")
                project.set_Controls("parmMax", 1.0e6, f"{pidx}:0:Scale")
            project.refine(makeBack=False)
            project.save(str(out / f"{token}.gpx"))
            row.update({
                "status": "refined",
                "candidate_scale": hap["Scale"][0],
                "candidate_weight_fraction": mass_fractions(project, hist)[candidate.name],
                "rwp_percent": hist.get_wR(),
                "fractions": mass_fractions(project, hist),
                "candidate_cell": candidate.get_cell(),
                "frozen": project.get_Frozen(),
            })
        except Exception as exc:
            row.update({"status": "unknown", "error": repr(exc)})
        rows.append(row)
        print(json.dumps(row))
    (out / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
