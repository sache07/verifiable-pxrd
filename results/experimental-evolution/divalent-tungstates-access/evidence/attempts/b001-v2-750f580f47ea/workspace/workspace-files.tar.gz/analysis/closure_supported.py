#!/usr/bin/env python3
"""Converge background/scales and supported Uiso values without weak-phase bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_structure import clear_all_flags, enable_scales, mass_fractions


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    row = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "fractions": mass_fractions(project, hist),
        "uiso": {p.name: [a.uiso for a in p.atoms()] for p in project.phases()},
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row))
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--cycles", type=int, default=25)
    args = ap.parse_args()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()))
    project.filename = str(out / "supported.gpx")
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    clear_all_flags(project)
    enable_scales(project)
    hist = project.histograms()[0]

    hist.set_refinements({"Background": {"refine": True}})
    project.refine(makeBack=False)
    project.save(str(out / "01_background.gpx"))
    (out / "01_background.json").write_text(
        json.dumps(state(project, "01_background"), indent=2) + "\n"
    )

    hist.clear_refinements({"Background": False})
    for pidx in (0, 1, 2):
        for atom in project.phases()[pidx].atoms():
            atom.refinement_flags = "U"
    project.refine(makeBack=False)
    project.save(str(out / "02_supported_uiso.gpx"))
    (out / "02_supported_uiso.json").write_text(
        json.dumps(state(project, "02_supported_uiso"), indent=2) + "\n"
    )

    hist.set_refinements({"Background": {"refine": True}})
    project.refine(makeBack=False)
    project.save(str(out / "03_joint.gpx"))
    (out / "03_joint.json").write_text(
        json.dumps(state(project, "03_joint"), indent=2) + "\n"
    )

    clear_all_flags(project)
    project.save(str(out / "supported.gpx"))


if __name__ == "__main__":
    main()
