#!/usr/bin/env python3
"""Refine one phase's uniaxial microstrain in an otherwise fixed common state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_structure import clear_all_flags, enable_scales, mass_fractions


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("phase", type=int)
    ap.add_argument("axis", choices=("001", "100", "010"))
    ap.add_argument("--cycles", type=int, default=15)
    args = ap.parse_args()
    axis = [int(v) for v in args.axis]
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.base.resolve()))
    project.filename = str(output)
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    clear_all_flags(project)
    enable_scales(project)
    hist = project.histograms()[0]
    phase = project.phases()[args.phase]
    hap = phase.data["Histograms"][hist.name]
    current = float(hap["Mustrain"][1][0])
    axial = (float(hap["Mustrain"][1][1])
             if hap["Mustrain"][0] == "uniaxial" else current)
    phase.setSampleProfile(hist.name, "microstrain", "uniaxial",
                           current, axial, axis, 1.0)
    phase.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}
    })
    project.set_Controls("parmMin", 0.0, f"{args.phase}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, f"{args.phase}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, f"{args.phase}:0:Mustrain;a")
    project.set_Controls("parmMax", 32000.0, f"{args.phase}:0:Mustrain;a")
    project.refine(makeBack=False)
    project.save(str(output))
    row = {
        "phase": phase.name,
        "axis": axis,
        "equatorial_ppm": hap["Mustrain"][1][0],
        "axial_ppm": hap["Mustrain"][1][1],
        "rwp_percent": hist.get_wR(),
        "fractions": mass_fractions(project, hist),
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(row, indent=2) + "\n")
    print(json.dumps(row))


if __name__ == "__main__":
    main()
