#!/usr/bin/env python3
"""Run the scorer's read-only full-grid GSAS-II replay for one project."""

import argparse
import json
import subprocess
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
GSAS_PYTHON = Path("<HOME>/.local/share/characterizagent/backends/gsas2/venv/bin/python")
WORKER = ROOT / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
OBSERVED = ROOT / "inputs/pattern.csv"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("project", type=Path)
    ap.add_argument("outdir", type=Path)
    args = ap.parse_args()
    project = args.project.resolve()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    request = {"project": str(project), "observed": str(OBSERVED), "histogram": None}
    req = out / "request.json"
    req.write_text(json.dumps(request, indent=2) + "\n")
    proc = subprocess.run(
        [str(GSAS_PYTHON), str(WORKER), str(req)], cwd=out,
        text=True, capture_output=True,
    )
    (out / "worker.log").write_text(proc.stdout + "\n" + proc.stderr)
    report = json.loads((out / "replay.json").read_text())
    if report.get("status") != "replayed":
        print(json.dumps(report, indent=2))
        raise SystemExit(proc.returncode or 2)
    with np.load(out / "prediction.npz") as z:
        y = z["observed"]
        calc = z["predicted"]
    q = 1 / np.maximum(y, 1.0)
    chi2 = float(np.sum(q * (y - calc) ** 2))
    rwp = float(100 * np.sqrt(chi2 / np.sum(q * y * y)))
    summary = {
        "project": str(project), "rwp_percent": rwp, "chi_square": chi2,
        "fractions": {p["name"]: p["weight_fraction"] for p in report["phases"]},
        "profile_review_flags": report["profile_review_flags"],
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
