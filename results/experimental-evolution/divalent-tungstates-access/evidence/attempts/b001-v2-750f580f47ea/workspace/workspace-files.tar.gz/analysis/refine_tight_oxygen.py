#!/usr/bin/env python3
"""Continue from the heavy-atom model with bounded WO3 oxygen shifts."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_structure import (
    clear_all_flags, clear_atom_flags, do_refine, enable_coordinates,
    enable_scales, snapshot,
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--half-width", type=float, default=0.008)
    ap.add_argument("--cycles", type=int, default=8)
    args = ap.parse_args()
    out = args.outdir.resolve()
    out.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.base.resolve()))
    project.filename = str(out / "structural.gpx")
    project.set_Controls("cycles", args.cycles)
    G2.SetPrintLevel("warn")
    clear_all_flags(project)
    enable_scales(project)
    snapshot(project, out, "00_heavy_atom_base")

    enable_coordinates(project, 2, {"O"}, half_width=args.half_width)
    do_refine(project, out, "01_wo3_o_tight")
    clear_atom_flags(project)

    # Existing per-phase equivalence constraints came from the parent project.
    # Re-equilibrate the phase-common Uiso values with all coordinates fixed.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    do_refine(project, out, "02_uiso_recycle")
    clear_atom_flags(project)
    project.save(str(out / "structural.gpx"))


if __name__ == "__main__":
    main()
