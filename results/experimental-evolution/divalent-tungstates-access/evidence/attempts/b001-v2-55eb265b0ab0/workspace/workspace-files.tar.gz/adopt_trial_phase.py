import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main(args):
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    phases = project.data["Phases"]
    if args.old not in phases or args.trial not in phases:
        raise KeyError(f"available phases: {list(phases)}")

    del phases[args.old]
    phases[args.old] = phases.pop(args.trial)
    phases[args.old]["General"]["Name"] = args.old

    for entry in project.names:
        if entry and entry[0] == "Phases":
            entry[:] = [entry[0]] + [name for name in entry[1:] if name != args.old]
            entry[entry.index(args.trial)] = args.old
            break

    for hist in project.histograms():
        refl = hist.data.get("Reflection Lists", {})
        refl.pop(args.old, None)
        if args.trial in refl:
            refl[args.old] = refl.pop(args.trial)

    # Trial projects can retain constraints on the disabled source phase. All
    # atom parameters in the adopted state are fixed, so those stale entries
    # should not be carried into subsequent refinements.
    for key, value in project.data.get("Constraints", {}).items():
        if key == "data" and isinstance(value, dict):
            for group in ["Hist", "HAP", "Phase", "Global"]:
                if group in value:
                    value[group] = []

    project.update_ids()
    project.save()
    print([phase.name for phase in project.phases()])


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--old", required=True)
    parser.add_argument("--trial", required=True)
    main(parser.parse_args())
