import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project):
    hist = project.histograms()[0]
    hist.clear_refinements({
        "Instrument Parameters": list(hist.InstrumentParameters),
        "Sample Parameters": [
            key for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
        ],
    })
    hist.clear_refinements({"Background": False})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True,
        })


def main(args):
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    clear_flags(project)
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    if phase is None:
        raise KeyError(args.phase)
    hap = phase.data["Histograms"][hist.name]
    if args.size_value is not None:
        hap["Size"][1][0] = args.size_value

    # Keep only a selected phase scale and profile variables active so each
    # profile/axis comparison starts from exactly the same common state.
    phase.set_HAP_refinements({"Scale": True})
    if args.mode == "scale-only":
        variables = {}
    elif args.mode == "isotropic":
        hap["Size"][1][0] = min(max(hap["Size"][1][0], 0.04), 1.5)
        hap["Mustrain"][1][0] = min(max(hap["Mustrain"][1][0], 1.0), 8000.0)
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        variables = {
            f"{phase.id}:{hist.id}:Size;i": (0.04, 1.5),
            f"{phase.id}:{hist.id}:Mustrain;i": (0.0, 8000.0),
        }
    elif args.mode == "uniaxial":
        value = min(max(hap["Mustrain"][1][0], 1.0), 8000.0)
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][1][1] = value
        phase.set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial", "direction": args.axis, "refine": True,
            },
        })
        variables = {
            f"{phase.id}:{hist.id}:Mustrain;i": (0.0, 8000.0),
            f"{phase.id}:{hist.id}:Mustrain;a": (0.0, 8000.0),
        }
    elif args.mode == "current":
        size_type = hap["Size"][0]
        strain_type = hap["Mustrain"][0]
        phase.set_HAP_refinements({
            "Size": {"type": size_type, "refine": True},
            "Mustrain": {"type": strain_type, "refine": True},
        })
        variables = {f"{phase.id}:{hist.id}:Size;i": (0.04, 1.5)}
        if size_type == "uniaxial":
            variables[f"{phase.id}:{hist.id}:Size;a"] = (0.04, 1.5)
        variables[f"{phase.id}:{hist.id}:Mustrain;i"] = (0.0, 8000.0)
        if strain_type == "uniaxial":
            variables[f"{phase.id}:{hist.id}:Mustrain;a"] = (0.0, 8000.0)
    else:
        strain_type = hap["Mustrain"][0]
        phase.set_HAP_refinements({
            "Mustrain": {"type": strain_type, "refine": True},
        })
        variables = {f"{phase.id}:{hist.id}:Mustrain;i": (0.0, 8000.0)}
        if strain_type == "uniaxial":
            variables[f"{phase.id}:{hist.id}:Mustrain;a"] = (0.0, 8000.0)

    for variable, (low, high) in variables.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine()
    project.save()

    result = {
        "phase": phase.name,
        "mode": args.mode,
        "axis": args.axis,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument(
        "--mode",
        choices=["scale-only", "isotropic", "uniaxial", "current", "strain-current"],
        required=True,
    )
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    parser.add_argument("--size-value", type=float)
    parser.add_argument("--cycles", type=int, default=20)
    main(parser.parse_args())
