from pathlib import Path
import warnings

from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parent
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c05/cif"
)
OUT = ROOT / "candidates"


def cod_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def load(cod_id: str):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return CifParser(cod_path(cod_id), occupancy_tolerance=10).parse_structures(
            primitive=False
        )[0]


def transfer(cod_id: str, replacements: dict[str, str], filename: str) -> None:
    structure = load(cod_id)
    structure.replace_species(replacements)
    CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(OUT / filename)


def main() -> None:
    OUT.mkdir(exist_ok=True)

    # Same-stoichiometry prototype transfers retained for common-state tests.
    transfer("7205001", {"Co": "Zn", "Mo": "W"}, "znwo4_p2c_comoo4.cif")
    transfer("1567215", {"Fe": "Zn"}, "znwo4_p2c_fewo4.cif")
    transfer("4000806", {"Cu": "Zn"}, "znwo4_p1_cuwo4.cif")
    transfer("1528282", {"Mo": "W"}, "znwo4_p1_znmoo4.cif")
    transfer("1549132", {"Cd": "Zn"}, "znwo4_i41a_cdwo4.cif")
    # Preserve the source's GSAS-II-compatible I2/a setting. A pymatgen
    # rewrite chooses an equivalent C2/c origin that the GSAS importer rejects.
    (OUT / "znwo4_c2c_cawo4.cif").write_text(
        cod_path("1546035").read_text().replace("Ca", "Zn")
    )
    transfer("2300504", {"Mg": "Zn", "Mo": "W"}, "znwo4_c2m_mgmoo4.cif")

    # Ordinary precursor references.
    CifWriter(load("9004178"), symprec=1e-3).write_file(OUT / "zno_wurtzite.cif")
    for cod_id, label in [
        ("1528915", "wo3_p21n"),
        ("2311041", "wo3_p21c_alt"),
        ("2106293", "wo3_p1"),
        ("2107312", "wo3_pnma"),
        ("1563541", "wo3_p21c_hp"),
    ]:
        CifWriter(load(cod_id), symprec=1e-3).write_file(OUT / f"{label}.cif")


if __name__ == "__main__":
    main()
