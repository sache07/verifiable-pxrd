import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project):
    hist = project.histograms()[0]
    hist.clear_refinements({
        "Instrument Parameters": list(hist.InstrumentParameters),
        "Sample Parameters": [
            key for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
        ],
    })
    hist.clear_refinements({"Background": False})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})


def main(args):
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    clear_flags(project)
    hist = project.histograms()[0]
    old = project.phase(args.phase)
    old_hap = old.data["Histograms"][hist.name]
    old_mass_scale = old.data["General"]["Mass"] * old_hap["Scale"][0]
    old_hap["Use"] = False

    trial_name = args.name or f"{args.phase}_trial"
    trial = project.add_phase(
        str(args.cif.resolve()), phasename=trial_name, histograms=[hist], fmthint="CIF"
    )
    new_hap = trial.data["Histograms"][hist.name]
    # HStrain has a symmetry-dependent number of terms and cannot be copied
    # across prototype symmetries. The other profile terms have compatible forms.
    for key in ["Size", "Mustrain", "Extinction", "Babinet"]:
        if key in old_hap:
            new_hap[key] = copy.deepcopy(old_hap[key])
    new_hap["Scale"] = [old_mass_scale / trial.data["General"]["Mass"], False]
    new_hap["Use"] = True
    new_hap["Pref.Ori."][0] = "MD"
    new_hap["Pref.Ori."][1] = 1.0 if args.reset_texture else old_hap["Pref.Ori."][1]
    new_hap["Pref.Ori."][2] = False
    new_hap["Pref.Ori."][3] = list(args.texture_axis or old_hap["Pref.Ori."][3])

    old_uiso = sum(atom.uiso for atom in old.atoms()) / len(old.atoms())
    for atom in trial.atoms():
        atom.uiso = old_uiso
        if args.coordinates == "all" or (args.coordinates == "heavy" and atom.element != "O"):
            atom.refinement_flags = "X"

    trial.set_refinements({"Cell": True})
    trial.set_HAP_refinements({"Scale": True})
    if args.refine_texture:
        trial.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine()
    project.save()

    result = {
        "replaced_phase": args.phase,
        "trial_phase": trial.name,
        "cif": str(args.cif),
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "cell": trial.get_cell(),
        "scale": new_hap["Scale"][0],
        "mass_scale": trial.data["General"]["Mass"] * new_hap["Scale"][0],
        "texture": new_hap["Pref.Ori."],
        "atoms": [
            {"label": atom.label, "element": atom.element, "xyz": atom.coordinates, "uiso": atom.uiso}
            for atom in trial.atoms()
        ],
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps({key: result[key] for key in ["cif", "rwp", "cell", "scale", "mass_scale"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--cif", type=Path, required=True)
    parser.add_argument("--name")
    parser.add_argument("--texture-axis", nargs=3, type=int)
    parser.add_argument("--reset-texture", action="store_true")
    parser.add_argument("--refine-texture", action="store_true")
    parser.add_argument("--coordinates", choices=["none", "heavy", "all"], default="none")
    parser.add_argument("--cycles", type=int, default=20)
    main(parser.parse_args())
