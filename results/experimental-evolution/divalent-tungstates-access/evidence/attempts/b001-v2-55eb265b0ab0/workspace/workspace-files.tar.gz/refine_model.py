from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


def write_inputs(folder: Path, pattern_csv: Path) -> tuple[Path, Path, np.ndarray, np.ndarray]:
    data = np.loadtxt(pattern_csv, delimiter=",", skiprows=1)
    x, y = data.T
    xye = folder / "pattern.xye"
    np.savetxt(xye, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")
    inst = folder / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst, x, y


def initial_background(x: np.ndarray, y: np.ndarray, count: int = 24) -> list[float]:
    knots = np.linspace(x[0], x[-1], count)
    values = []
    for pos in knots:
        mask = np.abs(x - pos) <= 1.2
        values.append(float(np.percentile(y[mask], 12)))
    # The broad background is smooth. A short moving average suppresses a knot
    # accidentally placed on a dense reflection cluster.
    values = np.asarray(values)
    values[1:-1] = (values[:-2] + 2 * values[1:-1] + values[2:]) / 4
    return values.tolist()


def phase_fractions(project: G2.G2Project, histogram_name: str) -> dict[str, float]:
    masses = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram_name]
        if hap.get("Use", True):
            masses[phase.name] = max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"])
    total = sum(masses.values())
    return {name: value / total for name, value in masses.items()} if total else masses


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    result = {
        "label": label,
        "residuals": hist.residuals,
        "fractions": phase_fractions(project, hist.name),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background[0],
        "phases": phases,
    }
    print(json.dumps(result, default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value)))
    return result


def refine_stage(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.refine()
    project.save()
    history.append(snapshot(project, label))


def set_atom_flags(phase, flags: str) -> None:
    for atom in phase.atoms():
        atom.refinement_flags = flags


def build_project(args) -> None:
    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    xye, inst, x, y = write_inputs(output.parent, args.pattern.resolve())
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    phase_specs = [
        (args.target.resolve(), "ZnWO4", 0.72),
        (args.wo3.resolve(), "WO3", 0.18),
        (args.zno.resolve(), "ZnO", 0.10),
    ]
    phases = []
    for path, name, fraction in phase_specs:
        phase = project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        phases.append(phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * fraction / phase.data["General"]["Mass"], False]
        phase.setSampleProfile(hist.name, "size", "isotropic", 0.35, LGmix=1.0)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 600.0, LGmix=0.0)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
        for atom in phase.atoms():
            atom.uiso = 0.008

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {
            "type": "lin interpolate",
            "no. coeffs": 24,
            "coeffs": initial_background(x, y),
            "refine": True,
        },
    })
    project.set_Controls("cycles", 12)
    project.save()
    history = [snapshot(project, "initial")]

    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    refine_stage(project, "scale_background", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_stage(project, "cells_zero", history)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_stage(project, "cells_zero_shift", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_stage(project, "instrument_profile", history)

    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    refine_stage(project, "phase_profiles", history)

    if args.mode == "full":
        for phase in phases:
            set_atom_flags(phase, "U")
        refine_stage(project, "atomic_displacements", history)
        set_atom_flags(phases[0], "XU")
        refine_stage(project, "target_coordinates", history)
        for phase in phases[1:]:
            set_atom_flags(phase, "XU")
        refine_stage(project, "all_coordinates", history)

    project.save()
    output.with_suffix(".summary.json").write_text(json.dumps(history, indent=2, default=str) + "\n")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--target", type=Path, required=True)
    parser.add_argument("--wo3", type=Path, default=Path("candidates/wo3_p21n.cif"))
    parser.add_argument("--zno", type=Path, default=Path("candidates/zno_wurtzite.cif"))
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--mode", choices=["screen", "full"], default="screen")
    return parser.parse_args()


if __name__ == "__main__":
    build_project(parse_args())
