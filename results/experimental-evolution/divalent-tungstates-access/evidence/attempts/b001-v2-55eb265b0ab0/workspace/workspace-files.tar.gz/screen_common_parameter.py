import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BOUNDS = {
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.1, 6.0),
    "SH/L": (0.005, 0.1),
    "Polariz.": (0.5, 1.0),
    "Zero": (-0.25, 0.25),
    "Shift": (-800.0, 800.0),
}


def clear_flags(project):
    hist = project.histograms()[0]
    hist.clear_refinements({
        "Instrument Parameters": list(hist.InstrumentParameters),
        "Sample Parameters": [
            key for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
        ],
    })
    hist.clear_refinements({"Background": False})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True,
        })


def main(args):
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    clear_flags(project)
    hist = project.histograms()[0]
    if args.parameter in hist.InstrumentParameters:
        hist.set_refinements({"Instrument Parameters": [args.parameter]})
        value = hist.InstrumentParameters[args.parameter]
    elif args.parameter in hist.SampleParameters:
        hist.set_refinements({"Sample Parameters": [args.parameter]})
        value = hist.SampleParameters[args.parameter]
    else:
        raise KeyError(args.parameter)
    if args.parameter in BOUNDS:
        low, high = BOUNDS[args.parameter]
        variable = f":{hist.id}:{args.parameter}"
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine()
    project.save()
    result = {
        "parameter": args.parameter,
        "value": value,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps(result, default=str))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--parameter", required=True)
    parser.add_argument("--cycles", type=int, default=16)
    main(parser.parse_args())
