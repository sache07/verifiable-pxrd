import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project):
    hist = project.histograms()[0]
    hist.clear_refinements({
        "Instrument Parameters": list(hist.InstrumentParameters),
        "Sample Parameters": [
            key for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
        ],
    })
    hist.clear_refinements({"Background": False})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": True,
            "Size": True,
            "Mustrain": True,
            "Pref.Ori.": True,
        })


def set_flags(project, stage):
    hist = project.histograms()[0]
    phases = {phase.name: phase for phase in project.phases()}

    # Scales and a smooth background are reoptimized with structural changes.
    hist.set_refinements({"Background": True})
    for phase in phases.values():
        phase.set_HAP_refinements({"Scale": True})
    phases["ZnWO4"].set_HAP_refinements({"Pref.Ori.": True})
    phases["WO3"].set_HAP_refinements({"Pref.Ori.": True})

    if stage == "target_coords":
        for atom in phases["ZnWO4"].atoms():
            atom.refinement_flags = "X"
    elif stage == "wo3_heavy_coords":
        for atom in phases["WO3"].atoms():
            if atom.element == "W":
                atom.refinement_flags = "X"
    elif stage == "wo3_all_coords":
        for atom in phases["WO3"].atoms():
            atom.refinement_flags = "X"
    elif stage == "zno_coords":
        for atom in phases["ZnO"].atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
    elif stage == "all_uiso":
        for phase in phases.values():
            for atom in phase.atoms():
                atom.refinement_flags = "U"
    elif stage == "phase_uiso":
        for phase in phases.values():
            atoms = phase.atoms()
            for atom in atoms:
                atom.uiso = 0.008
                atom.refinement_flags = "U"
            variables = [f"{phase.id}::AUiso:{index}" for index in range(len(atoms))]
            if len(variables) > 1:
                project.add_EquivConstr(variables)
            project.set_Controls("parmMin", 0.001, variable=variables[0])
            project.set_Controls("parmMax", 0.03, variable=variables[0])
    elif stage == "phase_uiso_current":
        for phase in phases.values():
            atoms = phase.atoms()
            for atom in atoms:
                atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:0"
            project.set_Controls("parmMin", 0.001, variable=variable)
            project.set_Controls("parmMax", 0.03, variable=variable)
    elif stage == "all_coords_uiso":
        for phase in phases.values():
            for atom in phase.atoms():
                atom.refinement_flags = "XU"
    elif stage == "cells":
        for phase in phases.values():
            phase.set_refinements({"Cell": True})
    elif stage == "profiles":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        for phase in phases.values():
            phase.set_HAP_refinements({
                "Size": {"type": phase.data["Histograms"][hist.name]["Size"][0], "refine": True},
                "Mustrain": {"type": phase.data["Histograms"][hist.name]["Mustrain"][0], "refine": True},
            })
    elif stage == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        project.set_Controls("parmMin", -0.25, variable=f":{hist.id}:Zero")
        project.set_Controls("parmMax", 0.25, variable=f":{hist.id}:Zero")
    elif stage == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        project.set_Controls("parmMin", -800.0, variable=f":{hist.id}:Shift")
        project.set_Controls("parmMax", 800.0, variable=f":{hist.id}:Shift")
    elif stage == "roughness":
        hist.SampleParameters["SurfRoughA"][0] = 0.30
        hist.SampleParameters["SurfRoughB"][0] = 0.10
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        for name, low, high in [("SurfRoughA", 0.05, 0.60), ("SurfRoughB", 0.02, 0.50)]:
            project.set_Controls("parmMin", low, variable=f":{hist.id}:{name}")
            project.set_Controls("parmMax", high, variable=f":{hist.id}:{name}")
    elif stage == "nuisance":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
        for phase in phases.values():
            phase.set_refinements({"Cell": True})
            phase.set_HAP_refinements({
                "Size": {"type": phase.data["Histograms"][hist.name]["Size"][0], "refine": True},
                "Mustrain": {"type": phase.data["Histograms"][hist.name]["Mustrain"][0], "refine": True},
            })
    else:
        raise ValueError(stage)


def summarize(project, stage):
    hist = project.histograms()[0]
    values = {"stage": stage, "rwp": hist.get_wR(), "residuals": hist.residuals, "phases": {}}
    mass = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass[phase.name] = phase.data["General"]["Mass"] * hap["Scale"][0]
        values["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {"label": atom.label, "element": atom.element, "xyz": atom.coordinates, "uiso": atom.uiso}
                for atom in phase.atoms()
            ],
        }
    total = sum(mass.values())
    values["fractions"] = {key: val / total for key, val in mass.items()}
    values["instrument"] = hist.InstrumentParameters
    values["sample"] = hist.SampleParameters
    return values


def main(args):
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    clear_flags(project)
    set_flags(project, args.stage)
    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save()
    result = summarize(project, args.stage)
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print(json.dumps({"stage": args.stage, "rwp": result["rwp"], "fractions": result["fractions"]}))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument(
        "--stage",
        required=True,
        choices=[
            "target_coords", "wo3_heavy_coords", "wo3_all_coords", "zno_coords",
            "all_uiso", "phase_uiso", "phase_uiso_current", "all_coords_uiso", "cells", "profiles", "zero", "shift", "roughness", "nuisance",
        ],
    )
    parser.add_argument("--cycles", type=int, default=16)
    main(parser.parse_args())
