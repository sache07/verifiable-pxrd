import argparse
import json
from pathlib import Path

import numpy as np


def main(args):
    with np.load(args.replay, allow_pickle=False) as data:
        x = data["x"]
        observed = data["observed"]
        calculated = data["predicted"]
        background = data["background"]
    difference = observed - calculated
    table = np.column_stack([x, observed, calculated, difference])
    np.savetxt(
        args.output,
        table,
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    dof = len(x) - args.parameters
    reduced = float(chi_square / dof)
    rexp = float(100.0 * np.sqrt(dof / denominator))
    stats = {
        "n_points": int(len(x)),
        "n_parameters_last_refinement": int(args.parameters),
        "degrees_of_freedom": int(dof),
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "Rexp_percent": rexp,
        "chi_square": chi_square,
        "reduced_chi_square": reduced,
        "goodness_of_fit": float(np.sqrt(reduced)),
        "minimum_calculated_counts": float(np.min(calculated)),
        "minimum_background_counts": float(np.min(background)),
    }
    args.stats.write_text(json.dumps(stats, indent=2) + "\n")
    print(json.dumps(stats))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--replay", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--stats", type=Path, required=True)
    parser.add_argument("--parameters", type=int, required=True)
    main(parser.parse_args())
