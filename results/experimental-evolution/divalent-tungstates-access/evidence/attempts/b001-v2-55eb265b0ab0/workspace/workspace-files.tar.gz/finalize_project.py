import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


FILENAMES = {"ZnWO4": "ZnWO4.cif", "WO3": "WO3.cif", "ZnO": "ZnO.cif"}


def clear_flags(project):
    hist = project.histograms()[0]
    hist.clear_refinements({
        "Instrument Parameters": list(hist.InstrumentParameters),
        "Sample Parameters": [
            key for key, value in hist.SampleParameters.items()
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
        ],
    })
    hist.clear_refinements({"Background": False})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True,
        })


def main(args):
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    clear_flags(project)
    project.save()

    hist = project.histograms()[0]
    masses = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if not hap.get("Use", True) or hap["Scale"][0] <= 0:
            continue
        masses[phase.name] = phase.data["General"]["Mass"] * hap["Scale"][0]
    total = sum(masses.values())

    # Export the saved atoms rather than rounded values cached in the most
    # recent covariance matrix. This is also how the independent replay works.
    covariance = project.data["Covariance"]["data"]
    project.data["Covariance"]["data"] = {}
    try:
        for phase in project.phases():
            phase.export_CIF(str((args.output.parent / FILENAMES[phase.name]).resolve()))
    finally:
        project.data["Covariance"]["data"] = covariance

    print(json.dumps({
        "project": str(args.output),
        "histogram": hist.name,
        "rwp": hist.get_wR(),
        "fractions": {name: value / total for name, value in masses.items()},
        "phases": [phase.name for phase in project.phases()],
    }))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args())
