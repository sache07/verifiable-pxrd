#!/usr/bin/env python3
"""Export the frozen GSAS-II model and its complete fitted profile."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
PHASE_FILES = {
    "srwo4": ROOT / "srwo4.cif",
    "wo3": ROOT / "wo3.cif",
    "srco3": ROOT / "srco3.cif",
}

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(PROJECT))
hist = project.histogram(0)

# Export the atom records actually stored in the project. A prior covariance
# dictionary can contain parameter snapshots from an earlier refinement stage.
project.data["Covariance"]["data"] = {}
for phase in project.phases():
    phase.export_CIF(str(PHASE_FILES[phase.name]))

arrays = np.ma.asarray(hist.data["data"][1]).filled(np.nan)
x, observed, calculated = arrays[0], arrays[1], arrays[3]
difference = observed - calculated
profile = np.column_stack((x, observed, calculated, difference))
np.savetxt(
    ROOT / "fit.csv",
    profile,
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
)

mass_terms = []
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    mass_terms.append(hap["Scale"][0] * phase.data["General"]["Mass"])
fractions = np.asarray(mass_terms) / np.sum(mass_terms)

weights = 1.0 / np.maximum(observed, 1.0)
rwp_check = 100.0 * np.sqrt(
    np.sum(weights * difference**2) / np.sum(weights * observed**2)
)
print("histogram", hist.name)
print("phases", [phase.name for phase in project.phases()])
print("weight_fractions", fractions.tolist())
print("Rp_percent", hist.residuals["R"])
print("Rwp_percent", hist.residuals["wR"])
print("Rwp_export_check_percent", rwp_check)
print("Rwp_expected_percent", hist.residuals["wRmin"])
print("goodness_of_fit_ratio", hist.residuals["wR"] / hist.residuals["wRmin"])
print("bins", len(x))
