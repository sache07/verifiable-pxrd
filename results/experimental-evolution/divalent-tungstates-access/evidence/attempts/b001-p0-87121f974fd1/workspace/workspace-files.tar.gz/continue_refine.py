#!/usr/bin/env python3
"""Continue a GSAS-II refinement and print replay-relevant parameters."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=10)
args = parser.parse_args()

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
project.set_Controls("cycles", args.cycles)
project.refine()
project.save()

hist = project.histogram(0)
terms = [
    p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
    for p in project.phases()
]
print("Rwp", hist.get_wR())
print("fractions", [v / sum(terms) for v in terms])
print("frozen", project.get_Frozen())
print("instrument", {k: hist.InstrumentParameters[k][1] for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")})
print("sample", {k: hist.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")})
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    print(phase.name, phase.get_cell(), "size", hap["Size"][1][0], "strain", hap["Mustrain"][1][0])

