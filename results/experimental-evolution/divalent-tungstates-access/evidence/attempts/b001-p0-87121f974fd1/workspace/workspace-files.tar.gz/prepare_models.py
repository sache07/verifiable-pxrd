#!/usr/bin/env python3
"""Prepare normalized starting models and an XYE file for GSAS-II."""

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c04/cif"
)


def cod_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def load(cod_id: str) -> Structure:
    return CifParser(str(cod_path(cod_id))).parse_structures(primitive=False)[0]


def write_structure(structure: Structure, filename: str) -> None:
    CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(ROOT / filename)


# Scheelite SrWO4: adapt the clean, fully occupied CaWO4 framework (COD 7219229).
# Approximate SrWO4 room-temperature lattice values are used only as refinement seeds.
srwo4 = load("7219229")
srwo4.replace_species({"Ca": "Sr"})
srwo4 = Structure(
    Lattice.tetragonal(5.416, 11.951),
    srwo4.species,
    srwo4.frac_coords,
    coords_are_cartesian=False,
    site_properties=srwo4.site_properties,
)
write_structure(srwo4, "start_srwo4.cif")

# Candidate residual precursors: monoclinic gamma-WO3 and orthorhombic SrCO3.
# Standardize the published P21/n WO3 setting to the P21/c setting GSAS-II uses.
wo3 = SpacegroupAnalyzer(load("1528915"), symprec=1e-2).get_conventional_standard_structure()
write_structure(wo3, "start_wo3.cif")
write_structure(load("9008198"), "start_srco3.cif")

x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1, unpack=True)
sigma = np.sqrt(np.maximum(y, 1.0))
np.savetxt(
    ROOT / "pattern.xye",
    np.column_stack((x, y, sigma)),
    fmt="%.8f %.8f %.8f",
)
