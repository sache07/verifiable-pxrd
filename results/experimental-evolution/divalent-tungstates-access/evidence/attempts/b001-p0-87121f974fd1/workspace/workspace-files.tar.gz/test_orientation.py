#!/usr/bin/env python3
"""Refine one candidate March-Dollase axis for the dominant SrWO4 phase."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("axis", help="comma-separated h,k,l")
parser.add_argument("output", type=Path)
parser.add_argument("--input", type=Path, default=Path("stage_02_cells_positions.gpx"))
parser.add_argument("--phase", default="srwo4")
args = parser.parse_args()
axis = [int(v) for v in args.axis.split(",")]

G2sc.SetPrintLevel("error")
project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)

# Freeze the converged peak positions and widths while testing intensity texture.
for key, value in hist.InstrumentParameters.items():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for key, value in hist.SampleParameters.items():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.data["Background"][0][1] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False

target = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
target[0] = "MD"
target[1] = 1.0
target[2] = True
target[3] = axis

project.set_Controls("cycles", 8)
project.refine()
target = project.phase(args.phase).data["Histograms"][hist.name]["Pref.Ori."]
terms = [
    p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
    for p in project.phases()
]
print(
    args.axis,
    f"Rwp={hist.get_wR():.6f}",
    f"MD={target[1]:.7f}",
    "fractions=" + ",".join(f"{v / sum(terms):.6f}" for v in terms),
)
project.save()
