#!/usr/bin/env python3
"""Compare the current WO3 coordinates with a neutron-reference model."""

import copy
from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c04/cif/2/31/10/2311041.cif"
)
CANDIDATE = ROOT / ".tmp" / "wo3_neutron_standard.cif"

structure = CifParser(SOURCE).parse_structures(primitive=False)[0]
structure = SpacegroupAnalyzer(structure, symprec=1e-2).get_conventional_standard_structure()
CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(CANDIDATE)

G2sc.SetPrintLevel("warn")
scratch = G2sc.G2Project(newgpx=str(ROOT / ".tmp" / "wo3_import.gpx"))
imported = scratch.add_phase(str(CANDIDATE), phasename="candidate", fmthint="CIF")

project = G2sc.G2Project(
    str(ROOT / "final.gpx"), newgpx=str(ROOT / ".tmp" / "wo3_neutron_test.gpx")
)
target = project.phase("wo3")
print("source cell", imported.data["General"]["Cell"])
print("source SG", imported.data["General"]["SGData"]["SpGrp"])
for atom in imported.atoms():
    print("source atom", atom.label, atom.element, atom.coordinates)

target.data["Atoms"] = copy.deepcopy(imported.data["Atoms"])
for atom in target.atoms():
    atom.uiso = 0.013
    atom.refinement_flags = " "
project.save()

target.data["Atoms"] = copy.deepcopy(imported.data["Atoms"])
for atom in target.atoms():
    atom.uiso = 0.013
    atom.refinement_flags = " "
project.save()
print("wrote", ROOT / ".tmp" / "wo3_neutron_test.gpx")
