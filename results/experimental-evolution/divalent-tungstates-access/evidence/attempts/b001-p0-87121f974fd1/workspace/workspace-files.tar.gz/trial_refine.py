#!/usr/bin/env python3
"""Build an initial three-phase GSAS-II project and report parameter layout."""

from pathlib import Path
import pprint

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(newgpx=str(ROOT / "trial.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "pattern.xye"),
    str(ROOT / "instrument.instprm"),
    fmthint="xye",
)
for name in ("srwo4", "wo3", "srco3"):
    project.add_phase(
        str(ROOT / f"start_{name}.cif"),
        phasename=name,
        histograms=[hist],
    )

print("histogram", hist.name)
print("limits", hist.data["Limits"])
print("background", hist.data["Background"])
print("instrument")
pprint.pp(hist.data["Instrument Parameters"])
print("sample")
pprint.pp(hist.data["Sample Parameters"])
for phase in project.phases():
    print("\nphase", phase.name, phase.get_cell())
    print("atoms")
    for atom in phase.atoms():
        print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso)
    print("HAP")
    pprint.pp(phase.data["Histograms"])
project.save()

