#!/usr/bin/env python3
"""Re-refine with physically supported bounds from the stated lab setup."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(
    str(ROOT / "stage_01_scale_background.gpx"),
    newgpx=str(ROOT / "constrained.gpx"),
)
hist = project.histogram(0)
project.set_Frozen()

# The previous unconstrained zero/height/cell solution was mathematically
# correlated but outside the documented experimental domain. Re-seed inside
# the known acquisition limits and compensate the cells to retain peak overlap.
hist.InstrumentParameters["Zero"][1] = 0.05
hist.SampleParameters["Shift"][0] = 400.0
for phase in project.phases():
    cell = phase.data["General"]["Cell"]
    cell[1:4] = [0.995 * value for value in cell[1:4]]
    cell[7] *= 0.995**3
    phase.data["General"]["Cell"][0] = True
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2] = [True, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [True, False, False]
    hap["Scale"][1] = True

for key, value in {"U": 20.0, "W": 10.0, "X": 1.0, "SH/L": 0.025, "Polariz.": 0.70}.items():
    hist.InstrumentParameters[key][1] = value
    hist.InstrumentParameters[key][2] = True
hist.InstrumentParameters["Zero"][2] = True
hist.SampleParameters["Shift"][1] = True
hist.data["Background"][0][1] = True

limits = {
    ":0:Zero": (-0.25, 0.25),
    ":0:Shift": (-800.0, 800.0),
    ":0:Polariz.": (0.5, 1.0),
    ":0:U": (0.0, 40.0),
    ":0:W": (2.0, 40.0),
    ":0:X": (0.1, 6.0),
    ":0:SH/L": (0.005, 0.10),
    "*:0:Size;i": (0.04, 1.5),
    "*:0:Mustrain;i": (0.0, 8000.0),
    "*:0:Scale": (0.0, 100.0),
}
for variable, (lower, upper) in limits.items():
    project.set_Controls("parmMin", lower, variable)
    project.set_Controls("parmMax", upper, variable)

project.set_Controls("cycles", 10)
project.refine()
project.save(ROOT / "constrained.gpx")

h = project.histogram(0)
terms = [
    p.data["Histograms"][h.name]["Scale"][0] * p.data["General"]["Mass"]
    for p in project.phases()
]
print("Rwp", h.get_wR())
print("fractions", [v / sum(terms) for v in terms])
print("frozen", project.get_Frozen())
print("instrument", {k: h.InstrumentParameters[k][1] for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")})
print("sample", {k: h.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")})
for phase in project.phases():
    hap = phase.data["Histograms"][h.name]
    print(phase.name, phase.get_cell(), "size", hap["Size"][1][0], "strain", hap["Mustrain"][1][0])

