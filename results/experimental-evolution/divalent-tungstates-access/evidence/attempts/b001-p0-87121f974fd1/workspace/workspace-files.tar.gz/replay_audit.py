#!/usr/bin/env python3
"""Force a zero-variable GSAS-II recalculation to audit saved-project replay."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
project.set_Frozen()
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
hist.data["Background"][0][1] = False
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for value in hist.SampleParameters.values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
project.set_Controls("cycles", 0)
project.refine()
project.save()
print("recalculated_Rwp", project.histogram(0).get_wR())

