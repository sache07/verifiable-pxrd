#!/usr/bin/env python3
"""Set one phase-wide Uiso and re-optimize linear intensity terms."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase")
parser.add_argument("uiso", type=float)
parser.add_argument("--cycles", type=int, default=6)
args = parser.parse_args()

G2sc.SetPrintLevel("error")
project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
project.set_Frozen()

for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
hist.data["Background"][0][1] = True
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
hist.InstrumentParameters["Polariz."][2] = True
for value in hist.SampleParameters.values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
for atom in project.phase(args.phase).atoms():
    atom.uiso = args.uiso

project.set_Controls("cycles", args.cycles)
project.refine()
project.save()
hist = project.histogram(0)
terms = [
    p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
    for p in project.phases()
]
print(
    args.phase,
    args.uiso,
    "Rwp", hist.get_wR(),
    "fractions", ",".join(f"{v / sum(terms):.8f}" for v in terms),
)

