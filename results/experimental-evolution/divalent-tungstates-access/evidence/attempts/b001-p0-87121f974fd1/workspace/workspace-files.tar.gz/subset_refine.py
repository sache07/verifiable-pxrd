#!/usr/bin/env python3
"""Refine selected GSAS-II parameter groups while freezing all others."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=8)
parser.add_argument("--instrument", default="", help="comma-separated instrument keys")
parser.add_argument("--sample", default="", help="comma-separated sample keys")
parser.add_argument("--background", action="store_true")
parser.add_argument("--scales", action="store_true")
parser.add_argument("--cells", default="", help="comma-separated phase names or all")
parser.add_argument("--sizes", default="", help="comma-separated phase names")
parser.add_argument("--strains", default="", help="comma-separated phase names")
parser.add_argument("--md", default="", help="phase:h,k,l")
parser.add_argument("--atoms", default="", help="phase:label=flags;label=flags")
args = parser.parse_args()


def names(value):
    return {v for v in value.split(",") if v}


G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
project.set_Frozen()

# Freeze everything first.
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for value in hist.SampleParameters.values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.data["Background"][0][1] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False

for key in names(args.instrument):
    hist.InstrumentParameters[key][2] = True
for key in names(args.sample):
    hist.SampleParameters[key][1] = True
hist.data["Background"][0][1] = args.background

cell_names = names(args.cells)
size_names = names(args.sizes)
strain_names = names(args.strains)
for phase in project.phases():
    if "all" in cell_names or phase.name in cell_names:
        phase.data["General"]["Cell"][0] = True
    hap = phase.data["Histograms"][hist.name]
    if args.scales:
        hap["Scale"][1] = True
    if phase.name in size_names:
        hap["Size"][2][0] = True
    if phase.name in strain_names:
        hap["Mustrain"][2][0] = True

if args.md:
    phase_name, axis_text = args.md.split(":", 1)
    axis = [int(v) for v in axis_text.split(",")]
    po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
    po[0], po[2], po[3] = "MD", True, axis

if args.atoms:
    phase_name, atom_text = args.atoms.split(":", 1)
    refs = {}
    for item in atom_text.split(";"):
        label, flags = item.split("=", 1)
        refs[label] = flags
    project.phase(phase_name).set_refinements({"Atoms": refs})

project.set_Controls("cycles", args.cycles)
project.refine()
project.save()

hist = project.histogram(0)
terms = [
    p.data["Histograms"][hist.name]["Scale"][0] * p.data["General"]["Mass"]
    for p in project.phases()
]
print("Rwp", hist.get_wR())
print("fractions", [v / sum(terms) for v in terms])
print("instrument", {k: hist.InstrumentParameters[k][1] for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")})
print("sample", {k: hist.SampleParameters[k][0] for k in ("Shift", "SurfRoughA", "SurfRoughB")})
for phase in project.phases():
    hap = phase.data["Histograms"][hist.name]
    print(phase.name, "scale", hap["Scale"][0], "size", hap["Size"][1][0], "strain", hap["Mustrain"][1][0], "MD", hap["Pref.Ori."][:4])

