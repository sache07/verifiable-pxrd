#!/usr/bin/env python3
"""Sequential Rietveld refinement for the Sr-W-O precursor/product mixture."""

from pathlib import Path
import shutil

import numpy as np
from scipy.ndimage import percentile_filter

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
G2sc.SetPrintLevel("warn")


def mass_fractions(project, hist):
    terms = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        terms.append(max(0.0, float(hap["Scale"][0])) * phase.data["General"]["Mass"])
    terms = np.asarray(terms)
    return terms / terms.sum()


def summary(project, label):
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    print(f"\n{label}: Rwp={hist.get_wR():.5f}%")
    print(
        "inst",
        {key: inst[key][1] for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")},
    )
    print(
        "sample",
        {key: sample[key][0] for key in ("Shift", "SurfRoughA", "SurfRoughB")},
    )
    print("fractions", dict(zip([p.name for p in project.phases()], mass_fractions(project, hist))))
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            phase.get_cell(),
            "scale", hap["Scale"][0],
            "size", hap["Size"][:4],
            "strain", hap["Mustrain"][:4],
            "MD", hap["Pref.Ori."][:4],
        )


def refine(project, label, cycles=8):
    project.set_Controls("cycles", cycles)
    project.refine()
    summary(project, label)
    project.save(ROOT / f"stage_{label}.gpx")


project = G2sc.G2Project(newgpx=str(ROOT / "working.gpx"))
hist = project.add_powder_histogram(
    str(ROOT / "pattern.xye"),
    str(ROOT / "instrument.instprm"),
    fmthint="xye",
)
for name in ("srwo4", "wo3", "srco3"):
    project.add_phase(
        str(ROOT / f"start_{name}.cif"),
        phasename=name,
        histograms=[hist],
    )

# Use one specimen scale and independent HAP scales so phase mass fractions are
# proportional to HAP scale times unit-cell mass.
hist.SampleParameters["Scale"] = [1.0, False]
hist.SampleParameters["Gonio. radius"] = 200.0
for phase, fraction in zip(project.phases(), (0.80, 0.12, 0.08)):
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [6000.0 * fraction / phase.data["General"]["Mass"], True]

# Robust smooth starting background, represented in GSAS-II's native Chebyshev basis.
x = np.asarray(hist.data["data"][1][0], float)
y = np.asarray(hist.data["data"][1][1], float)
smooth_floor = percentile_filter(y, percentile=25, size=401, mode="nearest")
t = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
bg_coeff = np.polynomial.chebyshev.chebfit(t, smooth_floor, deg=12)
hist.set_refinements(
    {
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": len(bg_coeff),
            "coeffs": bg_coeff.tolist(),
            "refine": True,
        }
    }
)

# Seed the common low-angle displacement seen in all three phase families.
hist.InstrumentParameters["Zero"][1] = -0.15
hist.SampleParameters["Shift"][0] = 100.0

refine(project, "01_scale_background", cycles=6)

# Lattice parameters and common angular calibration/specimen displacement.
for phase in project.phases():
    phase.set_refinements({"Cell": True})
hist.set_refinements(
    {
        "Instrument Parameters": ["Zero"],
        "Sample Parameters": ["Shift"],
    }
)
refine(project, "02_cells_positions", cycles=10)

# Instrumental broadening, polarization, and phase-specific isotropic size/strain.
hist.set_refinements(
    {"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]}
)
for phase in project.phases():
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.3, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
refine(project, "03_profile", cycles=12)

# Dominant-phase oxygen coordinate and all isotropic ADPs. Coordinates in the
# weak phases remain at their published values to avoid unsupported overfitting.
project.phase("srwo4").set_refinements({"Atoms": {"O2": "XU", "Sr0": "U", "W1": "U"}})
for name in ("wo3", "srco3"):
    project.phase(name).set_refinements({"Atoms": {"all": "U"}})
refine(project, "04_atomic", cycles=12)

project.save(ROOT / "working.gpx")
shutil.copy2(ROOT / "working.gpx", ROOT / "base_refined.gpx")

