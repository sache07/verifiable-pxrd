#!/usr/bin/env python3
"""Test a uniaxial microstrain model for one phase and direction."""

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("phase")
parser.add_argument("axis", help="comma-separated h,k,l")
parser.add_argument("--cycles", type=int, default=8)
args = parser.parse_args()
axis = [int(v) for v in args.axis.split(",")]

G2sc.SetPrintLevel("warn")
project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
hist = project.histogram(0)
project.set_Frozen()

# Freeze every parameter except the selected uniaxial strain pair.
for value in hist.InstrumentParameters.values():
    if isinstance(value, list) and len(value) > 2:
        value[2] = False
for value in hist.SampleParameters.values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False
hist.data["Background"][0][1] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.atoms():
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][1] = False
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False

hap = project.phase(args.phase).data["Histograms"][hist.name]
initial = float(hap["Mustrain"][1][0])
hap["Mustrain"][0] = "uniaxial"
hap["Mustrain"][1][0] = initial
hap["Mustrain"][1][1] = initial
hap["Mustrain"][2] = [True, True, False]
hap["Mustrain"][3] = axis

project.set_Controls("cycles", args.cycles)
project.refine()
project.save()
hap = project.phase(args.phase).data["Histograms"][hist.name]
print(args.phase, args.axis, "Rwp", hist.get_wR(), "Mustrain", hap["Mustrain"][:4])

