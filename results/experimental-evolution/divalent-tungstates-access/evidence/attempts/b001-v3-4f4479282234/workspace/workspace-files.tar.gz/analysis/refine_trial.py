#!/usr/bin/env python3
"""Build and stage a GSAS-II Rietveld trial for the supplied CIF references.

Run this script with the GSAS-II Python interpreter. It is intentionally kept
independent of pymatgen so the same project-building path can be replayed in the
GSAS environment.
"""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from GSASII import GSASIIscriptable as G2


def write_instrument(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:21.0;X:0.7745966692;Y:0.0;Z:0.0;SH/L:0.0223606798\n"
    )


def initial_background(pattern: Path, terms: int) -> list[float]:
    arr = np.loadtxt(pattern, delimiter=",", skiprows=1)
    x, y = arr.T
    step = float(np.median(np.diff(x)))
    width = max(5, int(round(2.0 / step)))
    if width % 2 == 0:
        width += 1
    baseline = percentile_filter(y, percentile=12, size=width, mode="nearest")
    baseline = gaussian_filter1d(baseline, max(2, int(round(0.25 / step))))
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(t, baseline, terms - 1).tolist()


def set_cycles(project: G2.G2Project, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)


def snapshot(project: G2.G2Project, outdir: Path, tag: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    record = {
        "tag": tag,
        "Rwp_percent": hist.get_wR(),
        "instrument": {
            key: float(inst[key][1])
            for key in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if key in inst
        },
        "sample": {
            key: float(sample[key][0]) if isinstance(sample.get(key), list) else sample.get(key)
            for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]
            if key in sample
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        record["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
            }
        )
    project.save(str(outdir / f"{tag}.gpx"))
    return record


def refine(project: G2.G2Project, label: str) -> None:
    print(f"\n===== {label} =====", flush=True)
    project.refine(makeBack=False)
    hist = project.histograms()[0]
    print(f"{label}: Rwp={hist.get_wR():.6g}%", flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--outdir", type=Path, required=True)
    parser.add_argument("--phase", action="append", required=True, metavar="NAME=PATH")
    parser.add_argument("--background-terms", type=int, default=14)
    parser.add_argument("--shift", type=float, default=600.0, help="Starting specimen shift, micrometres")
    parser.add_argument("--coords", choices=["none", "oxygen", "all"], default="none")
    parser.add_argument("--uiso", action="store_true", help="Refine isotropic displacement parameters")
    args = parser.parse_args()

    args.outdir.mkdir(parents=True, exist_ok=True)
    project_path = args.outdir / "trial.gpx"
    inst_path = args.outdir / "instrument.instprm"
    write_instrument(inst_path)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(project_path))
    phases = []
    for spec in args.phase:
        name, path = spec.split("=", 1)
        phases.append(project.add_phase(str(Path(path).resolve()), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(args.pattern.resolve()), str(inst_path.resolve()), phases="all", fmthint="comma"
    )

    # Explicitly preserve the experimental geometry used in generation.
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [float(args.shift), False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": initial_background(args.pattern, args.background_terms),
                "refine": True,
            },
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        # Imported HAP defaults vary between GSAS-II revisions; make the
        # starting state explicit so profile terms are introduced only in the
        # intended stage below.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]

    # Keep calibration/profile quantities inside the laboratory's stated
    # physical ranges and phase broadening inside the generator support.
    project.save(str(project_path))
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Shift": (-800.0, 800.0),
    }
    for phase in phases:
        pfx = f"{phase.id}:0:"
        bounds[pfx + "Scale"] = (0.0, 1.0e4)
        bounds[pfx + "Size;i"] = (0.04, 1.50)
        bounds[pfx + "Mustrain;i"] = (0.0, 8000.0)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    set_cycles(project, 8)
    records = []
    refine(project, "background and scales")
    records.append(snapshot(project, args.outdir, "stage01_scale_background"))

    # Cells absorb the modest phase-specific reference mismatch. The common
    # zero is first adjusted with specimen height held near the peak-match estimate.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells and zero")
    records.append(snapshot(project, args.outdir, "stage02_cells_zero"))

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "common specimen displacement")
    records.append(snapshot(project, args.outdir, "stage03_displacement"))

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.30, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    refine(project, "phase-specific isotropic broadening")
    records.append(snapshot(project, args.outdir, "stage05_broadening"))

    # Only the five instrument quantities randomized by this laboratory are
    # relaxed; V, Y and Z remain at their generating values of zero.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument profile")
    records.append(snapshot(project, args.outdir, "stage06_instrument"))

    if args.coords != "none":
        for phase in phases:
            for atom in phase.atoms():
                if args.coords == "all" or atom.element.strip().upper().startswith("O"):
                    atom.refinement_flags = "X"
        refine(project, f"{args.coords} coordinates")
        records.append(snapshot(project, args.outdir, "stage07_coordinates"))

    if args.uiso:
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
        refine(project, "isotropic displacement parameters")
        records.append(snapshot(project, args.outdir, "stage08_uiso"))

    project.save(str(project_path))
    (args.outdir / "summary.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
