#!/usr/bin/env python3
"""Freshly regenerate a saved GSAS-II project and report observed-pattern Rwp."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path

import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("observed", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--histogram")
    args = parser.parse_args()
    project = args.project.resolve()
    observed = args.observed.resolve()
    args.outdir.mkdir(parents=True, exist_ok=True)
    os.chdir(args.outdir)

    worker = (
        Path(__file__).resolve().parents[1]
        / "learned/divalent-tungstates/scorer/runtime/replay_worker.py"
    )
    spec = importlib.util.spec_from_file_location("pxrd_replay_worker", worker)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    request = {"project": str(project), "observed": str(observed)}
    if args.histogram:
        request["histogram"] = args.histogram
    result = module.replay(request)
    with np.load("prediction.npz") as data:
        y = data["observed"]
        calc = data["predicted"]
        weights = 1.0 / np.maximum(y, 1.0)
        result["fresh_Rwp_percent"] = float(
            100.0 * np.sqrt(np.sum(weights * (y - calc) ** 2) / np.sum(weights * y**2))
        )
        result["minimum_background_counts"] = float(np.min(data["background"]))
        result["minimum_predicted_counts"] = float(np.min(calc))
        w = 1.0 / np.maximum(y, 1.0)
        rwp = 100.0 * np.sqrt(np.sum(w * (y - calc) ** 2) / np.sum(w * y**2))
        result["fresh_Rwp_percent"] = float(rwp)
        result["minimum_background"] = float(np.min(data["background"]))
        result["minimum_predicted"] = float(np.min(calc))
    Path("replay.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
