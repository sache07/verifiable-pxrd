#!/usr/bin/env python3
"""Perform one isolated GSAS-II refinement step without parameter clamping."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


INSTRUMENT_KEYS = ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
SAMPLE_KEYS = ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]


def freeze_all(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.clear_refinements(
        {
            "Instrument Parameters": [k for k in INSTRUMENT_KEYS if k in hist.data["Instrument Parameters"][0]],
            "Sample Parameters": [k for k in SAMPLE_KEYS if k in hist.data["Sample Parameters"]],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""
    # Trials are screened after refinement. Removing old clamps avoids the
    # GSAS-II stale-calculation behavior when a variable crosses a bound.
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--instrument", choices=INSTRUMENT_KEYS)
    group.add_argument("--sample", choices=SAMPLE_KEYS)
    group.add_argument("--cell", metavar="PHASE")
    group.add_argument("--size", metavar="PHASE")
    group.add_argument("--mustrain", metavar="PHASE")
    group.add_argument("--coordinates", nargs=2, metavar=("PHASE", "ELEMENT"))
    group.add_argument("--uiso", nargs=2, metavar=("PHASE", "ELEMENT"))
    group.add_argument("--uniform-uiso", metavar="PHASE")
    group.add_argument("--uniform-uiso-existing", metavar="PHASE")
    group.add_argument("--texture", nargs=4, metavar=("PHASE", "H", "K", "L"))
    group.add_argument("--roughness", action="store_true")
    group.add_argument("--profile-all", action="store_true")
    group.add_argument("--profile-no-u", action="store_true")
    group.add_argument("--uniaxial-strain", nargs=4, metavar=("PHASE", "H", "K", "L"))
    parser.add_argument("--atom-label")
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    freeze_all(project)
    hist = project.histograms()[0]

    if args.profile_no_u:
        hist.set_refinements(
            {"Instrument Parameters": ["Zero", "Polariz.", "W", "X", "SH/L"]}
        )
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif args.profile_all:
        hist.set_refinements(
            {"Instrument Parameters": ["Zero", "Polariz.", "U", "W", "X", "SH/L"]}
        )
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif args.instrument:
        hist.set_refinements({"Instrument Parameters": [args.instrument]})
    elif args.sample:
        hist.set_refinements({"Sample Parameters": [args.sample]})
    elif args.roughness:
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.30, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.10, True]
    elif args.cell:
        project.phase(args.cell).set_refinements({"Cell": True})
    elif args.size:
        project.phase(args.size).set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif args.mustrain:
        project.phase(args.mustrain).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    elif args.uniaxial_strain:
        phase_name, h, k, l = args.uniaxial_strain
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        current = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = current
        hap["Mustrain"][1][1] = current
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = [int(h), int(k), int(l)]
    elif args.uniform_uiso_existing:
        # Reuse a previously-created equivalence constraint without adding a
        # duplicate. This is used for later polishing passes.
        for atom in project.phase(args.uniform_uiso_existing).atoms():
            atom.refinement_flags = "U"
    elif args.uniform_uiso:
        phase = project.phase(args.uniform_uiso)
        cia = phase.data["General"]["AtomPtrs"][3]
        # For anisotropic input structures GSAS-II keeps Ueq in cia+1, but
        # Atom.uiso intentionally raises. Use Ueq as the physically neutral
        # starting value and explicitly switch every site to isotropic ADPs.
        start_uiso = sum(float(atom.data[cia + 1]) for atom in phase.atoms()) / len(
            phase.atoms()
        )
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.data[cia] = "I"
            atom.uiso = start_uiso
            atom.refinement_flags = "U"
            variables.append(f"{phase.id}::AUiso:{index}")
        if len(variables) > 1:
            project.add_EquivConstr(tuple(variables), override=True)
    elif args.texture:
        phase_name, h, k, l = args.texture
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [int(h), int(k), int(l)]
    else:
        phase_name, element = args.coordinates or args.uiso
        flag = "X" if args.coordinates else "U"
        for atom in project.phase(phase_name).atoms():
            if atom.element.strip().upper() == element.upper() and (
                args.atom_label is None or atom.label == args.atom_label
            ):
                atom.refinement_flags = flag

    project.set_Controls("cycles", args.cycles)
    project.save(str(args.output))
    print(f"starting stored Rwp={hist.get_wR():.8g}%", flush=True)
    project.refine(makeBack=False)
    print(f"reported Rwp={hist.get_wR():.8g}%", flush=True)
    project.save(str(args.output))

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(
        "instrument",
        {k: v[1] for k, v in inst.items() if k in INSTRUMENT_KEYS},
        "sample",
        {k: sample[k][0] for k in SAMPLE_KEYS if k in sample},
        flush=True,
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            phase.name,
            "cell",
            phase.get_cell(),
            "scale",
            hap["Scale"][0],
            "size",
            hap["Size"][1][0],
            "mustrain",
            hap["Mustrain"][1][0],
            "mustrain_full",
            hap["Mustrain"],
            "texture",
            hap["Pref.Ori."],
            "atoms",
            [
                (
                    a.label,
                    a.element,
                    a.coordinates,
                    a.uiso if a.data[phase.data["General"]["AtomPtrs"][3]] == "I" else "anisotropic",
                )
                for a in phase.atoms()
            ],
            flush=True,
        )


if __name__ == "__main__":
    main()
