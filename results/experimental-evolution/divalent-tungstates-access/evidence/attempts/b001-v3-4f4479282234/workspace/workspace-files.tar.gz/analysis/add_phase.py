#!/usr/bin/env python3
"""Add one CIF phase to an existing GSAS-II project and refine its scale."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("name")
    parser.add_argument("cif", type=Path)
    parser.add_argument("--scale", type=float, default=1.0)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histograms()[0]

    # Freeze nonlinear terms while the new component establishes a scale.
    inst = hist.data["Instrument Parameters"][0]
    hist.clear_refinements(
        {
            "Instrument Parameters": [k for k, v in inst.items() if isinstance(v, list) and len(v) > 2],
            "Sample Parameters": [
                k
                for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
                if k in hist.data["Sample Parameters"]
            ],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""

    phase = project.add_phase(
        str(args.cif.resolve()), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][2] = [False for _ in hap["Size"][2]]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    project.set_Controls("cycles", 8)
    project.save(str(args.output))
    print(f"starting stored Rwp={hist.get_wR():.8g}%", flush=True)
    project.refine(makeBack=False)
    print(f"reported Rwp={hist.get_wR():.8g}%", flush=True)
    project.save(str(args.output))

    amounts = []
    for p in project.phases():
        h = p.data["Histograms"][hist.name]
        amount = float(p.data["General"]["Mass"]) * float(h["Scale"][0])
        amounts.append(amount)
    for p, amount in zip(project.phases(), amounts):
        h = p.data["Histograms"][hist.name]
        print(
            p.name,
            "scale",
            h["Scale"][0],
            "weight_fraction",
            amount / sum(amounts),
            "cell",
            p.get_cell(),
            flush=True,
        )


if __name__ == "__main__":
    main()
