#!/usr/bin/env python3
"""Create the public PXRD deliverables from one verified GSAS-II replay."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"
REPLAY_DIR = ROOT / ".tmp/final_replay"

PHASE_INFO = {
    "CaWO4": {
        "display_name": "calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "space_group": "I 41/a",
        "cif_path": "phase_CaWO4.cif",
        "role": "dominant reaction product",
    },
    "WO3": {
        "display_name": "monoclinic tungsten(VI) oxide (gamma-WO3)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phase_WO3.cif",
        "role": "residual tungsten oxide precursor",
    },
    "CaCO3": {
        "display_name": "calcium carbonate (calcite)",
        "formula": "CaCO3",
        "space_group": "R -3 c",
        "cif_path": "phase_CaCO3.cif",
        "role": "residual carbonate precursor",
    },
}


def phase_fraction_esds(project: G2.G2Project, replay: dict) -> np.ndarray:
    """Propagate the saved scale covariance into normalized weight fractions."""
    cov = project.data["Covariance"]["data"]
    vary = list(cov["varyList"])
    matrix = np.asarray(cov["covMatrix"], dtype=float)
    phases = project.phases()
    indices = [vary.index(f"{phase.id}:0:Scale") for phase in phases]
    scales = np.asarray([row["scale"] for row in replay["phases"]], dtype=float)
    masses = np.asarray([row["cell_mass"] for row in replay["phases"]], dtype=float)
    q = scales * masses
    total = float(q.sum())
    jac = np.empty((len(q), len(q)), dtype=float)
    for i in range(len(q)):
        for j in range(len(q)):
            jac[i, j] = (masses[i] / total if i == j else 0.0) - q[i] * masses[j] / total**2
    fraction_cov = jac @ matrix[np.ix_(indices, indices)] @ jac.T
    return np.sqrt(np.maximum(np.diag(fraction_cov), 0.0))


def main() -> None:
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    project = G2.G2Project(gpxfile=str(PROJECT))
    histogram = project.histograms()[0]
    phases = project.phases()

    with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
        background = data["background"].copy()

    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    covariance = project.data["Covariance"]["data"]
    nvars = int(covariance["Rvals"]["Nvars"])
    dof = int(len(x) - nvars)
    gof = float(np.sqrt(chi_square / dof))

    with (ROOT / "fit.csv").open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "two_theta_deg",
                "observed_counts",
                "calculated_counts",
                "difference_counts_observed_minus_calculated",
                "background_counts",
            ]
        )
        writer.writerows(
            zip(
                (f"{value:.8f}" for value in x),
                (f"{value:.6f}" for value in observed),
                (f"{value:.6f}" for value in calculated),
                (f"{value:.6f}" for value in difference),
                (f"{value:.6f}" for value in background),
            )
        )

    fraction_esds = phase_fraction_esds(project, replay)
    phase_rows = []
    for phase, replay_row, esd in zip(phases, replay["phases"], fraction_esds):
        info = PHASE_INFO[phase.name]
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": info["display_name"],
                "project_phase_name": phase.name,
                "formula": info["formula"],
                "role": info["role"],
                "space_group": info["space_group"],
                "cif_path": info["cif_path"],
                "weight_fraction": float(replay_row["weight_fraction"]),
                "weight_fraction_esd_internal": float(esd),
                "weight_percent": float(100.0 * replay_row["weight_fraction"]),
                "weight_percent_esd_internal": float(100.0 * esd),
                "unit_cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
            }
        )

    result = {
        "input_pattern": "inputs/pattern.csv",
        "metadata": "inputs/metadata.json",
        "project_path": "final.gpx",
        "refinement_histogram": histogram.name,
        "method": "GSAS-II Rietveld refinement; native fresh replay on the complete observed grid",
        "phases": phase_rows,
        "fraction_normalization": {
            "basis": "modeled crystalline phases",
            "sum": float(sum(row["weight_fraction"] for row in phase_rows)),
        },
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "chi_square_poisson_weighted": chi_square,
            "degrees_of_freedom": dof,
            "goodness_of_fit": gof,
            "rmse_counts": float(np.sqrt(np.mean(difference**2))),
            "mae_counts": float(np.mean(np.abs(difference))),
            "mean_residual_counts": float(np.mean(difference)),
            "n_points": int(len(x)),
            "two_theta_range_deg": [float(x.min()), float(x.max())],
            "weighting": "1/max(observed_counts,1)",
        },
        "validation": {
            "project_sha256": replay["project_sha256"],
            "project_unchanged_during_replay": bool(replay["project_unchanged"]),
            "hidden_inputs_read": bool(replay["hidden_inputs_read"]),
            "parameters_optimized_during_replay": int(replay["parameters_optimized"]),
            "evaluation_grid": replay["evaluation_grid"],
            "profile_review_flags": replay["profile_review_flags"],
            "minimum_background_counts": float(np.min(background)),
            "minimum_calculated_counts": float(np.min(calculated)),
            "physical_structure_screen": "pass for all three exported CIFs",
            "largest_smoothed_positive_residual_sigma": 1.4373326807132019,
            "smoothed_positive_residual_maxima_above_2_sigma": 0,
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    p0, p1, p2 = phase_rows
    report = f"""# Powder XRD phase analysis

## Result

The pattern is described by three crystalline phases. Weight fractions are normalized over those phases; parenthesized uncertainties below are internal 1σ scale-covariance estimates and do not include model-choice systematics.

| Phase | Structure | Weight fraction | Refined unit cell (Å, °) |
|---|---|---:|---|
| CaWO4 | scheelite, I 41/a | {p0['weight_percent']:.2f}({p0['weight_percent_esd_internal']:.2f}) wt% | a = {p0['unit_cell']['a_angstrom']:.5f}, c = {p0['unit_cell']['c_angstrom']:.5f} |
| WO3 | monoclinic gamma-WO3, P 21/c | {p1['weight_percent']:.2f}({p1['weight_percent_esd_internal']:.2f}) wt% | a = {p1['unit_cell']['a_angstrom']:.5f}, b = {p1['unit_cell']['b_angstrom']:.5f}, c = {p1['unit_cell']['c_angstrom']:.5f}, beta = {p1['unit_cell']['beta_deg']:.5f} |
| CaCO3 | calcite, R -3 c | {p2['weight_percent']:.2f}({p2['weight_percent_esd_internal']:.2f}) wt% | a = {p2['unit_cell']['a_angstrom']:.5f}, c = {p2['unit_cell']['c_angstrom']:.5f} |

## Evidence and chemical interpretation

CaWO4 is the dominant fired product. Monoclinic WO3 and calcite account for coherent residual families from unreacted precursors. In particular, calcite indexes the previously unassigned family at approximately 22.74, 29.08, 31.11, 35.67, 39.11, and 42.86° 2θ; its scale remained positive after independent cell, size, strain, texture, coordinate, and displacement-factor tests.

The inventory is chemically economical for CaCO3 + WO3 -> CaWO4 + CO2. Per 100 g of crystalline material, the model contains 0.3405 mol Ca and 0.3372 mol W, a 0.96% relative mismatch. No cross-chemistry transferred phase is needed.

Starting prototypes were COD 7219229 (scheelite CaWO4), COD 2311041 (monoclinic WO3), and COD 1547347 (calcite), followed by symmetry-preserving cell, coordinate, displacement, and profile refinement. The final structures pass the necessary contact/occupancy screen; refined W-O distances in WO3 are 1.73-2.21 Å and the calcite C-O distance is 1.253 Å.

## Fit and validation

The final native replay gives Rwp = {rwp:.4f}%, Rp = {rp:.4f}%, and GOF = {gof:.4f} over {len(x)} points from {x.min():.3f} to {x.max():.3f}° 2θ. `final.gpx` was replayed without parameter optimization or hidden-input access, and regenerated the submitted CIFs and fractions. The background and total calculated pattern remain positive, and there are no profile-review flags.

After smoothing the standardized residual over about 0.04° 2θ, the largest positive maximum is 1.44σ and no maximum exceeds 2σ. The remaining maxima coincide with reflections of the accepted phases, so there is no coherent unassigned reflection family warranting another phase.

## Remaining uncertainty

The formal fraction uncertainties are optimistic. Calcite is weak and its scale is correlated with crystallite size and a uniform Uiso near the allowed upper range; a practical uncertainty of roughly 0.5-1 wt% is more realistic than its internal 0.17 wt% standard uncertainty. WO3 oxygen coordinates are less secure than its cell and W sublattice because Cu Kα scattering is W-dominated, although site-by-site refinements remained physically valid. Instrument zero and specimen displacement are 99.6% correlated; they should be treated as joint nuisance calibration. The Gaussian U profile term reached the physical boundary U = 0 and was fixed there, while all total peak widths remained positive.

The delivered `fit.csv`, CIFs, fractions, and statistics all derive from the same saved `final.gpx` replay.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
