#!/usr/bin/env python3
"""Refine atomic parameters one phase/element class at a time in GSAS-II."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def rwp(project: G2.G2Project) -> float:
    return float(project.histograms()[0].get_wR())


def freeze_profile(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    hist.clear_refinements(
        {
            "Instrument Parameters": [k for k, v in inst.items() if isinstance(v, list) and len(v) > 2],
            "Sample Parameters": [
                key
                for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
                if key in hist.data["Sample Parameters"]
            ],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True, "Extinction": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        for atom in phase.atoms():
            atom.refinement_flags = ""


def stage(
    project: G2.G2Project,
    outdir: Path,
    tag: str,
    phase_name: str,
    element: str,
    atom_label: str | None = None,
    flag: str = "X",
    cycles: int = 5,
) -> tuple[G2.G2Project, dict]:
    freeze_profile(project)
    phase = project.phase(phase_name)
    selected = []
    for index, atom in enumerate(phase.atoms()):
        if atom.element.strip().upper() == element.upper() and (atom_label is None or atom.label == atom_label):
            atom.refinement_flags = flag
            selected.append((index, atom.label))
            if "X" in flag:
                for axis in "xyz":
                    variable = f"{phase.id}::dA{axis}:{index}"
                    project.set_Controls("parmMin", -0.008, variable=variable)
                    project.set_Controls("parmMax", 0.008, variable=variable)
            if "U" in flag:
                var = f"{phase.id}::AUiso:{index}"
                project.set_Controls("parmMin", 0.003, variable=var)
                project.set_Controls("parmMax", 0.020, variable=var)
    before = rwp(project)
    checkpoint = outdir / f"{tag}_before.gpx"
    project.save(str(checkpoint))
    project = G2.G2Project(gpxfile=str(checkpoint), newgpx=str(outdir / f"{tag}_trial.gpx"))
    project.set_Controls("cycles", cycles)
    print(f"\n===== {tag}: {phase_name} {element} {flag}, starting Rwp={before:.6g}% =====", flush=True)
    project.refine(makeBack=False)
    trial_rwp = rwp(project)
    accepted = trial_rwp <= before + 1e-7
    print(f"{tag}: Rwp={trial_rwp:.6g}% accepted={accepted}", flush=True)
    if not accepted:
        project = G2.G2Project(gpxfile=str(checkpoint), newgpx=str(outdir / "working.gpx"))
    else:
        project.save(str(outdir / f"{tag}.gpx"))
    return project, {
        "tag": tag,
        "phase": phase_name,
        "element": element,
        "atom_label": atom_label,
        "flag": flag,
        "selected_atoms": selected,
        "Rwp_before_percent": before,
        "Rwp_trial_percent": trial_rwp,
        "accepted": accepted,
        "Rwp_accepted_percent": rwp(project),
    }


def set_uniform_uiso(project: G2.G2Project, value: float = 0.010) -> None:
    """Set and tie one isotropic U value within each phase."""
    for phase in project.phases():
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = value
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(tuple(variables), override=True)


def full_replay(project: G2.G2Project, outdir: Path) -> tuple[G2.G2Project, dict]:
    # Keep variables that previously reached a physical bound frozen. Re-enable
    # the remaining profile, cell and specimen terms for a fresh coupled replay.
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    hist.set_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    before = rwp(project)
    checkpoint = outdir / "full_replay_before.gpx"
    project.save(str(checkpoint))
    project = G2.G2Project(gpxfile=str(checkpoint), newgpx=str(outdir / "full_replay_trial.gpx"))
    project.set_Controls("cycles", 8)
    print(f"\n===== full profile replay, starting Rwp={before:.6g}% =====", flush=True)
    project.refine(makeBack=False)
    after = rwp(project)
    accepted = after <= before + 1e-7
    print(f"full replay: Rwp={after:.6g}% accepted={accepted}", flush=True)
    if not accepted:
        project = G2.G2Project(gpxfile=str(checkpoint), newgpx=str(outdir / "working.gpx"))
    else:
        project.save(str(outdir / "full_replay.gpx"))
    return project, {
        "tag": "full_replay",
        "Rwp_before_percent": before,
        "Rwp_trial_percent": after,
        "accepted": accepted,
        "Rwp_accepted_percent": rwp(project),
    }


def export_state(project: G2.G2Project, outdir: Path) -> dict:
    project.save(str(outdir / "refined.gpx"))
    hist = project.histograms()[0]
    phases = []
    for phase in project.phases():
        cif = outdir / f"{phase.name}.cif"
        phase.export_CIF(str(cif))
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cif": str(cif),
                "cell": phase.get_cell(),
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "uiso": float(atom.uiso),
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    masses = [p["mass"] * p["scale"] for p in phases]
    for phase, amount in zip(phases, masses):
        phase["weight_fraction"] = amount / sum(masses)
    return {"Rwp_percent": rwp(project), "histogram": hist.name, "phases": phases}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--uiso", action="store_true")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.outdir / "working.gpx"))
    history = []

    project, row = stage(project, args.outdir, "stage01_wo3_w1", "WO3", "W", atom_label="W1")
    history.append(row)
    project, row = stage(project, args.outdir, "stage02_wo3_w2", "WO3", "W", atom_label="W2")
    history.append(row)
    project, row = stage(project, args.outdir, "stage03_cawo4_o", "CaWO4", "O")
    history.append(row)
    project, row = stage(project, args.outdir, "stage04_wo3_o", "WO3", "O", cycles=5)
    history.append(row)

    if args.uiso:
        freeze_profile(project)
        before = rwp(project)
        checkpoint = args.outdir / "stage05_uiso_before.gpx"
        project.save(str(checkpoint))
        set_uniform_uiso(project)
        uiso_start = args.outdir / "stage05_uiso_start.gpx"
        project.save(str(uiso_start))
        project = G2.G2Project(gpxfile=str(uiso_start), newgpx=str(args.outdir / "stage05_uiso_trial.gpx"))
        project.set_Controls("cycles", 8)
        print(f"\n===== stage05_uiso, starting Rwp={before:.6g}% =====", flush=True)
        project.refine(makeBack=False)
        after = rwp(project)
        accepted = after <= before + 1e-7
        if not accepted:
            project = G2.G2Project(gpxfile=str(checkpoint), newgpx=str(args.outdir / "working.gpx"))
        else:
            project.save(str(args.outdir / "stage05_uiso.gpx"))
        history.append(
            {
                "tag": "stage05_uiso",
                "Rwp_before_percent": before,
                "Rwp_trial_percent": after,
                "accepted": accepted,
                "Rwp_accepted_percent": rwp(project),
            }
        )

    project, row = full_replay(project, args.outdir)
    history.append(row)
    state = export_state(project, args.outdir)
    (args.outdir / "history.json").write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")
    (args.outdir / "state.json").write_text(json.dumps(state, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
