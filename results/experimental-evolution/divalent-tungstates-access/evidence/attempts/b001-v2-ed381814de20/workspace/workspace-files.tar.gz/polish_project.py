#!/usr/bin/env python3
"""Polish the accepted final state with only non-identifiable directions fixed.

This intentionally preserves all structural, profile and scale values from the
input project before refinement. It does not reset refinement flags globally.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def phase_fractions(project: G2.G2Project) -> list[dict[str, float | str]]:
    hist = project.histogram(0)
    records = []
    masses = []
    for phase in project.phases():
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        mass_scale = float(phase.data["General"]["Mass"]) * scale
        records.append({"name": phase.name, "scale": scale, "mass_scale": mass_scale})
        masses.append(mass_scale)
    total = sum(masses)
    for record, mass_scale in zip(records, masses):
        record["weight_fraction"] = mass_scale / total
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=20)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histogram(0)
    candidate = project.phase(2)
    hap = candidate.data["Histograms"][hist.name]

    # These four directions were previously frozen by GSAS-II at limits. Hold
    # their accepted values explicitly, rather than asking the least-squares
    # solver to rediscover a boundary or a flat direction.
    hist.InstrumentParameters["X"][2] = False
    hap["Size"][2][0] = False
    hap["Mustrain"][2][0] = False
    for atom in candidate.atoms():
        atom.refinement_flags = atom.refinement_flags.replace("U", "")

    # Sample displacement is highly correlated with the three refined cells;
    # retain its accepted value during this covariance-cleaning pass.
    hist.SampleParameters["Shift"][1] = False

    # The candidate common-U constraint became inconsistent when one Uiso hit
    # its bound. All candidate Uiso values are now fixed, so remove that stale
    # equality while retaining the unrelated fixed WO3 constraint record.
    phase_constraints = project.data["Constraints"]["data"].get("Phase", [])
    if len(phase_constraints) >= 2:
        del phase_constraints[1]

    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.refine(makeBack=False)
    project.save()

    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "rwp": float(hist.residuals["wR"]),
        "fractions": phase_fractions(project),
        "rvals": {
            key: rvals.get(key)
            for key in (
                "converged",
                "Aborted",
                "GOF",
                "Max shft/sig",
                "chisq",
                "Nobs",
                "Nvars",
                "SVD0",
                "msg",
            )
        },
    }
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
