#!/usr/bin/env python3
"""Screen non-ABO4 Mn-W-O stoichiometries against a common-state residual."""

from __future__ import annotations

import argparse
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy.ndimage import gaussian_filter1d

from screen_prototypes import INDEX, best_registration, cod_path, substituted


def records_for_target(target_formula: str) -> list[dict]:
    target = Composition(target_formula).reduced_composition
    target_amounts = {element: float(target[element]) for element in ("Mn", "W", "O")}
    target_cations = sorted([target_amounts["Mn"], target_amounts["W"]])
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    records = []
    seen = set()
    for key, rows in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "O" not in elements:
            continue
        cations = [element for element in elements if element != "O"]
        for formula, cod_id, space_group, r_factor in rows:
            if cod_id in seen:
                continue
            try:
                parent = Composition(formula).reduced_composition
                amounts = {element: float(parent[element]) for element in cations}
                oxygen = float(parent["O"])
            except Exception:
                continue
            if not np.allclose(sorted(amounts.values()), target_cations, atol=1e-5):
                continue
            if not np.isclose(oxygen, target_amounts["O"], atol=1e-5):
                continue
            mappings = []
            if not np.isclose(target_amounts["Mn"], target_amounts["W"]):
                mn_parent = min(cations, key=lambda element: abs(amounts[element] - target_amounts["Mn"]))
                w_parent = [element for element in cations if element != mn_parent][0]
                if not np.isclose(amounts[mn_parent], target_amounts["Mn"], atol=1e-5):
                    continue
                mappings = [{mn_parent: "Mn", w_parent: "W"}]
            else:
                mappings = [
                    {cations[0]: "Mn", cations[1]: "W"},
                    {cations[0]: "W", cations[1]: "Mn"},
                ]
            seen.add(cod_id)
            for mapping in mappings:
                records.append(
                    {
                        "target_formula": target_formula,
                        "id": cod_id,
                        "formula": formula,
                        "space_group_index": space_group,
                        "r_factor": r_factor,
                        "mapping": mapping,
                    }
                )
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", type=Path)
    parser.add_argument(
        "--targets",
        nargs="+",
        default=["Mn2WO5", "Mn2WO6", "Mn3WO6", "Mn3W2O8"],
    )
    parser.add_argument("--limit", type=int, default=50)
    parser.add_argument("--output", type=Path, default=Path("stoichiometry_screen.json"))
    args = parser.parse_args()

    data = np.loadtxt(args.profile, delimiter=",", skiprows=1)
    x, observed, calculated, background, difference, weight = data.T
    target_profile = gaussian_filter1d(np.maximum(difference, 0.0), 2.0)
    target_profile = np.maximum(target_profile - 100.0, 0.0)
    calculator = XRDCalculator(wavelength="CuKa")
    all_results = {}
    for target_formula in args.targets:
        results = []
        records = records_for_target(target_formula)
        print(f"{target_formula}: {len(records)} source records", flush=True)
        for record in records:
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    parent = Structure.from_file(cod_path(record["id"]))
                if len(parent) > 300:
                    continue
                model = substituted(parent, record["mapping"])
                pattern = calculator.get_pattern(model, two_theta_range=(5.0, 135.0), scaled=True)
                positions = np.asarray(pattern.x, dtype=float)
                intensities = np.asarray(pattern.y, dtype=float)
                keep = intensities >= 0.4
                registration = best_registration(
                    x, target_profile, positions[keep], intensities[keep]
                )
                results.append(
                    {
                        **record,
                        "parent_space_group": parent.get_space_group_info(),
                        "parent_cell": [*parent.lattice.abc, *parent.lattice.angles],
                        "sites": len(parent),
                        **registration,
                    }
                )
            except Exception:
                continue
        results.sort(key=lambda item: item["score"], reverse=True)
        all_results[target_formula] = results[: args.limit]
        for result in results[:20]:
            print(
                f"  {result['score']:.4f} {result['id']} {result['formula']:<18} "
                f"SG={result['parent_space_group'][1]:>3} scale={result['lattice_scale']:.4f} "
                f"zero={result['zero_deg']:+.3f} map={result['mapping']}"
            )
    args.output.write_text(json.dumps(all_results, indent=2) + "\n")


if __name__ == "__main__":
    main()
