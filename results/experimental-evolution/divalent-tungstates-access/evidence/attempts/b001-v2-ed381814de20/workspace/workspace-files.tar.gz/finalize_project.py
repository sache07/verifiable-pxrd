#!/usr/bin/env python3
"""Final clean replay with accepted boundary parameters held fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import activate_common, set_bound


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=25)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    clear_all_flags(project)
    hist = project.histogram(0)
    activate_common(project)

    # Ordinary isotropic profiles remain refinable for the two established
    # phases. In Mn2WO5, the boundary-limited size and equatorial strain are
    # fixed, while the identifiable axial strain remains free.
    for phase_index in (0, 1):
        phase = project.phase(phase_index)
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    candidate = project.phase(2)
    candidate_hap = candidate.data["Histograms"][hist.name]
    candidate_hap["Size"][0] = "isotropic"
    candidate_hap["Size"][1][0] = 1.5
    candidate_hap["Size"][2] = [False, False, False]
    candidate_hap["Mustrain"][0] = "uniaxial"
    candidate_hap["Mustrain"][1][0] = 8000.0
    candidate_hap["Mustrain"][2] = [False, True, False]
    candidate_hap["Mustrain"][3] = [0, 1, 0]
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][2] = True
    candidate_hap["Pref.Ori."][3] = [0, 1, 0]

    # X and the transferred phase Uiso are accepted at physical boundaries.
    hist.InstrumentParameters["X"][1] = 0.1
    hist.InstrumentParameters["X"][2] = False
    for atom in candidate.atoms():
        atom.ADP = 0.003
        atom.refinement_flags = " "
    hist.set_refinements(
        {"Instrument Parameters": ["W", "SH/L", "Polariz."]}
    )

    set_bound(project, "2:0:MD", 0.7, 1.4)
    set_bound(project, "2:0:Mustrain;a", 75.0, 32000.0)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for phase_index in range(3):
        set_bound(project, f"{phase_index}:0:Scale", 1e-12, 1e6)
    for phase_index in (0, 1):
        set_bound(project, f"{phase_index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase_index}:0:Mustrain;i", 0.0, 8000.0)

    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.refine(makeBack=False)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "rwp": float(hist.residuals["wR"]),
        "fractions": fractions(project),
        "texture_coefficient": float(candidate_hap["Pref.Ori."][1]),
        "candidate_strain": candidate_hap["Mustrain"][1][:2],
        "rvals": {
            key: rvals.get(key)
            for key in ("converged", "Aborted", "GOF", "Max shft/sig", "chisq", "Nobs", "Nvars")
        },
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
