#!/usr/bin/env python3
"""Build and progressively refine trial GSAS-II models for this PXRD case."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
INSTRUMENT = ROOT / "instrument.instprm"
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total if total > 0 else None
    record = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: value
            for key, value in inst.items()
            if key in {"Lam", "Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: sample.get(key)
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type")
        },
        "background": hist.data["Background"],
        "phases": phases,
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "variables": project.data.get("Covariance", {}).get("data", {}).get("variables", []).tolist()
        if hasattr(project.data.get("Covariance", {}).get("data", {}).get("variables", []), "tolist")
        else project.data.get("Covariance", {}).get("data", {}).get("variables", []),
        "sig": project.data.get("Covariance", {}).get("data", {}).get("sig", []).tolist()
        if hasattr(project.data.get("Covariance", {}).get("data", {}).get("sig", []), "tolist")
        else project.data.get("Covariance", {}).get("data", {}).get("sig", []),
    }
    print(json.dumps(record, indent=2, default=float))
    project.save(ROOT / f"trial_{label}.gpx")


def set_cycles(project: G2.G2Project, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5


def refine(project: G2.G2Project, label: str, cycles: int = 8) -> None:
    set_cycles(project, cycles)
    project.refine(makeBack=False)
    snapshot(project, label)


def build(cod_ids: list[str], output: Path) -> G2.G2Project:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), str(INSTRUMENT), fmthint="comma/tab/semicolon separated"
    )
    hist.data["Limits"] = [
        [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
    ]
    sample = hist.SampleParameters
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1500.0] + [0.0] * 9,
                "refine": True,
            }
        }
    )
    for cod_id in cod_ids:
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=f"COD_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0 / phase.data["General"]["Mass"], True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][1][1] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        hap["Extinction"] = [0.0, False]
    project.save()
    return project


def single_phase(output: Path) -> None:
    project = build(["1520200"], output)
    hist = project.histogram(0)
    phase = project.phase(0)

    # The compact high-pressure reference has a nearly uniform positive
    # displacement relative to the observed peaks. Seed the angular term close
    # to the measured offset so the first linear scale/background fit is stable.
    hist.InstrumentParameters["Zero"][1] = 0.34

    refine(project, "01_scale_background", 10)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "02_zero", 10)

    phase.set_refinements({"Cell": True})
    refine(project, "03_cell", 10)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "04_shift", 10)

    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    refine(project, "05_profile", 15)

    # Refine heavy-atom and oxygen coordinates after peak positions/profile stabilize.
    phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "06_coordinates", 15)

    project.save(output)


def set_bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def physical_single_phase(output: Path) -> None:
    """Fit a bounded, physically admissible one-phase nuisance model."""
    project = build(["1520200"], output)
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters

    # A near-constant +0.34 degree observed displacement can be represented by
    # a physically plausible combination of specimen height and angular zero.
    inst["Zero"][1] = 0.10
    sample["Shift"] = [-500.0, False]
    inst["U"][1] = 10.0
    inst["W"][1] = 15.0
    inst["X"][1] = 2.0
    inst["SH/L"][1] = 0.025
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][1][0] = 0.3
    hap["Mustrain"][1][0] = 3000.0

    project.save()
    for variable, low, high in (
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        ("0:0:Size;i", 0.04, 1.5),
        ("0:0:Mustrain;i", 0.0, 8000.0),
    ):
        set_bound(project, variable, low, high)

    refine(project, "p01_scale_background", 12)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "p02_cell_shift", 12)

    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "p03_profile", 15)

    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, "p04_size", 12)

    phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "p05_coordinates", 15)
    project.save(output)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["single", "physical"], default="single")
    parser.add_argument("--output", type=Path, default=ROOT / "trial_single.gpx")
    args = parser.parse_args()
    if args.mode == "single":
        single_phase(args.output.resolve())
    elif args.mode == "physical":
        physical_single_phase(args.output.resolve())


if __name__ == "__main__":
    main()
