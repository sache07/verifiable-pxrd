#!/usr/bin/env python3
"""Staged ordinary refinement of the accepted multiphase GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions


def set_bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def activate_common(project: G2.G2Project) -> None:
    """Activate ordinary whole-pattern terms shared by each safe stage."""
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})


def activate_profiles(project: G2.G2Project, *, size: bool, strain: bool) -> None:
    for phase in project.phases():
        refinements = {}
        if size:
            refinements["Size"] = {"type": "isotropic", "refine": True}
        if strain:
            refinements["Mustrain"] = {"type": "isotropic", "refine": True}
        if refinements:
            phase.set_HAP_refinements(refinements)


def activate_coordinates(project: G2.G2Project, stage: str) -> None:
    for phase_index, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            if stage == "heavy":
                refine = atom.element != "O"
            elif stage == "main_all":
                refine = phase_index == 0 or atom.element != "O"
            elif stage == "candidate_all":
                # The established wolframite coordinates were already refined;
                # keep them active, refine W sites in WO3, and allow the
                # transferred Pnnm framework to adapt fully.
                refine = phase_index in (0, 2) or atom.element != "O"
            elif stage == "allcoords":
                refine = True
            else:
                refine = False
            atom.refinement_flags = "X" if refine else " "


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    return {
        "stage": stage,
        "rwp": float(hist.residuals["wR"]),
        "gof": float(project.data.get("Covariance", {}).get("data", {}).get("GOF", float("nan"))),
        "fractions": fractions(project),
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: hist.SampleParameters.get(key)
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"][1][0],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
            }
            for phase in project.phases()
        ],
        "maximum_shift_over_esd": project.data.get("Covariance", {})
        .get("data", {})
        .get("Max shft/sig"),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--stages",
        nargs="+",
        choices=["base", "size", "strain", "instrument", "heavy", "main_all", "candidate_all", "allcoords"],
        default=["base", "size", "strain", "instrument"],
    )
    parser.add_argument("--cycles", type=int, default=20)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histogram(0)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    for phase_index, _phase in enumerate(project.phases()):
        set_bound(project, f"{phase_index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase_index}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase_index}:0:Scale", 1e-12, 1e6)

    history = []
    for number, stage in enumerate(args.stages, start=1):
        clear_all_flags(project)
        activate_common(project)
        if stage in {"size", "strain", "instrument", "heavy", "main_all", "candidate_all", "allcoords"}:
            activate_profiles(project, size=True, strain=False)
        if stage in {"strain", "instrument", "heavy", "main_all", "candidate_all", "allcoords"}:
            activate_profiles(project, size=True, strain=True)
        if stage in {"instrument", "heavy", "main_all", "candidate_all", "allcoords"}:
            hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
        if stage in {"heavy", "main_all", "candidate_all", "allcoords"}:
            activate_coordinates(project, stage)
        project.set_Controls("cycles", args.cycles)
        project.data["Controls"]["data"]["min dM/M"] = 1e-6
        project.save()
        project.refine(makeBack=False)
        project.save()
        record = snapshot(project, stage)
        history.append(record)
        print(json.dumps(record, indent=2), flush=True)
        checkpoint = args.output.with_name(f"{args.output.stem}_{number:02d}_{stage}.gpx")
        project.save(str(checkpoint))
        project.save(str(args.output))
    args.output.with_suffix(".history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
