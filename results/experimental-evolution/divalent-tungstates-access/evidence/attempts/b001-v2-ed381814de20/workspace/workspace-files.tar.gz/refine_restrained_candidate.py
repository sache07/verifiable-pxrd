#!/usr/bin/env python3
"""Refine the transferred Pnnm oxygen framework with bond restraints."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import activate_common, activate_profiles, set_bound


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--weight", type=float, required=True)
    parser.add_argument("--targets", choices=["physical", "parent"], default="physical")
    parser.add_argument("--mn-restraints", action="store_true")
    parser.add_argument("--cycles", type=int, default=15)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histogram(0)
    candidate = project.phase(2)

    project.data["Restraints"]["data"][candidate.name] = {
        "Bond": {"wtFactor": float(args.weight), "Range": 1.1, "Bonds": [], "Use": True}
    }
    if args.targets == "physical":
        targets = {"O4": 1.72, "O3": 1.76, "O2": 1.84}
    else:
        targets = {"O4": 1.62, "O3": 1.72, "O2": 1.86}
    counts = {}
    for oxygen, distance in targets.items():
        counts[f"W2-{oxygen}"] = candidate.addDistRestraint(
            ["W2"], [oxygen], distance, factor=1.25, ESD=0.03
        )
    if args.mn_restraints:
        oxygen_atoms = [atom for atom in candidate.atoms() if atom.element == "O"]
        counts["Mn-O"] = candidate.addDistRestraint(
            ["Mn1", "Mn2"], oxygen_atoms, 2.18, factor=1.18, ESD=0.12
        )
    candidate.setDistRestraintWeight(args.weight)

    clear_all_flags(project)
    activate_common(project)
    activate_profiles(project, size=True, strain=True)
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    for phase_index, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            # Keep the established main structure adjustable, retain only W
            # positional freedom in triclinic WO3, and refine all sites in the
            # restrained transferred framework.
            atom.refinement_flags = "X" if phase_index in (0, 2) or atom.element != "O" else " "

    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for phase_index, _phase in enumerate(project.phases()):
        set_bound(project, f"{phase_index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase_index}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase_index}:0:Scale", 1e-12, 1e6)
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {
        "rwp": float(hist.residuals["wR"]),
        "fractions": fractions(project),
        "restraint_weight": args.weight,
        "targets": args.targets,
        "mn_restraints": args.mn_restraints,
        "restraint_counts": counts,
        "cell": candidate.get_cell(),
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
