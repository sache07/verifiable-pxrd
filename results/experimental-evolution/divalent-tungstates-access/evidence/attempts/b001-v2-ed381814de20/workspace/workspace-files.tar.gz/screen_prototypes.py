#!/usr/bin/env python3
"""Residual-directed screening of ABO4 prototype structures from the frozen COD."""

from __future__ import annotations

import argparse
import gzip
import json
import math
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure
from scipy.ndimage import gaussian_filter1d


LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
INDEX = LIBRARY.parent / "index.json.gz"


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def abo4_records() -> list[dict]:
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    records = []
    seen = set()
    for key, rows in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "O" not in elements:
            continue
        cations = [element for element in elements if element != "O"]
        for formula, cod_id, space_group, r_factor in rows:
            if cod_id in seen:
                continue
            try:
                reduced = Composition(formula).reduced_composition
                amounts = sorted(float(reduced[element]) for element in cations)
                oxygen = float(reduced["O"])
            except Exception:
                continue
            if not np.allclose(amounts, [1.0, 1.0], atol=1e-5) or not math.isclose(oxygen, 4.0, abs_tol=1e-5):
                continue
            oxidation = None
            try:
                guesses = reduced.oxi_state_guesses()[:8]
            except Exception:
                guesses = []
            for guess in guesses:
                try:
                    values = sorted(round(float(guess[element])) for element in cations)
                except Exception:
                    continue
                if values == [2, 6]:
                    oxidation = guess
                    break
            if oxidation is None:
                continue
            low = min(cations, key=lambda element: oxidation[element])
            high = max(cations, key=lambda element: oxidation[element])
            seen.add(cod_id)
            records.append(
                {
                    "id": cod_id,
                    "formula": formula,
                    "space_group_index": space_group,
                    "r_factor": r_factor,
                    "elements": cations,
                    "target_mapping": {low: "Mn", high: "W"},
                }
            )
    return records


def broaden_pattern(x_grid: np.ndarray, positions: np.ndarray, intensities: np.ndarray, fwhm: float = 0.28) -> np.ndarray:
    impulses = np.zeros_like(x_grid)
    indices = np.searchsorted(x_grid, positions)
    valid = (indices > 0) & (indices < len(x_grid))
    indices = indices[valid]
    positions = positions[valid]
    intensities = intensities[valid]
    left = indices - 1
    choose_left = np.abs(x_grid[left] - positions) < np.abs(x_grid[indices] - positions)
    indices[choose_left] = left[choose_left]
    np.add.at(impulses, indices, intensities)
    sigma_points = fwhm / 2.35482 / np.median(np.diff(x_grid))
    return gaussian_filter1d(impulses, sigma_points, mode="constant")


def transform_positions(positions: np.ndarray, lattice_scale: float, zero: float) -> np.ndarray:
    argument = np.sin(np.deg2rad(positions / 2.0)) / lattice_scale
    transformed = np.full_like(argument, np.nan)
    valid = np.abs(argument) < 1
    transformed[valid] = 2.0 * np.rad2deg(np.arcsin(argument[valid])) + zero
    return transformed


def best_registration(x: np.ndarray, target: np.ndarray, positions: np.ndarray, intensities: np.ndarray) -> dict:
    """Fast coarse registration on a 0.05-degree grid.

    The result is only a prototype shortlist: anisotropic cell refinement and
    the common-state Rietveld test decide whether a framework is retained.
    """
    step = 0.05
    grid = np.arange(9.8, 100.21, step)
    target_grid = np.interp(grid, x, target)
    target_norm = float(np.dot(target_grid, target_grid))
    scales = np.linspace(0.80, 1.20, 67)
    profiles = np.zeros((len(scales), len(grid)), dtype=float)
    for row, lattice_scale in enumerate(scales):
        transformed = transform_positions(positions, lattice_scale, 0.0)
        finite = np.isfinite(transformed)
        indices = np.zeros(len(transformed), dtype=np.int64)
        indices[finite] = np.rint((transformed[finite] - grid[0]) / step).astype(np.int64)
        valid = finite & (indices >= 0) & (indices < len(grid))
        np.add.at(profiles[row], indices[valid], intensities[valid])
    profiles = gaussian_filter1d(profiles, 0.28 / 2.35482 / step, axis=1, mode="constant")
    best = {"score": -np.inf}
    # Shared project nuisance corresponds to an approximately +0.3--0.4 degree
    # low-angle correction. Do not let each prototype invent an independent zero.
    for lag in range(4, 10):
        if lag < 0:
            candidate = profiles[:, :lag]
            observed = target_grid[-lag:]
        elif lag > 0:
            candidate = profiles[:, lag:]
            observed = target_grid[:-lag]
        else:
            candidate = profiles
            observed = target_grid
        numerator = candidate @ observed
        candidate_norm = np.einsum("ij,ij->i", candidate, candidate)
        scores = numerator / np.sqrt(np.maximum(candidate_norm * target_norm, 1e-30))
        row = int(np.argmax(scores))
        score = float(scores[row])
        if score > best["score"]:
            denominator = float(candidate_norm[row])
            amplitude = max(0.0, float(numerator[row] / denominator)) if denominator > 0 else 0.0
            best = {
                "score": score,
                "lattice_scale": float(scales[row]),
                "zero_deg": float(lag * step),
                "amplitude": amplitude,
                "sse": float(target_norm - 2 * amplitude * numerator[row] + amplitude * amplitude * denominator),
            }
    return best


def substituted(structure: Structure, mapping: dict[str, str]) -> Structure:
    result = structure.copy()
    try:
        result.remove_oxidation_states()
    except Exception:
        pass
    result.replace_species(mapping)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", type=Path)
    parser.add_argument("--limit", type=int, default=100)
    parser.add_argument("--output", type=Path, default=Path("prototype_screen.json"))
    args = parser.parse_args()

    data = np.loadtxt(args.profile, delimiter=",", skiprows=1)
    x, observed, calculated, background, difference, weight = data.T
    # Keep only positive coherent residual intensity, smooth over counting noise,
    # and downweight the low residual floor.
    target = gaussian_filter1d(np.maximum(difference, 0.0), 2.0)
    target = np.maximum(target - 100.0, 0.0)
    calculator = XRDCalculator(wavelength="CuKa")
    results = []
    for number, record in enumerate(abo4_records(), start=1):
        path = cod_path(record["id"])
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                parent = Structure.from_file(path)
            if len(parent) > 300:
                continue
            for mapping in (record["target_mapping"],):
                model = substituted(parent, mapping)
                pattern = calculator.get_pattern(model, two_theta_range=(5.0, 135.0), scaled=True)
                positions = np.asarray(pattern.x, dtype=float)
                intensities = np.asarray(pattern.y, dtype=float)
                keep = intensities >= 0.4
                registration = best_registration(x, target, positions[keep], intensities[keep])
                results.append(
                    {
                        **record,
                        "mapping": mapping,
                        "parent_space_group": parent.get_space_group_info(),
                        "parent_cell": [*parent.lattice.abc, *parent.lattice.angles],
                        "sites": len(parent),
                        **registration,
                    }
                )
        except Exception as exc:
            continue
    results.sort(key=lambda item: item["score"], reverse=True)
    args.output.write_text(json.dumps(results[: args.limit], indent=2) + "\n")
    for result in results[: min(args.limit, 60)]:
        print(
            f"{result['score']:.4f} {result['id']} {result['formula']:<18} "
            f"SG={result['parent_space_group'][1]:>3} scale={result['lattice_scale']:.4f} "
            f"zero={result['zero_deg']:+.3f} map={result['mapping']}"
        )


if __name__ == "__main__":
    main()
