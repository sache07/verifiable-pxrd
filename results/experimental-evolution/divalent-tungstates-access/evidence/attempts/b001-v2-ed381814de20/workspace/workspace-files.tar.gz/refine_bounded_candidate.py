#!/usr/bin/env python3
"""Refine the Pnnm framework with bounded coordinate increments."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import activate_common, activate_profiles, set_bound


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--coordinate-limit", type=float, required=True)
    parser.add_argument("--cycles", type=int, default=15)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histogram(0)
    clear_all_flags(project)
    activate_common(project)
    activate_profiles(project, size=True, strain=True)
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    for phase_index, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = "X" if phase_index in (0, 2) or atom.element != "O" else " "

    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for phase_index, _phase in enumerate(project.phases()):
        set_bound(project, f"{phase_index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase_index}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase_index}:0:Scale", 1e-12, 1e6)
    # Despite their dA names, GSAS-II applies parmMin/parmMax to the resulting
    # absolute fractional coordinate. Center each limit on the current atom;
    # nonexistent symmetry-fixed terms are ignored by the refiner.
    limit = float(args.coordinate_limit)
    for atom_index, atom in enumerate(project.phase(2).atoms()):
        for axis, center in zip("xyz", atom.coordinates):
            set_bound(
                project,
                f"2::dA{axis}:{atom_index}",
                float(center) - limit,
                float(center) + limit,
            )

    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {
        "rwp": float(hist.residuals["wR"]),
        "fractions": fractions(project),
        "coordinate_limit_fractional": limit,
        "cell": project.phase(2).get_cell(),
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
