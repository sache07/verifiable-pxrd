#!/usr/bin/env python3
"""Continue a surviving common-state trial with only scales and its cell free."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=40)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    clear_all_flags(project)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.phase(len(project.phases()) - 1).set_refinements({"Cell": True})
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.refine(makeBack=False)
    project.save()
    print(
        json.dumps(
            {
                "rwp": float(hist.residuals["wR"]),
                "fractions": fractions(project),
                "cell": project.phase(len(project.phases()) - 1).get_cell(),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
