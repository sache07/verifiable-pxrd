#!/usr/bin/env python3
"""Normalize selected ordinary references to stable isotropic-ADP CIFs."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
IDS = {
    "mn3o4_i41amd": "1011262",
    "mn3o4_pbcm": "1514104",
    "mn2o3_ia3": "1514230",
    "mn2o3_pbca": "1514103",
    "wo3_p21m": "1010618",
    "wo3_p21c": "1528915",
    "wo3_p1bar": "2106293",
    "wo3_pnma": "2107312",
}


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    output = ROOT / "ordinary_models"
    output.mkdir(exist_ok=True)
    for label, cod_id in IDS.items():
        structure = Structure.from_file(cod_path(cod_id))
        try:
            structure.remove_oxidation_states()
        except Exception:
            pass
        CifWriter(structure, symprec=1e-3, refine_struct=False, significant_figures=10).write_file(
            output / f"{label}.cif"
        )


if __name__ == "__main__":
    main()
