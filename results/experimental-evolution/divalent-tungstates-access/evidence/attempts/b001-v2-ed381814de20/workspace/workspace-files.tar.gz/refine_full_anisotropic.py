#!/usr/bin/env python3
"""Joint accepted model with [010] uniaxial strain in Pnnm Mn2WO5."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import activate_common, set_bound


def serial_adp(value):
    if isinstance(value, (list, tuple)):
        return [float(item) for item in value]
    return float(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=25)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    # A replay must not inherit variables frozen by earlier rejected or
    # bounded trial stages. Current boundary hits will be rediscovered cleanly.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    clear_all_flags(project)
    hist = project.histogram(0)
    activate_common(project)
    for phase_index, phase in enumerate(project.phases()):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        if phase_index == 2:
            phase.set_HAP_refinements(
                {
                    "Mustrain": {
                        "type": "uniaxial",
                        "refine": True,
                        "direction": [0, 1, 0],
                    }
                }
            )
        else:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
    hist.set_refinements(
        {"Instrument Parameters": ["W", "X", "SH/L", "Polariz."]}
    )
    candidate_hap = project.phase(2).data["Histograms"][hist.name]
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][2] = True
    candidate_hap["Pref.Ori."][3] = [0, 1, 0]
    for atom in project.phase(2).atoms():
        atom.refinement_flags = "U"

    set_bound(project, "2:0:MD", 0.7, 1.4)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for phase_index, phase in enumerate(project.phases()):
        set_bound(project, f"{phase_index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase_index}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase_index}:0:Scale", 1e-12, 1e6)
        if phase_index == 2:
            set_bound(project, "2:0:Mustrain;a", 75.0, 32000.0)
            for atom_index, _atom in enumerate(phase.atoms()):
                set_bound(project, f"2::AUiso:{atom_index}", 0.003, 0.02)

    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {
        "rwp": float(hist.residuals["wR"]),
        "fractions": fractions(project),
        "texture": {
            "axis": candidate_hap["Pref.Ori."][3],
            "coefficient": float(candidate_hap["Pref.Ori."][1]),
        },
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("W", "X", "SH/L", "Polariz.", "Zero")
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "size_model": phase.data["Histograms"][hist.name]["Size"],
                "mustrain_model": phase.data["Histograms"][hist.name]["Mustrain"],
                "adps": [serial_adp(atom.ADP) for atom in phase.atoms()],
            }
            for phase in project.phases()
        ],
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
