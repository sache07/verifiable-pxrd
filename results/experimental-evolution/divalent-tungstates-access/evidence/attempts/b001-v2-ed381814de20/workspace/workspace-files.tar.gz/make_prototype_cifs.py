#!/usr/bin/env python3
"""Create Mn-W-O target-composition analogues from shortlisted ABO4 parents."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


MODELS = {
    # label: (COD parent, substitutions, isotropic starting-cell scale)
    "abo4_pmn21_8103529": ("8103529", {"Cd": "Mn", "S": "W"}, 1.1273),
    "abo4_c2m_1527061": ("1527061", {"Mn": "Mn", "Mo": "W"}, 0.8727),
    "abo4_pnma_1537317": ("1537317", {"Mn": "Mn", "Se": "W"}, 1.1636),
    "abo4_p1bar_1528282": ("1528282", {"Zn": "Mn", "Mo": "W"}, 0.9152),
    "abo4_imma_2311029": ("2311029", {"Mg": "Mn", "U": "W"}, 0.8970),
    "abo4_cmcm_4336422": ("4336422", {"Mn": "Mn", "Cr": "W"}, 1.1394),
    "abo4_p3m1_1533737": ("1533737", {"Cd": "Mn", "S": "W"}, 1.0000),
    "abo4_c2c_2107005": ("2107005", {"Hg": "Mn", "Mo": "W"}, 0.8242),
    "abo4_i41a_1547818": ("1547818", {"Sr": "Mn", "Cr": "W"}, 1.0061),
}


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    output = ROOT / "trial_models"
    output.mkdir(exist_ok=True)
    provenance = []
    for label, (cod_id, mapping, scale) in MODELS.items():
        structure = Structure.from_file(cod_path(cod_id))
        try:
            structure.remove_oxidation_states()
        except Exception:
            pass
        structure.replace_species(mapping)
        structure.scale_lattice(structure.volume * scale**3)
        path = output / f"{label}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=False, significant_figures=10).write_file(path)
        provenance.append(
            {
                "label": label,
                "path": str(path.relative_to(ROOT)),
                "parent_cod_id": cod_id,
                "parent_path": str(cod_path(cod_id)),
                "substitutions": mapping,
                "isotropic_starting_cell_scale": scale,
                "composition": structure.composition.reduced_formula,
                "space_group": structure.get_space_group_info(),
                "cell": [*structure.lattice.abc, *structure.lattice.angles],
                "sites": len(structure),
            }
        )
    (output / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
