#!/usr/bin/env python3
"""Refine triclinic WO3 coordinates within a small physical transfer bound."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import activate_common, activate_profiles, set_bound


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--coordinate-limit", type=float, required=True)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histogram(0)
    clear_all_flags(project)
    activate_common(project)
    activate_profiles(project, size=True, strain=True)
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    # Keep the accepted texture active but fixed during this coordinate test.
    candidate_hap = project.phase(2).data["Histograms"][hist.name]
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][1] = 0.7
    candidate_hap["Pref.Ori."][2] = False
    candidate_hap["Pref.Ori."][3] = [0, 1, 0]

    wo3 = project.phase(1)
    for atom in wo3.atoms():
        atom.refinement_flags = "X"
    limit = float(args.coordinate_limit)
    for atom_index, atom in enumerate(wo3.atoms()):
        for axis, center in zip("xyz", atom.coordinates):
            set_bound(
                project,
                f"1::dA{axis}:{atom_index}",
                float(center) - limit,
                float(center) + limit,
            )

    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for phase_index, _phase in enumerate(project.phases()):
        set_bound(project, f"{phase_index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase_index}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase_index}:0:Scale", 1e-12, 1e6)

    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {
        "rwp_pre_replay": float(hist.residuals["wR"]),
        "fractions_pre_replay": fractions(project),
        "coordinate_limit_fractional": limit,
        "cell": wo3.get_cell(),
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
