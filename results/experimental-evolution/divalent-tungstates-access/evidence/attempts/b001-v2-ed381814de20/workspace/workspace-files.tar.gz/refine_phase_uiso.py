#!/usr/bin/env python3
"""Refine one constrained isotropic displacement parameter per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import set_bound


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=15)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    clear_all_flags(project)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    # Start from a clean constraint set so each phase has exactly one Uiso.
    for scope in ("Hist", "HAP", "Phase", "Global"):
        project.get_Constraints(scope)[:] = []
    project.save()
    project.index_ids()
    for phase_index, phase in enumerate(project.phases()):
        if any(atom.adp_flag != "I" for atom in phase.atoms()):
            # Do not mix scalar and tensor ADPs in an artificial equality.
            # The available wolframite reference contains anisotropic heavy
            # atoms, so leave that published ADP model fixed.
            continue
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            atom.ADP = min(0.02, max(0.003, float(atom.ADP)))
            variable = f"{phase_index}::AUiso:{atom_index}"
            variables.append(variable)
            set_bound(project, variable, 0.003, 0.02)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {
        "rwp": float(hist.residuals["wR"]),
        "fractions": fractions(project),
        "phase_uiso_A2": [
            {
                "name": phase.name,
                "values": [float(atom.ADP) for atom in phase.atoms()],
            }
            for phase in project.phases()
        ],
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
