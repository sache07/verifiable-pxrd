#!/usr/bin/env python3
"""Common-state uniaxial microstrain test for one phase and axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import set_bound


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", type=int)
    parser.add_argument("h", type=int)
    parser.add_argument("k", type=int)
    parser.add_argument("l", type=int)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    clear_all_flags(project)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    isotropic = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = isotropic
    hap["Mustrain"][1][1] = isotropic
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = [args.h, args.k, args.l]
    set_bound(project, f"{args.phase}:0:Mustrain;i", 0.0, 8000.0)
    set_bound(project, f"{args.phase}:0:Mustrain;a", 0.0, 8000.0)
    project.set_Controls("cycles", 15)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {
        "phase_index": args.phase,
        "phase_name": phase.name,
        "axis": [args.h, args.k, args.l],
        "equatorial_microstrain_ppm": float(hap["Mustrain"][1][0]),
        "axial_microstrain_ppm": float(hap["Mustrain"][1][1]),
        "rwp": float(hist.residuals["wR"]),
        "fractions": fractions(project),
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
