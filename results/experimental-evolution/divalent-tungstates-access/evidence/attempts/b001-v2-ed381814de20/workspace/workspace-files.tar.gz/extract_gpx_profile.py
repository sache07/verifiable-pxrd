#!/usr/bin/env python3
"""Extract the saved GSAS-II profile arrays for diagnostics."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--histogram", default=0)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.project.resolve()))
    hist = project.histogram(int(args.histogram) if str(args.histogram).isdigit() else args.histogram)
    x, observed, weight, calculated, background, difference = hist.data["data"][1]
    table = np.column_stack((x, observed, calculated, background, observed - calculated, weight))
    np.savetxt(
        args.output,
        table,
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference,weight",
        comments="",
        fmt=["%.8f", "%.8g", "%.8g", "%.8g", "%.8g", "%.10g"],
    )


if __name__ == "__main__":
    main()
