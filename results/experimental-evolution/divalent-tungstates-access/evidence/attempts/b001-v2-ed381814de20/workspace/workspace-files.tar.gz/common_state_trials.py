#!/usr/bin/env python3
"""Test phase additions inside a fixed common GSAS-II project state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


ORDINARY = {
    label: ROOT / "ordinary_models" / f"{label}.cif"
    for label in (
        "mn3o4_i41amd",
        "mn3o4_pbcm",
        "mn2o3_ia3",
        "mn2o3_pbca",
        "wo3_p21c",
        "wo3_p1bar",
        "wo3_pnma",
    )
}


def clear_all_flags(project: G2.G2Project) -> None:
    for hist in project.histograms():
        hist.data["Background"][0][1] = False
        for value in hist.InstrumentParameters.values():
            if isinstance(value, list) and len(value) > 2 and isinstance(value[2], (bool, np.bool_)):
                value[2] = False
        for key, value in hist.SampleParameters.items():
            if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
                value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        for hap in phase.data["Histograms"].values():
            hap["Scale"][1] = False
            hap["Size"][2] = [False for _ in hap["Size"][2]]
            hap["Size"][5] = [False for _ in hap["Size"][5]]
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
            hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
            hap["Pref.Ori."][2] = False
            hap["Extinction"][1] = False


def fractions(project: G2.G2Project) -> list[dict]:
    hist = project.histogram(0)
    values = []
    total = 0.0
    for phase in project.phases():
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        mass_scale = scale * float(phase.data["General"]["Mass"])
        values.append({"name": phase.name, "scale": scale, "mass_scale": mass_scale})
        total += mass_scale
    for value in values:
        value["weight_fraction"] = value["mass_scale"] / total if total > 0 else None
    return values


def test_one(base: Path, label: str, cif: Path, output_dir: Path) -> dict:
    output = output_dir / f"{label}.gpx"
    project = G2.G2Project(gpxfile=str(base), newgpx=str(output))
    clear_all_flags(project)
    hist = project.histogram(0)
    main_phase = project.phase(0)
    main_hap = main_phase.data["Histograms"][hist.name]
    incumbent_mass_scale = sum(
        incumbent.data["Histograms"][hist.name]["Scale"][0] * incumbent.data["General"]["Mass"]
        for incumbent in project.phases()
    )
    phase = project.add_phase(str(cif), phasename=label, histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [max(1e-4, 0.03 * incumbent_mass_scale / phase.data["General"]["Mass"]), True]
    for atom in phase.atoms():
        if atom.adp_flag == "I":
            atom.ADP = 0.01
        else:
            atom.ADP = [0.01, 0.01, 0.01, 0.0, 0.0, 0.0]
    hap["Size"][0] = main_hap["Size"][0]
    hap["Size"][1] = list(main_hap["Size"][1])
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = main_hap["Mustrain"][0]
    hap["Mustrain"][1] = list(main_hap["Mustrain"][1])
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Extinction"] = [0.0, False]
    for incumbent in project.phases()[:-1]:
        incumbent.data["Histograms"][hist.name]["Scale"][1] = True
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    scale_only = {
        "rwp": float(project.histogram(0).residuals["wR"]),
        "fractions": fractions(project),
        "cell": phase.get_cell(),
    }
    # Give the trial framework only its own lattice degrees of freedom. All
    # incumbent structures, profiles, and global nuisance terms remain fixed.
    phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 16)
    project.refine(makeBack=False)
    cell_refined = {
        "rwp": float(project.histogram(0).residuals["wR"]),
        "fractions": fractions(project),
        "cell": phase.get_cell(),
    }
    project.save()
    return {
        "label": label,
        "cif": str(cif),
        "project": str(output),
        "scale_only": scale_only,
        "cell_refined": cell_refined,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", type=Path, default=ROOT / "base_physical.gpx")
    parser.add_argument(
        "--set", choices=["ordinary", "prototype", "stoich", "all"], default="all"
    )
    parser.add_argument("--output", type=Path, default=ROOT / "common_state_trials")
    parser.add_argument(
        "--labels",
        nargs="*",
        help="Optional exact candidate labels; useful for fresh-process reruns",
    )
    args = parser.parse_args()
    args.output.mkdir(exist_ok=True)
    candidates = {}
    if args.set in ("ordinary", "all"):
        candidates.update(ORDINARY)
    if args.set in ("prototype", "all"):
        for path in sorted((ROOT / "trial_models").glob("abo4_*.cif")):
            if path.stem in {"abo4_c2c_4030823", "abo4_p3m1_1533737"}:
                continue  # substitution creates sub-angstrom split/overlap contacts
            candidates[path.stem] = path
    if args.set in ("stoich", "all"):
        for path in sorted((ROOT / "stoich_models").glob("*.cif")):
            candidates[path.stem] = path
    if args.labels:
        requested = set(args.labels)
        candidates = {label: path for label, path in candidates.items() if label in requested}
    reports = []
    for label, path in candidates.items():
        print(f"Testing {label}", flush=True)
        try:
            report = test_one(args.base.resolve(), label, path.resolve(), args.output.resolve())
        except Exception as exc:
            report = {"label": label, "cif": str(path), "status": "failed", "error": repr(exc)}
        reports.append(report)
        (args.output / "summary.json").write_text(json.dumps(reports, indent=2) + "\n")
        if "cell_refined" in report:
            print(
                f"  Rwp {report['scale_only']['rwp']:.3f} -> {report['cell_refined']['rwp']:.3f}; "
                f"trial fraction {report['cell_refined']['fractions'][-1]['weight_fraction']:.4f}",
                flush=True,
            )


if __name__ == "__main__":
    main()
