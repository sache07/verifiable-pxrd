#!/usr/bin/env python3
"""Test polarization and Suortti surface roughness in a fixed common state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import set_bound


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--rough-a", type=float, default=0.3)
    parser.add_argument("--rough-b", type=float, default=0.1)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    clear_all_flags(project)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        set_bound(project, ":0:Polariz.", 0.5, 1.0)
    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [float(args.rough_a), True]
        hist.SampleParameters["SurfRoughB"] = [float(args.rough_b), True]
        set_bound(project, ":0:SurfRoughA", 0.0, 0.6)
        set_bound(project, ":0:SurfRoughB", 0.0, 0.5)
    project.set_Controls("cycles", 15)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {
        "rwp": float(hist.residuals["wR"]),
        "fractions": fractions(project),
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "surface_roughness_A": hist.SampleParameters["SurfRoughA"][0],
        "surface_roughness_B": hist.SampleParameters["SurfRoughB"][0],
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
