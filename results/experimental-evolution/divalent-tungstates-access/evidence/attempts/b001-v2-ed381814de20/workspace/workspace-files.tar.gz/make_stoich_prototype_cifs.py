#!/usr/bin/env python3
"""Build shortlisted Mn2WO5 analogues for common-state residual tests."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)

# Keep the leading independent Pnnm coordinate models as well as every
# distinct plausible symmetry/framework in the residual shortlist.  Scale
# factors come from the coarse full-range residual registration and are only
# starting values; GSAS-II tests each cell in the same incumbent project.
MODELS = {
    "mn2wo5_pnnm_cuas_9015082": ("9015082", {"Cu": "Mn", "As": "W"}, 1.018181818181818),
    "mn2wo5_p21c_cuas_9011171": ("9011171", {"Cu": "Mn", "As": "W"}, 1.018181818181818),
    "mn2wo5_pnnm_cup_1528172": ("1528172", {"Cu": "Mn", "P": "W"}, 1.0303030303030303),
    "mn2wo5_pnnm_coas_1524664": ("1524664", {"Co": "Mn", "As": "W"}, 1.0121212121212122),
    "mn2wo5_pnnm_mnas_9000178": ("9000178", {"As": "W"}, 0.9878787878787878),
    "mn2wo5_pnnm_znas_9015147": ("9015147", {"Zn": "Mn", "As": "W"}, 1.018181818181818),
    "mn2wo5_p21_lis_1010246": ("1010246", {"Li": "Mn", "S": "W"}, 0.8242424242424243),
    "mn2wo5_p321_beb_9009936": ("9009936", {"Be": "Mn", "B": "W"}, 0.8),
    "mn2wo5_p1bar_laru_2015098": ("2015098", {"La": "Mn", "Ru": "W"}, 0.8666666666666667),
    "mn2wo5_cmc21_bige_1526265": ("1526265", {"Bi": "Mn", "Ge": "W"}, 0.8060606060606061),
    # Mn2WO6: direct Y2WO6 frameworks plus distinct two-substitution models.
    "mn2wo6_p212121_yw_1541070": ("1541070", {"Y": "Mn"}, 0.9393939393939394),
    "mn2wo6_p212121_yw_super_2106838": ("2106838", {"Y": "Mn"}, 0.9575757575757575),
    "mn2wo6_p21c_cute_9004359": ("9004359", {"Cu": "Mn", "Te": "W"}, 0.9636363636363636),
    "mn2wo6_p21m_cun_1536129": ("1536129", {"Cu": "Mn", "N": "W"}, 1.018181818181818),
    # Mn3WO6: direct Mn3TeO6 and Ca3WO6 analogues, plus independent
    # corundum/cubic/monoclinic/orthorhombic relatives.
    "mn3wo6_r3bar_mnte_2211528": ("2211528", {"Te": "W"}, 0.9818181818181818),
    "mn3wo6_ia3_cute_1557963": ("1557963", {"Cu": "Mn", "Te": "W"}, 0.9090909090909091),
    "mn3wo6_c2c_cote_2015468": ("2015468", {"Co": "Mn", "Te": "W"}, 0.9818181818181818),
    "mn3wo6_p21c_caw_1563081": ("1563081", {"Ca": "Mn"}, 0.8787878787878788),
    "mn3wo6_r3_nite_2211031": ("2211031", {"Ni": "Mn", "Te": "W"}, 1.1151515151515152),
    "mn3wo6_pnma_feb_2310094": ("2310094", {"Fe": "Mn", "B": "W"}, 0.9757575757575757),
    # Mn3W2O8: one-substitution arsenate/tantalate relatives and distinct
    # two-substitution rhombohedral and tetragonal frameworks.
    "mn3w2o8_r3m_cap_9005865": ("9005865", {"Ca": "Mn", "P": "W"}, 0.9515151515151515),
    "mn3w2o8_p21c_mnas_1560682": ("1560682", {"As": "W"}, 1.0242424242424242),
    "mn3w2o8_i42d_mgas_2106370": ("2106370", {"Mg": "Mn", "As": "W"}, 0.9030303030303031),
    "mn3w2o8_i41a_mnta_4343261": ("4343261", {"Ta": "W"}, 0.8727272727272728),
}


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def closest_contacts(structure: Structure) -> tuple[float, float, float]:
    matrix = structure.distance_matrix.copy()
    matrix[matrix == 0] = float("inf")
    all_min = float(matrix.min())
    oo_min = float("inf")
    wo_min = float("inf")
    for i, site_i in enumerate(structure):
        symbols_i = {element.symbol for element in site_i.species.elements}
        for j in range(i + 1, len(structure)):
            symbols_j = {element.symbol for element in structure[j].species.elements}
            distance = float(matrix[i, j])
            if symbols_i == {"O"} and symbols_j == {"O"}:
                oo_min = min(oo_min, distance)
            if ("W" in symbols_i and "O" in symbols_j) or (
                "O" in symbols_i and "W" in symbols_j
            ):
                wo_min = min(wo_min, distance)
    return all_min, oo_min, wo_min


def main() -> None:
    output = ROOT / "stoich_models"
    output.mkdir(exist_ok=True)
    provenance = []
    for label, (cod_id, mapping, scale) in MODELS.items():
        structure = Structure.from_file(cod_path(cod_id))
        try:
            structure.remove_oxidation_states()
        except Exception:
            pass
        structure.replace_species(mapping)
        structure.scale_lattice(structure.volume * scale**3)
        # The source Cu2AsO5 CIF uses a nonstandard unique-a P21/n setting that
        # GSAS-II cannot import.  Convert only that model to the conventional
        # unique-b P21/c setting without changing its framework.
        if "p21c" in label or "p21m" in label:
            structure = SpacegroupAnalyzer(structure, symprec=1e-3).get_conventional_standard_structure()
        path = output / f"{label}.cif"
        CifWriter(
            structure,
            symprec=1e-3,
            refine_struct=False,
            significant_figures=10,
        ).write_file(path)
        contact, oo_contact, wo_contact = closest_contacts(structure)
        provenance.append(
            {
                "label": label,
                "path": str(path.relative_to(ROOT)),
                "parent_cod_id": cod_id,
                "parent_path": str(cod_path(cod_id)),
                "substitutions": mapping,
                "isotropic_starting_cell_scale": scale,
                "composition": structure.composition.reduced_formula,
                "space_group": structure.get_space_group_info(),
                "cell": [*structure.lattice.abc, *structure.lattice.angles],
                "sites": len(structure),
                "minimum_contact_A": contact,
                "minimum_O_O_A": oo_contact,
                "minimum_W_O_A": wo_contact,
            }
        )
    (output / "provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")


if __name__ == "__main__":
    main()
