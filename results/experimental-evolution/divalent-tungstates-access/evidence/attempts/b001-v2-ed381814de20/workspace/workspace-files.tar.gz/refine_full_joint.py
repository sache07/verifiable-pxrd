#!/usr/bin/env python3
"""Joint refinement of all accepted physical terms before final replay."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from common_state_trials import clear_all_flags, fractions
from refine_multiphase import activate_common, activate_profiles, set_bound


def serial_adp(value):
    if isinstance(value, (list, tuple)):
        return [float(item) for item in value]
    return float(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=25)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    clear_all_flags(project)
    hist = project.histogram(0)
    activate_common(project)
    activate_profiles(project, size=True, strain=True)
    hist.set_refinements(
        {"Instrument Parameters": ["W", "X", "SH/L", "Polariz."]}
    )
    candidate_hap = project.phase(2).data["Histograms"][hist.name]
    candidate_hap["Pref.Ori."][0] = "MD"
    candidate_hap["Pref.Ori."][2] = True
    candidate_hap["Pref.Ori."][3] = [0, 1, 0]
    # WO3 Uiso is fixed at its independently stable value; in a fully joint
    # run it is otherwise driven through the upper bound by size/scale
    # correlation. The transferred phase remains well determined and interior.
    for phase_index in (2,):
        for atom in project.phase(phase_index).atoms():
            atom.refinement_flags = "U"

    set_bound(project, "2:0:MD", 0.7, 1.4)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for phase_index, phase in enumerate(project.phases()):
        set_bound(project, f"{phase_index}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase_index}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase_index}:0:Scale", 1e-12, 1e6)
        if phase_index in (2,):
            for atom_index, _atom in enumerate(phase.atoms()):
                set_bound(project, f"{phase_index}::AUiso:{atom_index}", 0.003, 0.02)

    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-7
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {
        "rwp": float(hist.residuals["wR"]),
        "fractions": fractions(project),
        "texture": {
            "phase": project.phase(2).name,
            "axis": candidate_hap["Pref.Ori."][3],
            "coefficient": float(candidate_hap["Pref.Ori."][1]),
        },
        "instrument": {
            key: hist.InstrumentParameters[key][1]
            for key in ("W", "X", "SH/L", "Polariz.", "Zero")
        },
        "sample": {
            key: hist.SampleParameters[key][0]
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"][1][0],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
                "adps": [serial_adp(atom.ADP) for atom in phase.atoms()],
            }
            for phase in project.phases()
        ],
    }
    print(json.dumps(record, indent=2))
    args.output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")


if __name__ == "__main__":
    main()
