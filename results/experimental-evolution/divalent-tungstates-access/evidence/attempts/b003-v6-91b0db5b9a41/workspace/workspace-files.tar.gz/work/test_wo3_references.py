#!/usr/bin/env python3
"""Compare plausible exact-composition WO3 references in the full model."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from refine_model import cod_path, mass_fractions
from refine_profile import clear_flags, enable_scale_background


CANDIDATES = ("1528915", "2311041", "2106293", "1010618", "2107312")
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def remove_wo3(project: G2.G2Project):
    hist = project.histogram(0)
    phase = project.phase("WO3")
    old_hap = copy.deepcopy(phase.data["Histograms"][hist.name])
    del project.data["Phases"]["WO3"]
    for names in project.names:
        if names and names[0] == "Phases" and "WO3" in names:
            names.remove("WO3")
    hist.data.get("Reflection Lists", {}).pop("WO3", None)
    project.update_ids()
    return old_hap


def normalize_and_constrain_uiso(project: G2.G2Project, new_wo3=True):
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        pid = phase.data["pId"]
        cia = phase.data["General"]["AtomPtrs"][3]
        variables = []
        # Existing accepted phases retain their refined Uiso. The replacement
        # starts from the registered-model normalization.
        value = 0.005 if phase.name == "WO3" and new_wo3 else float(phase.atoms()[0].data[cia + 1])
        for index, atom in enumerate(phase.atoms()):
            atom.data[cia] = "I"
            atom.data[cia + 1] = value
            atom.data[cia + 2 : cia + 8] = [0.0] * 6
            atom.refinement_flags = "U"
            variable = f"{pid}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        project.save()
        if len(variables) > 1:
            project.add_EquivConstr(tuple(variables))


def set_cell_bounds(project, phase):
    cell = phase.get_cell()
    reciprocal = G2lat.cell2A(
        [
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ]
    )
    pid = phase.data["pId"]
    for index, value in enumerate(reciprocal):
        value = float(value)
        span = max(0.01 * abs(value), 0.0003)
        project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--candidates", nargs="+", default=list(CANDIDATES))
    parser.add_argument(
        "--axes", nargs="+", default=["001", "100", "010", "110", "111"],
        choices=("001", "100", "010", "110", "111"),
    )
    parser.add_argument("--max-passes", type=int, default=3)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    source = Path(args.input).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    results = []

    selected_axes = [[int(v) for v in tag] for tag in args.axes]
    for cod_id in args.candidates:
        for axis in selected_axes:
            tag = "".join(str(v) for v in axis)
            destination = outdir / f"wo3_{cod_id}_{tag}.gpx"
            project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
            project.save()
            old_hap = remove_wo3(project)
            hist = project.histogram(0)
            phase = project.add_phase(
                str(cod_path(cod_id)), phasename="WO3", histograms=[hist], fmthint="CIF"
            )
            hap = phase.data["Histograms"][hist.name]
            for key in ("Scale", "Size", "Mustrain", "Extinction"):
                hap[key] = copy.deepcopy(old_hap[key])
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            project.save()

            # Preserve accepted terms for the other phases while activating
            # the candidate's own cell/profile/texture and shared Uiso.
            accepted_textures = {
                ph.name: list(ph.data["Histograms"][hist.name]["Pref.Ori."][:4])
                for ph in project.phases() if ph.name != "WO3"
            }
            clear_flags(project)
            enable_scale_background(project)
            hist.InstrumentParameters["Polariz."][2] = True
            project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
            project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
            for ph in project.phases():
                phap = ph.data["Histograms"][hist.name]
                if ph.name in accepted_textures:
                    phap["Pref.Ori."][:4] = accepted_textures[ph.name]
                if phap["Pref.Ori."][2]:
                    pid = ph.data["pId"]
                    project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
                    project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][2] = True
            hap["Size"][0] = "isotropic"
            hap["Size"][2][0] = True
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][0] = True
            phase.set_refinements({"Cell": True})
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
            set_cell_bounds(project, phase)
            normalize_and_constrain_uiso(project)
            project.save()

            rows = []
            for pass_index in range(args.max_passes):
                project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
                project.set_Controls("cycles", 12)
                project.save()
                project.refine(makeBack=False)
                project.save()
                cov = project.data.get("Covariance", {}).get("data", {})
                rvals = cov.get("Rvals", {})
                rows.append(
                    {
                        "pass": pass_index + 1,
                        "Rwp_percent": float(hist.get_wR()),
                        "converged": bool(rvals.get("converged", False)),
                        "max_shift_esd": rvals.get("Max shft/sig"),
                        "frozen": list(project.get_Frozen()),
                    }
                )
                maximum = rvals.get("Max shft/sig")
                if rvals.get("converged") and maximum is not None and maximum <= 1 and not rows[-1]["frozen"]:
                    break
            cia = phase.data["General"]["AtomPtrs"][3]
            row = {
                "cod_id": cod_id,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "axis": list(axis),
                "Rwp_percent": rows[-1]["Rwp_percent"],
                "ratio": float(hap["Pref.Ori."][1]),
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "Uiso_A2": float(phase.atoms()[0].data[cia + 1]),
                "cell": phase.get_cell(),
                "fractions": mass_fractions(project),
                "passes": rows,
                "path": str(destination),
            }
            print(json.dumps(row), flush=True)
            results.append(row)
    (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
