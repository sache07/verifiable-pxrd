#!/usr/bin/env python3
"""Ordinary bounded coordinate refinement before the staged final polish."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_model import mass_fractions
from refine_profile import clear_flags, enable_scale_background


COORDINATE_WINDOW_A = 0.10


def prepare(project: G2.G2Project):
    hist = project.histogram(0)
    textures = {
        phase.name: list(phase.data["Histograms"][hist.name]["Pref.Ori."][:4])
        for phase in project.phases()
    }
    # Remove exploratory equivalence objects and retain a single fixed scalar
    # Uiso value per phase. This also repairs a bound-hit dependent value in the
    # Mn3WO6 trial branch.
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        cia = phase.data["General"]["AtomPtrs"][3]
        value = min(0.020, max(0.003, float(phase.atoms()[0].data[cia + 1])))
        for atom in phase.atoms():
            atom.data[cia] = "I"
            atom.data[cia + 1] = value
            atom.data[cia + 2 : cia + 8] = [0.0] * 6
            atom.refinement_flags = " "
    clear_flags(project)
    enable_scale_background(project)
    hist.InstrumentParameters["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    for phase in project.phases():
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[:4] = textures[phase.name]
        if pref[2]:
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        pid = phase.data["pId"]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half_width = COORDINATE_WINDOW_A / max(float(length), 1e-6)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half_width, variable=variable)
                project.set_Controls("parmMax", float(value) + half_width, variable=variable)
    project.save()


def set_coordinate_atoms(project, mode):
    for phase in project.phases():
        for atom in phase.atoms():
            if mode == "heavy":
                atom.refinement_flags = "X" if atom.element != "O" else " "
            elif mode == "oxygen":
                atom.refinement_flags = "X" if atom.element == "O" else " "
            elif mode == "all":
                atom.refinement_flags = "X"
            else:
                atom.refinement_flags = " "


def run(project, stage, max_passes=3):
    hist = project.histogram(0)
    rows = []
    for pass_index in range(max_passes):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {})
        rvals = cov.get("Rvals", {})
        row = {
            "stage": stage,
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "polarization": float(hist.InstrumentParameters["Polariz."][1]),
            "fractions": mass_fractions(project),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
        maximum = rvals.get("Max shft/sig")
        if rvals.get("converged") and maximum is not None and maximum <= 1.0 and not row["frozen"]:
            break
    return rows


def geometry(project):
    result = {}
    for phase in project.phases():
        result[phase.name] = {
            "short_distances": [
                [str(a), str(b), float(d)]
                for a, b, d in phase.ShortDistances(useAll=False)
            ]
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.input).resolve()), newgpx=str(output)
    )
    project.save()
    prepare(project)
    records = []
    for mode in ("heavy", "oxygen", "all"):
        set_coordinate_atoms(project, mode)
        records += run(project, mode, 4 if mode == "all" else 3)
    set_coordinate_atoms(project, "none")
    project.save()
    summary = {"stages": records, "geometry": geometry(project)}
    output.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary["geometry"]), flush=True)


if __name__ == "__main__":
    main()
