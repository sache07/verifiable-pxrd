#!/usr/bin/env python3
"""Export fit.csv and numerical summary from the verified final.gpx replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


def main() -> None:
    replay = Path("work/replay_final/prediction.npz")
    with np.load(replay) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
    public = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("verified replay grid/observations differ from pattern.csv")
    difference = observed - calculated
    np.savetxt(
        "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.1f", "%.10f", "%.10f"],
    )
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    n_parameters = 25
    stats = {
        "Rwp_percent": float(100 * np.sqrt(chi_square / denominator)),
        "Rp_percent": float(100 * np.sum(np.abs(difference)) / np.sum(observed)),
        "chi_square": chi_square,
        "goodness_of_fit": float(np.sqrt(chi_square / (len(x) - n_parameters))),
        "Rexp_percent": float(
            100
            * np.sqrt(chi_square / denominator)
            / np.sqrt(chi_square / (len(x) - n_parameters))
        ),
        "n_observations": int(len(x)),
        "n_refined_parameters": n_parameters,
        "weighting": "1/max(observed_counts,1)",
        "source": "fresh native GSAS-II replay of final.gpx; no parameters optimized",
    }
    Path("work/final_fit_statistics.json").write_text(
        json.dumps(stats, indent=2) + "\n"
    )
    print(json.dumps(stats))


if __name__ == "__main__":
    main()
