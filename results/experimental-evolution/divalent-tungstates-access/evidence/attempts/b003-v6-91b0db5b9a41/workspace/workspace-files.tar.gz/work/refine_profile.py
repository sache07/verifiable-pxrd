#!/usr/bin/env python3
"""Controlled profile refinement from a physical three-phase checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from refine_model import mass_fractions, run_stage, snapshot


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_scale_background(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    hist.SampleParameters["Scale"][1] = False
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def set_bounds(project: G2.G2Project) -> None:
    # Reset stale limits from exploratory branches.
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    for variable, low, high in (
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    hist = project.histogram(0)
    for phase in project.phases():
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        # The generator's specimen controls are known laboratory support, not
        # the hidden realization.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = min(1.5, max(0.04, float(hap["Size"][1][0])))
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = min(8000.0, max(0.0, float(hap["Mustrain"][1][0])))
        for variable, low, high in (
            (f"{pid}:0:Scale", 0.0, 1000.0),
            (f"{pid}:0:Size;i", 0.04, 1.5),
            (f"{pid}:0:Mustrain;i", 0.0, 8000.0),
        ):
            project.set_Controls("parmMin", low, variable=variable)
            project.set_Controls("parmMax", high, variable=variable)


def enable_instrument(hist, names) -> None:
    for name in names:
        hist.InstrumentParameters[name][2] = True


def enable_profiles(project: G2.G2Project, size=True, mustrain=True) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = bool(size)
        hap["Mustrain"][2][0] = bool(mustrain)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    working = outdir / "working.gpx"
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()), newgpx=str(working))
    project.save()
    set_bounds(project)
    hist = project.histogram(0)
    records = [snapshot(project, "source")]
    print(json.dumps(records[-1], default=str), flush=True)

    # Common optics with calibration and all specimen terms held fixed.
    clear_flags(project)
    enable_scale_background(project)
    enable_instrument(hist, ["W", "X", "SH/L"])
    records.append(run_stage(project, outdir, "01_common_WXSHL", 12))

    clear_flags(project)
    enable_scale_background(project)
    enable_instrument(hist, ["U", "W", "X", "SH/L"])
    records.append(run_stage(project, outdir, "02_common_UWXSHL", 12))

    # Phase-specific specimen widths against the now-fixed common optics.
    clear_flags(project)
    enable_scale_background(project)
    enable_profiles(project, size=True, mustrain=False)
    records.append(run_stage(project, outdir, "03_isotropic_sizes", 12))

    clear_flags(project)
    enable_scale_background(project)
    enable_profiles(project, size=True, mustrain=True)
    records.append(run_stage(project, outdir, "04_isotropic_size_strain", 15))

    # Joint width settle, still without allowing peak positions to wander.
    clear_flags(project)
    enable_scale_background(project)
    enable_instrument(hist, ["U", "W", "X", "SH/L"])
    enable_profiles(project, size=True, mustrain=True)
    records.append(run_stage(project, outdir, "05_width_settle", 15))

    # Reopen position terms only after widths are established.
    clear_flags(project)
    enable_scale_background(project)
    hist.InstrumentParameters["Zero"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    records.append(run_stage(project, outdir, "06_position_settle", 12))

    # One bounded ordinary joint settle.
    clear_flags(project)
    enable_scale_background(project)
    enable_instrument(hist, ["U", "W", "X", "SH/L", "Zero"])
    hist.SampleParameters["Shift"][1] = True
    enable_profiles(project, size=True, mustrain=True)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    records.append(run_stage(project, outdir, "07_joint_settle", 15))

    clear_flags(project)
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    (outdir / "stages.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
    print(json.dumps({"final_fractions": mass_fractions(project)}, default=str))


if __name__ == "__main__":
    main()
