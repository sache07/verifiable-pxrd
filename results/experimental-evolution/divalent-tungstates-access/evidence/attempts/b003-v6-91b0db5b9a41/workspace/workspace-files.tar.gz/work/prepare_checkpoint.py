#!/usr/bin/env python3
"""Prepare the complete physical checkpoint used by staged_polish.py."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_model import mass_fractions
from refine_profile import clear_flags, enable_scale_background


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.input).resolve()), newgpx=str(output)
    )
    project.save()
    hist = project.histogram(0)
    textures = {
        phase.name: list(phase.data["Histograms"][hist.name]["Pref.Ori."][:4])
        for phase in project.phases()
    }

    # Exploratory equal-Uiso constraints can leave a bound-hit dependent value
    # infinitesimally outside the intended range. Serialize the accepted scalar
    # value explicitly on every site and remove those constraints.
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        cia = phase.data["General"]["AtomPtrs"][3]
        value = min(0.020, max(0.003, float(phase.atoms()[0].data[cia + 1])))
        for atom in phase.atoms():
            atom.data[cia] = "I"
            atom.data[cia + 1] = value
            atom.data[cia + 2 : cia + 8] = [0.0] * 6
            atom.refinement_flags = " "

    clear_flags(project)
    enable_scale_background(project)
    hist.InstrumentParameters["Polariz."][1] = min(
        1.0, max(0.5, float(hist.InstrumentParameters["Polariz."][1]))
    )
    hist.InstrumentParameters["Polariz."][2] = False
    for phase in project.phases():
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[:4] = textures[phase.name]
        if pref[2]:
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")

    records = []
    for pass_index in range(3):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "fractions": mass_fractions(project),
        }
        records.append(row)
        print(json.dumps(row), flush=True)
        maximum = rvals.get("Max shft/sig")
        if rvals.get("converged") and maximum is not None and maximum <= 1 and not row["frozen"]:
            break

    clear_flags(project)
    project.save()
    ycalc = np.asarray(hist.getdata("Ycalc"), float)
    background = np.asarray(hist.getdata("Background"), float)
    geometry = {
        phase.name: [
            [str(left), str(right), float(distance)]
            for left, right, distance in phase.ShortDistances(useAll=False)
        ]
        for phase in project.phases()
    }
    summary = {
        "stages": records,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": mass_fractions(project),
        "minimum_ycalc": float(np.min(ycalc)),
        "minimum_background": float(np.min(background)),
        "short_distances": geometry,
    }
    output.with_suffix(".checkpoint.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
