#!/usr/bin/env python3
"""Refine one physically shared isotropic Uiso per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_model import mass_fractions
from test_nuisance import prepare


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.input).resolve()), newgpx=str(output)
    )
    project.save()
    prepare(project)
    # This model adds only these phase constraints.
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        pid = phase.data["pId"]
        cia = phase.data["General"]["AtomPtrs"][3]
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.data[cia] = "I"
            atom.data[cia + 1] = 0.005
            atom.data[cia + 2 : cia + 8] = [0.0] * 6
            atom.refinement_flags = "U"
            variable = f"{pid}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        project.save()
        if len(variables) > 1:
            project.add_EquivConstr(tuple(variables))
    project.save()

    hist = project.histogram(0)
    rows = []
    for pass_index in range(4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {})
        rvals = cov.get("Rvals", {})
        row = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "fractions": mass_fractions(project),
            "Uiso_A2": {
                phase.name: float(phase.atoms()[0].data[phase.data["General"]["AtomPtrs"][3] + 1])
                for phase in project.phases()
            },
        }
        print(json.dumps(row), flush=True)
        rows.append(row)
        maximum = rvals.get("Max shft/sig")
        if rvals.get("converged") and maximum is not None and maximum <= 1 and not row["frozen"]:
            break
    output.with_suffix(".json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
