#!/usr/bin/env python3
"""Screen the laboratory's allowed March-Dollase axes one phase at a time."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_model import mass_fractions
from refine_profile import clear_flags, enable_scale_background


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--phase-index", type=int, choices=(0, 1, 2))
    parser.add_argument("--preserve-textures", action="store_true")
    args = parser.parse_args()
    source = Path(args.input).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    results = []

    phase_indices = range(3) if args.phase_index is None else [args.phase_index]
    for phase_index in phase_indices:
        for axis in AXES:
            axis_name = "".join(str(v) for v in axis)
            destination = outdir / f"phase{phase_index}_{axis_name}.gpx"
            project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
            project.save()
            saved_textures = {
                i: list(ph.data["Histograms"][project.histogram(0).name]["Pref.Ori."][:4])
                for i, ph in enumerate(project.phases())
            }
            clear_flags(project)
            enable_scale_background(project)
            if args.preserve_textures:
                for i, ph in enumerate(project.phases()):
                    if i == phase_index or not saved_textures[i][2]:
                        continue
                    pref_existing = ph.data["Histograms"][project.histogram(0).name]["Pref.Ori."]
                    pref_existing[:4] = saved_textures[i]
            phase = project.phases()[phase_index]
            hist = project.histogram(0)
            pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
            pref[0] = "MD"
            pref[1] = 1.0
            pref[2] = True
            pref[3] = list(axis)
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            project.set_Controls("cycles", 10)
            project.save()
            project.refine(makeBack=False)
            project.save()
            cov = project.data.get("Covariance", {}).get("data", {})
            rvals = cov.get("Rvals", {})
            row = {
                "phase": phase.name,
                "phase_index": phase_index,
                "axis": list(axis),
                "ratio": float(pref[1]),
                "Rwp_percent": float(hist.get_wR()),
                "converged": bool(rvals.get("converged", False)),
                "max_shift_esd": rvals.get("Max shft/sig"),
                "frozen": list(project.get_Frozen()),
                "fractions": mass_fractions(project),
                "path": str(destination),
            }
            print(json.dumps(row), flush=True)
            results.append(row)
    (outdir / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
