#!/usr/bin/env python3
"""Build and stage a GSAS-II refinement for the Mn-W-O specimen.

This is an analysis helper, not a generic phase-search program.  It keeps a
checkpoint after every refinement stage so that failed late stages cannot
destroy the last physical model.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_instrument(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu K-alpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.25;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        )
    total = sum(weighted.values())
    if total <= 0:
        return {key: 0.0 for key in weighted}
    return {key: val / total for key, val in weighted.items()}


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    return {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "Nvars": len(cov.get("varyList", [])),
        "fractions": mass_fractions(project),
        "instrument": {
            key: inst[key][1]
            for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
            if key in inst
        },
        "sample": {
            key: sample[key][0] if isinstance(sample.get(key), list) else sample.get(key)
            for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
            if key in sample
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        },
        "sizes": {
            phase.name: phase.data["Histograms"][hist.name]["Size"][:3]
            for phase in project.phases()
        },
        "mustrains": {
            phase.name: phase.data["Histograms"][hist.name]["Mustrain"][:3]
            for phase in project.phases()
        },
        "frozen": list(project.get_Frozen()),
    }


def run_stage(project: G2.G2Project, outdir: Path, stage: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = snapshot(project, stage)
    checkpoint = outdir / f"{stage}.gpx"
    shutil.copy2(project.filename, checkpoint)
    print(json.dumps(record, default=str), flush=True)
    return record


def set_background_from_lower_envelope(hist) -> None:
    x = np.asarray(hist.getdata("X"), float)
    y = np.asarray(hist.getdata("Yobs"), float)
    step = float(np.median(np.diff(x)))
    # A 2.2-degree moving lower quartile rejects the narrow Bragg peaks while
    # retaining the broad laboratory background shape.
    width = max(5, int(round(2.2 / step)))
    if width % 2 == 0:
        width += 1
    envelope = percentile_filter(y, percentile=18, size=width, mode="nearest")
    grid = np.linspace(x[0], x[-1], 31)
    points = [(float(xx), float(np.interp(xx, x, envelope))) for xx in grid]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [float(np.median(envelope))] + [0.0] * 11,
                "FixedPoints": points,
                "fit fixed points": True,
                "refine": False,
            }
        }
    )


def clear_all_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Background": True,
            "Instrument Parameters": [
                key
                for key, val in hist.InstrumentParameters.items()
                if isinstance(val, list) and len(val) > 2
            ],
            "Sample Parameters": [
                key
                for key, val in hist.SampleParameters.items()
                if isinstance(val, list) and len(val) > 1 and isinstance(val[1], bool)
            ],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
            },
            [hist],
        )


def build(args: argparse.Namespace) -> tuple[G2.G2Project, Path]:
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    inst = outdir / "instrument.instprm"
    write_instrument(inst)
    project_path = outdir / "working.gpx"
    project = G2.G2Project(newgpx=str(project_path))
    hist = project.add_powder_histogram(
        str(Path(args.pattern).resolve()), str(inst), fmthint="comma"
    )
    phase_specs = [
        ("MnWO4", args.mnwo4),
        ("Mn3WO6", args.mn3wo6),
        ("WO3", args.wo3),
    ]
    for name, cod_id in phase_specs:
        project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    set_background_from_lower_envelope(hist)

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    controls = project.data["Controls"]["data"]
    controls["deriv type"] = "analytic Hessian"
    controls["min dM/M"] = 1.0e-5
    controls["SVDtol"] = 1.0e-6
    project.save()
    # Keep all fitted instrumental/specimen quantities inside the frozen lab's
    # physically available ranges. Blank phase/histogram fields are GSAS-II's
    # standard global histogram variable names.
    for variable, low, high in (
        (":0:Zero", -0.35, 0.35),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.02, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{pid}:0:Mustrain;i")
    project.save()
    return project, outdir


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    parser.add_argument("--outdir", required=True)
    parser.add_argument("--mnwo4", default="1520200")
    parser.add_argument("--mn3wo6", default="2002703")
    parser.add_argument("--wo3", default="1528915")
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project, outdir = build(args)
    hist = project.histogram(0)
    records = []

    # Forward calculation to populate reflection lists and the starting curve.
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save()
    records.append(snapshot(project, "initial"))
    print(json.dumps(records[-1], default=str), flush=True)

    # Establish positive scales against a fixed smooth background.
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])
    records.append(run_stage(project, outdir, "01_scale_background", 8))

    # Locate peaks globally before allowing the phase metrics to move.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    records.append(run_stage(project, outdir, "02_zero", 8))

    # Adapt each reference metric to the specimen.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    records.append(run_stage(project, outdir, "03_cells", 10))

    # Separate constant instrument zero from specimen-height displacement.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    records.append(run_stage(project, outdir, "04_zero_shift_cells", 10))

    # Establish the common optical profile before adding specimen broadening.
    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    records.append(run_stage(project, outdir, "05_profile_WXSHL", 10))
    hist.set_refinements({"Instrument Parameters": ["U"]})
    records.append(run_stage(project, outdir, "06_profile_U", 10))

    # Isotropic specimen contributions are the ordinary first model.
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
            [hist],
        )
    records.append(run_stage(project, outdir, "07_sizes", 10))
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    records.append(run_stage(project, outdir, "08_mustrain", 10))

    # Final settle for this inventory; atom coordinates and optional texture
    # are deliberately left for evidence-led branches after residual mapping.
    records.append(run_stage(project, outdir, "09_settle", 12))
    clear_all_flags(project)
    project.save()
    shutil.copy2(project.filename, outdir / "checkpoint.gpx")
    (outdir / "stages.json").write_text(json.dumps(records, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
