#!/usr/bin/env python3
"""Test bounded polarization and Suortti roughness on the accepted inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_model import mass_fractions
from refine_profile import clear_flags, enable_scale_background


def prepare(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    active = {}
    for phase in project.phases():
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        active[phase.name] = list(pref[:4])
    clear_flags(project)
    enable_scale_background(project)
    for phase in project.phases():
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[:4] = active[phase.name]
        if pref[2]:
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")


def refine(project, stage, max_passes=3):
    hist = project.histogram(0)
    rows = []
    for pass_index in range(max_passes):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {})
        rvals = cov.get("Rvals", {})
        row = {
            "stage": stage,
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "polarization": float(hist.InstrumentParameters["Polariz."][1]),
            "roughness_A": float(hist.SampleParameters["SurfRoughA"][0]),
            "roughness_B": float(hist.SampleParameters["SurfRoughB"][0]),
            "fractions": mass_fractions(project),
        }
        print(json.dumps(row), flush=True)
        rows.append(row)
        maximum = rvals.get("Max shft/sig")
        if rvals.get("converged") and maximum is not None and maximum <= 1 and not row["frozen"]:
            break
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("--outdir", required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    source = Path(args.input).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    all_rows = []

    baseline_path = outdir / "baseline.gpx"
    baseline = G2.G2Project(gpxfile=str(source), newgpx=str(baseline_path))
    baseline.save()
    prepare(baseline)
    all_rows += refine(baseline, "baseline", 2)

    pol_path = outdir / "polarization.gpx"
    pol = G2.G2Project(gpxfile=str(baseline_path), newgpx=str(pol_path))
    pol.save()
    prepare(pol)
    hist = pol.histogram(0)
    hist.InstrumentParameters["Polariz."][2] = True
    pol.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    pol.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    all_rows += refine(pol, "polarization", 3)

    rough_path = outdir / "polarization_roughness.gpx"
    rough = G2.G2Project(gpxfile=str(pol_path), newgpx=str(rough_path))
    rough.save()
    prepare(rough)
    hist = rough.histogram(0)
    hist.InstrumentParameters["Polariz."][2] = True
    hist.SampleParameters["SurfRoughA"] = [0.30, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    rough.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    rough.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    rough.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    rough.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    all_rows += refine(rough, "polarization_roughness", 4)

    (outdir / "results.json").write_text(json.dumps(all_rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
