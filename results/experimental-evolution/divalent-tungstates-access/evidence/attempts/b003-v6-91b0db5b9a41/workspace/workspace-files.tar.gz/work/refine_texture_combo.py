#!/usr/bin/env python3
"""Apply the two texture axes supported by the residual screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_model import mass_fractions
from refine_profile import clear_flags, enable_scale_background


TEXTURES = {
    "MnWO4": [1, 1, 1],
    "Mn3WO6": [1, 1, 0],
    "WO3": [0, 1, 0],
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile=str(Path(args.input).resolve()), newgpx=str(output)
    )
    project.save()
    clear_flags(project)
    enable_scale_background(project)
    hist = project.histogram(0)
    for phase in project.phases():
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        if phase.name in TEXTURES:
            pref[0] = "MD"
            pref[1] = min(1.4, max(0.7, float(pref[1])))
            pref[2] = True
            pref[3] = TEXTURES[phase.name]
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        else:
            pref[1] = 1.0
            pref[2] = False
    records = []
    for pass_index in range(4):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 12)
        project.save()
        project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {})
        rvals = cov.get("Rvals", {})
        row = {
            "pass": pass_index + 1,
            "Rwp_percent": float(hist.get_wR()),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "frozen": list(project.get_Frozen()),
            "fractions": mass_fractions(project),
            "textures": {
                phase.name: phase.data["Histograms"][hist.name]["Pref.Ori."][:4]
                for phase in project.phases()
            },
        }
        records.append(row)
        print(json.dumps(row), flush=True)
        maximum = rvals.get("Max shft/sig")
        if rvals.get("converged") and maximum is not None and maximum <= 1.0 and not row["frozen"]:
            break
    output.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
