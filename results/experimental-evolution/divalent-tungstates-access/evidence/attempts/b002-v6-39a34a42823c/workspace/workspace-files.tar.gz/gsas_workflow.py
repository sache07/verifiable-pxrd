#!/usr/bin/env python3
"""Small, replayable GSAS-II workflow helpers for this specimen."""

from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path
import re
import shutil
from types import SimpleNamespace

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cod_cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_support_files(outdir: Path) -> tuple[Path, Path]:
    outdir.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    xye = outdir / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y)), fmt="%.8f %.8f")
    inst = outdir / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def rwp_from_arrays(hist) -> float:
    x, y, w, yc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    return float(100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y**2)))


def mass_fractions(project) -> dict[str, float]:
    hist = project.histograms()[0]
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def snapshot(project, label: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "label": label,
        "rwp_percent_recomputed": rwp_from_arrays(hist),
        "residuals": copy.deepcopy(hist.residuals),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "fractions": mass_fractions(project),
        "instrument": {
            key: value[1] if isinstance(value, list) and len(value) > 1 else value
            for key, value in hist.InstrumentParameters.items()
        },
        "sample": {
            key: value[0] if isinstance(value, list) and value else value
            for key, value in hist.SampleParameters.items()
            if key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "background": copy.deepcopy(hist.Background[0]),
        "phases": {
            phase.name: {
                "cell": copy.deepcopy(phase.get_cell()),
                "hap": {
                    "Scale": copy.deepcopy(phase.data["Histograms"][hist.name]["Scale"]),
                    "Size": copy.deepcopy(phase.data["Histograms"][hist.name]["Size"]),
                    "Mustrain": copy.deepcopy(phase.data["Histograms"][hist.name]["Mustrain"]),
                    "Pref.Ori.": copy.deepcopy(phase.data["Histograms"][hist.name]["Pref.Ori."]),
                },
            }
            for phase in project.phases()
        },
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "frozen": [str(v) for v in project.get_Frozen()],
    }


def build(args) -> None:
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    xye, inst = make_support_files(outdir)
    gpx = outdir / "initial.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [float(args.intensity_scale), False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [float(args.background)]
                + [0.0] * (args.background_terms - 1),
                "refine": False,
            }
        }
    )
    specs = []
    for item in args.phase:
        cod_id, name, frac = item.split(":", 2)
        specs.append((cod_id, name, float(frac)))
    norm = sum(item[2] for item in specs)
    for cod_id, name, frac in specs:
        phase_path = Path(cod_id)
        if not phase_path.is_file():
            phase_path = cod_cif(cod_id)
        phase = project.add_phase(
            str(phase_path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        mass = float(phase.data["General"]["Mass"])
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * (frac / norm) / mass, False]
        phase.setSampleProfile(hist, "size", "isotropic", args.size)
        phase.setSampleProfile(hist, "microstrain", "isotropic", args.microstrain)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(gpx))
    record = snapshot(project, "initial-forward")
    (outdir / "log.json").write_text(json.dumps([record], indent=2) + "\n")
    if not getattr(args, "quiet", False):
        print(json.dumps(record, indent=2))


def inspect(args) -> None:
    project = G2.G2Project(str(Path(args.gpx).resolve()))
    print(json.dumps(snapshot(project, args.label), indent=2))


def export_profile(args) -> None:
    project = G2.G2Project(str(Path(args.gpx).resolve()))
    hist = project.histograms()[0]
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    np.savetxt(
        Path(args.output).resolve(),
        np.column_stack((x, y, calc, bkg, diff, w)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference,weight",
        comments="",
        fmt="%.10g",
    )


def clear_all_refinement_flags(project) -> None:
    """Retain parameter values while making a replay-only forward model."""
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"].get(hist.name)
        if not hap:
            continue
        if isinstance(hap.get("Scale"), list) and len(hap["Scale"]) > 1:
            hap["Scale"][1] = False
        for key in ("Size", "Mustrain"):
            value = hap.get(key)
            if isinstance(value, list) and len(value) > 2 and isinstance(value[2], list):
                value[2] = [False] * len(value[2])
            if isinstance(value, list) and len(value) > 5 and isinstance(value[5], list):
                value[5] = [False] * len(value[5])
        value = hap.get("Pref.Ori.")
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
        value = hap.get("HStrain")
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], list):
            value[1] = [False] * len(value[1])
        value = hap.get("Extinction")
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
        value = hap.get("Babinet")
        if isinstance(value, dict):
            for parameter in value.values():
                if isinstance(parameter, list) and len(parameter) > 1:
                    parameter[1] = False


def recalculate(args) -> None:
    """Save a fully replayed, no-variable profile from stored project values."""
    source = Path(args.gpx).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(source), newgpx=str(output))
    if args.clamp_physical:
        clamp_physical_profile(project)
    clear_all_refinement_flags(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()
    print(json.dumps(snapshot(project, args.label), indent=2))


def configure_stable_stage(project, stage: str) -> None:
    """Enable one low-correlation parameter block for a replay-audited trial."""
    hist = project.histograms()[0]
    if stage == "background-scales":
        hist.Background[0][1] = True
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True})
    elif stage == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    elif stage == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif stage == "cells":
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    elif stage == "instrument-uw":
        hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    elif stage == "instrument-x":
        hist.set_refinements({"Instrument Parameters": ["X"]})
    elif stage == "axial":
        hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    elif stage == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif stage.startswith("size-"):
        phase = project.phase(stage.removeprefix("size-"))
        phase.set_HAP_refinements(
            {"Size": {"type": phase.data["Histograms"][hist.name]["Size"][0], "refine": True}}
        )
    elif stage.startswith("strain-"):
        phase = project.phase(stage.removeprefix("strain-"))
        phase.set_HAP_refinements(
            {"Mustrain": {"type": phase.data["Histograms"][hist.name]["Mustrain"][0], "refine": True}}
        )
    else:
        raise ValueError(f"unknown stable refinement stage: {stage}")


def replay_in_place(project) -> None:
    clamp_physical_profile(project)
    clear_all_refinement_flags(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 0)
    project.save()
    project.refine()
    project.save()


def refine_stable(args) -> None:
    """Refine small blocks and accept only improvements that survive GPX replay."""
    source = Path(args.gpx).resolve()
    output = Path(args.output).resolve()
    outdir = output.parent
    outdir.mkdir(parents=True, exist_ok=True)
    accepted = outdir / "accepted.gpx"
    project = G2.G2Project(str(source), newgpx=str(accepted))
    replay_in_place(project)
    best = snapshot(project, "baseline-replay")
    best["accepted"] = True
    records = [best]
    phase_names = [phase.name for phase in project.phases()]
    size_stages = [f"size-{name}" for name in phase_names]
    strain_stages = [f"strain-{name}" for name in phase_names]
    sequence = [
        "background-scales", "zero", "cells", "instrument-uw", "instrument-x",
        *size_stages, *strain_stages,
        "polarization", "shift", "cells", "instrument-uw", "instrument-x",
        *size_stages, "background-scales", "zero", "cells", "background-scales",
    ]
    best_rwp = best["rwp_percent_recomputed"]
    for index, stage in enumerate(sequence, 1):
        trial_path = outdir / f"trial-{index:02d}-{stage}.gpx"
        trial = G2.G2Project(str(accepted), newgpx=str(trial_path))
        clear_all_refinement_flags(trial)
        set_common_bounds(trial)
        configure_stable_stage(trial, stage)
        trial.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        trial.set_Controls("cycles", args.cycles)
        trial.save()
        try:
            trial.refine()
            trial.save()
            replay_in_place(trial)
            record = snapshot(trial, stage)
            record["accepted"] = record["rwp_percent_recomputed"] < best_rwp - args.minimum_gain
            if record["accepted"]:
                best_rwp = record["rwp_percent_recomputed"]
                shutil.copy2(trial_path, accepted)
        except Exception as exc:
            record = {"label": stage, "accepted": False, "error": repr(exc)}
        records.append(record)
        (outdir / "stable-refinement-log.json").write_text(json.dumps(records, indent=2) + "\n")
        if "rwp_percent_recomputed" in record:
            print(
                f"{stage}: replay Rwp={record['rwp_percent_recomputed']:.5f}% "
                f"accepted={record['accepted']} fractions={record['fractions']}"
            )
        else:
            print(f"{stage}: ERROR {record['error']}")
    shutil.copy2(accepted, output)
    final = G2.G2Project(str(output))
    print(json.dumps(snapshot(final, "stable-final"), indent=2))


def branch_uiso(args) -> None:
    """Refine one common isotropic displacement parameter per phase."""
    source = Path(args.gpx).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(source), newgpx=str(output))
    clear_all_refinement_flags(project)
    project.index_ids()
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    project.get_Constraints("Phase").clear()
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.data[atom.cia] = "I"
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine()
    project.save()
    for phase in project.phases():
        for atom in phase.atoms():
            atom.data[atom.cia + 1] = min(max(float(atom.data[atom.cia + 1]), 0.003), 0.020)
    replay_in_place(project)
    print(json.dumps(snapshot(project, "common-uiso"), indent=2))


def branch_surface(args) -> None:
    """Test bounded Suortti surface roughness starts with scales/background."""
    source = Path(args.gpx).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    starts = [(0.05, 0.05), (0.15, 0.10), (0.35, 0.05), (0.50, 0.25)]
    records = []
    for index, (rough_a, rough_b) in enumerate(starts, 1):
        output = outdir / f"surface-{index}.gpx"
        project = G2.G2Project(str(source), newgpx=str(output))
        clear_all_refinement_flags(project)
        set_common_bounds(project)
        hist = project.histograms()[0]
        hist.SampleParameters["SurfRoughA"][0] = rough_a
        hist.SampleParameters["SurfRoughB"][0] = rough_b
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        hist.Background[0][1] = True
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True})
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", args.cycles)
        project.save()
        try:
            project.refine()
            project.save()
            hist.SampleParameters["SurfRoughA"][0] = min(
                max(float(hist.SampleParameters["SurfRoughA"][0]), 0.05), 0.60
            )
            hist.SampleParameters["SurfRoughB"][0] = min(
                max(float(hist.SampleParameters["SurfRoughB"][0]), 0.02), 0.50
            )
            replay_in_place(project)
            record = snapshot(project, f"surface-{index}")
        except Exception as exc:
            record = {"label": f"surface-{index}", "error": repr(exc)}
        record["start"] = [rough_a, rough_b]
        records.append(record)
        (outdir / "summary.json").write_text(json.dumps(records, indent=2) + "\n")
        print(json.dumps(record))


def export_final(args) -> None:
    """Export all submission artifacts from one immutable GSAS-II project."""
    source = Path(args.gpx).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(source))
    hist = project.histograms()[0]
    # Export saved atoms/cells, never stale covariance parameter values.
    project.data.setdefault("Covariance", {}).setdefault("data", {}).clear()
    fractions = mass_fractions(project)
    phase_rows = []
    for index, phase in enumerate(project.phases()):
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", phase.name).strip("_")
        filename = f"phase_{index + 1}_{safe}.cif"
        phase.export_CIF(str(outdir / filename))
        general = phase.data["General"]
        counts = {
            element: int(round(float(general.get("NoAtoms", {}).get(element, 0))))
            for element in general.get("AtomTypes", [])
        }
        divisor = math.gcd(*[value for value in counts.values() if value > 0]) if counts else 1
        formula = "".join(
            element + (str(count // divisor) if count // divisor != 1 else "")
            for element, count in counts.items()
            if count > 0
        )
        phase_rows.append(
            {
                "name": phase.name,
                "formula": formula or general.get("Name", phase.name),
                "space_group": general.get("SGData", {}).get("SpGrp"),
                "cif_path": filename,
                "weight_fraction": fractions[phase.name],
                "weight_percent": 100.0 * fractions[phase.name],
            }
        )

    x, observed, stored_weight, calculated, background = [
        np.asarray(value, float) for value in hist.data["data"][1][:5]
    ]
    difference = observed - calculated
    np.savetxt(
        outdir / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )
    weight = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weight * difference**2))
    denominator = float(np.sum(weight * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    result = {
        "phases": phase_rows,
        "refinement_histogram": hist.name,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "chi_square": chi_square,
            "data_points": int(len(x)),
            "weighting": "1/max(observed_counts,1)",
        },
    }
    (outdir / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


def seed_nuisance(args) -> None:
    """Transfer a converged measurement/profile model onto alternate structures."""
    target_path = Path(args.target).resolve()
    source_path = Path(args.source).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    target = G2.G2Project(str(target_path), newgpx=str(output))
    source = G2.G2Project(str(source_path))
    target_hist = target.histograms()[0]
    source_hist = source.histograms()[0]
    for key, value in source_hist.InstrumentParameters.items():
        if key in target_hist.InstrumentParameters and isinstance(value, list):
            target_hist.InstrumentParameters[key][1] = copy.deepcopy(value[1])
    for key, value in source_hist.SampleParameters.items():
        if key in target_hist.SampleParameters and isinstance(value, list):
            target_hist.SampleParameters[key][0] = copy.deepcopy(value[0])
    target_hist.data["Background"] = copy.deepcopy(source_hist.data["Background"])
    for target_phase in target.phases():
        source_phase = source.phase(target_phase.name)
        target_phase.data["General"]["Cell"] = copy.deepcopy(
            source_phase.data["General"]["Cell"]
        )
        target_hap = target_phase.data["Histograms"][target_hist.name]
        source_hap = source_phase.data["Histograms"][source_hist.name]
        for key in ("Scale", "Size", "Mustrain", "Pref.Ori."):
            target_hap[key] = copy.deepcopy(source_hap[key])
    replay_in_place(target)
    print(json.dumps(snapshot(target, "seeded-nuisance"), indent=2))


def set_common_bounds(project) -> None:
    project.index_ids()
    hist = project.histograms()[0]
    hid = hist.id
    bounds = {
        f":{hid}:Zero": (-0.30, 0.30),
        f":{hid}:U": (0.0, 45.0),
        f":{hid}:W": (0.5, 45.0),
        f":{hid}:X": (0.10, 6.0),
        f":{hid}:SH/L": (0.005, 0.10),
        f":{hid}:Polariz.": (0.45, 1.0),
        f":{hid}:Shift": (-800.0, 800.0),
        f":{hid}:SurfRoughA": (0.05, 0.60),
        f":{hid}:SurfRoughB": (0.02, 0.50),
    }
    for phase in project.phases():
        pid = phase.id
        hap = phase.data["Histograms"][hist.name]
        scale = float(hap["Scale"][0])
        bounds[f"{pid}:{hid}:Scale"] = (max(scale * 0.01, 0.0), scale * 100.0)
        bounds[f"{pid}:{hid}:Size;i"] = (0.04, 1.5)
        bounds[f"{pid}:{hid}:Mustrain;i"] = (0.0, 8000.0)
        bounds[f"{pid}:{hid}:Mustrain;a"] = (0.0, 8000.0)
        bounds[f"{pid}:{hid}:MD"] = (0.65, 1.5)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def run_stage(project, outdir: Path, label: str, records: list[dict]) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.refine()
    project.save()
    record = snapshot(project, label)
    records.append(record)
    shutil.copy2(project.filename, outdir / f"checkpoint-{len(records):02d}-{label}.gpx")
    (outdir / "refinement-log.json").write_text(json.dumps(records, indent=2) + "\n")
    print(
        f"{label}: Rwp={record['rwp_percent_recomputed']:.5f}% "
        f"converged={record['converged']} max_shift/esd={record['max_shift_esd']} "
        f"fractions={record['fractions']}"
    )


def refine_base(args) -> None:
    source = Path(args.gpx).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(source), newgpx=str(output))
    project.save()
    project.set_Controls("cycles", args.cycles)
    set_common_bounds(project)
    hist = project.histograms()[0]
    records: list[dict] = [snapshot(project, "loaded")]

    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    run_stage(project, output.parent, "background-scales", records)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_stage(project, output.parent, "angular-zero", records)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_stage(project, output.parent, "sample-shift", records)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_stage(project, output.parent, "cells", records)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_stage(project, output.parent, "instrument-profile", records)

    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_stage(project, output.parent, "phase-profile", records)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_stage(project, output.parent, "polarization", records)

    run_stage(project, output.parent, "settle", records)


def freeze_except_scales_background(project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "HStrain": True, "Pref.Ori.": True}
        )


def clamp_physical_profile(project) -> None:
    hist = project.histograms()[0]
    ip = hist.InstrumentParameters
    for key, low, high in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
    ):
        ip[key][1] = min(max(float(ip[key][1]), low), high)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = min(max(float(hap["Size"][1][0]), 0.04), 1.5)
        hap["Mustrain"][1][0] = min(max(float(hap["Mustrain"][1][0]), 0.0), 8000.0)


def branch_md(args) -> None:
    source = Path(args.gpx).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    axes = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]
    summaries = []
    baseline = G2.G2Project(str(source))
    phase_names = [phase.name for phase in baseline.phases()]
    if args.phase_name:
        phase_names = [name for name in phase_names if name == args.phase_name]
        if not phase_names:
            raise ValueError(f"phase not found: {args.phase_name}")
    for phase_name in phase_names:
        for axis in axes:
            tag = f"{phase_name}-{'-'.join(map(str, axis))}".replace("/", "_")
            output = outdir / f"md-{tag}.gpx"
            project = G2.G2Project(str(source), newgpx=str(output))
            project.save()
            project.set_Controls("cycles", args.cycles)
            clamp_physical_profile(project)
            set_common_bounds(project)
            freeze_except_scales_background(project)
            for phase in project.phases():
                po = phase.data["Histograms"][project.histograms()[0].name]["Pref.Ori."]
                po[2] = False
                if phase.name == phase_name:
                    po[0] = "MD"
                    po[1] = 1.0
                    po[2] = True
                    po[3] = list(axis)
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            project.refine()
            project.save()
            record = snapshot(project, tag)
            record["tested_phase"] = phase_name
            record["tested_axis"] = list(axis)
            summaries.append(record)
            (outdir / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
            ratio = project.phase(phase_name).data["Histograms"][project.histograms()[0].name]["Pref.Ori."][1]
            print(f"{tag}: Rwp={record['rwp_percent_recomputed']:.5f}% MD={ratio:.6g}")


def branch_mustrain(args) -> None:
    source = Path(args.gpx).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    axes = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]
    baseline = G2.G2Project(str(source))
    phase_names = [phase.name for phase in baseline.phases()]
    if args.phase_name:
        phase_names = [name for name in phase_names if name == args.phase_name]
        if not phase_names:
            raise ValueError(f"phase not found: {args.phase_name}")
    summaries = []
    for phase_name in phase_names:
        for axis in axes:
            tag = f"{phase_name}-{'-'.join(map(str, axis))}".replace("/", "_")
            output = outdir / f"mustrain-{tag}.gpx"
            project = G2.G2Project(str(source), newgpx=str(output))
            project.save()
            project.set_Controls("cycles", args.cycles)
            clamp_physical_profile(project)
            freeze_except_scales_background(project)
            hist = project.histograms()[0]
            phase = project.phase(phase_name)
            old = float(phase.data["Histograms"][hist.name]["Mustrain"][1][0])
            equatorial = min(max(old, 300.0), 8000.0)
            axial = min(max(equatorial * 0.5, 300.0), 8000.0)
            phase.setSampleProfile(
                hist, "microstrain", "uniaxial", equatorial, axial, list(axis)
            )
            strain = phase.data["Histograms"][hist.name]["Mustrain"]
            strain[2][0] = True
            strain[2][1] = True
            set_common_bounds(project)
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            project.refine()
            project.save()
            record = snapshot(project, tag)
            record["tested_phase"] = phase_name
            record["tested_axis"] = list(axis)
            summaries.append(record)
            (outdir / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")
            values = project.phase(phase_name).data["Histograms"][hist.name]["Mustrain"][1][:2]
            print(f"{tag}: Rwp={record['rwp_percent_recomputed']:.5f}% strain={values}")


def activate_physical_flags(project, surface_roughness: bool = False) -> None:
    hist = project.histograms()[0]
    hist.set_refinements({"Background": True})
    hist.set_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    if surface_roughness:
        if float(hist.SampleParameters["SurfRoughA"][0]) <= 0:
            hist.SampleParameters["SurfRoughA"][0] = 0.1
        if float(hist.SampleParameters["SurfRoughB"][0]) <= 0:
            hist.SampleParameters["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        size_type = hap["Size"][0]
        strain_type = hap["Mustrain"][0]
        phase.set_HAP_refinements(
            {
                "Size": {"type": size_type, "refine": True},
                "Mustrain": {"type": strain_type, "refine": True},
            }
        )
        if hap["Pref.Ori."][2]:
            phase.set_HAP_refinements({"Pref.Ori.": True})


def refine_physical(args) -> None:
    source = Path(args.gpx).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(source), newgpx=str(output))
    project.save()
    project.set_Controls("cycles", args.cycles)
    clamp_physical_profile(project)
    set_common_bounds(project)
    activate_physical_flags(project, args.surface_roughness)
    records = [snapshot(project, "loaded-physical")]
    for index in range(args.passes):
        run_stage(project, output.parent, f"physical-pass-{index + 1}", records)


def screen_references(args) -> None:
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    summaries = []
    for cod_id in args.cod_ids.split(","):
        cod_id = cod_id.strip()
        branch = outdir / cod_id
        branch.mkdir(parents=True, exist_ok=True)
        try:
            build(
                SimpleNamespace(
                    outdir=str(branch),
                    phase=["1520200:MnWO4:0.75", f"{cod_id}:WO3:0.25"],
                    background=1200.0,
                    background_terms=8,
                    intensity_scale=9.0,
                    size=0.3,
                    microstrain=1000.0,
                    quiet=True,
                )
            )
            source = branch / "initial.gpx"
            output = branch / "screened.gpx"
            project = G2.G2Project(str(source), newgpx=str(output))
            project.save()
            project.set_Controls("cycles", args.cycles)
            set_common_bounds(project)
            hist = project.histograms()[0]
            hist.set_refinements({"Background": True})
            hist.set_refinements({"Instrument Parameters": ["Zero"]})
            hist.set_refinements({"Sample Parameters": ["Shift"]})
            for phase in project.phases():
                phase.set_HAP_refinements({"Scale": True})
                phase.set_refinements({"Cell": True})
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            project.refine()
            first = snapshot(project, f"{cod_id}-positions")
            clamp_physical_profile(project)
            set_common_bounds(project)
            activate_physical_flags(project)
            project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
            project.refine()
            project.save()
            second = snapshot(project, f"{cod_id}-physical")
            summaries.append(
                {
                    "cod_id": cod_id,
                    "position_rwp_percent": first["rwp_percent_recomputed"],
                    "physical_rwp_percent": second["rwp_percent_recomputed"],
                    "record": second,
                }
            )
            print(
                f"{cod_id}: positions={first['rwp_percent_recomputed']:.5f}% "
                f"physical={second['rwp_percent_recomputed']:.5f}% "
                f"fractions={second['fractions']}"
            )
        except Exception as exc:
            summaries.append({"cod_id": cod_id, "error": repr(exc)})
            print(f"{cod_id}: ERROR {exc!r}")
        (outdir / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")


def normalize_isotropic_adps(project, value: float) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(value)
            atom.refinement_flags = " "


def freeze_for_coordinates(project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements(
            {
                "Size": True,
                "Mustrain": True,
                "HStrain": True,
                "Pref.Ori.": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )
        for atom in phase.atoms():
            atom.refinement_flags = " "


def install_coordinate_adp_bounds(project, coordinate_window_A: float = 0.10) -> None:
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hist = project.histograms()[0]
    for phase in project.phases():
        pid = phase.id
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        hap = phase.data["Histograms"][hist.name]
        scale = max(float(hap["Scale"][0]), 1e-12)
        project.set_Controls("parmMin", 0.1 * scale, variable=f"{pid}:{hist.id}:Scale")
        project.set_Controls("parmMax", 10.0 * scale, variable=f"{pid}:{hist.id}:Scale")
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half = coordinate_window_A / float(length)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half, variable=variable)
                project.set_Controls("parmMax", float(value) + half, variable=variable)
            project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:{index}")


def refine_coordinates(args) -> None:
    source = Path(args.gpx).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(source), newgpx=str(output))
    project.save()
    project.set_Controls("cycles", args.cycles)
    normalize_isotropic_adps(project, args.uiso)
    freeze_for_coordinates(project)
    install_coordinate_adp_bounds(project, args.window)
    records = [snapshot(project, "normalized-adps-loaded")]
    run_stage(project, output.parent, "normalized-adps-scales", records)

    selected = {"W"}
    for stage, additions in (("heavy-coordinates", set()), ("cation-coordinates", {"Mn"}), ("all-coordinates", {"O"})):
        selected |= additions
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "X" if atom.element in selected else " "
        run_stage(project, output.parent, stage, records)

    project.get_Constraints("Phase").clear()
    for phase in project.phases():
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "XU"
            variables.append(f"{phase.id}::AUiso:{index}")
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    run_stage(project, output.parent, "coordinates-common-uiso", records)


def refine_lebail(args) -> None:
    source = Path(args.gpx).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(source), newgpx=str(output))
    project.save()
    project.set_Controls("cycles", args.cycles)
    clamp_physical_profile(project)
    set_common_bounds(project)
    activate_physical_flags(project)
    for phase in project.phases():
        phase.set_refinements({"LeBail": True})
        if phase.name in args.fixed_phase_cell:
            phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
    records = [snapshot(project, "lebail-loaded")]
    for index in range(args.passes):
        run_stage(project, output.parent, f"lebail-pass-{index + 1}", records)


def branch_add_candidates(args) -> None:
    source = Path(args.gpx).resolve()
    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    summaries = []
    for spec in args.candidate:
        source_id, phase_name = spec.split(":", 1)
        tag = f"{phase_name}-{source_id}".replace("/", "_")
        output = outdir / f"{tag}.gpx"
        try:
            project = G2.G2Project(str(source), newgpx=str(output))
            project.save()
            hist = project.histograms()[0]
            path = Path(source_id)
            if not path.is_file():
                path = cod_cif(source_id)
            phase = project.add_phase(
                str(path), phasename=phase_name, histograms=[hist], fmthint="CIF"
            )
            total_weighted = sum(
                float(p.data["General"]["Mass"])
                * float(p.data["Histograms"][hist.name]["Scale"][0])
                for p in project.phases()
                if p.name != phase_name
            )
            mass = float(phase.data["General"]["Mass"])
            phase.data["Histograms"][hist.name]["Scale"] = [
                args.initial_fraction / (1.0 - args.initial_fraction) * total_weighted / mass,
                True,
            ]
            phase.setSampleProfile(hist, "size", "isotropic", 0.3)
            phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0)
            freeze_except_scales_background(project)
            controls = project.data["Controls"]["data"]
            controls["parmMinDict"] = {}
            controls["parmMaxDict"] = {}
            controls["parmFrozen"] = {"FrozenList": []}
            project.index_ids()
            for p in project.phases():
                scale = float(p.data["Histograms"][hist.name]["Scale"][0])
                project.set_Controls("parmMin", 0.0, variable=f"{p.id}:{hist.id}:Scale")
                project.set_Controls("parmMax", max(scale * 20.0, 1.0), variable=f"{p.id}:{hist.id}:Scale")
            project.set_Controls("cycles", args.cycles)
            project.refine()
            project.save()
            record = snapshot(project, tag)
            summaries.append({"source": source_id, "phase": phase_name, "record": record})
            print(
                f"{tag}: Rwp={record['rwp_percent_recomputed']:.5f}% "
                f"fraction={record['fractions'].get(phase_name, 0):.6f}"
            )
        except Exception as exc:
            summaries.append({"source": source_id, "phase": phase_name, "error": repr(exc)})
            print(f"{tag}: ERROR {exc!r}")
        (outdir / "summary.json").write_text(json.dumps(summaries, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(required=True)
    p = sub.add_parser("build")
    p.add_argument("outdir")
    p.add_argument("--phase", action="append", required=True, help="COD:name:fraction")
    p.add_argument("--background", type=float, default=1200.0)
    p.add_argument("--background-terms", type=int, default=8)
    p.add_argument("--intensity-scale", type=float, default=40000.0)
    p.add_argument("--size", type=float, default=0.3)
    p.add_argument("--microstrain", type=float, default=1000.0)
    p.set_defaults(func=build)
    p = sub.add_parser("inspect")
    p.add_argument("gpx")
    p.add_argument("--label", default="inspection")
    p.set_defaults(func=inspect)
    p = sub.add_parser("refine-base")
    p.add_argument("gpx")
    p.add_argument("output")
    p.add_argument("--cycles", type=int, default=8)
    p.set_defaults(func=refine_base)
    p = sub.add_parser("export-profile")
    p.add_argument("gpx")
    p.add_argument("output")
    p.set_defaults(func=export_profile)
    p = sub.add_parser("recalculate")
    p.add_argument("gpx")
    p.add_argument("output")
    p.add_argument("--label", default="replayed")
    p.add_argument("--clamp-physical", action="store_true")
    p.set_defaults(func=recalculate)
    p = sub.add_parser("refine-stable")
    p.add_argument("gpx")
    p.add_argument("output")
    p.add_argument("--cycles", type=int, default=8)
    p.add_argument("--minimum-gain", type=float, default=1.0e-5)
    p.set_defaults(func=refine_stable)
    p = sub.add_parser("branch-uiso")
    p.add_argument("gpx")
    p.add_argument("output")
    p.add_argument("--cycles", type=int, default=10)
    p.set_defaults(func=branch_uiso)
    p = sub.add_parser("branch-surface")
    p.add_argument("gpx")
    p.add_argument("outdir")
    p.add_argument("--cycles", type=int, default=10)
    p.set_defaults(func=branch_surface)
    p = sub.add_parser("export-final")
    p.add_argument("gpx")
    p.add_argument("outdir")
    p.set_defaults(func=export_final)
    p = sub.add_parser("seed-nuisance")
    p.add_argument("target")
    p.add_argument("source")
    p.add_argument("output")
    p.set_defaults(func=seed_nuisance)
    p = sub.add_parser("branch-md")
    p.add_argument("gpx")
    p.add_argument("outdir")
    p.add_argument("--cycles", type=int, default=8)
    p.add_argument("--phase-name")
    p.set_defaults(func=branch_md)
    p = sub.add_parser("branch-mustrain")
    p.add_argument("gpx")
    p.add_argument("outdir")
    p.add_argument("--cycles", type=int, default=8)
    p.add_argument("--phase-name")
    p.set_defaults(func=branch_mustrain)
    p = sub.add_parser("refine-physical")
    p.add_argument("gpx")
    p.add_argument("output")
    p.add_argument("--cycles", type=int, default=10)
    p.add_argument("--passes", type=int, default=1)
    p.add_argument("--surface-roughness", action="store_true")
    p.set_defaults(func=refine_physical)
    p = sub.add_parser("screen-references")
    p.add_argument("outdir")
    p.add_argument("cod_ids")
    p.add_argument("--cycles", type=int, default=8)
    p.set_defaults(func=screen_references)
    p = sub.add_parser("refine-coordinates")
    p.add_argument("gpx")
    p.add_argument("output")
    p.add_argument("--cycles", type=int, default=10)
    p.add_argument("--window", type=float, default=0.10)
    p.add_argument("--uiso", type=float, default=0.008)
    p.set_defaults(func=refine_coordinates)
    p = sub.add_parser("refine-lebail")
    p.add_argument("gpx")
    p.add_argument("output")
    p.add_argument("--cycles", type=int, default=8)
    p.add_argument("--passes", type=int, default=2)
    p.add_argument("--fixed-phase-cell", action="append", default=[])
    p.set_defaults(func=refine_lebail)
    p = sub.add_parser("branch-add-candidates")
    p.add_argument("gpx")
    p.add_argument("outdir")
    p.add_argument("--candidate", action="append", required=True, help="COD-or-path:name")
    p.add_argument("--initial-fraction", type=float, default=0.03)
    p.add_argument("--cycles", type=int, default=6)
    p.set_defaults(func=branch_add_candidates)
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
