from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d, percentile_filter


ROOT = Path(__file__).resolve().parent
CIF_ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")


def cif(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
baseline = gaussian_filter1d(
    percentile_filter(y, percentile=15, size=367, mode="nearest"), 30
)

fig, axes = plt.subplots(3, 1, figsize=(18, 10), sharex=False)
windows = [(9.9, 45), (40, 72), (68, 100.1)]
models = {
    "MnWO4 1520200": ("1520200", "C0"),
    "WO3 1528915": ("1528915", "C3"),
    "Mn3O4 hausmannite 9001963": ("9001963", "C2"),
    "Mn3O4 HP 1541183": ("1541183", "C4"),
}
calc = XRDCalculator(wavelength=1.540598)
patterns = {}
for label, (cod_id, color) in models.items():
    patterns[label] = (calc.get_pattern(Structure.from_file(cif(cod_id)), two_theta_range=(9.5, 101)), color)

for ax, (lo, hi) in zip(axes, windows):
    sel = (x >= lo) & (x <= hi)
    ax.plot(x[sel], y[sel], color="black", lw=0.7, label="observed")
    ax.plot(x[sel], baseline[sel], color="0.6", lw=0.7, label="estimated background")
    ymax = y[sel].max()
    levels = np.linspace(-0.05 * ymax, -0.28 * ymax, len(patterns))
    for level, (label, (pattern, color)) in zip(levels, patterns.items()):
        keep = (pattern.x >= lo) & (pattern.x <= hi) & (pattern.y >= 0.5)
        ax.vlines(pattern.x[keep], level, level - 0.07 * ymax * pattern.y[keep] / 100, color=color, lw=0.7)
        ax.text(lo + 0.3, level - 0.015 * ymax, label, color=color, va="top", fontsize=8)
    ax.set_xlim(lo, hi)
    ax.set_ylim(-0.4 * ymax, 1.04 * ymax)
    ax.set_ylabel("counts")
axes[-1].set_xlabel(r"$2\theta$ (deg)")
fig.tight_layout()
fig.savefig(ROOT / "analysis_overview.png", dpi=160)
