#!/usr/bin/env python3
"""Create a symmetry-preserving Mn3W2O9 analogue from COD 2311977 Sr3W2O9."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifFile, CifWriter


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/2/31/19/2311977.cif"
)
OUTPUT = ROOT / "mn3w2o9_analogue.cif"

structure = Structure.from_file(SOURCE, primitive=False)
structure.replace_species({"Sr": "Mn"})
lattice = structure.lattice
contracted = Lattice.from_parameters(
    0.945 * lattice.a,
    0.945 * lattice.b,
    0.945 * lattice.c,
    lattice.alpha,
    lattice.beta,
    lattice.gamma,
)
structure = Structure(
    contracted,
    structure.species,
    structure.frac_coords,
    coords_are_cartesian=False,
    site_properties=structure.site_properties,
)
writer = CifWriter(structure, symprec=0.001, significant_figures=10)
cif = CifFile.from_str(str(writer))
for block in cif.data.values():
    tag = "_atom_site_U_iso_or_equiv"
    block.data[tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
    loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
    if tag not in loop:
        loop.append(tag)
OUTPUT.write_text(str(cif) + "\n")
print(OUTPUT)
