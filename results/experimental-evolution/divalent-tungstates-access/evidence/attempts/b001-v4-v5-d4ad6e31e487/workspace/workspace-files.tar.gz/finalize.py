#!/usr/bin/env python3
"""Create the final full-grid GSAS-II replay and its public exports."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "branches" / "refine20b_uiso_converged.gpx"
OUTPUT = ROOT / "final.gpx"

FORMULAS = {
    "CuWO4": "CuWO4",
    "Cu3WO6": "Cu3WO6",
    "WO3": "WO3",
    "CuO": "CuO",
}
COD_IDS = {
    "CuWO4": "4000806",
    "Cu3WO6": "1527404",
    "WO3": "2311041",
    "CuO": "1011194",
}


def array(values: object) -> np.ndarray:
    return np.asarray(np.ma.filled(values, np.nan), dtype=float)


project = G2sc.G2Project(str(INPUT), newgpx=str(OUTPUT))
hist = project.histogram(0)

# Replay every supplied point. Calibration is retained from the physical
# checkpoint; its zero/height pair was highly correlated when reopened.
x = array(hist.data["data"][1][0])
hist.Limits("lower", float(x[0]))
hist.Limits("upper", float(x[-1]))
hist.clear_refinements({
    "Instrument Parameters": ["Zero"],
    "Sample Parameters": ["Shift"],
})
project.set_Frozen()
project.set_Controls("cycles", 16)
project.save(str(OUTPUT))

# A second pass is inexpensive and leaves a genuinely settled full-grid
# covariance matrix rather than only a recalculated profile.
for _ in range(2):
    project.do_refinements([{}])
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    if rvals.get("converged") and abs(float(rvals.get("Max shft/sig", 1.0))) < 0.1:
        break

hist = project.histogram(0)
profile = hist.data["data"][1]
x = array(profile[0])
observed = array(profile[1])
weights = array(profile[2])
calculated = array(profile[3])
difference = array(profile[5])

if len(x) != 8301:
    raise RuntimeError(f"Expected 8301 profile points, found {len(x)}")
if not np.all(np.isfinite(calculated)) or calculated[0] <= 0 or calculated[-1] <= 0:
    raise RuntimeError("Calculated profile does not cover the full measured grid")
if np.max(np.abs(difference - (observed - calculated))) > 1.0e-6:
    raise RuntimeError("GSAS-II difference array is inconsistent with Yo-Yc")

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack([x, observed, calculated, difference]),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
)

mass_fractions = hist.ComputeMassFracs()
phase_rows = []
for phase in project.phases():
    cif_name = f"{phase.name}.cif"
    phase.export_CIF(str(ROOT / cif_name))
    fraction, esd = mass_fractions[phase.name]
    phase_rows.append({
        "id": phase.name,
        "name": phase.name,
        "formula": FORMULAS[phase.name],
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "reference_cod_id": COD_IDS[phase.name],
        "cif_path": cif_name,
        "weight_fraction": float(fraction),
        "weight_fraction_esd": float(esd),
        "weight_percent": 100.0 * float(fraction),
    })

meta = hist.data["data"][0]
cov = project.data["Covariance"]["data"]
rvals = cov["Rvals"]
nobs = int(rvals["Nobs"])
nvars = len(cov["varyList"])
chisq_direct = float(np.sum(weights * difference**2))
rwp_direct = 100.0 * math.sqrt(
    chisq_direct / float(np.sum(weights * observed**2))
)
rp_direct = 100.0 * float(np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

if nobs != len(x):
    raise RuntimeError(f"Final refinement used {nobs} of {len(x)} supplied points")
if abs(rwp_direct - float(rvals["Rwp"])) > 1.0e-5:
    raise RuntimeError("Exported full-grid profile does not reproduce GSAS-II Rwp")

result = {
    "schema_version": 1,
    "refinement_histogram": hist.name,
    "project_path": "final.gpx",
    "profile_path": "fit.csv",
    "weight_fraction_basis": "normalized over the modeled crystalline phases",
    "phases": phase_rows,
    "fit_statistics": {
        "Rwp_percent": float(rvals["Rwp"]),
        "Rp_percent": float(meta["R"]),
        "Rp_direct_full_grid_percent": rp_direct,
        "R_expected_GSAS_percent": float(meta["wRmin"]),
        "chi_squared": float(rvals["chisq"]),
        "chi_squared_direct": chisq_direct,
        "reduced_chi_squared": float(rvals["chisq"]) / (nobs - nvars),
        "goodness_of_fit": float(rvals["GOF"]),
        "durbin_watson": float(meta["Durbin-Watson"]),
        "n_points": len(x),
        "n_observations": nobs,
        "n_refined_parameters": nvars,
    },
}

(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
project.save()

print(json.dumps(result, indent=2))
