#!/usr/bin/env python3
"""Apply one controlled refinement step to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat

from gsas_branch import stage_summary


def refine(project: G2sc.G2Project, output: Path, label: str) -> dict:
    project.set_Controls("cycles", 16)
    project.save(str(output))
    project.do_refinements([{}])
    project.save()
    result = stage_summary(project, label)
    result["vary_list"] = [
        str(item)
        for item in project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
    ]
    result["variables"] = [
        float(item)
        for item in project.data.get("Covariance", {}).get("data", {}).get("variables", [])
    ]
    result["sigmas"] = [
        float(item)
        for item in project.data.get("Covariance", {}).get("data", {}).get("sig", [])
    ]
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    stem = output.with_suffix("")
    for phase in project.phases():
        safe_name = re.sub(r"[^A-Za-z0-9_.-]+", "_", phase.name)
        phase.export_CIF(str(stem.parent / f"{stem.name}_{safe_name}.cif"))
    print(
        f"{label}: Rwp={result['Rwp_percent']:.6f}% "
        f"fractions={result.get('mass_fractions', {})}",
        flush=True,
    )
    return result


def clear_profile_flags(hist) -> None:
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})


def freeze_calibration(hist) -> None:
    hist.clear_refinements({
        "Instrument Parameters": ["Zero"],
        "Sample Parameters": ["Shift"],
    })


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "step",
        choices=[
            "calibration", "calibration_reopen", "heavy", "oxygen", "oxygen_bounded",
            "all_atoms", "polarization", "interpolate_fixed", "uiso_common", "uiso_rebuild",
            "uiso_fix", "profile_basic", "size_iso", "size_iso_one", "size_fix",
            "mustrain_iso", "mustrain_iso_one", "mustrain_uniaxial_one", "mustrain_fix",
            "add_phase", "cell_one", "texture_md",
        ],
    )
    parser.add_argument("--phase", action="append", default=[])
    parser.add_argument("--delta", type=float, default=0.01)
    parser.add_argument("--target-project", type=Path)
    parser.add_argument("--factor", type=float, default=0.25)
    parser.add_argument("--value", type=float, default=0.008)
    parser.add_argument("--cif", type=Path)
    parser.add_argument("--axis", type=int, nargs=3)
    args = parser.parse_args()

    output = args.output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(args.input.resolve()), newgpx=str(output))
    hist = project.histogram(0)

    if args.step == "add_phase":
        if not args.cif or len(args.phase) != 1:
            raise ValueError("add_phase needs --cif and one --phase name")
        phase = project.add_phase(
            str(args.cif.resolve()),
            phasename=args.phase[0],
            histograms=[hist],
            fmthint="CIF",
        )
        phase.set_HAP_refinements({"Scale": True}, [hist])
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1.0e5, variable=f"{phase.id}:0:Scale")
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2][0] = False
        for atom in phase.atoms():
            try:
                atom.uiso = args.value
            except G2sc.G2ScriptException:
                # Preserve a reference's anisotropic displacement tensor.
                pass
            atom.refinement_flags = ""
    elif args.step == "cell_one":
        if len(args.phase) != 1:
            raise ValueError("cell_one needs one --phase")
        phase = project.phase(args.phase[0])
        phase.set_refinements({"Cell": True})
        cell = phase.get_cell()
        metric = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(metric):
            span = max(0.25 * abs(value), 0.003)
            project.set_Controls(
                "parmMin", value - span, variable=f"{phase.id}::A{index}"
            )
            project.set_Controls(
                "parmMax", value + span, variable=f"{phase.id}::A{index}"
            )
    elif args.step == "texture_md":
        if len(args.phase) != 1 or args.axis is None:
            raise ValueError("texture_md needs one --phase and --axis h k l")
        phase = project.phase(args.phase[0])
        pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
        pref[0] = "MD"
        pref[1] = 1.0
        pref[2] = True
        pref[3] = list(args.axis)
        variable = f"{phase.id}:0:MD"
        project.set_Controls("parmMin", 0.7, variable=variable)
        project.set_Controls("parmMax", 1.4, variable=variable)
    elif args.step == "calibration":
        hist.SampleParameters["Shift"][0] = 700.0
        hist.InstrumentParameters["Zero"][1] = -0.075
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")
        hist.set_refinements({
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Zero"],
        })
    elif args.step == "calibration_reopen":
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")
        hist.set_refinements({
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Zero"],
        })
    elif args.step == "heavy":
        clear_profile_flags(hist)
        freeze_calibration(hist)
        selected = set(args.phase)
        for phase in project.phases():
            if selected and phase.name not in selected:
                continue
            flags = {
                atom.label: "X"
                for atom in phase.atoms()
                if atom.element != "O"
            }
            phase.set_refinements({"Atoms": flags})
    elif args.step in {"oxygen", "oxygen_bounded"}:
        clear_profile_flags(hist)
        freeze_calibration(hist)
        selected = set(args.phase)
        for phase in project.phases():
            if selected and phase.name not in selected:
                continue
            flags = {
                atom.label: "X"
                for atom in phase.atoms()
                if atom.element == "O"
            }
            phase.set_refinements({"Atoms": flags})
            if args.step == "oxygen_bounded":
                for index, atom in enumerate(phase.atoms()):
                    if atom.element != "O":
                        continue
                    for axis in "xyz":
                        variable = f"{phase.id}::dA{axis}:{index}"
                        project.set_Controls("parmMin", -args.delta, variable=variable)
                        project.set_Controls("parmMax", args.delta, variable=variable)
    elif args.step == "all_atoms":
        clear_profile_flags(hist)
        freeze_calibration(hist)
        selected = set(args.phase)
        for phase in project.phases():
            if selected and phase.name not in selected:
                continue
            phase.set_refinements({
                "Atoms": {atom.label: "X" for atom in phase.atoms()}
            })
    elif args.step == "polarization":
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif args.step == "interpolate_fixed":
        if not args.target_project or len(args.phase) != 1:
            raise ValueError("interpolate_fixed needs --target-project and one --phase")
        clear_profile_flags(hist)
        freeze_calibration(hist)
        target = G2sc.G2Project(str(args.target_project.resolve()))
        phase = project.phase(args.phase[0])
        target_phase = target.phase(args.phase[0])
        target_atoms = {atom.label: atom for atom in target_phase.atoms()}
        for atom in phase.atoms():
            if atom.element != "O":
                continue
            other = target_atoms[atom.label]
            start = np.asarray(atom.coordinates, dtype=float)
            end = np.asarray(other.coordinates, dtype=float)
            delta = (end - start + 0.5) % 1.0 - 0.5
            atom.coordinates = tuple((start + args.factor * delta) % 1.0)
            atom.refinement_flags = ""
        project.set_Frozen()
    elif args.step == "uiso_common":
        clear_profile_flags(hist)
        freeze_calibration(hist)
        selected = set(args.phase)
        for phase in project.phases():
            if selected and phase.name not in selected:
                continue
            variables = []
            for index, atom in enumerate(phase.atoms()):
                atom.uiso = args.value
                flags = set(atom.refinement_flags.strip())
                flags.add("U")
                atom.refinement_flags = "".join(key for key in "XFU" if key in flags)
                variable = f"{phase.id}::AUiso:{index}"
                variables.append(variable)
                project.set_Controls("parmMin", 0.003, variable=variable)
                project.set_Controls("parmMax", 0.020, variable=variable)
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)
    elif args.step == "uiso_rebuild":
        if not args.phase:
            raise ValueError("uiso_rebuild needs at least one --phase")
        # Remove stale equivalences left by earlier staged light-atom releases,
        # then recreate only the common-Uiso constraints that remain active.
        project.get_Constraints("Phase")[:] = []
        selected = set(args.phase)
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
            if phase.name not in selected:
                continue
            values = [atom.uiso for atom in phase.atoms()]
            common = min(0.020, max(0.003, float(np.mean(values))))
            variables = []
            for index, atom in enumerate(phase.atoms()):
                atom.uiso = common
                flags = set(atom.refinement_flags.strip())
                flags.add("U")
                atom.refinement_flags = "".join(
                    key for key in "XFU" if key in flags
                )
                variable = f"{phase.id}::AUiso:{index}"
                variables.append(variable)
                project.set_Controls("parmMin", 0.003, variable=variable)
                project.set_Controls("parmMax", 0.020, variable=variable)
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)
    elif args.step == "uiso_fix":
        if not args.phase:
            raise ValueError("uiso_fix needs at least one --phase")
        clear_profile_flags(hist)
        freeze_calibration(hist)
        selected_ids = set()
        for name in args.phase:
            phase = project.phase(name)
            selected_ids.add(str(phase.id) + "::AUiso:")
            for atom in phase.atoms():
                atom.uiso = args.value
                atom.refinement_flags = atom.refinement_flags.replace("U", "")
        constraints = project.get_Constraints("Phase")
        constraints[:] = [
            constraint for constraint in constraints
            if not any(
                any(prefix in str(term[1]) for prefix in selected_ids)
                for term in constraint[:-3]
            )
        ]
        project.set_Frozen()
    elif args.step == "profile_basic":
        project.set_Frozen()
        hist.InstrumentParameters["X"][1] = min(
            5.8, hist.InstrumentParameters["X"][1]
        )
        for key, low, high in [
            ("U", 0.0, 40.0),
            ("W", 2.0, 40.0),
            ("X", 0.1, 6.0),
            ("SH/L", 0.005, 0.10),
        ]:
            project.set_Controls("parmMin", low, variable=f":0:{key}")
            project.set_Controls("parmMax", high, variable=f":0:{key}")
        hist.set_refinements({
            "Instrument Parameters": ["U", "W", "X", "SH/L"]
        })
    elif args.step == "size_iso":
        project.set_Frozen()
        for phase in project.phases():
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True}
            }, [hist])
            variable = f"{phase.id}:0:Size;i"
            project.set_Controls("parmMin", 0.03, variable=variable)
            project.set_Controls("parmMax", 2.0, variable=variable)
    elif args.step == "size_iso_one":
        if len(args.phase) != 1:
            raise ValueError("size_iso_one needs one --phase")
        project.set_Frozen()
        clear_profile_flags(hist)
        freeze_calibration(hist)
        phase = project.phase(args.phase[0])
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True}
        }, [hist])
        variable = f"{phase.id}:0:Size;i"
        project.set_Controls("parmMin", 0.04, variable=variable)
        project.set_Controls("parmMax", 1.5, variable=variable)
    elif args.step == "size_fix":
        if not args.phase:
            raise ValueError("size_fix needs NAME=VALUE in --phase")
        for item in args.phase:
            name, text_value = item.split("=", 1)
            phase = project.phase(name)
            value = float(text_value)
            size = phase.data["Histograms"][hist.name]["Size"]
            size[0] = "isotropic"
            size[1][0] = value
            size[2][0] = False
            project.set_Frozen(f"{phase.id}:0:Size;i", mode="remove")
        if hist.InstrumentParameters["U"][1] <= 0.001:
            hist.InstrumentParameters["U"][1] = 0.0
            hist.InstrumentParameters["U"][2] = False
            project.set_Frozen(":0:U", mode="remove")
    elif args.step == "mustrain_iso":
        project.set_Frozen()
        for phase in project.phases():
            phase.set_HAP_refinements({
                "Mustrain": {"type": "isotropic", "refine": True}
            }, [hist])
            variable = f"{phase.id}:0:Mustrain;i"
            project.set_Controls("parmMin", 1.0, variable=variable)
            project.set_Controls("parmMax", 10000.0, variable=variable)
    elif args.step == "mustrain_iso_one":
        if len(args.phase) != 1:
            raise ValueError("mustrain_iso_one needs one --phase")
        project.set_Frozen()
        clear_profile_flags(hist)
        freeze_calibration(hist)
        phase = project.phase(args.phase[0])
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        }, [hist])
        variable = f"{phase.id}:0:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 8000.0, variable=variable)
    elif args.step == "mustrain_uniaxial_one":
        if len(args.phase) != 1 or args.axis is None:
            raise ValueError(
                "mustrain_uniaxial_one needs one --phase and --axis h k l"
            )
        project.set_Frozen()
        clear_profile_flags(hist)
        freeze_calibration(hist)
        phase = project.phase(args.phase[0])
        mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
        mustrain[0] = "uniaxial"
        mustrain[1][1] = mustrain[1][0]
        mustrain[2][0] = True
        mustrain[2][1] = True
        mustrain[3] = list(args.axis)
        for suffix in ("i", "a"):
            variable = f"{phase.id}:0:Mustrain;{suffix}"
            project.set_Controls("parmMin", 300.0, variable=variable)
            project.set_Controls("parmMax", 8000.0, variable=variable)
    elif args.step == "mustrain_fix":
        if not args.phase:
            raise ValueError("mustrain_fix needs NAME=VALUE in --phase")
        for item in args.phase:
            name, text_value = item.split("=", 1)
            phase = project.phase(name)
            value = float(text_value)
            mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
            mustrain[0] = "isotropic"
            mustrain[1][0] = value
            mustrain[2][0] = False
            project.set_Frozen(f"{phase.id}:0:Mustrain;i", mode="remove")
    else:
        raise AssertionError(args.step)

    refine(project, output, args.step)


if __name__ == "__main__":
    main()
