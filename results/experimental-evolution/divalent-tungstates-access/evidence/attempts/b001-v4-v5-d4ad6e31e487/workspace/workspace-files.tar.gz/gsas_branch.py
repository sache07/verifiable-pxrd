#!/usr/bin/env python3
"""Build and refine a comparable GSAS-II branch for candidate COD phases."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def stage_summary(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "sample": {
            key: value[0] if isinstance(value, list) else value
            for key, value in hist.SampleParameters.items()
            if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.", "I(L2)/I(L1)"}
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
        }
    try:
        result["mass_fractions"] = {
            key: [value[0], value[1]] for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        result["mass_fraction_error"] = repr(exc)
    return result


def refine(
    project: G2sc.G2Project,
    label: str,
    summaries: list[dict],
    verbose: bool,
) -> None:
    project.set_Controls("cycles", 12)
    project.do_refinements([{}])
    project.save()
    summary = stage_summary(project, label)
    summaries.append(summary)
    if verbose:
        print(json.dumps(summary, indent=2, default=str), flush=True)
    else:
        print(
            f"{project.filename} {label}: Rwp={summary['Rwp_percent']:.5f}% "
            f"fractions={summary.get('mass_fractions', {})}",
            flush=True,
        )


def build_branch(
    output: Path,
    specs: list[tuple[str, str]],
    verbose: bool = False,
) -> list[dict]:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "cu_lab.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"][0] = 760.0
    hist.InstrumentParameters["U"][1] = 10.0
    hist.InstrumentParameters["W"][1] = 10.0
    hist.InstrumentParameters["X"][1] = 1.0
    hist.InstrumentParameters["SH/L"][1] = 0.03
    hist.set_refinements({
        "Background": {"type": "chebyschev-1", "refine": True, "no. coeffs": 12},
    })

    phases = []
    for name, cod_id in specs:
        phases.append(project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        ))
    project.save()

    # Keep the redundant global histogram scale fixed; phase scales carry QPA.
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Scale"][0] = 1.0
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMax", 1.0e5, variable=f"{phase.id}:0:Scale")

        # Keep topology tests inside a broad but physical metric neighborhood.
        # Without this a rejected phase can numerically remove itself by driving
        # its cell volume to zero rather than letting its scale collapse.
        cell = phase.get_cell()
        metric = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(metric):
            span = max(0.25 * abs(value), 0.003)
            project.set_Controls(
                "parmMin", value - span, variable=f"{phase.id}::A{index}"
            )
            project.set_Controls(
                "parmMax", value + span, variable=f"{phase.id}::A{index}"
            )

    summaries: list[dict] = []
    refine(project, "scales_background", summaries, verbose)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells_shift", summaries, verbose)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "profile", summaries, verbose)

    # One additional cycle after all basic variables have settled.
    refine(project, "basic_checkpoint", summaries, verbose)
    project.save()
    return summaries


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "phase",
        nargs="+",
        help="phase specification Name=COD_ID",
    )
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()
    specs = []
    for item in args.phase:
        name, cod_id = item.split("=", 1)
        specs.append((name, cod_id))
    summaries = build_branch(args.output.resolve(), specs, args.verbose)
    summary_path = args.output.with_suffix(".json")
    summary_path.write_text(json.dumps(summaries, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
