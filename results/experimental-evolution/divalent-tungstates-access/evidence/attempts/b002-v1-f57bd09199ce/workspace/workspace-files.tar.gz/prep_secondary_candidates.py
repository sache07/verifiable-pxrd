#!/usr/bin/env python3
"""Enumerate and geometry-screen plausible secondary-phase structures."""

from __future__ import annotations

import gzip
import json
import warnings
from pathlib import Path

from pymatgen.core import Composition
from pymatgen.io.cif import CifParser


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01"
)


def cod_path(cod_id: str) -> Path:
    return RESOURCE / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def load(path: Path):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return CifParser(path, occupancy_tolerance=10).parse_structures(primitive=False)[0]


def minimum_distance(structure):
    return min(
        float(neighbor.nn_distance)
        for i, site in enumerate(structure)
        for neighbor in structure.get_neighbors(site, 4.0)
        if neighbor.index != i
    )


def main():
    with gzip.open(RESOURCE / "index.json.gz", "rt") as stream:
        index = json.load(stream)
    rows = []
    for key, target, family in [
        ("O-Zn", "ZnO", "residual precursor ZnO"),
        ("O-W", "WO3", "residual precursor WO3"),
    ]:
        target_comp = Composition(target).reduced_composition
        for formula, cod_id, reported_sg, r_factor in index[key]:
            try:
                if Composition(formula).reduced_composition != target_comp:
                    continue
            except Exception:
                continue
            path = cod_path(cod_id)
            try:
                structure = load(path)
                min_distance = minimum_distance(structure)
                sg_symbol, sg_number = structure.get_space_group_info(symprec=1e-3)
                status = "pending" if min_distance >= 0.8 else "rejected"
                reason = "" if status == "pending" else "hard interatomic contact below 0.8 A"
                cell = {
                    "a": structure.lattice.a,
                    "b": structure.lattice.b,
                    "c": structure.lattice.c,
                    "alpha": structure.lattice.alpha,
                    "beta": structure.lattice.beta,
                    "gamma": structure.lattice.gamma,
                    "volume": structure.volume,
                }
            except Exception as exc:
                min_distance = None
                sg_symbol, sg_number, cell = None, None, None
                status, reason = "unknown", f"parse/screen failed: {exc}"
            rows.append(
                {
                    "id": f"{target.lower()}_{cod_id}",
                    "formula": target,
                    "family": family,
                    "model_basis": "published",
                    "parent_cod": cod_id,
                    "cif_path": str(path),
                    "reported_space_group_number": reported_sg,
                    "space_group": sg_symbol,
                    "space_group_number": sg_number,
                    "reported_r_factor": r_factor,
                    "cell": cell,
                    "minimum_interatomic_distance_A": min_distance,
                    "status": status,
                    "reason": reason,
                }
            )

    for candidate in json.loads((ROOT / "candidates" / "manifest.json").read_text()):
        if candidate["id"] == "znwo4_wolframite_como":
            continue
        rows.append(
            {
                "id": candidate["id"],
                "formula": "ZnWO4",
                "family": "alternate ZnWO4 polymorph/topology",
                "model_basis": "analogue_derived",
                "parent_cod": candidate["cod_id"],
                "cif_path": str(ROOT / candidate["cif_path"]),
                "space_group": candidate["space_group"],
                "space_group_number": candidate["space_group_number"],
                "cell": candidate["cell"],
                "minimum_interatomic_distance_A": candidate["minimum_interatomic_distance_A"],
                "status": "pending",
                "reason": "",
            }
        )
    (ROOT / "secondary_candidates.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
