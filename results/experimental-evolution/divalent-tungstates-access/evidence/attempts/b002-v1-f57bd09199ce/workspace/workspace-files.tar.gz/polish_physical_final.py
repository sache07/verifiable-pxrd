#!/usr/bin/env python3
"""Final stable polish with the selected inventory and coordinates frozen."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "physical_final_refinement" / "iteration_6.gpx"
OUT = ROOT / "physical_final_refinement"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def snapshot(project, iteration):
    hist = project.histogram(0)
    weighted = []
    details = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted.append((phase.name, phase.data["General"]["Mass"] * hap["Scale"][0]))
        details[phase.name] = {
            "cell": plain(phase.get_cell()),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
            "atoms": [
                {"label": a.label, "element": a.element, "coordinates": list(a.coordinates)}
                for a in phase.atoms()
            ],
        }
    total = sum(v for _, v in weighted)
    return {
        "iteration": iteration,
        "residuals": plain(hist.residuals),
        "fractions": {n: float(v / total) for n, v in weighted},
        "phases": details,
        "vary_list": plain(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def validate(project):
    hist = project.histogram(0)
    expected = ["ZnWO4_wolframite", "wo3_2311041", "zno_9004178"]
    active = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap.get("Use", True) and hap["Scale"][0] > 0:
            active.append(phase.name)
        cell = phase.get_cell()
        if not all(np.isfinite(list(cell.values()))):
            raise RuntimeError(f"nonfinite cell for {phase.name}")
        if hap["Scale"][0] <= 0 or hap["Size"][1][0] <= 0 or hap["Mustrain"][1][0] < 0:
            raise RuntimeError(f"nonphysical HAP term for {phase.name}")
        if phase.ShortDistances(useAll=True):
            raise RuntimeError(f"hard contact for {phase.name}: {phase.ShortDistances(useAll=True)}")
    if active != expected:
        raise RuntimeError(f"wrong active inventory: {active}")
    if hist.SampleParameters["Scale"] != [1.0, False]:
        raise RuntimeError("histogram scale is not fixed at one")


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT / "polish_working.gpx"))
    hist = project.histogram(0)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.set_Controls("cycles", 25)
    project.save()
    history = []
    for iteration in range(1, 7):
        project.refine(makeBack=False)
        validate(project)
        entry = snapshot(project, iteration)
        history.append(entry)
        project.save()
        shutil.copy2(project.filename, OUT / f"polished_{iteration}.gpx")
        (OUT / "polish_history.json").write_text(json.dumps(history, indent=2) + "\n")
        print(iteration, entry["residuals"].get("wR"), entry["fractions"], flush=True)


if __name__ == "__main__":
    main()
