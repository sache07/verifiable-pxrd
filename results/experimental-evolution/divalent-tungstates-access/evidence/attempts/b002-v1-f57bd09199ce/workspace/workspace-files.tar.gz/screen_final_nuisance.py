#!/usr/bin/env python3
"""Screen physically bounded zero/displacement variants from one stable model."""

from __future__ import annotations

import json
import os
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "physical_final_refinement" / "polished_5.gpx"
OUT = ROOT / "nuisance_trials"

BRANCHES = {
    "fixed_zero025": {"zero": 0.25, "refine_zero": False, "shift": 0.0, "refine_shift": False},
    "zero_only": {"zero": 0.20, "refine_zero": True, "shift": 0.0, "refine_shift": False},
    "shift_at_zero0": {"zero": 0.0, "refine_zero": False, "shift": 0.0, "refine_shift": True},
    "shift_at_zero025": {"zero": 0.25, "refine_zero": False, "shift": 0.0, "refine_shift": True},
    "zero_and_shift": {"zero": 0.0, "refine_zero": True, "shift": 0.0, "refine_shift": True},
    "shift_at_inherited_zero": {"zero": 0.4031606844327575, "refine_zero": False, "shift": 0.0, "refine_shift": True},
}


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def correlations(project):
    data = project.data.get("Covariance", {}).get("data", {})
    variables = list(data.get("varyList", []))
    matrix = np.asarray(data.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(variables), len(variables)) or not len(variables):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = sigma[:, None] * sigma[None, :]
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    relevant = [i for i, name in enumerate(variables) if "Zero" in str(name) or "Shift" in str(name)]
    rows = []
    for i in relevant:
        for j in range(len(variables)):
            if i == j:
                continue
            rows.append(
                {
                    "a": str(variables[i]),
                    "b": str(variables[j]),
                    "correlation": float(corr[i, j]),
                }
            )
    return sorted(rows, key=lambda row: abs(row["correlation"]), reverse=True)[:12]


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(exist_ok=True)
    results = []
    selected = os.environ.get("NUISANCE_BRANCH")
    branches = {selected: BRANCHES[selected]} if selected else BRANCHES
    for name, settings in branches.items():
        folder = OUT / name
        folder.mkdir(exist_ok=True)
        project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(folder / "working.gpx"))
        hist = project.histogram(0)
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = " "
        hist.InstrumentParameters["Zero"][1] = settings["zero"]
        hist.InstrumentParameters["Zero"][2] = settings["refine_zero"]
        hist.SampleParameters["Shift"] = [settings["shift"], settings["refine_shift"]]
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")
        project.set_Controls("cycles", 30)
        project.save()
        passes = []
        for iteration in range(1, 4):
            project.refine(makeBack=False)
            hist = project.histogram(0)
            passes.append(
                {
                    "iteration": iteration,
                    "rwp_percent": float(hist.residuals["wR"]),
                    "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
                    "shift_um": float(hist.SampleParameters["Shift"][0]),
                    "correlations": correlations(project),
                }
            )
            project.save()
        project.save(folder / "retained.gpx")
        result = {"branch": name, "settings": settings, "passes": passes}
        (folder / "result.json").write_text(json.dumps(plain(result), indent=2) + "\n")
        results.append(result)
        last = passes[-1]
        print(name, last["rwp_percent"], last["zero_deg"], last["shift_um"], flush=True)
    (OUT / "summary.json").write_text(json.dumps(plain(results), indent=2) + "\n")


if __name__ == "__main__":
    main()
