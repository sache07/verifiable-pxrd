#!/usr/bin/env python3
"""Re-optimize the closed three-phase model with physical ZnWO4 oxygen geometry."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "three_phase_refinement" / "iteration_2.gpx"
PARENT = ROOT / "wolframite_refinement" / "stage3_isotropic_profile.gpx"
PARENT_ZNO = ROOT / "tertiary_trials" / "zno_9004178" / "stage3_candidate_profile.gpx"
OUT = ROOT / "physical_final_refinement"
PRIMARY = "ZnWO4_wolframite"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def state(project, iteration):
    hist = project.histogram(0)
    masses = []
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append((phase.name, phase.data["General"]["Mass"] * hap["Scale"][0]))
        phases[phase.name] = {
            "cell": plain(phase.get_cell()),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    total = sum(value for _, value in masses)
    return {
        "iteration": iteration,
        "residuals": plain(hist.residuals),
        "fractions": {name: float(value / total) for name, value in masses},
        "phases": phases,
        "vary_list": plain(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def validate(project):
    hist = project.histogram(0)
    expected = ["ZnWO4_wolframite", "wo3_2311041", "zno_9004178"]
    active = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap.get("Use", True) and hap["Scale"][0] > 0:
            active.append(phase.name)
        cell = phase.get_cell()
        if not all(np.isfinite(list(cell.values()))):
            raise RuntimeError(f"nonfinite cell for {phase.name}")
        if min(cell["length_a"], cell["length_b"], cell["length_c"], cell["volume"]) <= 0:
            raise RuntimeError(f"invalid cell for {phase.name}")
        if hap["Scale"][0] <= 0 or hap["Size"][1][0] <= 0 or hap["Mustrain"][1][0] < 0:
            raise RuntimeError(f"nonphysical HAP term for {phase.name}")
        if phase.ShortDistances(useAll=True):
            raise RuntimeError(f"hard contact for {phase.name}: {phase.ShortDistances(useAll=True)}")
    if active != expected:
        raise RuntimeError(f"wrong active inventory: {active}")
    if hist.SampleParameters["Scale"] != [1.0, False]:
        raise RuntimeError("histogram scale is not fixed at one")


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUT / "working.gpx"))
    parent_project = G2.G2Project(gpxfile=str(PARENT))
    parent_zno_project = G2.G2Project(gpxfile=str(PARENT_ZNO))
    parent_coords = {
        atom.label: list(atom.coordinates)
        for atom in parent_project.phase(PRIMARY).atoms()
        if atom.element == "O"
    }
    parent_zno_coords = {
        atom.label: list(atom.coordinates)
        for atom in parent_zno_project.phase("zno_9004178").atoms()
    }

    hist = project.histogram(0)
    primary = project.phase(PRIMARY)
    for atom in primary.atoms():
        if atom.element == "O":
            atom.coordinates = parent_coords[atom.label]
            atom.refinement_flags = " "
        else:
            atom.refinement_flags = "X"

    # Preserve the deliberately simple final nuisance model.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]}
    )
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {"Scale": True, "Size": {"type": "isotropic", "refine": True}},
            histograms=[hist],
        )
        phase.clear_HAP_refinements({"Mustrain": True}, histograms=[hist])
        phase.data["Histograms"][hist.name]["Mustrain"][1][0] = 0.0
        project.set_Controls("parmMin", 1e-12, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMin", 0.02, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:Size;i")

    for atom in project.phase("wo3_2311041").atoms():
        atom.refinement_flags = "X" if atom.element == "W" else " "
    for atom in project.phase("zno_9004178").atoms():
        atom.coordinates = parent_zno_coords[atom.label]
        atom.refinement_flags = " "
    primary.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    project.set_Controls("parmMin", 0.5, variable="0:0:MD")
    project.set_Controls("parmMax", 2.0, variable="0:0:MD")
    project.set_Controls("cycles", 25)

    history = []
    project.save()
    for iteration in range(1, 7):
        project.refine(makeBack=False)
        validate(project)
        entry = state(project, iteration)
        history.append(entry)
        project.save()
        shutil.copy2(project.filename, OUT / f"iteration_{iteration}.gpx")
        (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")
        print(iteration, entry["residuals"].get("wR"), entry["fractions"], flush=True)


if __name__ == "__main__":
    main()
