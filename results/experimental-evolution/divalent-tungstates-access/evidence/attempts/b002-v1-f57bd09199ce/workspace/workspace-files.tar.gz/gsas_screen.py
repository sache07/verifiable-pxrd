#!/usr/bin/env python3
"""Common-setting GSAS-II screen for prototype candidates.

Run with the GSAS-II Python interpreter. Each branch starts from the same
histogram/instrument/background setup and contains exactly one named phase.
"""

from __future__ import annotations

import json
import math
import shutil
import sys
import traceback
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "trials"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def background_coefficients(ncoeff=6):
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    baseline = percentile_filter(y, percentile=15, size=401, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoeff - 1).tolist()


def snapshot(project, hist, phase, stage):
    hap = phase.data["Histograms"][hist.name]
    inst = hist.InstrumentParameters
    return {
        "stage": stage,
        "phase_name": phase.name,
        "active_phases": [
            p.name
            for p in project.phases()
            if p.data.get("Histograms", {}).get(hist.name, {}).get("Use", True)
            and p.data.get("Histograms", {}).get(hist.name, {}).get("Scale", [0])[0] != 0
        ],
        "residuals": plain(hist.residuals),
        "cell": plain(phase.get_cell()),
        "scale": float(hap["Scale"][0]),
        "scale_refined": bool(hap["Scale"][1]),
        "size": plain(hap["Size"]),
        "mustrain": plain(hap["Mustrain"]),
        "instrument": {
            k: plain(inst[k])
            for k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if k in inst
        },
        "background": plain(hist.Background),
    }


def physical_branch_ok(phase, hist):
    cell = phase.get_cell()
    vals = [cell[k] for k in ("length_a", "length_b", "length_c", "volume")]
    if not all(np.isfinite(vals)) or min(vals) <= 0:
        return False, "nonfinite or nonpositive cell"
    if min(vals[:3]) < 2.0 or max(vals[:3]) > 40 or not 20 < vals[3] < 5000:
        return False, "cell left broad physical bounds"
    scale = phase.data["Histograms"][hist.name]["Scale"][0]
    if not np.isfinite(scale) or scale <= 0:
        return False, "nonpositive or nonfinite phase scale"
    return True, None


def refine_stage(project, hist, phase, stage, folder, history):
    active = [
        p.name
        for p in project.phases()
        if hist.name in p.data.get("Histograms", {})
        and p.data["Histograms"][hist.name].get("Use", True)
        and p.data["Histograms"][hist.name]["Scale"][0] != 0
    ]
    if active != [phase.name]:
        raise RuntimeError(f"wrong active phase inventory before {stage}: {active}")
    if phase.data["Histograms"][hist.name]["Scale"][0] <= 0:
        raise RuntimeError(f"nonpositive initialized scale before {stage}")
    project.refine(makeBack=False)
    project.save(folder / f"{stage}.gpx")
    history.append(snapshot(project, hist, phase, stage))
    ok, reason = physical_branch_ok(phase, hist)
    if not ok:
        raise RuntimeError(reason)


def run_candidate(record):
    cid = record["id"]
    folder = OUT / cid
    folder.mkdir(parents=True, exist_ok=True)
    history = []
    project = G2.G2Project(newgpx=str(folder / "trial.gpx"))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    hist.set_refinements({"Limits": [9.90343322, 100.09455322]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": background_coefficients(6),
                "refine": True,
            }
        }
    )
    phase = project.add_phase(
        str(ROOT / record["cif_path"]),
        phasename=cid,
        histograms=[hist],
        fmthint="CIF",
    )
    if project.phase(cid).name != cid:
        raise RuntimeError("phase identity lookup failed")
    phase = project.phase(cid)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [10.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("cycles", 8)
    project.save()
    history.append(snapshot(project, hist, phase, "initialized"))

    # Common nuisance sequence: scale/background, then positions/cell, then
    # isotropic profile terms. Atomic coordinates remain fixed in this screen.
    refine_stage(project, hist, phase, "stage1_scale_background", folder, history)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_stage(project, hist, phase, "stage2_zero_cell", folder, history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_stage(project, hist, phase, "stage3_instrument_profile", folder, history)

    phase.set_HAP_refinements(
        {
            "Mustrain": {"type": "isotropic", "refine": True},
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
        },
        histograms=[hist],
    )
    refine_stage(project, hist, phase, "stage4_specimen_profile", folder, history)
    project.save(folder / "trial.gpx")
    return {
        "id": cid,
        "status": "tested",
        "history": history,
        "final": history[-1],
        "project": str((folder / "trial.gpx").relative_to(ROOT)),
    }


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(exist_ok=True)
    records = json.loads((ROOT / "candidates" / "manifest.json").read_text())
    selected = set(sys.argv[1:])
    if selected:
        records = [r for r in records if r["id"] in selected]
    for record in records:
        try:
            result = run_candidate(record)
        except Exception as exc:
            folder = OUT / record["id"]
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "error.log").write_text(traceback.format_exc())
            result = {
                "id": record["id"],
                "status": "unknown",
                "reason": str(exc),
            }
        folder = OUT / record["id"]
        (folder / "result.json").write_text(json.dumps(result, indent=2) + "\n")
        results = []
        for path in sorted(OUT.glob("*/result.json")):
            results.append(json.loads(path.read_text()))
        (OUT / "screen_summary.json").write_text(json.dumps(results, indent=2) + "\n")
        final = result.get("final", {})
        print(
            record["id"],
            result["status"],
            "wR=",
            final.get("residuals", {}).get("wR"),
            "cell=",
            final.get("cell"),
            flush=True,
        )


if __name__ == "__main__":
    main()
