#!/usr/bin/env python3
"""Continue the retained simple wolframite branch to numerical convergence."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "wolframite_refinement" / "stage5_polarization.gpx"
DEST = ROOT / "wolframite_refinement" / "converged_simple.gpx"
PHASE = "ZnWO4_wolframite"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def state(project, round_number):
    hist = project.histogram(0)
    phase = project.phase(PHASE)
    hap = phase.data["Histograms"][hist.name]
    return {
        "round": round_number,
        "residuals": plain(hist.residuals),
        "cell": plain(phase.get_cell()),
        "instrument": plain(hist.InstrumentParameters),
        "sample": plain(hist.SampleParameters),
        "scale": plain(hap["Scale"]),
        "size": plain(hap["Size"]),
        "mustrain": plain(hap["Mustrain"]),
        "background": plain(hist.Background),
        "atoms": [
            {
                "label": a.label,
                "element": a.element,
                "coordinates": list(a.coordinates),
                "occupancy": a.occupancy,
                "uiso": a.uiso,
                "refinement_flags": a.refinement_flags,
            }
            for a in phase.atoms()
        ],
        "vary_list": plain(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SRC), newgpx=str(DEST))
    hist = project.histogram(0)
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    project.set_Controls("cycles", 25)
    history = [state(project, 0)]
    for round_number in range(1, 6):
        project.refine(makeBack=False)
        entry = state(project, round_number)
        history.append(entry)
        print(
            round_number,
            entry["residuals"].get("wR"),
            entry["cell"],
            entry["size"][1][0],
            entry["mustrain"][1][0],
            flush=True,
        )
        project.save()
        shutil.copy2(DEST, DEST.with_name(f"converged_round_{round_number}.gpx"))
        (DEST.with_suffix(".json")).write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
