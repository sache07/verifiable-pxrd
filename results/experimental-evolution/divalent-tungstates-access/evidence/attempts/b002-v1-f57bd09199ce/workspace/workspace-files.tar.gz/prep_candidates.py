#!/usr/bin/env python3
"""Build target-composition ZnWO4 prototype candidates from frozen COD parents."""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Element
from pymatgen.io.cif import CifParser, CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path(__file__).resolve().parent
COD = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)
OUT = ROOT / "candidates"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


CANDIDATES = [
    {
        "id": "znwo4_wolframite_como",
        "cod_id": "7205001",
        "prototype": "wolframite P2/c",
        "mapping": {"Co": "Zn", "Mo": "W"},
        "substitutions": 2,
    },
    {
        "id": "znwo4_wolframite_mnre",
        "cod_id": "2100243",
        "prototype": "wolframite P2/c",
        "mapping": {"Mn": "Zn", "Re": "W"},
        "substitutions": 2,
    },
    {
        "id": "znwo4_wolframite_scnb",
        "cod_id": "5910338",
        "prototype": "wolframite P2/c",
        "mapping": {"Sc": "Zn", "Nb": "W"},
        "substitutions": 2,
    },
    {
        "id": "znwo4_triclinic_znmo",
        "cod_id": "1528282",
        "prototype": "alpha-ZnMoO4 P-1",
        "mapping": {"Mo": "W"},
        "substitutions": 1,
    },
    {
        "id": "znwo4_scheelite_cdw",
        "cod_id": "1549132",
        "prototype": "scheelite I41/a",
        "mapping": {"Cd": "Zn"},
        "substitutions": 1,
    },
    {
        "id": "znwo4_fergusonite_caw",
        "cod_id": "1546035",
        "prototype": "fergusonite I2/a",
        "mapping": {"Ca": "Zn"},
        "substitutions": 1,
    },
]


def load_structure(path: Path):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        return CifParser(path, occupancy_tolerance=10).parse_structures(
            primitive=False
        )[0]


def nearest_distances(structure):
    distances = []
    for i, site in enumerate(structure):
        nn = structure.get_neighbors(site, 4.0)
        distances.extend(float(n.nn_distance) for n in nn if n.index != i)
    return min(distances) if distances else float("nan")


def main():
    OUT.mkdir(exist_ok=True)
    records = []
    for spec in CANDIDATES:
        parent_path = cod_path(spec["cod_id"])
        structure = load_structure(parent_path)
        structure.replace_species(
            {Element(src): Element(dst) for src, dst in spec["mapping"].items()}
        )
        if spec["id"] == "znwo4_fergusonite_caw":
            # The source is reported in I2/a axes. Convert to the standard C2/c
            # conventional setting so GSAS-II can map the symmetry operators.
            structure = SpacegroupAnalyzer(structure, symprec=1e-3).get_conventional_standard_structure(
                international_monoclinic=True
            )
        # Write symmetry-reduced target models while retaining the parent lattice
        # and topology. GSAS-II will refine independent cell terms later.
        out_path = OUT / f"{spec['id']}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(out_path)
        check = load_structure(out_path)
        sga = SpacegroupAnalyzer(check, symprec=1e-3)
        comp = check.composition.reduced_formula
        if check.composition.reduced_composition.get_el_amt_dict() != {
            "Zn": 1.0,
            "W": 1.0,
            "O": 4.0,
        }:
            raise ValueError(f"Unexpected composition for {spec['id']}: {comp}")
        rec = {
            **spec,
            "parent_path": str(parent_path),
            "cif_path": str(out_path.relative_to(ROOT)),
            "formula": comp,
            "space_group": sga.get_space_group_symbol(),
            "space_group_number": sga.get_space_group_number(),
            "sites_conventional": len(check),
            "cell": {
                "a": check.lattice.a,
                "b": check.lattice.b,
                "c": check.lattice.c,
                "alpha": check.lattice.alpha,
                "beta": check.lattice.beta,
                "gamma": check.lattice.gamma,
                "volume": check.volume,
            },
            "minimum_interatomic_distance_A": nearest_distances(check),
        }
        records.append(rec)

    (OUT / "manifest.json").write_text(json.dumps(records, indent=2) + "\n")

    pattern = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(pattern[:, 1], 1.0))
    np.savetxt(
        ROOT / "pattern.xye",
        np.column_stack([pattern, sigma]),
        fmt=["%.8f", "%.8f", "%.8f"],
        header="two_theta_deg intensity sigma",
        comments="# ",
    )


if __name__ == "__main__":
    main()
