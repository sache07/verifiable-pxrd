#!/usr/bin/env python3
"""Screen secondary phases as additions to a frozen ZnWO4 project."""

from __future__ import annotations

import json
import os
import shutil
import sys
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = Path(
    os.environ.get(
        "PXRD_BASE_GPX",
        str(ROOT / "wolframite_refinement" / "converged_simple.gpx"),
    )
)
OUT = Path(os.environ.get("PXRD_TRIAL_DIR", str(ROOT / "secondary_trials")))
PRIMARY = "ZnWO4_wolframite"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def clear_base_flags(project, hist, primary):
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            ]
        }
    )
    sample_keys = [
        k
        for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        if k in hist.SampleParameters and isinstance(hist.SampleParameters[k], list)
    ]
    hist.clear_refinements({"Sample Parameters": sample_keys})
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True},
            histograms=[hist],
        )
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])
    hist.set_refinements({"Background": True})


def fractions(project, hist):
    masses = []
    for phase in project.phases():
        hap = phase.data.get("Histograms", {}).get(hist.name)
        if hap is None or not hap.get("Use", True) or hap["Scale"][0] <= 0:
            continue
        masses.append((phase.name, float(phase.data["General"]["Mass"] * hap["Scale"][0])))
    total = sum(mass for _, mass in masses)
    return {name: mass / total for name, mass in masses}


def state(project, candidate, stage, initial_cell):
    hist = project.histogram(0)
    primary = project.phase(PRIMARY)
    phase = project.phase(candidate)
    hap = phase.data["Histograms"][hist.name]
    return {
        "stage": stage,
        "residuals": plain(hist.residuals),
        "fractions": fractions(project, hist),
        "primary_scale": float(primary.data["Histograms"][hist.name]["Scale"][0]),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_cell": plain(phase.get_cell()),
        "initial_cell": initial_cell,
        "candidate_size": plain(hap["Size"]),
        "candidate_mustrain": plain(hap["Mustrain"]),
        "background": plain(hist.Background),
        "active_phases": [
            p.name
            for p in project.phases()
            if hist.name in p.data.get("Histograms", {})
            and p.data["Histograms"][hist.name].get("Use", True)
            and p.data["Histograms"][hist.name]["Scale"][0] != 0
        ],
    }


def check(project, candidate, initial_cell, profile=False):
    hist = project.histogram(0)
    phase = project.phase(candidate)
    hap = phase.data["Histograms"][hist.name]
    cell = phase.get_cell()
    vals = list(cell.values())
    if not all(np.isfinite(vals)) or min(cell["length_a"], cell["length_b"], cell["length_c"], cell["volume"]) <= 0:
        raise RuntimeError("invalid candidate cell")
    if not np.isfinite(hap["Scale"][0]) or hap["Scale"][0] <= 0:
        raise RuntimeError("nonpositive candidate scale")
    if hist.SampleParameters["Scale"] != [1.0, False]:
        raise RuntimeError("histogram scale correlation re-enabled")
    ratio = cell["volume"] / initial_cell["volume"]
    if not 0.55 < ratio < 1.8:
        raise RuntimeError(f"candidate cell volume diverged: ratio={ratio}")
    if profile:
        if hap["Size"][1][0] <= 0 or hap["Mustrain"][1][0] < 0:
            raise RuntimeError("nonphysical candidate profile")


def save_snapshot(project, folder, name):
    project.save()
    shutil.copy2(project.filename, folder / f"{name}.gpx")


def run(record):
    cid = record["id"]
    folder = OUT / cid
    folder.mkdir(parents=True, exist_ok=True)
    working = folder / "working.gpx"
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(working))
    hist = project.histogram(0)
    primary = project.phase(PRIMARY)
    clear_base_flags(project, hist, primary)
    baseline_rwp = float(hist.residuals["wR"])
    phase = project.add_phase(
        record["cif_path"],
        phasename=cid,
        histograms=[hist],
        fmthint="CIF",
    )
    phase = project.phase(cid)
    for atom in phase.atoms():
        # ADPs are nuisance values for this topology screen. Some COD entries
        # contain anisotropic tensors; normalize all trial atoms to Uiso=0.01.
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.01
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [10.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    initial_cell = plain(phase.get_cell())
    project.save()
    p_id = phase.id
    project.set_Controls("parmMin", 1e-12, variable=f"{p_id}:0:Scale")
    project.set_Controls("parmMin", 0.02, variable=f"{p_id}:0:Size;i")
    project.set_Controls("parmMax", 5.0, variable=f"{p_id}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{p_id}:0:Mustrain;i")
    project.set_Controls("parmMax", 12000.0, variable=f"{p_id}:0:Mustrain;i")
    history = [state(project, cid, "initialized", initial_cell)]

    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    check(project, cid, initial_cell)
    history.append(state(project, cid, "stage1_scales_background", initial_cell))
    save_snapshot(project, folder, "stage1_scales_background")

    phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 10)
    project.refine(makeBack=False)
    check(project, cid, initial_cell)
    history.append(state(project, cid, "stage2_candidate_cell", initial_cell))
    save_snapshot(project, folder, "stage2_candidate_cell")

    stage2 = history[-1]
    improvement = baseline_rwp - float(stage2["residuals"]["wR"])
    retained = "stage2_candidate_cell"
    profile_error = None
    if improvement > 0.20 and stage2["fractions"].get(cid, 0.0) > 0.001:
        try:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "value": 0.20, "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                histograms=[hist],
            )
            project.set_Controls("cycles", 10)
            project.refine(makeBack=False)
            check(project, cid, initial_cell, profile=True)
            history.append(state(project, cid, "stage3_candidate_profile", initial_cell))
            save_snapshot(project, folder, "stage3_candidate_profile")
            retained = "stage3_candidate_profile"
        except Exception as exc:
            profile_error = str(exc)
            # Explicit rollback to the last physical project.
            project = G2.G2Project(
                gpxfile=str(folder / "stage2_candidate_cell.gpx"),
                newgpx=str(working),
            )

    final = next(item for item in history if item["stage"] == retained)
    final_rwp = float(final["residuals"]["wR"])
    fraction = float(final["fractions"].get(cid, 0.0))
    delta = baseline_rwp - final_rwp
    if fraction < 0.001 or delta < 0.05:
        status = "rejected"
        reason = "scale contribution collapsed or profile improvement was negligible"
    elif delta >= 0.5:
        status = "nominated"
        reason = "stable positive contribution under common nuisance settings"
    else:
        status = "tested"
        reason = "small stable contribution; retain only if residual mapping supports it"
    project.save(folder / "retained.gpx")
    return {
        "id": cid,
        "formula": record["formula"],
        "status": status,
        "reason": reason,
        "retained_stage": retained,
        "profile_extension_error": profile_error,
        "baseline_rwp_percent": baseline_rwp,
        "retained_rwp_percent": final_rwp,
        "rwp_improvement_percent_points": delta,
        "candidate_weight_fraction": fraction,
        "history": history,
        "project": str((folder / "retained.gpx").relative_to(ROOT)),
    }


def write_summary():
    results = []
    for path in sorted(OUT.glob("*/result.json")):
        results.append(json.loads(path.read_text()))
    (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(exist_ok=True)
    records = json.loads((ROOT / "secondary_candidates.json").read_text())
    selected = set(sys.argv[1:])
    records = [
        r
        for r in records
        if r["status"] == "pending" and (not selected or r["id"] in selected)
    ]
    for record in records:
        try:
            result = run(record)
        except Exception as exc:
            folder = OUT / record["id"]
            folder.mkdir(parents=True, exist_ok=True)
            (folder / "error.log").write_text(traceback.format_exc())
            result = {
                "id": record["id"],
                "formula": record["formula"],
                "status": "unknown",
                "reason": str(exc),
            }
        folder = OUT / record["id"]
        (folder / "result.json").write_text(json.dumps(result, indent=2) + "\n")
        write_summary()
        print(
            result["id"],
            result["status"],
            result.get("retained_rwp_percent"),
            result.get("candidate_weight_fraction"),
            result.get("reason"),
            flush=True,
        )


if __name__ == "__main__":
    main()
