#!/usr/bin/env python3
"""Jointly converge the closed ZnWO4 + WO3 + ZnO inventory."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "tertiary_trials" / "zno_9004178" / "retained.gpx"
OUT = ROOT / "three_phase_refinement"
NAMES = ["ZnWO4_wolframite", "wo3_2311041", "zno_9004178"]


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def state(project, iteration):
    hist = project.histogram(0)
    values = []
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = phase.data["General"]["Mass"] * hap["Scale"][0]
        values.append((phase.name, mass))
        phases[phase.name] = {
            "cell": plain(phase.get_cell()),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
            "short_distances": plain(phase.ShortDistances(useAll=True)),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "occupancy": atom.occupancy,
                    "adp_flag": atom.adp_flag,
                    "adp": plain(atom.ADP),
                    "refinement_flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    total = sum(value for _, value in values)
    return {
        "iteration": iteration,
        "residuals": plain(hist.residuals),
        "fractions": {name: float(value / total) for name, value in values},
        "instrument": plain(hist.InstrumentParameters),
        "sample": plain(hist.SampleParameters),
        "background": plain(hist.Background),
        "phases": phases,
        "vary_list": plain(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def check(project):
    hist = project.histogram(0)
    if hist.SampleParameters["Scale"] != [1.0, False]:
        raise RuntimeError("histogram scale correlation re-enabled")
    for phase in project.phases():
        cell = phase.get_cell()
        hap = phase.data["Histograms"][hist.name]
        if not all(np.isfinite(list(cell.values()))) or min(cell["length_a"], cell["length_b"], cell["length_c"], cell["volume"]) <= 0:
            raise RuntimeError(f"invalid cell for {phase.name}")
        if hap["Scale"][0] <= 0 or hap["Size"][1][0] <= 0 or hap["Mustrain"][1][0] < 0:
            raise RuntimeError(f"nonphysical scale/profile for {phase.name}")
        if phase.ShortDistances(useAll=True):
            raise RuntimeError(f"hard contact in {phase.name}: {phase.ShortDistances(useAll=True)}")


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(exist_ok=True)
    dest = OUT / "working.gpx"
    project = G2.G2Project(gpxfile=str(SRC), newgpx=str(dest))
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]}
    )
    hist.set_refinements({"Background": True})

    primary, wo3, zno = [project.phase(name) for name in NAMES]
    for phase in [primary, wo3, zno]:
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        phase.clear_HAP_refinements({"Mustrain": True}, histograms=[hist])
        phase.set_HAP_refinements(
            {"Scale": True, "Size": {"type": "isotropic", "refine": True}},
            histograms=[hist],
        )
        phase.set_refinements({"Cell": True})
        project.set_Controls("parmMin", 1e-12, variable=f"{phase.id}:0:Scale")
        project.set_Controls("parmMin", 0.02, variable=f"{phase.id}:0:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{phase.id}:0:Size;i")

    for atom in primary.atoms():
        atom.refinement_flags = "X"
    primary.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    project.set_Controls("parmMin", 0.5, variable="0:0:MD")
    project.set_Controls("parmMax", 2.0, variable="0:0:MD")
    for atom in wo3.atoms():
        atom.refinement_flags = "X" if atom.element == "W" else " "
    for atom in zno.atoms():
        atom.refinement_flags = "X" if atom.element == "O" else " "

    project.set_Controls("cycles", 25)
    project.save()
    history = [state(project, 0)]
    for iteration in range(1, 7):
        project.refine(makeBack=False)
        check(project)
        entry = state(project, iteration)
        history.append(entry)
        project.save()
        shutil.copy2(dest, OUT / f"iteration_{iteration}.gpx")
        (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")
        print(iteration, entry["residuals"].get("wR"), entry["fractions"], flush=True)
    project.save(OUT / "retained.gpx")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        OUT.mkdir(exist_ok=True)
        (OUT / "error.log").write_text(traceback.format_exc())
        raise
