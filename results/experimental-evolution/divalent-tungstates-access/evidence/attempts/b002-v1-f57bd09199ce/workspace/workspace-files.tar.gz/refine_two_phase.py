#!/usr/bin/env python3
"""Stage the retained ZnWO4 + WO3 model after texture selection."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "texture_trials" / "axis_111" / "retained.gpx"
OUT = ROOT / "two_phase_refinement"
PRIMARY = "ZnWO4_wolframite"
SECONDARY = "wo3_2311041"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def fractions(project, hist):
    vals = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        vals.append((phase.name, phase.data["General"]["Mass"] * hap["Scale"][0]))
    total = sum(value for _, value in vals)
    return {name: float(value / total) for name, value in vals}


def state(project, stage):
    hist = project.histogram(0)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": plain(phase.get_cell()),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
            "short_distances": plain(phase.ShortDistances(useAll=True)),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "occupancy": atom.occupancy,
                    "adp_flag": atom.adp_flag,
                    "adp": plain(atom.ADP),
                    "refinement_flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    return {
        "stage": stage,
        "residuals": plain(hist.residuals),
        "fractions": fractions(project, hist),
        "instrument": plain(hist.InstrumentParameters),
        "sample": plain(hist.SampleParameters),
        "background": plain(hist.Background),
        "phases": phases,
        "vary_list": plain(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def check(project):
    hist = project.histogram(0)
    if hist.SampleParameters["Scale"] != [1.0, False]:
        raise RuntimeError("histogram scale correlation re-enabled")
    for phase in project.phases():
        cell = phase.get_cell()
        if not all(np.isfinite(list(cell.values()))) or min(cell["length_a"], cell["length_b"], cell["length_c"], cell["volume"]) <= 0:
            raise RuntimeError(f"invalid cell for {phase.name}")
        hap = phase.data["Histograms"][hist.name]
        if hap["Scale"][0] <= 0 or hap["Size"][1][0] <= 0 or hap["Mustrain"][1][0] < 0:
            raise RuntimeError(f"nonphysical scale/profile for {phase.name}")
        if phase.ShortDistances(useAll=True):
            raise RuntimeError(f"hard contact in {phase.name}: {phase.ShortDistances(useAll=True)}")


def snapshot(project, stage, history):
    check(project)
    entry = state(project, stage)
    history.append(entry)
    project.save()
    shutil.copy2(project.filename, OUT / f"{stage}.gpx")
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(stage, entry["residuals"].get("wR"), entry["fractions"], flush=True)


def refine(project, stage, history, cycles=20):
    hist = project.histogram(0)
    active = [
        phase.name
        for phase in project.phases()
        if hist.name in phase.data.get("Histograms", {})
        and phase.data["Histograms"][hist.name].get("Use", True)
        and phase.data["Histograms"][hist.name]["Scale"][0] > 0
    ]
    if active != [PRIMARY, SECONDARY]:
        raise RuntimeError(f"wrong active inventory before {stage}: {active}")
    project.set_Controls("cycles", cycles)
    project.refine(makeBack=False)
    snapshot(project, stage, history)


def set_atom_flags(phase, elements, flag):
    for atom in phase.atoms():
        if atom.element in elements:
            atom.refinement_flags = flag


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUT / "working.gpx"))
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    primary = project.phase(PRIMARY)
    secondary = project.phase(SECONDARY)
    project.save()

    # Broad physical limits for profile and the retained texture term.
    for p_id in [primary.id, secondary.id]:
        project.set_Controls("parmMin", 1e-12, variable=f"{p_id}:0:Scale")
        project.set_Controls("parmMin", 0.02, variable=f"{p_id}:0:Size;i")
        project.set_Controls("parmMax", 5.0, variable=f"{p_id}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{p_id}:0:Mustrain;i")
        project.set_Controls("parmMax", 12000.0, variable=f"{p_id}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.5, variable="0:0:MD")
    project.set_Controls("parmMax", 2.0, variable="0:0:MD")
    project.set_Controls("parmMin", 0.4, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    history = []
    snapshot(project, "stage0_texture_base", history)

    primary.set_refinements({"Cell": True})
    set_atom_flags(primary, {"Zn", "W"}, "X")
    refine(project, "stage1_primary_heavy_cell", history)

    set_atom_flags(primary, {"O"}, "X")
    refine(project, "stage2_primary_oxygen", history)

    secondary.set_refinements({"Cell": True})
    set_atom_flags(secondary, {"W"}, "X")
    refine(project, "stage3_secondary_heavy_cell", history)

    primary.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        histograms=[hist],
    )
    secondary.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        histograms=[hist],
    )
    refine(project, "stage4_isotropic_profiles", history)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "stage5_polarization", history)

    project.save(OUT / "retained.gpx")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        OUT.mkdir(exist_ok=True)
        (OUT / "error.log").write_text(traceback.format_exc())
        raise
