#!/usr/bin/env python3
"""Compare one-at-a-time March-Dollase axes on the retained two-phase fit."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "secondary_trials" / "wo3_2311041" / "retained.gpx"
OUT = ROOT / "texture_trials"
PRIMARY = "ZnWO4_wolframite"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def clear_flags(project):
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "Zero",
                "Polariz.",
                "U",
                "V",
                "W",
                "X",
                "Y",
                "Z",
                "SH/L",
            ]
        }
    )
    sample_keys = [
        k
        for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        if k in hist.SampleParameters and isinstance(hist.SampleParameters[k], list)
    ]
    hist.clear_refinements({"Sample Parameters": sample_keys})
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True},
            histograms=[hist],
        )
        phase.set_HAP_refinements({"Scale": True}, histograms=[hist])


def fractions(project):
    hist = project.histogram(0)
    vals = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        vals.append((phase.name, phase.data["General"]["Mass"] * hap["Scale"][0]))
    total = sum(v for _, v in vals)
    return {name: float(v / total) for name, v in vals}


def run(axis):
    tag = "axis_" + "".join(str(v) for v in axis)
    folder = OUT / tag
    folder.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(folder / "working.gpx"))
    clear_flags(project)
    hist = project.histogram(0)
    phase = project.phase(PRIMARY)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    project.save()
    project.set_Controls("parmMin", 0.5, variable="0:0:MD")
    project.set_Controls("parmMax", 2.0, variable="0:0:MD")
    project.set_Controls("cycles", 20)
    project.refine(makeBack=False)
    project.refine(makeBack=False)
    project.save()
    shutil.copy2(project.filename, folder / "retained.gpx")
    result = {
        "axis": list(axis),
        "rwp_percent": float(hist.residuals["wR"]),
        "r_factors": plain(hist.residuals),
        "md_ratio": float(hap["Pref.Ori."][1]),
        "fractions": fractions(project),
        "background": plain(hist.Background),
        "project": str((folder / "retained.gpx").relative_to(ROOT)),
    }
    (folder / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(exist_ok=True)
    results = []
    for axis in AXES:
        result = run(axis)
        results.append(result)
        (OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
        print(axis, result["rwp_percent"], result["md_ratio"], result["fractions"], flush=True)


if __name__ == "__main__":
    main()
