#!/usr/bin/env python3
"""Export the independently replayed final observed/calculated/difference profile."""

from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
with np.load(ROOT / ".tmp" / "replay_final" / "prediction.npz", allow_pickle=False) as replay:
    x = replay["x"]
    observed = replay["observed"]
    calculated = replay["predicted"]

public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
    raise RuntimeError("replayed grid/observations do not match the supplied pattern")
if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
    raise RuntimeError("invalid replayed calculated profile")

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, observed - calculated)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
)
