#!/usr/bin/env python3
"""Build and stage a physically bounded ZnWO4 wolframite refinement."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
OUT = ROOT / "wolframite_refinement"
PHASE_NAME = "ZnWO4_wolframite"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def initial_background(ncoeff=6):
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    baseline = percentile_filter(y, percentile=15, size=401, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    return np.polynomial.chebyshev.chebfit(t, baseline, ncoeff - 1).tolist()


def record(project, stage):
    hist = project.histogram(0)
    phase = project.phase(PHASE_NAME)
    hap = phase.data["Histograms"][hist.name]
    atoms = []
    for atom in phase.atoms():
        atoms.append(
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "occupancy": atom.occupancy,
                "uiso": atom.uiso,
                "refinement_flags": atom.refinement_flags,
            }
        )
    return {
        "stage": stage,
        "residuals": plain(hist.residuals),
        "cell": plain(phase.get_cell()),
        "hap_scale": plain(hap["Scale"]),
        "histogram_scale": plain(hist.SampleParameters["Scale"]),
        "instrument": plain(hist.InstrumentParameters),
        "sample": plain(hist.SampleParameters),
        "background": plain(hist.Background),
        "size": plain(hap["Size"]),
        "mustrain": plain(hap["Mustrain"]),
        "preferred_orientation": plain(hap["Pref.Ori."]),
        "atoms": atoms,
        "vary_list": plain(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def physical_ok(project):
    hist = project.histogram(0)
    phase = project.phase(PHASE_NAME)
    hap = phase.data["Histograms"][hist.name]
    cell = phase.get_cell()
    if not all(np.isfinite(list(cell.values()))) or min(cell["length_a"], cell["length_b"], cell["length_c"], cell["volume"]) <= 0:
        raise RuntimeError("invalid cell")
    if hap["Scale"][0] <= 0 or not np.isfinite(hap["Scale"][0]):
        raise RuntimeError("invalid phase scale")
    if hist.SampleParameters["Scale"][0] != 1.0 or hist.SampleParameters["Scale"][1]:
        raise RuntimeError("histogram scale correlation was re-enabled")
    size = hap["Size"][1][0]
    strain = hap["Mustrain"][1][0]
    if size <= 0 or strain < 0:
        raise RuntimeError(f"nonphysical profile values size={size}, strain={strain}")
    inst = hist.InstrumentParameters
    for key in ("W", "SH/L"):
        if inst[key][1] <= 0:
            raise RuntimeError(f"nonphysical instrument parameter {key}={inst[key][1]}")


def snapshot(project, stage, history):
    physical_ok(project)
    state = record(project, stage)
    history.append(state)
    project.save()
    shutil.copy2(project.filename, OUT / f"{stage}.gpx")
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(stage, "wR=", state["residuals"].get("wR"), "cell=", state["cell"], flush=True)


def refine(project, stage, history, cycles=10):
    project.set_Controls("cycles", cycles)
    hist = project.histogram(0)
    phase = project.phase(PHASE_NAME)
    active = [
        p.name
        for p in project.phases()
        if hist.name in p.data.get("Histograms", {})
        and p.data["Histograms"][hist.name].get("Use", True)
        and p.data["Histograms"][hist.name]["Scale"][0] != 0
    ]
    if active != [PHASE_NAME]:
        raise RuntimeError(f"wrong active phase inventory: {active}")
    if phase.data["Histograms"][hist.name]["Scale"][0] <= 0:
        raise RuntimeError("nonpositive phase scale before refinement")
    project.refine(makeBack=False)
    snapshot(project, stage, history)


def bound(project, variable, low=None, high=None):
    if low is not None:
        project.set_Controls("parmMin", float(low), variable=variable)
    if high is not None:
        project.set_Controls("parmMax", float(high), variable=variable)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(exist_ok=True)
    working = OUT / "working.gpx"
    project = G2.G2Project(newgpx=str(working))
    hist = project.add_powder_histogram(
        str(ROOT / "pattern.xye"),
        str(ROOT / "instrument.instprm"),
        fmthint="xye",
    )
    hist.set_refinements({"Limits": [9.90343322, 100.09455322]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": initial_background(6),
                "refine": True,
            }
        }
    )
    phase = project.add_phase(
        str(ROOT / "candidates" / "znwo4_wolframite_como.cif"),
        phasename=PHASE_NAME,
        histograms=[hist],
        fmthint="CIF",
    )
    phase = project.phase(PHASE_NAME)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [100.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.20
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 2000.0
    hap["Mustrain"][2] = [False, False, False]
    project.save()

    # Keep only one absolute scale variable and impose broad physical bounds.
    bound(project, "0:0:Scale", 1e-8, None)
    bound(project, ":0:Zero", -1.0, 1.0)
    bound(project, ":0:W", 0.01, 100.0)
    bound(project, ":0:SH/L", 0.001, 0.2)
    bound(project, "0:0:Size;i", 0.02, 5.0)
    bound(project, "0:0:Mustrain;i", 0.0, 12000.0)
    bound(project, ":0:Shift", -1000.0, 1000.0)
    bound(project, ":0:Polariz.", 0.4, 1.0)

    history = []
    snapshot(project, "stage0_initialized", history)

    refine(project, "stage1_scale_background", history, cycles=10)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "stage2_zero_cell", history, cycles=12)

    # Decompose the total width into a fixed plausible U/X instrument term and
    # positive specimen size/strain terms; W and axial divergence remain free.
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.20, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        histograms=[hist],
    )
    refine(project, "stage3_isotropic_profile", history, cycles=12)

    # Symmetry restrictions in P2/c leave only the allowed coordinate terms.
    phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "stage4_coordinates", history, cycles=15)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "stage5_polarization", history, cycles=10)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "stage6_shift", history, cycles=12)

    project.save(OUT / "best_simple.gpx")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        OUT.mkdir(exist_ok=True)
        (OUT / "error.log").write_text(traceback.format_exc())
        raise
