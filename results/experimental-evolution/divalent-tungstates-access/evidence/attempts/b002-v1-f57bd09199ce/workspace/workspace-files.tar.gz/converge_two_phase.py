#!/usr/bin/env python3
"""Converge the retained two-phase stage after rejecting boundary polarization."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SRC = ROOT / "two_phase_refinement" / "stage4_isotropic_profiles.gpx"
DEST = ROOT / "two_phase_refinement" / "converged.gpx"


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def state(project, iteration):
    hist = project.histogram(0)
    phase_rows = {}
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append((phase.name, mass))
        phase_rows[phase.name] = {
            "cell": plain(phase.get_cell()),
            "scale": plain(hap["Scale"]),
            "size": plain(hap["Size"]),
            "mustrain": plain(hap["Mustrain"]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                    "refinement_flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    total = sum(value for _, value in masses)
    return {
        "iteration": iteration,
        "residuals": plain(hist.residuals),
        "fractions": {name: float(value / total) for name, value in masses},
        "instrument": plain(hist.InstrumentParameters),
        "background": plain(hist.Background),
        "phases": phase_rows,
        "vary_list": plain(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SRC), newgpx=str(DEST))
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    # Both isotropic strain terms refined to the physical zero boundary; remove
    # them and retain only the supported finite size contribution.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 0.0
        phase.clear_HAP_refinements({"Mustrain": True}, histograms=[hist])
    project.set_Controls("cycles", 25)
    project.save()
    history = [state(project, 0)]
    for iteration in range(1, 6):
        project.refine(makeBack=False)
        entry = state(project, iteration)
        history.append(entry)
        project.save()
        shutil.copy2(DEST, DEST.with_name(f"converged_{iteration}.gpx"))
        DEST.with_suffix(".json").write_text(json.dumps(history, indent=2) + "\n")
        print(iteration, entry["residuals"].get("wR"), entry["fractions"], flush=True)


if __name__ == "__main__":
    main()
