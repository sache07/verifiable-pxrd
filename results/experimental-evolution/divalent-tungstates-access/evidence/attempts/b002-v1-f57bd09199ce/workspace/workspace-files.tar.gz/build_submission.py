#!/usr/bin/env python3
"""Freeze the selected GSAS-II model and export its atomic phase CIFs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "physical_final_refinement" / "polished_5.gpx"
FINAL = ROOT / "final.gpx"
EXPORTS = {
    "ZnWO4_wolframite": ROOT / "ZnWO4_wolframite.cif",
    "wo3_2311041": ROOT / "WO3_monoclinic.cif",
    "zno_9004178": ROOT / "ZnO_wurtzite.cif",
}


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def main():
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    hist = project.histogram(0)
    if len(project.histograms()) != 1:
        raise RuntimeError("final project must contain exactly one powder histogram")
    if set(p.name for p in project.phases()) != set(EXPORTS):
        raise RuntimeError("unexpected final phase inventory")

    # Export from saved atom values, not covariance shifts, matching replay.
    project.data["Covariance"]["data"] = {}
    project.save()
    masses = {}
    phase_state = {}
    for name, path in EXPORTS.items():
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        if not hap.get("Use", True) or hap["Scale"][0] <= 0:
            raise RuntimeError(f"inactive/nonpositive final phase: {name}")
        phase.export_CIF(str(path))
        masses[name] = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        phase_state[name] = {
            "cif": path.name,
            "cell": plain(phase.get_cell()),
            "scale": float(hap["Scale"][0]),
            "cell_mass": float(phase.data["General"]["Mass"]),
            "size_micrometre": float(hap["Size"][1][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "preferred_orientation": plain(hap["Pref.Ori."]),
        }
    total = sum(masses.values())
    state = {
        "source_project": str(SOURCE.relative_to(ROOT)),
        "final_project": FINAL.name,
        "histogram": hist.name,
        "saved_residuals": plain(hist.residuals),
        "instrument": plain(hist.InstrumentParameters),
        "sample": plain(hist.SampleParameters),
        "background": plain(hist.Background),
        "phases": phase_state,
        "weight_fractions": {name: value / total for name, value in masses.items()},
    }
    (ROOT / "submission_state.json").write_text(json.dumps(state, indent=2) + "\n")
    print(json.dumps(state["weight_fractions"], indent=2))


if __name__ == "__main__":
    main()
