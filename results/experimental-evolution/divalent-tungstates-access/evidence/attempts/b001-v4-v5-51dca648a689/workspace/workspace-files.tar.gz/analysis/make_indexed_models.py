#!/usr/bin/env python3
"""Generate chemistry variants of a P2/c parent in the indexed cell."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
TARGET = Lattice.monoclinic(4.329141153, 4.446796793, 6.204113130, 92.13528779)


def source(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cod_id")
    parser.add_argument("output")
    parser.add_argument("--all-mn", action="store_true")
    parser.add_argument("--oxygen-occupancy", type=float, default=1.0)
    args = parser.parse_args()

    parent = Structure.from_file(source(args.cod_id))
    species = []
    for site in parent:
        replacement: dict[str, float] = {}
        for specie, occupancy in site.species.items():
            symbol = specie.symbol
            if symbol == "O":
                occupancy *= args.oxygen_occupancy
            elif args.all_mn or symbol != "W":
                symbol = "Mn"
            replacement[symbol] = replacement.get(symbol, 0.0) + occupancy
        species.append(replacement)
    model = Structure(TARGET, species, parent.frac_coords)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(model, symprec=1e-3, refine_struct=False).write_file(output)
    provenance = {
        "model_basis": "indexed_cell_analogue_derived",
        "parent_cod_id": args.cod_id,
        "parent_path": str(source(args.cod_id)),
        "parent_composition": parent.composition.formula,
        "derived_composition": model.composition.formula,
        "indexed_cell": list(TARGET.parameters),
        "all_cations_replaced_by_Mn": args.all_mn,
        "oxygen_site_occupancy": args.oxygen_occupancy,
    }
    output.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(output, provenance)


if __name__ == "__main__":
    main()
