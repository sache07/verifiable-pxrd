#!/usr/bin/env python3
"""Extract residual-phase intensities in the accepted indexed cell."""

from __future__ import annotations

import argparse
import csv
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIstrMain as G2main


ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("name")
    parser.add_argument("--cycles", type=int, default=30)
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "lebail" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    gpx = outdir / "working.gpx"
    project = G2sc.G2Project(args.input_gpx, newgpx=str(gpx))
    candidate = project.phases()[-1]
    candidate.set_refinements({"LeBail": True})
    project.save()

    ok, result = G2main.DoLeBail(str(gpx), cycles=args.cycles)
    if not ok:
        raise RuntimeError(result)
    project = G2sc.G2Project(str(gpx))
    hist = project.histogram(0)
    candidate = project.phases()[-1]
    reflections = hist.data["Reflection Lists"][candidate.name]["RefList"]
    with (outdir / "reflections.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "h", "k", "l", "multiplicity", "d_A", "two_theta_deg",
            "sigma", "gamma", "Fobs_sq", "Fcalc_sq", "phase_deg",
            "intensity_correction", "alpha", "beta", "wave",
        ])
        writer.writerows(reflections)
    shutil.copy2(gpx, outdir / "lebail.gpx")
    (outdir / "statistics.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
