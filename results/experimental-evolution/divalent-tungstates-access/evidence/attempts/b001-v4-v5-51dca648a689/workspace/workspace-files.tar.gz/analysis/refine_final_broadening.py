#!/usr/bin/env python3
"""Stage isotropic broadening for the two minor phases in the final model."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def stats(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (wt > 0)
    rwp = 100 * math.sqrt(np.sum(wt[use] * (yo[use] - yc[use]) ** 2) /
                          np.sum(wt[use] * yo[use] ** 2))
    return {
        "Rwp_percent": float(rwp),
        "project_wR_percent": float(hist.get_wR()),
        "mass_fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "broadening": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
    }


def snapshot(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    (outdir / f"{label}.json").write_text(json.dumps(stats(project), indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("name")
    parser.add_argument("--dense-mode", choices=["size", "strain", "both"], default="both")
    parser.add_argument("--skip-mno", action="store_true")
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "final_profile" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    hist = project.histogram(0)
    project.set_Controls("cycles", 10)
    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.set_refinements({"Background": True, "Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})

    dense = next(phase for phase in project.phases() if "dense_mnwo4" in phase.name)
    dense_terms = {}
    if args.dense_mode in {"size", "both"}:
        dense_terms["Size"] = {"type": "isotropic", "refine": True}
    if args.dense_mode in {"strain", "both"}:
        dense_terms["Mustrain"] = {"type": "isotropic", "refine": True}
    dense.set_HAP_refinements(dense_terms)
    project.refine()
    snapshot(project, outdir, "step01_dense_broadening")

    if args.skip_mno:
        print(json.dumps(stats(project), indent=2))
        return

    dense.clear_HAP_refinements({"Size": True, "Mustrain": True})
    mno = next(phase for phase in project.phases() if phase.name == "closure_4117966")
    mno.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    project.refine()
    snapshot(project, outdir, "step02_mno_broadening")
    print(json.dumps(stats(project), indent=2))


if __name__ == "__main__":
    main()
