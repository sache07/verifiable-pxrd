#!/usr/bin/env python3
"""Fast whole-profile screening against the positive GSAS-II residual."""

from __future__ import annotations

import gzip
import json
import math
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
LIB = INDEX.parent / "cif"
PROFILE = Path("analysis/trials/mnwo4_wo3_1528915/profile.dat")
LAM1 = 1.540598
LAM2 = 1.544426
SHIFT_MICRON = -658.0
RADIUS_MM = 200.0


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substitute_mn(structure: Structure) -> Structure:
    species = []
    for site in structure:
        repl = {}
        for sp, occ in site.species.items():
            symbol = sp.symbol
            symbol = symbol if symbol in {"O", "W"} else "Mn"
            repl[symbol] = repl.get(symbol, 0.0) + occ
        species.append(repl)
    return Structure(structure.lattice, species, structure.frac_coords)


def shifted_pos(d: np.ndarray, wavelength: float, scale: float) -> np.ndarray:
    arg = wavelength / (2.0 * d * scale)
    pos = np.full_like(arg, np.nan)
    valid = arg < 1.0
    pos[valid] = np.degrees(2.0 * np.arcsin(arg[valid]))
    const = 0.09 / (math.pi * RADIUS_MM)
    pos[valid] -= 4.0 * const * SHIFT_MICRON * np.cos(np.radians(pos[valid] / 2.0))
    return pos


def stick_profile(x: np.ndarray, pos: np.ndarray, inten: np.ndarray) -> np.ndarray:
    """Deposit integrated line intensity onto the uniform measured grid."""
    q = np.zeros_like(x)
    step = x[1] - x[0]
    fidx = (pos - x[0]) / step
    good = np.isfinite(fidx) & (fidx >= 0) & (fidx < len(x) - 1)
    left = np.floor(fidx[good]).astype(int)
    frac = fidx[good] - left
    np.add.at(q, left, inten[good] * (1.0 - frac))
    np.add.at(q, left + 1, inten[good] * frac)
    return q


def main() -> None:
    x, obs, calc, bkg, resid = np.loadtxt(PROFILE).T
    use = (x >= 15) & (x <= 82)
    x, obs, resid = x[use], obs[use], resid[use]
    wt = 1.0 / np.maximum(obs, 1.0)
    base_chi = float(np.sum(wt * resid**2))

    with gzip.open(INDEX, "rt") as f:
        index = json.load(f)
    records = {}
    for key, rows in index.items():
        elems = set(key.split("-"))
        take = key in {"Mn-O", "O-W", "Mn-O-W"}
        take |= "O" in elems and "W" in elems and len(elems - {"O", "W"}) <= 1
        if not take:
            continue
        for formula, cod_id, sg, r in rows:
            records[cod_id] = (key, formula, sg)

    out = []
    calc_xrd = XRDCalculator(wavelength=LAM1)
    for cod_id, (key, formula, sg) in records.items():
        try:
            original = Structure.from_file(cif_path(cod_id))
            structure = substitute_mn(original) if ("W" in key and key != "O-W") else original
            pat = calc_xrd.get_pattern(structure, two_theta_range=(7, 110), scaled=False)
        except Exception:
            continue
        p1 = np.asarray(pat.x, float)
        inten = np.asarray(pat.y, float)
        d = LAM1 / (2.0 * np.sin(np.radians(p1 / 2.0)))
        best = None
        for scale in np.linspace(0.88, 1.12, 61):
            pos1 = shifted_pos(d, LAM1, scale)
            pos2 = shifted_pos(d, LAM2, scale)
            pos = np.r_[pos1, pos2]
            ii = np.r_[inten, 0.5 * inten]
            sticks = stick_profile(x, pos, ii)
            for fwhm in (0.22, 0.35, 0.55, 0.75):
                q = gaussian_filter1d(
                    sticks, (fwhm / 2.354820045) / (x[1] - x[0]),
                    mode="constant", truncate=4.0,
                )
                den = float(np.sum(wt * q * q))
                if den <= 0:
                    continue
                coeff = max(0.0, float(np.sum(wt * resid * q)) / den)
                chi = float(np.sum(wt * (resid - coeff * q) ** 2))
                if best is None or chi < best[0]:
                    best = (chi, scale, fwhm, coeff)
        if best is None:
            continue
        chi, scale, fwhm, coeff = best
        out.append(
            {
                "id": cod_id,
                "key": key,
                "index_formula": formula,
                "composition": original.composition.reduced_formula,
                "spacegroup": original.get_space_group_info(),
                "cell": original.lattice.parameters,
                "improvement_fraction": (base_chi - chi) / base_chi,
                "chi": chi,
                "scale": scale,
                "fwhm": fwhm,
                "coefficient": coeff,
            }
        )
    out.sort(key=lambda z: z["chi"])
    Path("analysis/profile_screen.json").write_text(json.dumps(out, indent=2) + "\n")
    print("base_chi", base_chi, "candidates", len(out))
    for r in out[:100]:
        print(
            f"improve={100*r['improvement_fraction']:6.2f}% scale={r['scale']:.4f} "
            f"fwhm={r['fwhm']:.2f} {r['id']} {r['key']} {r['composition']} "
            f"{r['spacegroup']} cell={tuple(round(v,3) for v in r['cell'][:6])}"
        )


if __name__ == "__main__":
    main()
