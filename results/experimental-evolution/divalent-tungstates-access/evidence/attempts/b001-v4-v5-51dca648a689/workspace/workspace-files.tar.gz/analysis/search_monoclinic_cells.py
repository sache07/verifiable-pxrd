#!/usr/bin/env python3
"""Rank frozen-index monoclinic cells against the indexed residual cell.

This deliberately reads only CIF cell scalars.  It avoids structure parsing,
which is unnecessary for a metric search and fails for some historical COD
records with unusual occupancies.
"""

from __future__ import annotations

import gzip
import itertools
import json
import math
import re
from pathlib import Path


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
LIB = INDEX.parent / "cif"
TARGET = (4.329141153, 4.446796793, 6.204113130)
TARGET_BETA = 92.13528779


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def scalar(text: str, key: str) -> float:
    match = re.search(rf"(?mi)^\s*{re.escape(key)}\s+['\"]?([^\s'\"]+)", text)
    if match is None:
        raise ValueError(key)
    value = re.sub(r"\([^)]*\)$", "", match.group(1))
    return float(value)


def metric_score(lengths: tuple[float, float, float], beta: float) -> tuple[float, tuple[int, ...], float]:
    best = (math.inf, (0, 1, 2), 1.0)
    for perm in itertools.permutations(range(3)):
        vals = [lengths[i] for i in perm]
        # Permit an overall scale because substituted parents can differ in
        # ionic radius, but penalize anisotropic distortion and large scaling.
        scale = math.exp(sum(math.log(TARGET[i] / vals[i]) for i in range(3)) / 3)
        shape = sum(math.log(TARGET[i] / (vals[i] * scale)) ** 2 for i in range(3)) / 3
        angle = min(abs(beta - TARGET_BETA), abs((180 - beta) - TARGET_BETA)) / 20
        score = math.sqrt(shape + angle * angle) + 0.20 * abs(math.log(scale))
        if score < best[0]:
            best = (score, perm, scale)
    return best


def main() -> None:
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    rows = []
    seen = set()
    for key, entries in index.items():
        for formula, cod_id, sg_number, quality in entries:
            if sg_number not in range(3, 16) or cod_id in seen:
                continue
            seen.add(cod_id)
            try:
                text = cif_path(cod_id).read_text(errors="replace")
                lengths = tuple(scalar(text, key) for key in (
                    "_cell_length_a", "_cell_length_b", "_cell_length_c"
                ))
                beta = scalar(text, "_cell_angle_beta")
                score, perm, scale = metric_score(lengths, beta)
                volume = (
                    lengths[0] * lengths[1] * lengths[2]
                    * math.sin(math.radians(beta))
                )
                rows.append({
                    "score": score, "id": cod_id, "key": key,
                    "formula": formula, "sg": sg_number, "quality": quality,
                    "cell": [*lengths, beta], "volume": volume,
                    "permutation": perm, "isotropic_scale": scale,
                })
            except (OSError, ValueError, OverflowError):
                continue
    rows.sort(key=lambda row: row["score"])
    Path("analysis/monoclinic_cell_ranking.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )
    for row in rows[:250]:
        print(
            f"{row['score']:.5f} {row['id']} SG{row['sg']} {row['key']} "
            f"{row['formula']} cell={tuple(round(x, 5) for x in row['cell'])} "
            f"V={row['volume']:.3f} perm={row['permutation']} "
            f"scale={row['isotropic_scale']:.4f}"
        )


if __name__ == "__main__":
    main()
