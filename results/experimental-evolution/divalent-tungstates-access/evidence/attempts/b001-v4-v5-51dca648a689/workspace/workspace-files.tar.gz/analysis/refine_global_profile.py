#!/usr/bin/env python3
"""Test supported global profile terms from a fixed structural checkpoint."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def stats(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (wt > 0)
    chi = float(np.sum(wt[use] * (yo[use] - yc[use]) ** 2))
    rwp = 100.0 * math.sqrt(chi / np.sum(wt[use] * yo[use] ** 2))
    rp = 100.0 * np.sum(np.abs(yo[use] - yc[use])) / np.sum(np.abs(yo[use]))
    return {
        "Rwp_percent": float(rwp),
        "Rp_percent": float(rp),
        "chi_squared": chi,
        "project_wR_percent": float(hist.get_wR()),
        "mass_fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.SampleParameters,
        "broadening": {
            phase.name: {
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
    }


def snapshot(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    (outdir / f"{label}.json").write_text(json.dumps(stats(project), indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("name")
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "profile_refinements" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    hist = project.histogram(0)
    project.set_Controls("cycles", 8)
    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.set_refinements({"Background": True, "Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})

    # Lorentzian width is independent of the Gaussian terms already used.
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMax", 20.0, ":0:X")
    hist.set_refinements({"Instrument Parameters": ["X"]})
    project.refine()
    snapshot(project, outdir, "step01_X")

    # Revisit the Caglioti terms with broad but still laboratory-scale bounds.
    hist.clear_refinements({"Instrument Parameters": ["X"]})
    project.set_Controls("parmMin", 0.0, ":0:U")
    project.set_Controls("parmMax", 200.0, ":0:U")
    project.set_Controls("parmMin", -200.0, ":0:V")
    project.set_Controls("parmMax", 200.0, ":0:V")
    project.set_Controls("parmMin", 0.1, ":0:W")
    project.set_Controls("parmMax", 200.0, ":0:W")
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    project.refine()
    snapshot(project, outdir, "step02_UVW")

    # Axial divergence affects low-angle asymmetry and is tested last.
    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W"]})
    project.set_Controls("parmMin", 0.001, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.refine()
    snapshot(project, outdir, "step03_SHL")
    print(json.dumps(stats(project), indent=2))


if __name__ == "__main__":
    main()
