#!/usr/bin/env python3
"""Create Mn-substituted W/O analogues from frozen COD parents."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def source(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cod_id")
    ap.add_argument("output")
    args = ap.parse_args()
    structure = Structure.from_file(source(args.cod_id))
    before = structure.composition.formula
    for i, site in enumerate(structure):
        repl = {}
        for sp, occ in site.species.items():
            symbol = sp.symbol
            symbol = symbol if symbol in {"O", "W"} else "Mn"
            repl[symbol] = repl.get(symbol, 0.0) + occ
        structure.replace(i, repl)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(output)
    provenance = {
        "model_basis": "analogue_derived",
        "parent_cod_id": args.cod_id,
        "parent_path": str(source(args.cod_id)),
        "parent_composition": before,
        "derived_composition": structure.composition.formula,
        "transformation": "All non-O/W species replaced site-for-site by Mn; parent coordinates and cell retained as refinement start.",
    }
    output.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(output, provenance)


if __name__ == "__main__":
    main()
