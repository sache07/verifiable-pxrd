#!/usr/bin/env python3
"""Screen P2/c oxide coordinate topologies in the indexed residual cell."""

from __future__ import annotations

import gzip
import json
import math
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from scipy.ndimage import gaussian_filter1d


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
LIB = INDEX.parent / "cif"
PROFILE = Path("analysis/trials/mnwo4_wo3_1528915/profile.dat")
TARGET = Lattice.monoclinic(4.329141153, 4.446796793, 6.204113130, 92.13528779)
LAM1 = 1.540598
LAM2 = 1.544426
SHIFT_MICRON = -658.0
RADIUS_MM = 200.0
EXCLUDED = {"H", "C", "N", "F", "Cl", "Br", "I", "S", "Se", "P"}


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substitute(structure: Structure, mode: str) -> Structure:
    species = []
    for site in structure:
        replacement: dict[str, float] = {}
        for specie, occupancy in site.species.items():
            symbol = specie.symbol
            if symbol != "O":
                symbol = "W" if mode == "mn_w_oxide" and symbol == "W" else "Mn"
            replacement[symbol] = replacement.get(symbol, 0.0) + occupancy
        species.append(replacement)
    return Structure(TARGET, species, structure.frac_coords)


def shifted_pos(d: np.ndarray, wavelength: float) -> np.ndarray:
    arg = wavelength / (2.0 * d)
    pos = np.full_like(arg, np.nan)
    valid = arg < 1.0
    pos[valid] = np.degrees(2.0 * np.arcsin(arg[valid]))
    const = 0.09 / (math.pi * RADIUS_MM)
    pos[valid] -= 4.0 * const * SHIFT_MICRON * np.cos(np.radians(pos[valid] / 2.0))
    return pos


def stick_profile(x: np.ndarray, pos: np.ndarray, intensity: np.ndarray) -> np.ndarray:
    result = np.zeros_like(x)
    fractional = (pos - x[0]) / (x[1] - x[0])
    valid = np.isfinite(fractional) & (fractional >= 0) & (fractional < len(x) - 1)
    left = np.floor(fractional[valid]).astype(int)
    fraction = fractional[valid] - left
    np.add.at(result, left, intensity[valid] * (1.0 - fraction))
    np.add.at(result, left + 1, intensity[valid] * fraction)
    return result


def main() -> None:
    x, observed, calculated, background, residual = np.loadtxt(PROFILE).T
    use = (x >= 15.0) & (x <= 90.0)
    x, observed, residual = x[use], observed[use], residual[use]
    weight = 1.0 / np.maximum(observed, 1.0)
    base_chi = float(np.sum(weight * residual**2))

    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    records = {}
    for key, rows in index.items():
        elements = set(key.split("-"))
        if "O" not in elements or elements & EXCLUDED or len(elements - {"O"}) > 3:
            continue
        for formula, cod_id, space_group, quality in rows:
            if space_group == 13:
                records[cod_id] = (key, formula, quality)

    calculator = XRDCalculator(wavelength=LAM1)
    results = []
    warnings.filterwarnings("ignore")
    for cod_id, (key, formula, quality) in records.items():
        try:
            parent = Structure.from_file(cif_path(cod_id))
            if len(parent) > 100:
                continue
            modes = ["mn_oxide"]
            if "W" in {element.symbol for element in parent.composition.elements}:
                modes.append("mn_w_oxide")
            for mode in modes:
                trial = substitute(parent, mode)
                pattern = calculator.get_pattern(trial, two_theta_range=(8, 105), scaled=False)
                pos1 = np.asarray(pattern.x, float)
                intensity = np.asarray(pattern.y, float)
                d = LAM1 / (2.0 * np.sin(np.radians(pos1 / 2.0)))
                positions = np.r_[shifted_pos(d, LAM1), shifted_pos(d, LAM2)]
                intensities = np.r_[intensity, 0.5 * intensity]
                sticks = stick_profile(x, positions, intensities)
                best = None
                for fwhm in (0.10, 0.14, 0.18, 0.24, 0.32, 0.45):
                    profile = gaussian_filter1d(
                        sticks, (fwhm / 2.354820045) / (x[1] - x[0]),
                        mode="constant", truncate=4.0,
                    )
                    denominator = float(np.sum(weight * profile * profile))
                    if denominator <= 0:
                        continue
                    scale = max(0.0, float(np.sum(weight * residual * profile)) / denominator)
                    chi = float(np.sum(weight * (residual - scale * profile) ** 2))
                    if best is None or chi < best[0]:
                        best = (chi, fwhm, scale)
                if best is None:
                    continue
                chi, fwhm, scale = best
                results.append({
                    "id": cod_id, "key": key, "formula": formula, "quality": quality,
                    "parent_composition": parent.composition.reduced_formula,
                    "parent_cell": parent.lattice.parameters,
                    "parent_sites": len(parent), "mode": mode,
                    "trial_composition": trial.composition.reduced_formula,
                    "chi": chi, "improvement_fraction": (base_chi - chi) / base_chi,
                    "fwhm": fwhm, "scale": scale,
                })
        except Exception:
            continue
    results.sort(key=lambda result: result["chi"])
    Path("analysis/p2c_parent_screen.json").write_text(json.dumps(results, indent=2) + "\n")
    print("base_chi", base_chi, "parents", len(records), "trials", len(results))
    for result in results[:120]:
        print(
            f"improve={100*result['improvement_fraction']:6.2f}% "
            f"fwhm={result['fwhm']:.2f} {result['id']} {result['mode']} "
            f"{result['key']} {result['parent_composition']} -> {result['trial_composition']} "
            f"sites={result['parent_sites']}"
        )


if __name__ == "__main__":
    main()
