#!/usr/bin/env python3
"""Run repeated GSAS-II charge-flipping solutions for the residual phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIImath as G2mth
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


class SilentProgress:
    def Update(self, *_args, **_kwargs):
        return (True,)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx")
    parser.add_argument("--runs", type=int, default=8)
    args = parser.parse_args()

    project = G2sc.G2Project(args.gpx)
    hist = project.histogram(0)
    phase = project.phases()[-1]
    refl = hist.data["Reflection Lists"][phase.name]
    general = phase.data["General"]
    general["Flip"].update({
        "GridStep": 0.25,
        "Norm element": "Mn",
        "k-factor": 0.10,
        "k-Max": 20.0,
        "d-max": 100.0,
    })
    general["Map"]["cutOff"] = 12.0

    results = []
    for run in range(args.runs):
        result = G2mth.ChargeFlip(phase.data, refl, SilentProgress())
        general["Map"].update(result[0])
        peaks, mags, dzeros, dcents = G2mth.SearchMap(
            general, phase.data.get("Drawing", {})
        )
        order = np.argsort(np.asarray(mags).ravel())[::-1]
        rows = []
        for idx in order[:40]:
            rows.append({
                "xyz": [float(v % 1.0) for v in peaks[idx]],
                "height": float(mags[idx, 0]),
                "distance_origin_A": float(dzeros[idx, 0]),
                "distance_center_A": float(dcents[idx, 0]),
            })
        results.append({
            "run": run,
            "Rcf_percent": float(general["Map"]["Rcf"]),
            "summary": result[3],
            "peaks": rows,
        })

    out = ROOT / "analysis" / "lebail" / "residual_p2c" / "charge_flip.json"
    out.write_text(json.dumps(results, indent=2) + "\n")
    for item in sorted(results, key=lambda row: row["Rcf_percent"]):
        print("run", item["run"], "Rcf", item["Rcf_percent"])
        for peak in item["peaks"][:12]:
            print("  ", peak)


if __name__ == "__main__":
    main()
