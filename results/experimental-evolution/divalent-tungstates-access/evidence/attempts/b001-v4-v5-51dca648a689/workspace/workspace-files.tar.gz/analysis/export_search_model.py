#!/usr/bin/env python3
"""Export a structure-factor search result as a symmetry-aware CIF."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("result_json")
    parser.add_argument("output_cif")
    args = parser.parse_args()

    result = json.loads(Path(args.result_json).read_text())
    sites = result["unique_coordinates"]
    lattice = Lattice.monoclinic(4.3229339378, 4.4575304490, 6.1982944748, 92.1709382964)
    structure = Structure.from_spacegroup(
        "P2/c",
        lattice,
        [site["element"] for site in sites],
        [site["xyz"] for site in sites],
    )
    CifWriter(structure, symprec=1e-4, refine_struct=False).write_file(args.output_cif)


if __name__ == "__main__":
    main()
