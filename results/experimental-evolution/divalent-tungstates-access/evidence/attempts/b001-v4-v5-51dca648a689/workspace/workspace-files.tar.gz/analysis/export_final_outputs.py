#!/usr/bin/env python3
"""Export the selected full-grid GSAS-II checkpoint and submission files."""

from __future__ import annotations

import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "final_full_grid" / "step01_full_grid.gpx"
FINAL = ROOT / "final.gpx"

PHASE_INFO = [
    {
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cif": "phase_1_mnwo4_wolframite.cif",
        "model_basis": "COD 1520200",
    },
    {
        "name": "gamma-WO3",
        "formula": "WO3",
        "cif": "phase_2_gamma_wo3.cif",
        "model_basis": "COD 1528915",
    },
    {
        "name": "MnWO4 (indexed dense P2/c polymorph)",
        "formula": "MnWO4",
        "cif": "phase_3_mnwo4_p2c_indexed.cif",
        "model_basis": "indexed P2/c cell with wolframite-derived, bond-valence-screened coordinates",
    },
    {
        "name": "MnO (wurtzite)",
        "formula": "MnO",
        "cif": "phase_4_mno_wurtzite.cif",
        "model_basis": "COD 4117966",
    },
]


def main() -> None:
    shutil.copy2(SOURCE, FINAL)
    project = G2sc.G2Project(str(FINAL))
    histogram = project.histogram(0)
    phases = project.phases()
    if len(phases) != len(PHASE_INFO):
        raise RuntimeError(f"expected four phases, found {len(phases)}")

    fractions = histogram.ComputeMassFracs()
    phase_rows = []
    for phase, info in zip(phases, PHASE_INFO, strict=True):
        output = ROOT / info["cif"]
        phase.export_CIF(str(output))
        fraction, esd = fractions[phase.name]
        cell = phase.get_cell()
        phase_rows.append({
            **info,
            "cif_path": info["cif"],
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(esd),
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cell": {key: float(value) for key, value in cell.items()},
        })

    x = np.asarray(histogram.getdata("X"), float)
    observed = np.asarray(histogram.getdata("Yobs"), float)
    calculated = np.asarray(histogram.getdata("Ycalc"), float)
    background = np.asarray(histogram.getdata("Background"), float)
    weight = np.asarray(histogram.getdata("Yweight"), float)
    difference = observed - calculated
    low, high = histogram.data["Limits"][1]
    use = (x >= low) & (x <= high) & (weight > 0)
    chi = float(np.sum(weight[use] * difference[use] ** 2))
    denominator = float(np.sum(weight[use] * observed[use] ** 2))
    rwp = 100.0 * math.sqrt(chi / denominator)
    rp = 100.0 * float(np.sum(np.abs(difference[use])) / np.sum(np.abs(observed[use])))
    n_parameters = 29
    goodness_of_fit = math.sqrt(chi / (int(use.sum()) - n_parameters))
    rexp = rwp / goodness_of_fit

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta_deg", "observed_counts", "calculated_counts",
            "difference_counts", "background_counts",
        ])
        writer.writerows(zip(x, observed, calculated, difference, background))

    mw = {"MnWO4": 302.774044, "WO3": 231.837, "MnO": 70.937044}
    mn_moles = (
        (phase_rows[0]["weight_fraction"] + phase_rows[2]["weight_fraction"]) / mw["MnWO4"]
        + phase_rows[3]["weight_fraction"] / mw["MnO"]
    )
    w_moles = (
        (phase_rows[0]["weight_fraction"] + phase_rows[2]["weight_fraction"]) / mw["MnWO4"]
        + phase_rows[1]["weight_fraction"] / mw["WO3"]
    )
    result = {
        "phases": phase_rows,
        "weight_fraction_basis": "normalized over the four modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "Rexp_percent": rexp,
            "goodness_of_fit": goodness_of_fit,
            "chi_squared": chi,
            "n_profile_points": int(use.sum()),
            "n_refined_parameters": n_parameters,
            "two_theta_range_deg": [float(low), float(high)],
        },
        "molar_inventory_Mn_to_W": mn_moles / w_moles,
        "project": "final.gpx",
        "profile": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
