#!/usr/bin/env python3
"""Add a phase to an arbitrary physical GSAS-II checkpoint and compare safely."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def stats(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (wt > 0)
    rwp = 100.0 * math.sqrt(
        np.sum(wt[use] * (yo[use] - yc[use]) ** 2)
        / np.sum(wt[use] * yo[use] ** 2)
    )
    return {
        "Rwp_percent": float(rwp),
        "project_wR_percent": float(hist.get_wR()),
        "mass_fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "scales": {
            phase.name: phase.data["Histograms"][hist.name]["Scale"][0]
            for phase in project.phases()
        },
    }


def snapshot(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    (outdir / f"{label}.json").write_text(json.dumps(stats(project), indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("name")
    parser.add_argument("candidate")
    parser.add_argument("--cif", action="store_true")
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "closure_branches" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    hist = project.histogram(0)
    source = Path(args.candidate) if args.cif else cif_path(args.candidate)
    candidate = project.add_phase(
        str(source), phasename=f"closure_{source.stem}", histograms=[hist], fmthint="CIF"
    )
    project.set_Controls("cycles", 10)
    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True})
        phase.set_HAP_refinements({"Scale": True})
        project.set_Controls("parmMin", 1e-12, f"{phase.id}:{hist.id}:Scale")
    project.refine()
    snapshot(project, outdir, "step01_scale")

    candidate.set_refinements({"Cell": True})
    project.refine()
    snapshot(project, outdir, "step02_candidate_cell")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    snapshot(project, outdir, "step03_all_cells")
    print(json.dumps(stats(project), indent=2))


if __name__ == "__main__":
    main()
