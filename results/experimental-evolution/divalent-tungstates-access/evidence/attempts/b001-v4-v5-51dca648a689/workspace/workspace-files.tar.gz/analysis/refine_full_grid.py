#!/usr/bin/env python3
"""Converge the accepted physical model on the complete measured grid."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def stats(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & (wt > 0)
    chi = float(np.sum(wt[use] * (yo[use] - yc[use]) ** 2))
    rwp = 100 * math.sqrt(chi / np.sum(wt[use] * yo[use] ** 2))
    rp = 100 * np.sum(np.abs(yo[use] - yc[use])) / np.sum(np.abs(yo[use]))
    return {
        "Rwp_percent": rwp,
        "Rp_percent": float(rp),
        "chi_squared": chi,
        "n_points": int(use.sum()),
        "limits_deg": [float(lo), float(hi)],
        "mass_fractions": {key: list(value) for key, value in hist.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "sample": hist.SampleParameters,
    }


def snapshot(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    (outdir / f"{label}.json").write_text(json.dumps(stats(project), indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    args = parser.parse_args()
    outdir = ROOT / "analysis" / "final_full_grid"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    project.set_Controls("cycles", 10)
    hist.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": True,
        "Sample Parameters": ["Shift"],
    })
    hist.clear_refinements({"Instrument Parameters": ["U", "V", "W", "X", "Y", "Z", "SH/L"]})
    for phase in project.phases():
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    dense = next(phase for phase in project.phases() if "dense_mnwo4" in phase.name)
    dense.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})

    project.refine()
    snapshot(project, outdir, "step01_full_grid")
    project.refine()
    snapshot(project, outdir, "step02_full_grid_replay")
    print(json.dumps(stats(project), indent=2))


if __name__ == "__main__":
    main()
