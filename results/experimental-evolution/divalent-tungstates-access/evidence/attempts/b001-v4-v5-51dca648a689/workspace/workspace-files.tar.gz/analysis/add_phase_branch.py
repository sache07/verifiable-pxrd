#!/usr/bin/env python3
"""Add one candidate to the accepted two-phase checkpoint and refine it safely."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "trials" / "mnwo4_wo3_1528915" / "working.gpx"
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def stats(project) -> dict:
    hist = project.histogram(0)
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    lo, hi = hist.data["Limits"][1]
    m = (x >= lo) & (x <= hi) & (wt > 0)
    rwp = 100 * math.sqrt(np.sum(wt[m] * (yo[m] - yc[m]) ** 2) / np.sum(wt[m] * yo[m] ** 2))
    return {
        "Rwp_percent": float(rwp),
        "project_wR_percent": float(hist.get_wR()),
        "mass_fractions": {k: list(v) for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "scales": {p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()},
        "broadening": {
            p.name: {
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            }
            for p in project.phases()
        },
    }


def snapshot(project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    (outdir / f"{label}.json").write_text(json.dumps(stats(project), indent=2) + "\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("candidate")
    ap.add_argument("--cif", action="store_true", help="candidate is a CIF path")
    args = ap.parse_args()

    outdir = ROOT / "analysis" / "branches" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    working = outdir / "working.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(working))
    hist = project.histogram(0)
    candidate_path = Path(args.candidate) if args.cif else cif_path(args.candidate)
    candidate = project.add_phase(
        str(candidate_path), phasename=f"candidate_{Path(args.candidate).stem}",
        histograms=[hist], fmthint="CIF",
    )
    project.set_Controls("cycles", 10)

    # Freeze the accepted profile, cell, and broadening parameters initially.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True})
        phase.set_HAP_refinements({"Scale": True})
        project.set_Controls("parmMin", 1e-12, f"{phase.id}:{hist.id}:Scale")
    project.refine()
    snapshot(project, outdir, "step01_scale")

    # A genuine phase should improve after its cell is allowed to register.
    candidate.set_refinements({"Cell": True})
    project.refine()
    snapshot(project, outdir, "step02_candidate_cell")

    # Compare branches in a common multiphase relaxation state.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine()
    snapshot(project, outdir, "step03_all_cells")

    candidate.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.3, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    project.refine()
    snapshot(project, outdir, "step04_candidate_broadening")
    project.save()
    print(json.dumps(stats(project), indent=2))


if __name__ == "__main__":
    main()
