#!/usr/bin/env python3
"""Search the frozen COD index for physical parents of the residual phase."""

from __future__ import annotations

import gzip
import json
import math
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
LIB = INDEX.parent / "cif"
TARGET = Lattice.monoclinic(4.329141153, 4.446796793, 6.204113130, 92.13528779)
TARGET_POS = np.array([
    19.9532, 20.5080, 28.7790, 31.8995, 34.9654, 35.2702, 45.8498,
    46.6786, 54.5724, 55.5318, 56.6855, 64.5584, 66.6491, 70.3279,
    74.5736, 79.0737,
])
TARGET_W = np.array([7956, 8536, 7833, 3411, 3042, 9205, 2907, 4265, 3187,
                     1937, 1396, 1338, 1214, 973, 660, 699], float)


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def lattice_distance(lattice: Lattice) -> tuple[float, str]:
    """Metric mismatch after Niggli reduction; test small volume multiples."""
    try:
        a = TARGET.get_niggli_reduced_lattice()
        b = lattice.get_niggli_reduced_lattice()
        pa = np.array(a.parameters)
        pb = np.array(b.parameters)
        # Direct reduced-cell metric, allowing an isotropic size adjustment.
        scale = np.exp(np.mean(np.log(pa[:3] / pb[:3])))
        lens = np.log(pa[:3] / (pb[:3] * scale))
        angs = (pa[3:] - pb[3:]) / 10.0
        direct = float(np.sqrt(np.mean(np.r_[lens, angs] ** 2)))
        mode = f"direct scale={scale:.4f}"
        # Exact-ish lattice mapping is a useful discriminator when available.
        for ltol in (0.03, 0.06, 0.10):
            m = TARGET.find_mapping(lattice, ltol=ltol, atol=3.0, skip_rotation_matrix=True)
            if m is not None:
                direct -= 0.25
                mode += f" map@{ltol:.2f}"
                break
            m = lattice.find_mapping(TARGET, ltol=ltol, atol=3.0, skip_rotation_matrix=True)
            if m is not None:
                direct -= 0.2
                mode += f" reverse-map@{ltol:.2f}"
                break
        return direct, mode
    except Exception:
        return 99.0, "failed"


def peak_score(structure: Structure) -> tuple[float, float, int]:
    """Position-only score after replacing all cations by Mn and scaling cell."""
    species = []
    for site in structure:
        repl = {}
        for sp, occ in site.species.items():
            symbol = sp.symbol
            repl["O" if symbol == "O" else ("W" if symbol == "W" else "Mn")] = (
                repl.get("O" if symbol == "O" else ("W" if symbol == "W" else "Mn"), 0)
                + occ
            )
        species.append(repl)
    trial = Structure(structure.lattice, species, structure.frac_coords)
    calc = XRDCalculator(wavelength=WAVELENGTH)
    try:
        pat = calc.get_pattern(trial, two_theta_range=(8, 110), scaled=True)
    except Exception:
        return 1e9, 1.0, 0
    pos0 = np.asarray(pat.x)
    inten = np.asarray(pat.y)
    keep = inten >= 1.0
    pos0, inten = pos0[keep], inten[keep]
    d0 = WAVELENGTH / (2.0 * np.sin(np.radians(pos0 / 2.0)))
    best = (1e9, 1.0, 0)
    for scale in np.linspace(0.90, 1.10, 81):
        arg = WAVELENGTH / (2.0 * d0 * scale)
        valid = arg < 1.0
        pos = np.degrees(2.0 * np.arcsin(arg[valid]))
        if not len(pos):
            continue
        dist = np.min(np.abs(TARGET_POS[:, None] - pos[None, :]), axis=1)
        # Weighted RMS nearest-reflection mismatch, with a soft cap so one bad
        # line does not dominate. Count close lines for interpretability.
        score = float(np.sqrt(np.average(np.minimum(dist, 1.5) ** 2, weights=TARGET_W)))
        close = int(np.sum(dist < 0.25))
        if score < best[0]:
            best = (score, float(scale), close)
    return best


WAVELENGTH = 1.540598


def main() -> None:
    with gzip.open(INDEX, "rt") as f:
        index = json.load(f)
    records = []
    for key, rows in index.items():
        elems = key.split("-")
        if "O" not in elems or "W" not in elems:
            continue
        # A chemically readable topology parent should contain at most two
        # non-O/W elements; rank ternaries first but retain quaternaries.
        if len(set(elems) - {"O", "W"}) > 2:
            continue
        for formula, cod_id, sg, r in rows:
            records.append((len(elems), key, formula, cod_id, sg))

    results = []
    for n_elem, key, formula, cod_id, sg in records:
        path = cif_path(cod_id)
        try:
            structure = Structure.from_file(path)
            ld, mode = lattice_distance(structure.lattice)
            ps, scale, close = peak_score(structure)
            results.append(
                {
                    "id": cod_id,
                    "key": key,
                    "formula": formula,
                    "sg_index": sg,
                    "spacegroup": structure.get_space_group_info(),
                    "composition": structure.composition.reduced_formula,
                    "lattice": structure.lattice.parameters,
                    "volume": structure.volume,
                    "lattice_score": ld,
                    "lattice_mode": mode,
                    "peak_score_deg": ps,
                    "peak_scale": scale,
                    "close_lines": close,
                    "n_elements": n_elem,
                }
            )
        except Exception as exc:
            continue

    # Joint rank: reflection positions dominate; lattice equivalence and
    # chemical simplicity break ties.
    for r in results:
        r["joint"] = r["peak_score_deg"] + 0.15 * max(r["lattice_score"], 0) + 0.03 * (r["n_elements"] - 3)
    results.sort(key=lambda r: r["joint"])
    Path("analysis/residual_parent_ranking.json").write_text(json.dumps(results, indent=2) + "\n")
    for r in results[:80]:
        print(
            f"{r['joint']:6.3f} peak={r['peak_score_deg']:5.3f} close={r['close_lines']:2d} "
            f"lat={r['lattice_score']:6.3f} scale={r['peak_scale']:5.3f} "
            f"{r['id']} {r['key']} {r['composition']} {r['spacegroup']} "
            f"cell={tuple(round(x,3) for x in r['lattice'][:6])}"
        )


if __name__ == "__main__":
    main()
