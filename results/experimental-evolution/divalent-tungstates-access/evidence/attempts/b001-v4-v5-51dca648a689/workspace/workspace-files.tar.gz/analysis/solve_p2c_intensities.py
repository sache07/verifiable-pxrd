#!/usr/bin/env python3
"""Global structure-factor search in the indexed P2/c residual cell."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import ATOMIC_SCATTERING_PARAMS
from pymatgen.core import Element, Lattice, Structure
from scipy.optimize import differential_evolution


ROOT = Path(__file__).resolve().parents[1]
REFLECTIONS = ROOT / "analysis" / "lebail" / "residual_p2c" / "reflections.csv"
LATTICE = Lattice.monoclinic(4.3229339378, 4.4575304490, 6.1982944748, 92.1709382964)

SPECIAL = {
    "a": (0.0, 0.0, 0.0),
    "b": (0.5, 0.5, 0.0),
    "c": (0.0, 0.5, 0.0),
    "d": (0.5, 0.0, 0.0),
    "e": (0.0, None, 0.25),
    "f": (0.5, None, 0.25),
}


def model_sites(name: str) -> list[tuple[str, str]]:
    parts = name.split("_")
    if parts[0] == "mn2o3" and parts[1] == "g":
        return [("Mn", "g"), ("O", "g"), ("O", parts[2])]
    if parts[0] == "mn2o3" and parts[1] == "ef":
        return [("Mn", "e"), ("Mn", "f"), ("O", "g"), ("O", parts[2])]
    if name == "mno2_ggg":
        return [("Mn", "g"), ("O", "g"), ("O", "g")]
    if parts[0] == "mn3o4" and parts[1] == "g":
        return [("Mn", "g"), ("Mn", parts[2]), ("O", "g"), ("O", "g")]
    if parts[0] == "wo3" and len(parts) == 4 and parts[2] == "g":
        # P2/c, Z=2: W on a multiplicity-2 special site, with one
        # general and one special oxygen orbit (4 + 2 oxygen atoms).
        return [("W", parts[1]), ("O", "g"), ("O", parts[3])]
    if name == "mnwo4_ef_gg":
        return [("Mn", "e"), ("W", "f"), ("O", "g"), ("O", "g")]
    if name == "mnwo4_fe_gg":
        return [("Mn", "f"), ("W", "e"), ("O", "g"), ("O", "g")]
    raise ValueError(f"unknown model {name}")


def decode(values: np.ndarray, sites: list[tuple[str, str]]) -> list[tuple[str, tuple[float, float, float]]]:
    decoded = []
    offset = 0
    for element, wyckoff in sites:
        if wyckoff == "g":
            xyz = tuple(float(v % 1.0) for v in values[offset:offset + 3])
            offset += 3
        else:
            fixed = SPECIAL[wyckoff]
            if fixed[1] is None:
                xyz = (fixed[0], float(values[offset] % 1.0), fixed[2])
                offset += 1
            else:
                xyz = fixed
        decoded.append((element, xyz))
    return decoded


def orbit(xyz: tuple[float, float, float]) -> np.ndarray:
    x, y, z = xyz
    points = np.array([
        [x, y, z],
        [x, -y, z + 0.5],
        [-x, y, -z + 0.5],
        [-x, -y, -z],
    ]) % 1.0
    unique = []
    for point in points:
        if not any(np.allclose(point, old, atol=1e-7) for old in unique):
            unique.append(point)
    return np.asarray(unique)


def expanded(values: np.ndarray, sites: list[tuple[str, str]]) -> tuple[list[str], np.ndarray]:
    elements: list[str] = []
    coords: list[np.ndarray] = []
    for element, xyz in decode(values, sites):
        points = orbit(xyz)
        elements.extend([element] * len(points))
        coords.extend(points)
    return elements, np.asarray(coords)


def form_factor(symbol: str, d: np.ndarray) -> np.ndarray:
    s2 = (0.5 / d) ** 2
    coeff = np.asarray(ATOMIC_SCATTERING_PARAMS[symbol], float)
    return Element(symbol).Z - 41.78214 * s2 * np.sum(
        coeff[None, :, 0] * np.exp(-coeff[None, :, 1] * s2[:, None]), axis=1
    )


def load_groups(max_angle: float = 95.0, tolerance: float = 0.20):
    rows = []
    with REFLECTIONS.open(newline="") as stream:
        for row in csv.DictReader(stream):
            item = {key: float(value) for key, value in row.items()}
            if item["two_theta_deg"] <= max_angle:
                rows.append(item)
    rows.sort(key=lambda row: row["two_theta_deg"])
    groups: list[list[dict]] = []
    for row in rows:
        if not groups or row["two_theta_deg"] - groups[-1][-1]["two_theta_deg"] > tolerance:
            groups.append([row])
        else:
            groups[-1].append(row)
    return rows, groups


def geometry_summary(elements: list[str], coords: np.ndarray) -> dict:
    structure = Structure(LATTICE, elements, coords)
    matrix = structure.distance_matrix
    np.fill_diagonal(matrix, np.inf)
    min_by_pair = {}
    for left in {"Mn", "W", "O"}:
        for right in {"Mn", "W", "O"}:
            vals = [
                matrix[i, j]
                for i, a in enumerate(elements)
                for j, b in enumerate(elements)
                if i != j and a == left and b == right
            ]
            if vals:
                min_by_pair[f"{left}-{right}"] = float(min(vals))
    coordination = []
    oxygen_indices = [i for i, element in enumerate(elements) if element == "O"]
    for index, element in enumerate(elements):
        if element == "O":
            continue
        distances = sorted(float(matrix[index, j]) for j in oxygen_indices)
        coordination.append({"element": element, "nearest_O_A": distances[:8]})
    return {
        "density_g_cm3": float(structure.density),
        "minimum_distances_A": min_by_pair,
        "cation_coordination": coordination,
    }


def geometry_penalty(elements: list[str], coords: np.ndarray, profile: str = "wolframite") -> float:
    delta = coords[:, None, :] - coords[None, :, :]
    shifts = np.array([
        [i, j, k]
        for i in (-1, 0, 1)
        for j in (-1, 0, 1)
        for k in (-1, 0, 1)
    ], float)
    cart = (delta[:, :, None, :] + shifts[None, None, :, :]) @ LATTICE.matrix
    matrix = np.min(np.linalg.norm(cart, axis=-1), axis=2)
    np.fill_diagonal(matrix, np.inf)
    penalty = 0.0
    for i in range(len(elements)):
        for j in range(i + 1, len(elements)):
            pair = {elements[i], elements[j]}
            if pair == {"O"}:
                threshold = 2.15 if profile == "mno2" else 2.05
            elif "O" not in pair:
                threshold = 2.45 if profile == "mno2" else 2.25
            else:
                threshold = 1.65
            if matrix[i, j] < threshold:
                penalty += ((threshold - matrix[i, j]) / threshold) ** 2
    oxygen_indices = [i for i, element in enumerate(elements) if element == "O"]
    for i, element in enumerate(elements):
        if element == "O":
            continue
        distances = sorted(float(matrix[i, j]) for j in oxygen_indices)
        # Both cations are expected to be octahedrally coordinated in a
        # wolframite-derived MnWO4 topology.
        required = 6
        if len(distances) < required:
            penalty += 1.0
            continue
        if profile == "mno2":
            minimum = 1.70
        else:
            minimum = 1.65 if element == "W" else 1.80
        if distances[0] < minimum:
            penalty += ((minimum - distances[0]) / 0.20) ** 2
        if profile == "mno2":
            maximum = 2.25
        else:
            maximum = 2.40 if element == "W" else 2.65
        if distances[required - 1] > maximum:
            penalty += ((distances[required - 1] - maximum) / 0.30) ** 2
        # Soft octahedral targets from wolframite, contracted to the indexed
        # cell volume. This distinguishes merely non-overlapping solutions
        # from chemically credible Mn(II)O6 and W(VI)O6 polyhedra.
        if profile == "mno2":
            target = [1.85, 1.85, 1.90, 1.90, 2.05, 2.05]
        else:
            target = (
                [1.72, 1.72, 1.85, 1.85, 2.15, 2.15]
                if element == "W"
                else [1.95, 1.95, 2.10, 2.10, 2.40, 2.40]
            )
        penalty += sum(((distances[j] - target[j]) / 0.25) ** 2 for j in range(6))
    return float(penalty)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("model")
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument("--maxiter", type=int, default=350)
    parser.add_argument("--geometry-weight", type=float, default=0.0)
    parser.add_argument("--max-angle", type=float, default=95.0)
    parser.add_argument("--top-groups", type=int, default=0)
    parser.add_argument("--geometry-profile", choices=["wolframite", "mno2"], default="wolframite")
    args = parser.parse_args()

    sites = model_sites(args.model)
    dimensions = sum(3 if wyckoff == "g" else (1 if wyckoff in {"e", "f"} else 0)
                     for _, wyckoff in sites)
    rows, groups = load_groups(max_angle=args.max_angle)
    hkls = np.array([[row["h"], row["k"], row["l"]] for row in rows], float)
    d = np.array([row["d_A"] for row in rows], float)
    correction = np.array([row["intensity_correction"] for row in rows], float)
    observed = np.array([row["Fobs_sq"] for row in rows], float) * correction
    factors = {element: form_factor(element, d) for element in {item[0] for item in sites}}
    group_indices = []
    start = 0
    for group in groups:
        group_indices.append(np.arange(start, start + len(group)))
        start += len(group)
    grouped_observed = np.array([observed[idx].sum() for idx in group_indices])
    if args.top_groups:
        selected = np.argsort(grouped_observed)[::-1][:args.top_groups]
        groups = [groups[index] for index in selected]
        group_indices = [group_indices[index] for index in selected]
        grouped_observed = grouped_observed[selected]
    floor = 0.015 * grouped_observed.max()
    weights = 1.0 / np.maximum(grouped_observed, floor)

    def calculate(values: np.ndarray):
        elements, coords = expanded(values, sites)
        phase = np.exp(2j * np.pi * (hkls @ coords.T))
        atomic = np.column_stack([factors[element] for element in elements])
        fcalc = np.sum(atomic * phase, axis=1)
        raw = np.abs(fcalc) ** 2 * correction
        grouped = np.array([raw[idx].sum() for idx in group_indices])
        scale = float(np.sum(weights * grouped_observed * grouped) / np.sum(weights * grouped * grouped))
        residual = grouped_observed - scale * grouped
        xrd = math.sqrt(float(np.sum(weights * residual * residual) / np.sum(weights * grouped_observed ** 2)))
        return xrd, scale, elements, coords, grouped

    def objective(values: np.ndarray):
        xrd, _scale, elements, coords, _grouped = calculate(values)
        return xrd + args.geometry_weight * geometry_penalty(elements, coords, args.geometry_profile)

    result = differential_evolution(
        objective,
        bounds=[(0.0, 1.0)] * dimensions,
        seed=args.seed,
        maxiter=args.maxiter,
        popsize=16,
        tol=2e-6,
        polish=True,
        updating="immediate",
    )
    xrd, scale, elements, coords, grouped = calculate(result.x)
    decoded = decode(result.x, sites)
    geom = geometry_summary(elements, coords)
    strong = np.argsort(grouped_observed)[::-1][:30]
    comparison = [
        {
            "two_theta_deg": float(np.mean([groups[index][j]["two_theta_deg"] for j in range(len(groups[index]))])),
            "hkls": [[int(row["h"]), int(row["k"]), int(row["l"])] for row in groups[index]],
            "observed": float(grouped_observed[index]),
            "calculated": float(scale * grouped[index]),
        }
        for index in strong
    ]
    output = {
        "model": args.model,
        "sites": [{"element": element, "wyckoff": wyckoff} for element, wyckoff in sites],
        "unique_coordinates": [{"element": element, "xyz": xyz} for element, xyz in decoded],
        "xrd_weighted_fractional_residual": xrd,
        "objective": float(result.fun),
        "geometry_weight": args.geometry_weight,
        "geometry_profile": args.geometry_profile,
        "max_angle": args.max_angle,
        "top_groups": args.top_groups,
        "scale": scale,
        "success": bool(result.success),
        "message": str(result.message),
        "geometry": geom,
        "strong_group_comparison": comparison,
    }
    outdir = ROOT / "analysis" / "structure_factor_search"
    outdir.mkdir(parents=True, exist_ok=True)
    suffix = f"g{args.geometry_weight:g}_s{args.seed}"
    path = outdir / f"{args.model}_{suffix}.json"
    path.write_text(json.dumps(output, indent=2) + "\n")
    structure = Structure(LATTICE, elements, coords)
    structure.to(filename=str(outdir / f"{args.model}_{suffix}.cif"))
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
