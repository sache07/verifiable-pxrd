#!/usr/bin/env python3
"""Refine a registered candidate's heavy and oxygen coordinates in stages."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def statistics(project: G2sc.G2Project) -> dict:
    histogram = project.histogram(0)
    x = np.asarray(histogram.getdata("X"), float)
    observed = np.asarray(histogram.getdata("Yobs"), float)
    calculated = np.asarray(histogram.getdata("Ycalc"), float)
    weight = np.asarray(histogram.getdata("Yweight"), float)
    low, high = histogram.data["Limits"][1]
    use = (x >= low) & (x <= high) & (weight > 0)
    rwp = 100 * math.sqrt(
        np.sum(weight[use] * (observed[use] - calculated[use]) ** 2)
        / np.sum(weight[use] * observed[use] ** 2)
    )
    return {
        "Rwp_percent": float(rwp),
        "project_wR_percent": float(histogram.get_wR()),
        "mass_fractions": {key: list(value) for key, value in histogram.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "atoms": {
            phase.name: [atom[:] for atom in phase.data["Atoms"]]
            for phase in project.phases()
        },
    }


def snapshot(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    project.phases()[-1].export_CIF(str(outdir / f"{label}.cif"))
    result = statistics(project)
    (outdir / f"{label}.json").write_text(json.dumps(result, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("name")
    args = parser.parse_args()
    outdir = ROOT / "analysis" / "coordinate_branches" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    working = outdir / "working.gpx"
    project = G2sc.G2Project(args.input_gpx, newgpx=str(working))
    histogram = project.histogram(0)
    candidate = project.phases()[-1]
    project.set_Controls("cycles", 8)

    histogram.clear_refinements({"Sample Parameters": ["Shift"]})
    histogram.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})

    heavy = {atom.label: "X" for atom in candidate.atoms() if atom.element != "O"}
    candidate.set_refinements({"Atoms": heavy})
    project.refine()
    snapshot(project, outdir, "step01_heavy")

    oxygen = {atom.label: "X" for atom in candidate.atoms() if atom.element == "O"}
    candidate.set_refinements({"Atoms": oxygen})
    project.refine()
    snapshot(project, outdir, "step02_oxygen")
    print(json.dumps(statistics(project), indent=2))


if __name__ == "__main__":
    main()
