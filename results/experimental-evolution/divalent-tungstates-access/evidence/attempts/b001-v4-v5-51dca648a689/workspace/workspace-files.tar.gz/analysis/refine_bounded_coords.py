#!/usr/bin/env python3
"""Coordinate refinement with bounded displacements and staged rollback points."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def statistics(project: G2sc.G2Project) -> dict:
    histogram = project.histogram(0)
    x = np.asarray(histogram.getdata("X"), float)
    observed = np.asarray(histogram.getdata("Yobs"), float)
    calculated = np.asarray(histogram.getdata("Ycalc"), float)
    weight = np.asarray(histogram.getdata("Yweight"), float)
    low, high = histogram.data["Limits"][1]
    use = (x >= low) & (x <= high) & (weight > 0)
    rwp = 100 * math.sqrt(
        np.sum(weight[use] * (observed[use] - calculated[use]) ** 2)
        / np.sum(weight[use] * observed[use] ** 2)
    )
    return {
        "Rwp_percent": float(rwp),
        "project_wR_percent": float(histogram.get_wR()),
        "mass_fractions": {key: list(value) for key, value in histogram.ComputeMassFracs().items()},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "atoms": {phase.name: [atom[:] for atom in phase.data["Atoms"]] for phase in project.phases()},
    }


def snapshot(project: G2sc.G2Project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    project.phases()[-1].export_CIF(str(outdir / f"{label}.cif"))
    (outdir / f"{label}.json").write_text(json.dumps(statistics(project), indent=2) + "\n")


def bound_atom(project: G2sc.G2Project, phase_id: int, atom_index: int, delta: float) -> None:
    phase = next(item for item in project.phases() if item.id == phase_id)
    coordinates = phase.atoms()[atom_index].coordinates
    for axis in "xyz":
        name = f"{phase_id}::dA{axis}:{atom_index}"
        center = coordinates["xyz".index(axis)]
        project.set_Controls("parmMin", center - delta, name)
        project.set_Controls("parmMax", center + delta, name)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx")
    parser.add_argument("name")
    parser.add_argument("--heavy-delta", type=float, default=0.035)
    parser.add_argument("--oxygen-delta", type=float, default=0.04)
    parser.add_argument("--phase-name", help="phase to refine; defaults to the last phase")
    parser.add_argument("--heavy-only", action="store_true")
    args = parser.parse_args()

    outdir = ROOT / "analysis" / "bounded_coordinate_branches" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(args.input_gpx, newgpx=str(outdir / "working.gpx"))
    histogram = project.histogram(0)
    candidate = (
        next(phase for phase in project.phases() if phase.name == args.phase_name)
        if args.phase_name else project.phases()[-1]
    )
    project.set_Controls("cycles", 6)
    histogram.clear_refinements({"Sample Parameters": ["Shift"]})
    histogram.set_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})

    heavy_indices = [i for i, atom in enumerate(candidate.atoms()) if atom.element != "O"]
    oxygen_indices = [i for i, atom in enumerate(candidate.atoms()) if atom.element == "O"]
    for index in heavy_indices:
        bound_atom(project, candidate.id, index, args.heavy_delta)
    candidate.set_refinements({
        "Atoms": {candidate.atoms()[i].label: "X" for i in heavy_indices}
    })
    project.refine()
    snapshot(project, outdir, "step01_heavy_bounded")

    if args.heavy_only:
        print(json.dumps(statistics(project), indent=2))
        return

    candidate.clear_refinements({"Atoms": [candidate.atoms()[i].label for i in heavy_indices]})
    for index in oxygen_indices:
        bound_atom(project, candidate.id, index, args.oxygen_delta)
    candidate.set_refinements({
        "Atoms": {candidate.atoms()[i].label: "X" for i in oxygen_indices}
    })
    project.refine()
    snapshot(project, outdir, "step02_oxygen_bounded")
    print(json.dumps(statistics(project), indent=2))


if __name__ == "__main__":
    main()
