#!/usr/bin/env python3
"""Report positive residuals at the indexed unassigned line family."""

from __future__ import annotations

import argparse

import numpy as np
from GSASII import GSASIIscriptable as G2sc


LINES = np.array([
    20.32431, 20.87850, 29.13696, 32.25562, 35.31994, 35.62420,
    46.19721, 47.02306, 54.89033, 55.84657, 56.99841, 64.87655,
    66.96290, 70.63574, 74.87364, 79.36146,
])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", nargs="+")
    args = parser.parse_args()
    for filename in args.projects:
        project = G2sc.G2Project(filename)
        histogram = project.histogram(0)
        x = np.asarray(histogram.getdata("X"), float)
        residual = np.asarray(histogram.getdata("Residual"), float)
        observed = np.asarray(histogram.getdata("Yobs"), float)
        print("\n", filename, "wR", histogram.get_wR())
        total = 0.0
        for line in LINES:
            use = np.abs(x - line) <= 0.12
            idx = np.flatnonzero(use)[np.argmax(residual[use])]
            total += max(residual[idx], 0.0) ** 2 / max(observed[idx], 1.0)
            print(f"{line:9.5f} max@{x[idx]:9.5f} residual={residual[idx]:9.1f}")
        print("indexed_family_positive_chi", total)


if __name__ == "__main__":
    main()
