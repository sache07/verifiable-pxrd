#!/usr/bin/env python3
"""Index the coherent residual family after MnWO4 + gamma-WO3 fitting."""

from __future__ import annotations

import math

from GSASII import GSASIIindex as G2idx


WAVELENGTH = 1.540598
RADIUS_MM = 200.0
SHIFT_MICRON = -658.0

# Strong positive residual maxima that do not coincide with accepted phase
# reflections. The last few weaker lines are included to constrain the cell.
LINES = [
    (20.32431, 7956),
    (20.87850, 8536),
    (29.13696, 7833),
    (32.25562, 3411),
    (35.31994, 3042),
    (35.62420, 9205),
    (46.19721, 2907),
    (47.02306, 4265),
    (54.89033, 3187),
    (55.84657, 1937),
    (56.99841, 1396),
    (64.87655, 1338),
    (66.96290, 1214),
    (70.63574, 973),
    (74.87364, 660),
    (79.36146, 699),
]


def unshift(two_theta_obs: float) -> float:
    # GSAS-II Bragg-Brentano correction used in GetReflPos.
    const = 0.09 / (math.pi * RADIUS_MM)
    corr = -4.0 * const * SHIFT_MICRON * math.cos(math.radians(two_theta_obs / 2.0))
    return two_theta_obs - corr


def dspace(two_theta: float) -> float:
    return WAVELENGTH / (2.0 * math.sin(math.radians(two_theta / 2.0)))


def main() -> None:
    peaks = []
    for pos, inten in LINES:
        true_pos = unshift(pos)
        d = dspace(true_pos)
        peaks.append([true_pos, inten, True, False, 0, 0, 0, d, 0.0])
        print(f"line obs={pos:9.5f} corrected={true_pos:9.5f} d={d:9.5f}")

    names = [
        "Cubic-F", "Cubic-I", "Cubic-P", "Trigonal-R", "Hexagonal-P",
        "Tetragonal-I", "Tetragonal-P", "Orthorhombic-F", "Orthorhombic-I",
        "Orthorhombic-A", "Orthorhombic-B", "Orthorhombic-C",
        "Orthorhombic-P", "Monoclinic-I", "Monoclinic-A", "Monoclinic-C",
        "Monoclinic-P", "Triclinic",
    ]
    # Search serious symmetry families separately so a difficult low-symmetry
    # search cannot suppress simpler solutions.
    for selected in ([5, 6], list(range(7, 13)), list(range(13, 17)), [17]):
        bravais = [i in selected for i in range(18)]
        controls = [False, 0.0, 6, 40.0, 0, "P1", 1, 1, 1, 90, 90, 90, 1, "P 1"]
        print("\nSEARCH", [names[i] for i in selected])
        ok, dmin, cells = G2idx.DoIndexPeaks(
            [p[:] for p in peaks], controls, bravais, None,
            ifX20=True, timeout=25, M20_min=3.0, X20_max=6, return_Nc=True,
        )
        print("RESULT", ok, dmin, len(cells))
        for cell in sorted(cells, key=lambda c: c[0] / (c[1] + 1), reverse=True)[:20]:
            print(cell)


if __name__ == "__main__":
    main()
