#!/usr/bin/env python3
"""Build a staged GSAS-II trial refinement from COD phase IDs.

This is an exploratory helper. It deliberately keeps atom coordinates fixed;
the goal is phase identification and a stable profile/cell/scale checkpoint.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "inputs" / "pattern.csv"
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_inputs(outdir: Path) -> tuple[Path, Path]:
    datafile = outdir / "pattern.xye"
    instfile = outdir / "instrument.instprm"
    with INPUT.open(newline="") as src, datafile.open("w") as dst:
        rd = csv.DictReader(src)
        for row in rd:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            dst.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    instfile.write_text(
        "#GSAS-II instrument parameter file for lab CuKa data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return datafile, instfile


def fit_stats(hist) -> dict[str, float]:
    x = np.asarray(hist.getdata("X"), float)
    yo = np.asarray(hist.getdata("Yobs"), float)
    yc = np.asarray(hist.getdata("Ycalc"), float)
    wt = np.asarray(hist.getdata("Yweight"), float)
    lo, hi = hist.data["Limits"][1]
    m = (x >= lo) & (x <= hi) & np.isfinite(yo) & np.isfinite(yc) & (wt > 0)
    num = float(np.sum(wt[m] * (yo[m] - yc[m]) ** 2))
    den = float(np.sum(wt[m] * yo[m] ** 2))
    rwp = 100.0 * math.sqrt(num / den)
    rp = 100.0 * float(np.sum(np.abs(yo[m] - yc[m]))) / float(np.sum(np.abs(yo[m])))
    return {"Rwp_percent": rwp, "Rp_percent": rp, "n_points": int(m.sum())}


def save_snapshot(project, outdir: Path, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    hist = project.histogram(0)
    stats = fit_stats(hist)
    stats["project_wR_percent"] = float(hist.get_wR())
    stats["cells"] = {p.name: p.get_cell() for p in project.phases()}
    stats["scales"] = {
        p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()
    }
    (outdir / f"{label}.json").write_text(json.dumps(stats, indent=2) + "\n")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("name")
    ap.add_argument("cod_ids", nargs="+")
    args = ap.parse_args()
    outdir = ROOT / "analysis" / "trials" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    datafile, instfile = prepare_inputs(outdir)
    gpx = outdir / "working.gpx"
    project = G2sc.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(
        str(datafile), str(instfile), fmthint="xye"
    )
    phases = []
    for cod_id in args.cod_ids:
        path = cif_path(cod_id)
        if not path.exists():
            raise FileNotFoundError(path)
        phases.append(
            project.add_phase(
                str(path), phasename=f"COD_{cod_id}", histograms=[hist], fmthint="CIF"
            )
        )

    project.set_Controls("cycles", 12)
    # The overall histogram scale is redundant with all phase scales. Hold it
    # at unity so the phase scales, and therefore phase fractions, are defined.
    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 10,
            },
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.refine(printFile=str(outdir / "step01_scale.lst"))
    save_snapshot(project, outdir, "step01_scale")

    # Specimen displacement is expected in this reflection-geometry experiment.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.refine(printFile=str(outdir / "step02_shift.lst"))
    save_snapshot(project, outdir, "step02_shift")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.refine(printFile=str(outdir / "step03_cell.lst"))
    save_snapshot(project, outdir, "step03_cell")

    # Use a small set of global profile terms before phase-specific broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W"]})
    project.set_Controls("parmMin", 0.0, ":0:U")
    project.set_Controls("parmMax", 40.0, ":0:U")
    project.set_Controls("parmMin", 2.0, ":0:W")
    project.set_Controls("parmMax", 40.0, ":0:W")
    project.refine(printFile=str(outdir / "step04_instrument.lst"))
    save_snapshot(project, outdir, "step04_instrument")

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    project.refine(printFile=str(outdir / "step05_broadening.lst"))
    save_snapshot(project, outdir, "step05_broadening")

    project.save(gpx)
    print(json.dumps(fit_stats(hist), indent=2))
    print("project", gpx)


if __name__ == "__main__":
    main()
