#!/usr/bin/env python3
"""Independent chemistry/geometry checks for the exported final CIFs."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parent
EXPECTED = [
    ("phase_1_MnWO4_wolframite.cif", {"Mn": 1, "W": 1, "O": 4}),
    ("phase_2_WO3_monoclinic.cif", {"W": 1, "O": 3}),
    ("phase_3_Mn2WO6_P212121.cif", {"Mn": 2, "W": 1, "O": 6}),
    ("phase_4_Mn3W2O9_C2c.cif", {"Mn": 3, "W": 2, "O": 9}),
]


def normalized_composition(structure):
    values = structure.composition.get_el_amt_dict()
    oxygen = values["O"]
    expected_oxygen = None
    return values, oxygen, expected_oxygen


def close_formula(actual, expected):
    ratios = [actual[element] / count for element, count in expected.items()]
    return set(actual) == set(expected) and max(ratios) - min(ratios) < 1e-7


def inspect(path, expected):
    structure = Structure.from_file(path)
    actual = structure.composition.get_el_amt_dict()
    centers, neighbors, images, distances = structure.get_neighbor_list(3.5)
    all_distances = []
    oxygen_distances = []
    for i, j, image, distance in zip(centers, neighbors, images, distances):
        if i > j or (i == j and tuple(image) <= (0, 0, 0)):
            continue
        if distance <= 1e-8:
            continue
        all_distances.append(float(distance))
        if structure[int(i)].species_string == "O" and structure[int(j)].species_string == "O":
            oxygen_distances.append(float(distance))
    occupancies = [float(site.species.num_atoms) for site in structure]
    record = {
        "cif": path.name,
        "composition_in_cell": actual,
        "expected_reduced_formula": expected,
        "formula_pass": close_formula(actual, expected),
        "sites": len(structure),
        "density_g_cm3": float(structure.density),
        "minimum_interatomic_distance_A": min(all_distances),
        "minimum_O_O_distance_A": min(oxygen_distances),
        "minimum_site_occupancy": min(occupancies),
        "maximum_site_occupancy": max(occupancies),
    }
    record["status"] = "pass" if (
        record["formula_pass"]
        and 0.5 < record["density_g_cm3"] < 30
        and record["minimum_interatomic_distance_A"] >= 0.8
        and record["minimum_O_O_distance_A"] >= 1.8
        and record["minimum_site_occupancy"] > 0
        and record["maximum_site_occupancy"] <= 1.0001
    ) else "fail"
    return record


def main():
    records = [inspect(ROOT / name, expected) for name, expected in EXPECTED]
    output = {"status": "pass" if all(row["status"] == "pass" for row in records) else "fail", "phases": records}
    (ROOT / ".tmp" / "final_structure_validation.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output, indent=2))
    if output["status"] != "pass":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
