#!/usr/bin/env python3
"""Build a second, oxidation-state-diverse Mn-W-O prototype shortlist."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser, CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
OUT = Path("candidates")


SPECS = [
    ("mn3wo6_from_ca3wo6_1563081", "1563081", {"Ca": "Mn"}),
    ("mn2wo6_from_y2wo6_1563285", "1563285", {"Y": "Mn"}),
    ("mn2wo6_from_lu2wo6_7712111", "7712111", {"Lu": "Mn"}),
    ("mn2wo6_from_na2wo6_1541344", "1541344", {"Na": "Mn"}),
    ("mn2wo6_from_v2wo6_1008912", "1008912", {"V": "Mn"}),
    ("mn2wo6_fractional_from_fe_7243652", "7243652", {"Fe": "Mn"}),
    ("mn3w2o9_from_sr3w2o9_2311977", "2311977", {"Sr": "Mn"}),
    ("mn3w2o9_from_ba3w2o9_1533878", "1533878", {"Ba": "Mn"}),
    ("mn2w2o7_from_na2w2o7_9007740", "9007740", {"Na": "Mn"}),
    ("mn2w2o7_from_li2w2o7_2106564", "2106564", {"Li": "Mn"}),
    ("mn2wo4_3_from_y2wo4_3_1522204", "1522204", {"Y": "Mn"}),
    ("mn2wo4_3_from_al2wo4_3_1522201", "1522201", {"Al": "Mn"}),
    ("mnwo5_from_amwo5_1551090", "1551090", {"Am": "Mn"}),
    ("mn6wo12_from_in6wo12_1001180_std", "1001180", {"In": "Mn"}),
    ("mn2wo4_from_ag2wo4_1509984", "1509984", {"Ag": "Mn"}),
    ("mnwo2_from_bawo2_5910071", "5910071", {"Ba": "Mn"}),
    ("mn0p93wo3_from_li_4124850", "4124850", {"Li": "Mn"}),
    ("mnwo3_from_crwo3_1539081", "1539081", {"Cr": "Mn"}),
    ("mn2w5o16_from_al2w5o16_1528654", "1528654", {"Al": "Mn"}),
]


def cod_path(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def physical(structure):
    d = np.asarray(structure.distance_matrix, float)
    np.fill_diagonal(d, np.inf)
    oxygen = [i for i, site in enumerate(structure) if set(site.species.get_el_amt_dict()) == {"O"}]
    return {
        "minimum_interatomic_distance_A": float(d.min()),
        "minimum_O_O_distance_A": float(d[np.ix_(oxygen, oxygen)].min()) if len(oxygen) > 1 else None,
    }


def main():
    OUT.mkdir(exist_ok=True)
    records = []
    for name, cod_id, substitutions in SPECS:
        source = cod_path(cod_id)
        structure = CifParser(source, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
        source_formula = structure.composition.reduced_formula
        expanded = {}
        for old, new in substitutions.items():
            for site in structure:
                for specie in site.species:
                    if specie.symbol == old:
                        expanded[specie] = new
        if not expanded:
            raise ValueError(f"No occupied species for {name}: {substitutions}")
        structure.replace_species(expanded)
        structure.remove_oxidation_states()
        # Standardize the setting to avoid COD symmetry operators that GSAS-II
        # cannot import, while preserving the conventional topology.
        structure = SpacegroupAnalyzer(structure, symprec=1e-3).get_conventional_standard_structure()
        target = OUT / f"{name}.cif"
        CifWriter(structure, symprec=1e-3, angle_tolerance=5, significant_figures=10, refine_struct=False).write_file(target)
        parsed = CifParser(target, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
        records.append({
            "candidate": name,
            "status": "pending",
            "path": str(target),
            "source_cod_id": cod_id,
            "source_path": str(source),
            "model_basis": "analogue_derived",
            "source_formula": source_formula,
            "substitutions": substitutions,
            "target_formula": parsed.composition.reduced_formula,
            "space_group": parsed.get_space_group_info()[0],
            "space_group_number": parsed.get_space_group_info()[1],
            "cell": list(map(float, parsed.lattice.parameters)),
            "sites_in_cell": len(parsed),
            "density_g_cm3": float(parsed.density),
            "physical_screen": physical(parsed),
        })
    Path("expanded_candidate_ledger.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
