#!/usr/bin/env python3
"""Identical coordinate-refinement comparison for the closest third-phase branches."""

from __future__ import annotations

import copy
import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SCREEN = ROOT / ".tmp" / "third_phase_screen"
OUT = ROOT / ".tmp" / "deep_candidate_screen"
CANDIDATES = [
    "mn2wo6_from_y2wo6_1541070",
    "mn2wo6_from_y2wo6_2106838",
    "mn2wo6_from_cr2wo6_1530909",
    "mn2wo6_from_la2wo6_4501292",
    "mnwo4_scheelite_from_cawo4_7219229",
    "mn3wo6_from_cu3wo6_1527404",
]


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(v, 0.0) for _, v in vals)
    return {n: max(v, 0.0) / total for n, v in vals}


def snap(p, stage):
    h = p.histograms()[0]
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    inst = h.data["Instrument Parameters"][0]
    return {
        "stage": stage,
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "fractions": fractions(p, h),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
        "phases": {
            phase.name: {
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
                "size": copy.deepcopy(phase.data["Histograms"][h.name]["Size"]),
                "microstrain": copy.deepcopy(phase.data["Histograms"][h.name]["Mustrain"]),
                "atoms": [{"label": a.label, "element": a.element, "xyz": list(map(float, a.coordinates)), "uiso": float(a.uiso)} for a in phase.atoms()],
            }
            for phase in p.phases()
        },
    }


def run(p, repeats, cycles):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()


def test(name):
    result = {"candidate": name, "status": "unknown", "reason": None, "stages": []}
    try:
        source = SCREEN / name / "zero_cells.gpx"
        branch = OUT / name
        branch.mkdir(parents=True, exist_ok=True)
        work = branch / "working.gpx"
        shutil.copy2(source, work)
        p = G2.G2Project(str(work))
        h = p.histograms()[0]
        assert p.phases()[-1].name == name
        clear_frozen(p)
        inst = h.data["Instrument Parameters"][0]
        settings = {
            "Zero": (inst["Zero"][1], True), "Polariz.": (0.7, True),
            "U": (10.0, True), "V": (0.0, False), "W": (30.0, True),
            "X": (1.0, True), "Y": (0.0, False), "Z": (0.0, False),
            "SH/L": (0.005, False),
        }
        for key, (value, flag) in settings.items():
            inst[key][1] = value
            inst[key][2] = flag
        for var, lo, hi in [
            (":0:Zero", -0.5, 0.5), (":0:Polariz.", 0.5, 1.0),
            (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
        ]:
            p.set_Controls("parmMin", lo, var)
            p.set_Controls("parmMax", hi, var)
        for phase_id, phase in enumerate(p.phases()):
            phase.set_refinements({"Cell": True})
            for atom in phase.atoms():
                atom.uiso = 0.005
                atom.refinement_flags = " "
            hap = phase.data["Histograms"][h.name]
            hap["Scale"][1] = True
            p.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")
            hap["Size"][0] = "isotropic"
            hap["Size"][1][0] = 1.5
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0 if phase_id == 0 else 5000.0
            hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
            hap["Mustrain"][2] = [phase_id > 0, False, False]
            if phase_id > 0:
                p.set_Controls("parmMin", 0.0, f"{phase_id}:0:Mustrain;i")
                p.set_Controls("parmMax", 8000.0, f"{phase_id}:0:Mustrain;i")
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
        p.save(str(work))

        run(p, repeats=2, cycles=15)
        result["stages"].append(snap(p, "profile_cells"))
        for phase in p.phases():
            phase.set_refinements({"Atoms": {a.label: ("X" if a.element in {"Mn", "W"} else " ") for a in phase.atoms()}})
        run(p, repeats=3, cycles=18)
        result["stages"].append(snap(p, "heavy_coordinates"))
        for phase in p.phases():
            phase.set_refinements({"Atoms": {"all": "X"}})
        run(p, repeats=3, cycles=20)
        result["stages"].append(snap(p, "all_coordinates"))
        p.save(str(branch / "deep.gpx"))
        result["status"] = "tested"
    except Exception as exc:
        result["status"] = "unknown"
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=10)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for name in CANDIDATES:
        result = test(name)
        results.append(result)
        print(name, result["status"], [(s["stage"], round(s["rwp_percent"], 5), s["fractions"].get(name)) for s in result["stages"]], result.get("reason") or "", flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
