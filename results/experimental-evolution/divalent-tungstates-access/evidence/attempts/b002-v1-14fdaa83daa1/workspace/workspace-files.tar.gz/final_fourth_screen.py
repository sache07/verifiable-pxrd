#!/usr/bin/env python3
"""Final fourth-phase admission screen from the physically valid three-phase project."""

from __future__ import annotations

import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "physical_aniso" / "aniso.gpx"
OUT = ROOT / ".tmp" / "final_fourth_screen"
EXISTING = ["MnWO4_wolframite", "wo3_2311041", "mn2wo6_from_y2wo6_1541070"]
NAMES = [
    "mn2wo4_from_li2wo4_1523083", "mnwo4_scheelite_from_cawo4_7219229",
    "mn2wo6_from_fe2wo6_2310464", "mn2wo6_from_la2wo6_4501292",
    "mn3o4_9001963", "mno_1514108",
    "mnwo5_from_amwo5_1551090", "mn2wo6_from_y2wo6_1563285",
    "mn2wo6_from_lu2wo6_7712111", "mn2wo6_fractional_from_fe_7243652",
    "mn2w2o7_from_na2w2o7_9007740", "mn2w2o7_from_li2w2o7_2106564",
    "mn3w2o9_from_sr3w2o9_2311977", "mn2wo4_from_ag2wo4_1509984",
    "mnwo2_from_bawo2_5910071", "mn0p93wo3_from_li_4124850",
    "mnwo3_from_crwo3_1539081", "mn2w5o16_from_al2w5o16_1528654",
]


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(p, repeats=2, cycles=10):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(0.0, v) for _, v in vals)
    return {n: max(0.0, v) / total for n, v in vals} if total else {}


def snap(p, h, name, start):
    phase = p.phase(name)
    c = phase.get_cell()
    lengths = np.array([c[k] for k in ("length_a", "length_b", "length_c")])
    angles = np.array([c[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "rwp_percent": float(h.get_wR()),
        "fractions": fractions(p, h),
        "candidate_scale": float(phase.data["Histograms"][h.name]["Scale"][0]),
        "cell": [*map(float, lengths), *map(float, angles)],
        "max_length_change_fraction": float(np.max(np.abs(lengths / np.asarray(start[:3]) - 1))),
        "max_angle_change_deg": float(np.max(np.abs(angles - np.asarray(start[3:])))),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
    }


def prepare_common():
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "common.gpx"
    shutil.copy2(SOURCE, path)
    p = G2.G2Project(str(path)); h = p.histograms()[0]
    assert [phase.name for phase in p.phases()] == EXISTING
    clear_frozen(p)
    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
        h.data["Instrument Parameters"][0][key][2] = False
    for phase in p.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms(): atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        h.data["Sample Parameters"][key][1] = False
    p.save(str(path)); run(p); p.save(str(path))
    print("common", h.get_wR(), fractions(p, h), flush=True)
    return path


def test(common, record):
    short = record["candidate"]; name = "trial__" + short
    result = {"candidate": short, "status": "unknown", "reason": None, "stages": {}}
    dmin = record.get("physical_screen", {}).get("minimum_interatomic_distance_A")
    oo = record.get("physical_screen", {}).get("minimum_O_O_distance_A")
    if (dmin is not None and dmin < 0.8) or (oo is not None and oo < 1.8):
        result.update(status="rejected", reason="failed pre-fit contact screen")
        return result
    try:
        branch = OUT / short; branch.mkdir(parents=True, exist_ok=True)
        work = branch / "working.gpx"; shutil.copy2(common, work)
        p = G2.G2Project(str(work)); h = p.histograms()[0]
        phase = p.add_phase(str((ROOT / record["path"]).resolve()), phasename=name, histograms=[h], fmthint="CIF")
        for atom in phase.atoms(): atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"] = [1.0, True]; hap["Size"][2] = [False, False, False]; hap["Mustrain"][2] = [False, False, False]; hap["Pref.Ori."][2] = False
        phase.clear_refinements({"Cell": True})
        c = phase.get_cell(); start = [c[k] for k in ("length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma")]
        p.set_Controls("parmMin", 0.0, "3:0:Scale")
        p.save(str(work)); run(p)
        result["stages"]["scale_background"] = snap(p, h, name, start)
        s1 = result["stages"]["scale_background"]
        if not math.isfinite(s1["candidate_scale"]) or s1["candidate_scale"] <= 1e-10 or s1["fractions"].get(name, 0.0) < 0.0005:
            result.update(status="rejected", reason="scale collapsed in fixed-model admission test"); return result
        phase.set_refinements({"Cell": True}); run(p, repeats=2, cycles=12)
        result["stages"]["candidate_cell"] = snap(p, h, name, start)
        p.save(str(branch / "candidate_cell.gpx"))
        s2 = result["stages"]["candidate_cell"]
        if s2["candidate_scale"] <= 0 or s2["max_length_change_fraction"] > 0.12 or s2["max_angle_change_deg"] > 10:
            raise RuntimeError("cell/scale left admissible screen regime")
        result["status"] = "tested"
    except Exception as exc:
        result["status"] = "unknown"; result["reason"] = f"{type(exc).__name__}: {exc}"; result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    G2.SetPrintLevel("error")
    common = prepare_common()
    records = {r["candidate"]: r for f in ("candidate_ledger.json", "expanded_candidate_ledger.json") for r in json.loads((ROOT / f).read_text())}
    results = []
    for name in NAMES:
        result = test(common, records[name]); results.append(result)
        last = result["stages"].get("candidate_cell") or result["stages"].get("scale_background", {})
        print(name, result["status"], last.get("rwp_percent"), last.get("fractions", {}).get("trial__" + name), last.get("max_length_change_fraction"), result.get("reason") or "", flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
