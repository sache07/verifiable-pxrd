#!/usr/bin/env python3
"""Common-setting replacement screen for P212121 two-substitution models."""

from __future__ import annotations

import copy
import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_convergence" / "selected.gpx"
OUT = ROOT / ".tmp" / "two_substitution_screen_v2"
OLD = "mn2wo6_from_y2wo6_1541070"


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def active_phases(project, histogram):
    return [
        phase for phase in project.phases()
        if phase.data["Histograms"].get(histogram.name, {}).get("Use", True)
        and phase.data["Histograms"][histogram.name]["Scale"][0] > 0
    ]


def fractions(project, histogram):
    phases = active_phases(project, histogram)
    amounts = [
        float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][histogram.name]["Scale"][0])
        for phase in phases
    ]
    total = sum(amounts)
    return {phase.name: value / total for phase, value in zip(phases, amounts)}


def snapshot(project, histogram, candidate, start_cell, stage):
    phase = project.phase(candidate)
    cell = phase.get_cell()
    lengths = np.asarray([cell[k] for k in ("length_a", "length_b", "length_c")])
    angles = np.asarray([cell[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    hap = phase.data["Histograms"][histogram.name]
    return {
        "stage": stage,
        "rwp_percent": float(histogram.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        "message": rvals.get("msg", ""),
        "fractions": fractions(project, histogram),
        "cell": {k: float(v) for k, v in cell.items()},
        "max_length_change_fraction": float(np.max(np.abs(lengths / np.asarray(start_cell[:3]) - 1))),
        "max_angle_change_deg": float(np.max(np.abs(angles - np.asarray(start_cell[3:])))),
        "size": copy.deepcopy(hap["Size"]),
        "texture": copy.deepcopy(hap["Pref.Ori."]),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def refine(project, repeats, cycles):
    project.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(project)
        project.refine()


def test(record):
    name = record["candidate"]
    result = {"candidate": name, "source_cod_id": record["source_cod_id"], "status": "unknown", "reason": None, "stages": []}
    if not record["physical_screen"]["pass"]:
        result.update(status="rejected", reason="failed pre-fit O-O contact screen")
        return result
    try:
        folder = OUT / name
        folder.mkdir(parents=True, exist_ok=True)
        work = folder / "working.gpx"
        shutil.copy2(SOURCE, work)
        project = G2.G2Project(str(work))
        histogram = project.histograms()[0]
        old = project.phase(OLD)
        old_hap = old.data["Histograms"][histogram.name]
        old_hap["Use"] = False
        old_hap["Scale"] = [0.0, False]
        old.clear_refinements({"Cell": True})
        for atom in old.atoms():
            atom.refinement_flags = " "

        phase = project.add_phase(str((ROOT / record["path"]).resolve()), phasename=name, histograms=[histogram], fmthint="CIF")
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Use"] = True
        hap["Scale"] = [9.94, True]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        phase.clear_refinements({"Cell": True})
        cell = phase.get_cell()
        start = [cell[k] for k in ("length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma")]
        phase_id = int(phase.data["pId"])
        project.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")

        # Common admission: active scales and background only.
        inst = histogram.data["Instrument Parameters"][0]
        for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
            inst[key][2] = False
        for item in project.phases():
            item.clear_refinements({"Cell": True})
            for atom in item.atoms():
                atom.refinement_flags = " "
            item_hap = item.data["Histograms"].get(histogram.name)
            if item_hap and item_hap.get("Use", True) and item.name != OLD:
                item_hap["Scale"][1] = True
                item_hap["Size"][2] = [False, False, False]
                item_hap["Mustrain"][2] = [False, False, False]
                item_hap["Pref.Ori."][2] = False
        project.save(str(work))
        refine(project, repeats=2, cycles=12)
        result["stages"].append(snapshot(project, histogram, name, start, "scale_background"))
        if result["stages"][-1]["fractions"].get(name, 0.0) < 0.001:
            result.update(status="rejected", reason="scale collapsed in fixed-model admission test")
            return result

        # Candidate-cell test from the same nuisance model.
        phase.set_refinements({"Cell": True})
        refine(project, repeats=3, cycles=15)
        result["stages"].append(snapshot(project, histogram, name, start, "candidate_cell"))
        cell_stage = result["stages"][-1]
        if cell_stage["max_length_change_fraction"] > 0.15 or cell_stage["max_angle_change_deg"] > 8:
            result.update(status="unknown", reason="cell left the admissible analogue-screen regime")
            project.save(str(folder / "candidate_cell.gpx"))
            return result

        # Inventory admission deliberately stops here. Candidate profile terms
        # are compared only after a topology survives this common cell screen.
        result["status"] = "tested"
        project.save(str(folder / "candidate_cell.gpx"))
        project.data["Covariance"]["data"] = {}
        phase.export_CIF(str(folder / "candidate.cif"))
        return result

        # Identical integrated nuisance settings used for all surviving models.
        for key in ("Zero", "Polariz.", "U", "W", "X"):
            inst[key][2] = True
        for variable, lo, hi in [
            (":0:Zero", -0.5, 0.5), (":0:Polariz.", 0.5, 1.0),
            (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
            (f"{phase_id}:0:Size;i", 0.04, 1.5), (f"{phase_id}:0:MD", 0.7, 1.4),
        ]:
            project.set_Controls("parmMin", lo, variable)
            project.set_Controls("parmMax", hi, variable)
        for item in active_phases(project, histogram):
            item.set_refinements({"Cell": True})
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.08
        hap["Size"][2] = [True, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [0, 0, 1]
        # Restore the selected WO3 anisotropic strain for every branch.
        wo3 = project.phase("wo3_2311041").data["Histograms"][histogram.name]
        wo3["Mustrain"][0] = "uniaxial"
        wo3["Mustrain"][2] = [True, True, False]
        wo3["Mustrain"][3] = [0, 1, 0]
        project.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, "1:0:Mustrain;i")
        project.set_Controls("parmMin", 0.0, "1:0:Mustrain;a")
        project.set_Controls("parmMax", 32000.0, "1:0:Mustrain;a")
        refine(project, repeats=5, cycles=20)
        result["stages"].append(snapshot(project, histogram, name, start, "integrated_common"))
        final = result["stages"][-1]
        if final["frozen"]:
            result.update(status="unknown", reason="integrated branch froze a bounded parameter")
        elif not 0.04 < final["size"][1][0] < 1.5 or not 0.7 < final["texture"][1] < 1.4:
            result.update(status="rejected", reason="profile term reached a boundary")
        else:
            result["status"] = "tested"
        project.save(str(folder / "refined.gpx"))
        project.data["Covariance"]["data"] = {}
        phase.export_CIF(str(folder / "candidate.cif"))
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    records = json.loads((ROOT / "two_substitution_ledger.json").read_text())
    results = []
    for record in records:
        result = test(record)
        results.append(result)
        print(result["candidate"], result["status"], result["reason"], [(row["stage"], round(row["rwp_percent"], 5), round(row["fractions"].get(result["candidate"], 0), 5), round(row["max_length_change_fraction"], 4)) for row in result["stages"]], flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
