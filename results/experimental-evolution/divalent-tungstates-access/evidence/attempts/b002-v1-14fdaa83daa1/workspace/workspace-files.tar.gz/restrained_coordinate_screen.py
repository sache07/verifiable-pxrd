#!/usr/bin/env python3
"""Refine Mn2WO6 coordinates with source coordination-shell restraints."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_convergence" / "selected.gpx"
OUT = ROOT / ".tmp" / "restrained_heavy_strong_screen"
PHASE = "mn2wo6_from_y2wo6_1541070"
W_O = [1.774763, 1.791348, 1.849752, 1.876090, 1.885992, 1.964485]
MN_O = [2.082764, 2.179072, 2.192234, 2.210808, 2.215336, 2.232415, 2.236391,
        2.256027, 2.262472, 2.287127, 2.320964, 2.337895, 2.349619, 2.473204]
O_O = [2.395047, 2.423956, 2.447936, 2.525849, 2.573453, 2.589436,
       2.658922, 2.664273, 2.687273]
BRANCHES = {
    "very_strong": {"weight": 10000.0, "w_esd": 0.05, "mn_esd": 0.05, "o_esd": 0.10},
    "near_rigid": {"weight": 1000000.0, "w_esd": 0.05, "mn_esd": 0.05, "o_esd": 0.10},
}


def restraint_template():
    return {
        "Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True},
        "Angle": {"wtFactor": 1.0, "Range": 0.85, "Angles": [], "Use": True},
        "Plane": {"wtFactor": 1.0, "Planes": [], "Use": True},
        "Chiral": {"wtFactor": 1.0, "Volumes": [], "Use": True},
        "Torsion": {"wtFactor": 1.0, "Coeff": {}, "Torsions": [], "Use": True},
        "Rama": {"wtFactor": 1.0, "Coeff": {}, "Ramas": [], "Use": True},
        "Texture": {"wtFactor": 1.0, "HKLs": [], "Use": True},
        "SpinRB": {"wtFactor": 1.0, "SpinRBs": [], "Use": True},
        "ChemComp": {"wtFactor": 1.0, "Sites": [], "Use": True},
        "General": {"wtFactor": 1.0, "General": [], "Use": True},
    }


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project, histogram):
    amounts = [float(p.data["General"]["Mass"]) * float(p.data["Histograms"][histogram.name]["Scale"][0]) for p in project.phases()]
    total = sum(amounts)
    return {p.name: value / total for p, value in zip(project.phases(), amounts)}


def lattice_matrix(cell):
    a, b, c = (cell[k] for k in ("length_a", "length_b", "length_c"))
    alpha, beta, gamma = np.deg2rad([cell[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    vc = np.array([cx, cy, np.sqrt(max(0.0, c * c - cx * cx - cy * cy))])
    return np.vstack((va, vb, vc))


def run(label, settings):
    result = {"branch": label, "status": "unknown", "reason": None}
    try:
        folder = OUT / label
        folder.mkdir(parents=True, exist_ok=True)
        work = folder / "working.gpx"
        shutil.copy2(SOURCE, work)
        project = G2.G2Project(str(work))
        histogram = project.histograms()[0]
        phase = project.phase(PHASE)
        start = [np.asarray(atom.coordinates, float).copy() for atom in phase.atoms()]

        # Freeze all established nuisance/cell terms; retain active scales and
        # the common empirical background while testing coordinates.
        inst = histogram.data["Instrument Parameters"][0]
        for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
            inst[key][2] = False
        for item in project.phases():
            item.clear_refinements({"Cell": True})
            for atom in item.atoms(): atom.refinement_flags = " "
            hap = item.data["Histograms"][histogram.name]
            hap["Scale"][1] = True
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][2] = [False, False, False]
            hap["Pref.Ori."][2] = False
        for atom in phase.atoms(): atom.refinement_flags = "X" if atom.element != "O" else " "

        project.data["Restraints"]["data"][PHASE] = restraint_template()
        watoms = [atom for atom in phase.atoms() if atom.element == "W"]
        mnatoms = [atom for atom in phase.atoms() if atom.element == "Mn"]
        oatoms = [atom for atom in phase.atoms() if atom.element == "O"]
        counts = {"W-O": 0, "Mn-O": 0, "O-O": 0}
        for distance in W_O:
            counts["W-O"] += phase.addDistRestraint(watoms, oatoms, distance, factor=1.0025, ESD=settings["w_esd"])
        for distance in MN_O:
            counts["Mn-O"] += phase.addDistRestraint(mnatoms, oatoms, distance, factor=1.0020, ESD=settings["mn_esd"])
        phase.setDistRestraintWeight(settings["weight"])
        project.save(str(work))
        project.set_Controls("cycles", 20)
        history = []
        for iteration in range(2):
            clear_frozen(project)
            project.refine()
            rvals = project.data["Covariance"]["data"]["Rvals"]
            history.append({
                "iteration": iteration + 1,
                "rwp_percent": float(histogram.get_wR()),
                "gof": float(rvals["GOF"]),
                "max_shift_over_esd": float(rvals["Max shft/sig"]),
                "converged": bool(rvals["converged"]),
                "message": rvals.get("msg", ""),
                "restraint_sum": float(rvals.get("RestraintSum", np.nan)),
                "fractions": fractions(project, histogram),
                "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
            })
            if history[-1]["converged"] and history[-1]["max_shift_over_esd"] < 0.05:
                break
        matrix = lattice_matrix(phase.get_cell())
        displacements = []
        for atom, initial in zip(phase.atoms(), start):
            delta = np.asarray(atom.coordinates) - initial
            delta -= np.round(delta)
            displacements.append(float(np.linalg.norm(delta @ matrix)))
        final = history[-1]
        result.update(
            status="tested" if not final["frozen"] else "unknown",
            reason=None if not final["frozen"] else "bounded nuisance parameter froze",
            settings=settings,
            restraint_counts=counts,
            maximum_unique_atom_displacement_A=max(displacements),
            rms_unique_atom_displacement_A=float(np.sqrt(np.mean(np.square(displacements)))),
            displacements_A=displacements,
            history=history,
            final=final,
        )
        project.save(str(folder / "refined.gpx"))
        project.data["Covariance"]["data"] = {}
        for index, item in enumerate(project.phases()):
            item.export_CIF(str(folder / f"phase_{index}.cif"))
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    print(label, json.dumps(result), flush=True)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(label, settings) for label, settings in BRANCHES.items()]
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
