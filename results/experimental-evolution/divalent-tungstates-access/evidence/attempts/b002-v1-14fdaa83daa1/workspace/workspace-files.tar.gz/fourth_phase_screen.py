#!/usr/bin/env python3
"""Scale/background then candidate-cell screen for phase closure."""

from __future__ import annotations

import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "integrated" / "02_phase_uiso.gpx"
OUT = ROOT / ".tmp" / "fourth_phase_screen"
EXISTING = ["MnWO4_wolframite", "wo3_2311041", "mn2wo6_from_y2wo6_1541070"]


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(p, repeats=2, cycles=12):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(0.0, value) for _, value in vals)
    return {name: max(0.0, value) / total for name, value in vals} if total else {}


def snap(p, candidate, start_cell):
    h = p.histograms()[0]
    phase = p.phase(candidate)
    c = phase.get_cell()
    current = np.array([c[k] for k in ("length_a", "length_b", "length_c")])
    angles = np.array([c[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "rwp_percent": float(h.get_wR()),
        "fractions": fractions(p, h),
        "candidate_scale": float(phase.data["Histograms"][h.name]["Scale"][0]),
        "cell": [*map(float, current), *map(float, angles)],
        "max_length_change_fraction": float(np.max(np.abs(current / np.asarray(start_cell[:3]) - 1))),
        "max_angle_change_deg": float(np.max(np.abs(angles - np.asarray(start_cell[3:])))),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
    }


def prepare_common():
    OUT.mkdir(parents=True, exist_ok=True)
    path = OUT / "common_three_phase.gpx"
    shutil.copy2(SOURCE, path)
    p = G2.G2Project(str(path))
    h = p.histograms()[0]
    assert [phase.name for phase in p.phases()] == EXISTING
    clear_frozen(p)
    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
        h.data["Instrument Parameters"][0][key][2] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        h.data["Sample Parameters"][key][1] = False
    for phase_id, phase in enumerate(p.phases()):
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
            if phase_id < 2:
                atom.uiso = 0.003
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    p.save(str(path))
    run(p)
    p.save(str(path))
    print("common", h.get_wR(), fractions(p, h), flush=True)
    return path


def trial(common, record):
    short = record["candidate"]
    name = "trial__" + short
    result = {"candidate": short, "status": "unknown", "reason": None, "stages": {}}
    try:
        branch = OUT / short
        branch.mkdir(parents=True, exist_ok=True)
        work = branch / "working.gpx"
        shutil.copy2(common, work)
        p = G2.G2Project(str(work))
        h = p.histograms()[0]
        assert [phase.name for phase in p.phases()] == EXISTING
        phase = p.add_phase(str((ROOT / record["path"]).resolve()), phasename=name, histograms=[h], fmthint="CIF")
        assert p.phases()[-1].name == name
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        phase.clear_refinements({"Cell": True})
        c = phase.get_cell()
        start = [c[k] for k in ("length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma")]
        p.set_Controls("parmMin", 0.0, "3:0:Scale")
        p.save(str(work))

        run(p, repeats=2, cycles=10)
        result["stages"]["scale_background"] = snap(p, name, start)
        p.save(str(branch / "scale_background.gpx"))
        s1 = result["stages"]["scale_background"]
        if not math.isfinite(s1["candidate_scale"]) or s1["candidate_scale"] <= 1e-10 or s1["fractions"].get(name, 0.0) < 0.0005:
            result.update(status="rejected", reason="scale collapsed in fixed-model admission test")
            return result

        phase.set_refinements({"Cell": True})
        run(p, repeats=2, cycles=12)
        result["stages"]["candidate_cell"] = snap(p, name, start)
        p.save(str(branch / "candidate_cell.gpx"))
        s2 = result["stages"]["candidate_cell"]
        if s2["candidate_scale"] <= 0 or s2["max_length_change_fraction"] > 0.12 or s2["max_angle_change_deg"] > 10:
            raise RuntimeError("cell/scale left admissible screen regime")
        result["status"] = "tested"
    except Exception as exc:
        result["status"] = "unknown"
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    G2.SetPrintLevel("error")
    common = prepare_common()
    ledger = json.loads((ROOT / "candidate_ledger.json").read_text())
    skip = {"mnwo4_direct_1520200", "wo3_2311041", "mn2wo6_from_y2wo6_1541070"}
    records = [r for r in ledger if r["candidate"] not in skip]
    results = []
    for record in records:
        result = trial(common, record)
        results.append(result)
        last = result["stages"].get("candidate_cell") or result["stages"].get("scale_background", {})
        print(record["candidate"], result["status"], "Rwp", last.get("rwp_percent"), "fraction", last.get("fractions", {}).get("trial__" + record["candidate"]), result.get("reason") or "", flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
