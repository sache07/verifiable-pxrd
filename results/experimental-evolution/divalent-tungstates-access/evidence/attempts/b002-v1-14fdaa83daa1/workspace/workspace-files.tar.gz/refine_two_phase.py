#!/usr/bin/env python3
"""Staged two-phase refinement of wolframite MnWO4 plus monoclinic WO3."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp" / "cofit_screen" / "wo3_2311041" / "zero_cells.gpx"
OUT = ROOT / ".tmp" / "two_phase"
MN = "MnWO4_wolframite"
WO = "wo3_2311041"


def mass_fractions(project, histogram):
    values = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        values.append((phase.name, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])))
    total = sum(max(v, 0.0) for _, v in values)
    return {name: max(v, 0.0) / total for name, v in values}


def diag(project, label):
    histogram = project.histograms()[0]
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    arrays = histogram.data["data"][1]
    x, obs, wt, calc, background = map(np.asarray, arrays[:5])
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(map(float, atom.coordinates)),
                    "uiso_A2": float(atom.uiso),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    return {
        "stage": label,
        "rwp_percent": float(histogram.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        "message": rvals.get("msg", ""),
        "chi_square": float(np.sum(wt * (obs - calc) ** 2)),
        "background_min": float(background.min()),
        "calculated_min": float(calc.min()),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: float(sample[k][0]) for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "fractions": mass_fractions(project, histogram),
        "phases": phases,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def sane(d):
    if d["background_min"] < 0 or d["calculated_min"] < 0:
        return False
    if abs(sum(d["fractions"].values()) - 1) > 1e-8 or min(d["fractions"].values()) <= 0:
        return False
    i = d["instrument"]
    if not (-0.5 <= i["Zero"] <= 0.5 and 0 <= i["U"] <= 100 and 0 <= i["W"] <= 100 and 0 <= i["X"] <= 20 and 0.001 <= i["SH/L"] <= 0.2 and 0 <= i["Polariz."] <= 1):
        return False
    for p in d["phases"].values():
        c = p["cell"]
        if not all(3 < c[k] < 15 for k in ("length_a", "length_b", "length_c")):
            return False
        if not all(40 < c[k] < 150 for k in ("angle_alpha", "angle_beta", "angle_gamma")):
            return False
        if not all(0.0001 <= a["uiso_A2"] <= 0.05 for a in p["atoms"]):
            return False
    return True


def checkpoint(project, label, history):
    d = diag(project, label)
    if not sane(d):
        raise RuntimeError("unphysical stage " + label + ": " + json.dumps(d, indent=2))
    project.save(str(OUT / f"{label}.gpx"))
    history.append(d)
    print(
        f"{label:<28} Rwp={d['rwp_percent']:.5f}% GOF={d['gof']:.3f} "
        f"fractions={d['fractions']} maxshift={d['max_shift_over_esd']:.3g}"
    )
    return d


def refine(project, label, history, repeats=3, cycles=12):
    project.set_Controls("cycles", cycles)
    for _ in range(repeats):
        project.refine()
        r = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if r.get("converged") and float(r.get("Max shft/sig", 999)) < 0.05:
            break
    return checkpoint(project, label, history)


def set_limits(project):
    for var, low, high in [
        (":0:Zero", -0.5, 0.5),
        (":0:U", 0.0, 100.0),
        (":0:W", 0.0, 100.0),
        (":0:X", 0.1, 20.0),
        (":0:SH/L", 0.001, 0.2),
        (":0:Shift", -1000.0, 1000.0),
        (":0:Polariz.", 0.0, 1.0),
        ("1:0:Size;i", 0.04, 1.5),
        ("1:0:Mustrain;i", 0.0, 10000.0),
    ]:
        project.set_Controls("parmMin", low, var)
        project.set_Controls("parmMax", high, var)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    work = OUT / "working.gpx"
    shutil.copy2(START, work)
    project = G2.G2Project(str(work))
    histogram = project.histograms()[0]
    mn = project.phase(MN)
    wo = project.phase(WO)
    assert [p.name for p in project.phases()] == [MN, WO]
    assert histogram.SampleParameters["Scale"][1] is False
    for phase in (mn, wo):
        hap = phase.data["Histograms"][histogram.name]
        if hap["Scale"][0] <= 0:
            raise RuntimeError("phase lacks a positive initialized scale: " + phase.name)
        hap["Scale"][1] = True
        # Use the reference-library Uiso convention before thermal refinement.
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
        # The sharp principal phase defines the common isotropic width. The
        # second phase receives only relative phase-specific broadening.
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.5 if phase.name == MN else 0.15
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
    histogram.SampleParameters["Shift"] = [0.0, False]
    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"] = [0.0, False]
    project.save(str(work))
    set_limits(project)
    history = []
    checkpoint(project, "00_inventory", history)

    # Common isotropic instrumental profile.
    histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "01_profile_wx", history)
    histogram.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    refine(project, "02_profile_common", history)

    # Relative broadening of the visibly broader WO3 family, one supported
    # isotropic term at a time.
    wo.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.15, "refine": True}},
        histograms=[histogram],
    )
    refine(project, "03_wo3_size", history)
    wo.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}},
        histograms=[histogram],
    )
    refine(project, "04_wo3_size_strain", history)

    # Whole-specimen shift, with common zero and both cells retained.
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "05_specimen_shift", history)

    # Heavy-atom positions first; oxygen coordinates are admitted only in the
    # following stage so their incremental support is explicit.
    for phase in (mn, wo):
        flags = {a.label: ("X" if a.element in {"Mn", "W"} else " ") for a in phase.atoms()}
        phase.set_refinements({"Atoms": flags})
    refine(project, "06_heavy_coordinates", history, repeats=4, cycles=15)
    for phase in (mn, wo):
        phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "07_all_coordinates", history, repeats=4, cycles=15)

    # One isotropic displacement value per phase, matching the synthetic
    # specimen convention and avoiding unconstrained atom-by-atom collapse.
    for phase_id, phase in enumerate((mn, wo)):
        for atom in phase.atoms():
            atom.refinement_flags = "XU"
        variables = [f"{phase_id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        for var in variables:
            project.set_Controls("parmMin", 0.0001, var)
            project.set_Controls("parmMax", 0.05, var)
    refine(project, "08_phase_uiso", history, repeats=4, cycles=15)

    histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "09_simple_two_phase", history, repeats=4, cycles=15)
    project.save(str(OUT / "simple_two_phase.gpx"))
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    a = histogram.data["data"][1]
    np.savetxt(
        OUT / "simple_profile.csv",
        np.column_stack((a[0], a[1], a[3], a[1] - a[3], a[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )


if __name__ == "__main__":
    main()
