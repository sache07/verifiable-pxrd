#!/usr/bin/env python3
"""Place isostructural Mn2WO6 relatives in the indexed orthorhombic cell."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
CELL = (4.831852001860202, 8.9323430682213, 9.78201951916813)
SOURCE_IDS = ["8100234", "1535177", "1541070", "2213598"]


def main():
    source = {row["source_cod_id"]: row for row in json.loads((ROOT / "two_substitution_ledger.json").read_text())}
    rows = []
    for cod_id in SOURCE_IDS:
        parent = source[cod_id]
        structure = Structure.from_file(ROOT / parent["path"], primitive=False)
        structure = Structure(
            Lattice.orthorhombic(*CELL),
            structure.species,
            structure.frac_coords,
            site_properties=structure.site_properties,
        )
        name = f"mn2wo6_indexed_relative_{cod_id}"
        path = ROOT / "candidates" / f"{name}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(path)
        parsed = Structure.from_file(path, primitive=False)
        rows.append(
            {
                "candidate": name,
                "path": str(path.relative_to(ROOT)),
                "source_cod_id": cod_id,
                "source_formula": parent["source_formula"],
                "substitutions": parent["substitutions"],
                "cell_basis": "common indexed cell from the stable Y2WO6-topology fit",
                "space_group": parsed.get_space_group_info(symprec=1e-3)[0],
                "space_group_number": parsed.get_space_group_info(symprec=1e-3)[1],
                "sites_in_cell": len(parsed),
                "density_g_cm3": float(parsed.density),
                "status": "pending",
            }
        )
    (ROOT / "indexed_relative_ledger.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
