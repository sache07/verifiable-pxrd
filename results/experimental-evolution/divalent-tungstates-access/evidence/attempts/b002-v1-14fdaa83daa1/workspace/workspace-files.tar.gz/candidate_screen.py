#!/usr/bin/env python3
"""Identity-safe one-phase GSAS-II screening from a common nuisance setup."""

from __future__ import annotations

import argparse
import json
import math
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
TMP = ROOT / ".tmp" / "candidate_screen"
PROJECTS = TMP / "projects"


def prepare_observation() -> tuple[Path, Path]:
    TMP.mkdir(parents=True, exist_ok=True)
    PROJECTS.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = TMP / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst = TMP / "screen.instprm"
    inst.write_text(
        "# GSAS-II common screening instrument; all branches start identically\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def finite_number(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return None
    return value if math.isfinite(value) else None


def snapshot(project, phase, histogram, starting_cell):
    hap = phase.data["Histograms"][histogram.name]
    cell = phase.get_cell()
    current = np.array([cell[k] for k in ("length_a", "length_b", "length_c")], dtype=float)
    angles = np.array([cell[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")], dtype=float)
    start_lengths = np.array(starting_cell[:3], dtype=float)
    start_angles = np.array(starting_cell[3:6], dtype=float)
    inst = histogram.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "rwp_percent": finite_number(histogram.get_wR()),
        "phase_scale": finite_number(hap["Scale"][0]),
        "cell": [*current.tolist(), *angles.tolist()],
        "max_length_change_fraction": float(np.max(np.abs(current / start_lengths - 1.0))),
        "max_angle_change_deg": float(np.max(np.abs(angles - start_angles))),
        "zero_deg": finite_number(inst["Zero"][1]),
        "vary_list": [str(v) for v in cov.get("varyList", [])],
        "converged": bool(cov.get("Rvals", {}).get("converged", False)),
    }


def screen(record, xye, instfile):
    name = record["candidate"]
    cif = (ROOT / record["path"]).resolve()
    gpx = PROJECTS / f"{name}.gpx"
    result = {
        "candidate": name,
        "cif": str(cif.relative_to(ROOT)),
        "status": "unknown",
        "reason": None,
        "stages": {},
    }
    try:
        project = G2.G2Project(newgpx=str(gpx))
        phase = project.add_phase(str(cif), phasename=name, fmthint="CIF")
        histogram = project.add_powder_histogram(
            str(xye), str(instfile), phases=[phase], fmthint="xye"
        )
        # Identity and initialization checks required before every branch fit.
        assert len(project.phases()) == 1
        assert project.phase(name).name == name
        assert list(phase.data["Histograms"]) == [histogram.name]
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [1.0, False]
        assert hap["Scale"][0] > 0
        histogram.SampleParameters["Type"] = "Bragg-Brentano"
        histogram.SampleParameters["Gonio. radius"] = 200.0
        histogram.SampleParameters["Shift"] = [0.0, False]
        histogram.set_refinements({
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1600.0] + [0.0] * 9,
                "refine": True,
            },
        })
        phase.set_HAP_refinements({"Scale": True}, histograms=[histogram])
        starting_cell_dict = phase.get_cell()
        starting_cell = [
            starting_cell_dict[k]
            for k in (
                "length_a", "length_b", "length_c",
                "angle_alpha", "angle_beta", "angle_gamma",
            )
        ]
        project.set_Controls("cycles", 8)
        # Stage 1: only scale and common background basis.
        project.refine()
        result["stages"]["scale_background"] = snapshot(
            project, phase, histogram, starting_cell
        )
        if not (hap["Scale"][0] > 0 and math.isfinite(hap["Scale"][0])):
            raise RuntimeError("nonpositive or nonfinite refined scale")
        project.save(str(gpx))
        # Stage 2: retain exactly the same nuisance basis, then permit a common
        # zero and symmetry-independent cell terms for analogue mismatch.
        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
        phase.set_refinements({"Cell": True})
        project.set_Controls("cycles", 6)
        project.refine()
        result["stages"]["zero_cell"] = snapshot(project, phase, histogram, starting_cell)
        stage = result["stages"]["zero_cell"]
        if stage["phase_scale"] is None or stage["phase_scale"] <= 0:
            raise RuntimeError("cell-stage scale collapsed or became invalid")
        if stage["max_length_change_fraction"] > 0.10 or stage["max_angle_change_deg"] > 10:
            raise RuntimeError("cell stage left the physically modest analogue-mismatch regime")
        project.save(str(gpx))
        result["status"] = "tested"
    except Exception as exc:
        result["status"] = "unknown"
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--only", action="append", default=[])
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    xye, instfile = prepare_observation()
    ledger = json.loads((ROOT / "candidate_ledger.json").read_text())
    selected = [r for r in ledger if not args.only or r["candidate"] in set(args.only)]
    results = [screen(record, xye, instfile) for record in selected]
    out = TMP / ("screen_results.json" if not args.only else "screen_partial.json")
    out.write_text(json.dumps(results, indent=2) + "\n")
    for result in results:
        stages = result["stages"]
        s1 = stages.get("scale_background", {})
        s2 = stages.get("zero_cell", {})
        print(
            f"{result['candidate']:<42} {result['status']:<7} "
            f"Rwp1={s1.get('rwp_percent')} Rwp2={s2.get('rwp_percent')} "
            f"scale={s2.get('phase_scale', s1.get('phase_scale'))} "
            f"dcell={s2.get('max_length_change_fraction')} {result.get('reason') or ''}"
        )


if __name__ == "__main__":
    main()
