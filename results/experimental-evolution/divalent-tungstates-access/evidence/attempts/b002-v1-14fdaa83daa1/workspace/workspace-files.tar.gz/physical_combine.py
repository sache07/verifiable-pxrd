#!/usr/bin/env python3
"""Combine the two supported Mn2WO6 profile terms, then restore common terms."""

from __future__ import annotations

import copy
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "physical_branches" / "common.gpx"
OUT = ROOT / ".tmp" / "physical_combined"


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(v, 0.0) for _, v in vals)
    return {n: max(v, 0.0) / total for n, v in vals}


def run(p, repeats=4, cycles=18):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()


def snap(p, stage):
    h = p.histograms()[0]
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    inst = h.data["Instrument Parameters"][0]
    return {
        "stage": stage,
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "fractions": fractions(p, h),
        "instrument": {k: [float(inst[k][1]), bool(inst[k][2])] for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
        "phases": {
            phase.name: {
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
                "size": copy.deepcopy(phase.data["Histograms"][h.name]["Size"]),
                "microstrain": copy.deepcopy(phase.data["Histograms"][h.name]["Mustrain"]),
                "texture": copy.deepcopy(phase.data["Histograms"][h.name]["Pref.Ori."]),
            }
            for phase in p.phases()
        },
    }


def checkpoint(p, label, history):
    d = snap(p, label)
    p.save(str(OUT / f"{label}.gpx"))
    history.append(d)
    print(label, json.dumps(d), flush=True)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    work = OUT / "working.gpx"
    shutil.copy2(SOURCE, work)
    p = G2.G2Project(str(work))
    h = p.histograms()[0]
    clear_frozen(p)
    phase = p.phases()[2]
    hap = phase.data["Histograms"][h.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.08
    hap["Size"][1][1] = 0.08
    hap["Size"][2] = [True, False, False]
    p.set_Controls("parmMin", 0.04, "2:0:Size;i")
    p.set_Controls("parmMax", 1.5, "2:0:Size;i")
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.25
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = [0, 0, 1]
    p.set_Controls("parmMin", 0.7, "2:0:MD")
    p.set_Controls("parmMax", 1.4, "2:0:MD")
    p.save(str(work))
    history = []
    run(p, repeats=3, cycles=14)
    checkpoint(p, "01_size_texture", history)

    # Restore the common instrument and cell variables only after the two
    # phase-specific terms have demonstrated a stable joint contribution.
    inst = h.data["Instrument Parameters"][0]
    for key in ("Zero", "Polariz.", "U", "W", "X"):
        inst[key][2] = True
    for var, lo, hi in [
        (":0:Zero", -0.5, 0.5), (":0:Polariz.", 0.5, 1.0),
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
    ]:
        p.set_Controls("parmMin", lo, var)
        p.set_Controls("parmMax", hi, var)
    for item in p.phases():
        item.set_refinements({"Cell": True})
        for atom in item.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
    # WO3 isotropic strain is interior and remains refinable. The analogue
    # strain is held at its simpler isotropic rollback value.
    p.phases()[1].data["Histograms"][h.name]["Mustrain"][2] = [True, False, False]
    p.set_Controls("parmMin", 0.0, "1:0:Mustrain;i")
    p.set_Controls("parmMax", 8000.0, "1:0:Mustrain;i")
    p.phases()[2].data["Histograms"][h.name]["Mustrain"][2] = [False, False, False]
    p.save(str(work))
    run(p, repeats=5, cycles=20)
    checkpoint(p, "02_common_terms", history)
    p.save(str(OUT / "combined.gpx"))
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
