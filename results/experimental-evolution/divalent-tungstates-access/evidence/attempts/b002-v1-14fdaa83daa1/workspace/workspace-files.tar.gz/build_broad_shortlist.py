#!/usr/bin/env python3
"""Construct the top chemistry- and symmetry-diverse two-substitution models."""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
SEARCH = ROOT / ".tmp" / "broad_two_substitution_search.json"
SOURCE_IDS = [
    "2242674",  # Mn3WO6, R-3
    "9015147",  # Mn2WO5, Pnnm
    "9000178",  # Mn2WO5, Pnnm, direct Mn parent
    "1524664",  # Mn2WO5, Pnnm, Co parent
    "9011171",  # Mn2WO5, P21/c
    "4030285",  # Mn3W2O12, P21/c
    "6000107",  # Mn3W2O12, Pbcn
    "9004359",  # Mn2WO6, P21/c
    "1536075",  # Mn2WO6, P6522
    "1552115",  # Mn3W2O9, Cc
    "1544872",  # Mn2W2O9, Cc
]


def physical(structure):
    centers, neighbors, images, distances = structure.get_neighbor_list(3.5)
    all_distances, oxygen_distances = [], []
    for i, j, image, distance in zip(centers, neighbors, images, distances):
        if i > j or (i == j and tuple(image) <= (0, 0, 0)):
            continue
        all_distances.append(float(distance))
        if structure[int(i)].species_string == "O" and structure[int(j)].species_string == "O":
            oxygen_distances.append(float(distance))
    return {
        "minimum_interatomic_distance_A": min(all_distances),
        "minimum_O_O_distance_A": min(oxygen_distances),
        "pass": min(all_distances) >= 0.8 and min(oxygen_distances) >= 1.8,
    }


def main():
    search = json.loads(SEARCH.read_text())
    selected = {}
    for record in search:
        cod_id = record["source_cod_id"]
        if cod_id in SOURCE_IDS and cod_id not in selected and record.get("status") == "tested":
            selected[cod_id] = record
    missing = set(SOURCE_IDS) - set(selected)
    if missing:
        raise RuntimeError(f"shortlist IDs missing from full-profile search: {sorted(missing)}")
    rows = []
    for cod_id in SOURCE_IDS:
        source = selected[cod_id]
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(source["source_path"], primitive=False)
        structure.remove_oxidation_states()
        structure.replace_species(source["substitutions"])
        structure.remove_oxidation_states()
        name = f"broad_{source['target_formula'].replace('(', '').replace(')', '')}_{cod_id}".lower()
        path = ROOT / "candidates" / f"{name}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(path)
        parsed = Structure.from_file(path, primitive=False)
        screen = physical(parsed)
        rows.append(
            {
                "candidate": name,
                "path": str(path.relative_to(ROOT)),
                "source_cod_id": cod_id,
                "source_formula": source["source_formula"],
                "substitutions": source["substitutions"],
                "target_formula": parsed.composition.reduced_formula,
                "space_group": parsed.get_space_group_info(symprec=1e-3)[0],
                "space_group_number": parsed.get_space_group_info(symprec=1e-3)[1],
                "cell": list(map(float, parsed.lattice.parameters)),
                "sites_in_cell": len(parsed),
                "density_g_cm3": float(parsed.density),
                "profile_search_improvement_fraction": source["profile_improvement_fraction"],
                "profile_search_lattice_scale": source["lattice_scale"],
                "physical_screen": screen,
                "status": "pending",
            }
        )
    (ROOT / "broad_shortlist_ledger.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
