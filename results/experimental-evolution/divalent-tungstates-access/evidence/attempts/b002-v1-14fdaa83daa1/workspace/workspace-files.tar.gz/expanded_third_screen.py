#!/usr/bin/env python3
"""Common two-phase checkpoint screen for the expanded Mn-W-O shortlist."""

from __future__ import annotations

import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "two_phase" / "04_wo3_size_strain.gpx"
OUT = ROOT / ".tmp" / "expanded_third_screen"
EXISTING = ["MnWO4_wolframite", "wo3_2311041"]


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(p, repeats=2, cycles=12):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(v, 0.0) for _, v in vals)
    return {n: max(v, 0.0) / total for n, v in vals} if total else {}


def snap(p, h, name, start):
    phase = p.phase(name)
    c = phase.get_cell()
    lengths = np.array([c[k] for k in ("length_a", "length_b", "length_c")])
    angles = np.array([c[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "rwp_percent": float(h.get_wR()),
        "fractions": fractions(p, h),
        "candidate_scale": float(phase.data["Histograms"][h.name]["Scale"][0]),
        "cell": [*map(float, lengths), *map(float, angles)],
        "max_length_change_fraction": float(np.max(np.abs(lengths / np.asarray(start[:3]) - 1))),
        "max_angle_change_deg": float(np.max(np.abs(angles - np.asarray(start[3:])))),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
    }


def test(record):
    short = record["candidate"]
    result = {"candidate": short, "status": "unknown", "reason": None, "stages": {}}
    oo = record.get("physical_screen", {}).get("minimum_O_O_distance_A")
    dmin = record.get("physical_screen", {}).get("minimum_interatomic_distance_A")
    if (dmin is not None and dmin < 0.8) or (oo is not None and oo < 1.8):
        result.update(status="rejected", reason="failed pre-fit hard-contact/oxide O-O screen")
        return result
    try:
        branch = OUT / short
        branch.mkdir(parents=True, exist_ok=True)
        work = branch / "working.gpx"
        shutil.copy2(BASE, work)
        p = G2.G2Project(str(work))
        h = p.histograms()[0]
        assert [phase.name for phase in p.phases()] == EXISTING
        inst = h.data["Instrument Parameters"][0]
        for key in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
            inst[key][2] = False
        for key in ("Shift", "SurfRoughA", "SurfRoughB"):
            h.data["Sample Parameters"][key][1] = False
        h.data["Sample Parameters"]["Scale"] = [1.0, False]
        for phase in p.phases():
            phase.clear_refinements({"Cell": True})
            for atom in phase.atoms():
                atom.refinement_flags = " "
            hap = phase.data["Histograms"][h.name]
            hap["Scale"][1] = True
            hap["Size"][2] = [False, False, False]
            hap["Mustrain"][2] = [False, False, False]
            hap["Pref.Ori."][2] = False

        phase = p.add_phase(str((ROOT / record["path"]).resolve()), phasename=short, histograms=[h], fmthint="CIF")
        assert [phase.name for phase in p.phases()] == [*EXISTING, short]
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        phase.clear_refinements({"Cell": True})
        c = phase.get_cell()
        start = [c[k] for k in ("length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma")]
        p.set_Controls("parmMin", 0.0, "2:0:Scale")
        p.save(str(work))

        run(p, repeats=2, cycles=10)
        result["stages"]["scale_background"] = snap(p, h, short, start)
        s1 = result["stages"]["scale_background"]
        if not math.isfinite(s1["candidate_scale"]) or s1["candidate_scale"] <= 1e-10 or s1["fractions"].get(short, 0.0) < 0.0005:
            result.update(status="rejected", reason="scale collapsed in common admission test")
            return result

        inst["Zero"][2] = True
        for item in p.phases():
            item.set_refinements({"Cell": True})
        run(p, repeats=2, cycles=12)
        result["stages"]["zero_cells"] = snap(p, h, short, start)
        p.save(str(branch / "zero_cells.gpx"))
        s2 = result["stages"]["zero_cells"]
        if s2["candidate_scale"] <= 0 or s2["max_length_change_fraction"] > 0.12 or s2["max_angle_change_deg"] > 10:
            raise RuntimeError("cell/scale left admissible prototype-screen regime")
        result["status"] = "tested"
    except Exception as exc:
        result["status"] = "unknown"
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for record in json.loads((ROOT / "expanded_candidate_ledger.json").read_text()):
        result = test(record)
        results.append(result)
        last = result["stages"].get("zero_cells") or result["stages"].get("scale_background", {})
        print(record["candidate"], result["status"], "Rwp", last.get("rwp_percent"), "fraction", last.get("fractions", {}).get(record["candidate"]), "cell_change", last.get("max_length_change_fraction"), result.get("reason") or "", flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
