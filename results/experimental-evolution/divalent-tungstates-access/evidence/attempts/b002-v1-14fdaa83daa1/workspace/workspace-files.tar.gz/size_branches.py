#!/usr/bin/env python3
"""Common-checkpoint tests of phase-specific size and strain terms."""

from __future__ import annotations

import copy
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "profile_branches" / "U_X.gpx"
OUT = ROOT / ".tmp" / "size_branches"


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(p, repeats=3, cycles=14):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()


def snap(p):
    h = p.histograms()[0]
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "profiles": {
            phase.name: {
                "size": copy.deepcopy(phase.data["Histograms"][h.name]["Size"]),
                "microstrain": copy.deepcopy(phase.data["Histograms"][h.name]["Mustrain"]),
            }
            for phase in p.phases()
        },
    }


def prepare(source, destination):
    shutil.copy2(source, destination)
    p = G2.G2Project(str(destination))
    clear_frozen(p)
    for phase in p.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    p.save(str(destination))
    return p


def activate_size(p, indices):
    h = p.histograms()[0]
    for i in indices:
        hap = p.phases()[i].data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.35
        hap["Size"][1][1] = 0.35
        hap["Size"][2] = [True, False, False]
        p.set_Controls("parmMin", 0.04, f"{i}:0:Size;i")
        p.set_Controls("parmMax", 1.5, f"{i}:0:Size;i")


def activate_strain0(p):
    h = p.histograms()[0]
    hap = p.phases()[0].data["Histograms"][h.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1500.0
    hap["Mustrain"][1][1] = 1500.0
    hap["Mustrain"][2] = [True, False, False]
    p.set_Controls("parmMin", 0.0, "0:0:Mustrain;i")
    p.set_Controls("parmMax", 8000.0, "0:0:Mustrain;i")


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = {}
    branches = {
        "size_phase0": ([0], False),
        "size_phase1": ([1], False),
        "size_phase2": ([2], False),
        "size_all": ([0, 1, 2], False),
        "size_all_strain0": ([0, 1, 2], True),
    }
    for name, (indices, strain0) in branches.items():
        path = OUT / f"{name}.gpx"
        p = prepare(SOURCE, path)
        activate_size(p, indices)
        if strain0:
            activate_strain0(p)
        p.save(str(path))
        run(p)
        p.save(str(path))
        results[name] = snap(p)
        print(name, json.dumps(results[name]), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
