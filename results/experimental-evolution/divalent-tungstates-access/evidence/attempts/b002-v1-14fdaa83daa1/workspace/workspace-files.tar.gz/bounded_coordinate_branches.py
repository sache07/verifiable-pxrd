#!/usr/bin/env python3
"""Test limited coordinate corrections while preserving the stable rollback."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_convergence" / "selected.gpx"
OUT = ROOT / ".tmp" / "bounded_coordinate_branches_v2"
BRANCHES = {
    "wo3_oxygen": ("wo3_2311041", lambda element: element == "O"),
    "wo3_all": ("wo3_2311041", lambda element: True),
    "mn2wo6_heavy": ("mn2wo6_from_y2wo6_1541070", lambda element: element != "O"),
    "mn2wo6_oxygen": ("mn2wo6_from_y2wo6_1541070", lambda element: element == "O"),
    "mn2wo6_all": ("mn2wo6_from_y2wo6_1541070", lambda element: True),
}
STEP_BOUND = 0.006


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project, histogram):
    amounts = [
        float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][histogram.name]["Scale"][0])
        for phase in project.phases()
    ]
    total = sum(amounts)
    return {phase.name: value / total for phase, value in zip(project.phases(), amounts)}


def displacements(phase, start):
    cell = phase.get_cell()
    a, b, c = (cell[k] for k in ("length_a", "length_b", "length_c"))
    alpha, beta, gamma = np.deg2rad([cell[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gamma), b * np.sin(gamma), 0.0])
    cx = c * np.cos(beta)
    cy = c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma)
    vc = np.array([cx, cy, np.sqrt(max(0.0, c * c - cx * cx - cy * cy))])
    matrix = np.vstack((va, vb, vc))
    rows = []
    for index, (atom, initial) in enumerate(zip(phase.atoms(), start)):
        delta = np.asarray(atom.coordinates) - initial
        delta -= np.round(delta)
        rows.append({"index": index, "label": atom.label, "element": atom.element, "distance_A": float(np.linalg.norm(delta @ matrix)), "fractional_delta": delta.tolist()})
    return rows


def run(label, phase_name, selector):
    result = {"branch": label, "status": "unknown", "reason": None}
    try:
        folder = OUT / label
        folder.mkdir(parents=True, exist_ok=True)
        work = folder / "working.gpx"
        shutil.copy2(SOURCE, work)
        project = G2.G2Project(str(work))
        histogram = project.histograms()[0]
        phase = project.phase(phase_name)
        phase_index = [p.name for p in project.phases()].index(phase_name)
        start = [np.asarray(atom.coordinates, float).copy() for atom in phase.atoms()]
        selected = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "X" if selector(atom.element) else " "
            if selector(atom.element):
                selected.append(atom_index)
                for coordinate_index, coordinate in enumerate("xyz"):
                    variable = f"{phase_index}::dA{coordinate}:{atom_index}"
                    center = float(start[atom_index][coordinate_index])
                    project.set_Controls("parmMin", center - STEP_BOUND, variable)
                    project.set_Controls("parmMax", center + STEP_BOUND, variable)
        project.set_Controls("cycles", 20)
        clear_frozen(project)
        project.refine()
        rvals = project.data["Covariance"]["data"]["Rvals"]
        frozen = [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])]
        shifts = displacements(phase, start)
        maximum = max(row["distance_A"] for row in shifts)
        final = {
            "rwp_percent": float(histogram.get_wR()),
            "gof": float(rvals["GOF"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
            "message": rvals.get("msg", ""),
            "selected_atom_indices": selected,
            "coordinate_step_bound_fractional": STEP_BOUND,
            "maximum_unique_atom_displacement_A": maximum,
            "displacements": shifts,
            "fractions": fractions(project, histogram),
            "frozen": frozen,
        }
        if frozen:
            result.update(status="unknown", reason="coordinate or correlated parameter reached a bound")
        elif maximum > 0.09:
            result.update(status="rejected", reason="coordinate correction exceeded the physical mismatch regime")
        else:
            result["status"] = "tested"
        result["final"] = final
        project.save(str(folder / "refined.gpx"))
        project.data["Covariance"]["data"] = {}
        for index, item in enumerate(project.phases()):
            item.export_CIF(str(folder / f"phase_{index}.cif"))
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    print(label, json.dumps(result), flush=True)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(label, *settings) for label, settings in BRANCHES.items()]
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
