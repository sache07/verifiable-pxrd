#!/usr/bin/env python3
"""Test a topology-diverse third-phase shortlist from one two-phase checkpoint."""

from __future__ import annotations

import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "two_phase" / "04_wo3_size_strain.gpx"
OUT = ROOT / ".tmp" / "third_phase_screen"
EXISTING = ["MnWO4_wolframite", "wo3_2311041"]
SHORTLIST = [
    "mnwo4_scheelite_from_cawo4_7219229",
    "mnwo4_from_znwo4_p1_2101679",
    "mn3wo6_from_cu3wo6_1527404",
    "mn2wo6_from_fe2wo6_2310464",
    "mn2wo6_from_cr2wo6_1530909",
    "mn2wo6_from_y2wo6_1541070",
    "mn2wo6_from_y2wo6_2106838",
    "mn2wo6_from_la2wo6_4501292",
    "mn6wo12_from_in6wo12_1001180",
    "mn6wo12_from_sc6wo12_4001207",
    "mn2wo4_from_li2wo4_1523083",
    "mn3o4_1541183",
    "mn3o4_9001963",
    "mn2o3_1010586",
    "mn2o3_1514103",
    "mn2o3_1514230",
    "mno_1514108",
]


def fractions(project, histogram):
    values = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        values.append((phase.name, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])))
    total = sum(max(v, 0.0) for _, v in values)
    return {n: max(v, 0.0) / total for n, v in values} if total > 0 else {}


def snapshot(project, histogram, candidate, start_cell):
    phase = project.phase(candidate)
    c = phase.get_cell()
    current = np.array([c[k] for k in ("length_a", "length_b", "length_c")])
    angles = np.array([c[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    cov = project.data.get("Covariance", {}).get("data", {})
    r = cov.get("Rvals", {})
    hap = phase.data["Histograms"][histogram.name]
    return {
        "rwp_percent": float(histogram.get_wR()),
        "fractions": fractions(project, histogram),
        "candidate_scale": float(hap["Scale"][0]),
        "cell": [*map(float, current), *map(float, angles)],
        "max_length_change_fraction": float(np.max(np.abs(current / np.asarray(start_cell[:3]) - 1))),
        "max_angle_change_deg": float(np.max(np.abs(angles - np.asarray(start_cell[3:])))),
        "size": hap["Size"],
        "microstrain": hap["Mustrain"],
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
    }


def run(project, repeats=3, cycles=12):
    project.set_Controls("cycles", cycles)
    for _ in range(repeats):
        project.refine()
        r = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if r.get("converged") and float(r.get("Max shft/sig", 999)) < 0.1:
            break


def test(record):
    name = record["candidate"]
    result = {"candidate": name, "status": "unknown", "reason": None, "stages": {}}
    try:
        branch = OUT / name
        branch.mkdir(parents=True, exist_ok=True)
        work = branch / "working.gpx"
        shutil.copy2(BASE, work)
        project = G2.G2Project(str(work))
        histogram = project.histograms()[0]
        assert [p.name for p in project.phases()] == EXISTING
        # Freeze every inherited non-background nuisance parameter for the
        # scale-only admission test.
        histogram.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]})
        histogram.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
        histogram.SampleParameters["Scale"] = [1.0, False]
        for phase in project.phases():
            phase.clear_refinements({"Cell": True})
            phase.set_refinements({"Atoms": {"all": " "}})
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [histogram])
            phase.data["Histograms"][histogram.name]["Scale"][1] = True

        phase = project.add_phase(
            str((ROOT / record["path"]).resolve()),
            phasename=name,
            histograms=[histogram],
            fmthint="CIF",
        )
        assert [p.name for p in project.phases()] == [*EXISTING, name]
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [1.0, True]
        if hap["Scale"][0] <= 0:
            raise RuntimeError("third phase lacks positive initialized scale")
        phase.set_refinements({"Atoms": {"all": " "}})
        cell = phase.get_cell()
        start = [cell[k] for k in ("length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma")]
        project.save(str(work))
        project.set_Controls("parmMin", 0.0, "2:0:Scale")

        run(project)
        result["stages"]["scale_background"] = snapshot(project, histogram, name, start)
        project.save(str(branch / "scale_background.gpx"))
        s1 = result["stages"]["scale_background"]
        if s1["candidate_scale"] < 0 or not math.isfinite(s1["candidate_scale"]):
            raise RuntimeError("invalid completed scale fit")
        if s1["fractions"].get(name, 0.0) < 0.0005 or s1["candidate_scale"] <= 1e-10:
            result.update(status="rejected", reason="scale collapsed in three-phase admission test")
            return result

        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
        for p in project.phases():
            p.set_refinements({"Cell": True})
        run(project, repeats=3, cycles=14)
        result["stages"]["zero_cells"] = snapshot(project, histogram, name, start)
        project.save(str(branch / "zero_cells.gpx"))
        s2 = result["stages"]["zero_cells"]
        if s2["candidate_scale"] <= 0 or s2["max_length_change_fraction"] > 0.12 or s2["max_angle_change_deg"] > 10:
            raise RuntimeError("cell/scale left the admissible prototype-screen regime")

        # Candidate-specific isotropic size, then strain. These stages are
        # diagnostic and retained only if interior and stable.
        project.set_Controls("parmMin", 0.04, "2:0:Size;i")
        project.set_Controls("parmMax", 1.5, "2:0:Size;i")
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.3, "refine": True}}, [histogram]
        )
        run(project, repeats=3, cycles=12)
        result["stages"]["isotropic_size"] = snapshot(project, histogram, name, start)
        project.set_Controls("parmMin", 0.0, "2:0:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, "2:0:Mustrain;i")
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [histogram]
        )
        run(project, repeats=3, cycles=12)
        result["stages"]["isotropic_size_strain"] = snapshot(project, histogram, name, start)
        project.save(str(branch / "profile.gpx"))
        result["status"] = "tested"
    except Exception as exc:
        result["status"] = "unknown"
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    ledger = {r["candidate"]: r for r in json.loads((ROOT / "candidate_ledger.json").read_text())}
    results = []
    for name in SHORTLIST:
        result = test(ledger[name])
        results.append(result)
        stages = result["stages"]
        last = stages.get("isotropic_size_strain") or stages.get("isotropic_size") or stages.get("zero_cells") or stages.get("scale_background", {})
        print(
            f"{name:<42} {result['status']:<8} "
            f"Rwp={[round(v['rwp_percent'],4) for v in stages.values()]} "
            f"fraction={last.get('fractions',{}).get(name)} {result.get('reason') or ''}"
        )
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
