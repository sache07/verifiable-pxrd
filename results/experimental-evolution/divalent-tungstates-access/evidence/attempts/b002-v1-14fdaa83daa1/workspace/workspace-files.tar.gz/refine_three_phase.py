#!/usr/bin/env python3
"""Final-stage refinement of MnWO4 + WO3 + analogue-derived Mn2WO6."""

from __future__ import annotations

import copy
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
START = ROOT / ".tmp" / "third_phase_screen" / "mn2wo6_from_y2wo6_1541070" / "zero_cells.gpx"
OUT = ROOT / ".tmp" / "three_phase"
NAMES = ["MnWO4_wolframite", "wo3_2311041", "mn2wo6_from_y2wo6_1541070"]


def phase_fractions(project, histogram):
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        rows.append((phase.name, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])))
    total = sum(max(0.0, v) for _, v in rows)
    return {n: max(0.0, v) / total for n, v in rows}


def diagnostics(project, label):
    histogram = project.histograms()[0]
    arrays = histogram.data["data"][1]
    x, obs, wt, calc, background = map(np.asarray, arrays[:5])
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases[phase.name] = {
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "scale": float(hap["Scale"][0]),
            "size": copy.deepcopy(hap["Size"]),
            "microstrain": copy.deepcopy(hap["Mustrain"]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "coordinates": list(map(float, atom.coordinates)),
                    "uiso_A2": float(atom.uiso),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    return {
        "stage": label,
        "rwp_percent": float(histogram.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        "message": rvals.get("msg", ""),
        "chi_square": float(np.sum(wt * (obs - calc) ** 2)),
        "background_min": float(background.min()),
        "calculated_min": float(calc.min()),
        "fractions": phase_fractions(project, histogram),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: float(sample[k][0]) for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "phases": phases,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def sane(d):
    if d["background_min"] < 0 or d["calculated_min"] < 0:
        return False
    if abs(sum(d["fractions"].values()) - 1) > 1e-8 or min(d["fractions"].values()) <= 0:
        return False
    inst = d["instrument"]
    if not (-0.5 <= inst["Zero"] <= 0.5 and 0 <= inst["U"] <= 100 and 0 <= inst["W"] <= 100 and 0 <= inst["X"] <= 20 and 0.001 <= inst["SH/L"] <= 0.2 and 0 <= inst["Polariz."] <= 1):
        return False
    for phase in d["phases"].values():
        cell = phase["cell"]
        if not all(3 < cell[k] < 20 for k in ("length_a", "length_b", "length_c")):
            return False
        if not all(40 < cell[k] < 150 for k in ("angle_alpha", "angle_beta", "angle_gamma")):
            return False
        if not all(0.0001 <= atom["uiso_A2"] <= 0.05 for atom in phase["atoms"]):
            return False
    return True


def checkpoint(project, label, history):
    d = diagnostics(project, label)
    if not sane(d):
        raise RuntimeError("unphysical stage " + label + ": " + json.dumps(d, indent=2))
    project.save(str(OUT / f"{label}.gpx"))
    history.append(d)
    print(
        f"{label:<28} Rwp={d['rwp_percent']:.5f}% GOF={d['gof']:.3f} "
        f"fractions={d['fractions']} maxshift={d['max_shift_over_esd']:.3g}"
    )
    return d


def refine(project, label, history, repeats=4, cycles=15):
    project.set_Controls("cycles", cycles)
    for _ in range(repeats):
        project.refine()
        r = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if r.get("converged") and float(r.get("Max shft/sig", 999)) < 0.05:
            break
    return checkpoint(project, label, history)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    work = OUT / "working.gpx"
    shutil.copy2(START, work)
    project = G2.G2Project(str(work))
    histogram = project.histograms()[0]
    assert [p.name for p in project.phases()] == NAMES

    # Roll back boundary-hitting profile terms. A common Gaussian W plus one
    # isotropic strain for each broad minor phase is the retained simple model.
    instrument = histogram.data["Instrument Parameters"][0]
    for key, val, flag in [
        ("Zero", instrument["Zero"][1], True),
        ("Polariz.", 0.7, False),
        ("U", 0.0, False),
        ("V", 0.0, False),
        ("W", 35.0, True),
        ("X", 0.1, False),
        ("Y", 0.0, False),
        ("Z", 0.0, False),
        ("SH/L", 0.005, False),
    ]:
        instrument[key][1] = float(val)
        instrument[key][2] = bool(flag)
    sample = histogram.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]

    for phase_id, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"][1] = True
        if hap["Scale"][0] <= 0:
            raise RuntimeError("phase lacks positive scale: " + phase.name)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0 if phase_id == 0 else 7000.0
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2] = [phase_id > 0, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    project.save(str(work))

    for var, low, high in [
        (":0:Zero", -0.5, 0.5),
        (":0:W", 0.0, 100.0),
        (":0:Polariz.", 0.0, 1.0),
        ("1:0:Mustrain;i", 0.0, 8000.0),
        ("2:0:Mustrain;i", 0.0, 8000.0),
    ]:
        project.set_Controls("parmMin", low, var)
        project.set_Controls("parmMax", high, var)

    history = []
    checkpoint(project, "00_inventory_reset", history)
    refine(project, "01_scales_cells_profiles", history, repeats=4, cycles=18)

    # Refine scattering-dominant coordinates first.
    for phase in project.phases():
        phase.set_refinements({
            "Atoms": {a.label: ("X" if a.element in {"Mn", "W"} else " ") for a in phase.atoms()}
        })
    refine(project, "02_heavy_coordinates", history, repeats=5, cycles=18)

    # Then admit all symmetry-allowed oxygen coordinates, retaining the heavy-only rollback.
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "03_all_coordinates", history, repeats=5, cycles=20)

    # Match the generator's one isotropic Uiso per phase with equality constraints.
    for phase_id, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = "XU"
        variables = [f"{phase_id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=True)
        for var in variables:
            project.set_Controls("parmMin", 0.003, var)
            project.set_Controls("parmMax", 0.02, var)
    refine(project, "04_phase_uiso", history, repeats=5, cycles=20)

    histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "05_simple_three_phase", history, repeats=5, cycles=20)
    project.save(str(OUT / "simple_three_phase.gpx"))
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    a = histogram.data["data"][1]
    np.savetxt(
        OUT / "simple_profile.csv",
        np.column_stack((a[0], a[1], a[3], a[1] - a[3], a[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )


if __name__ == "__main__":
    main()
