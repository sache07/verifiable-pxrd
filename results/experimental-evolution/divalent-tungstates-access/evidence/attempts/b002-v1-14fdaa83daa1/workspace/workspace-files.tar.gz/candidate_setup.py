#!/usr/bin/env python3
"""Prepare composition-preserving phase-discovery candidates from the frozen COD subset."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
OUT = Path("candidates")


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


# The shortlist deliberately spans topology and symmetry, not only Mn-W-O entries.
SPECS = [
    # Direct-composition wolframite entry and same-stoichiometry analogues.
    ("mnwo4_direct_1520200", "1520200", {}),
    ("mnwo4_from_fewo4_1567215", "1567215", {"Fe": "Mn"}),
    ("mnwo4_from_znwo4_p2c_1520641", "1520641", {"Zn": "Mn"}),
    ("mnwo4_from_znwo4_p1_2101679", "2101679", {"Zn": "Mn"}),
    ("mnwo4_scheelite_from_cawo4_7219229", "7219229", {"Ca": "Mn"}),
    ("mnwo4_c2c_from_hgwo4_2012578", "2012578", {"Hg": "Mn"}),
    # Plausible Mn-rich/off-stoichiometric oxide prototypes.
    ("mn2wo6_from_fe2wo6_2310464", "2310464", {"Fe": "Mn"}),
    ("mn2wo6_from_cr2wo6_1530909", "1530909", {"Cr": "Mn"}),
    ("mn2wo6_from_y2wo6_1541070", "1541070", {"Y": "Mn"}),
    ("mn2wo6_from_y2wo6_2106838", "2106838", {"Y": "Mn"}),
    ("mn2wo6_from_la2wo6_4501292", "4501292", {"La": "Mn"}),
    ("mn3wo6_from_cu3wo6_1527404", "1527404", {"Cu": "Mn"}),
    ("mn6wo12_from_in6wo12_1001180", "1001180", {"In": "Mn"}),
    ("mn6wo12_from_sc6wo12_4001207", "4001207", {"Sc": "Mn"}),
    ("mn2wo4_from_li2wo4_1523083", "1523083", {"Li": "Mn"}),
    # Starting oxides and likely oxidation/decomposition products.
    ("mn3o4_1541183", "1541183", {}),
    ("mn3o4_9001302", "9001302", {}),
    ("mn3o4_9001963", "9001963", {}),
    ("mn2o3_1010586", "1010586", {}),
    ("mn2o3_1514103", "1514103", {}),
    ("mn2o3_1514230", "1514230", {}),
    ("mno_1514108", "1514108", {}),
    ("wo3_1004057", "1004057", {}),
    ("wo3_1010618", "1010618", {}),
    ("wo3_1521532", "1521532", {}),
    ("wo3_1521533", "1521533", {}),
    ("wo3_1528915", "1528915", {}),
    ("wo3_1563541", "1563541", {}),
    ("wo3_2311041", "2311041", {}),
    ("wo3_2106293", "2106293", {}),
    ("wo3_2107312", "2107312", {}),
]


def physical_summary(structure):
    distances = np.array(structure.distance_matrix, dtype=float)
    np.fill_diagonal(distances, np.inf)
    min_distance = float(distances.min()) if len(structure) > 1 else None
    oxygen = [i for i, site in enumerate(structure) if set(site.species.get_el_amt_dict()) == {"O"}]
    min_oo = None
    if len(oxygen) > 1:
        oo = distances[np.ix_(oxygen, oxygen)]
        min_oo = float(oo.min())
    return {
        "minimum_interatomic_distance_A": min_distance,
        "minimum_O_O_distance_A": min_oo,
        "hard_contact_pass": min_distance is None or min_distance >= 0.8,
        "oxide_O_O_review_pass": min_oo is None or min_oo >= 1.8,
    }


def main():
    OUT.mkdir(exist_ok=True)
    records = []
    for name, cod_id, substitutions in SPECS:
        source = cod_path(cod_id)
        structure = CifParser(source, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
        original_formula = structure.composition.reduced_formula
        if substitutions:
            expanded = {}
            for old, new in substitutions.items():
                for site in structure:
                    for specie in site.species:
                        if specie.symbol == old:
                            expanded[specie] = new
            if not expanded:
                raise ValueError(f"No occupied species found for substitutions {substitutions}")
            structure.replace_species(expanded)
            structure.remove_oxidation_states()
        target = OUT / f"{name}.cif"
        # Retain symmetry and independent-site multiplicities while avoiding a
        # chemically stale source formula after analogue substitution.
        CifWriter(
            structure,
            symprec=1e-3,
            angle_tolerance=5,
            significant_figures=10,
            refine_struct=False,
        ).write_file(target)
        reparsed = CifParser(target, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
        records.append(
            {
                "candidate": name,
                "status": "pending",
                "path": str(target),
                "source_cod_id": cod_id,
                "source_path": str(source),
                "model_basis": "published" if not substitutions else "analogue_derived",
                "source_formula": original_formula,
                "substitutions": substitutions,
                "target_formula": reparsed.composition.reduced_formula,
                "space_group": reparsed.get_space_group_info()[0],
                "space_group_number": reparsed.get_space_group_info()[1],
                "cell": reparsed.lattice.parameters,
                "sites_in_cell": len(reparsed),
                "density_g_cm3": reparsed.density,
                "physical_screen": physical_summary(reparsed),
            }
        )
    Path("candidate_ledger.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
