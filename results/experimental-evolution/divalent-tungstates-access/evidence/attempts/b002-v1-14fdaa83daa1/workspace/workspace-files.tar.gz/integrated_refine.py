#!/usr/bin/env python3
"""Reoptimize structure from the supported three-phase profile checkpoint."""

from __future__ import annotations

import copy
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "intensity_branches" / "texture_p2_100.gpx"
OUT = ROOT / ".tmp" / "integrated"


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(0.0, v) for _, v in vals)
    return {n: max(0.0, v) / total for n, v in vals}


def snapshot(p, label):
    h = p.histograms()[0]
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    inst = h.data["Instrument Parameters"][0]
    return {
        "stage": label,
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "fractions": fractions(p, h),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
        "phases": {
            phase.name: {
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
                "size": copy.deepcopy(phase.data["Histograms"][h.name]["Size"]),
                "microstrain": copy.deepcopy(phase.data["Histograms"][h.name]["Mustrain"]),
                "texture": copy.deepcopy(phase.data["Histograms"][h.name]["Pref.Ori."]),
                "atoms": [{"label": a.label, "element": a.element, "xyz": list(map(float, a.coordinates)), "uiso": float(a.uiso), "flags": a.refinement_flags} for a in phase.atoms()],
            }
            for phase in p.phases()
        },
    }


def run(p, label, history, repeats=4, cycles=18):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()
    d = snapshot(p, label)
    p.save(str(OUT / f"{label}.gpx"))
    history.append(d)
    print(label, json.dumps({k: d[k] for k in ("rwp_percent", "gof", "converged", "max_shift_over_esd", "message", "fractions", "instrument")}), flush=True)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    work = OUT / "working.gpx"
    shutil.copy2(SOURCE, work)
    p = G2.G2Project(str(work))
    h = p.histograms()[0]
    clear_frozen(p)

    inst = h.data["Instrument Parameters"][0]
    for key in ("Zero", "Polariz.", "U", "W", "X"):
        inst[key][2] = True
    for key in ("V", "Y", "Z", "SH/L"):
        inst[key][2] = False
    for var, lo, hi in [
        (":0:Zero", -0.5, 0.5), (":0:Polariz.", 0.5, 1.0),
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
    ]:
        p.set_Controls("parmMin", lo, var)
        p.set_Controls("parmMax", hi, var)

    for i, phase in enumerate(p.phases()):
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = "X"
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        p.set_Controls("parmMin", 0.0, f"{i}:0:Scale")
        # Roll back unsupported size terms; retain only the interior phase-2 term.
        hap["Size"][2] = [i == 2, False, False]
        if i == 2:
            p.set_Controls("parmMin", 0.04, "2:0:Size;i")
            p.set_Controls("parmMax", 1.5, "2:0:Size;i")
        # Boundary strain estimates are held fixed while structure is recovered.
        hap["Mustrain"][2] = [False, False, False]
        if i == 2:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = [1, 0, 0]
            p.set_Controls("parmMin", 0.7, "2:0:MD")
            p.set_Controls("parmMax", 1.4, "2:0:MD")
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
    p.save(str(work))

    history = []
    run(p, "01_coordinates_cells_profile", history, repeats=4, cycles=20)

    # A second stage isolates phase Uiso effects from coordinate startup.
    for phase_id, phase in enumerate(p.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = "XU"
        for i, _ in enumerate(phase.atoms()):
            var = f"{phase_id}::AUiso:{i}"
            p.set_Controls("parmMin", 0.003, var)
            p.set_Controls("parmMax", 0.02, var)
    run(p, "02_phase_uiso", history, repeats=4, cycles=20)

    p.save(str(OUT / "integrated.gpx"))
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
