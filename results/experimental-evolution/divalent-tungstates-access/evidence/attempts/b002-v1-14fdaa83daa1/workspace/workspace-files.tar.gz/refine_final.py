#!/usr/bin/env python3
"""Staged GSAS-II refinement for the nominated MnWO4 phase.

This script intentionally stops at a simple isotropic model. Optional texture,
roughness and anisotropic-width branches are compared separately from the saved
simple checkpoint before any one of them can enter the final project.
"""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / ".tmp" / "refinement"
SOURCE_CIF = ROOT / "candidates" / "mnwo4_direct_1520200.cif"


def prepare_files():
    WORK.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = WORK / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst = WORK / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return x, y, xye, inst


def value(entry):
    if isinstance(entry, (list, tuple)) and len(entry) > 1:
        return float(entry[1])
    return float(entry)


def diagnostics(project, label):
    histogram = project.histograms()[0]
    phase = project.phase("MnWO4_wolframite")
    hap = phase.data["Histograms"][histogram.name]
    inst = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    data = histogram.data["data"][1]
    x, obs, weight, calc, background, residual = map(np.asarray, data[:6])
    used = (x >= histogram.data["Limits"][1][0]) & (x <= histogram.data["Limits"][1][1])
    manual_chi2 = float(np.sum(weight[used] * (obs[used] - calc[used]) ** 2))
    manual_rwp = float(100 * np.sqrt(manual_chi2 / np.sum(weight[used] * obs[used] ** 2)))
    cell = phase.get_cell()
    atom_rows = []
    for atom in phase.atoms():
        atom_rows.append({
            "label": atom.label,
            "element": atom.element,
            "coordinates": list(map(float, atom.coordinates)),
            "uiso_A2": float(atom.uiso),
            "refinement_flags": atom.refinement_flags,
        })
    result = {
        "stage": label,
        "rwp_percent": float(histogram.get_wR()),
        "manual_rwp_percent": manual_rwp,
        "chi_square": manual_chi2,
        "gof": float(rvals.get("GOF", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        "refinement_message": rvals.get("msg", ""),
        "phase_scale": float(hap["Scale"][0]),
        "sample_scale": float(sample["Scale"][0]),
        "cell": {k: float(v) for k, v in cell.items()},
        "instrument": {k: value(inst[k]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {
            k: float(sample[k][0])
            for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "profile": {
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        },
        "background_min": float(np.min(background)),
        "background_max": float(np.max(background)),
        "calculated_min": float(np.min(calc)),
        "atoms": atom_rows,
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }
    return result


def physically_sane(diag):
    c = diag["cell"]
    lengths = [c["length_a"], c["length_b"], c["length_c"]]
    angles = [c["angle_alpha"], c["angle_beta"], c["angle_gamma"]]
    inst = diag["instrument"]
    return (
        all(math.isfinite(v) and 3 < v < 10 for v in lengths)
        and all(math.isfinite(v) and 60 < v < 120 for v in angles)
        and diag["phase_scale"] > 0
        and diag["sample_scale"] > 0
        and diag["background_min"] >= 0
        and diag["calculated_min"] >= 0
        and -0.5 <= inst["Zero"] <= 0.5
        and 0 <= inst["U"] <= 100
        and 0 <= inst["W"] <= 100
        and 0 <= inst["X"] <= 15
        and 0.001 <= inst["SH/L"] <= 0.2
        and 0 <= inst["Polariz."] <= 1
        and all(0 <= a["uiso_A2"] <= 0.05 for a in diag["atoms"])
    )


def save_checkpoint(project, label, history):
    diag = diagnostics(project, label)
    if not physically_sane(diag):
        raise RuntimeError(f"stage {label} left the physical bounds: {json.dumps(diag, indent=2)}")
    project.save(str(WORK / f"{label}.gpx"))
    history.append(diag)
    print(
        f"{label:<24} Rwp={diag['rwp_percent']:.5f}% "
        f"GOF={diag['gof']:.4f} maxshift={diag['max_shift_over_esd']:.3g} "
        f"cell=({diag['cell']['length_a']:.6f}, {diag['cell']['length_b']:.6f}, "
        f"{diag['cell']['length_c']:.6f}, {diag['cell']['angle_beta']:.5f})"
    )
    return diag


def refine_stage(project, label, history, repeats=3, cycles=10):
    project.set_Controls("cycles", cycles)
    for _ in range(repeats):
        project.refine()
        cov = project.data.get("Covariance", {}).get("data", {})
        rvals = cov.get("Rvals", {})
        if rvals.get("converged") and float(rvals.get("Max shft/sig", 999)) < 0.05:
            break
    return save_checkpoint(project, label, history)


def main():
    G2.SetPrintLevel("error")
    x, y, xye, instfile = prepare_files()
    history = []
    project = G2.G2Project(newgpx=str(WORK / "working.gpx"))
    phase = project.add_phase(str(SOURCE_CIF), phasename="MnWO4_wolframite", fmthint="CIF")
    histogram = project.add_powder_histogram(
        str(xye), str(instfile), phases=[phase], fmthint="xye"
    )
    assert len(project.phases()) == 1 and project.phase("MnWO4_wolframite").name == "MnWO4_wolframite"
    assert list(phase.data["Histograms"]) == [histogram.name]

    histogram.SampleParameters["Type"] = "Bragg-Brentano"
    histogram.SampleParameters["Gonio. radius"] = 200.0
    histogram.SampleParameters["Scale"] = [1.0, False]
    histogram.SampleParameters["Shift"] = [0.0, False]
    histogram.SampleParameters["SurfRoughA"] = [0.0, False]
    histogram.SampleParameters["SurfRoughB"] = [0.0, False]
    histogram.set_refinements({
        "Limits": [float(x[0]), float(x[-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 10,
            "coeffs": [1600.0] + [0.0] * 9,
            "refine": True,
        },
    })
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"] = [10.0, True]
    if hap["Scale"][0] <= 0:
        raise RuntimeError("principal phase did not receive a positive initialized scale")
    for atom in phase.atoms():
        atom.uiso = 0.005
        atom.refinement_flags = " "

    project.save(str(WORK / "initialized.gpx"))
    project.set_Controls("parmMin", -0.5, ":0:Zero")
    project.set_Controls("parmMax", 0.5, ":0:Zero")
    project.set_Controls("parmMin", 0.0, ":0:U")
    project.set_Controls("parmMax", 100.0, ":0:U")
    project.set_Controls("parmMin", 0.0, ":0:W")
    project.set_Controls("parmMax", 100.0, ":0:W")
    project.set_Controls("parmMin", 0.0, ":0:X")
    project.set_Controls("parmMax", 15.0, ":0:X")
    project.set_Controls("parmMin", 0.001, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")
    project.set_Controls("parmMin", -1000.0, ":0:Shift")
    project.set_Controls("parmMax", 1000.0, ":0:Shift")
    project.set_Controls("parmMin", 0.0, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")

    # 1. Inventory-safe scale/background refinement.
    refine_stage(project, "01_scale_background", history, cycles=12)

    # 2. Angular calibration and symmetry-independent cell terms.
    histogram.set_refinements({"Instrument Parameters": ["Zero"]})
    phase.set_refinements({"Cell": True})
    refine_stage(project, "02_zero_cell", history, cycles=10)

    # 3. Isotropic instrumental/profile basis. V, Y and Z stay fixed at their
    # generator convention (zero); size/strain remain at simple defaults.
    histogram.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine_stage(project, "03_profile_wx", history, cycles=12)
    histogram.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    refine_stage(project, "04_profile_uwx_shl", history, cycles=12)

    # 4. Separate Bragg-Brentano specimen displacement from common zero/cell.
    histogram.set_refinements({"Sample Parameters": ["Shift"]})
    refine_stage(project, "05_specimen_shift", history, cycles=12)

    # 5. Symmetry-allowed coordinates, then isotropic ADPs. The reference
    # mismatch is symmetry preserving, so no symmetry lowering is introduced.
    phase.set_refinements({"Atoms": {"all": "X"}})
    refine_stage(project, "06_coordinates", history, repeats=4, cycles=15)
    phase.set_refinements({"Atoms": {"all": "XU"}})
    for i, _atom in enumerate(phase.atoms()):
        project.set_Controls("parmMin", 0.0001, f"0::AUiso:{i}")
        project.set_Controls("parmMax", 0.05, f"0::AUiso:{i}")
    refine_stage(project, "07_coordinates_uiso", history, repeats=4, cycles=15)

    # 6. Polarization is unknown in metadata and affects the angular intensity
    # envelope. It is the last simple instrument term considered here.
    histogram.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine_stage(project, "08_simple", history, repeats=4, cycles=15)

    project.save(str(WORK / "simple.gpx"))
    (WORK / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    arrays = histogram.data["data"][1]
    np.savetxt(
        WORK / "simple_profile.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )


if __name__ == "__main__":
    main()
