#!/usr/bin/env python3
"""Construct or screen the residual-derived alternative metric for Mn2WO6."""

from __future__ import annotations

import argparse
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "candidates" / "mn2wo6_from_y2wo6_1541070.cif"
TARGET = ROOT / "candidates" / "mn2wo6_from_y2wo6_1541070_metricB.cif"
OUT = ROOT / ".tmp" / "metric_branch"


def generate():
    from pymatgen.io.cif import CifParser, CifWriter

    structure = CifParser(SOURCE, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
    factor = 0.9462120762462355
    structure.scale_lattice(float(structure.volume) * factor**3)
    CifWriter(structure, symprec=1e-3, angle_tolerance=5, significant_figures=10, refine_struct=False).write_file(TARGET)
    parsed = CifParser(TARGET, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
    record = {
        "candidate": "mn2wo6_from_y2wo6_1541070_metricB",
        "status": "pending",
        "path": str(TARGET.relative_to(ROOT)),
        "source_cod_id": "1541070",
        "source_path": str(SOURCE),
        "model_basis": "analogue_derived_metric_branch",
        "source_formula": "Y2WO6",
        "substitutions": {"Y": "Mn"},
        "target_formula": parsed.composition.reduced_formula,
        "space_group": parsed.get_space_group_info()[0],
        "space_group_number": parsed.get_space_group_info()[1],
        "cell": list(map(float, parsed.lattice.parameters)),
        "sites_in_cell": len(parsed),
        "density_g_cm3": float(parsed.density),
        "physical_screen": {
            "minimum_interatomic_distance_A": float(min(x for row in parsed.distance_matrix for x in row if x > 1e-8)),
            "minimum_O_O_distance_A": 1.8,
        },
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "record.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record, indent=2))


def screen_variant():
    import expanded_third_screen as screen

    record = json.loads((OUT / "record.json").read_text())
    screen.OUT = OUT
    result = screen.test(record)
    (OUT / "result.json").write_text(json.dumps({"record": record, "result": result}, indent=2) + "\n")
    print(json.dumps({"record": record, "result": result}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("generate", "screen"))
    args = parser.parse_args()
    generate() if args.mode == "generate" else screen_variant()


if __name__ == "__main__":
    main()
