#!/usr/bin/env python3
"""GSAS-II admission screen for broad two-substitution oxide prototypes."""

from __future__ import annotations

import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_convergence" / "selected.gpx"
OUT = ROOT / ".tmp" / "broad_shortlist_screen"
DEACTIVATE = ["mn2wo6_from_y2wo6_1541070", "trial__mn3w2o9_from_sr3w2o9_2311977"]


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def active_phases(project, histogram):
    return [phase for phase in project.phases() if phase.data["Histograms"].get(histogram.name, {}).get("Use", True) and phase.data["Histograms"][histogram.name]["Scale"][0] > 0]


def fractions(project, histogram):
    phases = active_phases(project, histogram)
    amounts = [float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][histogram.name]["Scale"][0]) for phase in phases]
    total = sum(amounts)
    return {phase.name: amount / total for phase, amount in zip(phases, amounts)}


def refine(project, repeats, cycles):
    project.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(project)
        project.refine()


def snapshot(project, histogram, name, start, stage):
    phase = project.phase(name)
    cell = phase.get_cell()
    lengths = np.asarray([cell[k] for k in ("length_a", "length_b", "length_c")])
    angles = np.asarray([cell[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "stage": stage,
        "rwp_percent": float(histogram.get_wR()),
        "gof": float(rvals["GOF"]),
        "converged": bool(rvals["converged"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "message": rvals.get("msg", ""),
        "fractions": fractions(project, histogram),
        "cell": {k: float(v) for k, v in cell.items()},
        "max_length_change_fraction": float(np.max(np.abs(lengths / np.asarray(start[:3]) - 1))),
        "max_angle_change_deg": float(np.max(np.abs(angles - np.asarray(start[3:])))),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def test(record):
    name = record["candidate"]
    result = {"candidate": name, "source_cod_id": record["source_cod_id"], "status": "unknown", "reason": None, "stages": []}
    if not record["physical_screen"]["pass"]:
        result.update(status="rejected", reason="failed pre-fit physical screen")
        return result
    try:
        folder = OUT / name
        folder.mkdir(parents=True, exist_ok=True)
        work = folder / "working.gpx"
        shutil.copy2(SOURCE, work)
        project = G2.G2Project(str(work))
        histogram = project.histograms()[0]
        for phase_name in DEACTIVATE:
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][histogram.name]
            hap["Use"] = False
            hap["Scale"] = [0.0, False]
            phase.clear_refinements({"Cell": True})
            for atom in phase.atoms(): atom.refinement_flags = " "

        phase = project.add_phase(str((ROOT / record["path"]).resolve()), phasename=name, histograms=[histogram], fmthint="CIF")
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Use"] = True
        hap["Scale"] = [10.0, True]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        phase.clear_refinements({"Cell": True})
        phase_id = int(phase.data["pId"])
        project.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")
        cell = phase.get_cell()
        start = [cell[k] for k in ("length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma")]

        inst = histogram.data["Instrument Parameters"][0]
        for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
            inst[key][2] = False
        for item in project.phases():
            item.clear_refinements({"Cell": True})
            for atom in item.atoms(): atom.refinement_flags = " "
            item_hap = item.data["Histograms"].get(histogram.name)
            if not item_hap or not item_hap.get("Use", True):
                continue
            item_hap["Scale"][1] = True
            item_hap["Size"][2] = [False, False, False]
            item_hap["Mustrain"][2] = [False, False, False]
            item_hap["Pref.Ori."][2] = False
        project.save(str(work))
        refine(project, repeats=2, cycles=12)
        result["stages"].append(snapshot(project, histogram, name, start, "scale_background"))
        scale_stage = result["stages"][-1]
        if scale_stage["fractions"].get(name, 0.0) < 0.0005:
            result.update(status="rejected", reason="scale collapsed in fixed-model admission test")
            return result

        phase.set_refinements({"Cell": True})
        refine(project, repeats=4, cycles=18)
        result["stages"].append(snapshot(project, histogram, name, start, "candidate_cell"))
        final = result["stages"][-1]
        if final["frozen"]:
            result.update(status="unknown", reason="cell branch froze a bounded parameter")
        elif final["max_length_change_fraction"] > 0.12 or final["max_angle_change_deg"] > 8:
            result.update(status="unknown", reason="cell left admissible prototype-screen regime")
        elif final["fractions"].get(name, 0.0) < 0.0005:
            result.update(status="rejected", reason="scale collapsed after cell refinement")
        else:
            result["status"] = "tested"
        project.save(str(folder / "candidate_cell.gpx"))
        project.data["Covariance"]["data"] = {}
        phase.export_CIF(str(folder / "candidate.cif"))
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    print(name, result["status"], result["reason"], [(s["stage"], round(s["rwp_percent"], 5), round(s["fractions"].get(name, 0), 5), round(s["max_length_change_fraction"], 4)) for s in result["stages"]], flush=True)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = [test(record) for record in json.loads((ROOT / "broad_shortlist_ledger.json").read_text())]
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
