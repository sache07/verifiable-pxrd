#!/usr/bin/env python3
"""Compare P212121 coordinate sets in one common indexed cell/profile."""

from __future__ import annotations

import copy
import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_convergence" / "selected.gpx"
OUT = ROOT / ".tmp" / "indexed_relative_screen"
OLD = "mn2wo6_from_y2wo6_1541070"


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def refine(project, repeats=3, cycles=20):
    project.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(project)
        project.refine()


def fractions(project, histogram):
    phases = [p for p in project.phases() if p.data["Histograms"].get(histogram.name, {}).get("Use", True) and p.data["Histograms"][histogram.name]["Scale"][0] > 0]
    amounts = [float(p.data["General"]["Mass"]) * float(p.data["Histograms"][histogram.name]["Scale"][0]) for p in phases]
    total = sum(amounts)
    return {p.name: amount / total for p, amount in zip(phases, amounts)}


def snapshot(project, histogram, candidate, stage, start):
    phase = project.phase(candidate)
    cell = phase.get_cell()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    lengths = np.asarray([cell[k] for k in ("length_a", "length_b", "length_c")])
    return {
        "stage": stage,
        "rwp_percent": float(histogram.get_wR()),
        "gof": float(rvals["GOF"]),
        "converged": bool(rvals["converged"]),
        "max_shift_over_esd": float(rvals["Max shft/sig"]),
        "message": rvals.get("msg", ""),
        "fractions": fractions(project, histogram),
        "cell": {k: float(v) for k, v in cell.items()},
        "max_length_change_fraction": float(np.max(np.abs(lengths / np.asarray(start) - 1))),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def test(record):
    name = record["candidate"]
    result = {"candidate": name, "source_cod_id": record["source_cod_id"], "status": "unknown", "reason": None, "stages": []}
    try:
        folder = OUT / name
        folder.mkdir(parents=True, exist_ok=True)
        work = folder / "working.gpx"
        shutil.copy2(SOURCE, work)
        project = G2.G2Project(str(work))
        histogram = project.histograms()[0]
        old = project.phase(OLD)
        old_hap = copy.deepcopy(old.data["Histograms"][histogram.name])
        old.data["Histograms"][histogram.name]["Use"] = False
        old.data["Histograms"][histogram.name]["Scale"] = [0.0, False]
        old.clear_refinements({"Cell": True})
        for atom in old.atoms(): atom.refinement_flags = " "

        phase = project.add_phase(str((ROOT / record["path"]).resolve()), phasename=name, histograms=[histogram], fmthint="CIF")
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram.name]
        hap["Use"] = True
        hap["Scale"] = [float(old_hap["Scale"][0]), True]
        for key in ("Size", "Mustrain", "Pref.Ori."):
            hap[key] = copy.deepcopy(old_hap[key])
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][2] = False
        phase.clear_refinements({"Cell": True})
        phase_id = int(phase.data["pId"])
        project.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")
        start_cell = phase.get_cell()
        start = [start_cell[k] for k in ("length_a", "length_b", "length_c")]

        # Freeze every nuisance term except active scales and the common background.
        inst = histogram.data["Instrument Parameters"][0]
        for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
            inst[key][2] = False
        for item in project.phases():
            item.clear_refinements({"Cell": True})
            for atom in item.atoms(): atom.refinement_flags = " "
            item_hap = item.data["Histograms"].get(histogram.name)
            if not item_hap or not item_hap.get("Use", True):
                continue
            item_hap["Scale"][1] = True
            item_hap["Size"][2] = [False, False, False]
            item_hap["Mustrain"][2] = [False, False, False]
            item_hap["Pref.Ori."][2] = False
        project.save(str(work))
        refine(project, repeats=3, cycles=20)
        result["stages"].append(snapshot(project, histogram, name, "common_metric_fixed_coordinates", start))

        phase.set_refinements({"Cell": True})
        refine(project, repeats=3, cycles=20)
        result["stages"].append(snapshot(project, histogram, name, "candidate_cell", start))
        final = result["stages"][-1]
        if final["frozen"]:
            result.update(status="unknown", reason="cell branch froze a bounded parameter")
        elif final["fractions"].get(name, 0) < 0.001:
            result.update(status="rejected", reason="scale collapsed")
        elif final["max_length_change_fraction"] > 0.04:
            result.update(status="unknown", reason="indexed cell moved outside the local comparison regime")
        else:
            result["status"] = "tested"
        project.save(str(folder / "refined.gpx"))
        project.data["Covariance"]["data"] = {}
        phase.export_CIF(str(folder / "candidate.cif"))
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    print(name, result["status"], result["reason"], [(s["stage"], round(s["rwp_percent"], 5), round(s["fractions"].get(name, 0), 5), round(s["max_length_change_fraction"], 5)) for s in result["stages"]], flush=True)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = [test(record) for record in json.loads((ROOT / "indexed_relative_ledger.json").read_text())]
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
