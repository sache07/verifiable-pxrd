#!/usr/bin/env python3
"""Screen charge-plausible two-cation oxide parents against the third-phase residual."""

from __future__ import annotations

import gzip
import json
import math
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy.signal import savgol_filter

from prototype_search import fit_candidate, transformed_positions


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02")
FIT = ROOT / ".tmp" / "two_phase" / "simple_profile.csv"
OUT = ROOT / ".tmp" / "broad_two_substitution_search.json"
SCALES = np.linspace(0.90, 1.10, 41)
SHIFTS = np.linspace(-0.30, 0.30, 9)


def cod_path(cod_id):
    return RESOURCE / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def candidate_rows(index):
    rows = []
    for system, records in index.items():
        elements = system.split("-")
        if len(set(elements)) != 3 or "O" not in elements:
            continue
        for formula, cod_id, sg_number, r_value in records:
            try:
                counts = Composition(formula).reduced_composition.get_el_amt_dict()
            except Exception:
                continue
            if len(counts) != 3 or "O" not in counts or sum(counts.values()) > 35:
                continue
            cations = [(element, value) for element, value in counts.items() if element != "O"]
            oxygen = counts["O"]
            if len(cations) != 2 or oxygen <= 0 or any(value <= 0 for _, value in cations):
                continue
            for assignment in (0, 1):
                manganese, mn_count = cations[assignment]
                tungsten, w_count = cations[1 - assignment]
                mn_valence = (2 * oxygen - 6 * w_count) / mn_count
                if not 1.8 <= mn_valence <= 4.1:
                    continue
                if max(mn_count / w_count, w_count / mn_count) > 8:
                    continue
                rows.append(
                    {
                        "source_cod_id": cod_id,
                        "source_formula": formula,
                        "source_space_group_number": sg_number,
                        "source_r_value": r_value,
                        "source_path": str(cod_path(cod_id)),
                        "assignment": assignment,
                        "substitutions": {manganese: "Mn", tungsten: "W"},
                        "target_stoichiometry": {"Mn": mn_count, "W": w_count, "O": oxygen},
                        "formal_Mn_valence": mn_valence,
                        "status": "unknown",
                    }
                )
    return rows


def coarse_score(x, residual, weights, positions, intensities):
    # Fast reflection-sampled prefilter. The full broadened profile is evaluated
    # later for only the strongest candidates.
    best = (-math.inf, None, None)
    norm_r = float(np.sum(weights * residual * residual))
    for scale in SCALES:
        moved0 = transformed_positions(positions, scale, 0.0)
        for shift in SHIFTS:
            moved = moved0 + shift
            good = np.isfinite(moved) & (moved >= x[0]) & (moved <= x[-1])
            if not np.any(good):
                continue
            pos = moved[good]
            intensity = intensities[good]
            sampled_r = np.interp(pos, x, residual)
            sampled_w = np.interp(pos, x, weights)
            dot = float(np.sum(sampled_w * intensity * sampled_r))
            norm_p = float(np.sum(sampled_w * intensity * intensity))
            score = dot * dot / (max(norm_p, 1e-30) * max(norm_r, 1e-30)) if dot > 0 else 0.0
            if score > best[0]:
                best = (score, float(scale), float(shift))
    return {"coarse_score": best[0], "coarse_lattice_scale": best[1], "coarse_zero_shift_deg": best[2]}


def main():
    fit = np.loadtxt(FIT, delimiter=",", skiprows=1)
    x_full, observed, _calculated, raw_residual, _background = fit.T
    mask = (x_full >= 15) & (x_full <= 70)
    x = x_full[mask]
    residual = np.maximum(savgol_filter(raw_residual[mask], 15, 3), 0.0)
    weights = 1 / np.maximum(observed[mask], 1.0)
    with gzip.open(RESOURCE / "index.json.gz", "rt") as stream:
        index = json.load(stream)
    rows = candidate_rows(index)
    calculator = XRDCalculator(wavelength="CuKa")
    tested = []
    for number, record in enumerate(rows, 1):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = Structure.from_file(record["source_path"], primitive=False)
            structure.remove_oxidation_states()
            if len(structure) > 100 or any(site.species.num_atoms > 1.0001 for site in structure):
                raise ValueError("site-count/occupancy screen")
            structure.replace_species(record["substitutions"])
            structure.remove_oxidation_states()
            if set(structure.composition.get_el_amt_dict()) != {"Mn", "W", "O"}:
                raise ValueError("substitution did not produce Mn-W-O only")
            distances = np.asarray(structure.distance_matrix, float)
            np.fill_diagonal(distances, np.inf)
            if len(structure) > 1 and float(np.min(distances)) < 0.8:
                raise ValueError("hard contact")
            oxygen_indices = [i for i, site in enumerate(structure) if site.species_string == "O"]
            if len(oxygen_indices) > 1:
                oo = distances[np.ix_(oxygen_indices, oxygen_indices)]
                if float(np.min(oo)) < 1.8:
                    raise ValueError("oxide O-O contact")
            pattern = calculator.get_pattern(structure, two_theta_range=(12, 74), scaled=False)
            positions = np.asarray(pattern.x, float)
            intensities = np.asarray(pattern.y, float)
            if not len(positions) or not np.max(intensities) > 0:
                raise ValueError("empty pattern")
            record.update(
                status="coarse_tested",
                target_formula=structure.composition.reduced_formula,
                detected_space_group=structure.get_space_group_info(symprec=1e-3)[0],
                detected_space_group_number=structure.get_space_group_info(symprec=1e-3)[1],
                cell=list(map(float, structure.lattice.parameters)),
                sites_in_cell=len(structure),
                density_g_cm3=float(structure.density),
                minimum_distance_A=float(np.min(distances)),
                positions=positions.tolist(),
                intensities=intensities.tolist(),
                **coarse_score(x, residual, weights, positions, intensities),
            )
            tested.append(record)
        except Exception as exc:
            record["reason"] = f"{type(exc).__name__}: {exc}"
        if number % 100 == 0:
            leaders = sorted(tested, key=lambda row: row["coarse_score"], reverse=True)[:3]
            print(f"progress {number}/{len(rows)} tested={len(tested)} leaders=" + ",".join(f"{r['source_cod_id']}:{r['coarse_score']:.4g}" for r in leaders), flush=True)

    tested.sort(key=lambda row: row["coarse_score"], reverse=True)
    for record in tested[:250]:
        positions = np.asarray(record.pop("positions"), float)
        intensities = np.asarray(record.pop("intensities"), float)
        record.update(status="tested", **fit_candidate(x, residual, weights, positions, intensities))
    for record in tested[250:]:
        record.pop("positions", None)
        record.pop("intensities", None)
    tested.sort(key=lambda row: row.get("profile_improvement_fraction", -1), reverse=True)
    OUT.write_text(json.dumps(tested, indent=2) + "\n")
    print("top full-profile candidates", flush=True)
    for record in tested[:80]:
        print(
            record["source_cod_id"], record["source_formula"], "->", record.get("target_formula"),
            "sg", record.get("detected_space_group_number"),
            "improve", round(record.get("profile_improvement_fraction", -1), 6),
            "scale", round(record.get("lattice_scale", 0), 6),
            "sub", record["substitutions"], flush=True,
        )


if __name__ == "__main__":
    main()
