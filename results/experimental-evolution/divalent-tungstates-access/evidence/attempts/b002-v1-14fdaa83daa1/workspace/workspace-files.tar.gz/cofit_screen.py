#!/usr/bin/env python3
"""Add each pending phase to the same MnWO4 checkpoint and test its scale/cell."""

from __future__ import annotations

import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "refinement" / "02_zero_cell.gpx"
OUT = ROOT / ".tmp" / "cofit_screen"
PRINCIPAL = "MnWO4_wolframite"


def mass_fractions(project, histogram):
    masses = []
    names = []
    for phase in project.phases():
        hap = phase.data["Histograms"].get(histogram.name)
        if hap is None or not hap.get("Use", True):
            continue
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
        names.append(phase.name)
    total = sum(max(0.0, v) for v in masses)
    return {n: max(0.0, v) / total for n, v in zip(names, masses)} if total > 0 else {}


def snapshot(project, histogram, candidate, starting_cell):
    phase = project.phase(candidate)
    hap = phase.data["Histograms"][histogram.name]
    cell = phase.get_cell()
    lengths = np.array([cell[k] for k in ("length_a", "length_b", "length_c")])
    angles = np.array([cell[k] for k in ("angle_alpha", "angle_beta", "angle_gamma")])
    start_lengths = np.asarray(starting_cell[:3])
    start_angles = np.asarray(starting_cell[3:])
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    return {
        "rwp_percent": float(histogram.get_wR()),
        "candidate_scale": float(hap["Scale"][0]),
        "weight_fractions": mass_fractions(project, histogram),
        "cell": [*map(float, lengths), *map(float, angles)],
        "max_length_change_fraction": float(np.max(np.abs(lengths / start_lengths - 1))),
        "max_angle_change_deg": float(np.max(np.abs(angles - start_angles))),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        "message": rvals.get("msg", ""),
    }


def run_refinement(project, repeats=2, cycles=10):
    project.set_Controls("cycles", cycles)
    for _ in range(repeats):
        project.refine()
        rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rvals.get("converged") and float(rvals.get("Max shft/sig", 999)) < 0.1:
            break


def test_candidate(record):
    candidate = record["candidate"]
    result = {"candidate": candidate, "status": "unknown", "stages": {}, "reason": None}
    try:
        branch = OUT / candidate
        branch.mkdir(parents=True, exist_ok=True)
        branch_base = branch / "branch_base.gpx"
        shutil.copy2(BASE, branch_base)
        project = G2.G2Project(str(branch_base))
        histogram = project.histograms()[0]
        principal = project.phase(PRINCIPAL)
        # Restore the common discovery settings; no fine atomic terms from later
        # stages are present in BASE.
        histogram.clear_refinements({"Instrument Parameters": ["Zero"]})
        principal.clear_refinements({"Cell": True})
        principal.set_refinements({"Atoms": {"all": " "}})
        histogram.SampleParameters["Scale"] = [1.0, False]
        principal.data["Histograms"][histogram.name]["Scale"][1] = True

        cif = (ROOT / record["path"]).resolve()
        phase = project.add_phase(
            str(cif), phasename=candidate, histograms=[histogram], fmthint="CIF"
        )
        assert len(project.phases()) == 2
        assert project.phase(candidate).name == candidate
        assert set(p.name for p in project.phases()) == {PRINCIPAL, candidate}
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [1.0, True]
        if hap["Scale"][0] <= 0:
            raise RuntimeError("candidate did not receive a positive initialized scale")
        phase.set_refinements({"Atoms": {"all": " "}})
        start = phase.get_cell()
        starting_cell = [
            start[k]
            for k in (
                "length_a", "length_b", "length_c",
                "angle_alpha", "angle_beta", "angle_gamma",
            )
        ]
        project.save(str(branch / "initialized.gpx"))
        project.set_Controls("parmMin", 0.0, "1:0:Scale")

        # Stage 1: candidate scale plus the already common background basis.
        run_refinement(project, repeats=3, cycles=12)
        result["stages"]["scale_background"] = snapshot(
            project, histogram, candidate, starting_cell
        )
        project.save(str(branch / "scale_background.gpx"))
        s1 = result["stages"]["scale_background"]
        fraction = s1["weight_fractions"].get(candidate, 0.0)
        if not math.isfinite(s1["candidate_scale"]) or s1["candidate_scale"] < 0:
            raise RuntimeError("invalid scale after a completed scale/background fit")
        if fraction < 0.0005 or s1["candidate_scale"] <= 1e-10:
            result.update(status="rejected", reason="scale collapsed in common scale/background fit")
            return result

        # Stage 2: only now permit common zero and both symmetry-independent cells.
        histogram.set_refinements({"Instrument Parameters": ["Zero"]})
        principal.set_refinements({"Cell": True})
        phase.set_refinements({"Cell": True})
        run_refinement(project, repeats=3, cycles=12)
        result["stages"]["zero_cells"] = snapshot(project, histogram, candidate, starting_cell)
        project.save(str(branch / "zero_cells.gpx"))
        s2 = result["stages"]["zero_cells"]
        if (
            s2["candidate_scale"] <= 0
            or s2["max_length_change_fraction"] > 0.10
            or s2["max_angle_change_deg"] > 10
        ):
            raise RuntimeError("candidate cell/scale left the valid analogue-screen regime")
        result["status"] = "tested"
    except Exception as exc:
        result["status"] = "unknown"
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    ledger = json.loads((ROOT / "candidate_ledger.json").read_text())
    records = [r for r in ledger if r["candidate"] != "mnwo4_direct_1520200"]
    results = []
    for record in records:
        result = test_candidate(record)
        results.append(result)
        s1 = result["stages"].get("scale_background", {})
        s2 = result["stages"].get("zero_cells", {})
        last = s2 or s1
        fraction = last.get("weight_fractions", {}).get(result["candidate"])
        print(
            f"{result['candidate']:<42} {result['status']:<8} "
            f"Rwp1={s1.get('rwp_percent')} Rwp2={s2.get('rwp_percent')} "
            f"fraction={fraction} {result.get('reason') or ''}"
        )
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
