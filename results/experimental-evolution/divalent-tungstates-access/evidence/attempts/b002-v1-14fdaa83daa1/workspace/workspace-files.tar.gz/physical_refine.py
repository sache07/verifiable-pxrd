#!/usr/bin/env python3
"""Physically constrained refinement with the analogue phase coordinates fixed."""

from __future__ import annotations

import copy
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "three_phase" / "00_inventory_reset.gpx"
OUT = ROOT / ".tmp" / "physical_refine2"


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(v, 0.0) for _, v in vals)
    return {n: max(v, 0.0) / total for n, v in vals}


def snap(p, stage):
    h = p.histograms()[0]
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    inst = h.data["Instrument Parameters"][0]
    return {
        "stage": stage,
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "fractions": fractions(p, h),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
        "phases": {
            phase.name: {
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
                "size": copy.deepcopy(phase.data["Histograms"][h.name]["Size"]),
                "microstrain": copy.deepcopy(phase.data["Histograms"][h.name]["Mustrain"]),
                "texture": copy.deepcopy(phase.data["Histograms"][h.name]["Pref.Ori."]),
                "atoms": [{"label": a.label, "element": a.element, "xyz": list(map(float, a.coordinates)), "uiso": float(a.uiso), "flags": a.refinement_flags} for a in phase.atoms()],
            }
            for phase in p.phases()
        },
    }


def run(p, label, history, repeats=4, cycles=20):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()
    d = snap(p, label)
    # Save a copy without changing the live project's autosave target.
    current = Path(p.filename)
    p.save(str(OUT / f"{label}.gpx"))
    p.filename = str(current)
    history.append(d)
    print(label, json.dumps({k: d[k] for k in ("rwp_percent", "gof", "converged", "max_shift_over_esd", "message", "fractions", "instrument")}), flush=True)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    work = OUT / "working.gpx"
    shutil.copy2(SOURCE, work)
    p = G2.G2Project(str(work))
    h = p.histograms()[0]
    clear_frozen(p)
    inst = h.data["Instrument Parameters"][0]
    settings = {
        "Zero": (inst["Zero"][1], True), "Polariz.": (0.75, True),
        "U": (8.0, True), "V": (0.0, False), "W": (34.0, True),
        "X": (0.7, True), "Y": (0.0, False), "Z": (0.0, False),
        "SH/L": (0.005, False),
    }
    for key, (value, flag) in settings.items():
        inst[key][1] = value
        inst[key][2] = flag
    for var, lo, hi in [
        (":0:Zero", -0.5, 0.5), (":0:Polariz.", 0.5, 1.0),
        (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
        ("1:0:Mustrain;i", 0.0, 8000.0), ("2:0:Mustrain;i", 0.0, 8000.0),
    ]:
        p.set_Controls("parmMin", lo, var)
        p.set_Controls("parmMax", hi, var)

    for phase_id, phase in enumerate(p.phases()):
        phase.set_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.uiso = 0.005
            if phase_id == 0:
                atom.refinement_flags = "X"
            elif phase_id == 1 and atom.element == "W":
                atom.refinement_flags = "X"
            else:
                atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        p.set_Controls("parmMin", 0.0, f"{phase_id}:0:Scale")
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0 if phase_id == 0 else (7400.0 if phase_id == 1 else 7000.0)
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2] = [phase_id > 0, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    p.save(str(work))

    history = []
    run(p, "01_major_phase_coordinates", history, repeats=5, cycles=20)

    # Refine one isotropic displacement parameter per major phase; keep the
    # analogue phase at the registered 0.005 A^2 value.
    for phase_id, phase in enumerate(p.phases()[:2]):
        for atom in phase.atoms():
            atom.refinement_flags = ("X" if "X" in atom.refinement_flags else "") + "U"
        variables = [f"{phase_id}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            p.add_EquivConstr(variables, reloadIdx=True)
        for var in variables:
            p.set_Controls("parmMin", 0.003, var)
            p.set_Controls("parmMax", 0.02, var)
    run(p, "02_major_phase_uiso", history, repeats=4, cycles=20)
    p.save(str(OUT / "physical.gpx"))
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
