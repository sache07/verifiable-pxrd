#!/usr/bin/env python3
"""Common-checkpoint tests of instrument-profile terms for the three-phase model."""

from __future__ import annotations

import copy
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "three_phase" / "simple_three_phase.gpx"
OUT = ROOT / ".tmp" / "profile_branches"


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(project, repeats=5, cycles=18):
    project.set_Controls("cycles", cycles)
    clear_frozen(project)
    for _ in range(repeats):
        project.refine()
        clear_frozen(project)
        r = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if r.get("converged") and float(r.get("Max shft/sig", 999)) < 0.05:
            break


def snapshot(project):
    h = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    r = cov.get("Rvals", {})
    inst = h.data["Instrument Parameters"][0]
    return {
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "instrument": {k: [float(inst[k][1]), bool(inst[k][2])] for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "profiles": {
            p.name: {
                "size": copy.deepcopy(p.data["Histograms"][h.name]["Size"]),
                "microstrain": copy.deepcopy(p.data["Histograms"][h.name]["Mustrain"]),
            }
            for p in project.phases()
        },
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }


def prepare(source, destination):
    shutil.copy2(source, destination)
    p = G2.G2Project(str(destination))
    clear_frozen(p)
    # Hold structural variables at the current values so each branch measures
    # only the intended common profile contribution.
    for phase in p.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    p.save(str(destination))
    return p


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    common_path = OUT / "common.gpx"
    common = prepare(SOURCE, common_path)
    run(common, repeats=5)
    common.save(str(common_path))
    results = {"common": snapshot(common)}
    print("common", results["common"])

    branches = {
        "U": {"U": 10.0},
        "X": {"X": 1.0},
        "SHL": {"SH/L": 0.02},
        "U_X": {"U": 10.0, "X": 1.0},
        "U_X_SHL": {"U": 10.0, "X": 1.0, "SH/L": 0.02},
    }
    bounds = {"U": (0.0, 40.0), "X": (0.1, 6.0), "SH/L": (0.005, 0.1)}
    for name, terms in branches.items():
        path = OUT / f"{name}.gpx"
        p = prepare(common_path, path)
        h = p.histograms()[0]
        inst = h.data["Instrument Parameters"][0]
        for key, value in terms.items():
            inst[key][1] = value
            inst[key][2] = True
            low, high = bounds[key]
            p.set_Controls("parmMin", low, f":0:{key}")
            p.set_Controls("parmMax", high, f":0:{key}")
        p.save(str(path))
        run(p, repeats=6, cycles=20)
        p.save(str(path))
        results[name] = snapshot(p)
        print(name, results[name])
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
