#!/usr/bin/env python3
"""Export the converged four-phase project and required submission files."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_convergence" / "selected.gpx"
FINAL = ROOT / "final.gpx"
PHASES = [
    {
        "project_name": "MnWO4_wolframite",
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cif_path": "phase_1_MnWO4_wolframite.cif",
        "model_basis": "same-formula COD 1520200",
    },
    {
        "project_name": "wo3_2311041",
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cif_path": "phase_2_WO3_monoclinic.cif",
        "model_basis": "same-formula COD 2311041",
    },
    {
        "project_name": "mn2wo6_from_y2wo6_1541070",
        "name": "Mn2WO6 (P212121 analogue model)",
        "formula": "Mn2WO6",
        "cif_path": "phase_3_Mn2WO6_P212121.cif",
        "model_basis": "Y2WO6 topology, COD 1541070, Y->Mn",
    },
    {
        "project_name": "trial__mn3w2o9_from_sr3w2o9_2311977",
        "name": "Mn3W2O9 (C2/c analogue model)",
        "formula": "Mn3W2O9",
        "cif_path": "phase_4_Mn3W2O9_C2c.cif",
        "model_basis": "Sr3W2O9 topology, COD 2311977, Sr->Mn",
    },
]


def main():
    G2.SetPrintLevel("error")
    shutil.copy2(SOURCE, FINAL)
    project = G2.G2Project(str(FINAL))
    histogram = project.histograms()[0]
    if histogram.name != "PWDR pattern.xye":
        raise RuntimeError(f"unexpected refinement histogram {histogram.name!r}")
    if [phase.name for phase in project.phases()] != [row["project_name"] for row in PHASES]:
        raise RuntimeError("final phase order or identity changed")

    x, observed, weights, calculated, background, _residual = map(
        np.asarray, histogram.data["data"][1][:6]
    )
    source = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    if source.shape != (len(x), 2):
        raise RuntimeError("final profile does not cover the measured grid")
    if not np.allclose(source[:, 0], x, rtol=0, atol=1e-7) or not np.allclose(source[:, 1], observed, rtol=0, atol=1e-5):
        raise RuntimeError("final project does not contain the original observations")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("final calculated profile is nonfinite or negative")
    if np.min(background) < -1e-6:
        raise RuntimeError("final background is negative")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, observed - calculated, background)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )

    amounts = []
    for phase in project.phases():
        scale = float(phase.data["Histograms"][histogram.name]["Scale"][0])
        if not np.isfinite(scale) or scale <= 0:
            raise RuntimeError(f"nonpositive final scale for {phase.name}")
        amounts.append(float(phase.data["General"]["Mass"]) * scale)
    total = sum(amounts)
    fractions = [amount / total for amount in amounts]

    rvals = project.data["Covariance"]["data"]["Rvals"]
    manual_chi_square = float(np.sum(weights * (observed - calculated) ** 2))
    manual_rwp = float(100 * np.sqrt(manual_chi_square / np.sum(weights * observed**2)))
    records = []
    for spec, phase, fraction in zip(PHASES, project.phases(), fractions):
        cell = phase.get_cell()
        record = {k: v for k, v in spec.items() if k != "project_name"}
        record.update(
            project_phase_name=phase.name,
            space_group=phase.data["General"]["SGData"]["SpGrp"].strip(),
            weight_fraction=float(fraction),
            weight_percent=float(100 * fraction),
            cell={k: float(v) for k, v in cell.items()},
        )
        records.append(record)

    result = {
        "phases": records,
        "fit_statistics": {
            "rwp_percent": manual_rwp,
            "rp_percent": float(histogram.residuals["R"]),
            "chi_square": manual_chi_square,
            "goodness_of_fit": float(rvals["GOF"]),
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
            "weighting": "w = 1/max(observed counts, 1)",
        },
        "fit_file": "fit.csv",
        "refinement_project": "final.gpx",
        "refinement_histogram": histogram.name,
        "fraction_basis": "normalized over the four modeled crystalline phases",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    # Match the evaluator's replay export: write full-precision saved phase
    # data without allowing stale covariance values to alter CIF output.
    project.data["Covariance"]["data"] = {}
    for spec, phase in zip(PHASES, project.phases()):
        phase.export_CIF(str(ROOT / spec["cif_path"]))

    diagnostics = {
        "native_rwp_percent": float(histogram.get_wR()),
        "manual_rwp_percent": manual_rwp,
        "native_chi_square": float(rvals["chisq"]),
        "manual_chi_square": manual_chi_square,
        "background_min": float(np.min(background)),
        "calculated_min": float(np.min(calculated)),
        "profile_rows": int(len(x)),
        "fraction_sum": float(sum(fractions)),
        "result": result,
    }
    (ROOT / ".tmp" / "final_diagnostics.json").write_text(json.dumps(diagnostics, indent=2) + "\n")
    print(json.dumps(diagnostics, indent=2))


if __name__ == "__main__":
    main()
