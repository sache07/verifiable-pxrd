#!/usr/bin/env python3
"""Converge the selected four-phase GSAS-II model with physical guards."""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "refined_fourth_shortlist" / "mn3w2o9_from_sr3w2o9_2311977" / "refined.gpx"
OUT = ROOT / ".tmp" / "final_convergence"
EXPECTED = [
    "MnWO4_wolframite",
    "wo3_2311041",
    "mn2wo6_from_y2wo6_1541070",
    "trial__mn3w2o9_from_sr3w2o9_2311977",
]


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project, histogram):
    amounts = []
    for phase in project.phases():
        scale = float(phase.data["Histograms"][histogram.name]["Scale"][0])
        amounts.append(float(phase.data["General"]["Mass"]) * scale)
    total = sum(amounts)
    return {phase.name: amount / total for phase, amount in zip(project.phases(), amounts)}


def snapshot(project, iteration):
    histogram = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    arrays = list(map(np.asarray, histogram.data["data"][1][:6]))
    inst = histogram.data["Instrument Parameters"][0]
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": {k: float(v) for k, v in phase.get_cell().items()},
                "size": hap["Size"],
                "microstrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    return {
        "iteration": iteration,
        "rwp_percent": float(histogram.get_wR()),
        "gof": float(rvals.get("GOF", np.nan)),
        "chi_square": float(rvals.get("chisq", np.nan)),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_over_esd": float(rvals.get("Max shft/sig", np.nan)),
        "message": str(rvals.get("msg", "")),
        "fractions": fractions(project, histogram),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "background_min": float(np.min(arrays[4])),
        "calculated_min": float(np.min(arrays[3])),
        "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        "phases": phases,
    }


def valid(record):
    if not all(math.isfinite(record[k]) for k in ("rwp_percent", "gof", "chi_square", "max_shift_over_esd")):
        return False
    if record["background_min"] < -1e-6 or record["calculated_min"] < -1e-6 or record["frozen"]:
        return False
    inst = record["instrument"]
    if not (-0.5 <= inst["Zero"] <= 0.5 and 0.5 <= inst["Polariz."] <= 1.0):
        return False
    if not (0 <= inst["U"] <= 40 and 2 <= inst["W"] <= 40 and 0.1 <= inst["X"] <= 6):
        return False
    if any(value <= 0 for value in record["fractions"].values()):
        return False
    for phase in record["phases"]:
        cell = phase["cell"]
        if not all(2 < cell[key] < 30 for key in ("length_a", "length_b", "length_c")):
            return False
        if not all(45 < cell[key] < 145 for key in ("angle_alpha", "angle_beta", "angle_gamma")):
            return False
    size = record["phases"][2]["size"][1][0]
    md = record["phases"][2]["preferred_orientation"][1]
    strain = record["phases"][1]["microstrain"][1][:2]
    return 0.04 < size < 1.5 and 0.7 < md < 1.4 and all(0 < v < 32000 for v in strain)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    start = OUT / "start.gpx"
    work = OUT / "working.gpx"
    shutil.copy2(SOURCE, start)
    shutil.copy2(SOURCE, work)
    project = G2.G2Project(str(work))
    histogram = project.histograms()[0]
    assert [phase.name for phase in project.phases()] == EXPECTED
    assert histogram.name == "PWDR pattern.xye"
    project.set_Controls("cycles", 20)
    history = [snapshot(project, 0)]
    if not valid(history[0]):
        raise RuntimeError("starting model failed final physical guards")
    project.save(str(OUT / "checkpoint_00.gpx"))
    project.filename = str(work)
    for iteration in range(1, 9):
        clear_frozen(project)
        project.refine()
        record = snapshot(project, iteration)
        history.append(record)
        print(json.dumps({k: record[k] for k in ("iteration", "rwp_percent", "gof", "converged", "max_shift_over_esd", "fractions")}), flush=True)
        if not valid(record):
            break
        checkpoint = OUT / f"checkpoint_{iteration:02d}.gpx"
        project.save(str(checkpoint))
        project.filename = str(work)
        if record["converged"] and record["max_shift_over_esd"] < 0.05:
            break
    valid_records = [record for record in history if valid(record)]
    converged_records = [
        record for record in valid_records
        if record["converged"] and record["max_shift_over_esd"] < 0.05
    ]
    # Prefer an actually settled least-squares solution. The tiny Rwp increase
    # relative to the incoming cached profile is below 4e-5 percentage points.
    selected = min(converged_records or valid_records, key=lambda item: item["rwp_percent"])
    selected_checkpoint = OUT / f"checkpoint_{selected['iteration']:02d}.gpx"
    shutil.copy2(selected_checkpoint, OUT / "selected.gpx")
    (OUT / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    (OUT / "selected.json").write_text(json.dumps(selected, indent=2) + "\n")
    print("selected", json.dumps({k: selected[k] for k in ("iteration", "rwp_percent", "gof", "converged", "max_shift_over_esd", "fractions")}))


if __name__ == "__main__":
    main()
