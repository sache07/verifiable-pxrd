#!/usr/bin/env python3
"""Test symmetry-distinct Mn2WO6 texture axes from the stable four-phase model."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "final_convergence" / "selected.gpx"
OUT = ROOT / ".tmp" / "final_texture_branches"
AXES = {
    "none": None,
    "001": [0, 0, 1],
    "100": [1, 0, 0],
    "010": [0, 1, 0],
    "110": [1, 1, 0],
    "111": [1, 1, 1],
}


def clear_frozen(project):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project, histogram):
    amounts = [
        float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][histogram.name]["Scale"][0])
        for phase in project.phases()
    ]
    total = sum(amounts)
    return {phase.name: value / total for phase, value in zip(project.phases(), amounts)}


def run(label, axis):
    result = {"branch": label, "status": "unknown", "reason": None}
    try:
        folder = OUT / label
        folder.mkdir(parents=True, exist_ok=True)
        work = folder / "working.gpx"
        shutil.copy2(SOURCE, work)
        project = G2.G2Project(str(work))
        histogram = project.histograms()[0]
        phase = project.phase("mn2wo6_from_y2wo6_1541070")
        hap = phase.data["Histograms"][histogram.name]
        if axis is None:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
        else:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            project.set_Controls("parmMin", 0.7, "2:0:MD")
            project.set_Controls("parmMax", 1.4, "2:0:MD")
        project.set_Controls("cycles", 20)
        history = []
        for iteration in range(5):
            clear_frozen(project)
            project.refine()
            rvals = project.data["Covariance"]["data"]["Rvals"]
            history.append(
                {
                    "iteration": iteration + 1,
                    "rwp_percent": float(histogram.get_wR()),
                    "gof": float(rvals["GOF"]),
                    "max_shift_over_esd": float(rvals["Max shft/sig"]),
                    "converged": bool(rvals["converged"]),
                    "message": rvals.get("msg", ""),
                    "ratio": float(hap["Pref.Ori."][1]),
                    "axis": list(hap["Pref.Ori."][3]),
                    "fractions": fractions(project, histogram),
                    "frozen": [str(v) for v in project.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
                }
            )
            if history[-1]["converged"] and history[-1]["max_shift_over_esd"] < 0.05:
                break
        final = history[-1]
        if final["frozen"]:
            result.update(status="unknown", reason="refinement froze a bounded parameter")
        elif axis is not None and not 0.705 < final["ratio"] < 1.395:
            result.update(status="rejected", reason="texture ratio reached a boundary")
        else:
            result["status"] = "tested"
        result.update(final=final, history=history)
        project.save(str(folder / "refined.gpx"))
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc(limit=8)
    print(label, json.dumps(result), flush=True)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = [run(label, axis) for label, axis in AXES.items()]
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
