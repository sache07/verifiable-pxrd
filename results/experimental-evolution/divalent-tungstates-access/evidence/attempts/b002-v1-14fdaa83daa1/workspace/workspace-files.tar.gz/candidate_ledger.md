# Candidate ledger

The machine-readable ledger is `candidate_ledger.json`. Status values are updated only after a branch has been imported and fitted from the common screening setup. A failed import, invalid cell, or interrupted refinement remains **unknown**, not rejected.

Initial branches:

- pending — MnWO4, direct P2/c COD 1520200; the only available same-formula Mn-W-O entry.
- pending — MnWO4 analogue substitutions spanning P2/c wolframite, P-1 distorted wolframite, I41/a scheelite, and C2/c topology.
- pending — Mn2WO6 and Mn3WO6 analogue-derived Mn-rich oxides.
- pending — all available Mn3O4 and WO3 same-formula entries, plus symmetry-distinct MnO/Mn2O3 products.

