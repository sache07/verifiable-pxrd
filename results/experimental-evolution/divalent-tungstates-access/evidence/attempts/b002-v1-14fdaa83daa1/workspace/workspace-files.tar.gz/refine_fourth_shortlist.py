#!/usr/bin/env python3
"""Integrate the chemically valid trace-phase shortlist one branch at a time."""

from __future__ import annotations

import json
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SCREEN = ROOT / ".tmp" / "final_fourth_screen"
OUT = ROOT / ".tmp" / "refined_fourth_shortlist"
CANDIDATES = [
    "mn3w2o9_from_sr3w2o9_2311977",
    "mn2w2o7_from_li2w2o7_2106564",
    "mn2wo4_from_ag2wo4_1509984",
    "mn2wo4_from_li2wo4_1523083",
    "mnwo3_from_crwo3_1539081",
]


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(0.0, v) for _, v in vals)
    return {n: max(0.0, v) / total for n, v in vals}


def test(short):
    result = {"candidate": short, "status": "unknown", "reason": None}
    try:
        source = SCREEN / short / "candidate_cell.gpx"
        branch = OUT / short; branch.mkdir(parents=True, exist_ok=True)
        work = branch / "working.gpx"; shutil.copy2(source, work)
        p = G2.G2Project(str(work)); h = p.histograms()[0]
        assert p.phases()[-1].name == "trial__" + short
        clear_frozen(p)
        inst = h.data["Instrument Parameters"][0]
        for key in ("Zero", "Polariz.", "U", "W", "X"):
            inst[key][2] = True
        for var, lo, hi in [
            (":0:Zero", -0.5, 0.5), (":0:Polariz.", 0.5, 1.0),
            (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
            ("1:0:Mustrain;i", 0.0, 8000.0), ("1:0:Mustrain;a", 0.0, 32000.0),
            ("2:0:Size;i", 0.04, 1.5), ("2:0:MD", 0.7, 1.4), ("3:0:Scale", 0.0, 1e6),
        ]:
            p.set_Controls("parmMin", lo, var); p.set_Controls("parmMax", hi, var)
        for phase in p.phases():
            phase.set_refinements({"Cell": True})
            for atom in phase.atoms(): atom.refinement_flags = " "
            phase.data["Histograms"][h.name]["Scale"][1] = True
        wo3 = p.phases()[1].data["Histograms"][h.name]
        wo3["Mustrain"][0] = "uniaxial"; wo3["Mustrain"][2] = [True, True, False]; wo3["Mustrain"][3] = [0, 1, 0]
        minor = p.phases()[2].data["Histograms"][h.name]
        minor["Size"][2] = [True, False, False]
        minor["Pref.Ori."][2] = True; minor["Pref.Ori."][3] = [0, 0, 1]
        trial = p.phases()[3].data["Histograms"][h.name]
        trial["Size"][2] = [False, False, False]; trial["Mustrain"][2] = [False, False, False]; trial["Pref.Ori."][2] = False
        p.save(str(work)); p.set_Controls("cycles", 20)
        for _ in range(6):
            clear_frozen(p); p.refine()
        r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        result.update(
            status="tested", rwp_percent=float(h.get_wR()), gof=float(r.get("GOF", np.nan)),
            converged=bool(r.get("converged", False)), max_shift_over_esd=float(r.get("Max shft/sig", np.nan)),
            message=r.get("msg", ""), fractions=fractions(p, h),
            candidate_cell={k: float(v) for k, v in p.phases()[3].get_cell().items()},
            wo3_microstrain=wo3["Mustrain"], mn2wo6_size=minor["Size"], mn2wo6_texture=minor["Pref.Ori."],
            frozen=[str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        )
        p.save(str(branch / "refined.gpx"))
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"; result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for short in CANDIDATES:
        result = test(short); results.append(result)
        print(short, json.dumps(result), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
