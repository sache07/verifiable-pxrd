#!/usr/bin/env python3
"""Test scheelite MnWO4 as a fifth phase after admitting Mn3W2O9."""

from __future__ import annotations

import json
import math
import shutil
import traceback
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "refined_fourth_shortlist" / "mn3w2o9_from_sr3w2o9_2311977" / "refined.gpx"
OUT = ROOT / ".tmp" / "fifth_phase_test"
CANDIDATES = {
    "scheelite_ca_metric": ROOT / "candidates" / "mnwo4_scheelite_from_cawo4_7219229.cif",
    "scheelite_ba_metric": ROOT / "candidates" / "mnwo4_scheelite_ba_metric.cif",
}


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(p, repeats=2, cycles=12):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p); p.refine()


def fractions(p, h):
    vals = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(0.0, v) for _, v in vals)
    return {n: max(0.0, v) / total for n, v in vals}


def test(short, cif):
    result = {"candidate": short, "status": "unknown", "reason": None, "stages": {}}
    try:
        branch = OUT / short; branch.mkdir(parents=True, exist_ok=True)
        work = branch / "working.gpx"; shutil.copy2(SOURCE, work)
        p = G2.G2Project(str(work)); h = p.histograms()[0]; clear_frozen(p)
        for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
            h.data["Instrument Parameters"][0][key][2] = False
        for phase in p.phases():
            phase.clear_refinements({"Cell": True})
            for atom in phase.atoms(): atom.refinement_flags = " "
            hap = phase.data["Histograms"][h.name]
            hap["Scale"][1] = True; hap["Size"][2] = [False, False, False]; hap["Mustrain"][2] = [False, False, False]; hap["Pref.Ori."][2] = False
        phase = p.add_phase(str(cif), phasename=short, histograms=[h], fmthint="CIF")
        for atom in phase.atoms(): atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"] = [1.0, True]; hap["Size"][2] = [False, False, False]; hap["Mustrain"][2] = [False, False, False]; hap["Pref.Ori."][2] = False
        phase.clear_refinements({"Cell": True})
        c = phase.get_cell(); start = np.array([c[k] for k in ("length_a", "length_b", "length_c")])
        p.set_Controls("parmMin", 0.0, "4:0:Scale")
        p.save(str(work)); run(p)
        f1 = fractions(p, h)
        result["stages"]["scale"] = {"rwp_percent": float(h.get_wR()), "fractions": f1, "cell": phase.get_cell()}
        if f1.get(short, 0.0) < 0.0005 or hap["Scale"][0] <= 1e-10:
            result.update(status="rejected", reason="scale collapsed"); return result
        phase.set_refinements({"Cell": True}); run(p, repeats=3)
        c = phase.get_cell(); lengths = np.array([c[k] for k in ("length_a", "length_b", "length_c")])
        result["stages"]["cell"] = {"rwp_percent": float(h.get_wR()), "fractions": fractions(p, h), "cell": c, "max_length_change_fraction": float(np.max(np.abs(lengths / start - 1)))}

        # Restore retained common terms and integrate the addition.
        inst = h.data["Instrument Parameters"][0]
        for key in ("Zero", "Polariz.", "U", "W", "X"): inst[key][2] = True
        for item in p.phases(): item.set_refinements({"Cell": True})
        wo3 = p.phases()[1].data["Histograms"][h.name]; wo3["Mustrain"][2] = [True, True, False]
        minor = p.phases()[2].data["Histograms"][h.name]; minor["Size"][2] = [True, False, False]; minor["Pref.Ori."][2] = True
        for var, lo, hi in [
            (":0:Zero", -0.5, 0.5), (":0:Polariz.", 0.5, 1.0), (":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0), (":0:X", 0.1, 6.0),
            ("1:0:Mustrain;i", 0.0, 8000.0), ("1:0:Mustrain;a", 0.0, 32000.0), ("2:0:Size;i", 0.04, 1.5), ("2:0:MD", 0.7, 1.4),
        ]:
            p.set_Controls("parmMin", lo, var); p.set_Controls("parmMax", hi, var)
        run(p, repeats=6, cycles=20)
        r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        result["stages"]["integrated"] = {
            "rwp_percent": float(h.get_wR()), "gof": float(r.get("GOF", np.nan)), "fractions": fractions(p, h),
            "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)), "message": r.get("msg", ""), "cell": phase.get_cell(),
            "mn2wo6_size": minor["Size"], "mn2wo6_texture": minor["Pref.Ori."], "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
        }
        p.save(str(branch / "refined.gpx")); result["status"] = "tested"
    except Exception as exc:
        result["reason"] = f"{type(exc).__name__}: {exc}"; result["traceback"] = traceback.format_exc(limit=8)
    return result


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for short, cif in CANDIDATES.items():
        result = test(short, cif); results.append(result); print(short, json.dumps(result), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
