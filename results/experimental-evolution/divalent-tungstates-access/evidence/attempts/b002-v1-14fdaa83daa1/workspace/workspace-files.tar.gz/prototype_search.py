#!/usr/bin/env python3
"""Screen all one-substitution metal-W-O prototypes against the third residual family."""

from __future__ import annotations

import gzip
import json
import math
import warnings
import argparse
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Element
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import minimize
from scipy.signal import savgol_filter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02")


def cod_path(cod_id):
    return RESOURCE / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def transformed_positions(two_theta, lattice_scale, zero_shift):
    theta = np.deg2rad(np.asarray(two_theta) / 2)
    arg = np.sin(theta) / lattice_scale
    if np.any(np.abs(arg) >= 1):
        return np.full_like(theta, np.nan)
    return np.rad2deg(2 * np.arcsin(arg)) + zero_shift


def profile_on_grid(x, positions, intensities, sigma_deg=0.17):
    step = x[1] - x[0]
    impulses = np.zeros(len(x), dtype=float)
    u = (positions - x[0]) / step
    i = np.floor(u).astype(int)
    f = u - i
    good = np.isfinite(u) & (i >= 0) & (i < len(x) - 1)
    np.add.at(impulses, i[good], intensities[good] * (1 - f[good]))
    np.add.at(impulses, i[good] + 1, intensities[good] * f[good])
    return gaussian_filter1d(impulses, sigma_deg / step, mode="constant")


def fit_candidate(x, residual, weights, positions, intensities):
    base_loss = float(np.sum(weights * residual**2))

    def evaluate(params, details=False):
        scale, shift = map(float, params)
        moved = transformed_positions(positions, scale, shift)
        p = profile_on_grid(x, moved, intensities)
        den = float(np.sum(weights * p * p))
        amp = max(0.0, float(np.sum(weights * p * residual)) / den) if den > 0 else 0.0
        loss = float(np.sum(weights * (residual - amp * p) ** 2))
        if details:
            return loss, amp
        return loss

    best = None
    for start in ((1.0, 0.0), (0.98, 0.0), (1.02, 0.0), (1.0, -0.2), (1.0, 0.2)):
        trial = minimize(
            evaluate,
            start,
            method="Powell",
            bounds=((0.94, 1.06), (-0.5, 0.5)),
            options={"maxiter": 70, "xtol": 2e-5, "ftol": 1e-7},
        )
        if best is None or trial.fun < best.fun:
            best = trial
    loss, amplitude = evaluate(best.x, details=True)
    return {
        "profile_improvement_fraction": max(0.0, (base_loss - loss) / base_loss),
        "lattice_scale": float(best.x[0]),
        "zero_shift_deg": float(best.x[1]),
        "amplitude": amplitude,
        "optimizer_success": bool(best.success),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--fit", type=Path, default=ROOT / ".tmp" / "two_phase" / "simple_profile.csv")
    parser.add_argument("--out", type=Path, default=ROOT / ".tmp" / "prototype_search.json")
    args = parser.parse_args()
    fit = np.loadtxt(args.fit, delimiter=",", skiprows=1)
    x_full, observed, _calc, raw_residual, _background = fit.T
    mask = (x_full >= 15) & (x_full <= 70)
    x = x_full[mask]
    # Broad positive families carry the discovery signal; isolated negative
    # misfit and counting noise cannot reward a candidate.
    residual = np.maximum(savgol_filter(raw_residual[mask], 15, 3), 0.0)
    weights = 1 / np.maximum(observed[mask], 1.0)

    with gzip.open(RESOURCE / "index.json.gz", "rt") as stream:
        index = json.load(stream)
    rows = []
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 3 or not {"W", "O"} <= set(elements):
            continue
        parent_cation = next(e for e in elements if e not in {"W", "O"})
        try:
            if not Element(parent_cation).is_metal:
                continue
        except Exception:
            continue
        for formula, cod_id, sg_number, r_value in records:
            source = cod_path(cod_id)
            record = {
                "source_cod_id": cod_id,
                "source_formula": formula,
                "parent_cation": parent_cation,
                "source_space_group_number": sg_number,
                "source_r_value": r_value,
                "source_path": str(source),
                "status": "unknown",
            }
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = CifParser(source, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
                substitutions = {
                    specie: "Mn"
                    for site in structure
                    for specie in site.species
                    if specie.symbol == parent_cation
                }
                if parent_cation != "Mn":
                    if not substitutions:
                        raise ValueError("parent cation not represented on occupied sites")
                    structure.replace_species(substitutions)
                if parent_cation != "Mn" and parent_cation in structure.composition.get_el_amt_dict():
                    raise ValueError("analogue substitution was incomplete")
                structure.remove_oxidation_states()
                distances = np.asarray(structure.distance_matrix, float)
                np.fill_diagonal(distances, np.inf)
                if len(structure) > 1 and float(distances.min()) < 0.8:
                    raise ValueError("hard contact after substitution")
                pattern = XRDCalculator(wavelength="CuKa").get_pattern(
                    structure, two_theta_range=(12, 74), scaled=False
                )
                positions = np.asarray(pattern.x, float)
                intensities = np.asarray(pattern.y, float)
                if len(positions) == 0 or intensities.max() <= 0:
                    raise ValueError("empty powder pattern")
                score = fit_candidate(x, residual, weights, positions, intensities)
                record.update(
                    status="tested",
                    target_formula=structure.composition.reduced_formula,
                    detected_space_group=structure.get_space_group_info()[0],
                    detected_space_group_number=structure.get_space_group_info()[1],
                    cell=list(map(float, structure.lattice.parameters)),
                    sites_in_cell=len(structure),
                    minimum_distance_A=float(distances.min()),
                    **score,
                )
            except Exception as exc:
                record["reason"] = f"{type(exc).__name__}: {exc}"
            rows.append(record)
    rows.sort(key=lambda r: r.get("profile_improvement_fraction", -1), reverse=True)
    out = args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows[:60]:
        print(
            f"{row['source_cod_id']} {row['source_formula']:<18} -> {row.get('target_formula','?'):<14} "
            f"sg={row.get('detected_space_group_number')} improve={row.get('profile_improvement_fraction')} "
            f"scale={row.get('lattice_scale')} shift={row.get('zero_shift_deg')}"
        )


if __name__ == "__main__":
    main()
