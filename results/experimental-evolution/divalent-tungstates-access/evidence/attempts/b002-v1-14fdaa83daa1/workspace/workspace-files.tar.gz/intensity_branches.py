#!/usr/bin/env python3
"""Screen one roughness model or one phase/axis texture term at a time."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "size_branches" / "size_phase2.gpx"
OUT = ROOT / ".tmp" / "intensity_branches"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(p, repeats=2, cycles=12):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()


def common_prepare(destination):
    shutil.copy2(SOURCE, destination)
    p = G2.G2Project(str(destination))
    h = p.histograms()[0]
    clear_frozen(p)
    inst = h.data["Instrument Parameters"][0]
    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
        inst[key][2] = False
    sp = h.data["Sample Parameters"]
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        sp[key][1] = False
    for phase in p.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    p.save(str(destination))
    return p


def clone(source, destination):
    shutil.copy2(source, destination)
    p = G2.G2Project(str(destination))
    clear_frozen(p)
    return p


def snap(p):
    h = p.histograms()[0]
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    sp = h.data["Sample Parameters"]
    return {
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "roughness": {k: [float(sp[k][0]), bool(sp[k][1])] for k in ("SurfRoughA", "SurfRoughB")},
        "texture": {
            phase.name: {
                "ratio": float(phase.data["Histograms"][h.name]["Pref.Ori."][1]),
                "refine": bool(phase.data["Histograms"][h.name]["Pref.Ori."][2]),
                "axis": list(phase.data["Histograms"][h.name]["Pref.Ori."][3]),
            }
            for phase in p.phases()
        },
    }


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    common_path = OUT / "common.gpx"
    p = common_prepare(common_path)
    run(p)
    p.save(str(common_path))
    results = {"common": snap(p)}
    print("common", json.dumps(results["common"]), flush=True)

    rough_path = OUT / "roughness.gpx"
    p = clone(common_path, rough_path)
    sp = p.histograms()[0].data["Sample Parameters"]
    sp["SurfRoughA"] = [0.15, True]
    sp["SurfRoughB"] = [0.10, True]
    p.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
    p.set_Controls("parmMax", 0.6, ":0:SurfRoughA")
    p.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
    p.set_Controls("parmMax", 0.5, ":0:SurfRoughB")
    p.save(str(rough_path))
    run(p, repeats=3)
    p.save(str(rough_path))
    results["roughness"] = snap(p)
    print("roughness", json.dumps(results["roughness"]), flush=True)

    for phase_id in range(3):
        for axis in AXES:
            key = f"texture_p{phase_id}_{axis[0]}{axis[1]}{axis[2]}"
            path = OUT / f"{key}.gpx"
            p = clone(common_path, path)
            h = p.histograms()[0]
            po = p.phases()[phase_id].data["Histograms"][h.name]["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.0
            po[2] = True
            po[3] = list(axis)
            p.set_Controls("parmMin", 0.7, f"{phase_id}:0:MD")
            p.set_Controls("parmMax", 1.4, f"{phase_id}:0:MD")
            p.save(str(path))
            run(p)
            p.save(str(path))
            results[key] = snap(p)
            print(key, json.dumps(results[key]), flush=True)
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
