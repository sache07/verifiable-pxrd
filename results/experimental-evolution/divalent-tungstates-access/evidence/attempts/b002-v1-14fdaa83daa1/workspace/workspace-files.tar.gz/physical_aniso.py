#!/usr/bin/env python3
"""Replace boundary WO3 isotropic strain with the supported [010] uniaxial model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "physical_combined" / "combined.gpx"
OUT = ROOT / ".tmp" / "physical_aniso"


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(p, h):
    values = [(phase.name, float(phase.data["General"]["Mass"]) * float(phase.data["Histograms"][h.name]["Scale"][0])) for phase in p.phases()]
    total = sum(max(0.0, v) for _, v in values)
    return {n: max(0.0, v) / total for n, v in values}


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    work = OUT / "working.gpx"
    shutil.copy2(SOURCE, work)
    p = G2.G2Project(str(work))
    h = p.histograms()[0]
    clear_frozen(p)
    hap = p.phases()[1].data["Histograms"][h.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 6500.0
    hap["Mustrain"][1][1] = 10500.0
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = [0, 1, 0]
    for suffix, upper in (("i", 8000.0), ("a", 32000.0)):
        p.set_Controls("parmMin", 0.0, f"1:0:Mustrain;{suffix}")
        p.set_Controls("parmMax", upper, f"1:0:Mustrain;{suffix}")
    p.save(str(work))
    p.set_Controls("cycles", 20)
    for _ in range(6):
        clear_frozen(p)
        p.refine()
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    inst = h.data["Instrument Parameters"][0]
    result = {
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "fractions": fractions(p, h),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "Polariz.", "U", "W", "X", "SH/L")},
        "wo3_microstrain": hap["Mustrain"],
        "mn2wo6_size": p.phases()[2].data["Histograms"][h.name]["Size"],
        "mn2wo6_texture": p.phases()[2].data["Histograms"][h.name]["Pref.Ori."],
        "frozen": [str(v) for v in p.data["Controls"]["data"].get("parmFrozen", {}).get("FrozenList", [])],
    }
    p.save(str(OUT / "aniso.gpx"))
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
