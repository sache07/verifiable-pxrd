#!/usr/bin/env python3
"""One-term profile/texture tests from the physically valid structural rollback."""

from __future__ import annotations

import copy
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "physical_refine2" / "01_major_phase_coordinates.gpx"
OUT = ROOT / ".tmp" / "physical_branches"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def clear_frozen(p):
    p.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def run(p, repeats=2, cycles=10):
    p.set_Controls("cycles", cycles)
    for _ in range(repeats):
        clear_frozen(p)
        p.refine()


def snap(p):
    h = p.histograms()[0]
    r = p.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    sp = h.data["Sample Parameters"]
    return {
        "rwp_percent": float(h.get_wR()),
        "gof": float(r.get("GOF", np.nan)),
        "converged": bool(r.get("converged", False)),
        "max_shift_over_esd": float(r.get("Max shft/sig", np.nan)),
        "message": r.get("msg", ""),
        "sample": {k: [float(sp[k][0]), bool(sp[k][1])] for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "profiles": {
            phase.name: {
                "size": copy.deepcopy(phase.data["Histograms"][h.name]["Size"]),
                "microstrain": copy.deepcopy(phase.data["Histograms"][h.name]["Mustrain"]),
                "texture": copy.deepcopy(phase.data["Histograms"][h.name]["Pref.Ori."]),
            }
            for phase in p.phases()
        },
    }


def prepare_common(path):
    shutil.copy2(SOURCE, path)
    p = G2.G2Project(str(path))
    h = p.histograms()[0]
    clear_frozen(p)
    for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"):
        h.data["Instrument Parameters"][0][key][2] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        h.data["Sample Parameters"][key][1] = False
    for phase in p.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    p.save(str(path))
    run(p)
    p.save(str(path))
    return p


def clone(common, path):
    shutil.copy2(common, path)
    p = G2.G2Project(str(path))
    clear_frozen(p)
    return p


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    common_path = OUT / "common.gpx"
    p = prepare_common(common_path)
    results = {"common": snap(p)}
    print("common", json.dumps(results["common"]), flush=True)

    # Isotropic crystallite size, one phase at a time.
    for phase_id in range(3):
        key = f"size_p{phase_id}"
        path = OUT / f"{key}.gpx"
        p = clone(common_path, path)
        h = p.histograms()[0]
        hap = p.phases()[phase_id].data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [True, False, False]
        p.set_Controls("parmMin", 0.04, f"{phase_id}:0:Size;i")
        p.set_Controls("parmMax", 1.5, f"{phase_id}:0:Size;i")
        p.save(str(path)); run(p); p.save(str(path))
        results[key] = snap(p); print(key, json.dumps(results[key]), flush=True)

    # Uniaxial strain for each broad phase and each generator-supported axis.
    for phase_id in (1, 2):
        for axis in AXES[:3]:
            key = f"strain_p{phase_id}_{axis[0]}{axis[1]}{axis[2]}"
            path = OUT / f"{key}.gpx"
            p = clone(common_path, path)
            h = p.histograms()[0]
            hap = p.phases()[phase_id].data["Histograms"][h.name]
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = 5000.0
            hap["Mustrain"][1][1] = 8000.0
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = list(axis)
            for suffix, hi in (("i", 8000.0), ("a", 32000.0)):
                p.set_Controls("parmMin", 0.0, f"{phase_id}:0:Mustrain;{suffix}")
                p.set_Controls("parmMax", hi, f"{phase_id}:0:Mustrain;{suffix}")
            p.save(str(path)); run(p); p.save(str(path))
            results[key] = snap(p); print(key, json.dumps(results[key]), flush=True)

    # One March-Dollase term on the analogue phase at a time.
    for axis in AXES:
        key = f"texture_p2_{axis[0]}{axis[1]}{axis[2]}"
        path = OUT / f"{key}.gpx"
        p = clone(common_path, path)
        h = p.histograms()[0]
        po = p.phases()[2].data["Histograms"][h.name]["Pref.Ori."]
        po[0] = "MD"; po[1] = 1.0; po[2] = True; po[3] = list(axis)
        p.set_Controls("parmMin", 0.7, "2:0:MD")
        p.set_Controls("parmMax", 1.4, "2:0:MD")
        p.save(str(path)); run(p); p.save(str(path))
        results[key] = snap(p); print(key, json.dumps(results[key]), flush=True)

    # Shift alone, with instrument zero fixed at the common value.
    path = OUT / "shift.gpx"
    p = clone(common_path, path)
    p.histograms()[0].data["Sample Parameters"]["Shift"] = [0.0, True]
    p.set_Controls("parmMin", -800.0, ":0:Shift")
    p.set_Controls("parmMax", 800.0, ":0:Shift")
    p.save(str(path)); run(p); p.save(str(path))
    results["shift"] = snap(p); print("shift", json.dumps(results["shift"]), flush=True)

    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
