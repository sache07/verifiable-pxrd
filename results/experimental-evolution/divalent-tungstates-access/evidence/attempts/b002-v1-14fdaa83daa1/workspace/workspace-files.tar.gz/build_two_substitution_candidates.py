#!/usr/bin/env python3
"""Build Mn2WO6 models from every P212121 A2BO6 two-substitution parent."""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Composition, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
LIBRARY = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
OUT = ROOT / "candidates"
SOURCE_IDS = ["2239027", "1531778", "8100234", "1535177", "1541070", "2106838", "1527431", "2106238", "2213598"]


def source_path(cod_id):
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def contact_summary(structure):
    centers, neighbors, images, distances = structure.get_neighbor_list(3.5)
    all_distances, oxygen_distances = [], []
    for i, j, image, distance in zip(centers, neighbors, images, distances):
        if i > j or (i == j and tuple(image) <= (0, 0, 0)):
            continue
        all_distances.append(float(distance))
        if structure[int(i)].species_string == "O" and structure[int(j)].species_string == "O":
            oxygen_distances.append(float(distance))
    return min(all_distances), min(oxygen_distances)


def main():
    rows = []
    for cod_id in SOURCE_IDS:
        path = source_path(cod_id)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(path, primitive=False)
        structure.remove_oxidation_states()
        reduced = structure.composition.reduced_composition.get_el_amt_dict()
        cations = {element: value for element, value in reduced.items() if element != "O"}
        if abs(reduced.get("O", 0) - 6) > 1e-6 or sorted(cations.values()) != [1.0, 2.0]:
            raise RuntimeError(f"{cod_id} is not an A2BO6 parent: {reduced}")
        divalent_site = next(element for element, value in cations.items() if value == 2)
        tungsten_site = next(element for element, value in cations.items() if value == 1)
        structure.replace_species({divalent_site: "Mn", tungsten_site: "W"})
        structure.remove_oxidation_states()
        target = structure.composition.reduced_composition.get_el_amt_dict()
        if target != {"Mn": 2.0, "W": 1.0, "O": 6.0}:
            raise RuntimeError(f"incomplete substitution for {cod_id}: {target}")
        dmin, oo = contact_summary(structure)
        short = f"mn2wo6_two_sub_{cod_id}"
        destination = OUT / f"{short}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(destination)
        parsed = Structure.from_file(destination, primitive=False)
        row = {
            "candidate": short,
            "path": str(destination.relative_to(ROOT)),
            "source_cod_id": cod_id,
            "source_formula": Composition(reduced).reduced_formula,
            "substitutions": {divalent_site: "Mn", tungsten_site: "W"},
            "target_formula": parsed.composition.reduced_formula,
            "space_group": parsed.get_space_group_info(symprec=1e-3)[0],
            "space_group_number": parsed.get_space_group_info(symprec=1e-3)[1],
            "cell": list(map(float, parsed.lattice.parameters)),
            "sites_in_cell": len(parsed),
            "density_g_cm3": float(parsed.density),
            "physical_screen": {
                "minimum_interatomic_distance_A": dmin,
                "minimum_O_O_distance_A": oo,
                "pass": bool(dmin >= 0.8 and oo >= 1.8),
            },
            "status": "pending",
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (ROOT / "two_substitution_ledger.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
