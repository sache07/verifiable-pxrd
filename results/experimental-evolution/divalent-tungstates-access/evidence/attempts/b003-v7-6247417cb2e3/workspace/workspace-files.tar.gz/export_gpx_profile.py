#!/usr/bin/env python3
"""Export the saved GSAS-II histogram arrays and a compact model snapshot."""

from __future__ import annotations

import csv
import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


source = Path(sys.argv[1]).resolve()
destination = Path(sys.argv[2]).resolve()
project = G2.G2Project(gpxfile=str(source))
hist = max(project.histograms(), key=lambda item: len(item.getdata("X")))

x = np.asarray(hist.getdata("X"), dtype=float)
obs = np.asarray(hist.getdata("Yobs"), dtype=float)
calc = np.asarray(hist.getdata("Ycalc"), dtype=float)
background = np.asarray(hist.getdata("Background"), dtype=float)
difference = obs - calc

with destination.open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["two_theta_deg", "observed", "calculated", "difference", "background"])
    writer.writerows(zip(x, obs, calc, difference, background))

weights = np.asarray(hist.getdata("Yweight"), dtype=float)
manual_rwp = 100.0 * np.sqrt(np.sum(weights * difference**2) / np.sum(weights * obs**2))

phase_info = {}
weighted_mass = {}
for phase in project.phases():
    hap = phase.data["Histograms"].get(hist.name)
    if not hap or not hap.get("Use", True):
        continue
    weighted_mass[phase.name] = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
    phase_info[phase.name] = {
        "cell": phase.get_cell(),
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "scale": float(hap["Scale"][0]),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": [float(value) for value in atom.coordinates],
                "occupancy": float(atom.occupancy),
                "refinement_flags": atom.refinement_flags,
                "uiso": float(atom.uiso) if atom.adp_flag == "I" else None,
            }
            for atom in phase.atoms()
        ],
    }
total = sum(weighted_mass.values())
for name, value in weighted_mass.items():
    phase_info[name]["weight_fraction"] = value / total

cov = project.data.get("Covariance", {}).get("data", {})
rvals = cov.get("Rvals", {})
summary = {
    "project": str(source),
    "histogram": hist.name,
    "points": len(x),
    "Rwp_percent_saved": float(hist.get_wR()),
    "Rwp_percent_manual": float(manual_rwp),
    "Rp_percent": float(hist.residuals.get("R", np.nan)),
    "converged": bool(rvals.get("converged", False)),
    "max_shift_esd": rvals.get("Max shft/sig"),
    "frozen": [str(value) for value in project.get_Frozen()],
    "instrument": hist.InstrumentParameters,
    "sample": hist.SampleParameters,
    "background": hist.Background,
    "phases": phase_info,
}
destination.with_suffix(".json").write_text(json.dumps(summary, indent=2, default=str) + "\n")
print(json.dumps({key: summary[key] for key in ("Rwp_percent_saved", "Rwp_percent_manual", "converged", "max_shift_esd", "frozen")}))
