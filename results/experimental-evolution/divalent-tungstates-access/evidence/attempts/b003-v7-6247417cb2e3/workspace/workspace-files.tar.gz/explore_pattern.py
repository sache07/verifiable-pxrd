#!/usr/bin/env python3
"""Initial peak and reference-pattern diagnostics for the Mn-W-O scan."""

from __future__ import annotations

import csv
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import percentile_filter
from scipy.signal import find_peaks


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
IDS = {
    "MnWO4 1520200": "1520200",
    "Mn3WO6 2002703": "2002703",
    "WO3 2106293": "2106293",
    "WO3 1528915": "1528915",
    "Mn3O4 9001963": "9001963",
    "Mn2O3 1514230": "1514230",
    "MnO 1514108": "1514108",
}


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


with (ROOT / "inputs/pattern.csv").open(newline="") as handle:
    rows = list(csv.DictReader(handle))
x = np.array([float(row["two_theta_deg"]) for row in rows])
y = np.array([float(row["intensity"]) for row in rows])
baseline = percentile_filter(y, size=501, percentile=15, mode="nearest")
net = y - baseline
peaks, props = find_peaks(net, prominence=250, distance=7)

fig, axes = plt.subplots(
    len(IDS) + 1,
    1,
    figsize=(16, 12),
    sharex=True,
    gridspec_kw={"height_ratios": [5] + [1] * len(IDS)},
)
axes[0].plot(x, y, lw=0.65, color="black")
axes[0].plot(x, baseline, lw=0.8, color="tab:orange")
axes[0].scatter(x[peaks], y[peaks], s=4, color="tab:red")
axes[0].set_ylabel("counts")

calculator = XRDCalculator(wavelength="CuKa")
for axis, (label, cod_id) in zip(axes[1:], IDS.items()):
    structure = Structure.from_file(cif_path(cod_id))
    pattern = calculator.get_pattern(structure, two_theta_range=(x.min(), x.max()))
    intensity = np.asarray(pattern.y, dtype=float)
    axis.vlines(pattern.x, 0, intensity / intensity.max(), lw=0.7)
    axis.set_ylim(0, 1.05)
    axis.set_ylabel(label, rotation=0, ha="right", va="center")

axes[-1].set_xlabel(r"$2\theta$ (degrees)")
axes[-1].set_xlim(x.min(), x.max())
fig.tight_layout()
fig.savefig(ROOT / "diagnostic_initial.png", dpi=170)
