#!/usr/bin/env python3
"""Read-only geometry and refinement-state audit for a GSAS-II project."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrMain as G2st


project = G2.G2Project(gpxfile=str(Path(sys.argv[1]).resolve()))
report = {"project": str(Path(sys.argv[1]).resolve()), "phases": {}}
for phase in project.phases():
    controls, data = phase.InitDisAgl(False)
    controls["Factors"] = [1.25, 0.0]
    _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
    atoms = phase.atoms()
    pair_minima = {}
    for center, rows in distances.items():
        for row in rows:
            other = int(row[0])
            pair = "-".join(sorted((atoms[center].element, atoms[other].element)))
            distance = float(row[-2])
            pair_minima[pair] = min(pair_minima.get(pair, distance), distance)
    report["phases"][phase.name] = {
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "cell": phase.get_cell(),
        "composition_mass_amu": float(phase.data["General"]["Mass"]),
        "pair_min_A": pair_minima,
        "catastrophic_contacts": [
            [str(left), str(right), float(distance)]
            for left, right, distance in phase.ShortDistances(useAll=False)
        ],
    }
print(json.dumps(report, indent=2))
