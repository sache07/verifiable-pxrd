#!/usr/bin/env python3
"""Export the verified final GSAS-II replay without changing final.gpx."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys

import numpy as np


root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
replay_dir = root / "work" / "final_replay"
replay = json.loads((replay_dir / "replay.json").read_text())
if replay.get("status") != "replayed":
    raise RuntimeError(f"final project did not replay: {replay}")
if replay.get("profile_review_flags"):
    raise RuntimeError(f"final replay has review flags: {replay['profile_review_flags']}")

phase_metadata = {
    "MnWO4_wolframite": {
        "display_name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "space_group": "P 2/c",
        "reference": "COD 1520200",
        "filename": "phase_1_MnWO4.cif",
    },
    "Mn3WO6_rhombohedral": {
        "display_name": "Mn3WO6 (rhombohedral)",
        "formula": "Mn3WO6",
        "space_group": "R -3",
        "reference": "COD 2002703",
        "filename": "phase_2_Mn3WO6.cif",
    },
    "WO3_triclinic": {
        "display_name": "WO3 (triclinic)",
        "formula": "WO3",
        "space_group": "P -1",
        "reference": "COD 2106293",
        "filename": "phase_3_WO3.cif",
    },
}

phase_rows = []
for phase in replay["phases"]:
    name = phase["name"]
    if name not in phase_metadata:
        raise RuntimeError(f"unexpected phase in final replay: {name}")
    metadata = phase_metadata[name]
    source_cif = replay_dir / phase["cif"]
    output_cif = root / metadata["filename"]
    shutil.copy2(source_cif, output_cif)
    phase_rows.append({
        "name": metadata["display_name"],
        "project_phase": name,
        "formula": metadata["formula"],
        "space_group": metadata["space_group"],
        "reference_structure": metadata["reference"],
        "cif_path": metadata["filename"],
        "weight_fraction": float(phase["weight_fraction"]),
    })

with np.load(replay_dir / "prediction.npz", allow_pickle=False) as values:
    x = values["x"].astype(float)
    observed = values["observed"].astype(float)
    calculated = values["predicted"].astype(float)
    background = values["background"].astype(float)
difference = observed - calculated

with (root / "fit.csv").open("w", newline="") as handle:
    writer = csv.writer(handle)
    writer.writerow(["two_theta", "observed", "calculated", "difference", "background"])
    writer.writerows(zip(x, observed, calculated, difference, background))

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp_percent = float(100.0 * np.sqrt(chi_square / denominator))
rp_percent = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))

project_path = root / "final.gpx"
project_sha256 = hashlib.sha256(project_path.read_bytes()).hexdigest()
if project_sha256 != replay["project_sha256"]:
    raise RuntimeError("final.gpx changed after its verified replay")

zero_parameter = replay.get("instrument", {}).get("Zero")
zero_deg = None
if isinstance(zero_parameter, list) and len(zero_parameter) > 1:
    zero_deg = float(zero_parameter[1])

fit_statistics = {
    "Rwp_percent": rwp_percent,
    "Rp_percent": rp_percent,
    "chi_square": chi_square,
    "n_points": int(len(x)),
    "weighting": "1/max(observed_count, 1)",
    "profile_source": "read-only native GSAS-II atomic replay on the complete observed grid",
}
result = {
    "project_path": "final.gpx",
    "project_sha256": project_sha256,
    "refinement_histogram": replay["histogram"],
    "phases": phase_rows,
    "fit_statistics": fit_statistics,
    "calibration": {"zero_deg": zero_deg},
    "fraction_basis": "normalized over the modeled crystalline phases",
}
(root / "result.json").write_text(json.dumps(result, indent=2) + "\n")

audit_path = root / "polished.staged_polish.json"
audit = json.loads(audit_path.read_text()) if audit_path.is_file() else {}
selected = audit.get("selected", {})
selected_name = selected.get("name", "unknown")
selected_rwp = selected.get("Rwp_percent", rwp_percent)
selected_branch = next(
    (branch for branch in audit.get("branches", []) if branch.get("name") == selected_name),
    {},
)
if selected_name != "baseline" and not selected_branch.get("eligible", False):
    raise RuntimeError("the selected staged-polish branch is not audit-eligible")

fraction_by_formula = {row["formula"]: row["weight_fraction"] for row in phase_rows}
if selected_name == "baseline":
    coordinate_statement = (
        "The bounded coordinate-polish branches did not clear the script's combined "
        "material-improvement and physical-audit threshold, so reference-constrained "
        "coordinates were retained. Fine oxygen positions, especially in WO3, are less "
        "securely determined than the phase identity and lattice."
    )
else:
    coordinate_statement = (
        f"The bounded `{selected_name}` coordinate-polish branch was selected and passed "
        "the convergence, fraction-stability, and geometry audits. Fine oxygen positions "
        "remain less precisely constrained than phase identity and lattice."
    )

report = f"""# Powder XRD phase analysis

## Result

| Phase | Structure | Crystalline weight fraction |
|---|---|---:|
| MnWO4 (wolframite) | P 2/c; COD 1520200 | {100*fraction_by_formula['MnWO4']:.3f}% |
| Mn3WO6 | R -3; COD 2002703 | {100*fraction_by_formula['Mn3WO6']:.3f}% |
| WO3 | P -1 triclinic; COD 2106293 | {100*fraction_by_formula['WO3']:.3f}% |

The final read-only atomic replay gives Rwp = {rwp_percent:.4f}% and Rp = {rp_percent:.4f}% over all {len(x)} measured points. The mandatory staged polish selected `{selected_name}` at Rwp = {float(selected_rwp):.4f}%; its output is the submitted `final.gpx`. Replay generated fresh structure factors and reflection lists, changed no parameters, and returned no profile-review flags.

## Evidence

MnWO4 accounts for the dominant wolframite reflection set. The 19.68/20.18 degree pair and its higher-angle family require rhombohedral Mn3WO6, while the 22.89/24.16 degree peaks and the 33-34 degree family require WO3. Controlled phase deletion raised Rwp from the complete rough model (10.80%) to 12.92% without Mn3WO6, 16.36% without WO3, and 17.76% for MnWO4 alone.

Several exact-composition WO3 parents were developed comparably. The accepted triclinic P -1 basin reached 3.20% before the final polish and retained physical contacts (minimum O-O about 2.56 A); the best monoclinic alternative stopped at 3.30% and inherited an implausibly short O-O contact near 1.58 A, so it was discarded. Orthorhombic and alternate monoclinic starts fit substantially worse. In the accepted model, every coherent reflection family is indexed by one of the three retained phases; the largest remaining residuals are paired peak-center/wing shape errors on accepted reflections rather than a separate indexed family.

## Uncertainty

The fractions are normalized only over modeled crystalline material; this measurement does not quantify amorphous content. Strong but bounded preferred orientation is needed for all three phases, and the Mn3WO6 texture axis has close alternatives, so systematic fraction uncertainty is larger than a covariance-only standard error. Nevertheless, the phase contributions remain positive and the fractions are stable across the accepted branches. No fourth crystalline phase can be identified reliably, and trace phases below the pattern's detection limit are not excluded.

{coordinate_statement}

Calibration/profile alternatives that reached bounds or were inseparable from correlated parameters were rolled back. The retained zero offset ({zero_deg:.6f} degrees), axial-divergence term, crystallite sizes, Mn3WO6 isotropic microstrain, and March-Dollase terms are all inside the supplied laboratory ranges.
"""
(root / "report.md").write_text(report)

print(json.dumps({
    "Rwp_percent": rwp_percent,
    "Rp_percent": rp_percent,
    "project_sha256": project_sha256,
    "selected_polish_branch": selected_name,
    "phases": {row["formula"]: row["weight_fraction"] for row in phase_rows},
}, indent=2))
