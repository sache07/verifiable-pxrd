#!/usr/bin/env python3
"""Continue a GSAS-II checkpoint with an explicitly selected parameter set."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2

from gsas_refine import fractions, set_bounds, snapshot


COORDINATE_VARIABLE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False


def select_phases(value: str, project: G2.G2Project) -> list[int]:
    if value == "all":
        return list(range(len(project.phases())))
    if value in {"", "none"}:
        return []
    return [int(item) for item in value.split(",")]


def covariance_summary(project: G2.G2Project) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    variables = [str(value) for value in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    pairs = []
    if matrix.ndim == 2 and matrix.shape == (len(variables), len(variables)):
        diagonal = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        denominator = np.outer(diagonal, diagonal)
        correlation = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator > 0)
        for row in range(len(variables)):
            for column in range(row):
                value = float(correlation[row, column])
                if abs(value) >= 0.75:
                    pairs.append([variables[column], variables[row], value])
    pairs.sort(key=lambda item: abs(item[2]), reverse=True)
    return {"high_correlations": pairs[:50]}


def install_profile_bounds(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hid = hist.id
    for phase in project.phases():
        pid = phase.id
        for variable, lower, upper in (
            (f"{pid}:{hid}:Size;i", 0.04, 1.5),
            (f"{pid}:{hid}:Mustrain;i", 300.0, 8000.0),
            (f"{pid}:{hid}:Mustrain;a", 300.0, 8000.0),
            (f"{pid}:{hid}:MD", 0.7, 1.4),
        ):
            project.set_Controls("parmMin", lower, variable=variable)
            project.set_Controls("parmMax", upper, variable=variable)


def install_coordinate_bounds(project: G2.G2Project, selected: list[int]) -> None:
    for phase_index in selected:
        phase = project.phases()[phase_index]
        pid = phase.id
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for atom_index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half_width = 0.10 / float(length)
                variable = f"{pid}::dA{axis}:{atom_index}"
                project.set_Controls("parmMin", float(value) - half_width, variable=variable)
                project.set_Controls("parmMax", float(value) + half_width, variable=variable)


def configure_uiso(project: G2.G2Project, args: argparse.Namespace) -> None:
    if args.normalize_uiso:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.data[atom.cia] = "I"
                atom.data[atom.cia + 1] = 0.005
    selected = select_phases(args.uiso, project)
    for phase_index in selected:
        phase = project.phases()[phase_index]
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.adp_flag != "I":
                raise ValueError("Uiso refinement requires --normalize-uiso")
            atom.refinement_flags = "U"
            variable = f"{phase.id}::AUiso:{atom_index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def enable_flags(project: G2.G2Project, args: argparse.Namespace) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({"Scale": True})

    instrument = [item for item in args.instrument.split(",") if item]
    if instrument:
        hist.set_refinements({"Instrument Parameters": instrument})

    sample = []
    if args.shift:
        sample.append("Shift")
    if args.roughness:
        if hist.SampleParameters["SurfRoughA"][0] <= 0:
            hist.SampleParameters["SurfRoughA"][0] = 0.2
        if hist.SampleParameters["SurfRoughB"][0] <= 0:
            hist.SampleParameters["SurfRoughB"][0] = 0.1
        sample.extend(["SurfRoughA", "SurfRoughB"])
    if sample:
        hist.set_refinements({"Sample Parameters": sample})

    for index in select_phases(args.size, project):
        project.phases()[index].set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True}
        })
    mustrain_indices = select_phases(args.mustrain, project)
    uniaxial_specs = []
    for specification in args.uniaxial_mustrain:
        index_text, axis_text = specification.split(":", 1)
        uniaxial_specs.append((int(index_text), [int(value) for value in axis_text.split(",")]))
    active_mustrain = set(mustrain_indices) | {item[0] for item in uniaxial_specs}
    if args.zero_mustrain:
        for phase_index, phase in enumerate(project.phases()):
            hap = phase.data["Histograms"][hist.name]
            hap["Mustrain"][1][0] = 800.0 if phase_index in active_mustrain else 0.0
            hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
    for index in mustrain_indices:
        project.phases()[index].set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        })
    for index, axis in uniaxial_specs:
        project.phases()[index].set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial",
                "direction": axis,
                "refine": True,
            }
        })
    for index in args.reset_texture:
        phase = project.phases()[index]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    for specification in args.texture:
        index_text, axis_text = specification.split(":", 1)
        index = int(index_text)
        axis = [int(value) for value in axis_text.split(",")]
        phase = project.phases()[index]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][3] = axis
        if not 0.7 <= float(hap["Pref.Ori."][1]) <= 1.4:
            hap["Pref.Ori."][1] = 1.0
        phase.set_HAP_refinements({"Pref.Ori.": True})

    atom_indices = select_phases(args.atoms, project)
    install_coordinate_bounds(project, atom_indices)
    for index in atom_indices:
        for atom in project.phases()[index].atoms():
            oxygen = atom.element.strip().upper() in {"O", "O-2"}
            selected = (
                args.atom_elements == "all"
                or (args.atom_elements == "oxygen" and oxygen)
                or (args.atom_elements == "heavy" and not oxygen)
            )
            atom.refinement_flags = args.atom_flags if selected else " "
    configure_uiso(project, args)


def run(source: Path, destination: Path, args: argparse.Namespace) -> dict:
    destination.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source), newgpx=str(destination))
    source_coordinates = {
        (phase.id, atom_index): tuple(float(value) for value in atom.coordinates)
        for phase in project.phases()
        for atom_index, atom in enumerate(phase.atoms())
    }
    clear_flags(project)
    set_bounds(project)
    install_profile_bounds(project)
    enable_flags(project, args)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", args.cycles)
    project.save()

    records = []
    excluded_coordinate_atoms: set[tuple[int, int]] = set()
    for index in range(args.passes):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.refine(makeBack=False)
        project.save()
        record = snapshot(project, f"pass_{index + 1}")
        record.update(covariance_summary(project))
        records.append(record)
        print(json.dumps({
            "pass": index + 1,
            "Rwp_percent": record["Rwp_percent"],
            "converged": record["converged"],
            "max_shift_esd": record["max_shift_esd"],
            "frozen": record["frozen"],
            "fractions": record["fractions"],
            "high_correlations": record["high_correlations"][:8],
        }), flush=True)
        if args.stabilize_coordinates:
            newly_excluded = set()
            for variable in record["frozen"]:
                match = COORDINATE_VARIABLE.match(variable)
                if match:
                    newly_excluded.add((int(match.group(1)), int(match.group(2))))
            excluded_coordinate_atoms.update(newly_excluded)
            for phase in project.phases():
                for atom_index, atom in enumerate(phase.atoms()):
                    key = (phase.id, atom_index)
                    if key in excluded_coordinate_atoms:
                        atom.coordinates = source_coordinates[key]
                        atom.refinement_flags = " "
            if newly_excluded:
                project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
                project.save()
        if record["converged"] and record["max_shift_esd"] is not None and record["max_shift_esd"] <= 1.0 and not record["frozen"]:
            break
    return {
        "status": "complete",
        "source": str(source),
        "output": str(destination),
        "settings": {
            "instrument": args.instrument,
            "size": args.size,
            "mustrain": args.mustrain,
            "zero_mustrain": args.zero_mustrain,
            "uniaxial_mustrain": args.uniaxial_mustrain,
            "shift": args.shift,
            "roughness": args.roughness,
            "texture": args.texture,
            "reset_texture": args.reset_texture,
            "atoms": args.atoms,
            "atom_flags": args.atom_flags,
            "atom_elements": args.atom_elements,
            "normalize_uiso": args.normalize_uiso,
            "uiso": args.uiso,
        },
        "records": records,
        "excluded_coordinate_atoms": [list(item) for item in sorted(excluded_coordinate_atoms)],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--instrument", default="")
    parser.add_argument("--size", default="none")
    parser.add_argument("--mustrain", default="none")
    parser.add_argument("--zero-mustrain", action="store_true")
    parser.add_argument("--uniaxial-mustrain", action="append", default=[])
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--texture", action="append", default=[])
    parser.add_argument("--reset-texture", action="append", type=int, default=[])
    parser.add_argument("--atoms", default="none")
    parser.add_argument("--atom-flags", default="X")
    parser.add_argument("--atom-elements", choices=["all", "heavy", "oxygen"], default="all")
    parser.add_argument("--stabilize-coordinates", action="store_true")
    parser.add_argument("--normalize-uiso", action="store_true")
    parser.add_argument("--uiso", default="none")
    parser.add_argument("--cycles", type=int, default=10)
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    payload = None
    try:
        payload = run(args.source.resolve(), args.output.resolve(), args)
    except Exception as exc:
        payload = {
            "status": "failed",
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        raise
    finally:
        args.output.with_suffix(".json").write_text(json.dumps(payload, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
