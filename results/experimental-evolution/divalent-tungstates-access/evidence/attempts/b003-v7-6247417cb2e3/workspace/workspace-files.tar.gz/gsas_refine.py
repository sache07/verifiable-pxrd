#!/usr/bin/env python3
"""Build comparable, restrained GSAS-II checkpoints for candidate phase sets."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
NAMES = {
    "1520200": "MnWO4_wolframite",
    "2002703": "Mn3WO6_rhombohedral",
    "1004057": "WO3_hexagonal",
    "1010618": "WO3_monoclinic_smallcell",
    "1521532": "WO3_tetragonal_P4ncc",
    "1521533": "WO3_tetragonal_P4nmm",
    "1528915": "WO3_monoclinic",
    "1563541": "WO3_monoclinic_alt",
    "2311041": "WO3_monoclinic_largebeta",
    "2106293": "WO3_triclinic",
    "2107312": "WO3_orthorhombic",
    "1541183": "Mn3O4_orthorhombic",
    "9001963": "Mn3O4_tetragonal",
    "1514230": "Mn2O3_cubic",
    "1514108": "MnO_cubic",
}


def cif_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_text() -> str:
    return (
        "# GSAS-II Cu K-alpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.24;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.5;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def convergence(project: G2.G2Project) -> dict:
    data = project.data.get("Covariance", {}).get("data", {})
    rvals = data.get("Rvals", {})
    return {
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "vary_list": [str(item) for item in data.get("varyList", [])],
        "variables": [float(item) for item in data.get("variables", [])],
        "sigmas": [float(item) for item in data.get("sig", [])],
    }


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = {
        key: (float(value[1]) if isinstance(value, list) and len(value) > 1 else value)
        for key, value in hist.InstrumentParameters.items()
        if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
    }
    sample = {
        key: (float(value[0]) if isinstance(value, list) else value)
        for key, value in hist.SampleParameters.items()
        if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"}
    }
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.residuals.get("R", np.nan)),
        "background": hist.Background,
        "instrument": inst,
        "sample": sample,
        "fractions": fractions(project),
        "phases": phases,
        **convergence(project),
    }


def run_stage(project: G2.G2Project, stage: str, cycles: int, records: list[dict]) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = snapshot(project, stage)
    records.append(record)
    print(json.dumps({
        "stage": stage,
        "Rwp_percent": record["Rwp_percent"],
        "converged": record["converged"],
        "max_shift_esd": record["max_shift_esd"],
        "fractions": record["fractions"],
        "frozen": record["frozen"],
    }), flush=True)


def set_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    hist = project.histogram(0)
    hid = hist.id
    bounds = {
        f":{hid}:Zero": (-0.25, 0.25),
        f":{hid}:U": (0.0, 40.0),
        f":{hid}:W": (2.0, 40.0),
        f":{hid}:X": (0.1, 6.0),
        f":{hid}:SH/L": (0.005, 0.10),
        f":{hid}:Polariz.": (0.5, 1.0),
        f":{hid}:Shift": (-800.0, 800.0),
        f":{hid}:SurfRoughA": (0.05, 0.6),
        f":{hid}:SurfRoughB": (0.02, 0.5),
    }
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)
    for phase in project.phases():
        pid = phase.id
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")


def build(ids: list[str], destination: Path, inputs: Path) -> tuple[G2.G2Project, list[dict]]:
    destination.parent.mkdir(parents=True, exist_ok=True)
    inst = destination.parent / "instrument.instprm"
    inst.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(destination))
    hist = project.add_powder_histogram(
        str(inputs / "pattern.csv"), str(inst), fmthint="comma/tab/semicolon"
    )
    hist.Limits("lower", float(hist.getdata("X")[0]))
    hist.Limits("upper", float(hist.getdata("X")[-1]))
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 10,
            "coeffs": [4000.0] + [0.0] * 9,
            "refine": False,
        }
    })

    phases = []
    for cod_id in ids:
        phase = project.add_phase(
            str(cif_path(cod_id)),
            phasename=NAMES.get(cod_id, f"COD_{cod_id}"),
            histograms=[hist],
            fmthint="CIF",
        )
        phases.append(phase)

    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 / len(phases) / float(phase.data["General"]["Mass"]), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.25
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 800.0
        hap["Mustrain"][1][1] = 800.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    set_bounds(project)
    project.save()
    records: list[dict] = []

    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run_stage(project, "background_scales", 8, records)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_stage(project, "cells_background_scales", 10, records)
    run_stage(project, "cells_background_scales_settle", 10, records)

    return project, records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("ids", nargs="+")
    parser.add_argument("--inputs", type=Path, default=Path("inputs"))
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    records: list[dict] = []
    try:
        project, records = build(args.ids, args.output, args.inputs)
        payload = {"status": "complete", "ids": args.ids, "stages": records}
    except Exception as exc:
        payload = {
            "status": "failed",
            "ids": args.ids,
            "error": str(exc),
            "traceback": traceback.format_exc(),
            "stages": records,
        }
        raise
    finally:
        args.output.with_suffix(".json").write_text(json.dumps(payload, indent=2) + "\n")


if __name__ == "__main__":
    main()
