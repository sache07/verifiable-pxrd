#!/usr/bin/env python3
"""Screen chemically supported tungstate analogue frameworks against a residual."""

from __future__ import annotations

import argparse
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy import ndimage


RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06"
)


def cif_path(identifier):
    return RESOURCE / "cif" / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def formula_signature(formula):
    try:
        composition = Composition(formula).reduced_composition
    except Exception:
        return None
    amounts = {str(element): float(amount) for element, amount in composition.items()}
    if "W" not in amounts or "O" not in amounts or len(amounts) != 3:
        return None
    cation = next(element for element in amounts if element not in {"W", "O"})
    return cation, amounts[cation] / amounts["W"], amounts["O"] / amounts["W"]


def target_structure(path):
    structure = Structure.from_file(path, primitive=False)
    substitutions = {
        element: "Mn"
        for element in structure.composition.elements
        if str(element) not in {"O", "W"}
    }
    structure.replace_species(substitutions)
    return structure


def sticks(structure, x_range):
    pattern = XRDCalculator(wavelength=1.540598).get_pattern(
        structure, two_theta_range=(x_range[0] - 10.0, x_range[1] + 20.0), scaled=False
    )
    return np.asarray(pattern.d_hkls), np.asarray(pattern.y)


def profile(d_spacings, intensities, x, length_scale, shift, fwhm):
    step = float(np.median(np.diff(x)))
    result = np.zeros_like(x)
    scaled_d = d_spacings * length_scale
    for wavelength, ratio in ((1.540598, 1.0), (1.544426, 0.5)):
        argument = wavelength / (2.0 * scaled_d)
        valid_bragg = argument < 1.0
        positions = np.rad2deg(2.0 * np.arcsin(argument[valid_bragg])) + shift
        values = ratio * intensities[valid_bragg]
        indices = (positions - x[0]) / step
        valid = (indices >= 0.0) & (indices < len(x) - 1)
        left = np.floor(indices[valid]).astype(int)
        fraction = indices[valid] - left
        np.add.at(result, left, values[valid] * (1.0 - fraction))
        np.add.at(result, left + 1, values[valid] * fraction)
    return ndimage.gaussian_filter1d(result, fwhm / (2.354820045 * step), mode="constant")


def score(structure, x, target, weights):
    d_spacings, intensities = sticks(structure, (x[0], x[-1]))
    target_norm = float(np.sum(weights * target * target))
    best = None
    for length_scale in np.arange(0.88, 1.121, 0.005):
        for fwhm in (0.16, 0.22, 0.30, 0.42, 0.58):
            for shift in np.arange(0.0, 0.601, 0.03):
                calculated = profile(
                    d_spacings, intensities, x, float(length_scale), float(shift), fwhm
                )
                norm = float(np.sum(weights * calculated * calculated))
                if norm <= 0.0:
                    continue
                dot = float(np.sum(weights * target * calculated))
                scale = max(0.0, dot / norm)
                gain = (2.0 * scale * dot - scale * scale * norm) / target_norm
                cosine = dot / np.sqrt(target_norm * norm)
                record = (gain, cosine, length_scale, shift, fwhm, scale)
                if best is None or record[0] > best[0]:
                    best = record
    return best, d_spacings, intensities


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("residual", type=Path)
    args = parser.parse_args()
    data = np.load(args.residual)
    x = np.asarray(data["x"])
    observed = np.asarray(data["observed"])
    target = np.maximum(np.asarray(data["difference"]), 0.0)
    weights = 1.0 / np.maximum(observed, 1000.0)

    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)
    candidates = []
    targets = {(2.0, 6.0): "Mn2WO6", (3.0, 6.0): "Mn3WO6"}
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "W" not in elements or "O" not in elements:
            continue
        for formula, identifier, space_group, quality in records:
            signature = formula_signature(formula)
            if signature is None:
                continue
            source_cation, cation_per_w, oxygen_per_w = signature
            for expected, target_formula in targets.items():
                if (
                    abs(cation_per_w - expected[0]) < 1.0e-6
                    and abs(oxygen_per_w - expected[1]) < 1.0e-6
                ):
                    candidates.append(
                        (target_formula, source_cation, formula, str(identifier), space_group, quality)
                    )

    warnings.simplefilter("ignore")
    results = []
    for target_formula, source_cation, formula, identifier, space_group, quality in candidates:
        try:
            structure = target_structure(cif_path(identifier))
            best, d_spacings, intensities = score(structure, x, target, weights)
            results.append(
                {
                    "target": target_formula,
                    "source_cation": source_cation,
                    "formula": formula,
                    "id": identifier,
                    "sg": space_group,
                    "quality": quality,
                    "best": best,
                    "structure": structure,
                    "d": d_spacings,
                    "intensity": intensities,
                }
            )
        except Exception as error:
            print(f"ERROR {identifier} {formula}: {type(error).__name__}: {error}")
    results.sort(key=lambda item: item["best"][0], reverse=True)
    print("rank target source formula id sg quality gain cosine length_scale shift fwhm")
    for rank, item in enumerate(results, 1):
        gain, cosine, length_scale, shift, fwhm, scale = item["best"]
        print(
            f"{rank:3d} {item['target']:7s} {item['source_cation']:>2s} "
            f"{item['formula']:18s} {item['id']} {item['sg']:3d} {str(item['quality']):>7s} "
            f"{gain:.5f} {cosine:.5f} {length_scale:.4f} {shift:+.3f} {fwhm:.2f}"
        )

    for item in results[:5]:
        gain, cosine, length_scale, shift, fwhm, scale = item["best"]
        positions = np.rad2deg(
            2.0 * np.arcsin(1.540598 / (2.0 * item["d"] * length_scale))
        ) + shift
        print(
            f"\nPEAKS target={item['target']} source={item['formula']} "
            f"id={item['id']} length_scale={length_scale:.4f} shift={shift:+.3f}"
        )
        for peak_index in np.argsort(item["intensity"])[::-1][:50]:
            if x[0] <= positions[peak_index] <= x[-1]:
                print(f"{positions[peak_index]:10.5f} {item['intensity'][peak_index]:12.4f}")


if __name__ == "__main__":
    main()
