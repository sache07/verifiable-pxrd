#!/usr/bin/env python3
"""Screen the frozen COD subset against the supplied pattern."""

from __future__ import annotations

import gzip
import json
import warnings
import argparse
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy import ndimage, optimize, sparse
from scipy.sparse.linalg import spsolve


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06"
)


def cif_path(identifier: str) -> Path:
    return RESOURCE / "cif" / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def baseline_als(y, lam=2.0e7, p=0.002, iterations=15):
    size = len(y)
    difference = sparse.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(size - 2, size), format="csc")
    weights = np.ones(size)
    penalty = lam * difference.T @ difference
    for _ in range(iterations):
        matrix = sparse.spdiags(weights, 0, size, size, format="csc")
        baseline = spsolve(matrix + penalty, weights * y)
        weights = p * (y > baseline) + (1.0 - p) * (y <= baseline)
    return baseline


def sticks(structure: Structure, wavelength: float, x_min: float, x_max: float):
    pattern = XRDCalculator(wavelength=wavelength).get_pattern(
        structure, two_theta_range=(x_min - 1.0, x_max + 1.0), scaled=False
    )
    return np.asarray(pattern.x), np.asarray(pattern.y)


def profile(stick_sets, x: np.ndarray, shift: float, fwhm: float):
    step = float(np.median(np.diff(x)))
    result = np.zeros_like(x)
    for (positions, intensities), ratio in zip(stick_sets, (1.0, 0.5)):
        positions = positions + shift
        indices = (positions - x[0]) / step
        valid = (indices >= 0) & (indices < len(x) - 1)
        left = np.floor(indices[valid]).astype(int)
        fraction = indices[valid] - left
        values = ratio * intensities[valid]
        np.add.at(result, left, values * (1.0 - fraction))
        np.add.at(result, left + 1, values * fraction)
    sigma_points = fwhm / (2.354820045 * step)
    return ndimage.gaussian_filter1d(result, sigma_points, mode="constant")


def score_structure(structure: Structure, x: np.ndarray, target: np.ndarray, weights: np.ndarray):
    best = None
    target_norm = float(np.sum(weights * target * target))
    stick_sets = [
        sticks(structure, wavelength, x[0], x[-1])
        for wavelength in (1.540598, 1.544426)
    ]
    for fwhm in (0.14, 0.18, 0.22, 0.28, 0.36, 0.46, 0.60):
        for shift in np.arange(-0.40, 0.401, 0.02):
            calculated = profile(stick_sets, x, float(shift), fwhm)
            denominator = float(np.sum(weights * calculated * calculated))
            if denominator <= 0.0:
                continue
            scale = max(0.0, float(np.sum(weights * target * calculated)) / denominator)
            gain = (2.0 * scale * np.sum(weights * target * calculated) - scale * scale * denominator) / target_norm
            cosine = float(np.sum(weights * target * calculated)) / np.sqrt(target_norm * denominator)
            record = (float(gain), cosine, float(shift), fwhm, scale)
            if best is None or record[0] > best[0]:
                best = record
    return best


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--target-npz",
        type=Path,
        help="Profile NPZ from gpx_diagnostics.py; screen its positive difference",
    )
    args = parser.parse_args()
    data = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = data["two_theta_deg"]
    y = data["intensity"]
    if args.target_npz:
        profile_data = np.load(args.target_npz)
        if not np.allclose(x, profile_data["x"], rtol=0.0, atol=1.0e-7):
            raise ValueError("target grid does not match pattern.csv")
        target = np.maximum(profile_data["difference"], 0.0)
    else:
        background = baseline_als(y)
        target = np.maximum(y - background, 0.0)
    # Poisson-like weighting, softened to avoid making tiny high-angle peaks dominate.
    weights = 1.0 / np.maximum(y, 1000.0)

    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)
    records = []
    candidates = []
    for key in ("Mn-O-W", "Mn-O", "O-W"):
        for formula, identifier, space_group, quality in index.get(key, []):
            candidates.append((key, formula, str(identifier), space_group, quality))

    warnings.simplefilter("ignore")
    for number, (key, formula, identifier, space_group, quality) in enumerate(candidates, 1):
        path = cif_path(identifier)
        try:
            structure = Structure.from_file(path, primitive=False)
            gain, cosine, shift, fwhm, scale = score_structure(structure, x, target, weights)
            records.append(
                {
                    "key": key,
                    "formula": formula,
                    "id": identifier,
                    "sg": space_group,
                    "quality": quality,
                    "gain": gain,
                    "cosine": cosine,
                    "shift": shift,
                    "fwhm": fwhm,
                    "scale": scale,
                    "sites": len(structure),
                    "density": structure.density,
                    "volume": structure.volume,
                }
            )
        except Exception as error:
            print(f"ERROR {identifier} {formula}: {type(error).__name__}: {error}")

    records.sort(key=lambda item: item["gain"], reverse=True)
    print("rank key formula id sg quality gain cosine shift fwhm sites density volume")
    for rank, item in enumerate(records, 1):
        print(
            f"{rank:3d} {item['key']:6s} {item['formula']:16s} {item['id']} "
            f"{item['sg']:3d} {str(item['quality']):>7s} {item['gain']:.5f} "
            f"{item['cosine']:.5f} {item['shift']:+.3f} {item['fwhm']:.2f} "
            f"{item['sites']:3d} {item['density']:.3f} {item['volume']:.3f}"
        )

    for identifier in ("1520200", "9001963", "9001302", "1528915", "1004057", "1010618"):
        matching = [item for item in candidates if item[2] == identifier]
        if not matching:
            continue
        formula = matching[0][1]
        structure = Structure.from_file(cif_path(identifier), primitive=False)
        pattern = XRDCalculator(wavelength=1.540598).get_pattern(
            structure, two_theta_range=(x[0], x[-1]), scaled=True
        )
        print(f"\nPEAKS {identifier} {formula}")
        order = np.argsort(pattern.y)[::-1]
        for index_number in order[:40]:
            print(f"{pattern.x[index_number]:10.5f} {pattern.y[index_number]:9.3f} {pattern.hkls[index_number]}")


if __name__ == "__main__":
    main()
