#!/usr/bin/env python3
"""Direct-space heavy-atom fit for the P-1 Mn2WO5 candidate.

Le Bail intensities are grouped over unresolved powder reflections.  Two W
sites are searched globally, followed by all W/Mn sites.  Oxygen coordinates
remain at the selected analogue in this diagnostic.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.optimize import differential_evolution, minimize

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIElem as G2elem


def form_factor(symbol, d_spacings):
    requested = {"W": "W+6", "Mn": "MN+2", "O": "O-2"}[symbol]
    table = next(row for row in G2elem.GetFormFactorCoeff(symbol) if row["Symbol"] == requested)
    sq = 1.0 / (4.0 * np.asarray(d_spacings) ** 2)
    return np.asarray(G2elem.ScatFac(table, sq), float) * np.exp(-8.0 * math.pi**2 * 0.01 * sq)


def expanded(elements, coordinates):
    elements = np.asarray(elements)
    coordinates = np.asarray(coordinates) % 1.0
    return np.concatenate((elements, elements)), np.vstack((coordinates, (-coordinates) % 1.0))


def f_squared(elements, coordinates, hkls, factors):
    full_elements, full_coordinates = expanded(elements, coordinates)
    phases = 2j * np.pi * (full_coordinates @ hkls.T)
    result = np.zeros(len(hkls), complex)
    for element in ("W", "Mn", "O"):
        result += factors[element] * np.exp(phases[full_elements == element]).sum(axis=0)
    return np.abs(result) ** 2


def reflection_groups(positions, separation):
    groups, current = [], [0]
    for index in range(1, len(positions)):
        if positions[index] - positions[index - 1] <= separation:
            current.append(index)
        else:
            groups.append(np.asarray(current, int)); current = [index]
    groups.append(np.asarray(current, int))
    return groups


def grouped(values, multip, correction, groups):
    weighted = values * multip * correction
    return np.asarray([weighted[group].sum() for group in groups])


def fit_scale(calculated, observed, weights):
    x, y = calculated * weights, observed * weights
    denominator = float(np.dot(x, x))
    return max(0.0, float(np.dot(x, y)) / denominator) if denominator else 0.0


def periodic_distances(left, right, cell):
    delta = left[:, None, :] - right[None, :, :]
    delta -= np.round(delta)
    return np.sqrt(np.sum((delta * cell) ** 2, axis=2))


def geometry_penalty(elements, coordinates, cell):
    full_elements, full_coordinates = expanded(elements, coordinates)
    oxygens = full_coordinates[full_elements == "O"]
    penalty = 0.0
    detail = {}
    for element, lower, upper, count in (("W", 1.62, 2.12, 4), ("Mn", 1.72, 2.70, 4)):
        centers = full_coordinates[full_elements == element]
        distances = np.sort(periodic_distances(centers, oxygens, cell), axis=1)
        selected = distances[:, :count]
        penalty += float(np.mean(np.maximum(lower - selected, 0) ** 2 + np.maximum(selected - upper, 0) ** 2))
        detail[f"{element}_O_first_{count}"] = selected.tolist()
        if element == "Mn":
            fifth_sixth = distances[:, 4:6]
            penalty += 0.15 * float(np.mean(np.maximum(fifth_sixth - 3.00, 0) ** 2))
            detail["Mn_O_fifth_sixth"] = fifth_sixth.tolist()
    for element, lower in (("W", 2.65), ("Mn", 2.45), ("O", 1.80)):
        points = full_coordinates[full_elements == element]
        distances = periodic_distances(points, points, cell)
        distances[distances < 1e-8] = np.inf
        shortest = float(distances.min())
        penalty += max(lower - shortest, 0) ** 2
        detail[f"{element}_{element}_min"] = shortest
    cross = periodic_distances(full_coordinates[full_elements == "W"], full_coordinates[full_elements == "Mn"], cell)
    detail["Mn_W_min"] = float(cross.min())
    penalty += max(2.50 - detail["Mn_W_min"], 0) ** 2
    detail["penalty"] = penalty
    return penalty, detail


def write_cif(path, elements, coordinates, cell):
    counters = {"W": 0, "Mn": 0, "O": 0}
    lines = [
        "# P-1 Mn2WO5 direct-space heavy-atom diagnostic.",
        "data_Mn2WO5_heavy_fit", "_chemical_formula_sum 'Mn2 O5 W'",
        "_space_group_IT_number 2", "_space_group_name_Hall '-P 1'",
        "_space_group_name_H-M_alt 'P -1'",
        f"_cell_length_a {cell[0]:.9f}", f"_cell_length_b {cell[1]:.9f}", f"_cell_length_c {cell[2]:.9f}",
        "_cell_angle_alpha 90", "_cell_angle_beta 90", "_cell_angle_gamma 90", "_cell_formula_units_Z 4", "",
        "loop_", "_space_group_symop_id", "_space_group_symop_operation_xyz", "1 x,y,z", "2 -x,-y,-z", "",
        "loop_", "_atom_site_label", "_atom_site_type_symbol", "_atom_site_fract_x", "_atom_site_fract_y",
        "_atom_site_fract_z", "_atom_site_occupancy", "_atom_site_U_iso_or_equiv",
    ]
    for element, xyz in zip(elements, coordinates % 1.0):
        counters[element] += 1
        lines.append(f"{element}{counters[element]} {element} {xyz[0]:.9f} {xyz[1]:.9f} {xyz[2]:.9f} 1 0.010")
    path.write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("lebail")
    parser.add_argument("base")
    parser.add_argument("phase")
    parser.add_argument("output_cif", type=Path)
    parser.add_argument("--seed", type=int, default=4071)
    parser.add_argument("--separation", type=float, default=0.07)
    parser.add_argument("--w-iterations", type=int, default=700)
    parser.add_argument("--cation-iterations", type=int, default=450)
    parser.add_argument("--geometry-weight", type=float, default=0.08)
    args = parser.parse_args()

    lebail = G2.G2Project(gpxfile=args.lebail)
    base = G2.G2Project(gpxfile=args.base)
    phase = base.phase(args.phase)
    cell_record = phase.get_cell()
    cell = np.asarray([cell_record[f"length_{axis}"] for axis in "abc"], float)
    atoms = phase.atoms()
    elements = np.asarray([atom.element.strip().replace("+6", "").replace("+2", "").replace("-2", "").title() for atom in atoms])
    elements = np.asarray(["Mn" if value.lower() == "mn" else "W" if value.lower() == "w" else "O" for value in elements])
    coordinates = np.asarray([atom.coordinates for atom in atoms], float)
    ref = np.asarray(lebail.histograms()[0].data["Reflection Lists"][args.phase]["RefList"], float)
    base_ref = np.asarray(base.histograms()[0].data["Reflection Lists"][args.phase]["RefList"], float)
    selection = (ref[:, 5] >= 10.0) & (ref[:, 5] <= 100.0)
    ref, base_ref = ref[selection], base_ref[selection]
    hkls, d_spacings, positions = ref[:, :3], ref[:, 4], ref[:, 5]
    multip, correction = ref[:, 3], ref[:, 11]
    groups = reflection_groups(positions, args.separation)
    observed = np.sqrt(np.maximum(grouped(np.maximum(ref[:, 8], 0), multip, correction, groups), 0))
    floor = max(float(np.percentile(observed[observed > 0], 20)) * 0.2, 1.0)
    weights = 1.0 / np.sqrt(observed + floor)
    factors = {element: form_factor(element, d_spacings) for element in ("W", "Mn", "O")}

    denominator = float(np.dot(observed * weights, observed * weights))
    def diffraction(trial):
        calculated = np.sqrt(np.maximum(grouped(f_squared(elements, trial, hkls, factors), multip, correction, groups), 0))
        scale = fit_scale(calculated, observed, weights)
        residual = (scale * calculated - observed) * weights
        return float(np.dot(residual, residual) / denominator)

    def objective(trial):
        geom = geometry_penalty(elements, trial, cell)[0]
        return diffraction(trial) + args.geometry_weight * geom

    start = coordinates.copy()
    w_indices = np.where(elements == "W")[0]
    cation_indices = np.where(elements != "O")[0]

    def apply_subset(values, indices, source):
        trial = source.copy(); trial[indices] = np.asarray(values).reshape((-1, 3)); return trial

    w_bounds = []
    for index in w_indices:
        w_bounds.extend((float(start[index, axis] - 0.35), float(start[index, axis] + 0.35)) for axis in range(3))
    w_result = differential_evolution(
        lambda values: objective(apply_subset(values, w_indices, start)), w_bounds,
        seed=args.seed, maxiter=args.w_iterations, popsize=24, tol=1e-8,
        polish=True, updating="immediate", workers=1,
    )
    w_coordinates = apply_subset(w_result.x, w_indices, start)

    cation_bounds = []
    for index in cation_indices:
        span = 0.16 if elements[index] == "W" else 0.13
        cation_bounds.extend((float(w_coordinates[index, axis] - span), float(w_coordinates[index, axis] + span)) for axis in range(3))
    cation_result = differential_evolution(
        lambda values: objective(apply_subset(values, cation_indices, w_coordinates)), cation_bounds,
        seed=args.seed + 1, maxiter=args.cation_iterations, popsize=16, tol=2e-7,
        polish=False, updating="immediate", workers=1,
    )
    local = minimize(
        lambda values: objective(apply_subset(values, cation_indices, w_coordinates)),
        cation_result.x, method="L-BFGS-B", bounds=cation_bounds,
        options={"maxiter": 1200, "ftol": 1e-12, "gtol": 1e-7, "maxls": 40},
    )
    final = apply_subset(local.x, cation_indices, w_coordinates)
    write_cif(args.output_cif, elements, final, cell)

    code = f_squared(elements, start, hkls, factors)
    gsas = np.maximum(base_ref[:, 9], 0)
    raw_scale = max(0, float(np.dot(code, gsas) / np.dot(code, code)))
    validation = {
        "R1": float(np.sum(np.abs(raw_scale * code - gsas)) / np.sum(np.abs(gsas))),
        "correlation": float(np.corrcoef(raw_scale * code, gsas)[0, 1]),
    }
    result = {
        "groups": len(groups), "reflections": len(ref), "cell": cell.tolist(),
        "validation": validation,
        "start": {"diffraction": diffraction(start), "objective": objective(start), "geometry": geometry_penalty(elements, start, cell)[1]},
        "w_fit": {"success": bool(w_result.success), "message": str(w_result.message), "diffraction": diffraction(w_coordinates), "objective": objective(w_coordinates), "geometry": geometry_penalty(elements, w_coordinates, cell)[1], "coordinates": w_coordinates[w_indices].tolist()},
        "cation_fit": {"success": bool(local.success), "message": str(local.message), "diffraction": diffraction(final), "objective": objective(final), "geometry": geometry_penalty(elements, final, cell)[1], "coordinates": final[cation_indices].tolist()},
        "output_cif": str(args.output_cif),
    }
    print(json.dumps(result, indent=1))


if __name__ == "__main__":
    main()
