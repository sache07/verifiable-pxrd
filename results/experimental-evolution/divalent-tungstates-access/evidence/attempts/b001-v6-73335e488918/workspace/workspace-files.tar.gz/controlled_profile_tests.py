#!/usr/bin/env python3
"""Test ordinary profile terms one at a time from a stable checkpoint."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_refine import clear_all_flags, run_refinement


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def base_flags(project, candidate):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        if phase.name != candidate:
            phase.set_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def copy_project(source, destination):
    return G2.G2Project(gpxfile=str(source), newgpx=str(destination))


def test(source, destination, candidate, label, configure, cycles=12):
    project = copy_project(source, destination)
    base_flags(project, candidate)
    configure(project)
    record = run_refinement(project, label, cycles)
    clear_all_flags(project)
    project.save()
    return project, record


def acceptable(record, incumbent, gain):
    value = float(record["Rwp_percent"])
    return (
        math.isfinite(value)
        and value + gain < incumbent
        and bool(record.get("converged"))
        and not record.get("frozen")
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("candidate")
    parser.add_argument("--minimum-gain", type=float, default=0.02)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    work = args.destination.parent / f".{args.destination.stem}_tests"
    work.mkdir(parents=True, exist_ok=True)
    initial = G2.G2Project(gpxfile=str(args.source))
    incumbent = args.source
    incumbent_rwp = float(initial.histograms()[0].get_wR())
    records = []
    decisions = []

    def consider(label, configure, cycles=12, validate=lambda project: True):
        nonlocal incumbent, incumbent_rwp
        path = work / f"{len(records):02d}_{label}.gpx"
        project, record = test(incumbent, path, args.candidate, label, configure, cycles)
        records.append(record)
        accepted = acceptable(record, incumbent_rwp, args.minimum_gain) and validate(project)
        decisions.append({
            "stage": label,
            "accepted": accepted,
            "from_Rwp_percent": incumbent_rwp,
            "trial_Rwp_percent": float(record["Rwp_percent"]),
        })
        if accepted:
            incumbent, incumbent_rwp = path, float(record["Rwp_percent"])

    consider(
        "zero_offset",
        lambda project: project.histograms()[0].InstrumentParameters["Zero"].__setitem__(2, True),
        14,
        lambda project: -0.25 <= float(project.histograms()[0].InstrumentParameters["Zero"][1]) <= 0.25,
    )
    consider(
        "polarization",
        lambda project: project.histograms()[0].InstrumentParameters["Polariz."].__setitem__(2, True),
        12,
        lambda project: 0.5 <= float(project.histograms()[0].InstrumentParameters["Polariz."][1]) <= 1.0,
    )

    phase_names = [phase.name for phase in initial.phases()]
    for phase_name in phase_names:
        def configure_strain(project, name=phase_name):
            hap = project.phase(name).data["Histograms"][project.histograms()[0].name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 800.0
            hap["Mustrain"][2][0] = True
            hap["Size"][2][0] = True
        consider(f"isotropic_strain_{phase_name}", configure_strain, 14)

    def configure_roughness(project):
        hist = project.histograms()[0]
        hist.SampleParameters["SurfRoughA"] = [0.30, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
    consider(
        "surface_roughness",
        configure_roughness,
        14,
        lambda project: (
            0.0 <= float(project.histograms()[0].SampleParameters["SurfRoughA"][0]) <= 1.0
            and 0.001 <= float(project.histograms()[0].SampleParameters["SurfRoughB"][0]) <= 1.0
        ),
    )

    for phase_name in phase_names:
        for axis in AXES:
            axis_label = "".join(str(value) for value in axis)
            def configure_po(project, name=phase_name, direction=axis):
                hap = project.phase(name).data["Histograms"][project.histograms()[0].name]
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = True
                hap["Pref.Ori."][3] = list(direction)
            consider(
                f"preferred_orientation_{phase_name}_{axis_label}",
                configure_po,
                10,
                lambda project, name=phase_name: (
                    0.70 <= float(project.phase(name).data["Histograms"][project.histograms()[0].name]["Pref.Ori."][1]) <= 1.40
                ),
            )

    output = copy_project(incumbent, args.destination)
    clear_all_flags(output)
    output.save()
    summary = {
        "source": str(args.source),
        "output": str(args.destination),
        "starting_Rwp_percent": float(initial.histograms()[0].get_wR()),
        "Rwp_percent": incumbent_rwp,
        "decisions": decisions,
        "records": records,
    }
    args.destination.with_suffix(".tests.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    print(json.dumps({"output": str(args.destination), "Rwp_percent": incumbent_rwp, "accepted": [item["stage"] for item in decisions if item["accepted"]]}, indent=1))


if __name__ == "__main__":
    main()
