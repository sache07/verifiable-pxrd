#!/usr/bin/env python3
"""Fit a physical Pbam Mn2WO5 model to Le Bail-extracted intensities.

This is a structure-solution diagnostic, not a replacement for the final
Rietveld refinement. It uses the fixed special-position topology of the
Mn2BiO5 analogue, groups unresolved powder reflections, and combines an
amplitude residual with broad local-geometry bounds.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from scipy.optimize import differential_evolution, least_squares

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIElem as G2elem


SYMMETRY = (
    # Signs and translations for Pbam, Hall -P 2 2ab.
    ((1, 1, 1), (0.0, 0.0, 0.0)),
    ((1, -1, 1), (0.5, 0.5, 0.0)),
    ((-1, 1, -1), (0.5, 0.5, 0.0)),
    ((-1, 1, 1), (0.5, 0.5, 0.0)),
    ((1, -1, -1), (0.5, 0.5, 0.0)),
    ((1, 1, -1), (0.0, 0.0, 0.0)),
    ((-1, -1, 1), (0.0, 0.0, 0.0)),
    ((-1, -1, -1), (0.0, 0.0, 0.0)),
)

PARAMETER_NAMES = (
    "W1_x", "W1_y", "Mn1_z", "Mn2_x", "Mn2_y", "O1_z",
    "O2_x", "O2_y", "O3_x", "O3_y", "O4_x", "O4_y",
)


def asym_sites(values):
    v = dict(zip(PARAMETER_NAMES, values))
    return (
        ("W", "W1", (v["W1_x"], v["W1_y"], 0.0)),
        ("Mn", "Mn1", (0.5, 0.0, v["Mn1_z"])),
        ("Mn", "Mn2", (v["Mn2_x"], v["Mn2_y"], 0.5)),
        ("O", "O1", (0.0, 0.0, v["O1_z"])),
        ("O", "O2", (v["O2_x"], v["O2_y"], 0.25)),
        ("O", "O3", (v["O3_x"], v["O3_y"], 0.5)),
        ("O", "O4", (v["O4_x"], v["O4_y"], 0.0)),
    )


def expand(values):
    elements = []
    labels = []
    coordinates = []
    for element, label, coordinate in asym_sites(values):
        equivalents = []
        source = np.asarray(coordinate, dtype=float)
        for signs, translation in SYMMETRY:
            transformed = (source * np.asarray(signs) + np.asarray(translation)) % 1.0
            if not any(np.linalg.norm((transformed - old) - np.round(transformed - old)) < 1.0e-7 for old in equivalents):
                equivalents.append(transformed)
        for transformed in equivalents:
            elements.append(element)
            labels.append(label)
            coordinates.append(transformed)
    return np.asarray(elements), np.asarray(labels), np.asarray(coordinates)


def form_factor(symbol, d_spacings):
    requested = {"W": "W+6", "Mn": "MN+2", "O": "O-2"}[symbol]
    table = next(
        row for row in G2elem.GetFormFactorCoeff(symbol)
        if row["Symbol"] == requested
    )
    sq = 1.0 / (4.0 * np.asarray(d_spacings) ** 2)
    return np.asarray(G2elem.ScatFac(table, sq), dtype=float) * np.exp(-8.0 * math.pi**2 * 0.01 * sq)


def structure_factors(values, hkls, factors):
    elements, _labels, coordinates = expand(values)
    phases = 2j * np.pi * (coordinates @ hkls.T)
    result = np.zeros(len(hkls), dtype=complex)
    for element in ("W", "Mn", "O"):
        selection = elements == element
        result += factors[element] * np.exp(phases[selection]).sum(axis=0)
    return np.abs(result) ** 2


def reflection_groups(positions, separation=0.055):
    groups = []
    current = [0]
    for index in range(1, len(positions)):
        if positions[index] - positions[index - 1] <= separation:
            current.append(index)
        else:
            groups.append(np.asarray(current, dtype=int))
            current = [index]
    groups.append(np.asarray(current, dtype=int))
    return groups


def grouped_intensity(f_squared, multip, correction, groups):
    weighted = f_squared * multip * correction
    return np.asarray([np.sum(weighted[group]) for group in groups])


def fit_scale(calculated, observed):
    denominator = float(np.dot(calculated, calculated))
    return 0.0 if denominator <= 0.0 else max(0.0, float(np.dot(calculated, observed)) / denominator)


def periodic_distances(left, right, cell):
    delta = left[:, None, :] - right[None, :, :]
    delta -= np.round(delta)
    return np.sqrt(np.sum((delta * cell) ** 2, axis=2))


def geometry(values, cell):
    elements, labels, coordinates = expand(values)
    oxygens = coordinates[elements == "O"]
    records = {}
    penalty = 0.0
    for element, lower, upper, count in (("W", 1.68, 2.30, 6), ("Mn", 1.78, 2.65, 6)):
        centers = coordinates[elements == element]
        distances = np.sort(periodic_distances(centers, oxygens, cell), axis=1)
        selected = distances[:, :count]
        penalty += float(np.mean(np.maximum(lower - selected, 0.0) ** 2 + np.maximum(selected - upper, 0.0) ** 2))
        records[f"{element}-O_first_{count}"] = selected.tolist()
    for element, minimum in (("W", 2.70), ("Mn", 2.55), ("O", 1.95)):
        points = coordinates[elements == element]
        distances = periodic_distances(points, points, cell)
        distances[distances < 1.0e-8] = np.inf
        shortest = float(np.min(distances))
        penalty += max(minimum - shortest, 0.0) ** 2
        records[f"{element}-{element}_min"] = shortest
    cations = coordinates[np.isin(elements, ("W", "Mn"))]
    cation_elements = elements[np.isin(elements, ("W", "Mn"))]
    cross = periodic_distances(cations[cation_elements == "W"], cations[cation_elements == "Mn"], cell)
    records["Mn-W_min"] = float(np.min(cross))
    penalty += max(2.65 - records["Mn-W_min"], 0.0) ** 2
    records["penalty"] = penalty
    return penalty, records


def write_cif(path, values, cell):
    sites = {label: coordinate for _element, label, coordinate in asym_sites(values)}
    lines = [
        "# Pbam Mn2WO5 model fitted to Le Bail intensities with broad geometry bounds.",
        "# Topology parent: COD 9008146 (BiMn2O5); transformation Bi -> W.",
        "data_Mn2WO5_optimized",
        "_audit_creation_method 'cross-chemistry topology transfer, intensity optimization, and geometry bounds'",
        "_chemical_formula_sum 'Mn2 O5 W'",
        "_space_group_IT_number 55",
        "_symmetry_space_group_name_Hall '-P 2 2ab'",
        "_symmetry_space_group_name_H-M 'P b a m'",
        f"_cell_length_a {cell[0]:.8f}",
        f"_cell_length_b {cell[1]:.8f}",
        f"_cell_length_c {cell[2]:.8f}",
        "_cell_angle_alpha 90", "_cell_angle_beta 90", "_cell_angle_gamma 90",
        "_cell_formula_units_Z 4", "",
        "loop_", "_space_group_symop_operation_xyz",
        "x,y,z", "1/2+x,1/2-y,z", "1/2-x,1/2+y,-z", "1/2-x,1/2+y,z",
        "1/2+x,1/2-y,-z", "x,y,-z", "-x,-y,z", "-x,-y,-z", "",
        "loop_", "_atom_site_label", "_atom_site_type_symbol",
        "_atom_site_fract_x", "_atom_site_fract_y", "_atom_site_fract_z",
        "_atom_site_occupancy", "_atom_site_U_iso_or_equiv",
    ]
    symbols = {"W1": "W+6", "Mn1": "Mn+2", "Mn2": "Mn+2", "O1": "O-2", "O2": "O-2", "O3": "O-2", "O4": "O-2"}
    for label in ("W1", "Mn1", "Mn2", "O1", "O2", "O3", "O4"):
        xyz = sites[label]
        lines.append(f"{label} {symbols[label]} {xyz[0]:.8f} {xyz[1]:.8f} {xyz[2]:.8f} 1 0.010")
    path.write_text("\n".join(lines) + "\n")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("lebail", type=Path)
    parser.add_argument("base", type=Path)
    parser.add_argument("output_cif", type=Path)
    parser.add_argument("--seed", type=int, default=1729)
    parser.add_argument("--maxiter-heavy", type=int, default=500)
    parser.add_argument("--maxiter-all", type=int, default=900)
    parser.add_argument("--geometry-weight", type=float, default=0.10)
    args = parser.parse_args()

    lebail = G2.G2Project(gpxfile=str(args.lebail))
    base = G2.G2Project(gpxfile=str(args.base))
    phase_name = "Mn2WO5_Pbam"
    phase = lebail.phase(phase_name)
    cell_data = phase.get_cell()
    cell = np.asarray([cell_data["length_a"], cell_data["length_b"], cell_data["length_c"]], dtype=float)
    ref = np.asarray(lebail.histograms()[0].data["Reflection Lists"][phase_name]["RefList"], dtype=float)
    base_ref = np.asarray(base.histograms()[0].data["Reflection Lists"][phase_name]["RefList"], dtype=float)
    if not np.array_equal(ref[:, :3], base_ref[:, :3]):
        raise RuntimeError("base and Le Bail reflection lists differ")
    selection = (ref[:, 5] >= 10.0) & (ref[:, 5] <= 100.0)
    ref = ref[selection]
    base_ref = base_ref[selection]
    hkls = ref[:, :3]
    d_spacings = ref[:, 4]
    positions = ref[:, 5]
    multip = ref[:, 3]
    correction = ref[:, 11]
    observed_f2 = np.maximum(ref[:, 8], 0.0)
    groups = reflection_groups(positions)
    observed_group = grouped_intensity(observed_f2, multip, correction, groups)
    observed_amp = np.sqrt(np.maximum(observed_group, 0.0))
    amp_floor = max(float(np.percentile(observed_amp[observed_amp > 0], 20)) * 0.2, 1.0)
    amplitude_weights = 1.0 / np.sqrt(observed_amp + amp_floor)
    factors = {element: form_factor(element, d_spacings) for element in ("W", "Mn", "O")}

    base_phase = base.phase(phase_name)
    atom_values = {atom.label: atom.coordinates for atom in base_phase.atoms()}
    start = np.asarray([
        atom_values["W1"][0], atom_values["W1"][1], atom_values["Mn1"][2],
        atom_values["Mn2"][0], atom_values["Mn2"][1], atom_values["O1"][2],
        atom_values["O2"][0], atom_values["O2"][1], atom_values["O3"][0],
        atom_values["O3"][1], atom_values["O4"][0], atom_values["O4"][1],
    ], dtype=float)

    def diffraction_residual(values):
        f2 = structure_factors(values, hkls, factors)
        calculated_group = grouped_intensity(f2, multip, correction, groups)
        calculated_amp = np.sqrt(np.maximum(calculated_group, 0.0))
        scale = fit_scale(calculated_amp * amplitude_weights, observed_amp * amplitude_weights)
        residual = (scale * calculated_amp - observed_amp) * amplitude_weights
        return float(np.dot(residual, residual) / np.dot(observed_amp * amplitude_weights, observed_amp * amplitude_weights))

    def objective(values):
        diffraction = diffraction_residual(values)
        geometry_penalty, _ = geometry(values, cell)
        return diffraction + args.geometry_weight * geometry_penalty

    # Broad topology-preserving ranges. Special positions remain fixed by the
    # parameterization; wrapping-equivalent solutions are intentionally avoided.
    spans = np.asarray([0.22, 0.22, 0.18, 0.22, 0.22, 0.18, 0.22, 0.22, 0.22, 0.22, 0.22, 0.22])
    lower = np.maximum(start - spans, 0.001)
    upper = np.minimum(start + spans, 0.999)
    bounds = list(zip(lower, upper))

    heavy_indices = np.asarray([0, 1, 2, 3, 4], dtype=int)
    heavy_bounds = [bounds[index] for index in heavy_indices]

    def heavy_objective(values):
        trial = start.copy()
        trial[heavy_indices] = values
        return objective(trial)

    heavy = differential_evolution(
        heavy_objective, heavy_bounds, seed=args.seed, maxiter=args.maxiter_heavy,
        popsize=24, tol=1.0e-7, polish=True, updating="immediate",
    )
    heavy_start = start.copy()
    heavy_start[heavy_indices] = heavy.x

    # Seed the joint search with the best heavy-atom branch and the analogue.
    population_size = max(20 * len(start), 5)
    rng = np.random.default_rng(args.seed + 1)
    population = rng.uniform(lower, upper, size=(population_size, len(start)))
    population[0] = heavy_start
    population[1] = start
    joint = differential_evolution(
        objective, bounds, seed=args.seed + 2, maxiter=args.maxiter_all,
        popsize=20, tol=1.0e-8, polish=True, init=population, updating="immediate",
    )

    optimized = np.asarray(joint.x)
    write_cif(args.output_cif, optimized, cell)

    code_f2 = structure_factors(start, hkls, factors)
    gsas_f2 = np.maximum(base_ref[:, 9], 0.0)
    code_scale = fit_scale(code_f2, gsas_f2)
    validation_r = float(np.sum(np.abs(code_scale * code_f2 - gsas_f2)) / np.sum(np.abs(gsas_f2)))
    validation_corr = float(np.corrcoef(code_scale * code_f2, gsas_f2)[0, 1])
    start_geometry = geometry(start, cell)[1]
    optimized_geometry = geometry(optimized, cell)[1]
    result = {
        "input_lebail": str(args.lebail),
        "input_base": str(args.base),
        "output_cif": str(args.output_cif),
        "groups": len(groups),
        "reflections": len(ref),
        "form_factor_validation": {"R1": validation_r, "correlation": validation_corr, "scale": code_scale},
        "start": {"parameters": dict(zip(PARAMETER_NAMES, start)), "diffraction_residual": diffraction_residual(start), "objective": objective(start), "geometry": start_geometry},
        "heavy": {"success": bool(heavy.success), "message": str(heavy.message), "parameters": dict(zip(PARAMETER_NAMES, heavy_start)), "diffraction_residual": diffraction_residual(heavy_start), "objective": objective(heavy_start), "geometry": geometry(heavy_start, cell)[1]},
        "optimized": {"success": bool(joint.success), "message": str(joint.message), "parameters": dict(zip(PARAMETER_NAMES, optimized)), "diffraction_residual": diffraction_residual(optimized), "objective": objective(optimized), "geometry": optimized_geometry},
    }
    print(json.dumps(result, indent=1))


if __name__ == "__main__":
    main()
