#!/usr/bin/env python3
"""Refine a low-symmetry candidate while holding its indexed metric fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_refine import clear_all_flags, run_refinement


def flags(project, candidate, instrument=False, sizes=False):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    if instrument:
        for key in ("U", "W", "X", "SH/L"):
            hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        if phase.name != candidate:
            phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if sizes:
            hap["Size"][2][0] = True


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("candidate")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.destination))
    records = []
    flags(project, args.candidate)
    records.append(run_refinement(project, "accepted_cells_fixed_candidate", 10))
    flags(project, args.candidate, instrument=True)
    records.append(run_refinement(project, "instrument_fixed_candidate", 12))
    flags(project, args.candidate, instrument=True, sizes=True)
    records.append(run_refinement(project, "sizes_fixed_candidate", 15))
    clear_all_flags(project)
    project.save()
    args.destination.with_suffix(".fixed.json").write_text(json.dumps(records, indent=2, default=float) + "\n")


if __name__ == "__main__":
    main()
