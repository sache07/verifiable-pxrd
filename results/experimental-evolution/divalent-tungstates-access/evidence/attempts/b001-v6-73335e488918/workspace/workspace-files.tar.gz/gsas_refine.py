#!/usr/bin/env python3
"""Build and refine replayable GSAS-II checkpoints for this specimen.

Run with the GSAS-II Python interpreter. The script intentionally keeps each
stage explicit so phase-inventory branches can be compared from saved GPX
checkpoints.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys

import numpy as np
from scipy import sparse
from scipy.sparse.linalg import spsolve

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cif_path(identifier: str) -> Path:
    return RESOURCE / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def asymmetric_baseline(y, lam=2.0e7, p=0.002, iterations=15):
    size = len(y)
    difference = sparse.diags(
        [1.0, -2.0, 1.0], [0, 1, 2], shape=(size - 2, size), format="csc"
    )
    penalty = lam * difference.T @ difference
    weights = np.ones(size)
    for _ in range(iterations):
        diagonal = sparse.spdiags(weights, 0, size, size, format="csc")
        baseline = spsolve(diagonal + penalty, weights * y)
        weights = p * (y > baseline) + (1.0 - p) * (y <= baseline)
    return baseline


def background_coefficients(x, y, number=12):
    baseline = asymmetric_baseline(y)
    coordinate = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    return np.polynomial.chebyshev.chebfit(coordinate, baseline, number - 1).tolist()


def clear_all_flags(project):
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        for key in ("Size", "Mustrain"):
            value = hap[key]
            if len(value) > 2 and isinstance(value[2], list):
                value[2] = [False] * len(value[2])
            if len(value) > 5 and isinstance(value[5], list):
                value[5] = [False] * len(value[5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def mass_fractions(project):
    hist = project.histograms()[0]
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap.get("Use", True) and hap["Scale"][0] > 0:
            weighted[phase.name] = (
                float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
            )
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()} if total else {}


def install_physical_bounds(project):
    """Apply broad bounds from the frozen laboratory envelope."""
    project.index_ids()
    hist = project.histograms()[0]
    hid = int(hist.data["data"][0]["hId"])
    limits = {
        f":{hid}:Zero": (-0.25, 0.25),
        f":{hid}:U": (0.0, 40.0),
        f":{hid}:W": (2.0, 40.0),
        f":{hid}:X": (0.1, 6.0),
        f":{hid}:SH/L": (0.005, 0.10),
        f":{hid}:Polariz.": (0.5, 1.0),
        f":{hid}:Shift": (-800.0, 800.0),
        f":{hid}:SurfRoughA": (0.0, 1.0),
        f":{hid}:SurfRoughB": (0.001, 1.0),
    }
    for phase in project.phases():
        pid = int(phase.data["pId"])
        limits[f"{pid}:{hid}:Scale"] = (0.0, 1000.0)
        limits[f"{pid}:{hid}:Size;i"] = (0.04, 1.5)
        limits[f"{pid}:{hid}:Mustrain;i"] = (300.0, 8000.0)
    for variable, (minimum, maximum) in limits.items():
        project.set_Controls("parmMin", minimum, variable=variable)
        project.set_Controls("parmMax", maximum, variable=variable)


def state(project, label):
    hist = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    record = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": covariance.get("Rvals", {}).get("GOF"),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "max_shift_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "fractions": mass_fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "instrument": {
            key: value[1] if isinstance(value, list) and len(value) > 1 else value
            for key, value in hist.InstrumentParameters.items()
        },
        "sample": {
            key: value[0] if isinstance(value, list) and value else value
            for key, value in hist.SampleParameters.items()
            if key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phase_profiles": {},
        "frozen": [str(value) for value in project.get_Frozen()],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        record["phase_profiles"][phase.name] = {
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return record


def run_refinement(project, label, cycles=8):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    install_physical_bounds(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = state(project, label)
    print(json.dumps(record, default=float), flush=True)
    return record


def build(output: Path, phase_specs):
    if output.exists():
        raise FileExistsError(f"refusing to overwrite {output}")
    data = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = data["two_theta_deg"]
    y = data["intensity"]
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-600.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    coeffs = background_coefficients(x, y, 12)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": len(coeffs),
                "coeffs": coeffs,
                "refine": False,
            }
        }
    )
    for index, (identifier, name) in enumerate(phase_specs):
        phase_file = cif_path(identifier) if identifier.isdigit() else (ROOT / identifier)
        phase = project.add_phase(
            str(phase_file.resolve()), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10.0 / max(len(phase_specs), 1), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
    project.save()
    clear_all_flags(project)
    project.save()
    run_refinement(project, "initial_calculation", cycles=0)
    return project


def stage_scale_background(project):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    return run_refinement(project, "scale_background", cycles=8)


def stage_cell_shift(project):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    return run_refinement(project, "cell_shift_scale_background", cycles=10)


def stage_instrument(project):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    return run_refinement(project, "instrument_cell_shift_scale_background", cycles=12)


def stage_size(project):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
    return run_refinement(project, "bounded_instrument_size", cycles=15)


def stage_zero_size_strain(project):
    clear_all_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    for key in ("Zero", "U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    return run_refinement(project, "zero_size_strain_full_profile", cycles=15)


STAGES = {
    "scale": stage_scale_background,
    "cell": stage_cell_shift,
    "instrument": stage_instrument,
    "size": stage_size,
    "profile": stage_zero_size_strain,
}


def main():
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    make_parser = subparsers.add_parser("build")
    make_parser.add_argument("output", type=Path)
    make_parser.add_argument(
        "--phase", action="append", required=True, help="COD_ID:phase_name or CIF_path:phase_name"
    )
    make_parser.add_argument(
        "--stages", nargs="*", choices=STAGES, default=["scale", "cell", "instrument", "profile"]
    )
    refine_parser = subparsers.add_parser("refine")
    refine_parser.add_argument("source", type=Path)
    refine_parser.add_argument("output", type=Path)
    refine_parser.add_argument("stages", nargs="+", choices=STAGES)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    if args.command == "build":
        phase_specs = []
        for value in args.phase:
            identifier, name = value.split(":", 1)
            phase_specs.append((identifier, name))
        project = build(args.output.resolve(), phase_specs)
        stages = args.stages
    else:
        source = args.source.resolve()
        output = args.output.resolve()
        if output.exists():
            raise FileExistsError(f"refusing to overwrite {output}")
        shutil.copy2(source, output)
        project = G2.G2Project(gpxfile=str(output))
        stages = args.stages

    records = []
    for stage in stages:
        records.append(STAGES[stage](project))
    project.save()
    args.output.with_suffix(".stages.json").write_text(
        json.dumps(records, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
