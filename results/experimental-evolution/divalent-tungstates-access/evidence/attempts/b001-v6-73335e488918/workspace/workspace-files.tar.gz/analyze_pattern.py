#!/usr/bin/env python3
"""Quick, reproducible diagnostics for the supplied powder pattern."""

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy import ndimage, signal, sparse
from scipy.sparse.linalg import spsolve


ROOT = Path(__file__).resolve().parent


def asymmetric_least_squares(y, lam=2.0e7, p=0.002, iterations=15):
    """Smooth lower-envelope baseline (Eilers asymmetric least squares)."""
    size = len(y)
    differences = sparse.diags([1.0, -2.0, 1.0], [0, 1, 2], shape=(size - 2, size))
    weights = np.ones(size)
    for _ in range(iterations):
        weight_matrix = sparse.spdiags(weights, 0, size, size)
        baseline = spsolve(weight_matrix + lam * differences.T @ differences, weights * y)
        weights = p * (y > baseline) + (1.0 - p) * (y <= baseline)
    return baseline


def main():
    data = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    x = data["two_theta_deg"]
    y = data["intensity"]
    baseline = asymmetric_least_squares(y)
    corrected = y - baseline
    noise = 1.4826 * np.median(np.abs(np.diff(y) - np.median(np.diff(y)))) / np.sqrt(2.0)

    # A light smoothing is used only for locating peak maxima, not fitting.
    smooth = signal.savgol_filter(corrected, 13, 3)
    peaks, props = signal.find_peaks(
        smooth,
        prominence=max(5.0 * noise, 60.0),
        width=(1.0, 200.0),
        distance=3,
    )
    order = np.argsort(props["prominences"])[::-1]

    print(f"points={len(x)} range={x[0]:.8f}..{x[-1]:.8f} step={np.median(np.diff(x)):.8f}")
    print(f"intensity min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}; noise~{noise:.2f} counts")
    print("top peaks by prominence")
    print("rank  2theta       intensity  baseline  corrected  prominence  fwhm_deg")
    for rank, item in enumerate(order[:100], 1):
        index = peaks[item]
        width_deg = props["widths"][item] * np.median(np.diff(x))
        print(
            f"{rank:3d} {x[index]:11.6f} {y[index]:10.1f} {baseline[index]:9.1f} "
            f"{corrected[index]:10.1f} {props['prominences'][item]:11.1f} {width_deg:9.4f}"
        )

    outdir = ROOT / ".tmp"
    outdir.mkdir(exist_ok=True)
    fig, axes = plt.subplots(3, 1, figsize=(16, 11), sharex=True)
    axes[0].plot(x, y, color="black", lw=0.55)
    axes[0].plot(x, baseline, color="tab:red", lw=1.0)
    axes[0].set_ylabel("counts")
    axes[0].set_title("Raw pattern and diagnostic baseline")
    axes[1].plot(x, corrected, color="black", lw=0.55)
    axes[1].axhline(0.0, color="0.7", lw=0.6)
    axes[1].set_ylabel("counts above baseline")
    axes[2].semilogy(x, np.maximum(corrected, 1.0), color="black", lw=0.55)
    axes[2].set_ylabel("counts above baseline (log)")
    axes[2].set_xlabel(r"$2\theta$ (degrees)")
    for axis in axes:
        axis.set_xlim(x[0], x[-1])
        axis.grid(alpha=0.15)
    fig.tight_layout()
    fig.savefig(outdir / "pattern_overview.png", dpi=170)


if __name__ == "__main__":
    main()
