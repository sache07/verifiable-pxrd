#!/usr/bin/env python3
"""Install direct-space candidate coordinates into a GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import learned.staged_polish as polish


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    parser.add_argument("fit_json", type=Path)
    parser.add_argument("--record", default="cation_fit")
    parser.add_argument("--element", choices=("Mn", "W", "O"))
    args = parser.parse_args()
    text = args.fit_json.read_text()
    data = json.loads(text[text.index("{"):])
    coordinates = data[args.record]["coordinates"]
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.destination))
    target = project.phase(args.phase)
    atoms = target.atoms()
    selected = [atom for atom in atoms if not args.element or atom.element.strip().upper().startswith(args.element.upper())]
    if len(coordinates) != len(selected):
        if args.element:
            raise ValueError(f"coordinate count {len(coordinates)} does not match {len(selected)} {args.element} atoms")
    if len(coordinates) > len(selected):
        raise ValueError("more coordinates than phase atoms")
    for atom, xyz in zip(selected, coordinates):
        atom.coordinates = xyz
    polish.clear_flags(project)
    polish.enable_scales_and_background(project)
    records = []
    polish.run(project, "coordinate_install_scale_background", records, 12)
    polish.clear_flags(project)
    project.save()
    result = {
        "output": str(args.destination), "coordinates_installed": len(coordinates),
        "Rwp_percent": float(polish.histogram(project).get_wR()),
        "fractions": polish.mass_fractions(project),
        "geometry": polish.geometry_profile(project), "records": records,
    }
    args.destination.with_suffix(".installed.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=1))


if __name__ == "__main__":
    main()
