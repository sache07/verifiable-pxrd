#!/usr/bin/env python3
"""Complete bounded profile refinement for the accepted three-phase model.

The indexed low-symmetry candidate has an orthogonal metric in P-1, which
makes a simultaneous six-parameter cell refinement ill-conditioned.  Its
metric is therefore held at the independently indexed values while the two
published phases, calibration, and ordinary specimen terms are refined.
Optional roughness, uniaxial strain, and March-Dollase terms are retained only
when they improve the weighted profile from a replayable checkpoint.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_refine import clear_all_flags, install_physical_bounds, run_refinement


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def install_extended_bounds(project):
    install_physical_bounds(project)
    project.index_ids()
    hist = project.histograms()[0]
    hid = int(hist.data["data"][0]["hId"])
    for phase in project.phases():
        pid = int(phase.data["pId"])
        for suffix in ("Mustrain;i", "Mustrain;a"):
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:{suffix}")
            project.set_Controls("parmMax", 32000.0, variable=f"{pid}:{hid}:{suffix}")
        project.set_Controls("parmMin", 0.70, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", 1.40, variable=f"{pid}:{hid}:MD")


def common_flags(project, candidate, *, roughness=False, strain=True, po_phase=None):
    clear_all_flags(project)
    install_extended_bounds(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    hist.SampleParameters["Shift"][1] = True
    if roughness:
        hist.SampleParameters["SurfRoughA"][1] = True
        hist.SampleParameters["SurfRoughB"][1] = True
    for key in ("Zero", "U", "W", "X", "SH/L", "Polariz."):
        hist.InstrumentParameters[key][2] = True
    for phase in project.phases():
        if phase.name != candidate:
            phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        if strain:
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][0] = True
                hap["Mustrain"][2][1] = True
            else:
                hap["Mustrain"][2][0] = True
        if phase.name == po_phase:
            hap["Pref.Ori."][2] = True


def branch(source, destination):
    return G2.G2Project(gpxfile=str(source), newgpx=str(destination))


def rwp(project):
    return float(project.histograms()[0].get_wR())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("candidate")
    parser.add_argument("--minimum-gain", type=float, default=0.03)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    records = []
    work = args.destination.parent / f".{args.destination.stem}_profile"
    work.mkdir(parents=True, exist_ok=True)

    base_path = work / "ordinary.gpx"
    project = branch(args.source, base_path)
    common_flags(project, args.candidate)
    records.append(run_refinement(project, "ordinary_zero_shift_profile_strain", 25))
    clear_all_flags(project)
    project.save()
    incumbent_path = base_path
    incumbent_rwp = rwp(project)

    # Surface roughness has a singular inactive representation at A=B=0.
    # Start a physical trial and retain it only if the data support it.
    rough_path = work / "roughness.gpx"
    trial = branch(incumbent_path, rough_path)
    hist = trial.histograms()[0]
    if hist.SampleParameters["SurfRoughA"][0] <= 0.0:
        hist.SampleParameters["SurfRoughA"][0] = 0.30
    if hist.SampleParameters["SurfRoughB"][0] <= 0.0:
        hist.SampleParameters["SurfRoughB"][0] = 0.10
    common_flags(trial, args.candidate, roughness=True)
    rough_record = run_refinement(trial, "surface_roughness_trial", 18)
    records.append(rough_record)
    rough_a = float(hist.SampleParameters["SurfRoughA"][0])
    rough_b = float(hist.SampleParameters["SurfRoughB"][0])
    if rwp(trial) + args.minimum_gain < incumbent_rwp and 0.0 <= rough_a <= 1.0 and 0.001 <= rough_b <= 1.0:
        clear_all_flags(trial); trial.save()
        incumbent_path, incumbent_rwp = rough_path, rwp(trial)

    # Test the generator's three allowed uniaxial strain directions phasewise.
    for phase_name in [phase.name for phase in project.phases()]:
        best = None
        for axis in AXES[:3]:
            label = "".join(str(value) for value in axis)
            test_path = work / f"strain_{phase_name}_{label}.gpx"
            trial = branch(incumbent_path, test_path)
            hap = trial.phase(phase_name).data["Histograms"][trial.histograms()[0].name]
            current = float(hap["Mustrain"][1][0])
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = current
            hap["Mustrain"][1][1] = max(current, 300.0)
            hap["Mustrain"][3] = list(axis)
            common_flags(trial, args.candidate)
            rec = run_refinement(trial, f"uniaxial_strain_{phase_name}_{label}", 14)
            records.append(rec)
            values = hap["Mustrain"][1]
            candidate = (rwp(trial), test_path, float(values[0]), float(values[1]))
            if best is None or candidate[0] < best[0]:
                best = candidate
        if best and best[0] + args.minimum_gain < incumbent_rwp:
            incumbent_rwp, incumbent_path = best[0], best[1]

    # Test the five allowed March-Dollase axes one phase at a time.
    for phase_name in [phase.name for phase in project.phases()]:
        best = None
        for axis in AXES:
            label = "".join(str(value) for value in axis)
            test_path = work / f"po_{phase_name}_{label}.gpx"
            trial = branch(incumbent_path, test_path)
            hap = trial.phase(phase_name).data["Histograms"][trial.histograms()[0].name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(axis)
            common_flags(trial, args.candidate, po_phase=phase_name)
            rec = run_refinement(trial, f"preferred_orientation_{phase_name}_{label}", 14)
            records.append(rec)
            ratio = float(hap["Pref.Ori."][1])
            candidate = (rwp(trial), test_path, ratio)
            if best is None or candidate[0] < best[0]:
                best = candidate
        if best and best[0] + args.minimum_gain < incumbent_rwp and 0.70 <= best[2] <= 1.40:
            incumbent_rwp, incumbent_path = best[0], best[1]

    final = branch(incumbent_path, args.destination)
    common_flags(final, args.candidate, roughness=(final.histograms()[0].SampleParameters["SurfRoughB"][0] > 0.0))
    records.append(run_refinement(final, "complete_profile_settle", 20))
    clear_all_flags(final)
    final.save()
    summary = {
        "source": str(args.source),
        "output": str(args.destination),
        "Rwp_percent": rwp(final),
        "records": records,
    }
    args.destination.with_suffix(".profile.json").write_text(json.dumps(summary, indent=2, default=float) + "\n")
    print(json.dumps({"output": str(args.destination), "Rwp_percent": rwp(final)}, indent=1))


if __name__ == "__main__":
    main()
