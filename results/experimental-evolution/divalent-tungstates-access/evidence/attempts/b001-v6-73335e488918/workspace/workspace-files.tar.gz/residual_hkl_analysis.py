#!/usr/bin/env python3
"""Assign the coherent residual peaks to an orthorhombic indexing solution."""

from __future__ import annotations

import math

from index_residual import PEAKS, d_spacing, unshift_position


CELL = (4.44652004, 7.70049943, 10.46103295)


def reflections(d_min=0.9, limit=12):
    a, b, c = CELL
    rows = []
    for h in range(limit + 1):
        for k in range(limit + 1):
            for l in range(limit + 1):
                if h == k == l == 0:
                    continue
                reciprocal = (h / a) ** 2 + (k / b) ** 2 + (l / c) ** 2
                d = 1.0 / math.sqrt(reciprocal)
                if d >= d_min:
                    rows.append((d, h, k, l))
    return rows


def main():
    candidates = reflections()
    print("obs_2theta corrected_2theta d_obs h k l d_calc delta_d delta_2theta")
    for observed, _intensity in PEAKS:
        corrected = unshift_position(observed)
        d_obs = d_spacing(corrected)
        d_calc, h, k, l = min(candidates, key=lambda row: abs(row[0] - d_obs))
        calc_position = math.degrees(2.0 * math.asin(1.540598 / (2.0 * d_calc)))
        print(
            f"{observed:10.5f} {corrected:10.5f} {d_obs:9.6f} "
            f"{h:2d} {k:2d} {l:2d} {d_calc:9.6f} {d_calc-d_obs:+.7f} "
            f"{calc_position-corrected:+.5f}"
        )


if __name__ == "__main__":
    main()
