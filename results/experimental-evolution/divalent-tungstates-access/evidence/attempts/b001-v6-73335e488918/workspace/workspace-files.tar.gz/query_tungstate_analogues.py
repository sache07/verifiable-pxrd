#!/usr/bin/env python3
"""List frozen-index ternary tungstate entries by reduced stoichiometry."""

import gzip
import json
from collections import defaultdict
from pathlib import Path

from pymatgen.core import Composition


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)


def signature(formula):
    try:
        composition = Composition(formula).reduced_composition
    except Exception:
        return None
    elements = {str(element): float(amount) for element, amount in composition.items()}
    if "W" not in elements or "O" not in elements or len(elements) != 3:
        return None
    cation = next(element for element in elements if element not in {"W", "O"})
    w = elements["W"]
    return cation, elements[cation] / w, elements["O"] / w


with gzip.open(INDEX, "rt") as handle:
    index = json.load(handle)

targets = defaultdict(list)
for key, records in index.items():
    if "W" not in key.split("-") or "O" not in key.split("-") or len(key.split("-")) != 3:
        continue
    for formula, identifier, space_group, quality in records:
        item = signature(formula)
        if item is None:
            continue
        cation, cation_per_w, oxygen_per_w = item
        for label, expected in (
            ("A2WO5", (2.0, 5.0)),
            ("A2WO6", (2.0, 6.0)),
            ("A3WO6", (3.0, 6.0)),
            ("AWO4", (1.0, 4.0)),
            ("A2W3O11", (2.0 / 3.0, 11.0 / 3.0)),
            ("A4WO7", (4.0, 7.0)),
        ):
            if abs(cation_per_w - expected[0]) < 1.0e-6 and abs(oxygen_per_w - expected[1]) < 1.0e-6:
                targets[label].append((cation, formula, str(identifier), space_group, quality, key))

for label, records in targets.items():
    print(f"\n{label} ({len(records)} entries)")
    for record in records:
        print(*record)
