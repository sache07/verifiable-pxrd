#!/usr/bin/env python3
"""Bounded coordinate tests for one candidate with its indexed metric fixed."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import learned.staged_polish as polish


def checkpoint(project, destination, suffix):
    polish.clear_flags(project)
    project.save()
    path = destination.with_name(destination.stem + suffix + destination.suffix)
    shutil.copy2(destination, path)
    return str(path)


def activate(project, target, predicate):
    polish.clear_flags(project)
    polish.enable_scales_and_background(project)
    polish.set_all_atoms(project, lambda atom: False)
    polish.set_atoms(target, predicate)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.destination))
    polish.clear_flags(project)
    polish.reset_limits(project)
    polish.install_bounds(project)
    target = project.phase(args.phase)
    records = []

    activate(project, target, lambda atom: not polish.is_oxygen(atom))
    polish.run(project, "candidate_heavy_coordinates", records, 14, kind="coordinates")
    records[-1]["geometry"] = polish.geometry_profile(project)
    records[-1]["checkpoint"] = checkpoint(project, args.destination, ".heavy")

    activate(project, target, polish.is_oxygen)
    polish.run(project, "candidate_oxygen_coordinates", records, 14, kind="coordinates")
    records[-1]["geometry"] = polish.geometry_profile(project)
    records[-1]["checkpoint"] = checkpoint(project, args.destination, ".oxygen")

    activate(project, target, lambda atom: True)
    polish.run(project, "candidate_joint_coordinates", records, 10, kind="coordinates")
    records[-1]["geometry"] = polish.geometry_profile(project)
    records[-1]["checkpoint"] = checkpoint(project, args.destination, ".joint")

    args.destination.with_suffix(".coords.json").write_text(
        json.dumps({"output": str(args.destination), "records": records}, indent=2) + "\n"
    )
    print(json.dumps({"output": str(args.destination), "records": records}, indent=1))


if __name__ == "__main__":
    main()
