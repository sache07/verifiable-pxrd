#!/usr/bin/env python3
"""Compare substituted analogue coordinates in an independently indexed cell."""

from __future__ import annotations

import itertools
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure

from reference_screen import RESOURCE, score_structure


TARGET_CELL = (4.44652004, 7.70049943, 10.46103295)
PARENTS = ("1541070", "2106838", "2213598", "1535177", "8100234")


def cif_path(identifier: str) -> Path:
    return RESOURCE / "cif" / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def nearest_distances(structure: Structure, center: str, neighbor: str, count: int = 8):
    values = []
    for site in structure:
        if site.specie.symbol != center:
            continue
        distances = sorted(
            site.distance(other)
            for other in structure
            if other.specie.symbol == neighbor and other is not site
        )
        values.extend(distances[:count])
    return sorted(values)[:count]


def main():
    profile = np.load(".tmp/two_phase_size.npz")
    x = np.asarray(profile["x"])
    observed = np.asarray(profile["observed"])
    target = np.maximum(np.asarray(profile["difference"]), 0.0)
    weights = 1.0 / np.maximum(observed, 1000.0)

    warnings.simplefilter("ignore")
    rows = []
    for identifier in PARENTS:
        path = cif_path(identifier)
        if not path.exists():
            continue
        source = Structure.from_file(path, primitive=False)
        replacements = {
            element: ("O" if str(element) == "O" else "W" if str(element) in {"W", "Te"} else "Mn")
            for element in source.composition.elements
        }
        source.replace_species(replacements)
        for permutation in itertools.permutations(TARGET_CELL):
            candidate = source.copy()
            candidate.lattice = Lattice.orthorhombic(*permutation)
            best = score_structure(candidate, x, target, weights)
            w_o = nearest_distances(candidate, "W", "O", 8)
            mn_o = nearest_distances(candidate, "Mn", "O", 12)
            rows.append((best[0], best[1], identifier, permutation, best[2], best[3], w_o, mn_o))

    rows.sort(reverse=True)
    print("rank gain cosine parent assigned_cell shift fwhm W-O(first8) Mn-O(first12)")
    for rank, row in enumerate(rows[:30], 1):
        gain, cosine, identifier, permutation, shift, fwhm, w_o, mn_o = row
        print(
            f"{rank:2d} {gain:.6f} {cosine:.6f} {identifier} "
            f"{','.join(f'{value:.6f}' for value in permutation)} {shift:+.3f} {fwhm:.2f} "
            f"{','.join(f'{value:.3f}' for value in w_o)} "
            f"{','.join(f'{value:.3f}' for value in mn_o)}"
        )


if __name__ == "__main__":
    main()
