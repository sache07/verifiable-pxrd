#!/usr/bin/env python3
"""Autoindex the coherent residual family with GSAS-II's cell search."""

from __future__ import annotations

import argparse
import math

from GSASII import GSASIIindex as G2index


PEAKS = [
    (20.32431, 7992.0),
    (20.87850, 8728.0),
    (25.89877, 1150.0),
    (29.14783, 7660.0),
    (32.25562, 3391.0),
    (32.98367, 1343.0),
    (35.29821, 3008.0),
    (35.62420, 9066.0),
    (46.20808, 2794.0),
    (47.01219, 4265.0),
    (54.90120, 3136.0),
    (55.84657, 1886.0),
    (56.99841, 1547.0),
    (59.92147, 614.0),
    (66.96290, 1278.0),
    (70.65748, 797.0),
    (74.85191, 659.0),
    (77.78583, 665.0),
    (79.38319, 754.0),
    (84.72946, 317.0),
    (91.60789, 260.0),
    (94.50922, 295.0),
    (99.07311, 389.0),
]


def unshift_position(observed, shift_um=-671.17, radius_mm=200.0):
    coefficient = 0.09 / (math.pi * radius_mm)
    # One fixed-point iteration is ample for a sub-degree correction.
    position = observed
    for _ in range(3):
        displacement = -coefficient * 4.0 * shift_um * math.cos(math.radians(position / 2.0))
        position = observed - displacement
    return position


def d_spacing(two_theta, wavelength=1.540598):
    return wavelength / (2.0 * math.sin(math.radians(two_theta / 2.0)))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=18)
    parser.add_argument("--timeout", type=float, default=60.0)
    parser.add_argument("--start-volume", type=float, default=300.0)
    parser.add_argument(
        "--bravais",
        nargs="+",
        type=int,
        default=[12, 16],
        help="GSAS-II Bravais indices; 12=P-orthorhombic, 16=P-monoclinic, 17=triclinic",
    )
    args = parser.parse_args()

    peaks = []
    for observed, intensity in PEAKS[: args.count]:
        corrected = unshift_position(observed)
        peaks.append([corrected, intensity, True, False, 0, 0, 0, d_spacing(corrected), 0.0])
        print(f"PEAK observed={observed:.5f} corrected={corrected:.5f} d={d_spacing(corrected):.6f}")

    controls = [0, 0.0, 6, float(args.start_volume), 0, "P1", 1.0, 1.0, 1.0, 90.0, 90.0, 90.0, 1.0, "P 1"]
    names = [
        "Cubic-F", "Cubic-I", "Cubic-P", "Trigonal-R", "Hexagonal-P",
        "Tetragonal-I", "Tetragonal-P", "Orthorhombic-F", "Orthorhombic-I",
        "Orthorhombic-A", "Orthorhombic-B", "Orthorhombic-C", "Orthorhombic-P",
        "Monoclinic-I", "Monoclinic-A", "Monoclinic-C", "Monoclinic-P", "Triclinic",
    ]
    for bravais_index in args.bravais:
        flags = [False] * 18
        flags[bravais_index] = True
        print(f"\nSEARCH {bravais_index} {names[bravais_index]}")
        ok, dmin, cells = G2index.DoIndexPeaks(
            [row[:] for row in peaks], controls[:], flags, None,
            ifX20=True, timeout=args.timeout, M20_min=2.0, X20_max=10,
            return_Nc=True,
        )
        cells = G2index.sortM20(cells)
        print(f"RESULT ok={ok} dmin={dmin:.6f} cells={len(cells)}")
        for cell in cells[:30]:
            print("CELL", cell)


if __name__ == "__main__":
    main()
