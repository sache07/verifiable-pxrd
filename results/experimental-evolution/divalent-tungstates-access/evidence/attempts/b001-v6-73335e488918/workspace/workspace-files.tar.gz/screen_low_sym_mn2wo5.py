#!/usr/bin/env python3
"""Screen low-symmetry A2BO5/ABC O5 frameworks in the indexed residual cell.

The source chemistry is discarded, but source fractional coordinates and site
multiplicities are retained.  All assignments of the three cation populations
to 2 Mn + 1 W and all axis permutations are tested.  This is a prototype
search, not a structure determination by itself.
"""

from __future__ import annotations

import gzip
import itertools
import json
import warnings

import numpy as np
from pymatgen.core import Composition, Lattice, Structure

from reference_screen import RESOURCE, score_structure
from screen_metric_analogues import TARGET_CELL, cif_path


def integer_counts(formula):
    try:
        values = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return None
    if any(abs(value - round(value)) > 1e-6 for value in values.values()):
        return None
    return {key: int(round(value)) for key, value in values.items()}


def mappings(counts):
    """Return element substitutions giving Mn2WO5, including ABCO5 orderings."""
    if counts.get("O") != 5 or sum(counts.values()) != 8:
        return []
    cations = {key: value for key, value in counts.items() if key != "O"}
    result = []
    if sorted(cations.values()) == [1, 2]:
        mapping = {"O": "O"}
        for element, count in cations.items():
            mapping[element] = "Mn" if count == 2 else "W"
        result.append(mapping)
    elif sorted(cations.values()) == [1, 1, 1]:
        for tungsten in cations:
            mapping = {"O": "O"}
            mapping.update({element: ("W" if element == tungsten else "Mn") for element in cations})
            result.append(mapping)
    return result


def symbol(site):
    return max(site.species.items(), key=lambda item: item[1])[0].symbol


def geometry(structure):
    all_dist = structure.distance_matrix.copy()
    np.fill_diagonal(all_dist, np.inf)
    nearest = float(all_dist.min())
    element_pairs = {}
    for i, a in enumerate(structure):
        for j in range(i + 1, len(structure)):
            b = structure[j]
            key = "-".join(sorted((symbol(a), symbol(b))))
            element_pairs.setdefault(key, []).append(float(all_dist[i, j]))
    for values in element_pairs.values():
        values.sort()

    coordinations = {"W": [], "Mn": []}
    for i, site in enumerate(structure):
        center = symbol(site)
        if center not in coordinations:
            continue
        distances = sorted(
            float(all_dist[i, j])
            for j, other in enumerate(structure)
            if symbol(other) == "O"
        )
        coordinations[center].append(distances[:8])

    def plausible_center(center, minimum, cutoff):
        rows = coordinations[center]
        return bool(rows) and all(row and row[0] >= minimum and sum(v <= cutoff for v in row) >= 4 for row in rows)

    cation_short = min(
        element_pairs.get("Mn-Mn", [99.0])
        + element_pairs.get("Mn-W", [99.0])
        + element_pairs.get("W-W", [99.0])
    )
    oxygen_short = min(element_pairs.get("O-O", [99.0]))
    physical = (
        nearest >= 0.8
        and cation_short >= 2.35
        and oxygen_short >= 1.75
        and plausible_center("W", 1.45, 2.45)
        and plausible_center("Mn", 1.55, 2.85)
        and 3.0 <= float(structure.density) <= 10.0
    )
    return {
        "physical": physical,
        "nearest": nearest,
        "cation_short": cation_short,
        "oxygen_short": oxygen_short,
        "W_O": sorted(v for row in coordinations["W"] for v in row)[:12],
        "Mn_O": sorted(v for row in coordinations["Mn"] for v in row)[:16],
    }


def metric_mismatch(source, target_axes):
    source_lengths = np.asarray(source.lattice.abc)
    target_lengths = np.asarray(target_axes)
    ratios = target_lengths / source_lengths
    isotropic = float(np.exp(np.mean(np.log(ratios))))
    anisotropy = float(np.max(np.abs(ratios / isotropic - 1.0)))
    angle_error = float(max(abs(value - 90.0) for value in source.lattice.angles))
    return anisotropy, angle_error


def main():
    profile = np.load(".tmp/two_phase_size.npz")
    x = np.asarray(profile["x"])
    observed = np.asarray(profile["observed"])
    residual = np.maximum(np.asarray(profile["difference"]), 0.0)
    weights = 1.0 / np.maximum(observed, 1000.0)

    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)

    records = []
    seen = set()
    for system, rows in index.items():
        for formula, identifier, listed_sg, quality in rows:
            identifier = str(identifier)
            key = (identifier, formula)
            if key in seen:
                continue
            seen.add(key)
            counts = integer_counts(formula)
            for mapping in mappings(counts or {}):
                records.append((formula, identifier, listed_sg, quality, system, mapping))

    warnings.simplefilter("ignore")
    scored = []
    failures = 0
    for formula, identifier, listed_sg, quality, system, mapping in records:
        try:
            source = Structure.from_file(cif_path(identifier), primitive=False)
            if len(source) > 96 or len(source) < 8:
                continue
            actual_sg = source.get_space_group_info(symprec=1e-3)
            # Lower-symmetry candidates are the purpose, but retain orthorhombic
            # parents as a control and to catch pseudosymmetric settings.
            if actual_sg[1] > 74:
                continue
            candidate0 = source.copy()
            candidate0.replace_species(mapping)
            for target_axes in itertools.permutations(TARGET_CELL):
                anisotropy, angle_error = metric_mismatch(source, target_axes)
                if anisotropy > 0.45 or angle_error > 18.0:
                    continue
                candidate = candidate0.copy()
                candidate.lattice = Lattice.orthorhombic(*target_axes)
                gain, cosine, shift, fwhm, fitted_scale = score_structure(
                    candidate, x, residual, weights
                )
                geom = geometry(candidate)
                scored.append({
                    "gain": gain,
                    "cosine": cosine,
                    "formula": formula,
                    "id": identifier,
                    "listed_sg": listed_sg,
                    "actual_sg": actual_sg,
                    "quality": quality,
                    "system": system,
                    "mapping": mapping,
                    "axes": target_axes,
                    "anisotropy": anisotropy,
                    "angle_error": angle_error,
                    "shift": shift,
                    "fwhm": fwhm,
                    "density": float(candidate.density),
                    "sites": len(candidate),
                    **geom,
                })
        except Exception:
            failures += 1

    scored.sort(key=lambda item: item["gain"], reverse=True)
    with open(".tmp/low_sym_mn2wo5_screen.json", "w") as handle:
        json.dump(scored, handle, indent=1, default=float)

    print(f"mappings={len(records)} variants={len(scored)} failures={failures}")
    print("rank gain cosine phys id formula sg axes aniso ang shift fwhm rho min cat O-O W-O Mn-O mapping")
    for rank, item in enumerate(scored[:160], 1):
        print(
            f"{rank:3d} {item['gain']:.5f} {item['cosine']:.5f} {str(item['physical']):5s} "
            f"{item['id']} {item['formula']:20s} {item['actual_sg'][0]:10s} "
            f"{','.join(f'{v:.5f}' for v in item['axes'])} {item['anisotropy']:.3f} "
            f"{item['angle_error']:.2f} {item['shift']:+.3f} {item['fwhm']:.2f} "
            f"{item['density']:.2f} {item['nearest']:.2f} {item['cation_short']:.2f} "
            f"{item['oxygen_short']:.2f} "
            f"{','.join(f'{v:.2f}' for v in item['W_O'][:6])} "
            f"{','.join(f'{v:.2f}' for v in item['Mn_O'][:8])} "
            f"{','.join(f'{a}->{b}' for a,b in sorted(item['mapping'].items()))}"
        )

    print("\nPHYSICAL")
    for rank, item in enumerate((row for row in scored if row["physical"]), 1):
        if rank > 100:
            break
        print(
            f"{rank:3d} {item['gain']:.5f} {item['cosine']:.5f} {item['id']} "
            f"{item['formula']:20s} {item['actual_sg'][0]:10s} "
            f"{','.join(f'{v:.5f}' for v in item['axes'])} aniso={item['anisotropy']:.3f} "
            f"shift={item['shift']:+.3f} fwhm={item['fwhm']:.2f}"
        )


if __name__ == "__main__":
    main()
