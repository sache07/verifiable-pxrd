#!/usr/bin/env python3
"""Create inversion-only Mn2WO5 subgroup models from analogue parents."""

from __future__ import annotations

from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure

from reference_screen import cif_path


ROOT = Path(__file__).resolve().parent


def inversion_asymmetric_sites(structure):
    """Reduce a full conventional structure to one site per inversion pair."""
    used = set()
    rows = []
    symbols = [max(site.species.items(), key=lambda item: item[1])[0].symbol for site in structure]
    for index, site in enumerate(structure):
        if index in used:
            continue
        target = (-site.frac_coords) % 1.0
        candidates = [
            (structure.lattice.get_distance_and_image(target, other.frac_coords)[0], j)
            for j, other in enumerate(structure)
            if j not in used and symbols[j] == symbols[index]
        ]
        distance, partner = min(candidates)
        if distance > 1e-3:
            raise ValueError(f"no inversion mate for site {index}: nearest {distance}")
        used.add(index)
        used.add(partner)
        rows.append((symbols[index], np.asarray(site.frac_coords) % 1.0))
    return rows


def write_pminus1(path, source_id, source_mapping, axes, note, formula="Mn2 O5 W"):
    source = Structure.from_file(cif_path(source_id), primitive=False)
    source.replace_species(source_mapping)
    source.lattice = Lattice.orthorhombic(*axes)
    rows = inversion_asymmetric_sites(source)
    counts = {"Mn": 0, "W": 0, "O": 0}
    lines = [
        f"# Mn2WO5 inversion subgroup candidate from COD {source_id}.",
        f"# {note}",
        "data_Mn2WO5_Pminus1_candidate",
        "_audit_creation_method 'analogue substitution and inversion subgroup expansion'",
        f"_chemical_formula_sum '{formula}'",
        "_space_group_IT_number 2",
        "_space_group_name_Hall '-P 1'",
        "_space_group_name_H-M_alt 'P -1'",
        f"_cell_length_a {axes[0]:.8f}",
        f"_cell_length_b {axes[1]:.8f}",
        f"_cell_length_c {axes[2]:.8f}",
        "_cell_angle_alpha 90",
        "_cell_angle_beta 90",
        "_cell_angle_gamma 90",
        "_cell_formula_units_Z 4",
        "",
        "loop_",
        "_space_group_symop_id",
        "_space_group_symop_operation_xyz",
        "1 x,y,z",
        "2 -x,-y,-z",
        "",
        "loop_",
        "_atom_site_label",
        "_atom_site_type_symbol",
        "_atom_site_fract_x",
        "_atom_site_fract_y",
        "_atom_site_fract_z",
        "_atom_site_occupancy",
        "_atom_site_U_iso_or_equiv",
    ]
    for symbol, xyz in rows:
        counts[symbol] += 1
        lines.append(
            f"{symbol}{counts[symbol]} {symbol} "
            f"{xyz[0]:.9f} {xyz[1]:.9f} {xyz[2]:.9f} 1 0.010"
        )
    path.write_text("\n".join(lines) + "\n")
    print(path, counts, len(source), source.density)


def main():
    write_pminus1(
        ROOT / "Mn2WO5_from_CaBeAsO5_Pminus1.cif",
        "9008314", {"Ca": "Mn", "Be": "Mn", "As": "W", "O": "O"},
        (4.44652004, 7.70049943, 10.46103295),
        "Parent P21/c general orbits split into inversion pairs to permit the observed odd axial reflections.",
    )
    write_pminus1(
        ROOT / "Mn2WO5_from_La2RuO5_Pminus1.cif",
        "2015098", {"La": "Mn", "Ru": "W", "O": "O"},
        (7.70049943, 4.44652004, 10.46103295),
        "Low-temperature La2RuO5 is already P-1; La and Ru were replaced by Mn and W.",
    )
    write_pminus1(
        ROOT / "Mn2WO5_from_Mn2BiO5_Pminus1.cif",
        "9008146", {"Mn": "Mn", "Bi": "W", "O": "O"},
        (10.46103295, 7.70049943, 4.44652004),
        "Parent Pbam orbits split into inversion pairs to remove glide extinctions.",
    )
    write_pminus1(
        ROOT / "Mn3O5_from_La2RuO5_Pminus1.cif",
        "2015098", {"La": "Mn", "Ru": "Mn", "O": "O"},
        (7.70049943, 4.44652004, 10.46103295),
        "Low-temperature La2RuO5 is already P-1; both cation sublattices were replaced by Mn.",
        formula="Mn3 O5",
    )


if __name__ == "__main__":
    main()
