#!/usr/bin/env python3
"""Fast text scan of the frozen CIF tree for the indexed residual metric."""

from __future__ import annotations

import gzip
import itertools
import json
import math
import re
from pathlib import Path

import numpy as np

from reference_screen import RESOURCE
from screen_metric_analogues import TARGET_CELL


NUMBER = r"([-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[Ee][-+]?\d+)?)(?:\(\d+\))?"


def extract(text, tag):
    match = re.search(r"(?mi)^\s*" + re.escape(tag) + r"\s+['\"]?" + NUMBER, text)
    return float(match.group(1)) if match else None


def main():
    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)
    metadata = {}
    for system, rows in index.items():
        for formula, identifier, sg, quality in rows:
            metadata[str(identifier)] = (formula, sg, quality, system)

    target = np.asarray(TARGET_CELL)
    rows = []
    for path in (RESOURCE / "cif").rglob("*.cif"):
        identifier = path.stem
        if identifier not in metadata:
            continue
        try:
            text = path.read_text(errors="ignore")[:30000]
            lengths = np.array([extract(text, f"_cell_length_{axis}") for axis in "abc"], float)
            angles = np.array([extract(text, f"_cell_angle_{axis}") for axis in ("alpha", "beta", "gamma")], float)
            if not np.all(np.isfinite(lengths)) or not np.all(np.isfinite(angles)):
                continue
            best = None
            for perm in itertools.permutations(target):
                ratios = np.asarray(perm) / lengths
                scale = float(np.exp(np.mean(np.log(ratios))))
                shape = float(np.sqrt(np.mean(np.log(ratios / scale) ** 2)))
                absolute = float(np.sqrt(np.mean(np.log(ratios) ** 2)))
                maximum = float(np.max(np.abs(ratios - 1.0)))
                record = (shape, absolute, maximum, scale, tuple(float(v) for v in perm))
                if best is None or record < best:
                    best = record
            angle_rms = float(np.sqrt(np.mean((angles - 90.0) ** 2)))
            angle_max = float(np.max(np.abs(angles - 90.0)))
            formula, sg, quality, system = metadata[identifier]
            rows.append((*best, angle_rms, angle_max, identifier, formula, sg, quality, system,
                         tuple(lengths), tuple(angles)))
        except Exception:
            continue

    rows.sort(key=lambda row: (row[0] + row[5] / 150.0, row[1]))
    print("rank shape absolute max scale target_axes angle_rms angle_max id formula sg source_cell angles")
    for rank, row in enumerate(rows[:600], 1):
        shape, absolute, maximum, scale, axes, angle_rms, angle_max, identifier, formula, sg, quality, system, lengths, angles = row
        print(
            f"{rank:4d} {shape:.5f} {absolute:.5f} {maximum:.4f} {scale:.4f} "
            f"{','.join(f'{v:.5f}' for v in axes)} {angle_rms:.3f} {angle_max:.3f} "
            f"{identifier} {formula:28s} {sg:3d} "
            f"{','.join(f'{v:.5f}' for v in lengths)} {','.join(f'{v:.3f}' for v in angles)}"
        )


if __name__ == "__main__":
    main()
