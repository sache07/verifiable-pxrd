#!/usr/bin/env python3
"""Broad low-symmetry Mn/W oxide prototype screen in the indexed cell."""

from __future__ import annotations

import argparse
import gzip
import itertools
import json
import math
import warnings

import numpy as np
from pymatgen.core import Composition, Lattice, Structure

from reference_screen import RESOURCE, profile, sticks
from screen_metric_analogues import TARGET_CELL, cif_path


NO_TRANSLATION_GROUPS = {1, 2, 3, 6, 10, 16, 25, 47}


def integer_counts(formula):
    try:
        values = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return None
    if any(abs(value - round(value)) > 1e-6 for value in values.values()):
        return None
    return {key: int(round(value)) for key, value in values.items()}


def reduced_target(counts, mapping):
    totals = {"Mn": 0, "W": 0, "O": counts["O"]}
    for element, target in mapping.items():
        totals[target] += counts[element]
    common = math.gcd(math.gcd(totals["Mn"], totals["W"]), totals["O"])
    return {key: value // common for key, value in totals.items()}


def chemically_plausible(target):
    mn, w, oxygen = target["Mn"], target["W"], target["O"]
    if mn + w == 0 or oxygen < mn + w or oxygen > 3 * (mn + w):
        return False
    charge = 2 * oxygen
    return 2 * mn + 4 * w <= charge <= 4 * mn + 6 * w


def mapping_options(counts):
    if "O" not in counts or len(counts) < 2:
        return []
    cations = [element for element in counts if element != "O"]
    if not 1 <= len(cations) <= 3 or sum(counts.values()) > 24:
        return []
    options = []
    for assigned in itertools.product(("Mn", "W"), repeat=len(cations)):
        mapping = dict(zip(cations, assigned))
        target = reduced_target(counts, mapping)
        if chemically_plausible(target) and target["Mn"] > target["W"]:
            options.append((mapping, target))
    return options


def symbol(site):
    return max(site.species.items(), key=lambda item: item[1])[0].symbol


def geometry(structure):
    dm = structure.distance_matrix.copy()
    np.fill_diagonal(dm, np.inf)
    nearest = float(dm.min())
    pair_min = {}
    for i, left in enumerate(structure):
        for j in range(i + 1, len(structure)):
            key = "-".join(sorted((symbol(left), symbol(structure[j]))))
            pair_min[key] = min(pair_min.get(key, 99.0), float(dm[i, j]))
    coordination = {"Mn": [], "W": []}
    for i, site in enumerate(structure):
        element = symbol(site)
        if element in coordination:
            coordination[element].append(sorted(float(dm[i, j]) for j, other in enumerate(structure) if symbol(other) == "O")[:8])

    def centers_ok(element, shortest, cutoff):
        return bool(coordination[element]) and all(
            bool(row) and row[0] >= shortest and sum(v <= cutoff for v in row) >= 4
            for row in coordination[element]
        )

    physical = (
        nearest >= 0.8
        and pair_min.get("O-O", 99.0) >= 1.75
        and min(pair_min.get("Mn-Mn", 99.0), pair_min.get("Mn-W", 99.0), pair_min.get("W-W", 99.0)) >= 2.3
        and centers_ok("Mn", 1.50, 2.90)
        and centers_ok("W", 1.45, 2.50)
    )
    return physical, nearest, pair_min, coordination


def fixed_score(structure, x, target, weights, shift=0.34, fwhm=0.22):
    sets = [sticks(structure, wavelength, x[0], x[-1]) for wavelength in (1.540598, 1.544426)]
    calculated = profile(sets, x, shift, fwhm)
    denominator = float(np.sum(weights * calculated * calculated))
    target_norm = float(np.sum(weights * target * target))
    cross = float(np.sum(weights * target * calculated))
    scale = max(0.0, cross / denominator) if denominator else 0.0
    gain = (2 * scale * cross - scale * scale * denominator) / target_norm if target_norm else 0.0
    cosine = cross / math.sqrt(target_norm * denominator) if target_norm and denominator else 0.0
    return float(gain), float(cosine)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--count-only", action="store_true")
    parser.add_argument("--physical-only", action="store_true")
    args = parser.parse_args()
    profile_data = np.load(".tmp/two_phase_size.npz")
    x = np.asarray(profile_data["x"])
    observed = np.asarray(profile_data["observed"])
    residual = np.maximum(np.asarray(profile_data["difference"]), 0.0)
    weights = 1.0 / np.maximum(observed, 1000.0)

    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)
    formulas = []
    seen = set()
    for system, rows in index.items():
        for formula, identifier, listed_sg, quality in rows:
            identifier = str(identifier)
            if int(listed_sg) not in NO_TRANSLATION_GROUPS:
                continue
            counts = integer_counts(formula)
            if counts is None:
                continue
            for mapping, target in mapping_options(counts):
                key = (identifier, tuple(sorted(mapping.items())))
                if key not in seen:
                    seen.add(key)
                    formulas.append((formula, identifier, listed_sg, quality, system, mapping, target))
    print(f"formula_mappings={len(formulas)}", flush=True)

    warnings.simplefilter("ignore")
    variants = []
    parsed = 0
    for formula, identifier, listed_sg, quality, system, mapping, target_formula in formulas:
        try:
            source = Structure.from_file(cif_path(identifier), primitive=False)
            if len(source) > 96:
                continue
            sg = source.get_space_group_info(symprec=1e-3)
            if sg[1] not in NO_TRANSLATION_GROUPS:
                continue
            parsed += 1
            source_lengths = np.asarray(source.lattice.abc)
            angle_error = max(abs(value - 90.0) for value in source.lattice.angles)
            if angle_error > 18.0:
                continue
            candidate0 = source.copy()
            candidate0.replace_species({**mapping, "O": "O"})
            formula_atoms = sum(target_formula.values())
            z = len(candidate0) / formula_atoms
            if abs(z - round(z)) > 1e-5:
                continue
            for axes in itertools.permutations(TARGET_CELL):
                ratios = np.asarray(axes) / source_lengths
                scale = float(np.exp(np.mean(np.log(ratios))))
                anisotropy = float(np.max(np.abs(ratios / scale - 1.0)))
                if anisotropy > 0.45:
                    continue
                candidate = candidate0.copy()
                candidate.lattice = Lattice.orthorhombic(*axes)
                if not 3.0 <= float(candidate.density) <= 10.0:
                    continue
                physical, nearest, pair_min, coordination = geometry(candidate)
                variants.append((candidate, {
                    "formula": formula, "id": identifier, "sg": sg,
                    "listed_sg": listed_sg, "quality": quality, "system": system,
                    "mapping": mapping, "target": target_formula, "axes": axes,
                    "anisotropy": anisotropy, "angle_error": angle_error,
                    "density": float(candidate.density), "sites": len(candidate),
                    "z": z, "physical": physical, "nearest": nearest,
                    "pair_min": pair_min,
                    "W_O": sorted(v for row in coordination["W"] for v in row)[:12],
                    "Mn_O": sorted(v for row in coordination["Mn"] for v in row)[:16],
                }))
        except Exception:
            continue
    print(f"low_symmetry_structures={parsed} metric_variants={len(variants)} physical={sum(v[1]['physical'] for v in variants)}", flush=True)
    if args.count_only:
        return
    if args.physical_only:
        variants = [variant for variant in variants if variant[1]["physical"]]
        print(f"scoring_physical_variants={len(variants)}", flush=True)

    scored = []
    for number, (candidate, item) in enumerate(variants, 1):
        try:
            item["gain"], item["cosine"] = fixed_score(candidate, x, residual, weights)
            scored.append(item)
        except Exception:
            continue
        if number % 100 == 0:
            print(f"scored={number}/{len(variants)}", flush=True)
    scored.sort(key=lambda item: item["gain"], reverse=True)
    with open(".tmp/general_mn_w_oxide_screen.json", "w") as handle:
        json.dump(scored, handle, indent=1, default=float)
    print("rank gain cosine phys target id source sg axes aniso rho min pairs W-O Mn-O mapping")
    for rank, item in enumerate(scored[:200], 1):
        target_name = f"Mn{item['target']['Mn']}W{item['target']['W']}O{item['target']['O']}"
        print(
            f"{rank:3d} {item['gain']:.5f} {item['cosine']:.5f} {str(item['physical']):5s} "
            f"{target_name:10s} {item['id']} {item['formula']:24s} {item['sg'][0]:8s} "
            f"{','.join(f'{v:.5f}' for v in item['axes'])} {item['anisotropy']:.3f} "
            f"{item['density']:.2f} {item['nearest']:.2f} "
            f"{','.join(f'{k}:{v:.2f}' for k,v in sorted(item['pair_min'].items()))} "
            f"{','.join(f'{v:.2f}' for v in item['W_O'][:6])} "
            f"{','.join(f'{v:.2f}' for v in item['Mn_O'][:8])} "
            f"{','.join(f'{a}->{b}' for a,b in sorted(item['mapping'].items()))}"
        )


if __name__ == "__main__":
    main()
