#!/usr/bin/env python3
"""Run a structure-independent Le Bail test for one phase in a checkpoint."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrMain as G2main

sys.path.insert(0, str((Path(__file__).resolve().parent / "learned").resolve()))
import staged_polish as polish


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--cycles", type=int, default=25)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.destination))
    polish.clear_flags(project)
    target = next((phase for phase in project.phases() if phase.name == args.phase), None)
    if target is None:
        raise SystemExit(f"phase not found: {args.phase}")
    target.set_refinements({"LeBail": True})
    project.save()
    ok, values = G2main.DoLeBail(str(args.destination), cycles=args.cycles)
    project.reload()
    hist = polish.histogram(project)
    print(json.dumps({
        "ok": bool(ok),
        "Rwp_percent": float(hist.get_wR()),
        "values": values,
        "phase": args.phase,
        "output": str(args.destination),
    }, indent=1))


if __name__ == "__main__":
    main()
