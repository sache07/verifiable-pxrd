#!/usr/bin/env python3
"""Screen chemically plausible Mn-rich oxide framework transfers in an indexed cell."""

from __future__ import annotations

import gzip
import json
import warnings

import numpy as np
from pymatgen.core import Composition, Lattice, Structure

from reference_screen import RESOURCE, score_structure
from screen_metric_analogues import TARGET_CELL, cif_path, metric_record, neighbor_distances


TARGETS = {
    "Mn2WO5": {"Mn": 2, "W": 1, "O": 5},
    "Mn2WO6": {"Mn": 2, "W": 1, "O": 6},
    "Mn3WO6": {"Mn": 3, "W": 1, "O": 6},
    "Mn4WO7": {"Mn": 4, "W": 1, "O": 7},
    "Mn2W3O11": {"Mn": 2, "W": 3, "O": 11},
}


def reduced_integer_counts(formula: str):
    try:
        values = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return None
    if any(abs(value - round(value)) > 1.0e-6 for value in values.values()):
        return None
    return {element: int(round(value)) for element, value in values.items()}


def mapping_for(counts, target):
    if len(counts) != 3 or counts.get("O") != target["O"]:
        return None
    source_cations = {element: value for element, value in counts.items() if element != "O"}
    if sorted(source_cations.values()) != sorted((target["Mn"], target["W"])):
        return None
    if target["Mn"] == target["W"]:
        return None
    mapping = {"O": "O"}
    for element, value in source_cations.items():
        mapping[element] = "Mn" if value == target["Mn"] else "W"
    return mapping


def geometry_summary(structure):
    w_o = neighbor_distances(structure, "W", "O", 10)
    mn_o = neighbor_distances(structure, "Mn", "O", 16)
    physical = (
        len(w_o) >= 4
        and len(mn_o) >= 4
        and min(w_o) >= 1.55
        and min(mn_o) >= 1.65
        and sum(value <= 2.35 for value in w_o) >= 4
        and sum(value <= 2.70 for value in mn_o) >= 4
    )
    return physical, w_o, mn_o


def main():
    profile = np.load(".tmp/two_phase_size.npz")
    x = np.asarray(profile["x"])
    observed = np.asarray(profile["observed"])
    residual = np.maximum(np.asarray(profile["difference"]), 0.0)
    weights = 1.0 / np.maximum(observed, 1000.0)

    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)
    records = []
    seen = set()
    for system, rows in index.items():
        for formula, identifier, listed_space_group, quality in rows:
            identifier = str(identifier)
            if identifier in seen:
                continue
            counts = reduced_integer_counts(formula)
            if counts is None:
                continue
            for target_name, target_counts in TARGETS.items():
                mapping = mapping_for(counts, target_counts)
                if mapping is not None:
                    records.append(
                        (target_name, formula, identifier, listed_space_group, quality, mapping, system)
                    )
                    seen.add(identifier)
                    break

    warnings.simplefilter("ignore")
    scored = []
    for target_name, formula, identifier, listed_space_group, quality, mapping, system in records:
        try:
            source = Structure.from_file(cif_path(identifier), primitive=False)
            if len(source) > 96:
                continue
            metric = metric_record(source)
            if metric is None or metric[0] > 0.40:
                continue
            candidate = source.copy()
            candidate.replace_species(mapping)
            candidate.lattice = Lattice.orthorhombic(*metric[2])
            gain, cosine, shift, fwhm, fitted_scale = score_structure(
                candidate, x, residual, weights
            )
            physical, w_o, mn_o = geometry_summary(candidate)
            actual_space_group = source.get_space_group_info(symprec=1.0e-3)
            factor = len(source) / sum(TARGETS[target_name].values())
            scored.append(
                dict(
                    gain=gain,
                    cosine=cosine,
                    target=target_name,
                    formula=formula,
                    identifier=identifier,
                    listed_space_group=listed_space_group,
                    actual_space_group=actual_space_group,
                    quality=quality,
                    mapping=mapping,
                    system=system,
                    metric_anisotropy=metric[0],
                    target_axes=metric[2],
                    shift=shift,
                    fwhm=fwhm,
                    physical=physical,
                    w_o=w_o,
                    mn_o=mn_o,
                    z=factor,
                    density=float(candidate.density),
                )
            )
        except Exception:
            continue

    def show(rows, title, count=80):
        print(f"\n{title}")
        print("rank gain cosine phys target id source_formula sg_actual aniso axes shift fwhm Z density W-O Mn-O")
        for rank, item in enumerate(rows[:count], 1):
            print(
                f"{rank:3d} {item['gain']:.6f} {item['cosine']:.6f} {str(item['physical']):5s} "
                f"{item['target']:9s} {item['identifier']} {item['formula']:22s} "
                f"{item['actual_space_group'][0]} {item['metric_anisotropy']:.4f} "
                f"{','.join(f'{value:.5f}' for value in item['target_axes'])} "
                f"{item['shift']:+.3f} {item['fwhm']:.2f} {item['z']:.1f} {item['density']:.3f} "
                f"{','.join(f'{value:.3f}' for value in item['w_o'][:8])} "
                f"{','.join(f'{value:.3f}' for value in item['mn_o'][:12])}"
            )

    scored.sort(key=lambda item: item["gain"], reverse=True)
    print(f"formula_candidates={len(records)} scored={len(scored)}")
    show(scored, "ALL BY PROFILE", 70)
    physical = [item for item in scored if item["physical"] and 3.0 <= item["density"] <= 10.0]
    show(physical, "PHYSICAL GEOMETRY AND DENSITY", 70)


if __name__ == "__main__":
    main()
