#!/usr/bin/env python3
"""Screen A2BO6 oxide frameworks in the frozen index in an indexed target cell."""

from __future__ import annotations

import gzip
import itertools
import json
import math
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Composition, Lattice, Structure

from reference_screen import RESOURCE, score_structure


TARGET_CELL = (4.44652004, 7.70049943, 10.46103295)


def cif_path(identifier: str) -> Path:
    return RESOURCE / "cif" / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def reduced_integer_counts(formula: str):
    try:
        values = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return None
    if any(abs(value - round(value)) > 1.0e-6 for value in values.values()):
        return None
    return {element: int(round(value)) for element, value in values.items()}


def composition_mapping(counts):
    if counts.get("O") != 6 or sum(counts.values()) != 9:
        return None
    cations = {element: count for element, count in counts.items() if element != "O"}
    if sorted(cations.values()) != [1, 2]:
        return None
    mapping = {"O": "O"}
    for element, count in cations.items():
        mapping[element] = "W" if count == 1 else "Mn"
    return mapping


def metric_record(structure: Structure):
    lengths = structure.lattice.abc
    angles = structure.lattice.angles
    if max(abs(angle - 90.0) for angle in angles) > 5.0:
        return None
    best = None
    for permutation in itertools.permutations(TARGET_CELL):
        logarithms = np.log(np.asarray(permutation) / np.asarray(lengths))
        scale = float(np.exp(np.mean(logarithms)))
        anisotropy = float(np.max(np.abs(np.exp(logarithms) / scale - 1.0)))
        record = (anisotropy, scale, permutation)
        if best is None or record < best:
            best = record
    return best


def neighbor_distances(structure: Structure, center: str, neighbor: str, count: int):
    def symbol(site):
        return max(site.species.items(), key=lambda item: item[1])[0].symbol

    rows = []
    for site in structure:
        if symbol(site) != center:
            continue
        rows.extend(
            sorted(
                site.distance(other)
                for other in structure
                if symbol(other) == neighbor and other is not site
            )[:count]
        )
    return sorted(rows)[:count]


def main():
    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)

    candidates = []
    seen = set()
    for system, records in index.items():
        for formula, identifier, listed_space_group, quality in records:
            identifier = str(identifier)
            if identifier in seen:
                continue
            counts = reduced_integer_counts(formula)
            mapping = composition_mapping(counts) if counts is not None else None
            if mapping is None:
                continue
            seen.add(identifier)
            candidates.append((formula, identifier, listed_space_group, quality, mapping, system))

    warnings.simplefilter("ignore")
    metric_rows = []
    for formula, identifier, listed_space_group, quality, mapping, system in candidates:
        try:
            structure = Structure.from_file(cif_path(identifier), primitive=False)
            if len(structure) > 72:
                continue
            metric = metric_record(structure)
            if metric is None:
                continue
            actual_space_group = structure.get_space_group_info(symprec=1.0e-3)
            metric_rows.append(
                (metric[0], formula, identifier, listed_space_group, quality, mapping, system,
                 structure, actual_space_group, metric[1])
            )
        except Exception:
            continue
    metric_rows.sort(key=lambda row: row[0])
    # A deliberately broad metric gate: analogue substitution can be anisotropic,
    # but frameworks beyond this are no longer modest transfer candidates.
    selected = [row for row in metric_rows if row[0] <= 0.28][:140]

    profile = np.load(".tmp/two_phase_size.npz")
    x = np.asarray(profile["x"])
    observed = np.asarray(profile["observed"])
    target = np.maximum(np.asarray(profile["difference"]), 0.0)
    weights = 1.0 / np.maximum(observed, 1000.0)

    scored = []
    for row in selected:
        anisotropy, formula, identifier, listed_space_group, quality, mapping, system, source, actual_space_group, scale = row
        source = source.copy()
        source.replace_species(mapping)
        for permutation in itertools.permutations(TARGET_CELL):
            candidate = source.copy()
            candidate.lattice = Lattice.orthorhombic(*permutation)
            try:
                gain, cosine, shift, fwhm, fitted_scale = score_structure(
                    candidate, x, target, weights
                )
            except Exception:
                continue
            w_o = neighbor_distances(candidate, "W", "O", 8)
            mn_o = neighbor_distances(candidate, "Mn", "O", 12)
            scored.append(
                (gain, cosine, anisotropy, identifier, formula, listed_space_group,
                 actual_space_group, permutation, shift, fwhm, quality, system, mapping,
                 w_o, mn_o)
            )

    scored.sort(key=lambda row: row[0], reverse=True)
    print(f"eligible={len(candidates)} metric_parsed={len(metric_rows)} screened={len(selected)} variants={len(scored)}")
    print("rank gain cosine metric_aniso id formula sg_list sg_actual target_axes shift fwhm mapping W-O Mn-O")
    for rank, row in enumerate(scored[:100], 1):
        (gain, cosine, anisotropy, identifier, formula, listed_space_group,
         actual_space_group, permutation, shift, fwhm, quality, system, mapping,
         w_o, mn_o) = row
        print(
            f"{rank:3d} {gain:.6f} {cosine:.6f} {anisotropy:.4f} {identifier} "
            f"{formula:24s} {listed_space_group:3d} {actual_space_group[0]} "
            f"{','.join(f'{value:.6f}' for value in permutation)} {shift:+.3f} {fwhm:.2f} "
            f"{','.join(f'{key}->{value}' for key, value in sorted(mapping.items()))} "
            f"{','.join(f'{value:.3f}' for value in w_o)} "
            f"{','.join(f'{value:.3f}' for value in mn_o)}"
        )


if __name__ == "__main__":
    main()
