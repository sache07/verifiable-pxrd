#!/usr/bin/env python3
"""Print residual families and plot a GSAS-II powder checkpoint."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from scipy import signal

try:
    import matplotlib.pyplot as plt
except ModuleNotFoundError:
    plt = None

from GSASII import GSASIIscriptable as G2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("--prominence", type=float, default=150.0)
    parser.add_argument("--top", type=int, default=100)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.project.resolve()))
    hist = max(project.histograms(), key=lambda item: len(item.data["data"][1][0]))
    x, observed, weights, calculated, background, difference = [
        np.asarray(array, dtype=float) for array in hist.data["data"][1][:6]
    ]
    smooth = signal.savgol_filter(difference, 13, 3)
    peaks, props = signal.find_peaks(
        smooth, prominence=args.prominence, width=(1.0, 200.0), distance=3
    )
    order = np.argsort(props["prominences"])[::-1]
    step = float(np.median(np.diff(x)))
    print(f"project={args.project} histogram={hist.name} Rwp={hist.get_wR():.6f}%")
    print("positive residual peaks")
    print("rank 2theta observed calculated difference prominence fwhm_deg")
    for rank, item in enumerate(order[: args.top], 1):
        index = peaks[item]
        print(
            f"{rank:3d} {x[index]:10.5f} {observed[index]:9.1f} {calculated[index]:10.1f} "
            f"{difference[index]:10.1f} {props['prominences'][item]:10.1f} "
            f"{props['widths'][item] * step:9.4f}"
        )

    output = args.output or args.project.with_suffix(".png")
    np.savez(
        output.with_suffix(".npz"),
        x=x,
        observed=observed,
        calculated=calculated,
        background=background,
        difference=difference,
    )
    if plt is None:
        print(f"profile arrays saved to {output.with_suffix('.npz')}")
        return
    fig, axes = plt.subplots(2, 1, figsize=(17, 9), sharex=True)
    axes[0].plot(x, observed, color="black", lw=0.55, label="observed")
    axes[0].plot(x, calculated, color="tab:red", lw=0.65, label="calculated")
    axes[0].plot(x, background, color="tab:blue", lw=0.65, label="background")
    axes[0].legend(loc="upper right")
    axes[0].set_ylabel("counts")
    axes[0].set_title(f"{args.project.name}: Rwp={hist.get_wR():.3f}%")
    axes[1].plot(x, difference, color="black", lw=0.55)
    axes[1].axhline(0.0, color="tab:red", lw=0.6)
    axes[1].set_ylabel("observed - calculated")
    axes[1].set_xlabel(r"$2\theta$ (degrees)")
    for axis in axes:
        axis.grid(alpha=0.15)
        axis.set_xlim(x[0], x[-1])
    fig.tight_layout()
    fig.savefig(output, dpi=170)


if __name__ == "__main__":
    main()
