#!/usr/bin/env python3
"""Bounded diagnostic coordinate refinement for one named candidate phase."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str((Path(__file__).resolve().parent / "learned").resolve()))
import staged_polish as polish


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("phase")
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.destination))
    polish.clear_flags(project)
    polish.reset_limits(project)
    polish.install_bounds(project)
    polish.enable_scales_and_background(project)
    project.save()

    target = next((phase for phase in project.phases() if phase.name == args.phase), None)
    if target is None:
        raise SystemExit(f"phase not found: {args.phase}")
    records = []

    polish.set_all_atoms(project, lambda atom: False)
    polish.set_atoms(target, lambda atom: not polish.is_oxygen(atom))
    polish.run(project, "candidate_heavy_coordinates", records, 10, kind="coordinates")

    polish.set_all_atoms(project, lambda atom: False)
    polish.set_atoms(target, polish.is_oxygen)
    polish.run(project, "candidate_oxygen_coordinates", records, 10, kind="coordinates")

    polish.set_all_atoms(project, lambda atom: False)
    polish.set_atoms(target, lambda atom: True)
    polish.run(project, "candidate_joint_coordinates", records, 10, kind="coordinates")

    polish.clear_flags(project)
    polish.enable_scales_and_background(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    polish.run(project, "cell_scale_background_settle", records, 8, kind="settle")
    polish.clear_flags(project)
    project.save()

    print(json.dumps({
        "output": str(args.destination),
        "fractions": polish.mass_fractions(project),
        "geometry": polish.geometry_profile(project),
        "records": records,
    }, indent=1))


if __name__ == "__main__":
    main()
