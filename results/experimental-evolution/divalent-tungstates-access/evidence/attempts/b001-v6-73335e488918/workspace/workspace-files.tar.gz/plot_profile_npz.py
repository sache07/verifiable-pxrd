#!/usr/bin/env python3
"""Render profile arrays exported by gpx_diagnostics.py."""

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
data = np.load(args.input)
x = data["x"]

fig, axes = plt.subplots(2, 1, figsize=(17, 9), sharex=True)
axes[0].plot(x, data["observed"], color="black", lw=0.55, label="observed")
axes[0].plot(x, data["calculated"], color="tab:red", lw=0.65, label="calculated")
axes[0].plot(x, data["background"], color="tab:blue", lw=0.65, label="background")
axes[0].legend(loc="upper right")
axes[0].set_ylabel("counts")
axes[1].plot(x, data["difference"], color="black", lw=0.55)
axes[1].axhline(0.0, color="tab:red", lw=0.6)
axes[1].set_ylabel("observed - calculated")
axes[1].set_xlabel(r"$2\theta$ (degrees)")
for axis in axes:
    axis.grid(alpha=0.15)
    axis.set_xlim(x[0], x[-1])
fig.tight_layout()
fig.savefig(args.output, dpi=170)
