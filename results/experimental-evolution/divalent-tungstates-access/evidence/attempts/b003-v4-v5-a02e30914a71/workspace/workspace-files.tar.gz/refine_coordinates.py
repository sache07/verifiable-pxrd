#!/usr/bin/env python3
"""Continue a checkpoint with bounded coordinate refinement."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--mode", choices=["heavy", "oxygen"], required=True)
    parser.add_argument("--phases", default="all")
    parser.add_argument("--delta", type=float, default=0.03)
    args = parser.parse_args()

    project = G2sc.G2Project(args.input, newgpx=args.out)
    hist = project.histogram(0)
    selected = (
        {phase.name for phase in project.phases()}
        if args.phases == "all"
        else {item.strip() for item in args.phases.split(",")}
    )
    before = float(hist.residuals["wR"])
    project.index_ids()

    for phase in project.phases():
        for atom_index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = " "
            wanted = (
                (args.mode == "heavy" and atom.element != "O")
                or (args.mode == "oxygen" and atom.element == "O")
            )
            if phase.name not in selected or not wanted:
                continue
            atom.refinement_flags = "X"
            for axis, value in zip(("x", "y", "z"), atom.coordinates):
                variable = project.make_var_obj(
                    phase=phase,
                    varname=f"dA{axis}",
                    atomId=atom,
                    reloadIdx=False,
                )
                variable = str(variable)
                project.set_Controls(
                    "parmMin", float(value) - args.delta, variable=variable
                )
                project.set_Controls(
                    "parmMax", float(value) + args.delta, variable=variable
                )

    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.set_Controls("cycles", 10)
    project.save()
    project.do_refinements([{}])
    # GSAS-II clips and freezes any coordinate that crosses a limit after a
    # cycle. A second pass is needed so the saved profile is recalculated at
    # the clipped physical coordinate rather than at the rejected trial value.
    project.do_refinements([{}])
    project.save()

    result = {
        "mode": args.mode,
        "selected": sorted(selected),
        "wR_before": before,
        "wR_after": float(hist.residuals["wR"]),
        "fractions": hist.ComputeMassFracs(),
        "atoms": {},
    }
    for phase in project.phases():
        result["atoms"][phase.name] = [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": [float(value) for value in atom.coordinates],
                "uiso_or_uaniso": atom.ADP,
            }
            for atom in phase.atoms()
        ]
        phase.export_CIF(
            args.out.replace(".gpx", f"-{phase.name}.cif")
        )
    print(json.dumps(result, indent=2, default=str))


if __name__ == "__main__":
    main()
