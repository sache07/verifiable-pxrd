#!/usr/bin/env python3
"""Replay the accepted physical refinement and export the submission files."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("branches/aniso-MnWO4-010.gpx")
PROJECT = Path("final.gpx")


def as_float_dict(values):
    return {
        name: [float(value), float(esd)]
        for name, (value, esd) in values.items()
    }


def main():
    project = G2sc.G2Project(str(SOURCE), newgpx=str(PROJECT))
    histogram = project.histogram(0)

    # Coordinate refinement was completed in bounded stages. Keep those
    # accepted coordinates fixed for this replay and remove stale limit flags.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "

    instrument = histogram.data["Instrument Parameters"][0]
    for name in ("U", "X", "SH/L"):
        instrument[name][2] = False

    sample = histogram.data["Sample Parameters"]
    sample["SurfRoughA"][1] = False

    # WO3 microstrain collapsed reproducibly to zero. Do not count a
    # boundary-clipped zero as an active parameter in the final replay.
    wo3_strain = project.phase("WO3").data["Histograms"][histogram.name][
        "Mustrain"
    ]
    wo3_strain[2][0] = False

    project.set_Frozen()
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-6
    project.set_Controls("cycles", 10)
    project.save()

    residual_history = [float(histogram.residuals["wR"])]
    for _ in range(3):
        project.do_refinements([{}])
        residual_history.append(float(histogram.residuals["wR"]))
    project.save()

    filenames = {
        "MnWO4": "MnWO4.cif",
        "Mn3WO6": "Mn3WO6.cif",
        "WO3": "WO3.cif",
    }
    for phase in project.phases():
        phase.export_CIF(filenames[phase.name])

    profile = histogram.data["data"][1]
    fit = np.column_stack(
        (profile[0], profile[1], profile[3], profile[1] - profile[3])
    )
    np.savetxt(
        "fit.csv",
        fit,
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    residuals = {
        key: float(histogram.residuals[key])
        for key in ("wR", "R", "wRb", "Rb", "wRmin", "Durbin-Watson")
        if key in histogram.residuals
    }
    summary = {
        "project": str(PROJECT),
        "histogram": histogram.name,
        "residual_history_Rwp_percent": residual_history,
        "residuals_percent_except_Durbin_Watson": residuals,
        "mass_fractions": as_float_dict(histogram.ComputeMassFracs()),
        "cells": {
            phase.name: {
                key: float(value) for key, value in phase.get_cell().items()
            }
            for phase in project.phases()
        },
        "phase_parameters": {},
        "instrument": {
            name: [float(value[1]), bool(value[2])]
            for name, value in instrument.items()
            if name not in ("Type",)
        },
        "sample": {
            name: [float(sample[name][0]), bool(sample[name][1])]
            for name in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "frozen": project.get_Frozen(),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        summary["phase_parameters"][phase.name] = {
            "scale": hap["Scale"],
            "size": hap["Size"],
            "microstrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    Path("final_summary.json").write_text(
        json.dumps(summary, indent=2, default=str) + "\n", encoding="utf-8"
    )
    print(json.dumps(summary, indent=2, default=str))


if __name__ == "__main__":
    main()
