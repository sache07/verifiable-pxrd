#!/usr/bin/env python3
"""Test one phase-wide, bounded isotropic displacement parameter."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", required=True)
    args = parser.parse_args()
    project = G2sc.G2Project(args.input, newgpx=args.out)
    hist = project.histogram(0)
    before = float(hist.residuals["wR"])
    selected = project.phase(args.phase)
    project.index_ids()
    variables = []
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
            if phase.name != args.phase or atom.adp_flag != "I":
                continue
            atom.refinement_flags = "U"
            variables.append(
                str(
                    project.make_var_obj(
                        phase=phase,
                        varname="AUiso",
                        atomId=atom,
                        reloadIdx=False,
                    )
                )
            )
    if len(variables) > 1:
        project.add_EquivConstr(variables, reloadIdx=False, override=True)
    for variable in variables:
        project.set_Controls("parmMin", 0.003, variable=variable)
        project.set_Controls("parmMax", 0.020, variable=variable)
        project.set_Frozen(variable=variable)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.set_Controls("cycles", 8)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    print(
        json.dumps(
            {
                "phase": args.phase,
                "wR_before": before,
                "wR_after": float(hist.residuals["wR"]),
                "uiso": {
                    atom.label: atom.uiso
                    for atom in selected.atoms()
                    if atom.adp_flag == "I"
                },
                "fractions": hist.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
