#!/usr/bin/env python3
"""Test one bounded March-Dollase texture term from a physical checkpoint."""

from __future__ import annotations

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", required=True, help="comma-separated h,k,l")
    args = parser.parse_args()
    axis = [int(item) for item in args.axis.split(",")]

    project = G2sc.G2Project(args.input, newgpx=args.out)
    hist = project.histogram(0)
    before = float(hist.residuals["wR"])
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        if phase.name == args.phase:
            po[0], po[1], po[2] = "MD", 1.0, True
            po[3] = axis
            project.set_Controls(
                "parmMin", 0.7, variable=f"{phase.id}:{hist.id}:MD"
            )
            project.set_Controls(
                "parmMax", 1.4, variable=f"{phase.id}:{hist.id}:MD"
            )
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.set_Controls("cycles", 7)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    phase = project.phase(args.phase)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    print(
        json.dumps(
            {
                "phase": args.phase,
                "axis": axis,
                "coefficient": float(po[1]),
                "wR_before": before,
                "wR_after": float(hist.residuals["wR"]),
                "fractions": hist.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
