#!/usr/bin/env python3
"""Refine optional (zero-allowed) isotropic microstrain for all phases."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    project = G2sc.G2Project(args.input, newgpx=args.out)
    hist = project.histogram(0)
    before = float(hist.residuals["wR"])
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        variable = f"{phase.id}:{hist.id}:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", 8000.0, variable=variable)
        project.set_Frozen(variable=variable)
        strain = phase.data["Histograms"][hist.name]["Mustrain"]
        strain[0] = "isotropic"
        strain[2][0] = True
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.set_Controls("cycles", 8)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    print(
        json.dumps(
            {
                "wR_before": before,
                "wR_after": float(hist.residuals["wR"]),
                "fractions": hist.ComputeMassFracs(),
                "microstrain": {
                    phase.name: phase.data["Histograms"][hist.name]["Mustrain"]
                    for phase in project.phases()
                },
                "frozen": project.get_Frozen(),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
