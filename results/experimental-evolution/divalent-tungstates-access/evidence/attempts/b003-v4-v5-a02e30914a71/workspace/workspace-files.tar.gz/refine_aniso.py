#!/usr/bin/env python3
"""Test one bounded uniaxial microstrain term."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--axis", required=True)
    args = parser.parse_args()
    axis = [int(item) for item in args.axis.split(",")]
    project = G2sc.G2Project(args.input, newgpx=args.out)
    hist = project.histogram(0)
    before = float(hist.residuals["wR"])
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        if phase.name != args.phase:
            continue
        strain = phase.data["Histograms"][hist.name]["Mustrain"]
        start = max(100.0, float(strain[1][0]))
        strain[0] = "uniaxial"
        strain[1][0] = start
        strain[1][1] = start
        strain[2][0] = True
        strain[2][1] = True
        strain[3] = axis
        for suffix in ("i", "a"):
            variable = f"{phase.id}:{hist.id}:Mustrain;{suffix}"
            project.set_Controls("parmMin", 0.0, variable=variable)
            project.set_Controls("parmMax", 8000.0, variable=variable)
            project.set_Frozen(variable=variable)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.set_Controls("cycles", 8)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    phase = project.phase(args.phase)
    strain = phase.data["Histograms"][hist.name]["Mustrain"]
    print(
        json.dumps(
            {
                "phase": args.phase,
                "axis": axis,
                "wR_before": before,
                "wR_after": float(hist.residuals["wR"]),
                "mustrain": strain,
                "fractions": hist.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
