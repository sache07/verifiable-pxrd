#!/usr/bin/env python3
"""Build comparable three-phase GSAS-II checkpoints for WO3 topology tests."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np

from GSASII import GSASIIfiles as G2fil
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def instrument_parameters():
    names = [
        "Type", "Lam1", "Lam2", "Zero", "I(L2)/I(L1)", "Polariz.",
        "U", "V", "W", "X", "Y", "Z", "SH/L", "Azimuth",
    ]
    values = [
        "PXC", 1.540598, 1.544426, 0.0, 0.5, 0.70,
        10.0, 0.0, 10.0, 1.0, 0.0, 0.0, 0.02, 0.0,
    ]
    return [G2fil.makeInstDict(names, values, [False] * len(names)), {}]


def configure_histogram(hist):
    sample = hist.data["Sample Parameters"]
    sample["Scale"] = [1.0, False]
    sample["Type"] = "Bragg-Brentano"
    sample.pop("Absorption", None)
    sample.pop("DisplaceX", None)
    sample.pop("DisplaceY", None)
    sample.update(
        {
            "Shift": [400.0, False],
            "Transparency": [0.0, False],
            "SurfRoughA": [0.0, False],
            "SurfRoughB": [0.0, False],
            "Gonio. radius": 200.0,
        }
    )
    # A low-order smooth background cannot absorb any diffraction peaks.
    hist.data["Background"][0] = [
        "chebyschev-1", False, 12, 3600.0, *([0.0] * 11)
    ]


def describe(project, label):
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    try:
        fracs = hist.ComputeMassFracs()
    except Exception:
        fracs = {}
    item = {
        "stage": label,
        "residuals": {
            key: float(value)
            for key, value in hist.residuals.items()
            if key in {"wR", "R", "wRb", "Rb", "wRmin"}
        },
        "fractions": {
            key: [float(value[0]), float(value[1])] for key, value in fracs.items()
        },
        "instrument": {
            key: float(inst[key][1])
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]
        },
        "sample": {
            key: float(sample[key][0])
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        item["phases"][phase.name] = {
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    print(json.dumps(item, indent=2, default=str), flush=True)
    return item


def checkpoint(project, output: Path, label: str):
    project.save()
    target = output.with_name(f"{output.stem}-{label}.gpx")
    shutil.copy2(output, target)


def refine_stage(project, output: Path, history: list, label: str, settings):
    project.do_refinements([settings])
    history.append(describe(project, label))
    checkpoint(project, output, label)


def set_bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", required=True, help="COD id for WO3 branch")
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    args = parser.parse_args()

    args.out.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(newgpx=str(args.out))
    hist = project.add_powder_histogram(
        args.pattern, instrument_parameters(), fmthint="comma"
    )
    configure_histogram(hist)

    source_ids = ["1520200", "2002703", args.wo3]
    names = ["MnWO4", "Mn3WO6", "WO3"]
    for cod_id, name in zip(source_ids, names):
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist]
        )
        phase.HAPvalue("Scale", 3.0)
        # Older WO3 records use zero displacement parameters; use a physical
        # starting value without changing source coordinates or occupancies.
        for atom in phase.atoms():
            if atom.adp_flag == "I" and atom.uiso <= 0:
                atom.uiso = 0.01

    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.set_Controls("cycles", 8)
    project.save()
    set_bound(project, ":0:Shift", -800.0, 800.0)
    set_bound(project, ":0:Polariz.", 0.5, 1.0)
    set_bound(project, ":0:U", 0.0, 40.0)
    set_bound(project, ":0:W", 2.0, 40.0)
    set_bound(project, ":0:X", 0.1, 6.0)
    set_bound(project, ":0:SH/L", 0.005, 0.10)
    for phase_id in range(3):
        set_bound(project, f"{phase_id}:0:Scale", 0.0, 1000.0)
        set_bound(project, f"{phase_id}:0:Size;i", 0.04, 1.5)
        set_bound(project, f"{phase_id}:0:Mustrain;i", 300.0, 8000.0)

    history = []
    refine_stage(
        project,
        args.out,
        history,
        "scale-bkg",
        {"set": {"Background": {"refine": True}, "Scale": True}},
    )
    refine_stage(
        project,
        args.out,
        history,
        "shift",
        {"set": {"Sample Parameters": ["Shift"]}},
    )
    refine_stage(
        project,
        args.out,
        history,
        "cells",
        {"set": {"Cell": True}},
    )
    refine_stage(
        project,
        args.out,
        history,
        "profile",
        {
            "set": {
                "Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]
            }
        },
    )
    refine_stage(
        project,
        args.out,
        history,
        "size",
        {
            "set": {
                "Size": {"type": "isotropic", "value": 1.0, "refine": True},
            }
        },
    )
    refine_stage(
        project,
        args.out,
        history,
        "mustrain",
        {"set": {"Mustrain": {"type": "isotropic", "refine": True}}},
    )

    with args.out.with_suffix(".history.json").open("w") as stream:
        json.dump(history, stream, indent=2)
    project.save()


if __name__ == "__main__":
    main()
