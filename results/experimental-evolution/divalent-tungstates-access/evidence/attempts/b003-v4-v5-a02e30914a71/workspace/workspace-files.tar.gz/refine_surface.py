#!/usr/bin/env python3
"""Test a bounded Suortti surface-roughness correction."""

import argparse
import json

from GSASII import GSASIIscriptable as G2sc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    project = G2sc.G2Project(args.input, newgpx=args.out)
    hist = project.histogram(0)
    before = float(hist.residuals["wR"])
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.20, True]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.set_Controls("cycles", 8)
    project.save()
    project.do_refinements([{}])
    project.do_refinements([{}])
    project.save()
    print(
        json.dumps(
            {
                "wR_before": before,
                "wR_after": float(hist.residuals["wR"]),
                "SurfRoughA": sample["SurfRoughA"],
                "SurfRoughB": sample["SurfRoughB"],
                "fractions": hist.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
            },
            indent=2,
            default=str,
        )
    )


if __name__ == "__main__":
    main()
