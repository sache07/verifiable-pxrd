#!/usr/bin/env python3
"""Test a phase-common isotropic displacement model for MnWO4."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("refinement/final_candidate_uiso.gpx")
OUTPUT = Path("uiso_tests/phase0_common_uiso_combined.gpx")


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    phase_index = 0
    phase = project.phases()[phase_index]
    atoms = phase.atoms()

    # GSAS-II offers no public isotropic/anisotropic conversion setter. The
    # flag and first ADP slot are the documented storage fields used by the
    # atom wrapper; unused anisotropic slots remain inert in isotropic mode.
    for atom in atoms:
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.010
        atom.refinement_flags = "U"
    variables = [f"{phase_index}::AUiso:{i}" for i in range(len(atoms))]
    project.save()
    project.add_EquivConstr(variables)
    for variable in variables:
        project.set_Controls("parmMin", 0.003, variable=variable)
        project.set_Controls("parmMax", 0.020, variable=variable)

    project.set_Controls("cycles", 20)
    history = []
    for iteration in range(1, 5):
        project.refine()
        project.save()
        cov = project.data["Covariance"]["data"]
        record = {
            "iteration": iteration,
            "rwp_percent": project.histogram(0).residuals.get("wR"),
            "rp_percent": project.histogram(0).residuals.get("R"),
            "gof": cov.get("Rvals", {}).get("GOF"),
            "message": cov.get("Rvals", {}).get("msg", ""),
            "uiso_A2": [atom.uiso for atom in phase.atoms()],
        }
        history.append(record)
        print(json.dumps(record))
    Path("uiso_tests/phase0_common_uiso_combined.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
