#!/usr/bin/env python3
"""Screen one March-Dollase phase/axis term at a time from a common checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


BASE = Path("refinement/physical_base.gpx")
OUT = Path("texture_tests")
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def prepare(project: G2.G2Project):
    histogram = project.histogram(0)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.getHAPvalues(histogram)
        if hap["Mustrain"][1][0] <= 1.0:
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2][0] = False
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    return histogram


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(exist_ok=True)
    results = []
    for phase_index in range(3):
        for axis in AXES:
            tag = f"phase{phase_index}_axis{axis[0]}{axis[1]}{axis[2]}"
            output = OUT / f"{tag}.gpx"
            project = G2.G2Project(str(BASE), newgpx=str(output))
            histogram = prepare(project)
            hap = project.phases()[phase_index].getHAPvalues(histogram)
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            variable = f"{phase_index}:0:MD"
            project.set_Controls("parmMin", 0.60, variable=variable)
            project.set_Controls("parmMax", 1.60, variable=variable)
            project.set_Controls("cycles", 14)
            project.refine()
            project.save()
            masses = np.array([p.data["General"]["Mass"] for p in project.phases()])
            scales = np.array(
                [p.getHAPvalues(histogram)["Scale"][0] for p in project.phases()]
            )
            fractions = masses * scales
            fractions /= fractions.sum()
            cov = project.data["Covariance"]["data"]
            vary = dict(zip(cov.get("varyList", []), zip(cov.get("variables", []), cov.get("sig", []))))
            result = {
                "phase_index": phase_index,
                "phase": project.phases()[phase_index].name,
                "axis": axis,
                "rwp_percent": histogram.residuals.get("wR"),
                "rp_percent": histogram.residuals.get("R"),
                "md_ratio": hap["Pref.Ori."][1],
                "md_esd": vary.get(variable, [None, None])[1],
                "fractions": fractions.tolist(),
                "message": cov.get("Rvals", {}).get("msg", ""),
                "gpx": str(output),
            }
            results.append(result)
            print(json.dumps(result))
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
