#!/usr/bin/env python3
"""Final-state sensitivity test for a trace Mn3O4 precursor phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("final.gpx")
CIF = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/9/00/19/9001963.cif"
)
OUT = Path("trace_tests_final")


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(exist_ok=True)
    results = []
    for start_fraction in (0.005, 0.02, 0.05):
        output = OUT / f"mn3o4_start_{start_fraction:.3f}.gpx"
        project = G2.G2Project(str(SOURCE), newgpx=str(output))
        histogram = project.histogram(0)
        phase = project.add_phase(
            str(CIF), phasename="Mn3O4_trace_test", histograms=[histogram]
        )
        project.data["Controls"]["data"]["parmFrozen"] = {}

        existing_mass_scale = sum(
            p.data["General"]["Mass"] * p.getHAPvalues(histogram)["Scale"][0]
            for p in project.phases()[:-1]
        )
        scale = (
            start_fraction
            / (1.0 - start_fraction)
            * existing_mass_scale
            / phase.data["General"]["Mass"]
        )
        hap = phase.getHAPvalues(histogram)
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.15
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        phase.data["General"]["Cell"][0] = True
        for atom in phase.atoms():
            atom.refinement_flags = " "

        project.set_Controls("parmMin", 0.0, variable="3:0:Scale")
        project.set_Controls("parmMax", 5.0, variable="3:0:Scale")
        project.set_Controls("parmMin", 0.02, variable="3:0:Size;i")
        project.set_Controls("parmMax", 5.0, variable="3:0:Size;i")
        project.set_Controls("cycles", 20)
        for _ in range(3):
            project.refine()
        project.save()

        cov = project.data["Covariance"]["data"]
        fractions = histogram.ComputeMassFracs()
        result = {
            "start_weight_fraction": start_fraction,
            "rwp_percent": histogram.residuals.get("wR"),
            "rp_percent": histogram.residuals.get("R"),
            "mn3o4_weight_fraction": fractions[phase.name][0],
            "mn3o4_weight_fraction_esd": fractions[phase.name][1],
            "mn3o4_scale": hap["Scale"][0],
            "mn3o4_size_um": hap["Size"][1][0],
            "mn3o4_cell": phase.get_cell(),
            "message": cov.get("Rvals", {}).get("msg", ""),
            "gpx": str(output),
        }
        results.append(result)
        print(json.dumps(result))
    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
