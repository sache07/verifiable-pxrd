#!/usr/bin/env python3
"""Refine heavy and then phase-limited oxygen coordinates with checkpoints."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def atom_snapshot(project: G2.G2Project) -> list[dict]:
    values = []
    for phase in project.phases():
        values.append(
            {
                "phase": phase.name,
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    return values


def clear_atom_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def save_stage(project: G2.G2Project, out_dir: Path, stage: str, history: list[dict]) -> None:
    project.save(str(out_dir / f"{stage}.gpx"))
    histogram = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    history.append(
        {
            "stage": stage,
            "rwp_percent": histogram.residuals.get("wR"),
            "rp_percent": histogram.residuals.get("R"),
            "gof": cov.get("Rvals", {}).get("GOF"),
            "message": cov.get("Rvals", {}).get("msg", ""),
            "vary_list": cov.get("varyList", []),
            "atoms": atom_snapshot(project),
        }
    )
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(out_dir / f"{stage}_phase{index}_{phase.name}.cif"))


def run(input_gpx: Path, out_dir: Path) -> None:
    G2.SetPrintLevel("warn")
    out_dir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(input_gpx), newgpx=str(out_dir / "coordinates.gpx"))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    # Boundary-collapsed strain terms are fixed before coordinates are introduced.
    for phase in project.phases():
        hap = phase.getHAPvalues(project.histogram(0))
        if hap["Mustrain"][1][0] <= 1.0 or hap["Mustrain"][1][0] >= 11999.0:
            hap["Mustrain"][2][0] = False
        if hap["Size"][1][0] <= 0.02001 or hap["Size"][1][0] >= 4.999:
            hap["Size"][2][0] = False

    history: list[dict] = []
    save_stage(project, out_dir, "stage0_profile", history)

    clear_atom_flags(project)
    for phase in project.phases():
        for atom in phase.atoms():
            if atom.element != "O":
                atom.refinement_flags = "X"
    project.set_Controls("cycles", 16)
    project.refine()
    save_stage(project, out_dir, "stage1_heavy", history)

    # Oxygen parameters are introduced one phase at a time so every step can be
    # screened and rolled back independently if geometry becomes nonphysical.
    for phase_index, phase in enumerate(project.phases()):
        clear_atom_flags(project)
        for atom in phase.atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
        project.set_Controls("cycles", 16)
        project.refine()
        save_stage(project, out_dir, f"stage{phase_index + 2}_oxygen_phase{phase_index}", history)

    clear_atom_flags(project)
    project.save(str(out_dir / "coordinates.gpx"))
    (out_dir / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(json.dumps(history[-1]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("out_dir", type=Path)
    args = parser.parse_args()
    run(args.input_gpx, args.out_dir)
