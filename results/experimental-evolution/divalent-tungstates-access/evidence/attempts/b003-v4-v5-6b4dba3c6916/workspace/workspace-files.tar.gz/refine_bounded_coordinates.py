#!/usr/bin/env python3
"""Coordinate refinement with Cartesian displacement bounds and replay checkpoints."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "


def set_coordinate_bounds(
    project: G2.G2Project, phase_index: int, atom_index: int, max_displacement_a: float
) -> None:
    phase = project.phases()[phase_index]
    atom = phase.atoms()[atom_index]
    cell = phase.get_cell()
    lengths = (cell["length_a"], cell["length_b"], cell["length_c"])
    for axis, length, center in zip("xyz", lengths, atom.coordinates):
        limit = max_displacement_a / length
        variable = f"{phase_index}::dA{axis}:{atom_index}"
        # Despite the historical dA variable name, GSAS-II applies these limits
        # to the absolute fractional coordinate, not a displacement from zero.
        project.set_Controls("parmMin", center - limit, variable=variable)
        project.set_Controls("parmMax", center + limit, variable=variable)


def snapshot(project: G2.G2Project, stage: str) -> dict:
    histogram = project.histogram(0)
    cov = project.data["Covariance"]["data"]
    return {
        "stage": stage,
        "rwp_percent": histogram.residuals.get("wR"),
        "rp_percent": histogram.residuals.get("R"),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "message": cov.get("Rvals", {}).get("msg", ""),
        "variables": dict(zip(cov.get("varyList", []), cov.get("variables", []))),
        "phases": [
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                    }
                    for atom in phase.atoms()
                ],
            }
            for phase in project.phases()
        ],
    }


def checkpoint(
    project: G2.G2Project, out_dir: Path, stage: str, history: list[dict]
) -> None:
    project.save()
    shutil.copy2(project.filename, out_dir / f"{stage}.gpx")
    history.append(snapshot(project, stage))
    for index, phase in enumerate(project.phases()):
        phase.export_CIF(str(out_dir / f"{stage}_phase{index}_{phase.name}.cif"))


def run(input_gpx: Path, out_dir: Path) -> None:
    G2.SetPrintLevel("warn")
    out_dir.mkdir(parents=True, exist_ok=True)
    main_gpx = out_dir / "bounded.gpx"
    project = G2.G2Project(str(input_gpx), newgpx=str(main_gpx))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    histogram = project.histogram(0)
    for phase in project.phases():
        hap = phase.getHAPvalues(histogram)
        if hap["Mustrain"][1][0] <= 1.0 or hap["Mustrain"][1][0] >= 11999.0:
            hap["Mustrain"][2][0] = False
        if hap["Size"][1][0] <= 0.02001 or hap["Size"][1][0] >= 4.999:
            hap["Size"][2][0] = False

    history: list[dict] = []
    project.save()
    checkpoint(project, out_dir, "stage0_profile", history)

    clear_flags(project)
    for phase_index, phase in enumerate(project.phases()):
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.element != "O":
                atom.refinement_flags = "X"
                set_coordinate_bounds(project, phase_index, atom_index, 0.06)
    project.set_Controls("cycles", 20)
    project.refine()
    checkpoint(project, out_dir, "stage1_heavy_bounded", history)

    for phase_index, phase in enumerate(project.phases()):
        clear_flags(project)
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.element == "O":
                atom.refinement_flags = "X"
                set_coordinate_bounds(project, phase_index, atom_index, 0.08)
        project.data["Controls"]["data"]["parmFrozen"] = {}
        project.set_Controls("cycles", 20)
        project.refine()
        checkpoint(
            project,
            out_dir,
            f"stage{phase_index + 2}_oxygen_phase{phase_index}_bounded",
            history,
        )

    clear_flags(project)
    project.save()
    (out_dir / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print(json.dumps(history[-1]))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("input_gpx", type=Path)
    parser.add_argument("out_dir", type=Path)
    args = parser.parse_args()
    run(args.input_gpx, args.out_dir)
