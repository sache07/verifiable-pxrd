#!/usr/bin/env python3
"""Converge the accepted physical model without changing its parameterization."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("anisotropy_tests/p0_axis010.gpx")
OUTPUT = Path("refinement/final_candidate.gpx")


def covariance_snapshot(project: G2.G2Project) -> tuple[dict[str, float], dict[str, float]]:
    cov = project.data["Covariance"]["data"]
    values = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
    sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
    return values, sigmas


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 20)

    history: list[dict] = []
    prior_values: dict[str, float] | None = None
    prior_rwp: float | None = None
    for iteration in range(1, 7):
        project.refine()
        project.save()
        values, sigmas = covariance_snapshot(project)
        rwp = float(project.histogram(0).residuals["wR"])
        if prior_values is None:
            max_step_esd = None
        else:
            standardized = [
                abs(values[name] - prior_values[name]) / sigmas[name]
                for name in values.keys() & prior_values.keys() & sigmas.keys()
                if sigmas[name] and sigmas[name] > 0
            ]
            max_step_esd = max(standardized, default=0.0)
        cov = project.data["Covariance"]["data"]
        record = {
            "iteration": iteration,
            "rwp_percent": rwp,
            "rp_percent": project.histogram(0).residuals.get("R"),
            "gof": cov.get("Rvals", {}).get("GOF"),
            "max_between_run_step_esd": max_step_esd,
            "message": cov.get("Rvals", {}).get("msg", ""),
        }
        history.append(record)
        print(json.dumps(record))
        if (
            prior_rwp is not None
            and abs(rwp - prior_rwp) < 1e-6
            and max_step_esd is not None
            and max_step_esd < 0.02
        ):
            break
        prior_values = values
        prior_rwp = rwp

    Path("refinement/final_candidate_convergence.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
