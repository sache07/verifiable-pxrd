#!/usr/bin/env python3
"""Screen one constrained, phase-common Uiso parameter at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BASE = Path("refinement/final_candidate.gpx")
OUT = Path("uiso_tests")


def main() -> None:
    G2.SetPrintLevel("warn")
    OUT.mkdir(exist_ok=True)
    results: list[dict] = []

    # MnWO4 (phase 0) contains published anisotropic displacement tensors.
    # Screen only phases for which every site already uses isotropic ADPs.
    for phase_index in (1, 2):
        output = OUT / f"phase{phase_index}_common_uiso.gpx"
        project = G2.G2Project(str(BASE), newgpx=str(output))
        project.data["Controls"]["data"]["parmFrozen"] = {}
        phase = project.phases()[phase_index]
        atoms = phase.atoms()
        if not all(atom.adp_flag == "I" for atom in atoms):
            raise RuntimeError(f"{phase.name} has non-isotropic ADPs")

        for atom in atoms:
            atom.uiso = 0.010
            atom.refinement_flags = "U"
        variables = [f"{phase_index}::AUiso:{i}" for i in range(len(atoms))]
        project.save()
        project.add_EquivConstr(variables)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)

        project.set_Controls("cycles", 20)
        for _ in range(3):
            project.refine()
        project.save()

        cov = project.data["Covariance"]["data"]
        varying = dict(zip(cov.get("varyList", []), cov.get("variables", [])))
        sigmas = dict(zip(cov.get("varyList", []), cov.get("sig", [])))
        uiso_variables = {
            name: {"value": varying[name], "esd": sigmas.get(name)}
            for name in varying
            if "AUiso" in name
        }
        result = {
            "phase_index": phase_index,
            "phase": phase.name,
            "rwp_percent": project.histogram(0).residuals.get("wR"),
            "rp_percent": project.histogram(0).residuals.get("R"),
            "uiso_A2": [atom.uiso for atom in phase.atoms()],
            "uiso_variables": uiso_variables,
            "message": cov.get("Rvals", {}).get("msg", ""),
            "gpx": str(output),
        }
        results.append(result)
        print(json.dumps(result))

    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
