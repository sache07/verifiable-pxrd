#!/usr/bin/env python3
"""Run a comparable staged GSAS-II screen for a three-phase candidate set."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(record_id: str) -> Path:
    return COD_ROOT / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def summarize(project: G2.G2Project, histogram, record_ids: list[str], stage: str) -> dict:
    masses = np.array([phase.data["General"]["Mass"] for phase in project.phases()])
    scales = np.array(
        [phase.getHAPvalues(histogram)["Scale"][0] for phase in project.phases()]
    )
    fractions = masses * scales
    fractions /= fractions.sum()
    result = {
        "stage": stage,
        "rwp_percent": histogram.residuals.get("wR"),
        "rp_percent": histogram.residuals.get("R"),
        "gof": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "record_ids": record_ids,
        "instrument": {
            key: histogram.InstrumentParameters[key][1]
            for key in ("Zero", "U", "V", "W", "X", "SH/L", "Polariz.")
        },
        "sample_shift_um": histogram.SampleParameters["Shift"][0],
        "phases": [],
        "messages": project.data["Covariance"]["data"].get("Rvals", {}).get("msg", ""),
    }
    for phase, record_id, fraction in zip(project.phases(), record_ids, fractions):
        hap = phase.getHAPvalues(histogram)
        result["phases"].append(
            {
                "name": phase.name,
                "record_id": record_id,
                "weight_fraction": float(fraction),
                "scale": hap["Scale"][0],
                "cell": phase.get_cell(),
                "size_um": hap["Size"][1][0],
                "microstrain_ppm": hap["Mustrain"][1][0],
            }
        )
    return result


def run(label: str, wo3_id: str, out_root: Path) -> None:
    G2.SetPrintLevel("warn")
    out_dir = out_root / label
    out_dir.mkdir(parents=True, exist_ok=True)
    final_path = out_dir / "profile.gpx"
    project = G2.G2Project(newgpx=str(final_path))
    records = ["1520200", "2002703", wo3_id]
    names = ["MnWO4_wolframite", "Mn3WO6_trigonal", f"WO3_{label}"]
    phases = [
        project.add_phase(str(cod_path(record)), phasename=name, fmthint="CIF")
        for name, record in zip(names, records)
    ]
    histogram = project.add_powder_histogram(
        "inputs/pattern.csv", "instrument.instprm", phases=phases
    )
    histogram.SampleParameters["Scale"][1] = False
    histogram.SampleParameters["Gonio. radius"] = 200.0
    histogram.SampleParameters["Shift"] = [800.0, True]
    histogram.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [3670.0, 20.0, -180.0, 160.0, -38.0, 19.0, -5.0, -89.0],
                "refine": True,
            }
        }
    )
    inst = histogram.InstrumentParameters
    for key, value, refine in (
        ("Zero", 0.20, True),
        ("U", 33.9, False),
        ("V", 0.0, False),
        ("W", 6.2, True),
        ("X", 1.46, False),
        ("SH/L", 0.02, False),
        ("Polariz.", 0.80, False),
    ):
        inst[key][1] = value
        inst[key][2] = refine

    # Start all branches at the same approximate phase inventory.
    target_fractions = np.array([0.64, 0.18, 0.18])
    common_scale = 135000.0
    for phase, fraction in zip(phases, target_fractions):
        mass = phase.data["General"]["Mass"]
        phase.getHAPvalues(histogram)["Scale"] = [common_scale * fraction / mass, True]

    for variable, lower, upper in (
        (":0:Zero", -0.35, 0.35),
        (":0:Shift", -1000.0, 1000.0),
        (":0:W", 0.1, 80.0),
    ):
        project.set_Controls("parmMin", lower, variable=variable)
        project.set_Controls("parmMax", upper, variable=variable)

    project.set_Controls("cycles", 10)
    project.refine()
    project.save(str(out_dir / "stage1_scale_background.gpx"))

    for phase in phases:
        phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 18)
    project.refine()
    project.save(str(out_dir / "stage2_cell_calibration.gpx"))

    initial_profiles = ((0.07, 300.0), (0.04, 100.0), (0.19, 5500.0))
    for index, (phase, (size, microstrain)) in enumerate(zip(phases, initial_profiles)):
        hap = phase.getHAPvalues(histogram)
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = microstrain
        hap["Mustrain"][2] = [True, False, False]
        for name, lower, upper in (
            ("Size;i", 0.02, 5.0),
            ("Mustrain;i", 0.0, 12000.0),
        ):
            variable = f"{index}:0:{name}"
            project.set_Controls("parmMin", lower, variable=variable)
            project.set_Controls("parmMax", upper, variable=variable)
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.set_Controls("cycles", 24)
    project.refine()
    project.save(str(final_path))

    summary = summarize(project, histogram, records, "profile")
    (out_dir / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("label")
    parser.add_argument("wo3_id")
    parser.add_argument("--out", default="branches")
    args = parser.parse_args()
    run(args.label, args.wo3_id, Path(args.out))
