#!/usr/bin/env python3
"""Add the second phase-common Uiso term after accepting WO3 Uiso."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


SOURCE = Path("uiso_tests/phase2_common_uiso.gpx")
OUTPUT = Path("refinement/final_candidate_uiso.gpx")


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.data["Controls"]["data"]["parmFrozen"] = {}

    phase_index = 1
    phase = project.phases()[phase_index]
    atoms = phase.atoms()
    for atom in atoms:
        atom.uiso = 0.010
        atom.refinement_flags = "U"
    variables = [f"{phase_index}::AUiso:{i}" for i in range(len(atoms))]
    project.save()
    project.add_EquivConstr(variables)
    for variable in variables:
        project.set_Controls("parmMin", 0.003, variable=variable)
        project.set_Controls("parmMax", 0.020, variable=variable)

    project.set_Controls("cycles", 20)
    history = []
    for iteration in range(1, 5):
        project.refine()
        project.save()
        cov = project.data["Covariance"]["data"]
        history.append(
            {
                "iteration": iteration,
                "rwp_percent": project.histogram(0).residuals.get("wR"),
                "rp_percent": project.histogram(0).residuals.get("R"),
                "gof": cov.get("Rvals", {}).get("GOF"),
                "message": cov.get("Rvals", {}).get("msg", ""),
            }
        )
        print(json.dumps(history[-1]))
    Path("refinement/final_candidate_uiso_convergence.json").write_text(
        json.dumps(history, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
