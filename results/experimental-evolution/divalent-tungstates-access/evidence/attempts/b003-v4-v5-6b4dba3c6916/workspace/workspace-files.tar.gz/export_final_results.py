#!/usr/bin/env python3
"""Create the requested deliverables from the accepted GSAS-II checkpoint."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = Path("refinement/final_candidate_uiso.gpx")
FINAL = Path("final.gpx")

PHASE_METADATA = [
    {
        "project_name": "MnWO4_wolframite",
        "name": "manganese tungstate (wolframite)",
        "formula": "MnWO4",
        "space_group": "P 2/c",
        "cif_path": "phase_1_MnWO4.cif",
        "reference": "COD 1520200",
    },
    {
        "project_name": "Mn3WO6_trigonal",
        "name": "trimanganese tungsten oxide",
        "formula": "Mn3WO6",
        "space_group": "R -3",
        "cif_path": "phase_2_Mn3WO6.cif",
        "reference": "COD 2002703",
    },
    {
        "project_name": "WO3_monoclinic_neutron",
        "name": "tungsten trioxide (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phase_3_WO3.cif",
        "reference": "COD 2311041",
    },
]


def cell_record(phase: G2.G2Phase) -> dict[str, float]:
    cell = phase.get_cell()
    return {
        "a_A": float(cell["length_a"]),
        "b_A": float(cell["length_b"]),
        "c_A": float(cell["length_c"]),
        "alpha_deg": float(cell["angle_alpha"]),
        "beta_deg": float(cell["angle_beta"]),
        "gamma_deg": float(cell["angle_gamma"]),
        "volume_A3": float(cell["volume"]),
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(SOURCE), newgpx=str(FINAL))
    project.data["Controls"]["data"]["parmFrozen"] = {}
    project.save()

    histogram = project.histogram(0)
    phases = project.phases()
    if [phase.name for phase in phases] != [m["project_name"] for m in PHASE_METADATA]:
        raise RuntimeError("Unexpected final phase inventory or phase order")

    # Export the exact saved phase models used by the final project.
    for phase, metadata in zip(phases, PHASE_METADATA):
        phase.export_CIF(metadata["cif_path"])

    x, observed, weights, calculated, background, difference = np.asarray(
        histogram.data["data"][1]
    )
    public = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1, ndmin=2)
    if public.shape != (len(x), 2):
        raise RuntimeError("Final project does not span the complete observed grid")
    if not np.allclose(x, public[:, 0], rtol=0, atol=1e-8):
        raise RuntimeError("Final project angle grid differs from pattern.csv")
    if not np.allclose(observed, public[:, 1], rtol=0, atol=1e-8):
        raise RuntimeError("Final project observations differ from pattern.csv")
    if not np.allclose(difference, observed - calculated, rtol=0, atol=1e-9):
        raise RuntimeError("Stored GSAS-II difference array is inconsistent")
    if not np.isfinite(calculated).all() or np.any(calculated < 0):
        raise RuntimeError("Final calculated profile is nonfinite or negative")

    with Path("fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta", "observed", "calculated", "difference", "background"]
        )
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{float(value):.15g}" for value in row])

    mass_fractions = histogram.ComputeMassFracs()
    covariance = project.data["Covariance"]["data"]
    rvals = covariance.get("Rvals", {})
    instrument = histogram.data["Instrument Parameters"][0]
    sample = histogram.data["Sample Parameters"]

    phase_records = []
    for phase_index, (phase, metadata) in enumerate(zip(phases, PHASE_METADATA)):
        fraction, fraction_esd = mass_fractions[phase.name]
        phase_records.append(
            {
                "name": metadata["name"],
                "formula": metadata["formula"],
                "space_group": metadata["space_group"],
                "cif_path": metadata["cif_path"],
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(fraction_esd),
                "cell": cell_record(phase),
                "reference_parent": metadata["reference"],
                "bragg_Rf_percent": float(
                    histogram.residuals.get(f"{phase_index}:0:Rf", float("nan"))
                ),
            }
        )

    result = {
        "refinement_histogram": histogram.name,
        "phases": phase_records,
        "unresolved_components": [
            {
                "name": "possible trace Mn3O4",
                "status": "not reliably determined",
                "weight_fraction": None,
                "estimated_scale_test_weight_fraction": "approximately 0.008; not included in the normalized modeled-phase fractions",
                "reason": "its candidate reflections overlap the accepted phases and no unique coherent peak family is present",
            }
        ],
        "fit_statistics": {
            "Rwp_percent": float(histogram.residuals["wR"]),
            "Rp_percent": float(histogram.residuals["R"]),
            "Rexp_percent": float(histogram.residuals["wRmin"]),
            "goodness_of_fit": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "reduced_chi_square": float(rvals["GOF"]) ** 2,
            "observations": int(rvals["Nobs"]),
            "refined_variables": int(rvals["Nvars"]),
            "weighting": "Poisson, w=1/max(observed_counts,1)",
        },
        "calibration": {
            "zero_shift_deg": float(instrument["Zero"][1]),
            "specimen_displacement_um": float(sample["Shift"][0]),
            "goniometer_radius_mm": float(sample["Gonio. radius"]),
            "polarization_fraction": float(instrument["Polariz."][1]),
        },
        "notes": "Weight fractions are normalized over the three modeled crystalline phases; formal e.s.d. values do not include phase-model or preferred-orientation systematics.",
    }
    Path("result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    # Independent consistency check against the exported table.
    rwp = 100 * np.sqrt(
        np.sum(weights * (observed - calculated) ** 2)
        / np.sum(weights * observed**2)
    )
    if abs(rwp - result["fit_statistics"]["Rwp_percent"]) > 1e-9:
        raise RuntimeError("fit.csv and final.gpx Rwp values differ")
    if abs(sum(row["weight_fraction"] for row in phase_records) - 1.0) > 1e-10:
        raise RuntimeError("Exported modeled-phase fractions are not normalized")

    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
