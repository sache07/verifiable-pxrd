#!/usr/bin/env python3
"""Scan the laboratory's allowed March-Dollase axes for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--cycles", type=int, default=3)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []

    for axis in AXES:
        G2.SetPrintLevel("warn")
        tag = "".join(str(v) for v in axis)
        output = args.output_dir / f"{args.phase}_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(args.input.resolve()))
        project.filename = str(output.resolve())
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        hist = project.histogram(0)
        hist.clear_refinements(
            {
                "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
                "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            }
        )
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": False},
                    "Mustrain": {"type": "isotropic", "refine": False},
                    "Pref.Ori.": False,
                },
                [hist],
            )
            hap = phase.getHAPvalues(hist)
            hap["Pref.Ori."][1] = 1.0
        target = project.phase(args.phase)
        hap = target.getHAPvalues(hist)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.index_ids()
        variable = f"{target.id}:0:MD"
        project.set_Controls("parmMin", 0.7, variable)
        project.set_Controls("parmMax", 1.4, variable)
        project.refine(makeBack=False)
        hap["Pref.Ori."][2] = False
        project.set_Frozen()
        project.set_Controls("cycles", 0)
        project.refine(makeBack=False)
        project.save(str(output.resolve()))
        row = {
            "axis": axis,
            "ratio": hap["Pref.Ori."][1],
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "output": str(output),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (args.output_dir / f"{args.phase}.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
