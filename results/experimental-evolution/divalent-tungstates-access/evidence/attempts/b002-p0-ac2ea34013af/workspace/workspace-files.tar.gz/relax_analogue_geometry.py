#!/usr/bin/env python3
"""Regularize analogue oxygen positions while retaining the refined cation net."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifFile, str2float
from scipy.optimize import least_squares


def values(block, key: str) -> list[str]:
    value = block.data[key]
    return value if isinstance(value, list) else [value]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--component-A", type=float, default=0.50)
    parser.add_argument("--coordinate-sigma-A", type=float, default=0.25)
    parser.add_argument("--max-nfev", type=int, default=180)
    args = parser.parse_args()

    cif = CifFile.from_file(args.input)
    block = next(iter(cif.data.values()))
    labels = values(block, "_atom_site_label")
    species = values(block, "_atom_site_type_symbol")
    coords = np.column_stack(
        [
            [str2float(x) for x in values(block, key)]
            for key in (
                "_atom_site_fract_x",
                "_atom_site_fract_y",
                "_atom_site_fract_z",
            )
        ]
    )
    lattice = Lattice.from_parameters(
        *[
            str2float(block.data[key])
            for key in (
                "_cell_length_a",
                "_cell_length_b",
                "_cell_length_c",
                "_cell_angle_alpha",
                "_cell_angle_beta",
                "_cell_angle_gamma",
            )
        ]
    )
    space_group = str(block.data["_symmetry_space_group_name_H-M"]).strip(" '\"")
    oxygen = np.array([i for i, element in enumerate(species) if element == "O"])
    start = coords[oxygen].copy()
    lengths = np.asarray(lattice.abc)
    widths = args.component_A / lengths

    def structure(vector: np.ndarray) -> Structure:
        trial = coords.copy()
        trial[oxygen] = vector.reshape((-1, 3))
        return Structure.from_spacegroup(space_group, lattice, species, trial)

    def residual(vector: np.ndarray) -> np.ndarray:
        expanded = structure(vector)
        elements = np.asarray([site.specie.symbol for site in expanded])
        distances = expanded.distance_matrix
        oi = np.flatnonzero(elements == "O")
        mni = np.flatnonzero(elements == "Mn")
        wi = np.flatnonzero(elements == "W")
        # The analogue is an octahedral framework. Broad distance targets
        # regularize it without pretending that all individual bonds are known.
        mn_o = np.sort(distances[np.ix_(mni, oi)], axis=1)[:, :6]
        w_o = np.sort(distances[np.ix_(wi, oi)], axis=1)[:, :6]
        oo = distances[np.ix_(oi, oi)]
        oo = oo[np.triu_indices(len(oi), 1)]
        displacement = (vector.reshape((-1, 3)) - start) @ lattice.matrix
        return np.concatenate(
            [
                ((mn_o - 2.15) / 0.16).ravel(),
                ((w_o - 1.92) / 0.14).ravel(),
                np.maximum(0.0, 2.20 - oo) / 0.04,
                (displacement / args.coordinate_sigma_A).ravel(),
            ]
        )

    x0 = start.ravel()
    lower = (start - widths).ravel()
    upper = (start + widths).ravel()
    before = residual(x0)
    result = least_squares(
        residual,
        x0,
        bounds=(lower, upper),
        max_nfev=args.max_nfev,
        verbose=1,
        x_scale="jac",
    )
    optimized = result.x.reshape((-1, 3))
    final_structure = structure(result.x)
    elements = np.asarray([site.specie.symbol for site in final_structure])
    dm = final_structure.distance_matrix

    def minimum(a: str, b: str) -> float:
        ia, ib = np.flatnonzero(elements == a), np.flatnonzero(elements == b)
        matrix = dm[np.ix_(ia, ib)]
        if a == b:
            matrix = matrix[np.triu_indices(len(ia), 1)]
        return float(np.min(matrix))

    payload = {
        "success": bool(result.success),
        "message": result.message,
        "nfev": result.nfev,
        "initial_cost": float(0.5 * before @ before),
        "final_cost": float(result.cost),
        "minimum_distances_A": {
            "Mn-O": minimum("Mn", "O"),
            "W-O": minimum("W", "O"),
            "O-O": minimum("O", "O"),
        },
        "coordinates": [
            {"label": labels[index], "xyz": xyz.tolist()}
            for index, xyz in zip(oxygen, optimized)
        ],
    }
    args.output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({key: payload[key] for key in payload if key != "coordinates"}))


if __name__ == "__main__":
    main()
