#!/usr/bin/env python3
"""Refine physically bounded profile and specimen terms in GSAS-II."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][:2],
                "strain": hap["Mustrain"][1][:2],
                "orientation": hap["Pref.Ori."][:4],
            }
        )
    return {
        "stage": stage,
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": {
            key: value[0] if isinstance(value, list) else value
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
        "phases": phases,
        "frozen": project.get_Frozen(),
    }


def refine(project: G2.G2Project, stage: str, rows: list[dict], root: Path) -> None:
    project.refine(makeBack=False)
    row = snapshot(project, stage)
    rows.append(row)
    print(json.dumps(row, default=str), flush=True)
    project.save()
    shutil.copy2(project.filename, root.with_name(root.stem + f"_{stage}.gpx"))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=4)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    project.index_ids()
    hist = project.histogram(0)
    phases = project.phases()

    # Preserve the physically screened coordinates while profile terms are
    # determined. Start with indexed cells fixed, then release positions late.
    for phase in phases:
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )
    hist.clear_refinements(
        {
            "Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )

    for variable, low, high in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
    ]:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    for pindex, _phase in enumerate(phases):
        for variable, low, high in [
            (f"{pindex}:0:Size;i", 0.04, 1.5),
            (f"{pindex}:0:Mustrain;i", 0.0, 8000.0),
        ]:
            project.set_Controls("parmMin", low, variable)
            project.set_Controls("parmMax", high, variable)

    rows: list[dict] = []
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, "instrument_sizes", rows, args.output)

    project.set_Frozen()
    for phase in phases:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, "isotropic_strain", rows, args.output)

    project.set_Frozen()
    hist.set_refinements(
        {
            "Instrument Parameters": ["Zero", "Polariz."],
            "Sample Parameters": ["Shift"],
        }
    )
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "positions_polarization", rows, args.output)

    project.set_Frozen()
    refine(project, "joint_profile", rows, args.output)
    project.save(str(args.output.resolve()))
    args.output.with_suffix(".profile.json").write_text(
        json.dumps(rows, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
