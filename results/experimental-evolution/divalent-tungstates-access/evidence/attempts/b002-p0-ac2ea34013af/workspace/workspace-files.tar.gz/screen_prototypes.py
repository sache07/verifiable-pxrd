#!/usr/bin/env python3
"""Rank oxide structure prototypes against the unmodeled PXRD residual peaks."""

from __future__ import annotations

import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/index.json.gz"
)
CIFS = INDEX.with_name("cif")
PROFILE = Path(".tmp/fit2/profile.csv")
CORE = np.array([19.8462, 20.4004, 35.1135, 45.6756, 46.4906,
                 56.4551, 59.3347, 66.4087, 70.1685])


def family_and_mapping(formula: str):
    comp = Composition(formula).reduced_composition.get_el_amt_dict()
    if len(comp) != 3 or "O" not in comp:
        return None
    cats = [(el, round(v, 6)) for el, v in comp.items() if el != "O"]
    vals = sorted(v for _, v in cats)
    oxygen = round(comp["O"], 6)
    if vals == [1, 2] and oxygen == 5:
        family = "A2BO5"
        mapping = {el: ("Mn" if v == 2 else "W") for el, v in cats}
    elif vals == [1, 3] and oxygen == 6:
        family = "A3BO6"
        mapping = {el: ("Mn" if v == 3 else "W") for el, v in cats}
    elif vals == [1, 2] and oxygen == 7:
        family = "AB2O7"
        mapping = {el: ("W" if v == 2 else "Mn") for el, v in cats}
    else:
        return None
    return family, mapping


def transformed_positions(pos: np.ndarray, scale: float, zero: float = 0.0):
    arg = np.sin(np.deg2rad(pos / 2.0)) / scale
    if np.any(arg >= 1):
        return np.full_like(pos, 200.0)
    return np.rad2deg(2.0 * np.arcsin(arg)) + zero


def main():
    x, observed, calculated, background, residual = np.loadtxt(
        PROFILE, delimiter=",", skiprows=1
    ).T
    smooth = gaussian_filter1d(residual, 2)
    pks, props = find_peaks(smooth, prominence=120, distance=7, height=80)
    order = np.argsort(props["prominences"])[::-1][:80]
    target_pos = x[pks[order]]
    target_w = props["prominences"][order]
    target_w /= target_w.sum()

    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    candidates = []
    seen = set()
    for rows in index.values():
        for formula, ident, sg, quality in rows:
            if ident in seen:
                continue
            try:
                item = family_and_mapping(formula)
            except Exception:
                continue
            if item:
                candidates.append((ident, formula, sg, quality, *item))
                seen.add(ident)

    calc = XRDCalculator(wavelength=1.540598)
    scales = np.linspace(0.80, 1.20, 321)
    results = []
    warnings.filterwarnings("ignore")
    for count, (ident, formula, sg, quality, family, mapping) in enumerate(candidates, 1):
        path = CIFS / ident[0] / ident[1:3] / ident[3:5] / f"{ident}.cif"
        try:
            structures = CifParser(
                path, occupancy_tolerance=1.0, site_tolerance=1e-5,
                frac_tolerance=0,
            ).parse_structures(primitive=False, on_error="raise")
            if len(structures) != 1 or len(structures[0]) > 300:
                continue
            structure = structures[0]
            structure.remove_oxidation_states()
            structure.replace_species(mapping)
            pattern = calc.get_pattern(structure, two_theta_range=(9, 105), scaled=True)
            pos = np.asarray(pattern.x)
            inten = np.asarray(pattern.y)
            keep = inten >= 1.0
            pos, inten = pos[keep], inten[keep] / 100.0
            if len(pos) == 0:
                continue
        except Exception:
            continue

        best = None
        for scale in scales:
            pp = transformed_positions(pos, scale)
            # Broad residual-peak recall, weighted by the observed residual.
            dist = np.min(np.abs(target_pos[:, None] - pp[None, :]), axis=1)
            recall = float(np.sum(target_w * np.exp(-0.5 * (dist / 0.14) ** 2)))
            # Match the most diagnostic residual family independent of intensity.
            core_dist = np.min(np.abs(CORE[:, None] - pp[None, :]), axis=1)
            core = float(np.mean(np.exp(-0.5 * (core_dist / 0.16) ** 2)))
            # Penalize intense lines that are absent from the entire observed scan.
            obs_dist = np.min(np.abs(x[pks, None] - pp[None, :]), axis=0)
            precision = float(np.sum(inten * np.exp(-0.5 * (obs_dist / 0.18) ** 2)) / np.sum(inten))
            score = 0.45 * recall + 0.40 * core + 0.15 * precision
            if best is None or score > best[0]:
                best = (score, scale, recall, core, precision)
        results.append(
            dict(
                score=best[0], scale=best[1], residual_recall=best[2],
                core_match=best[3], precision=best[4], id=ident,
                formula=formula, family=family, space_group=sg,
                quality=quality, sites=len(structure), path=str(path),
            )
        )

    results.sort(key=lambda row: row["score"], reverse=True)
    Path(".tmp/prototype_screen.json").write_text(json.dumps(results, indent=2) + "\n")
    for row in results[:80]:
        print(json.dumps(row))


if __name__ == "__main__":
    main()
