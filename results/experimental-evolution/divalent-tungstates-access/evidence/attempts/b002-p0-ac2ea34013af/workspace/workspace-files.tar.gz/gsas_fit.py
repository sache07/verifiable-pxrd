#!/usr/bin/env python3
"""Build and refine a GSAS-II Rietveld model for the supplied PXRD scan.

Run this with the GSAS-II Python interpreter, not the general materials
environment. Phase arguments have the form NAME=path/to/model.cif.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def write_inputs(pattern: Path, work: Path) -> tuple[Path, Path]:
    data = np.loadtxt(pattern, delimiter=",", skiprows=1, ndmin=2)
    if data.shape[1] != 2:
        raise ValueError("pattern must contain two columns")
    x, y = data.T
    xye = work / "observed.xye"
    np.savetxt(
        xye,
        np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))),
        fmt=["%.8f", "%.8f", "%.10f"],
    )
    inst = work / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {
            key: val[1] if isinstance(val, list) and len(val) > 1 else val
            for key, val in hist.InstrumentParameters.items()
        },
        "sample": {
            key: val[0] if isinstance(val, list) and val else val
            for key, val in hist.SampleParameters.items()
            if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    print(json.dumps(result, default=str))
    return result


def refine(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    history.append(summarize(project, label))


def parse_phase(text: str) -> tuple[str, Path]:
    if "=" not in text:
        raise argparse.ArgumentTypeError("phase must be NAME=path.cif")
    name, path = text.split("=", 1)
    if not name or not Path(path).is_file():
        raise argparse.ArgumentTypeError(f"invalid phase specification: {text}")
    return name, Path(path).resolve()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", action="append", type=parse_phase, required=True)
    parser.add_argument("--background", type=int, default=12)
    parser.add_argument("--mode", choices=("basic", "profile"), default="profile")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    work = args.output.parent
    xye, inst = write_inputs(args.pattern.resolve(), work)
    project = G2.G2Project(newgpx=str(args.output.resolve()))
    phases = [
        project.add_phase(str(path), phasename=name, fmthint="CIF")
        for name, path in args.phase
    ]
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [float(np.loadtxt(args.pattern, delimiter=",", skiprows=1)[0, 0]),
                       float(np.loadtxt(args.pattern, delimiter=",", skiprows=1)[-1, 0])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background,
                "coeffs": [1200.0] + [0.0] * (args.background - 1),
                "refine": True,
            },
        }
    )
    # Positive, comparable starting scales; only their ratios matter.
    for phase in phases:
        hap = phase.getHAPvalues(hist)
        hap["Scale"] = [10.0, True]
        phase.setSampleProfile(hist, "size", "isotropic", 0.5)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 500.0)
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.set_Controls("cycles", 12)
    project.index_ids()
    # Keep profile and specimen terms inside the laboratory's physically
    # meaningful region. GSAS-II freezes a variable if a step reaches a bound.
    for variable, low, high in [
        (":0:Zero", -0.30, 0.30),
        (":0:Shift", -1000.0, 1000.0),
        (":0:U", 0.0, 60.0),
        (":0:W", 0.1, 60.0),
        (":0:X", 0.01, 10.0),
        (":0:SH/L", 0.002, 0.20),
    ]:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    for i, _phase in enumerate(phases):
        for variable, low, high in [
            (f"{i}:0:Scale", 0.0, 1.0e6),
            (f"{i}:0:Size;i", 0.02, 5.0),
            (f"{i}:0:Mustrain;i", 0.0, 15000.0),
        ]:
            project.set_Controls("parmMin", low, variable)
            project.set_Controls("parmMax", high, variable)
    history: list[dict] = []
    project.save()

    # Establish the linear parameters first.
    refine(project, "background_scales", history)

    # Correct peak positions in stages to reduce cell/zero/displacement correlation.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero", history)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells", history)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "cells_shift", history)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_zero", history)

    if args.mode == "profile":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        refine(project, "instrument_profile", history)
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                },
                [hist],
            )
        refine(project, "phase_sizes", history)
        for phase in phases:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
        refine(project, "phase_profiles", history)

    project.save()
    (work / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
