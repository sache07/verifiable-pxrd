#!/usr/bin/env python3
"""Freeze a selected GSAS-II model and export its exact phase CIFs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


CIF_NAMES = {
    "MnWO4": "phase_mnwo4.cif",
    "WO3": "phase_wo3.cif",
    "Mn3WO6": "phase_mn3wo6.cif",
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--summary", type=Path, default=Path(".tmp/final_summary.json"))
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    constraints = project.data["Constraints"]["data"]
    for key in ("Hist", "HAP", "Phase", "Global"):
        constraints[key] = []
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": [
                "U", "V", "W", "X", "Y", "Z", "SH/L", "Zero", "Polariz."
            ],
            "Sample Parameters": [
                "Scale", "Shift", "Transparency", "Absorption", "SurfRoughA", "SurfRoughB"
            ],
        }
    )
    hist.Background[0][1] = False
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
        phase.set_HAP_refinements(
            {
                "Size": {"type": phase.getHAPvalues(hist)["Size"][0], "refine": False},
                "Mustrain": {
                    "type": phase.getHAPvalues(hist)["Mustrain"][0],
                    "refine": False,
                },
                "Pref.Ori.": False,
                "Extinction": False,
            },
            [hist],
        )
        hap = phase.getHAPvalues(hist)
        hap["Scale"][1] = False
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]
        hap["LeBail"] = False
        for value in hap.get("Babinet", {}).values():
            if isinstance(value, list) and len(value) > 1:
                value[1] = False

    project.refine(makeBack=False)
    project.save(str(args.output.resolve()))
    if set(CIF_NAMES) != {phase.name for phase in project.phases()}:
        raise ValueError("Unexpected final phase inventory")
    for phase in project.phases():
        phase.export_CIF(CIF_NAMES[phase.name])

    x, observed, _weights, calculated, background, difference = [
        np.asarray(v, dtype=float) for v in hist.data["data"][1]
    ]
    masses = np.array(
        [
            phase.getHAPvalues(hist)["Scale"][0] * phase.data["General"]["Mass"]
            for phase in project.phases()
        ],
        dtype=float,
    )
    fractions = masses / masses.sum()
    summary = {
        "histogram": hist.name,
        "residuals": hist.residuals,
        "points": len(x),
        "x_min": float(x[0]),
        "x_max": float(x[-1]),
        "minimum_calculated": float(calculated.min()),
        "maximum_cached_difference_mismatch": float(
            np.max(np.abs(difference - (observed - calculated)))
        ),
        "phases": [
            {
                "name": phase.name,
                "cif": CIF_NAMES[phase.name],
                "weight_fraction": float(fraction),
                "scale": float(phase.getHAPvalues(hist)["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "cell": phase.get_cell(),
            }
            for phase, fraction in zip(project.phases(), fractions)
        ],
    }
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary))


if __name__ == "__main__":
    main()
