#!/usr/bin/env python3
"""Add a candidate trace phase to an existing GSAS-II fit and test its scale."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def info(project: G2.G2Project, stage: str) -> None:
    hist = project.histogram(0)
    rows = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        rows.append(
            {
                "name": phase.name,
                "scale": hap["Scale"][0],
                "cell": phase.get_cell(),
                "size": hap["Size"][1][0],
                "strain": hap["Mustrain"][1][0],
            }
        )
    print(
        json.dumps(
            {"stage": stage, "residuals": hist.residuals, "phases": rows},
            default=str,
        ),
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    project.set_Controls("cycles", 4)
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )

    candidate = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = candidate.getHAPvalues(hist)
    hap["Scale"] = [0.5, True]
    candidate.setSampleProfile(hist, "size", "isotropic", 0.5)
    candidate.setSampleProfile(hist, "microstrain", "isotropic", 500.0)
    candidate.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    project.index_ids()
    pindex = candidate.id
    project.set_Controls("parmMin", 0.0, f"{pindex}:0:Scale")
    project.set_Controls("parmMax", 1e5, f"{pindex}:0:Scale")
    project.save()
    project.refine(makeBack=False)
    info(project, "scale")

    candidate.set_refinements({"Cell": True})
    project.refine(makeBack=False)
    info(project, "cell")

    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}, [hist]
    )
    project.set_Controls("parmMin", 0.04, f"{pindex}:0:Size;i")
    project.set_Controls("parmMax", 1.5, f"{pindex}:0:Size;i")
    project.refine(makeBack=False)
    info(project, "size")
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
