#!/usr/bin/env python3
"""Test the physically allowed Bragg-Brentano surface-roughness correction."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    project.data["Constraints"]["data"]["Phase"] = []
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
        phase.set_HAP_refinements(
            {
                "Size": {"type": phase.getHAPvalues(hist)["Size"][0], "refine": False},
                "Mustrain": {
                    "type": phase.getHAPvalues(hist)["Mustrain"][0],
                    "refine": False,
                },
                "Pref.Ori.": False,
            },
            [hist],
        )
    hist.SampleParameters["SurfRoughA"][0] = 0.20
    hist.SampleParameters["SurfRoughB"][0] = 0.10
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for variable, low, high in [
        (":0:SurfRoughA", 0.05, 0.60),
        (":0:SurfRoughB", 0.02, 0.50),
    ]:
        project.set_Controls("parmMin", low, variable)
        project.set_Controls("parmMax", high, variable)
    project.refine(makeBack=False)
    project.set_Frozen()
    project.refine(makeBack=False)
    hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save(str(args.output.resolve()))
    print(
        json.dumps(
            {
                "residuals": hist.residuals,
                "SurfRoughA": hist.SampleParameters["SurfRoughA"][0],
                "SurfRoughB": hist.SampleParameters["SurfRoughB"][0],
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
