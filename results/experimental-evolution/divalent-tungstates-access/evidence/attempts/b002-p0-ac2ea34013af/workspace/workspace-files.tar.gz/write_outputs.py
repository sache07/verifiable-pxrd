#!/usr/bin/env python3
"""Write the replayed profile and machine-readable final result."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


PHASE_DETAILS = {
    "MnWO4": {
        "display_name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "space_group": "P 2/c",
        "model_status": "reference-based Rietveld model",
    },
    "WO3": {
        "display_name": "WO3 (triclinic)",
        "formula": "WO3",
        "space_group": "P -1",
        "model_status": "reference-based Rietveld model",
    },
    "Mn3WO6": {
        "display_name": "Mn3WO6 (monoclinic analogue model)",
        "formula": "Mn3WO6",
        "space_group": "C 2/c",
        "model_status": "analogue-constrained; detailed atomic coordinates uncertain",
    },
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("prediction", type=Path)
    parser.add_argument("replay", type=Path)
    parser.add_argument("summary", type=Path)
    parser.add_argument("fit", type=Path, default=Path("fit.csv"))
    parser.add_argument("result", type=Path, default=Path("result.json"))
    args = parser.parse_args()

    replay = json.loads(args.replay.read_text())
    summary = json.loads(args.summary.read_text())
    if replay["status"] != "replayed":
        raise ValueError("Final project did not replay")
    with np.load(args.prediction, allow_pickle=False) as data:
        x = data["x"].copy()
        observed = data["observed"].copy()
        calculated = data["predicted"].copy()
    difference = observed - calculated
    np.savetxt(
        args.fit,
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.12g", "%.12g", "%.12g"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    rexp = float(summary["residuals"]["wRmin"])
    cells = {row["name"]: row["cell"] for row in summary["phases"]}
    cifs = {row["name"]: row["cif"] for row in summary["phases"]}
    phases = []
    for row in replay["phases"]:
        detail = PHASE_DETAILS[row["name"]]
        phases.append(
            {
                "name": detail["display_name"],
                "formula": detail["formula"],
                "space_group": detail["space_group"],
                "cif_path": cifs[row["name"]],
                "weight_fraction": row["weight_fraction"],
                "model_status": detail["model_status"],
                "refined_cell": cells[row["name"]],
            }
        )
    result = {
        "schema_version": 1,
        "project": "final.gpx",
        "refinement_histogram": replay["histogram"],
        "profile": "fit.csv",
        "fractions_basis": "normalized over the three modeled crystalline phases",
        "phases": phases,
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "r_expected_percent": rexp,
            "gof_rwp_over_rexp": rwp / rexp,
            "weighted_chi_square": chi_square,
            "n_points": int(len(x)),
            "weighting": "1/max(observed_counts, 1)",
            "profile_source": "zero-parameter native GSAS-II replay of final.gpx",
        },
        "project_replay": {
            "status": replay["status"],
            "project_sha256": replay["project_sha256"],
            "parameters_optimized": replay["parameters_optimized"],
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    args.result.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
