#!/usr/bin/env python3
"""Refine an analogue-derived phase with parent-centred coordinate bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("parent_project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=str, default="Mn3WO6")
    parser.add_argument("--component-A", type=float, default=0.15)
    parser.add_argument("--cycles", type=int, default=5)
    parser.add_argument("--metals-only", action="store_true")
    parser.add_argument("--oxygen-only", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    parent = G2.G2Project(gpxfile=str(args.parent_project.resolve()))
    project.filename = str(args.output.resolve())
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    hist = project.histogram(0)

    hist.clear_refinements(
        {
            "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )

    phase = project.phase(args.phase)
    source = parent.phase(args.phase)
    if phase is None or source is None or len(phase.atoms()) != len(source.atoms()):
        raise ValueError("phase/parent mismatch")
    pindex = phase.id
    cell = phase.get_cell()
    widths = [
        args.component_A / cell["length_a"],
        args.component_A / cell["length_b"],
        args.component_A / cell["length_c"],
    ]
    project.index_ids()
    for aindex, atom in enumerate(source.atoms()):
        for axis, value, width in zip("xyz", atom.coordinates, widths):
            variable = f"{pindex}::dA{axis}:{aindex}"
            project.set_Controls("parmMin", value - width, variable)
            project.set_Controls("parmMax", value + width, variable)

    selected = {
        a.label: "X"
        for a in phase.atoms()
        if (a.element == "O") == bool(args.oxygen_only)
    }
    phase.set_refinements({"Atoms": selected})
    project.refine(makeBack=False)
    print(
        json.dumps(
            {
                "stage": "oxygen" if args.oxygen_only else "metals",
                "residuals": hist.residuals,
                "frozen": project.get_Frozen(),
            },
            default=str,
        ),
        flush=True,
    )

    if args.metals_only or args.oxygen_only:
        phase.set_refinements({"Atoms": {"all": " "}})
        project.set_Frozen()
        project.set_Controls("cycles", 0)
        project.refine(makeBack=False)
        print(json.dumps({"stage": "replay", "residuals": hist.residuals}), flush=True)
        project.save(str(args.output.resolve()))
        return

    project.set_Frozen()
    phase.set_refinements({"Atoms": {"all": "X"}})
    project.refine(makeBack=False)
    print(
        json.dumps(
            {"stage": "all", "residuals": hist.residuals, "frozen": project.get_Frozen()},
            default=str,
        ),
        flush=True,
    )
    phase.set_refinements({"Atoms": {"all": " "}})
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    print(json.dumps({"stage": "replay", "residuals": hist.residuals}), flush=True)
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
