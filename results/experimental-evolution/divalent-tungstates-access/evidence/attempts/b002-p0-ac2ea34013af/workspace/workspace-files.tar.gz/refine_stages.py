#!/usr/bin/env python3
"""Continue a powder refinement in short, auditable GSAS-II stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def summary(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][:2],
                "size_refine": hap["Size"][2][:2],
                "mustrain": hap["Mustrain"][1][:2],
                "mustrain_refine": hap["Mustrain"][2][:2],
                "orientation": hap["Pref.Ori."][:4],
            }
        )
    return {
        "stage": stage,
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": {
            key: value[0] if isinstance(value, list) else value
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "SurfRoughA", "SurfRoughB"}
        },
        "phases": phases,
        "frozen": project.get_Frozen(),
    }


def run(project: G2.G2Project, stage: str, log: list[dict]) -> None:
    project.refine(makeBack=False)
    row = summary(project, stage)
    log.append(row)
    print(json.dumps(row, default=str), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=4)
    parser.add_argument(
        "--recipe",
        choices=("sizes", "strain", "coordinates", "uiso", "all"),
        default="sizes",
    )
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()
    log: list[dict] = []

    # Keep the short refinements well conditioned. Background, scale, cell,
    # zero and any already enabled atom flags remain active.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )

    if args.recipe in {"sizes", "all"}:
        for index, phase in enumerate(phases):
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}, [hist]
            )
            run(project, f"size_{phase.name}", log)
        # Correlation with the instrumental Lorentzian width is reduced after
        # the individual estimates have settled; release W and X together.
        hist.set_refinements({"Instrument Parameters": ["W", "X"]})
        project.set_Controls("parmMin", 2.0, ":0:W")
        project.set_Controls("parmMax", 40.0, ":0:W")
        project.set_Controls("parmMin", 0.1, ":0:X")
        project.set_Controls("parmMax", 6.0, ":0:X")
        run(project, "sizes_instrument", log)

    if args.recipe in {"strain", "all"}:
        for phase in phases:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
            run(project, f"strain_{phase.name}", log)

    if args.recipe in {"coordinates", "all"}:
        # Heavy-atom coordinates dominate Cu-radiation intensities. Refine one
        # phase at a time, metals first, then add oxygen coordinates.
        for phase in phases:
            metal = {a.label: "X" for a in phase.atoms() if a.element != "O"}
            phase.set_refinements({"Atoms": metal})
            run(project, f"metal_coordinates_{phase.name}", log)
            phase.set_refinements({"Atoms": {"all": "X"}})
            run(project, f"all_coordinates_{phase.name}", log)

    if args.recipe in {"uiso", "all"}:
        # This creates independent values, so use only a short final stage and
        # enforce the laboratory's documented isotropic-displacement range.
        project.index_ids()
        for pindex, phase in enumerate(phases):
            phase.set_refinements({"Atoms": {"all": "U"}})
            for aindex, _atom in enumerate(phase.atoms()):
                project.set_Controls("parmMin", 0.003, f"{pindex}::AUiso:{aindex}")
                project.set_Controls("parmMax", 0.020, f"{pindex}::AUiso:{aindex}")
            run(project, f"uiso_{phase.name}", log)

    project.save(str(args.output.resolve()))
    args.output.with_suffix(".stages.json").write_text(
        json.dumps(log, indent=2, default=str) + "\n"
    )


if __name__ == "__main__":
    main()
