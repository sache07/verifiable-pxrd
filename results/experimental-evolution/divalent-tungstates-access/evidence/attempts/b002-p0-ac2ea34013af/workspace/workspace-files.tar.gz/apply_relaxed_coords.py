#!/usr/bin/env python3
"""Apply geometry-regularized unique coordinates to a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("coordinates", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", default="Mn3WO6")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    payload = json.loads(args.coordinates.read_text())
    lookup = {row["label"]: row["xyz"] for row in payload["coordinates"]}
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    project.data["Constraints"]["data"]["Phase"] = []
    phase = project.phase(args.phase)
    for atom in phase.atoms():
        atom.refinement_flags = " "
        if atom.label in lookup:
            atom.coordinates = lookup[atom.label]
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save(str(args.output.resolve()))
    print(json.dumps({"residuals": project.histogram(0).residuals}))


if __name__ == "__main__":
    main()
