#!/usr/bin/env python3
"""Scan allowed uniaxial microstrain directions for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("phase")
    parser.add_argument("--cycles", type=int, default=4)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []

    for axis in AXES:
        G2.SetPrintLevel("warn")
        tag = "".join(str(v) for v in axis)
        output = args.output_dir / f"{args.phase}_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(args.input.resolve()))
        project.filename = str(output.resolve())
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        # The Uiso equivalences were useful during the preceding refinement,
        # but all atomic parameters are fixed in this profile scan.
        project.data["Constraints"]["data"]["Phase"] = []
        hist = project.histogram(0)
        hist.clear_refinements(
            {
                "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
                "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            }
        )
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": False},
                    "Mustrain": {"type": "isotropic", "refine": False},
                    "Pref.Ori.": False,
                },
                [hist],
            )

        target = project.phase(args.phase)
        hap = target.getHAPvalues(hist)
        equatorial = float(hap["Mustrain"][1][0])
        # Give the newly introduced axial term an interior starting value.
        axial = 4000.0 if equatorial <= 0.0 or equatorial >= 8000.0 else equatorial
        target.setSampleProfile(hist, "microstrain", "uniaxial", equatorial, axial, axis)
        # GSASIIscriptable's public helper currently rejects a list of both
        # uniaxial terms, so set the two documented refinement flags directly.
        hap = target.getHAPvalues(hist)
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        project.index_ids()
        for suffix in ("Mustrain;i", "Mustrain;a"):
            variable = f"{target.id}:0:{suffix}"
            project.set_Controls("parmMin", 0.0, variable)
            project.set_Controls("parmMax", 8000.0, variable)
        project.refine(makeBack=False)
        hap = target.getHAPvalues(hist)
        hap["Mustrain"][2][0] = False
        hap["Mustrain"][2][1] = False
        project.set_Frozen()
        project.set_Controls("cycles", 0)
        project.refine(makeBack=False)
        project.save(str(output.resolve()))
        row = {
            "axis": axis,
            "equatorial": hap["Mustrain"][1][0],
            "axial": hap["Mustrain"][1][1],
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "output": str(output),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (args.output_dir / f"{args.phase}.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
