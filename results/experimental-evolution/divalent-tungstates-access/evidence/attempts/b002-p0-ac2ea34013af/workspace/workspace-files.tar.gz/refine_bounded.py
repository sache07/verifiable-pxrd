#!/usr/bin/env python3
"""Bounded structural refinement from a stable indexed GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def record(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    return {
        "stage": stage,
        "wR": hist.residuals.get("wR"),
        "R": hist.residuals.get("R"),
        "Rf": {
            phase.name: hist.residuals.get(f"{phase.id}:0:Rf")
            for phase in project.phases()
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "frozen": project.get_Frozen(),
    }


def refine(project: G2.G2Project, stage: str, rows: list[dict]) -> None:
    project.refine(makeBack=False)
    row = record(project, stage)
    rows.append(row)
    print(json.dumps(row), flush=True)


def coordinate_bounds(project: G2.G2Project, cartesian_component_A: float) -> None:
    """Limit each fractional coordinate to a small component displacement."""
    project.index_ids()
    for pindex, phase in enumerate(project.phases()):
        cell = phase.get_cell()
        widths = [
            cartesian_component_A / cell["length_a"],
            cartesian_component_A / cell["length_b"],
            cartesian_component_A / cell["length_c"],
        ]
        for aindex, atom in enumerate(phase.atoms()):
            # GSAS-II varies coordinate shifts named dAx/dAy/dAz, but its
            # bound checker applies those limits to the resulting absolute
            # Ax/Ay/Az coordinate. Thus the lookup key is dA while the limits
            # are centred on the starting absolute coordinate.
            for axis, value, width in zip("xyz", atom.coordinates, widths):
                variable = f"{pindex}::dA{axis}:{aindex}"
                project.set_Controls("parmMin", value - width, variable)
                project.set_Controls("parmMax", value + width, variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--cycles", type=int, default=4)
    parser.add_argument("--coordinate-component-A", type=float, default=0.08)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    hist = project.histogram(0)
    phases = project.phases()

    # Hold peak locations and broadening at the stable indexed solution while
    # determining intensities. Scale/background remain active.
    hist.clear_refinements(
        {
            "Instrument Parameters": ["U", "W", "X", "Zero"],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in phases:
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
                "Pref.Ori.": False,
            },
            [hist],
        )
    coordinate_bounds(project, args.coordinate_component_A)

    rows: list[dict] = []
    for phase in phases:
        phase.set_refinements(
            {"Atoms": {a.label: "X" for a in phase.atoms() if a.element != "O"}}
        )
        refine(project, f"metal_{phase.name}", rows)
        phase.set_refinements(
            {"Atoms": {a.label: "X" for a in phase.atoms() if a.element == "O"}}
        )
        project.set_Frozen()
        refine(project, f"all_atoms_{phase.name}", rows)

    project.set_Frozen()
    refine(project, "joint_atoms", rows)
    project.save(str(args.output.resolve()))
    args.output.with_suffix(".bounded.json").write_text(
        json.dumps(rows, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
