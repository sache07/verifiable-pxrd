#!/usr/bin/env python3
"""Remove a rejected trace phase and refine one common Uiso per phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def remove_phase(project: G2.G2Project, name: str) -> None:
    if project.phase(name) is None:
        return
    del project.data["Phases"][name]
    for item in project.names:
        if item and item[0] == "Phases" and name in item:
            item.remove(name)
    for hist in project.histograms():
        hist.data.get("Reflection Lists", {}).pop(name, None)
    project.data["Restraints"]["data"].pop(name, None)
    project.update_ids()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--remove", default="Mn3O4")
    parser.add_argument("--cycles", type=int, default=5)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    remove_phase(project, args.remove)
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": "U"}, "Cell": False})
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )
    project.save()
    project.index_ids()
    for phase in project.phases():
        variables = [f"{phase.id}::AUiso:{i}" for i, _a in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable)
            project.set_Controls("parmMax", 0.020, variable)

    project.refine(makeBack=False)
    print(
        json.dumps(
            {
                "stage": "common_uiso",
                "residuals": hist.residuals,
                "uiso": {
                    ph.name: [a.uiso for a in ph.atoms()] for ph in project.phases()
                },
                "frozen": project.get_Frozen(),
            },
            default=str,
        ),
        flush=True,
    )
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save(str(args.output.resolve()))
    print(json.dumps({"stage": "replay", "residuals": hist.residuals}), flush=True)


if __name__ == "__main__":
    main()
