#!/usr/bin/env python3
"""Refine an analogue model while restraining its starting coordination."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIImath as G2mth
from GSASII import GSASIIlattice as G2lat


def initialize_restraints(phase: G2.G2Phase, weight: float, esd: float) -> int:
    data = phase.proj.data["Restraints"]["data"]
    data[phase.name] = {
        "Bond": {"wtFactor": float(weight), "Range": 1.3, "Bonds": [], "Use": True}
    }
    mn = [a for a in phase.atoms() if a.element == "Mn"]
    w = [a for a in phase.atoms() if a.element == "W"]
    oxy = [a for a in phase.atoms() if a.element == "O"]
    phase.addDistRestraint(mn, oxy, 2.15, factor=1.27, ESD=esd)
    phase.addDistRestraint(w, oxy, 1.90, factor=1.22, ESD=esd)

    # Preserve each individual starting distance rather than forcing all
    # octahedral bonds to one idealized value.
    general = phase.data["General"]
    cx, _ct, _cs, cia = general["AtomPtrs"]
    atoms = phase.data["Atoms"]
    lookup = G2mth.FillAtomLookUp(atoms, cia + 8)
    amat, _bmat = G2lat.cell2AB(general["Cell"][1:7])
    bonds = data[phase.name]["Bond"]["Bonds"]
    for bond in bonds:
        ids, ops = bond[0], bond[1]
        xyz = np.array([atoms[lookup[atom_id]][cx : cx + 3] for atom_id in ids])
        xyz = G2mth.getSyXYZ(xyz, ops, general["SGData"])
        bond[2] = float(G2mth.getRestDist(xyz, amat))
        bond[3] = float(esd)
    return len(bonds)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("parent_project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", default="Mn3WO6")
    parser.add_argument("--component-A", type=float, default=0.50)
    parser.add_argument("--weight", type=float, default=100.0)
    parser.add_argument("--esd", type=float, default=0.05)
    parser.add_argument("--cycles", type=int, default=5)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    parent = G2.G2Project(gpxfile=str(args.parent_project.resolve()))
    project.filename = str(args.output.resolve())
    project.set_Controls("cycles", args.cycles)
    project.set_Frozen()
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for ph in project.phases():
        ph.set_refinements({"Atoms": {"all": " "}, "Cell": False})
        ph.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": False},
                "Mustrain": {"type": "isotropic", "refine": False},
            },
            [hist],
        )

    phase = project.phase(args.phase)
    source = parent.phase(args.phase)
    pindex = phase.id
    cell = phase.get_cell()
    widths = [
        args.component_A / cell["length_a"],
        args.component_A / cell["length_b"],
        args.component_A / cell["length_c"],
    ]
    project.index_ids()
    for aindex, atom in enumerate(source.atoms()):
        for axis, value, width in zip("xyz", atom.coordinates, widths):
            var = f"{pindex}::dA{axis}:{aindex}"
            project.set_Controls("parmMin", value - width, var)
            project.set_Controls("parmMax", value + width, var)

    count = initialize_restraints(phase, args.weight, args.esd)
    phase.set_refinements({"Atoms": {"all": "X"}})
    project.save()
    project.refine(makeBack=False)
    print(
        json.dumps(
            {
                "stage": "restrained_coordinates",
                "bond_restraints": count,
                "residuals": hist.residuals,
                "frozen": project.get_Frozen(),
            },
            default=str,
        ),
        flush=True,
    )

    phase.set_refinements({"Atoms": {"all": " "}})
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    print(json.dumps({"stage": "replay", "residuals": hist.residuals}), flush=True)
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
