#!/usr/bin/env python3
"""Refine analogue oxygen positions with chemically broad bond restraints."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", default="Mn3WO6")
    parser.add_argument("--component-A", type=float, default=0.15)
    parser.add_argument("--weight", type=float, default=100.0)
    parser.add_argument("--esd", type=float, default=0.08)
    parser.add_argument("--cycles", type=int, default=8)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.input.resolve()))
    project.filename = str(args.output.resolve())
    project.data["Constraints"]["data"]["Phase"] = []
    project.set_Frozen()
    project.set_Controls("cycles", args.cycles)
    hist = project.histogram(0)
    hist.clear_refinements(
        {
            "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
        phase.set_HAP_refinements(
            {
                "Size": {"type": phase.getHAPvalues(hist)["Size"][0], "refine": False},
                "Mustrain": {
                    "type": phase.getHAPvalues(hist)["Mustrain"][0],
                    "refine": False,
                },
                "Pref.Ori.": False,
            },
            [hist],
        )

    phase = project.phase(args.phase)
    cell = phase.get_cell()
    widths = [
        args.component_A / cell["length_a"],
        args.component_A / cell["length_b"],
        args.component_A / cell["length_c"],
    ]
    project.index_ids()
    for aindex, atom in enumerate(phase.atoms()):
        for axis, value, width in zip("xyz", atom.coordinates, widths):
            variable = f"{phase.id}::dA{axis}:{aindex}"
            project.set_Controls("parmMin", value - width, variable)
            project.set_Controls("parmMax", value + width, variable)

    project.data["Restraints"]["data"][phase.name] = {
        "Bond": {"wtFactor": args.weight, "Range": 1.3, "Bonds": [], "Use": True}
    }
    manganese = [a for a in phase.atoms() if a.element == "Mn"]
    tungsten = [a for a in phase.atoms() if a.element == "W"]
    oxygen = [a for a in phase.atoms() if a.element == "O"]
    count = phase.addDistRestraint(manganese, oxygen, 2.10, factor=1.25, ESD=args.esd)
    count += phase.addDistRestraint(tungsten, oxygen, 1.90, factor=1.20, ESD=args.esd)
    phase.set_refinements({"Atoms": {a.label: "X" for a in oxygen}})
    project.refine(makeBack=False)

    phase.set_refinements({"Atoms": {"all": " "}})
    project.set_Frozen()
    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    project.save(str(args.output.resolve()))
    print(
        json.dumps(
            {
                "residuals": hist.residuals,
                "bond_restraints": count,
                "weight": args.weight,
                "esd": args.esd,
                "frozen": project.get_Frozen(),
            }
        ),
        flush=True,
    )


if __name__ == "__main__":
    main()
