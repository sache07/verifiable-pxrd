#!/usr/bin/env python3
"""Compare physically motivated Mn3WO6 coordinate variants in one profile model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("sources", nargs="+", type=Path)
    parser.add_argument("--phase", default="Mn3WO6")
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []

    variants = []
    for source_path in args.sources:
        variants.extend(
            [
                (source_path, "all"),
                (source_path, "oxygen"),
                (source_path, "metals"),
            ]
        )

    for source_path, mode in variants:
        G2.SetPrintLevel("warn")
        source = G2.G2Project(gpxfile=str(source_path.resolve()))
        project = G2.G2Project(gpxfile=str(args.base.resolve()))
        tag = source_path.stem + "_" + mode
        output = args.output_dir / f"{tag}.gpx"
        project.filename = str(output.resolve())
        project.data["Constraints"]["data"]["Phase"] = []
        project.set_Frozen()
        project.set_Controls("cycles", args.cycles)
        hist = project.histogram(0)
        hist.clear_refinements(
            {
                "Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."],
                "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
            }
        )
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": " "}, "Cell": False})
            phase.set_HAP_refinements(
                {
                    "Size": {"type": phase.getHAPvalues(hist)["Size"][0], "refine": False},
                    "Mustrain": {
                        "type": phase.getHAPvalues(hist)["Mustrain"][0],
                        "refine": False,
                    },
                    "Pref.Ori.": False,
                },
                [hist],
            )
        target = project.phase(args.phase)
        parent = source.phase(args.phase)
        if target is None or parent is None or len(target.atoms()) != len(parent.atoms()):
            raise ValueError(f"phase mismatch for {source_path}")
        for atom, old in zip(target.atoms(), parent.atoms()):
            if mode == "all" or (mode == "oxygen") == (atom.element == "O"):
                atom.coordinates = old.coordinates

        # Reoptimize only scales/background and the two established texture
        # amplitudes, not any structural or peak-position variables.
        for name in ("WO3", "Mn3WO6"):
            phase = project.phase(name)
            phase.getHAPvalues(hist)["Pref.Ori."][2] = True
            project.index_ids()
            variable = f"{phase.id}:0:MD"
            project.set_Controls("parmMin", 0.7, variable)
            project.set_Controls("parmMax", 1.4, variable)
        project.refine(makeBack=False)
        for phase in project.phases():
            phase.getHAPvalues(hist)["Pref.Ori."][2] = False
        project.set_Frozen()
        project.set_Controls("cycles", 0)
        project.refine(makeBack=False)
        project.save(str(output.resolve()))
        row = {
            "source": str(source_path),
            "mode": mode,
            "wR": hist.residuals.get("wR"),
            "R": hist.residuals.get("R"),
            "texture": {
                p.name: p.getHAPvalues(hist)["Pref.Ori."][1]
                for p in project.phases()
            },
            "output": str(output),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (args.output_dir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
