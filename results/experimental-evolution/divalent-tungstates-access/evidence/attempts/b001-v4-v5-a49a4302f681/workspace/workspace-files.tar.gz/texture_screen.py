#!/usr/bin/env python3
"""Screen the lab-supported March-Dollase axes one phase at a time."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "uiso_refinement" / "02_polarization.gpx"
WORK = ROOT / ".tmp" / "texture_screen"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    rows = []
    baseline = G2.G2Project(gpxfile=str(BASE))
    baseline_rwp = baseline.histogram(0).get_wR()
    phase_names = [phase.name for phase in baseline.phases()]

    for phase_index, phase_name in enumerate(phase_names):
        for axis in AXES:
            tag = "".join(str(v) for v in axis)
            target = WORK / f"p{phase_index}_{tag}.gpx"
            project = G2.G2Project(gpxfile=str(BASE))
            project.save(str(target))
            project.set_Controls("cycles", 12)
            project.set_Frozen()
            hist = project.histogram(0)
            for phase in project.phases():
                po = phase.data["Histograms"][hist.name]["Pref.Ori."]
                po[0] = "MD"
                po[1] = 1.0
                po[2] = False
            po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
            po[2] = True
            po[3] = list(axis)
            variable = f"{phase_index}:0:MD"
            project.set_Controls("parmMin", 0.7, variable)
            project.set_Controls("parmMax", 1.4, variable)
            project.refine(makeBack=False)
            cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            row = {
                "phase_index": phase_index,
                "phase": phase_name,
                "axis": list(axis),
                "march_dollase": po[1],
                "rwp": hist.get_wR(),
                "delta_rwp": hist.get_wR() - baseline_rwp,
                "converged": cov.get("converged"),
                "max_shift_over_sigma": cov.get("Max shft/sig"),
                "message": cov.get("msg", ""),
                "frozen": project.get_Frozen(),
                "project": str(target.relative_to(ROOT)),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
            (WORK / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
