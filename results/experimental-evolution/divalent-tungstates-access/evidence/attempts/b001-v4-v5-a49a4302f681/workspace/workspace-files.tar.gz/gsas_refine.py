#!/usr/bin/env python3
"""Build and iteratively refine a GSAS-II MnWO4 powder project.

This script is intentionally conservative: every refinement stage is saved,
reported, and can be inspected before more model complexity is introduced.
"""

from __future__ import annotations

import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
REFERENCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif/1/52/02/1520200.cif"
)
WORK = ROOT / ".tmp" / "mnwo4_refinement"
GPX = WORK / "working.gpx"


def instrument_text() -> str:
    return (
        "#GSAS-II instrument parameter file; do not add/delete items!\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.34;Polariz.:0.70;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def prepare_inputs() -> tuple[Path, Path]:
    WORK.mkdir(parents=True, exist_ok=True)
    x, y = np.loadtxt(PATTERN, delimiter=",", skiprows=1, unpack=True)
    # The supplied scan has counting-statistical weights but no explicit sigma.
    # Use sigma=sqrt(counts), which is also the evaluator's Rwp convention.
    xye = WORK / "observed.xye"
    np.savetxt(xye, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.10g")
    inst = WORK / "instrument.instprm"
    inst.write_text(instrument_text())
    return xye, inst


def normalize_adps(phase) -> None:
    """Match the frozen-library registration convention (isotropic Uiso=.005)."""
    _, _, _, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = 0.005


def build_project() -> tuple[G2.G2Project, object, object]:
    xye, inst = prepare_inputs()
    if GPX.exists():
        GPX.unlink()
    project = G2.G2Project(newgpx=str(GPX))
    phase = project.add_phase(str(REFERENCE), phasename="MnWO4_wolframite", fmthint="CIF")
    normalize_adps(phase)
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=[phase], fmthint="xye"
    )
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1500.0] + [0.0] * 11,
                "refine": False,
            },
        }
    )
    sample = hist.data["Sample Parameters"]
    sample["Type"] = "Bragg-Brentano"
    sample["Gonio. radius"] = 200.0
    sample["Scale"] = [1.0, False]
    sample["Shift"] = [0.0, False]
    sample["Transparency"] = [0.0, False]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    project.set_Controls("cycles", 8)
    project.save()
    return project, phase, hist


def finite(value) -> float | None:
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except Exception:
        return None


def state(project, phase, hist, label: str) -> dict:
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hist.name]
    atoms = []
    cx, ct, _, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atoms.append(
            {
                "label": atom[ct - 1],
                "element": atom[ct],
                "xyz": [float(v) for v in atom[cx : cx + 3]],
                "adp": atom[cia],
                "uiso": finite(atom[cia + 1]),
                "flags": atom[cx + 3],
            }
        )
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "instrument": {
            k: finite(v[1]) if isinstance(v, list) and len(v) > 1 else v
            for k, v in inst.items()
            if k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "sample": {
            k: finite(v[0]) if isinstance(v, list) else v
            for k, v in sample.items()
            if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"]
        },
        "hap": {
            "Scale": finite(hap["Scale"][0]),
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "Pref.Ori.": hap["Pref.Ori."],
        },
        "atoms": atoms,
        "varyList": [str(v) for v in covariance.get("varyList", [])],
        "variables": [finite(v) for v in covariance.get("variables", [])],
        "sig": [finite(v) for v in covariance.get("sig", [])],
        "Rvals": covariance.get("Rvals", {}),
    }
    print(json.dumps(result, indent=2, default=str))
    return result


def checkpoint(project, phase, hist, label: str, history: list[dict]) -> None:
    project.save()
    target = WORK / f"{label}.gpx"
    shutil.copy2(GPX, target)
    history.append(state(project, phase, hist, label))
    (WORK / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")


def run_refine(project, phase, hist, label: str, history: list[dict]) -> None:
    print(f"\n===== {label} =====")
    project.refine(makeBack=False)
    checkpoint(project, phase, hist, label, history)


def main() -> None:
    G2.SetPrintLevel("warn")
    project, phase, hist = build_project()
    history: list[dict] = []
    checkpoint(project, phase, hist, "00_initial", history)

    # Establish intensity scale and smooth background first.
    hist.set_refinements({"Background": True})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    run_refine(project, phase, hist, "01_scale_background", history)

    # Align the entire coherent reflection family with lattice and calibration.
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refine(project, phase, hist, "02_cell_zero", history)

    # Refine the common instrumental profile before specimen broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
    run_refine(project, phase, hist, "03_instrument_profile", history)

    # Add only isotropic specimen broadening terms at this checkpoint.
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    run_refine(project, phase, hist, "04_specimen_profile", history)


if __name__ == "__main__":
    main()
