#!/usr/bin/env python3
"""Refine the accepted three-phase model in conservative coordinate stages.

Every stage is saved independently so that a later coordinate block can be
discarded if it produces nonphysical geometry or an unstable least-squares
solution.
"""

from __future__ import annotations

import json
import math
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "final_refinement" / "01_geometry.gpx"
WORK = ROOT / ".tmp" / "coordinate_refinement"


def clean_name(name: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]+", "_", name)


def finite(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except Exception:
        return None


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    mass_scales = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        mass_scales.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": finite(hap["Scale"][0]),
                "size_um": finite(hap["Size"][1][0]),
                "microstrain": finite(hap["Mustrain"][1][0]),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": [finite(v) for v in atom.coordinates],
                        "flags": atom.refinement_flags,
                        "uiso": finite(atom.uiso),
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(mass_scales)
    for row, value in zip(phases, mass_scales):
        row["weight_fraction"] = value / total

    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": stage,
        "rwp": finite(hist.get_wR()),
        "residuals": hist.residuals,
        "instrument": {
            key: finite(inst[key][1])
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "SH/L"]
        },
        "sample": {
            key: finite(sample[key][0])
            for key in ["Shift", "SurfRoughA", "SurfRoughB"]
        },
        "phases": phases,
        "vary_list": [str(v) for v in covariance.get("varyList", [])],
        "sig": [finite(v) for v in covariance.get("sig", [])],
        "rvals": covariance.get("Rvals", {}),
    }
    print(json.dumps(result, default=str))
    return result


def save_stage(project: G2.G2Project, stage: str, history: list[dict]) -> None:
    target = WORK / f"{stage}.gpx"
    project.save(str(target))
    history.append(snapshot(project, stage))
    cif_dir = WORK / "cifs"
    cif_dir.mkdir(exist_ok=True)
    for phase in project.phases():
        phase.export_CIF(str(cif_dir / f"{stage}_{clean_name(phase.name)}.cif"))
    (WORK / "history.json").write_text(
        json.dumps(history, indent=2, default=str) + "\n"
    )


def refine_stage(project: G2.G2Project, stage: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    save_stage(project, stage, history)


def set_atom_flags(phase, labels: list[str], flags: str = "X") -> None:
    phase.set_refinements({"Atoms": {label: flags for label in labels}})


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.set_Controls("cycles", 14)
    phases = {phase.name: phase for phase in project.phases()}
    history: list[dict] = []
    save_stage(project, "01_geometry", history)

    # Heavy-atom coordinates carry the strongest intensity information.
    set_atom_flags(phases["MnWO4_wolframite"], ["W1"])
    set_atom_flags(phases["WO3_2311041"], ["W1", "W2"])
    refine_stage(project, "02_tungsten", history)

    set_atom_flags(phases["MnWO4_wolframite"], ["Mn1"])
    set_atom_flags(phases["Mn3WO6_R-3"], ["Mn0"])
    refine_stage(project, "03_manganese", history)

    # Add oxygen sublattices one phase at a time, preserving rollback points.
    set_atom_flags(phases["MnWO4_wolframite"], ["O1", "O2"])
    refine_stage(project, "04_oxygen_mnwo4", history)

    set_atom_flags(phases["Mn3WO6_R-3"], ["O3", "O4"])
    refine_stage(project, "05_oxygen_mn3wo6", history)

    set_atom_flags(
        phases["WO3_2311041"], ["O1", "O2", "O3", "O4", "O5", "O6"]
    )
    refine_stage(project, "06_oxygen_wo3", history)


if __name__ == "__main__":
    main()
