#!/usr/bin/env python3
"""Test bounded oxygen-coordinate refinements from the last physical checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
# Because GSAS-II writes a refinement into the currently named project before
# the explicit checkpoint save, this file contains the completed MnWO4 oxygen
# stage (the following filename contains the subsequent Mn3WO6 stage).
BASE = ROOT / ".tmp" / "coordinate_refinement" / "03_manganese.gpx"


def clear_atom_flags(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.set_refinements(
            {"Atoms": {atom.label: "" for atom in phase.atoms()}}
        )


def coordinate_limits(
    project: G2.G2Project, phase, labels: list[str], component_limit_A: float
) -> None:
    cell = phase.get_cell()
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    phase_index = [item.name for item in project.phases()].index(phase.name)
    for label in labels:
        atom = phase.atom(label)
        atom_index = [item.label for item in phase.atoms()].index(label)
        for axis, length, center in zip("xyz", lengths, atom.coordinates):
            # Despite the historical dA name, GSAS-II's coordinate variables
            # contain the absolute fractional coordinate, not an increment.
            variable = f"{phase_index}::dA{axis}:{atom_index}"
            bound = component_limit_A / length
            project.set_Controls("parmMin", center - bound, variable)
            project.set_Controls("parmMax", center + bound, variable)


def summary(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    result = {
        "stage": stage,
        "rwp": hist.get_wR(),
        "gof": project.data["Covariance"]["data"].get("Rvals", {}).get("GOF"),
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "atoms": {
                atom.label: [float(v) for v in atom.coordinates]
                for atom in phase.atoms()
            },
        }
    print(json.dumps(result))
    return result


def save_cifs(project: G2.G2Project, directory: Path, stage: str) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    for phase in project.phases():
        phase.export_CIF(str(directory / f"{stage}_{phase.name}.cif"))


def refine_group(
    project: G2.G2Project,
    phase_name: str,
    labels: list[str],
    component_limit_A: float,
    target: Path,
    stage: str,
) -> dict:
    clear_atom_flags(project)
    phase = project.phase(phase_name)
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})
    coordinate_limits(project, phase, labels, component_limit_A)
    project.refine(makeBack=False)
    project.save(str(target / f"{stage}.gpx"))
    save_cifs(project, target / "cifs", stage)
    return summary(project, stage)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--component-limit-A", type=float, required=True)
    args = parser.parse_args()
    if not 0.01 <= args.component_limit_A <= 0.15:
        raise ValueError("coordinate component limit must be 0.01--0.15 A")

    tag = f"{args.component_limit_A:.3f}".replace(".", "p")
    target = ROOT / ".tmp" / f"bounded_coordinates_abs_{tag}"
    target.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(target / "working.gpx"))
    project.set_Controls("cycles", 12)
    rows = [summary(project, "00_start")]

    rows.append(
        refine_group(
            project,
            "Mn3WO6_R-3",
            ["O3", "O4"],
            args.component_limit_A,
            target,
            "01_mn3wo6_oxygen",
        )
    )
    rows.append(
        refine_group(
            project,
            "WO3_2311041",
            ["O1", "O2", "O3", "O4", "O5", "O6"],
            args.component_limit_A,
            target,
            "02_wo3_oxygen",
        )
    )

    # Freeze coordinates at the accepted bounded values, clear stale limit
    # freezes, and reconverge only profile, scale, background and cell terms.
    clear_atom_flags(project)
    project.set_Frozen()
    project.refine(makeBack=False)
    project.save(str(target / "03_fixed_coordinates.gpx"))
    save_cifs(project, target / "cifs", "03_fixed_coordinates")
    rows.append(summary(project, "03_fixed_coordinates"))
    (target / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
