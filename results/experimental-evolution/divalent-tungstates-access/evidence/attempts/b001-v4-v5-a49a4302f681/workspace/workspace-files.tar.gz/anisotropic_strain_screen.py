#!/usr/bin/env python3
"""Screen lab-supported uniaxial microstrain axes phase by phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "texture_screen" / "p1_010.gpx"
WORK = ROOT / ".tmp" / "strain_screen"
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0)]


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    baseline_project = G2.G2Project(gpxfile=str(BASE))
    baseline = baseline_project.histogram(0).get_wR()
    names = [phase.name for phase in baseline_project.phases()]
    rows = []

    for phase_index, name in enumerate(names):
        for axis in AXES:
            tag = "".join(str(i) for i in axis)
            target = WORK / f"p{phase_index}_{tag}.gpx"
            project = G2.G2Project(gpxfile=str(BASE))
            project.save(str(target))
            project.set_Controls("cycles", 14)
            project.set_Frozen()
            hist = project.histogram(0)
            for phase in project.phases():
                strain = phase.data["Histograms"][hist.name]["Mustrain"]
                strain[2] = [False for _ in strain[2]]
            phase = project.phase(name)
            strain = phase.data["Histograms"][hist.name]["Mustrain"]
            start = strain[1][0]
            strain[0] = "uniaxial"
            strain[1][0] = start
            strain[1][1] = start
            strain[2][0] = True
            strain[2][1] = True
            strain[3] = list(axis)
            for variable in [
                f"{phase_index}:0:Mustrain;i",
                f"{phase_index}:0:Mustrain;a",
            ]:
                project.set_Controls("parmMin", 100.0, variable)
                project.set_Controls("parmMax", 16000.0, variable)
            project.refine(makeBack=False)
            cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            equatorial, axial = strain[1][:2]
            row = {
                "phase_index": phase_index,
                "phase": name,
                "axis": list(axis),
                "equatorial_microstrain": equatorial,
                "axial_microstrain": axial,
                "axial_ratio": axial / equatorial,
                "rwp": hist.get_wR(),
                "delta_rwp": hist.get_wR() - baseline,
                "converged": cov.get("converged"),
                "max_shift_over_sigma": cov.get("Max shft/sig"),
                "message": cov.get("msg", ""),
                "frozen": project.get_Frozen(),
                "project": str(target.relative_to(ROOT)),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
            (WORK / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
