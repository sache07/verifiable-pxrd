#!/usr/bin/env python3
"""Compare exact-composition WO3 references against the MnWO4 residual."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / ".tmp" / "wo3_comparison"
BASE = ROOT / ".tmp" / "mnwo4_refinement" / "02_cell_zero.gpx"
CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
CANDIDATES = ["2107312", "2311041", "1528915", "1010618", "2106293", "1563541"]


def cif_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def normalize_adps(phase) -> None:
    _, _, _, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = 0.005


def report(project, cod_id: str, stage: str) -> dict:
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][0],
                "mustrain": hap["Mustrain"][1][0],
            }
        )
    row = {
        "candidate": cod_id,
        "stage": stage,
        "rwp": hist.get_wR(),
        "phases": phases,
        "instrument": {
            k: v[1]
            for k, v in hist.data["Instrument Parameters"][0].items()
            if k in ["Zero", "U", "V", "W", "X", "SH/L"]
        },
    }
    print(json.dumps(row, default=str))
    return row


def refine(project, cod_id: str, stage: str, rows: list[dict]) -> None:
    project.refine(makeBack=False)
    rows.append(report(project, cod_id, stage))
    project.save(str(WORK / f"{cod_id}_{stage}.gpx"))


def run_candidate(cod_id: str) -> list[dict]:
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(WORK / f"{cod_id}_working.gpx"))
    hist = project.histogram(0)
    mnwo4 = project.phase(0)
    wo3 = project.add_phase(
        str(cif_path(cod_id)),
        phasename=f"WO3_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    normalize_adps(wo3)
    hap = wo3.data["Histograms"][hist.name]
    hap["Scale"] = [20.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1500.0
    hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("cycles", 10)
    rows: list[dict] = []

    # Existing MnWO4 scale/background/cell/zero remain active from the checkpoint.
    refine(project, cod_id, "01_scale", rows)
    wo3.set_refinements({"Cell": True})
    refine(project, cod_id, "02_cell", rows)

    # Model phase broadening with specimen terms while keeping the physical
    # common instrument profile fixed at this comparison checkpoint.
    for phase in [mnwo4, wo3]:
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, cod_id, "03_mustrain", rows)
    for phase in [mnwo4, wo3]:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.5, "refine": True}},
            [hist],
        )
    refine(project, cod_id, "04_size", rows)
    return rows


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    all_rows = []
    for cod_id in CANDIDATES:
        try:
            all_rows.extend(run_candidate(cod_id))
        except Exception as exc:
            row = {"candidate": cod_id, "error": repr(exc)}
            print(json.dumps(row))
            all_rows.append(row)
    (WORK / "comparison.json").write_text(json.dumps(all_rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
