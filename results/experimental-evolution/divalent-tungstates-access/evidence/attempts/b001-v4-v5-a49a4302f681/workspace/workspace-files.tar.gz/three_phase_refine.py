#!/usr/bin/env python3
"""Introduce indexed analogue-derived Mn3WO6 into the best two-phase project."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "wo3_comparison" / "2311041_04_size.gpx"
MODEL = ROOT / ".tmp" / "models" / "Mn3WO6_R-3_start.cif"
WORK = ROOT / ".tmp" / "three_phase"
GPX = WORK / "working.gpx"


def snapshot(project, stage: str) -> dict:
    hist = project.histogram(0)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][0],
                "mustrain": hap["Mustrain"][1][0],
            }
        )
    total = sum(masses)
    for phase, mass_scale in zip(phases, masses):
        phase["weight_fraction"] = mass_scale / total
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "stage": stage,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": {
            k: v[1]
            for k, v in inst.items()
            if k in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]
        },
        "phases": phases,
    }
    print(json.dumps(row, default=str))
    return row


def refine(project, stage: str, rows: list[dict]) -> None:
    project.refine(makeBack=False)
    rows.append(snapshot(project, stage))
    project.save(str(WORK / f"{stage}.gpx"))


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(GPX))
    hist = project.histogram(0)
    mn3wo6 = project.add_phase(
        str(MODEL), phasename="Mn3WO6_R-3", histograms=[hist], fmthint="CIF"
    )
    hap = mn3wo6.data["Histograms"][hist.name]
    hap["Scale"] = [15.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.12
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 5000.0
    hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("cycles", 12)
    rows = [snapshot(project, "00_added")]

    refine(project, "01_scale", rows)
    mn3wo6.set_refinements({"Cell": True})
    refine(project, "02_cell", rows)
    mn3wo6.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    refine(project, "03_mustrain", rows)
    mn3wo6.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.12, "refine": True}}, [hist]
    )
    refine(project, "04_size", rows)

    shutil.copy2(WORK / "04_size.gpx", WORK / "best.gpx")
    (WORK / "history.json").write_text(json.dumps(rows, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
