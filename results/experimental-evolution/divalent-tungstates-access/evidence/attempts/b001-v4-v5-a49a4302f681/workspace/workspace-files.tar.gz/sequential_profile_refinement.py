#!/usr/bin/env python3
"""Reconcile instrument and specimen widths without correlated joint fitting."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "profile_refinement" / "02_common_profile.gpx"
WORK = ROOT / ".tmp" / "sequential_profile"
WORKING = WORK / "working.gpx"


def set_hap_flags(project: G2.G2Project, size: bool, strain: bool) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = size
        hap["Mustrain"][2][0] = strain


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = []
    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        value = phase.data["General"]["Mass"] * hap["Scale"][0]
        mass_scales.append(value)
        phases.append(
            {
                "name": phase.name,
                "size_um": hap["Size"][1][0],
                "microstrain": hap["Mustrain"][1][0],
                "scale": hap["Scale"][0],
            }
        )
    total = sum(mass_scales)
    for phase, value in zip(phases, mass_scales):
        phase["weight_fraction"] = value / total
    row = {
        "stage": stage,
        "rwp": hist.get_wR(),
        "rp": hist.residuals.get("R"),
        "gof": cov.get("GOF"),
        "converged": cov.get("converged"),
        "max_shift_over_sigma": cov.get("Max shft/sig"),
        "message": cov.get("msg", ""),
        "instrument": {
            key: {"value": inst[key][1], "refine": bool(inst[key][2])}
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "phases": phases,
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(row))
    return row


def run(project: G2.G2Project, stage: str, rows: list[dict]) -> None:
    project.refine(makeBack=False)
    shutil.copy2(WORKING, WORK / f"{stage}.gpx")
    rows.append(state(project, stage))
    (WORK / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(WORKING))
    project.set_Controls("cycles", 16)
    project.set_Frozen()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    rows: list[dict] = []

    # X reached its physically allowed lower limit. Hold it there and obtain a
    # genuine stationary point for the remaining common terms.
    set_hap_flags(project, False, False)
    for key in ["U", "W", "SH/L"]:
        inst[key][2] = True
    inst["X"][2] = False
    run(project, "01_common_reconverged", rows)

    # Fit the two phase-profile components in separate blocks. Their joint
    # refinement is >90% correlated and gave a nonconverged, worse solution.
    for key in ["U", "W", "SH/L"]:
        inst[key][2] = False
    for phase_index in range(len(project.phases())):
        project.set_Controls("parmMin", 0.04, f"{phase_index}:0:Size;i")
        project.set_Controls("parmMax", 1.5, f"{phase_index}:0:Size;i")
        project.set_Controls("parmMin", 300.0, f"{phase_index}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{phase_index}:0:Mustrain;i")
    set_hap_flags(project, True, False)
    run(project, "02_sizes", rows)

    set_hap_flags(project, False, True)
    project.set_Frozen()
    run(project, "03_strains", rows)

    set_hap_flags(project, False, False)
    project.set_Frozen()
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    run(project, "04_polarization", rows)


if __name__ == "__main__":
    main()
