#!/usr/bin/env python3
"""Test the lab-supported Bragg-Brentano surface-roughness correction."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "texture_screen" / "p1_010.gpx"
WORK = ROOT / ".tmp" / "surface_roughness"
TARGET = WORK / "roughness.gpx"


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    baseline = project.histogram(0).get_wR()
    project.save(str(TARGET))
    project.set_Controls("cycles", 16)
    sample = project.histogram(0).data["Sample Parameters"]
    sample["SurfRoughA"] = [0.10, True]
    sample["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, ":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, ":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, ":0:SurfRoughB")
    project.refine(makeBack=False)
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "baseline_rwp": baseline,
        "rwp": hist.get_wR(),
        "delta_rwp": hist.get_wR() - baseline,
        "surface_roughness_A": sample["SurfRoughA"][0],
        "surface_roughness_B": sample["SurfRoughB"][0],
        "converged": cov.get("converged"),
        "max_shift_over_sigma": cov.get("Max shft/sig"),
        "message": cov.get("msg", ""),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result))
    (WORK / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
