#!/usr/bin/env python3
"""Create the final replayable project and all machine-readable deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "strain_screen" / "p2_010.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_OUTPUTS = {
    "MnWO4_wolframite": ("MnWO4", "phase_1_MnWO4.cif"),
    "WO3_2311041": ("WO3", "phase_2_WO3.cif"),
    "Mn3WO6_R-3": ("Mn3WO6", "phase_3_Mn3WO6.cif"),
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(BASE))

    # The tied Uiso values have already been refined and then fixed. Remove the
    # now-unused equivalence records so replay is quiet and self-contained.
    constraints = project.data["Constraints"]["data"]
    for key in ["Hist", "HAP", "Phase", "Global"]:
        constraints[key] = []
    for phase in project.phases():
        phase.set_refinements(
            {"Atoms": {atom.label: "" for atom in phase.atoms()}}
        )

    project.set_Frozen()
    project.set_Controls("cycles", 16)
    project.save(str(FINAL_GPX))
    project.refine(makeBack=False)
    project.save(str(FINAL_GPX))

    hist = project.histogram(0)
    profile = np.asarray(hist.data["data"][1], dtype=float)
    x, observed, _weight, calculated, _background, _residual = profile
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    mass_scales = []
    phase_rows = []
    for phase in project.phases():
        if phase.name not in PHASE_OUTPUTS:
            raise RuntimeError(f"Unexpected phase in final project: {phase.name}")
        display_name, cif_name = PHASE_OUTPUTS[phase.name]
        phase.export_CIF(str(ROOT / cif_name))
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        mass_scales.append(mass_scale)
        cell = phase.get_cell()
        phase_rows.append(
            {
                "name": display_name,
                "project_phase_name": phase.name,
                "formula": display_name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif": cif_name,
                "weight_fraction": None,
                "cell": {
                    "a_angstrom": cell["length_a"],
                    "b_angstrom": cell["length_b"],
                    "c_angstrom": cell["length_c"],
                    "alpha_deg": cell["angle_alpha"],
                    "beta_deg": cell["angle_beta"],
                    "gamma_deg": cell["angle_gamma"],
                    "volume_angstrom3": cell["volume"],
                },
            }
        )
    total = sum(mass_scales)
    for row, mass_scale in zip(phase_rows, mass_scales):
        row["weight_fraction"] = mass_scale / total

    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    result = {
        "schema_version": 1,
        "refinement_method": "GSAS-II Rietveld refinement",
        "project": "final.gpx",
        "refinement_histogram": hist.name,
        "profile": "fit.csv",
        "fractions_basis": "normalized over the modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": hist.get_wR(),
            "Rp_percent": hist.residuals.get("R"),
            "Rexp_percent": hist.residuals.get("wRmin"),
            "GOF": rvals.get("GOF"),
            "chi_square": rvals.get("chisq"),
            "n_observations": rvals.get("Nobs"),
            "n_variables": rvals.get("Nvars"),
            "converged": rvals.get("converged"),
            "max_shift_over_sigma": rvals.get("Max shft/sig"),
        },
        "measurement": {
            "radiation": "Cu Kalpha1/Kalpha2",
            "wavelength_Kalpha1_angstrom": 1.540598,
            "wavelength_Kalpha2_angstrom": 1.544426,
            "Kalpha2_to_Kalpha1_ratio": 0.5,
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
            "points": int(x.size),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
