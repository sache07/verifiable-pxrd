#!/usr/bin/env python3
"""Refine one physically bounded isotropic displacement value per phase."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "sequential_profile" / "04_polarization.gpx"
WORK = ROOT / ".tmp" / "uiso_refinement"
WORKING = WORK / "working.gpx"


def summary(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    mass_scales = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        mass_scales.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "uiso_A2": [atom.uiso for atom in phase.atoms()],
                "scale": hap["Scale"][0],
            }
        )
    total = sum(mass_scales)
    for phase, mass_scale in zip(phases, mass_scales):
        phase["weight_fraction"] = mass_scale / total
    return {
        "rwp": hist.get_wR(),
        "rp": hist.residuals.get("R"),
        "gof": cov.get("GOF"),
        "converged": cov.get("converged"),
        "max_shift_over_sigma": cov.get("Max shft/sig"),
        "message": cov.get("msg", ""),
        "frozen": project.get_Frozen(),
        "phases": phases,
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(WORKING))
    project.set_Controls("cycles", 16)
    project.set_Frozen()
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    # Uiso and polarization both describe high-angle intensity falloff.
    # Fit them sequentially to avoid the 97% correlation seen in a joint trial.
    inst["Polariz."][2] = False

    for phase_index, phase in enumerate(project.phases()):
        labels = [atom.label for atom in phase.atoms()]
        phase.set_refinements({"Atoms": {label: "U" for label in labels}})
        variables = [
            f"{phase_index}::AUiso:{atom_index}"
            for atom_index in range(len(labels))
        ]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable)
            project.set_Controls("parmMax", 0.020, variable)

    project.refine(makeBack=False)
    shutil.copy2(WORKING, WORK / "01_uiso.gpx")
    first = summary(project)
    first["stage"] = "01_uiso"
    print(json.dumps(first))

    for phase in project.phases():
        phase.set_refinements(
            {"Atoms": {atom.label: "" for atom in phase.atoms()}}
        )
    inst["Polariz."][2] = True
    project.refine(makeBack=False)
    shutil.copy2(WORKING, WORK / "02_polarization.gpx")
    second = summary(project)
    second["stage"] = "02_polarization"
    print(json.dumps(second))
    (WORK / "history.json").write_text(
        json.dumps([first, second], indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
