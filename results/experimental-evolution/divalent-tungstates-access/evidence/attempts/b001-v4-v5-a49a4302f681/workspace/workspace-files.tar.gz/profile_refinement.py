#!/usr/bin/env python3
"""Refine common instrument terms, then phase specimen broadening.

The common Gaussian/Lorentzian terms are fitted while phase broadening is
temporarily held, and are then fixed before phase size/strain is reopened. This
avoids exact or near-exact instrument/specimen width correlations.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "coordinate_refinement" / "03_manganese.gpx"
WORK = ROOT / ".tmp" / "profile_refinement"
WORKING = WORK / "working.gpx"


def atom_flags_off(project: G2.G2Project) -> None:
    for phase in project.phases():
        phase.set_refinements(
            {"Atoms": {atom.label: "" for atom in phase.atoms()}}
        )


def hap_profile_flags(project: G2.G2Project, value: bool) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = value
        hap["Mustrain"][2][0] = value


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    phases = []
    mass_scales = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        mass_scales.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size_um": hap["Size"][1][0],
                "microstrain": hap["Mustrain"][1][0],
            }
        )
    total = sum(mass_scales)
    for phase, mass_scale in zip(phases, mass_scales):
        phase["weight_fraction"] = mass_scale / total
    row = {
        "stage": stage,
        "rwp": hist.get_wR(),
        "rp": hist.residuals.get("R"),
        "rwp_min": hist.residuals.get("wRmin"),
        "gof": covariance.get("Rvals", {}).get("GOF"),
        "converged": covariance.get("Rvals", {}).get("converged"),
        "max_shift_over_sigma": covariance.get("Rvals", {}).get("Max shft/sig"),
        "instrument": {
            key: {"value": inst[key][1], "refine": bool(inst[key][2])}
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
        },
        "sample": {
            key: {"value": sample[key][0], "refine": bool(sample[key][1])}
            for key in ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"]
        },
        "frozen": project.get_Frozen(),
        "phases": phases,
    }
    print(json.dumps(row))
    return row


def checkpoint(project: G2.G2Project, stage: str, history: list[dict]) -> None:
    shutil.copy2(WORKING, WORK / f"{stage}.gpx")
    history.append(snapshot(project, stage))
    (WORK / "history.json").write_text(json.dumps(history, indent=2) + "\n")


def refine(project: G2.G2Project, stage: str, history: list[dict]) -> None:
    project.refine(makeBack=False)
    checkpoint(project, stage, history)


def main() -> None:
    G2.SetPrintLevel("warn")
    WORK.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(BASE))
    project.save(str(WORKING))
    project.set_Controls("cycles", 12)
    atom_flags_off(project)
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]

    # Preserve the physically bounded zero/height solution while removing its
    # 99.97% correlation: hold zero and continue refining specimen height.
    inst["Zero"][2] = False
    hist.data["Sample Parameters"]["Shift"][1] = True
    history: list[dict] = []
    refine(project, "01_coordinates_fixed", history)

    # Fit the common profile with phase-specific widths held at their current
    # physical values. V is kept at zero because the lab profile does not use it.
    hap_profile_flags(project, False)
    for key in ["U", "W", "X", "SH/L"]:
        inst[key][2] = True
    limits = {
        "U": (0.0, 40.0),
        "W": (2.0, 40.0),
        "X": (0.1, 6.0),
        "SH/L": (0.005, 0.10),
    }
    for key, (lower, upper) in limits.items():
        project.set_Controls("parmMin", lower, f":0:{key}")
        project.set_Controls("parmMax", upper, f":0:{key}")
    refine(project, "02_common_profile", history)

    # Freeze the common profile and restore independent, positive phase widths.
    for key in ["U", "W", "X", "SH/L"]:
        inst[key][2] = False
    project.set_Frozen()
    hap_profile_flags(project, True)
    refine(project, "03_phase_profile", history)

    # Polarization changes relative intensities smoothly and is independent of
    # the coordinate blocks that were rejected above.
    inst["Polariz."][2] = True
    project.set_Controls("parmMin", 0.5, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    refine(project, "04_polarization", history)


if __name__ == "__main__":
    main()
