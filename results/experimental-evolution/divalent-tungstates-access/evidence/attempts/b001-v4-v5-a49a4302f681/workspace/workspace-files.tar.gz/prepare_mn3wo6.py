#!/usr/bin/env python3
"""Create an R-3 Mn3WO6 start model from the isovalent Mn3TeO6 analogue."""

from pathlib import Path
import sys

from pymatgen.core import Lattice, Structure


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif/2/21/15/2211528.cif"
)
OUTPUT = ROOT / ".tmp" / "models" / "Mn3WO6_R-3_start.cif"

# Reuse the frozen process's neutral-element, symmetry-preserving CIF writer.
sys.path.insert(0, str(ROOT / "learned" / "divalent-tungstates" / "runtime"))
from models import write_synthetic_model  # noqa: E402


def main() -> None:
    parent = Structure.from_file(SOURCE, primitive=False)
    parent.remove_oxidation_states()
    parent.replace_species({"Te": "W"})
    indexed = Structure(
        Lattice.hexagonal(8.90273, 10.47621),
        parent.species,
        parent.frac_coords,
        coords_are_cartesian=False,
    )
    write_synthetic_model(indexed, OUTPUT)
    distances = indexed.distance_matrix.copy()
    distances[distances == 0] = float("inf")
    print("output", OUTPUT)
    print("formula", indexed.composition.reduced_formula)
    print("space_group", indexed.get_space_group_info(symprec=1e-3))
    print("cell", indexed.lattice)
    print("density_g_cm3", indexed.density)
    print("minimum_distance_A", distances.min())


if __name__ == "__main__":
    main()
