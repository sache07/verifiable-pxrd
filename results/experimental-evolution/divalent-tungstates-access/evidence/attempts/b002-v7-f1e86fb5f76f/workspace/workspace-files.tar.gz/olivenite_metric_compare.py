#!/usr/bin/env python3
"""Compare olivenite Mn2WO5 metrics without coordinate or profile refinement.

This is deliberately a narrow checkpoint: all candidates receive the same
scale/background, cell, zero and specimen-displacement development.  The
monoclinic analogue is allowed enough reciprocal shear to establish whether
its pseudo-orthorhombic start is an interior solution rather than a bound
artifact.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

sys.path.insert(0, str(Path(__file__).resolve().parent / "learned"))
import staged_polish as SP
from refine_driver import residual_peaks, write_data_and_instrument


MNWO4 = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif/1/52/02/1520200.cif")
WO3 = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif/1/52/89/1528915.cif")
HMNO = Path("candidates/mno_hexagonal.cif")
LAB = {"Zero": (-0.25, 0.25), "Shift": (-800.0, 800.0)}


def phase(project, name):
    return next(item for item in project.phases() if item.name == name)


def set_flags(project, *, cells=True, shift=False):
    SP.clear_flags(project)
    SP.enable_scales_and_background(project)
    hist = SP.histogram(project)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    if shift:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    if cells:
        for item in project.phases():
            item.set_refinements({"Cell": True})


def state(project, stage):
    hist = SP.histogram(project)
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": SP.mass_fractions(project),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "cells": {item.name: item.get_cell() for item in project.phases()},
        "converged": bool(covariance.get("Rvals", {}).get("converged", False)),
        "max_shift_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(value) for value in project.get_Frozen()],
    }


def run(project, label, records, cycles=12):
    SP.clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = state(project, label)
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def install_bounds(project, source_cells):
    project.index_ids()
    hist = SP.histogram(project)
    hid = int(hist.data["data"][0]["hId"])
    for name, (low, high) in LAB.items():
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    for item in project.phases():
        pid = int(item.data["pId"])
        project.set_Controls("parmMin", 1e-9, variable=f"{pid}:{hid}:Scale")
        reciprocal = G2lat.cell2A(source_cells[item.name])
        for index, raw in enumerate(reciprocal):
            value = float(raw)
            if item.name == "Mn2WO5":
                # The transformed analogue already matches lengths closely,
                # but its symmetry-lowering shear was initially exactly zero.
                span = 0.04 * abs(value) if index < 3 else 0.003
            elif item.name == "hMnO":
                span = max(0.012 * abs(value), 0.0002)
            else:
                span = max(0.006 * abs(value), 0.0002)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--include-hmno", action="store_true")
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)

    sources = [("MnWO4", MNWO4, 0.65), ("WO3", WO3, 0.20),
               ("Mn2WO5", args.candidate.resolve(), 0.15)]
    if args.include_hmno:
        sources = [("MnWO4", MNWO4, 0.65), ("WO3", WO3, 0.20),
                   ("Mn2WO5", args.candidate.resolve(), 0.10),
                   ("hMnO", HMNO.resolve(), 0.05)]
    total = sum(row[2] for row in sources)

    G2.SetPrintLevel("error")
    data, inst = write_data_and_instrument(args.out.parent / f".{args.out.stem}_inputs", Path("inputs").resolve())
    project = G2.G2Project(newgpx=str(args.out.resolve()))
    items = [project.add_phase(str(path), phasename=name, fmthint="CIF") for name, path, _ in sources]
    hist = project.add_powder_histogram(str(data), str(inst), phases="all", fmthint="xye")
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12,
                       "coeffs": [1200.0, 400.0] + [0.0] * 10, "refine": True},
    })
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]

    source_cells = {}
    for item, (_, _, start) in zip(items, sources):
        cell = item.get_cell()
        source_cells[item.name] = [cell[key] for key in (
            "length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma")]
        hap = item.data["Histograms"][hist.name]
        hap["Scale"] = [100000.0 * start / total / float(item.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    install_bounds(project, source_cells)
    records = []

    SP.clear_flags(project)
    SP.enable_scales_and_background(project)
    run(project, "scale_background_1", records)
    SP.clear_flags(project)
    SP.enable_scales_and_background(project)
    run(project, "scale_background_2", records)
    set_flags(project, shift=False)
    run(project, "zero_cells_1", records)
    set_flags(project, shift=False)
    run(project, "zero_cells_2", records)
    for index in range(1, 5):
        set_flags(project, shift=True)
        result = run(project, f"zero_shift_cells_{index}", records)
        if (result["converged"] and not result["frozen"] and
                result["max_shift_esd"] is not None and result["max_shift_esd"] <= 1.0):
            break
    SP.clear_flags(project)
    project.save()

    result = {
        "project": str(args.out.resolve()), "candidate": str(args.candidate.resolve()),
        "include_hmno": args.include_hmno, "records": records,
        "final": state(project, "final"), "geometry": SP.geometry_profile(project),
        "residual_peaks": residual_peaks(project, 40),
    }
    args.out.with_suffix(".metric.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"final": result["final"], "residual": result["residual_peaks"][:12]}), flush=True)


if __name__ == "__main__":
    main()
