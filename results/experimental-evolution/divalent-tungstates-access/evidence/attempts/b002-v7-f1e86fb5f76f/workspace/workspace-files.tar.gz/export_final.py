#!/usr/bin/env python3
"""Export the accepted final.gpx without changing or refining it."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "replay_final"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    project_path = ROOT / "final.gpx"
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay["status"] != "replayed" or not replay["project_unchanged"]:
        raise RuntimeError("read-only forward replay did not pass")
    if sha256(project_path) != replay["project_sha256"]:
        raise RuntimeError("final.gpx changed after the verified replay")

    project = G2.G2Project(gpxfile=str(project_path))
    histogram = next(item for item in project.histograms()
                     if item.name == replay["histogram"])
    phase_by_name = {item.name: item for item in project.phases()}
    mass_fractions = histogram.ComputeMassFracs()

    export_names = {
        "MnWO4": "phase_1_MnWO4.cif",
        "WO3": "phase_2_WO3.cif",
        "Mn2WO5": "phase_3_Mn2WO5.cif",
    }
    phases = []
    for source in replay["phases"]:
        name = source["name"]
        destination = ROOT / export_names[name]
        shutil.copy2(REPLAY / source["cif"], destination)
        phase = phase_by_name[name]
        cell = phase.get_cell()
        fraction, sigma = mass_fractions[name]
        phases.append({
            "name": name,
            "formula": {"MnWO4": "MnWO4", "WO3": "WO3",
                        "Mn2WO5": "Mn2WO5"}[name],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": destination.name,
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(sigma),
            "cell": {
                "a_A": float(cell["length_a"]),
                "b_A": float(cell["length_b"]),
                "c_A": float(cell["length_c"]),
                "alpha_deg": float(cell["angle_alpha"]),
                "beta_deg": float(cell["angle_beta"]),
                "gamma_deg": float(cell["angle_gamma"]),
                "volume_A3": float(cell["volume"]),
            },
        })

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as arrays:
        x = arrays["x"].copy()
        observed = arrays["observed"].copy()
        calculated = arrays["predicted"].copy()
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for row in zip(x, observed, calculated, difference):
            writer.writerow([f"{row[0]:.10f}", f"{row[1]:.10g}",
                             f"{row[2]:.10f}", f"{row[3]:.10f}"])

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    result = {
        "phases": phases,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "GOF": float(rvals["GOF"]),
            "weighted_chi_square": chi_square,
            "n_points": int(len(x)),
            "n_refined_parameters_in_final_covariance": int(rvals["Nvars"]),
            "calculation": "read-only native GSAS-II forward replay on the full observed grid",
        },
        "refinement_histogram": histogram.name,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "project_sha256": replay["project_sha256"],
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
