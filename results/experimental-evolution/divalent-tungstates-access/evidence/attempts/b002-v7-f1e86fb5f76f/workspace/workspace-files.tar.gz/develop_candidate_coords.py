#!/usr/bin/env python3
"""Develop one substituted Mn2WO5 candidate at an equal GSAS-II checkpoint.

The input is a scale/background/cell-refined three-phase project. Phase
broadening and specimen/profile terms are held fixed while the substituted
phase is adapted in heavy-atom, oxygen, and joint-coordinate stages.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent / "learned"))
import staged_polish as SP


def target(project):
    matches = [phase for phase in project.phases() if phase.name == "Mn2WO5"]
    if len(matches) != 1:
        raise RuntimeError("project must contain exactly one Mn2WO5 phase")
    return matches[0]


def enable_metric_model(project) -> None:
    SP.clear_flags(project)
    SP.enable_scales_and_background(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})


def enable_target_atoms(project, predicate) -> int:
    enable_metric_model(project)
    count = 0
    for atom in target(project).atoms():
        atom.refinement_flags = "X" if predicate(atom) else " "
        count += bool(atom.refinement_flags.strip())
    return count


def run(project, label, records, cycles=8):
    SP.clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    state = SP.convergence_state(project)
    item = {
        "stage": label,
        "Rwp_percent": float(SP.histogram(project).get_wR()),
        "fractions": SP.mass_fractions(project),
        **state,
    }
    records.append(item)
    print(json.dumps(item), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve())
    )
    SP.clear_flags(project)
    SP.reset_limits(project)
    SP.install_bounds(project)
    records = []

    # Complete the same metric/scale/background checkpoint for every start.
    for index in range(3):
        enable_metric_model(project)
        run(project, f"metric_settle_{index + 1}", records, 8)
        state = records[-1]
        maximum = state.get("max_shift_esd")
        if state.get("converged") and maximum is not None and maximum <= 1.0 and not state["frozen"]:
            break

    enable_target_atoms(project, lambda atom: not SP.is_oxygen(atom))
    run(project, "target_heavy_coordinates", records, 8)
    enable_target_atoms(project, SP.is_oxygen)
    run(project, "target_oxygen_coordinates", records, 8)
    enable_target_atoms(project, lambda atom: True)
    run(project, "target_joint_coordinates", records, 10)

    # Replay the same active model until stable, without introducing nuisance
    # terms. A bounded atom remains explicit in the audit rather than being
    # interpreted as a structural rejection.
    for index in range(3):
        enable_target_atoms(project, lambda atom: True)
        run(project, f"coordinate_replay_{index + 1}", records, 8)
        state = records[-1]
        maximum = state.get("max_shift_esd")
        if state.get("converged") and maximum is not None and maximum <= 1.0 and not state["frozen"]:
            break

    SP.clear_flags(project)
    project.save()
    result = {
        "source": str(args.source.resolve()),
        "output": str(args.output.resolve()),
        "records": records,
        "final_Rwp_percent": float(SP.histogram(project).get_wR()),
        "fractions": SP.mass_fractions(project),
        "geometry": SP.geometry_profile(project),
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "coordinates": [float(value) for value in atom.coordinates],
                "occupancy": float(atom.occupancy),
                "uiso": float(atom.uiso),
            }
            for atom in target(project).atoms()
        ],
    }
    args.output.with_suffix(".coords.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps({"final": result["final_Rwp_percent"], "fractions": result["fractions"]}), flush=True)


if __name__ == "__main__":
    main()
