#!/usr/bin/env python3
"""Compare March-Dollase axes at equal development for each accepted phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import terminal_olivenite as T
import staged_polish as SP


AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--outdir", required=True, type=Path)
    parser.add_argument("--phases", default="MnWO4,WO3,Mn2WO5",
                        help="comma-separated phase names to test")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    G2.SetPrintLevel("error")
    for phase_name in [item for item in args.phases.split(",") if item]:
        for axis in AXES:
            tag = "".join(map(str, axis))
            path = args.outdir / f"{phase_name}_{tag}.gpx"
            project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(path.resolve()))
            hist = SP.histogram(project)
            hap = T.phase(project, phase_name).data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            hap["Pref.Ori."][3] = list(axis)
            records = []
            T.set_flags(project, instrument=("U", "W", "Polariz."),
                        textures={phase_name: axis})
            T.run(project, "texture", records, cycles=8, passes=2)
            SP.clear_flags(project)
            project.save()
            state = T.record(project, "final")
            row = {"phase": phase_name, "axis": axis, "project": str(path.resolve()),
                   "ratio": state["texture"][phase_name][0], "state": state}
            rows.append(row)
            print(json.dumps(row), flush=True)
    (args.outdir / "texture_screen.json").write_text(json.dumps({
        "source": str(args.source.resolve()), "rows": rows,
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
