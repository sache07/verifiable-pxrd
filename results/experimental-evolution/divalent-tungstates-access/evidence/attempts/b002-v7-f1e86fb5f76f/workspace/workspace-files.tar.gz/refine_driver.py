#!/usr/bin/env python3
"""Build and develop trial GSAS-II Rietveld models for the supplied pattern.

This is an exploratory helper. It writes each requested model to a separate
project and records every refinement checkpoint so candidate phase sets can be
compared at the same level of development.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from scipy.signal import find_peaks

from GSASII import GSASIIscriptable as G2


LAB_BOUNDS = {
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.1, 6.0),
    "SH/L": (0.005, 0.1),
    "Polariz.": (0.5, 1.0),
    "Zero": (-0.25, 0.25),
    "Shift": (-800.0, 800.0),
}


def write_data_and_instrument(work: Path, inputs: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    raw = np.genfromtxt(inputs / "pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], float)
    y = np.asarray(raw["intensity"], float)
    data = work / "pattern.xye"
    np.savetxt(data, np.column_stack((x, y, np.sqrt(np.maximum(y, 1.0)))), fmt="%.8f %.8f %.8f")
    inst = work / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:21.0;X:0.7745966692414834;Y:0.0;Z:0.0;SH/L:0.022360679775\n"
    )
    return data, inst


def parse_phase(item: str) -> tuple[str, Path]:
    try:
        name, filename = item.split("=", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("phase must be NAME=CIF") from exc
    path = Path(filename).resolve()
    if not name.strip() or not path.is_file():
        raise argparse.ArgumentTypeError(f"invalid phase specification: {item}")
    return name.strip(), path


def clear_all_flags(project: G2.G2Project) -> None:
    for hist in project.histograms():
        hist.clear_refinements({
            "Background": True,
            "Instrument Parameters": list(hist.InstrumentParameters),
            "Sample Parameters": [
                key for key, value in hist.SampleParameters.items()
                if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)
            ],
        })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True,
            "Size": True,
            "Mustrain": True,
            "Pref.Ori.": True,
            "HStrain": True,
            "Extinction": True,
            "Babinet": True,
        })


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    try:
        values = hist.ComputeMassFracs()
    except Exception:
        values = {}
    if values:
        return {str(k): float(v[0]) for k, v in values.items()}
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True):
            weighted[phase.name] = max(0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(weighted.values())
    return {k: v / total for k, v in weighted.items()} if total else weighted


def snapshot(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": stage,
        "Rwp_percent": None if hist.get_wR() is None else float(hist.get_wR()),
        "Rp_percent": float(hist.data["data"][0].get("R", np.nan)),
        "GOF": float(covariance.get("Rvals", {}).get("GOF", np.nan)),
        "converged": bool(covariance.get("Rvals", {}).get("converged", False)),
        "max_shift_esd": covariance.get("Rvals", {}).get("Max shft/sig"),
        "variables": {
            str(k): float(v)
            for k, v in zip(covariance.get("varyList", []), covariance.get("variables", []))
        },
        "instrument": {
            k: float(v[1]) for k, v in hist.InstrumentParameters.items()
            if (
                isinstance(v, list) and len(v) > 1 and np.isscalar(v[1])
                and not isinstance(v[1], (str, bytes))
            )
        },
        "sample": {
            k: float(v[0]) for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and v and np.isscalar(v[0]) and not isinstance(v[0], str)
        },
        "fractions": mass_fractions(project),
        "phases": {},
        "frozen": [str(item) for item in project.get_Frozen()],
    }
    if result["max_shift_esd"] is not None:
        result["max_shift_esd"] = float(result["max_shift_esd"])
    for phase in project.phases():
        hist_data = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": {k: float(v) for k, v in phase.get_cell().items()},
            "scale": float(hist_data["Scale"][0]),
            "size": [hist_data["Size"][0], [float(v) for v in hist_data["Size"][1]]],
            "mustrain": [hist_data["Mustrain"][0], [float(v) for v in hist_data["Mustrain"][1]]],
            "preferred_orientation": [
                hist_data["Pref.Ori."][0], float(hist_data["Pref.Ori."][1]),
                list(hist_data["Pref.Ori."][3]),
            ],
        }
    return result


def residual_peaks(project: G2.G2Project, count: int = 40) -> list[dict]:
    data = project.histograms()[0].data["data"][1]
    x, obs, calc, bkg = map(lambda a: np.asarray(a, float), (data[0], data[1], data[3], data[4]))
    resid = obs - calc
    peaks, props = find_peaks(resid, prominence=max(75.0, 2.5 * np.sqrt(np.median(obs))), distance=5)
    order = np.argsort(props["prominences"])[::-1][:count]
    return [
        {
            "two_theta_deg": float(x[peaks[i]]),
            "residual_counts": float(resid[peaks[i]]),
            "prominence_counts": float(props["prominences"][i]),
            "observed_counts": float(obs[peaks[i]]),
            "calculated_counts": float(calc[peaks[i]]),
            "background_counts": float(bkg[peaks[i]]),
        }
        for i in order
    ]


def run_refinement(project: G2.G2Project, label: str, records: list[dict], cycles: int = 8) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = snapshot(project, label)
    records.append(record)
    print(json.dumps(record), flush=True)


def set_phase_scale_guesses(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    # Equal starting mass fractions; this convention is stable for phases with
    # very different unit-cell masses.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = 100.0 / float(phase.data["General"]["Mass"])
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]


def install_physical_bounds(project: G2.G2Project) -> None:
    """Apply the supplied laboratory ranges and positive HAP limits."""
    project.index_ids()
    hist = project.histograms()[0]
    hid = int(hist.data["data"][0]["hId"])
    for name in ("U", "W", "X", "SH/L", "Polariz.", "Zero"):
        low, high = LAB_BOUNDS[name]
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    low, high = LAB_BOUNDS["Shift"]
    project.set_Controls("parmMin", low, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", high, variable=f":{hid}:Shift")
    for phase in project.phases():
        pid = int(phase.data["pId"])
        project.set_Controls("parmMin", 1.0e-9, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")


def initialize(args: argparse.Namespace) -> G2.G2Project:
    output = args.out.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    data, inst = write_data_and_instrument(output.parent / f".{output.stem}_inputs", args.inputs.resolve())
    project = G2.G2Project(newgpx=str(output))
    for name, path in args.phase:
        project.add_phase(str(path), phasename=name, fmthint="CIF")
    hist = project.add_powder_histogram(str(data), str(inst), phases="all", fmthint="xye")
    hist.set_refinements({
        "Limits": [float(np.min(hist.data["data"][1][0])), float(np.max(hist.data["data"][1][0]))],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": args.background_terms,
            "coeffs": [1200.0, 400.0] + [0.0] * (args.background_terms - 2),
            "refine": True,
        },
    })
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    set_phase_scale_guesses(project)
    project.set_Controls("cycles", 0)
    project.save()
    project.refine(makeBack=False)
    install_physical_bounds(project)
    project.save()
    return project


def develop(project: G2.G2Project, level: str = "full") -> list[dict]:
    records: list[dict] = []
    hist = project.histograms()[0]

    # 1. Establish positive scales and a smooth continuum.
    run_refinement(project, "scale_background", records, 10)

    # 2. Refine crystallographic metrics with the common angular zero.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_refinement(project, "zero_cells", records, 10)
    if level == "cells":
        return records

    # 3. Develop phase-specific symmetric breadth. Size and strain are separated
    # in two checkpoints before their joint settle.
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": True}})
    run_refinement(project, "isotropic_size", records, 10)
    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run_refinement(project, "isotropic_size_strain", records, 10)
    if level == "breadth":
        return records

    # 4. Complete the common instrumental peak shape within the supplied lab family.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    run_refinement(project, "instrument_profile", records, 10)
    if level == "profile":
        return records

    # 5. Add the physically generated specimen displacement. It is retained only
    # after later range/correlation review.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(project, "sample_shift", records, 10)

    # Repeat a settled checkpoint to expose replay or convergence instability.
    run_refinement(project, "settle", records, 12)
    return records


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--inputs", type=Path, default=Path("inputs"))
    parser.add_argument("--phase", type=parse_phase, action="append", required=True)
    parser.add_argument("--background-terms", type=int, default=8)
    parser.add_argument("--level", choices=("cells", "breadth", "profile", "full"), default="full")
    args = parser.parse_args()
    if args.background_terms < 2:
        parser.error("at least two background terms are required")

    G2.SetPrintLevel("error")
    project = initialize(args)
    records = develop(project, args.level)
    result = {
        "project": str(args.out.resolve()),
        "phases": [{"name": name, "source": str(path)} for name, path in args.phase],
        "records": records,
        "final": snapshot(project, "final"),
        "residual_peaks": residual_peaks(project),
    }
    args.out.with_suffix(".trial.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"final": result["final"], "residual_peaks": result["residual_peaks"]}), flush=True)


if __name__ == "__main__":
    main()
