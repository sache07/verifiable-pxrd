#!/usr/bin/env python3
"""Build a replayable terminal refinement while rolling back bound-hit terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

sys.path.insert(0, str(Path(__file__).resolve().parent / "learned"))
import staged_polish as SP
from refine_driver import residual_peaks, write_data_and_instrument


SOURCES = [
    ("MnWO4", "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif/1/52/02/1520200.cif", 0.68),
    ("WO3", "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif/1/52/89/1528915.cif", 0.21),
    ("Mn2WO5", "candidates/mn2wo5_repaired_natisite.cif", 0.06),
    ("Mn3O4", "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif/9/00/19/9001963.cif", 0.05),
]
MNO = ("MnO", "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif/1/51/42/1514231.cif", 0.02)
LAB = {
    "U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
    "SH/L": (0.005, 0.1), "Polariz.": (0.5, 1.0), "Zero": (-0.25, 0.25),
}


def phase(project, name):
    return next(item for item in project.phases() if item.name == name)


def set_flags(project, *, cells=(), instrument=(), sizes=(), strains=(), texture=None):
    SP.clear_flags(project)
    SP.enable_scales_and_background(project)
    hist = SP.histogram(project)
    if instrument:
        hist.set_refinements({"Instrument Parameters": list(instrument)})
    for name in cells:
        phase(project, name).set_refinements({"Cell": True})
    for name in sizes:
        item = phase(project, name)
        value = float(item.data["Histograms"][hist.name]["Size"][1][0])
        item.set_HAP_refinements({"Size": {"type": "isotropic", "value": value, "refine": True}})
    for name in strains:
        item = phase(project, name)
        item.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    if texture is not None:
        name, axis = texture
        phase(project, name).set_HAP_refinements({
            "Pref.Ori.": {"type": "MD", "axis": list(axis), "ratio": 1.0, "refine": True}
        })


def covariance_summary(project):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(item) for item in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), float)
    if matrix.shape != (len(names), len(names)) or not names:
        return []
    sig = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    den = np.outer(sig, sig)
    corr = np.divide(matrix, den, out=np.zeros_like(matrix), where=den > 0)
    rows = []
    for i in range(len(names)):
        for j in range(i):
            if abs(corr[i, j]) >= 0.9:
                rows.append([names[j], names[i], float(corr[i, j])])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)[:40]


def state(project, stage):
    hist = SP.histogram(project)
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": SP.mass_fractions(project),
        "instrument": {key: float(hist.InstrumentParameters[key][1]) for key in LAB},
        "cells": {item.name: item.get_cell() for item in project.phases()},
        "sizes_um": {item.name: float(item.data["Histograms"][hist.name]["Size"][1][0]) for item in project.phases()},
        "strains_ppm": {item.name: float(item.data["Histograms"][hist.name]["Mustrain"][1][0]) for item in project.phases()},
        "MD": {item.name: [float(item.data["Histograms"][hist.name]["Pref.Ori."][1]), list(item.data["Histograms"][hist.name]["Pref.Ori."][3])] for item in project.phases()},
        "high_correlations": covariance_summary(project),
        **SP.convergence_state(project),
    }


def run(project, label, records, cycles=10):
    SP.clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    item = state(project, label)
    records.append(item)
    print(json.dumps(item), flush=True)
    return item


def install_bounds(project, source_cells):
    project.index_ids()
    hist = SP.histogram(project)
    hid = int(hist.data["data"][0]["hId"])
    for key, (low, high) in LAB.items():
        project.set_Controls("parmMin", low, variable=f":{hid}:{key}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{key}")
    for item in project.phases():
        pid = int(item.data["pId"])
        project.set_Controls("parmMin", 1e-9, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")
        reciprocal = G2lat.cell2A(source_cells[item.name])
        for index, value in enumerate(reciprocal):
            span = max(0.006 * abs(float(value)), 0.0002)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--include-mno", action="store_true")
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    sources = list(SOURCES) + ([MNO] if args.include_mno else [])
    total = sum(row[2] for row in sources)

    G2.SetPrintLevel("error")
    data, inst = write_data_and_instrument(args.out.parent / f".{args.out.stem}_inputs", Path("inputs").resolve())
    project = G2.G2Project(newgpx=str(args.out.resolve()))
    items = [project.add_phase(str(Path(path).resolve()), phasename=name, fmthint="CIF") for name, path, _ in sources]
    hist = project.add_powder_histogram(str(data), str(inst), phases="all", fmthint="xye")
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": 10,
                       "coeffs": [1200.0, 400.0] + [0.0] * 8, "refine": True},
    })
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Scale"] = [1.0, False]

    source_cells = {}
    for item, (_, _, start) in zip(items, sources):
        cell = item.get_cell()
        source_cells[item.name] = [cell[key] for key in (
            "length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma"
        )]
        hap = item.data["Histograms"][hist.name]
        hap["Scale"] = [100000.0 * start / total / float(item.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = hap["Size"][1][1] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    install_bounds(project, source_cells)
    records = []
    main_cells = ("MnWO4", "WO3")

    set_flags(project)
    run(project, "scale_background_1", records, 12)
    set_flags(project)
    run(project, "scale_background_2", records, 10)
    set_flags(project, cells=main_cells, instrument=("Zero",))
    run(project, "zero_main_cells_1", records, 12)
    set_flags(project, cells=main_cells, instrument=("Zero",))
    run(project, "zero_main_cells_2", records, 10)

    accepted_instrument = ["Zero"]
    for label, additions in (
        ("gaussian", ("U", "W")),
        ("lorentzian", ("X",)),
        ("axial", ("SH/L",)),
        ("polarization", ("Polariz.",)),
    ):
        previous = {key: float(hist.InstrumentParameters[key][1]) for key in additions}
        trial = accepted_instrument + list(additions)
        set_flags(project, cells=main_cells, instrument=trial)
        result = run(project, f"{label}_trial", records, 10)
        hit = [key for key in additions if any(f":0:{key}" in str(value) for value in result["frozen"])]
        if hit:
            for key in additions:
                hist.InstrumentParameters[key][1] = previous[key]
            set_flags(project, cells=main_cells, instrument=accepted_instrument)
            run(project, f"{label}_rollback", records, 8)
        else:
            accepted_instrument.extend(additions)

    # Freeze calibration/profile while phase breadth is tested one phase at a time.
    accepted_sizes = []
    for name in ("WO3", "Mn2WO5", "Mn3O4") + (("MnO",) if args.include_mno else ()): 
        item = phase(project, name)
        hap = item.data["Histograms"][hist.name]
        previous = float(hap["Size"][1][0])
        set_flags(project, cells=main_cells, sizes=(name,))
        result = run(project, f"size_{name}_trial", records, 10)
        pid = int(item.data["pId"])
        variable = f"{pid}:0:Size;i"
        if variable in [str(value) for value in result["frozen"]]:
            hap["Size"][1][0] = hap["Size"][1][1] = previous
            set_flags(project, cells=main_cells)
            run(project, f"size_{name}_rollback", records, 8)
        else:
            accepted_sizes.append(name)

    # Test isotropic strain only for phases whose size did not become a bound proxy.
    for name in ("WO3", "Mn2WO5", "Mn3O4"):
        item = phase(project, name)
        hap = item.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 1000.0
        set_flags(project, cells=main_cells, strains=(name,))
        result = run(project, f"strain_{name}_trial", records, 10)
        pid = int(item.data["pId"])
        value = float(hap["Mustrain"][1][0])
        if f"{pid}:0:Mustrain;i" in [str(x) for x in result["frozen"]] or value < 300.0:
            hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
            set_flags(project, cells=main_cells)
            run(project, f"strain_{name}_rollback", records, 8)

    # Texture is tested against the most diagnostic generated axes, one phase
    # at a time; bound hits or negligible gains are removed.
    for name, axis in (("Mn2WO5", (0, 0, 1)), ("Mn3O4", (0, 0, 1)), ("WO3", (0, 1, 0))):
        before = float(hist.get_wR())
        item = phase(project, name)
        hap = item.data["Histograms"][hist.name]
        set_flags(project, cells=main_cells, texture=(name, axis))
        result = run(project, f"texture_{name}_trial", records, 10)
        ratio = float(hap["Pref.Ori."][1])
        if ratio <= 0.701 or ratio >= 1.399 or before - result["Rwp_percent"] < 0.03:
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][2] = False
            set_flags(project, cells=main_cells)
            run(project, f"texture_{name}_rollback", records, 8)

    # Final replay of only retained scales/background and the two well-indexed
    # reference cells; all trial nuisance terms are frozen at accepted values.
    for index in range(3):
        set_flags(project, cells=main_cells)
        result = run(project, f"terminal_replay_{index + 1}", records, 10)
        if result["converged"] and result["max_shift_esd"] is not None and result["max_shift_esd"] <= 1.0 and not result["frozen"]:
            break
    SP.clear_flags(project)
    project.save()
    summary = {
        "project": str(args.out.resolve()), "sources": sources, "records": records,
        "final": state(project, "final"), "geometry": SP.geometry_profile(project),
        "residual_peaks": residual_peaks(project, 60),
    }
    args.out.with_suffix(".terminal_work.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"final": summary["final"], "residual": summary["residual_peaks"][:20]}), flush=True)


if __name__ == "__main__":
    main()
