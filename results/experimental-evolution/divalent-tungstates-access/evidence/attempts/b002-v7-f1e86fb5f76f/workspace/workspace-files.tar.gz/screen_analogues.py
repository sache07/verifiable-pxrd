#!/usr/bin/env python3
"""Rank O-W ternary structure topologies against a signed residual profile."""

from __future__ import annotations

import argparse
import gzip
import json
from pathlib import Path
import warnings

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02")
INDEX = ROOT / "index.json.gz"
WAVELENGTH_1 = 1.540598
WAVELENGTH_2 = 1.544426


def cif_path(identifier: str) -> Path:
    return ROOT / "cif" / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def deposit_profile(
    x: np.ndarray, two_theta: np.ndarray, intensity: np.ndarray, fwhm_deg: float
) -> np.ndarray:
    step = float(np.median(np.diff(x)))
    sticks = np.zeros_like(x)
    for wavelength, ratio in ((WAVELENGTH_1, 1.0), (WAVELENGTH_2, 0.5)):
        theta1 = np.radians(two_theta / 2.0)
        argument = np.sin(theta1) * wavelength / WAVELENGTH_1
        valid = (argument > 0) & (argument < 1)
        positions = np.degrees(2.0 * np.arcsin(argument[valid]))
        values = ratio * intensity[valid]
        indices = np.rint((positions - x[0]) / step).astype(int)
        keep = (indices >= 0) & (indices < len(sticks))
        np.add.at(sticks, indices[keep], values[keep])
    sigma_bins = fwhm_deg / (2.354820045 * step)
    return gaussian_filter1d(sticks, sigma_bins, mode="constant")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", choices=("ternary", "ordinary"), default="ternary")
    args = parser.parse_args()
    with np.load(".tmp/base_breadth_residual.npz") as data:
        x = np.asarray(data["x"], float)
        observed = np.asarray(data["observed"], float)
        calculated = np.asarray(data["calculated"], float)
    residual = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    old_sse = float(np.sum(weights * residual * residual))
    denominator = float(np.sum(weights * observed * observed))

    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    records = []
    for system, entries in index.items():
        elements = system.split("-")
        if args.scope == "ternary":
            selected = "O" in elements and "W" in elements and len(elements) == 3
        else:
            selected = system in {"O-W", "Mn-O", "Mn-O-W"}
        if not selected:
            continue
        for formula, identifier, space_group, quality in entries:
            records.append((system, formula, identifier, space_group, quality))

    calculator = XRDCalculator(wavelength=WAVELENGTH_1)
    scales = np.linspace(0.72, 1.24, 131)
    results = []
    for number, (system, formula, identifier, space_group, quality) in enumerate(records, 1):
        path = cif_path(identifier)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = Structure.from_file(path, primitive=False)
                pattern = calculator.get_pattern(structure, two_theta_range=(7.0, 120.0), scaled=False)
            base_tt = np.asarray(pattern.x, float)
            base_intensity = np.asarray(pattern.y, float)
            if len(base_tt) == 0 or not np.isfinite(base_intensity).all():
                continue
            # Remove only numerically negligible reflections; weak families can
            # still be decisive when their heavy-atom structure factors differ.
            keep = base_intensity >= max(base_intensity) * 2.0e-4
            base_tt = base_tt[keep]
            base_intensity = base_intensity[keep]
            d_spacing = WAVELENGTH_1 / (2.0 * np.sin(np.radians(base_tt / 2.0)))
            best = None
            for scale in scales:
                arg = WAVELENGTH_1 / (2.0 * d_spacing * scale)
                valid = (arg > 0) & (arg < 1)
                tt = np.degrees(2.0 * np.arcsin(arg[valid]))
                inten = base_intensity[valid]
                in_range = (tt >= x[0] - 0.5) & (tt <= x[-1] + 0.5)
                if not np.any(in_range):
                    continue
                profile = deposit_profile(x, tt[in_range], inten[in_range], fwhm_deg=0.20)
                norm = float(np.sum(weights * profile * profile))
                if norm <= 0:
                    continue
                amplitude = max(0.0, float(np.sum(weights * profile * residual)) / norm)
                gain = amplitude * amplitude * norm
                if best is None or gain > best[0]:
                    best = (gain, float(scale), amplitude, profile)
            if best is None:
                continue
            gain, scale, amplitude, profile = best
            new_sse = old_sse - gain
            new_rwp = 100.0 * np.sqrt(max(new_sse, 0.0) / denominator)
            pred = amplitude * profile
            results.append({
                "system": system,
                "formula": formula,
                "id": identifier,
                "space_group_number": space_group,
                "quality": quality,
                "isotropic_length_scale": scale,
                "amplitude": amplitude,
                "predicted_Rwp_percent": new_rwp,
                "delta_weighted_sse": gain,
                "composition": structure.composition.formula,
                "sites": len(structure),
                "volume_A3": float(structure.volume),
                "strong_predicted_peaks": [
                    [float(x[i]), float(pred[i]), float(residual[i])]
                    for i in np.argsort(pred)[-20:][::-1]
                ],
            })
        except Exception as exc:
            results.append({
                "system": system,
                "formula": formula,
                "id": identifier,
                "space_group_number": space_group,
                "error": str(exc),
            })
        if number % 50 == 0:
            print(f"screened {number}/{len(records)}", flush=True)

    valid = [item for item in results if "predicted_Rwp_percent" in item]
    valid.sort(key=lambda item: item["predicted_Rwp_percent"])
    output = {
        "base_Rwp_percent": 100.0 * np.sqrt(old_sse / denominator),
        "method": "signed residual projection of isotropically scaled Cu Kalpha doublet profiles; ranking only",
        "results": valid,
        "errors": [item for item in results if "error" in item],
    }
    target = Path(f".tmp/{args.scope}_screen.json")
    target.write_text(json.dumps(output, indent=2) + "\n")
    for item in valid[:80]:
        print(
            item["id"], item["formula"], item["system"],
            "SG", item["space_group_number"],
            "scale", round(item["isotropic_length_scale"], 4),
            "Rwp", round(item["predicted_Rwp_percent"], 4),
        )


if __name__ == "__main__":
    main()
