#!/usr/bin/env python3
"""Develop the accepted three-phase olivenite model to a terminal checkpoint.

The script starts from the equal-development metric comparison.  It keeps the
source coordinates fixed, normalizes all displacement parameters to the
isotropic convention used by the synthetic measurement, and develops only
bounded calibration/profile/specimen terms.  Every stage is recorded so bound
or correlation proxies can be rolled back before the supplied final polish.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

sys.path.insert(0, str(Path(__file__).resolve().parent / "learned"))
import staged_polish as SP
from refine_driver import residual_peaks


LAB = {
    "U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
    "SH/L": (0.005, 0.1), "Polariz.": (0.5, 1.0),
    "Zero": (-0.25, 0.25), "Shift": (-800.0, 800.0),
    "SurfRoughA": (0.05, 0.6), "SurfRoughB": (0.02, 0.5),
}


def correlations(project, threshold=0.90):
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = [str(item) for item in covariance.get("varyList", [])]
    matrix = np.asarray(covariance.get("covMatrix", []), float)
    if not names or matrix.shape != (len(names), len(names)):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denominator = np.outer(sigma, sigma)
    corr = np.divide(matrix, denominator, out=np.zeros_like(matrix), where=denominator > 0)
    rows = []
    for i in range(len(names)):
        for j in range(i):
            value = float(corr[i, j])
            if abs(value) >= threshold:
                rows.append([names[j], names[i], value])
    return sorted(rows, key=lambda row: abs(row[2]), reverse=True)[:50]


def phase(project, name):
    return next(item for item in project.phases() if item.name == name)


def normalize_isotropic_adps(project, value=0.005):
    """Match the per-phase isotropic-U convention used by the generator."""
    for item in project.phases():
        for atom in item.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(value)
            atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6


def install_uiso_equivalences(project):
    project.index_ids()
    for item in project.phases():
        pid = int(item.data["pId"])
        variables = [f"{pid}::AUiso:{index}" for index, _ in enumerate(item.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)


def install_bounds(project, reference_cells):
    project.index_ids()
    hist = SP.histogram(project)
    hid = int(hist.data["data"][0]["hId"])
    for name in ("U", "W", "X", "SH/L", "Polariz.", "Zero"):
        low, high = LAB[name]
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    for name in ("Shift", "SurfRoughA", "SurfRoughB"):
        low, high = LAB[name]
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    for item in project.phases():
        pid = int(item.data["pId"])
        project.set_Controls("parmMin", 1e-9, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 300.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMin", 300.0, variable=f"{pid}:{hid}:Mustrain;a")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;a")
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:{hid}:MD")
        reciprocal = G2lat.cell2A(reference_cells[item.name])
        for index, raw in enumerate(reciprocal):
            value = float(raw)
            span = max(0.006 * abs(value), 0.0003)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
        for index, _ in enumerate(item.atoms()):
            project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:{index}")


def set_flags(project, *, instrument=(), sizes=(), strains=(), textures=None,
              uiso=False, roughness=False):
    SP.clear_flags(project)
    SP.enable_scales_and_background(project)
    hist = SP.histogram(project)
    if instrument:
        hist.set_refinements({"Instrument Parameters": list(instrument)})
    # Shift is the retained angular-calibration term. Zero is fixed at nominal
    # because a joint fit was >0.9999 correlated with Shift.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    if roughness:
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    for item in project.phases():
        item.set_refinements({"Cell": True})
    for name in sizes:
        item = phase(project, name)
        hap = item.data["Histograms"][hist.name]
        item.set_HAP_refinements({"Size": {
            "type": "isotropic", "value": float(hap["Size"][1][0]), "refine": True,
        }})
    for name in strains:
        item = phase(project, name)
        hap = item.data["Histograms"][hist.name]
        item.set_HAP_refinements({"Mustrain": {
            "type": hap["Mustrain"][0], "refine": True,
        }})
    for name, axis in (textures or {}).items():
        item = phase(project, name)
        hap = item.data["Histograms"][hist.name]
        item.set_HAP_refinements({"Pref.Ori.": {
            "type": "MD", "axis": list(axis), "ratio": float(hap["Pref.Ori."][1]),
            "refine": True,
        }})
    if uiso:
        for item in project.phases():
            for atom in item.atoms():
                atom.refinement_flags = "U"


def record(project, stage):
    hist = SP.histogram(project)
    covariance = project.data.get("Covariance", {}).get("data", {})
    data = hist.data["data"][1]
    background = np.asarray(data[4], float)
    result = {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "Rp_percent": float(hist.data["data"][0].get("R", np.nan)),
        "GOF": float(covariance.get("Rvals", {}).get("GOF", np.nan)),
        "fractions": SP.mass_fractions(project),
        "instrument": {key: float(hist.InstrumentParameters[key][1]) for key in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {key: float(hist.SampleParameters[key][0]) for key in ("Shift", "SurfRoughA", "SurfRoughB")},
        "cells": {item.name: item.get_cell() for item in project.phases()},
        "sizes_um": {}, "strains_ppm": {}, "texture": {}, "uiso_A2": {},
        "background_min_counts": float(np.min(background)),
        "correlations_abs_ge_0.90": correlations(project),
        **SP.convergence_state(project),
    }
    for item in project.phases():
        hap = item.data["Histograms"][hist.name]
        result["sizes_um"][item.name] = float(hap["Size"][1][0])
        result["strains_ppm"][item.name] = [hap["Mustrain"][0], float(hap["Mustrain"][1][0]), float(hap["Mustrain"][1][1]), list(hap["Mustrain"][3])]
        result["texture"][item.name] = [float(hap["Pref.Ori."][1]), list(hap["Pref.Ori."][3])]
        result["uiso_A2"][item.name] = [float(atom.uiso) for atom in item.atoms()]
    return result


def run(project, label, records, cycles=12, passes=3):
    result = None
    for pass_index in range(passes):
        SP.clear_frozen(project)
        project.set_Controls("cycles", cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
        suffix = "" if passes == 1 else f"_{pass_index + 1}"
        result = record(project, label + suffix)
        records.append(result)
        print(json.dumps(result), flush=True)
        maximum = result.get("max_shift_esd")
        if result.get("converged") and maximum is not None and maximum <= 1.0 and not result.get("frozen"):
            break
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.out.resolve()))
    hist = SP.histogram(project)
    SP.clear_flags(project)
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"] = [110.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    normalize_isotropic_adps(project)
    # Make all phase-breadth starts explicit before any profile development.
    for item in project.phases():
        hap = item.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    reference_cells = {}
    for item in project.phases():
        cell = item.get_cell()
        reference_cells[item.name] = [cell[key] for key in (
            "length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma")]
    install_uiso_equivalences(project)
    install_bounds(project, reference_cells)
    project.save()

    records = []
    accepted_instrument = []
    accepted_sizes = []
    accepted_strains = []
    accepted_textures = {}

    set_flags(project)
    run(project, "shift_cells_scale_background", records, cycles=12)

    for label, additions in (
        ("gaussian", ("U", "W")),
        ("lorentzian", ("X",)),
        ("axial", ("SH/L",)),
        ("polarization", ("Polariz.",)),
    ):
        accepted_instrument.extend(additions)
        set_flags(project, instrument=accepted_instrument)
        run(project, label, records, cycles=12)

    set_flags(project, instrument=accepted_instrument, uiso=True)
    run(project, "phase_uiso", records, cycles=12)

    # Phase sizes are guaranteed specimen terms in this laboratory. Develop
    # them jointly so the common instrument is not assigned to one phase.
    accepted_sizes = [item.name for item in project.phases()]
    set_flags(project, instrument=accepted_instrument, sizes=accepted_sizes, uiso=True)
    run(project, "joint_sizes", records, cycles=12)

    # Isotropic strain is optional; test each phase from a physical interior
    # start. The audit below makes bound proxies explicit for later rollback.
    for item in project.phases():
        hap = item.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 1000.0
        accepted_strains.append(item.name)
        set_flags(project, instrument=accepted_instrument, sizes=accepted_sizes,
                  strains=accepted_strains, uiso=True)
        run(project, f"strain_through_{item.name}", records, cycles=12)

    set_flags(project, instrument=accepted_instrument, sizes=accepted_sizes,
              strains=accepted_strains, textures=accepted_textures, uiso=True)
    run(project, "complete_replay", records, cycles=12, passes=4)
    SP.clear_flags(project)
    project.save()

    summary = {
        "project": str(args.out.resolve()), "source": str(args.source.resolve()),
        "records": records, "final": record(project, "final"),
        "geometry": SP.geometry_profile(project),
        "residual_peaks": residual_peaks(project, 60),
    }
    args.out.with_suffix(".terminal.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"final": summary["final"], "residual": summary["residual_peaks"][:20]}), flush=True)


if __name__ == "__main__":
    main()
