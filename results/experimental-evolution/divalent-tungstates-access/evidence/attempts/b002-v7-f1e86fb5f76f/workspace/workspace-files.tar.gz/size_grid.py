#!/usr/bin/env python3
"""Profile a phase-size parameter on fixed physical values.

This avoids relying on a numerically stalled size derivative for complex
overlapping phases.  At each value only scales, smooth background, cells and
the retained specimen displacement are replayed.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import terminal_olivenite as T
import staged_polish as SP


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--out-dir", required=True, type=Path)
    parser.add_argument("--values", default="0.04,0.06,0.1,0.2,0.3,0.5,0.8,1.2,1.5")
    parser.add_argument("--instrument", default="")
    args = parser.parse_args()
    args.out_dir.mkdir(parents=True, exist_ok=True)
    values = [float(item) for item in args.values.split(",")]
    instrument = [item for item in args.instrument.split(",") if item]
    rows = []
    G2.SetPrintLevel("error")
    for index, value in enumerate(values):
        path = args.out_dir / f"{args.phase}_{index:02d}.gpx"
        project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(path.resolve()))
        hist = SP.histogram(project)
        hap = T.phase(project, args.phase).data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = hap["Size"][1][1] = value
        hap["Size"][2] = [False, False, False]
        T.set_flags(project, instrument=instrument)
        records = []
        T.run(project, f"size_{value:g}", records, cycles=5, passes=1)
        SP.clear_flags(project)
        project.save()
        result = T.record(project, "final")
        rows.append({"value_um": value, "project": str(path.resolve()), "state": result})
        print(json.dumps(rows[-1]), flush=True)
    summary = {"source": str(args.source.resolve()), "phase": args.phase,
               "instrument": instrument, "rows": rows}
    (args.out_dir / f"{args.phase}.size_grid.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
