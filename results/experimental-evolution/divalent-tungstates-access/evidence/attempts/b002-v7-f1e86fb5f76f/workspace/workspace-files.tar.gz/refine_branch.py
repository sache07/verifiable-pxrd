#!/usr/bin/env python3
"""Run one reversible GSAS-II nuisance-term branch from a saved checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import terminal_olivenite as T
import staged_polish as SP
from refine_driver import residual_peaks


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True, type=Path)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--instrument", default="")
    parser.add_argument("--sizes", default="")
    parser.add_argument("--size-start", type=float, default=None)
    parser.add_argument("--strains", default="")
    parser.add_argument("--strain-start", type=float, default=1000.0)
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(args.out.resolve()))
    hist = SP.histogram(project)
    instrument = [item for item in args.instrument.split(",") if item]
    if args.polarization and "Polariz." not in instrument:
        instrument.append("Polariz.")
    sizes = [item for item in args.sizes.split(",") if item]
    strains = [item for item in args.strains.split(",") if item]
    for name in sizes:
        hap = T.phase(project, name).data["Histograms"][hist.name]
        if args.size_start is not None:
            hap["Size"][1][0] = hap["Size"][1][1] = float(args.size_start)
    for name in strains:
        hap = T.phase(project, name).data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = float(args.strain_start)
    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.3, False]
        hist.SampleParameters["SurfRoughB"] = [0.1, False]

    records = []
    T.set_flags(project, instrument=instrument, sizes=sizes, strains=strains,
                roughness=args.roughness)
    T.run(project, "branch", records, cycles=12, passes=4)
    SP.clear_flags(project)
    project.save()
    summary = {
        "source": str(args.source.resolve()), "project": str(args.out.resolve()),
        "instrument": instrument, "sizes": sizes, "strains": strains,
        "roughness": args.roughness, "records": records,
        "final": T.record(project, "final"),
        "residual_peaks": residual_peaks(project, 40),
    }
    args.out.with_suffix(".branch.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({"final": summary["final"], "residual": summary["residual_peaks"][:12]}), flush=True)


if __name__ == "__main__":
    main()
