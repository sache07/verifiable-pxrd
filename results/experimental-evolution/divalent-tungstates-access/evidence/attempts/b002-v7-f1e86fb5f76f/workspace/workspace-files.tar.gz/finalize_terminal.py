#!/usr/bin/env python3
"""Replay the accepted complete model and save a clean terminal checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent / "learned"))
import staged_polish as SP
import terminal_olivenite as T
from refine_driver import residual_peaks


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve())
    )
    hist = SP.histogram(project)
    SP.clear_flags(project)
    SP.reset_limits(project)
    SP.clear_frozen(project)

    # Reassert the retained physical conventions before installing local bounds.
    hist.InstrumentParameters["Zero"][1] = 0.0
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    T.normalize_isotropic_adps(project, 0.005)
    reference_cells = {}
    for item in project.phases():
        cell = item.get_cell()
        reference_cells[item.name] = [cell[key] for key in (
            "length_a", "length_b", "length_c",
            "angle_alpha", "angle_beta", "angle_gamma",
        )]
    T.install_bounds(project, reference_cells)

    records = []
    T.set_flags(
        project,
        instrument=("U", "W", "Polariz."),
        textures={"WO3": (0, 0, 1), "Mn2WO5": (0, 1, 0)},
    )
    T.run(project, "complete_replay", records, cycles=12, passes=4)
    SP.clear_flags(project)
    SP.clear_frozen(project)
    project.save()

    summary = {
        "source": str(args.source.resolve()),
        "project": str(args.output.resolve()),
        "records": records,
        "final": T.record(project, "final"),
        "geometry": SP.geometry_profile(project),
        "residual_peaks": residual_peaks(project, 60),
    }
    args.output.with_suffix(".terminal.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps({
        "final": summary["final"],
        "residual": summary["residual_peaks"][:20],
    }), flush=True)


if __name__ == "__main__":
    main()
