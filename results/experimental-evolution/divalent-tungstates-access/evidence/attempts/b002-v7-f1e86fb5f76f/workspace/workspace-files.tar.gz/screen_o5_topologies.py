#!/usr/bin/env python3
"""Rank complete eight-atom oxide topologies after conversion to Mn2WO5."""

from __future__ import annotations

import gzip
import json
from pathlib import Path
import warnings

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02")
INDEX = ROOT / "index.json.gz"
L1, L2, RATIO = 1.540598, 1.544426, 0.5


def cif_path(identifier: str) -> Path:
    return ROOT / "cif" / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


def profile(x, two_theta, intensity, fwhm=0.20):
    step = float(np.median(np.diff(x)))
    sticks = np.zeros_like(x)
    for wavelength, ratio in ((L1, 1.0), (L2, RATIO)):
        arg = np.sin(np.radians(two_theta / 2)) * wavelength / L1
        valid = (arg > 0) & (arg < 1)
        positions = np.degrees(2 * np.arcsin(arg[valid]))
        indices = np.rint((positions - x[0]) / step).astype(int)
        keep = (indices >= 0) & (indices < len(x))
        np.add.at(sticks, indices[keep], ratio * intensity[valid][keep])
    return gaussian_filter1d(sticks, fwhm / (2.354820045 * step), mode="constant")


def main():
    with np.load(".tmp/hmno_residual.npz") as data:
        x = np.asarray(data["x"], float)
        observed = np.asarray(data["observed"], float)
        residual = observed - np.asarray(data["calculated"], float)
    weights = 1 / np.maximum(observed, 1)
    old_sse = float(np.sum(weights * residual**2))
    denominator = float(np.sum(weights * observed**2))
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)

    entries = []
    for system, rows in index.items():
        for formula, identifier, sg, quality in rows:
            try:
                counts = Composition(formula).reduced_composition.get_el_amt_dict()
            except Exception:
                continue
            if abs(sum(counts.values()) - 8) > 1e-6 or abs(counts.get("O", 0) - 5) > 1e-6:
                continue
            entries.append((system, formula, identifier, sg, quality, counts))

    calculator = XRDCalculator(wavelength=L1)
    scales = np.linspace(0.72, 1.28, 141)
    results = []
    for number, (system, formula, identifier, sg, quality, counts) in enumerate(entries, 1):
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                source = Structure.from_file(cif_path(identifier), primitive=False)
            source.remove_oxidation_states()
            reduced = source.composition.reduced_composition.get_el_amt_dict()
            if abs(sum(reduced.values()) - 8) > 1e-5 or abs(reduced.get("O", 0) - 5) > 1e-5:
                continue
            cations = {key: value for key, value in reduced.items() if key != "O"}
            choices = [key for key, value in cations.items() if abs(value - 1) < 1e-5]
            for w_source in choices:
                target = source.copy()
                target.replace_species({key: ("W" if key == w_source else "Mn") for key in cations})
                if target.composition.reduced_formula != "Mn2WO5":
                    continue
                pattern = calculator.get_pattern(target, two_theta_range=(7, 120), scaled=False)
                base_tt = np.asarray(pattern.x, float)
                base_intensity = np.asarray(pattern.y, float)
                if not len(base_tt) or not np.isfinite(base_intensity).all():
                    continue
                keep = base_intensity >= max(base_intensity) * 2e-4
                base_tt, base_intensity = base_tt[keep], base_intensity[keep]
                d = L1 / (2 * np.sin(np.radians(base_tt / 2)))
                best = None
                for scale in scales:
                    arg = L1 / (2 * d * scale)
                    valid = (arg > 0) & (arg < 1)
                    tt = np.degrees(2 * np.arcsin(arg[valid]))
                    calculated = profile(x, tt, base_intensity[valid])
                    norm = float(np.sum(weights * calculated**2))
                    if norm <= 0:
                        continue
                    amplitude = max(0.0, float(np.sum(weights * calculated * residual)) / norm)
                    gain = amplitude**2 * norm
                    if best is None or gain > best[0]:
                        best = gain, float(scale), amplitude, calculated
                if best is None:
                    continue
                gain, scale, amplitude, calculated = best
                predicted = amplitude * calculated
                results.append({
                    "id": identifier, "formula": formula, "system": system,
                    "space_group_number": sg, "quality": quality,
                    "w_source": w_source, "source_composition": str(source.composition),
                    "source_cell": list(source.lattice.abc) + list(source.lattice.angles),
                    "isotropic_length_scale": scale,
                    "predicted_Rwp_percent": 100 * np.sqrt(max(old_sse - gain, 0) / denominator),
                    "delta_weighted_sse": gain,
                    "strong_predicted_peaks": [
                        [float(x[i]), float(predicted[i]), float(residual[i])]
                        for i in np.argsort(predicted)[-16:][::-1]
                    ],
                })
        except Exception as exc:
            results.append({"id": identifier, "formula": formula, "error": str(exc)})
        if number % 50 == 0:
            print(f"screened {number}/{len(entries)}", flush=True)

    valid = [row for row in results if "predicted_Rwp_percent" in row]
    valid.sort(key=lambda row: row["predicted_Rwp_percent"])
    output = {
        "base_Rwp_percent": 100 * np.sqrt(old_sse / denominator),
        "method": "complete O5 parents converted by crystallographic source-element site to Mn2WO5; isotropic metric screen",
        "results": valid,
        "errors": [row for row in results if "error" in row],
    }
    Path(".tmp/o5_topology_screen.json").write_text(json.dumps(output, indent=2) + "\n")
    for row in valid[:100]:
        print(row["id"], row["formula"], "SG", row["space_group_number"],
              "W<-", row["w_source"], "scale", round(row["isotropic_length_scale"], 4),
              "Rwp", round(row["predicted_Rwp_percent"], 4))


if __name__ == "__main__":
    main()
