#!/usr/bin/env python3
"""Branch one project through equally developed uniaxial microstrain axes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent / "learned"))
import staged_polish as SP
from refine_driver import residual_peaks


AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0))


def setup(project, target_name, axis):
    SP.clear_flags(project)
    SP.enable_scales_and_background(project)
    for name in ("MnWO4", "WO3"):
        next(p for p in project.phases() if p.name == name).set_refinements({"Cell": True})
    hist = SP.histogram(project)
    target = next(p for p in project.phases() if p.name == target_name)
    hap = target.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = list(axis)
    pid = int(target.data["pId"])
    project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMin", 75.0, variable=f"{pid}:0:Mustrain;a")
    project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
    return target, hap


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--phase", required=True)
    parser.add_argument("--outdir", required=True, type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    rows = []
    for axis in AXES:
        tag = "".join(map(str, axis))
        output = args.outdir / f"{args.phase}_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(args.source.resolve()), newgpx=str(output.resolve()))
        target, hap = setup(project, args.phase, axis)
        stages = []
        for index in range(3):
            SP.clear_frozen(project)
            project.set_Controls("cycles", 12)
            project.save()
            project.refine(makeBack=False)
            project.save()
            state = SP.convergence_state(project)
            row = {
                "pass": index + 1, "Rwp_percent": float(SP.histogram(project).get_wR()),
                "fractions": SP.mass_fractions(project),
                "equatorial_ppm": float(hap["Mustrain"][1][0]),
                "axial_ppm": float(hap["Mustrain"][1][1]),
                "ratio": float(hap["Mustrain"][1][1]) / max(float(hap["Mustrain"][1][0]), 1e-12),
                **state,
            }
            stages.append(row)
            print(json.dumps({"axis": axis, **row}), flush=True)
            if row["converged"] and row["max_shift_esd"] is not None and row["max_shift_esd"] <= 1 and not row["frozen"]:
                break
        SP.clear_flags(project)
        project.save()
        rows.append({"axis": axis, "project": str(output.resolve()), "stages": stages,
                     "residual_peaks": residual_peaks(project, 30)})
    summary = {"source": str(args.source.resolve()), "phase": args.phase, "branches": rows}
    (args.outdir / f"{args.phase}.uniaxial.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
