#!/usr/bin/env python3
"""Compare complete phase inventories at identical bounded GSAS-II stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

sys.path.insert(0, str(Path(__file__).resolve().parent / "learned"))
import staged_polish as SP
from refine_driver import residual_peaks, write_data_and_instrument


LAB = {
    "U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
    "SH/L": (0.005, 0.1), "Polariz.": (0.5, 1.0),
    "Zero": (-0.25, 0.25), "Shift": (-800.0, 800.0),
}


def phase_spec(value: str):
    name, rest = value.split("=", 1)
    filename, fraction = rest.rsplit("@", 1)
    path = Path(filename).resolve()
    if not path.is_file():
        raise argparse.ArgumentTypeError(f"missing CIF: {path}")
    fraction = float(fraction)
    if fraction <= 0:
        raise argparse.ArgumentTypeError("starting fraction must be positive")
    return name, path, fraction


def set_flags(project, *, cells=False, instrument=(), sizes=()):
    SP.clear_flags(project)
    SP.enable_scales_and_background(project)
    hist = SP.histogram(project)
    if instrument:
        hist.set_refinements({"Instrument Parameters": list(instrument)})
    if cells:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    selected = set(sizes)
    for phase in project.phases():
        if phase.name in selected:
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "value": phase.data["Histograms"][hist.name]["Size"][1][0], "refine": True}
            })


def install_bounds(project, source_cells):
    project.index_ids()
    hist = SP.histogram(project)
    hid = int(hist.data["data"][0]["hId"])
    for key, limits in LAB.items():
        project.set_Controls("parmMin", limits[0], variable=f":{hid}:{key}")
        project.set_Controls("parmMax", limits[1], variable=f":{hid}:{key}")
    for phase in project.phases():
        pid = int(phase.data["pId"])
        project.set_Controls("parmMin", 1e-9, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        reciprocal = G2lat.cell2A(source_cells[phase.name])
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(0.006 * abs(value), 0.0002)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")


def correlations(project):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(item) for item in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), float)
    if matrix.shape != (len(names), len(names)) or not len(names):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(sigma, sigma)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    rows = []
    for i in range(len(names)):
        for j in range(i):
            value = float(corr[i, j])
            if abs(value) >= 0.90:
                rows.append([names[j], names[i], value])
    return sorted(rows, key=lambda item: abs(item[2]), reverse=True)[:30]


def record(project, stage):
    hist = SP.histogram(project)
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": SP.mass_fractions(project),
        "instrument": {key: float(value[1]) for key, value in hist.InstrumentParameters.items() if key in LAB},
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "sizes_um": {phase.name: float(phase.data["Histograms"][hist.name]["Size"][1][0]) for phase in project.phases()},
        "correlations_abs_ge_0.90": correlations(project),
        **SP.convergence_state(project),
    }


def run(project, stage, records, cycles=10):
    SP.clear_frozen(project)
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    item = record(project, stage)
    records.append(item)
    print(json.dumps(item), flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--inputs", default=Path("inputs"), type=Path)
    parser.add_argument("--phase", action="append", type=phase_spec, required=True)
    parser.add_argument("--background-terms", type=int, default=10)
    args = parser.parse_args()
    total = sum(item[2] for item in args.phase)
    starts = {item[0]: item[2] / total for item in args.phase}

    G2.SetPrintLevel("error")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    data, inst = write_data_and_instrument(args.out.parent / f".{args.out.stem}_inputs", args.inputs.resolve())
    project = G2.G2Project(newgpx=str(args.out.resolve()))
    phases = [project.add_phase(str(path), phasename=name, fmthint="CIF") for name, path, _ in args.phase]
    hist = project.add_powder_histogram(str(data), str(inst), phases="all", fmthint="xye")
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {"type": "chebyschev-1", "no. coeffs": args.background_terms,
                       "coeffs": [1200.0, 400.0] + [0.0] * (args.background_terms - 2), "refine": True},
    })
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]

    source_cells = {}
    for phase in phases:
        cell = phase.get_cell()
        source_cells[phase.name] = [cell[key] for key in (
            "length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma"
        )]
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [100000.0 * starts[phase.name] / float(phase.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = hap["Size"][1][1] = 0.3
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]

    project.set_Controls("cycles", 0)
    project.refine(makeBack=False)
    install_bounds(project, source_cells)
    records = []

    set_flags(project)
    run(project, "scale_background", records, 12)
    set_flags(project, instrument=("Zero",))
    run(project, "zero", records, 8)
    set_flags(project, cells=True, instrument=("Zero",))
    run(project, "bounded_cells", records, 12)
    set_flags(project, cells=True, instrument=("Zero", "U", "W"))
    run(project, "gaussian_profile", records, 10)
    set_flags(project, cells=True, instrument=("Zero", "U", "W", "X"))
    run(project, "lorentzian_profile", records, 10)
    set_flags(project, cells=True, instrument=("Zero", "U", "W", "X", "SH/L"))
    run(project, "axial_profile", records, 10)

    developed_sizes = []
    for phase in phases:
        developed_sizes.append(phase.name)
        set_flags(project, cells=True, instrument=("Zero", "U", "W", "X", "SH/L"), sizes=developed_sizes)
        run(project, f"sizes_through_{phase.name}", records, 10)

    SP.clear_flags(project)
    project.save()
    result = {
        "project": str(args.out.resolve()),
        "phases": [{"name": n, "source": str(p), "start_fraction": starts[n]} for n, p, _ in args.phase],
        "records": records,
        "final": record(project, "final"),
        "geometry": SP.geometry_profile(project),
        "residual_peaks": residual_peaks(project, 60),
    }
    args.out.with_suffix(".phase_set.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"final": result["final"], "residual_peaks": result["residual_peaks"][:15]}), flush=True)


if __name__ == "__main__":
    main()
