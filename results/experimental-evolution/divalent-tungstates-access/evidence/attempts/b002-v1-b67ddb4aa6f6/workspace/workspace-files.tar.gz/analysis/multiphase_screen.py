#!/usr/bin/env python3
"""Screen one added phase against a fixed, stable principal-phase project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gsas_refine import weighted_metrics  # noqa: E402


def phase_record(phase: G2.G2Phase, histname: str) -> dict:
    hap = phase.data["Histograms"][histname]
    return {
        "name": phase.name,
        "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
        "mass": float(phase.data["General"]["Mass"]),
        "scale": float(hap["Scale"][0]),
        "scale_refine": bool(hap["Scale"][1]),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "use": bool(hap.get("Use", True)),
    }


def snapshot(project: G2.G2Project, principal_name: str, trial_name: str) -> dict:
    phases = {p.name: p for p in project.phases()}
    if set(phases) != {principal_name, trial_name}:
        raise RuntimeError(f"Unexpected active phase inventory: {list(phases)}")
    hist = project.histograms()[0]
    records = [phase_record(phases[name], hist.name) for name in [principal_name, trial_name]]
    for record in records:
        if not record["use"] or not np.isfinite(record["scale"]) or record["scale"] < 0:
            raise RuntimeError(f"Invalid active phase record: {record}")
    masses = np.array([r["mass"] * r["scale"] for r in records], float)
    fractions = masses / masses.sum()
    for record, fraction in zip(records, fractions):
        record["weight_fraction"] = float(fraction)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "metrics": weighted_metrics(hist),
        "phases": records,
        "instrument": {
            key: float(inst[key][1])
            for key in ["Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if key in inst
        },
        "sample": {
            key: float(sample[key][0]) if isinstance(sample.get(key), list) else sample.get(key)
            for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
            if key in sample
        },
        "covariance": {
            "Rvals": covariance.get("Rvals", {}),
            "varyList": [str(v) for v in covariance.get("varyList", [])],
        },
    }


def refine(project: G2.G2Project, principal_name: str, trial_name: str, outdir: Path, stage: str) -> dict:
    project.set_Controls("cycles", 10)
    for _ in range(3):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rv.get("converged") and float(rv.get("Max shft/sig", 999.0)) < 1.0:
            break
    result = snapshot(project, principal_name, trial_name)
    cell = next(r["cell"] for r in result["phases"] if r["name"] == trial_name)
    if any(not np.isfinite(v) or v <= 0 for v in cell[:3]) or not np.isfinite(cell[6]) or cell[6] <= 0:
        raise RuntimeError(f"Invalid trial cell: {cell}")
    project.save(outdir / f"{stage}.gpx")
    (outdir / f"{stage}.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def run(base: Path, trial_cif: Path, trial_label: str, outdir: Path) -> dict:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    if len(project.phases()) != 1:
        raise RuntimeError("Base project must contain exactly one principal phase")
    hist = project.histograms()[0]
    principal = project.phases()[0]
    principal_name = principal.name
    principal_hap = principal.data["Histograms"][hist.name]
    if not principal_hap.get("Use", True) or principal_hap["Scale"][0] <= 0:
        raise RuntimeError("Principal phase is not positively active")

    # Freeze the principal phase and common profile at the stable rollback.
    principal.clear_refinements({"Cell": True, "Atoms": []})
    principal.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    project.set_Frozen()

    trial_name = f"trial__{trial_label}"
    trial = project.add_phase(str(trial_cif), phasename=trial_name, histograms=[hist], fmthint="CIF")
    if project.phase(trial_name).name != trial_name:
        raise RuntimeError("Trial phase identity lookup failed")
    trial_hap = trial.data["Histograms"][hist.name]
    mass_ratio = float(principal.data["General"]["Mass"]) / float(trial.data["General"]["Mass"])
    trial_hap["Scale"] = [max(0.20 * principal_hap["Scale"][0] * mass_ratio, 1e-6), True]
    trial_hap["Size"][0] = "isotropic"
    trial_hap["Size"][1][0] = float(principal_hap["Size"][1][0])
    trial_hap["Size"][2] = [False, False, False]
    trial_hap["Mustrain"][0] = "isotropic"
    trial_hap["Mustrain"][1][0] = 0.0
    trial_hap["Mustrain"][2] = [False, False, False]
    trial.set_refinements({"Cell": False})
    principal.set_HAP_refinements({"Scale": True}, [hist])
    hist.set_refinements({"Background": {"refine": True}})
    project.save()

    # Stage A: candidate contribution with all positions fixed.
    refine(project, principal_name, trial_name, outdir, "01_scale")

    # Stage B: symmetry-independent cell terms for the intended candidate only.
    trial.set_refinements({"Cell": True})
    refine(project, principal_name, trial_name, outdir, "02_cell")

    # Stage C: one isotropic phase-profile term, common across every branch.
    project.set_Controls("parmMin", 0.02, "1:0:Size;i")
    project.set_Controls("parmMax", 5.0, "1:0:Size;i")
    trial.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": float(principal_hap["Size"][1][0]), "refine": True}},
        [hist],
    )
    final = refine(project, principal_name, trial_name, outdir, "03_profile")
    project.save(outdir / "screen_final.gpx")
    (outdir / "screen_final.json").write_text(json.dumps(final, indent=2, allow_nan=False) + "\n")
    return final


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("trial_cif", type=Path)
    parser.add_argument("trial_label")
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    result = run(args.base.resolve(), args.trial_cif.resolve(), args.trial_label, args.outdir.resolve())
    print(json.dumps({"metrics": result["metrics"], "phases": result["phases"]}, indent=2))


if __name__ == "__main__":
    main()
