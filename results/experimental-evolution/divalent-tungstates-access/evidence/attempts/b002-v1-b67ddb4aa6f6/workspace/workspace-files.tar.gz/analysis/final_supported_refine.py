#!/usr/bin/env python3
"""Finalize only stable, interior terms from the three-phase refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from joint_three_refine import atoms, snapshot, stage  # noqa: E402


def run(base: Path, outdir: Path):
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    if len(project.phases()) != 3:
        raise RuntimeError("Expected three phases")
    hist = project.histograms()[0]
    principal = next(p for p in project.phases() if p.name.startswith("ZnWO4__"))
    wo3 = next(p for p in project.phases() if "WO3" in p.name)
    zno = next(p for p in project.phases() if p.name.startswith("third__ZnO"))
    ordered = [principal.name, wo3.name, zno.name]
    project.set_Frozen()

    # Keep the stable common profile from the preceding interior solution.
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]}
    )
    project.set_Controls("parmMin", -0.5, ":0:Zero")
    project.set_Controls("parmMax", 0.5, ":0:Zero")
    project.set_Controls("parmMin", -1500.0, ":0:Shift")
    project.set_Controls("parmMax", 1500.0, ":0:Shift")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, ordered, outdir, "01_zero")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    stage(project, ordered, outdir, "02_shift")
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, ordered, outdir, "03_zero")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

    principal.set_refinements(
        {"Atoms": {a["label"]: "X" for a in atoms(principal) if a["element"] != "O"}}
    )
    stage(project, ordered, outdir, "04_principal_cations")
    wo3.set_refinements(
        {"Atoms": {a["label"]: "X" for a in atoms(wo3) if a["element"] != "O"}}
    )
    stage(project, ordered, outdir, "05_wo3_tungsten")
    zno_oxygen = next(a["label"] for a in atoms(zno) if a["element"] == "O")
    zno.set_refinements({"Atoms": {zno_oxygen: "X"}})
    final = stage(project, ordered, outdir, "06_zno_internal", passes=6)

    frozen = project.get_Frozen()
    if frozen:
        raise RuntimeError(f"Final supported model unexpectedly froze parameters: {frozen}")
    project.save()
    shutil.copy2(project.filename, outdir / "refined.gpx")
    (outdir / "refined.json").write_text(json.dumps(final, indent=2, allow_nan=False) + "\n")
    return final


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    result = run(args.base.resolve(), args.outdir.resolve())
    print(json.dumps({"metrics": result["metrics"], "fractions": {p["name"]: p["weight_fraction"] for p in result["phases"]}, "instrument": result["instrument"], "sample": result["sample"]}, indent=2))


if __name__ == "__main__":
    main()
