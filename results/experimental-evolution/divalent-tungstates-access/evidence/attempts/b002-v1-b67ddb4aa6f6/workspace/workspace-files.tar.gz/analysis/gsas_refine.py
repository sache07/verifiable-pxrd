#!/usr/bin/env python3
"""Build and stage GSAS-II single-phase screening refinements.

Run with the GSAS-II Python interpreter. Each candidate gets an independent
project with identical starting histogram, background, instrument and staged
refinement settings.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import shutil
import sys
import traceback

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "analysis" / "pattern.xye"


def instrument_text() -> str:
    return (
        "#GSAS-II instrument parameter file for Cu K-alpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def weighted_metrics(hist: G2.G2PwdrData) -> dict[str, float]:
    arrays = [np.asarray(v, float) for v in hist.data["data"][1]]
    x, yo, w, yc, yb, yd = arrays[:6]
    good = np.isfinite(x + yo + w + yc) & (w > 0)
    num = float(np.sum(w[good] * (yo[good] - yc[good]) ** 2))
    den = float(np.sum(w[good] * yo[good] ** 2))
    rpden = float(np.sum(np.abs(yo[good])))
    return {
        "Rwp_percent": 100.0 * math.sqrt(num / den),
        "Rp_percent": 100.0 * float(np.sum(np.abs(yo[good] - yc[good]))) / rpden,
        "chi2_sum": num,
        "n_points": int(np.sum(good)),
        "max_observed": float(np.max(yo[good])),
        "max_calculated": float(np.max(yc[good])),
        "min_calculated": float(np.min(yc[good])),
        "min_background": float(np.min(yb[good])),
    }


def phase_snapshot(phase: G2.G2Phase, histname: str) -> dict:
    hap = phase.data["Histograms"][histname]
    atoms = []
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    for row in phase.data["Atoms"]:
        atoms.append(
            {
                "label": row[ct - 1],
                "type": row[ct],
                "xyz": [float(v) for v in row[cx : cx + 3]],
                "occupancy": float(row[cx + 3]),
                "uiso": float(row[cia + 1]),
                "refine": row[ct + 1],
            }
        )
    return {
        "name": phase.name,
        "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
        "mass": float(phase.data["General"]["Mass"]),
        "scale": float(hap["Scale"][0]),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": atoms,
    }


def project_snapshot(project: G2.G2Project, expected_phase: str) -> dict:
    phases = project.phases()
    if len(phases) != 1 or phases[0].name != expected_phase:
        raise RuntimeError(
            f"Active phase mismatch: expected {expected_phase!r}, "
            f"found {[p.name for p in phases]}"
        )
    hist = project.histograms()[0]
    phase = phases[0]
    hap = phase.data["Histograms"].get(hist.name)
    if not hap or not hap.get("Use", True):
        raise RuntimeError(f"{expected_phase} is not active in {hist.name}")
    if not np.isfinite(hap["Scale"][0]) or hap["Scale"][0] <= 0:
        raise RuntimeError(f"{expected_phase} has nonpositive scale")
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    return {
        "metrics": weighted_metrics(hist),
        "phase": phase_snapshot(phase, hist.name),
        "instrument": {
            key: float(inst[key][1])
            for key in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if key in inst
        },
        "sample": {
            key: float(sample[key][0]) if isinstance(sample.get(key), list) else sample.get(key)
            for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
            if key in sample
        },
        "background": hist.data["Background"],
        "covariance": {
            "Rvals": covariance.get("Rvals", {}),
            "varyList": [str(v) for v in covariance.get("varyList", [])],
            "sig": [float(v) for v in covariance.get("sig", [])],
        },
    }


def save_snapshot(project: G2.G2Project, expected_phase: str, destination: Path) -> dict:
    snap = project_snapshot(project, expected_phase)
    destination.write_text(json.dumps(snap, indent=2, allow_nan=False) + "\n")
    return snap


def initialize_scale(project: G2.G2Project, phase_name: str) -> None:
    hist = project.histograms()[0]
    phase = project.phase(phase_name)
    project.set_Controls("cycles", 0)
    project.refine()
    arrays = [np.asarray(v, float) for v in hist.data["data"][1]]
    _, yo, w, yc, yb = arrays[:5]
    signal = yc - yb
    good = np.isfinite(yo + w + signal) & (w > 0)
    denom = float(np.sum(w[good] * signal[good] ** 2))
    numer = float(np.sum(w[good] * signal[good] * (yo[good] - yb[good])))
    multiplier = numer / denom if denom > 0 else 1.0
    old = float(phase.data["Histograms"][hist.name]["Scale"][0])
    phase.data["Histograms"][hist.name]["Scale"][0] = max(old * multiplier, 1e-12)
    project.save()


def guarded_refine(
    project: G2.G2Project,
    phase_name: str,
    outdir: Path,
    stage: str,
    cycles: int = 8,
    passes: int = 3,
) -> dict:
    rollback = outdir / f"{stage}_rollback.gpx"
    project.save(rollback)
    project.set_Controls("cycles", cycles)
    try:
        for _ in range(passes):
            project.refine()
            rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
            max_shift = rvals.get("Max shft/sig", np.inf)
            if rvals.get("converged") and np.isfinite(max_shift) and max_shift < 1.0:
                break
        snap = project_snapshot(project, phase_name)
        cell = snap["phase"]["cell"]
        if any((not np.isfinite(v) or v <= 0) for v in cell[:3]) or cell[6] <= 0:
            raise RuntimeError(f"Invalid cell after {stage}: {cell}")
        if snap["metrics"]["min_calculated"] < -1e-6:
            raise RuntimeError(f"Negative calculated intensity after {stage}")
        msg = str(snap["covariance"]["Rvals"].get("msg", ""))
        if "Refinement failed" in msg or "unable to evaluate" in msg:
            raise RuntimeError(f"GSAS-II reported failure after {stage}: {msg}")
        project.save(outdir / f"{stage}.gpx")
        save_snapshot(project, phase_name, outdir / f"{stage}.json")
        return snap
    except Exception:
        (outdir / f"{stage}_failure.txt").write_text(traceback.format_exc())
        raise


def run(candidate: Path, outdir: Path, full: bool) -> dict:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    inst = outdir / "instrument.instprm"
    inst.write_text(instrument_text())
    phase_name = "ZnWO4__" + candidate.stem
    project = G2.G2Project(newgpx=str(outdir / "working.gpx"))
    hist = project.add_powder_histogram(str(DATA), str(inst), fmthint="xye")
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [900.0] + [0.0] * 11,
                "refine": False,
            },
        }
    )
    phase = project.add_phase(
        str(candidate), phasename=phase_name, histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    project.save()
    initialize_scale(project, phase_name)
    save_snapshot(project, phase_name, outdir / "00_initialized.json")

    # Common screen stage 1: only scale and smooth background.
    hist.set_refinements({"Background": {"refine": True}})
    phase.set_HAP_refinements({"Scale": True}, [hist])
    guarded_refine(project, phase_name, outdir, "01_scale_background")

    # Common screen stage 2: cell first, then coordinate-descent between zero
    # and specimen shift. Refining both together is nearly singular.
    phase.set_refinements({"Cell": True})
    guarded_refine(project, phase_name, outdir, "02a_cell")
    project.set_Controls("parmMin", -0.5, ":0:Zero")
    project.set_Controls("parmMax", 0.5, ":0:Zero")
    project.set_Controls("parmMin", -1500.0, ":0:Shift")
    project.set_Controls("parmMax", 1500.0, ":0:Shift")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    guarded_refine(project, phase_name, outdir, "02b_zero_cell")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    guarded_refine(project, phase_name, outdir, "02c_shift_cell")
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    guarded_refine(project, phase_name, outdir, "02d_zero_cell")

    # Common screen stage 3: isotropic profile only. Instrument X and U remain
    # fixed while physically distinct size and microstrain terms are staged.
    project.set_Controls("parmMin", 0.01, ":0:W")
    project.set_Controls("parmMax", 100.0, ":0:W")
    project.set_Controls("parmMin", 0.001, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")
    project.set_Controls("parmMin", 0.02, "0:0:Size;i")
    project.set_Controls("parmMax", 5.0, "0:0:Size;i")
    project.set_Controls("parmMin", 0.0, "0:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, "0:0:Mustrain;i")
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.25, "refine": True}},
        [hist],
    )
    guarded_refine(project, phase_name, outdir, "03a_size_profile", cycles=12)
    phase.set_HAP_refinements(
        {
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    guarded_refine(project, phase_name, outdir, "03b_size_mustrain", cycles=12)
    hist.set_refinements({"Instrument Parameters": ["W"]})
    screen = guarded_refine(project, phase_name, outdir, "03c_isotropic_profile", cycles=12)

    if full:
        # Limited coordinates: cations first, then all symmetry-independent
        # sites. Uiso remains fixed in this pass.
        atom_labels = [a["label"] for a in screen["phase"]["atoms"]]
        cation_labels = [a["label"] for a in screen["phase"]["atoms"] if a["type"] != "O"]
        phase.set_refinements({"Atoms": {label: "X" for label in cation_labels}})
        guarded_refine(project, phase_name, outdir, "04_cation_coordinates", cycles=8)
        phase.set_refinements({"Atoms": {label: "X" for label in atom_labels}})
        guarded_refine(project, phase_name, outdir, "05_all_coordinates", cycles=12)

    project.save(outdir / "screen_final.gpx")
    final = save_snapshot(project, phase_name, outdir / "screen_final.json")
    return final


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()
    result = run(args.candidate.resolve(), args.outdir.resolve(), args.full)
    print(json.dumps(result["metrics"], indent=2))


if __name__ == "__main__":
    main()
