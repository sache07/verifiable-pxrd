#!/usr/bin/env python3
"""Test one uniaxial microstrain direction with a fixed two-phase inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from multiphase_screen import snapshot  # noqa: E402


def run(base: Path, axis: list[int], outdir: Path) -> dict:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    if len(project.phases()) != 2:
        raise RuntimeError("Expected exactly two phases")
    hist = project.histograms()[0]
    principal = next(p for p in project.phases() if p.name.startswith("ZnWO4__"))
    secondary = next(p for p in project.phases() if p.name != principal.name)
    for phase in [principal, secondary]:
        hap = phase.data["Histograms"][hist.name]
        if not hap.get("Use", True) or hap["Scale"][0] <= 0:
            raise RuntimeError(f"Inactive phase: {phase.name}")
    project.set_Frozen()

    principal.set_refinements({"Cell": True})
    principal.set_HAP_refinements(
        {
            "Scale": True,
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {
                "type": "uniaxial",
                "direction": axis,
                "refine": True,
            },
        },
        [hist],
    )
    phap = principal.data["Histograms"][hist.name]
    phap["Mustrain"][1][0] = 1000.0
    phap["Mustrain"][1][1] = 1000.0
    secondary.set_HAP_refinements({"Scale": True}, [hist])
    hist.set_refinements({"Background": {"refine": True}})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    project.set_Controls("parmMin", 0.0, "0:0:Mustrain;i")
    project.set_Controls("parmMax", 20000.0, "0:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, "0:0:Mustrain;a")
    project.set_Controls("parmMax", 20000.0, "0:0:Mustrain;a")
    project.set_Controls("parmMin", 0.02, "0:0:Size;i")
    project.set_Controls("parmMax", 5.0, "0:0:Size;i")
    project.set_Controls("cycles", 12)
    project.save()
    for _ in range(4):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rv.get("converged") and float(rv.get("Max shft/sig", 999.0)) < 1.0:
            break
    result = snapshot(project, principal.name, secondary.name)
    result["axis"] = axis
    result["principal_mustrain"] = principal.data["Histograms"][hist.name]["Mustrain"]
    project.save(outdir / "screen_final.gpx")
    (outdir / "screen_final.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("axis", help="comma-separated h,k,l")
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3 or axis == [0, 0, 0]:
        raise ValueError("Invalid uniaxial direction")
    result = run(args.base.resolve(), axis, args.outdir.resolve())
    print(json.dumps({"metrics": result["metrics"], "mustrain": result["principal_mustrain"]}, indent=2))


if __name__ == "__main__":
    main()
