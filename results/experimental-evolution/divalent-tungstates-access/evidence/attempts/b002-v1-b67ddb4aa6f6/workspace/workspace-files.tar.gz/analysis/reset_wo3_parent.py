#!/usr/bin/env python3
"""Reset the nominated WO3 phase to its exact COD 2311041 coordinates."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


source, destination = map(Path, sys.argv[1:3])
project = G2.G2Project(gpxfile=str(source.resolve()), newgpx=str(destination.resolve()))
matches = [phase for phase in project.phases() if "WO3" in phase.name]
if len(matches) != 1:
    raise RuntimeError(f"Could not select WO3 phase by identity: {[p.name for p in project.phases()]}")
phase = matches[0]
parent = {
    "O6": [0.714, 0.487, 0.721],
    "O2": [0.225, 0.474, 0.007],
    "W1": [0.028, 0.037, 0.746],
    "O5": [0.716, 0.043, 0.708],
    "O3": [0.998, 0.262, 0.712],
    "O1": [0.206, 0.042, 0.995],
    "W2": [0.534, 0.023, 0.750],
    "O4": [0.519, 0.259, 0.789],
}
cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
seen = set()
for atom in phase.data["Atoms"]:
    label = atom[ct - 1]
    if label not in parent:
        raise RuntimeError(f"Unexpected WO3 atom label: {label}")
    atom[cx : cx + 3] = parent[label]
    atom[ct + 1] = " "
    seen.add(label)
if seen != set(parent):
    raise RuntimeError(f"Missing WO3 labels: {set(parent) - seen}")
project.save()
