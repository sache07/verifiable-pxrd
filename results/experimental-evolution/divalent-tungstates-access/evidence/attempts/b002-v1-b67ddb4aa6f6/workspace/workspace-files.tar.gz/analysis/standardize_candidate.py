#!/usr/bin/env python3
"""Write a candidate in pymatgen's conventional standard setting for GSAS-II import."""

from pathlib import Path
import sys

from pymatgen.io.cif import CifWriter
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


source, destination = map(Path, sys.argv[1:3])
structure = Structure.from_file(source, primitive=False)
standard = SpacegroupAnalyzer(structure, symprec=1e-3).get_conventional_standard_structure(
    international_monoclinic=True
)
CifWriter(standard, symprec=1e-3, refine_struct=False).write_file(destination)
check = Structure.from_file(destination, primitive=False)
if check.composition.reduced_formula != "ZnWO4":
    raise RuntimeError(f"Unexpected standardized composition: {check.composition}")
