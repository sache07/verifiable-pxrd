#!/usr/bin/env python3
"""Test WO3 tungsten coordinates within a small source-mismatch envelope."""

from __future__ import annotations

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from joint_three_refine import snapshot, stage  # noqa: E402


base, outdir = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
outdir.mkdir(parents=True, exist_ok=True)
project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
hist = project.histograms()[0]
principal = next(p for p in project.phases() if p.name.startswith("ZnWO4__"))
wo3 = next(p for p in project.phases() if "WO3" in p.name)
zno = next(p for p in project.phases() if p.name.startswith("third__ZnO"))
ordered = [principal.name, wo3.name, zno.name]
for name in ordered:
    hap = project.phase(name).data["Histograms"][hist.name]
    if not hap.get("Use", True) or hap["Scale"][0] <= 0:
        raise RuntimeError(f"Inactive phase: {name}")
project.set_Frozen()

cx, ct, cs, cia = wo3.data["General"]["AtomPtrs"]
labels = [atom[ct - 1] for atom in wo3.data["Atoms"]]
targets = [atom[ct - 1] for atom in wo3.data["Atoms"] if atom[ct].startswith("W")]
if set(targets) != {"W1", "W2"}:
    raise RuntimeError(f"Unexpected WO3 tungsten labels: {targets}")
start = {atom[ct - 1]: np.asarray(atom[cx : cx + 3], float) for atom in wo3.data["Atoms"]}
wo3.set_refinements({"Atoms": {label: "X" for label in targets}})

# Fractional bounds corresponding to at most about 0.08 A along each basis vector.
cell = wo3.data["General"]["Cell"][1:4]
pid = wo3.data["pId"]
for index, atom in enumerate(wo3.data["Atoms"]):
    if atom[ct - 1] not in targets:
        continue
    for axis, length in zip("xyz", cell):
        bound = 0.08 / float(length)
        project.set_Controls("parmMin", -bound, f"{pid}::dA{axis}:{index}")
        project.set_Controls("parmMax", bound, f"{pid}::dA{axis}:{index}")

result = stage(project, ordered, outdir, "screen_final", passes=6)
# Use the refined lattice vectors directly from GSAS cell values.
a, b, c, alpha, beta, gamma = wo3.data["General"]["Cell"][1:7]
ar, br, gr = np.deg2rad([alpha, beta, gamma])
va = np.array([a, 0.0, 0.0])
vb = np.array([b * np.cos(gr), b * np.sin(gr), 0.0])
vc = np.array([c * np.cos(br), c * (np.cos(ar) - np.cos(br) * np.cos(gr)) / np.sin(gr), 0.0])
vc[2] = np.sqrt(max(c * c - vc[0] ** 2 - vc[1] ** 2, 0.0))
lattice = np.vstack([va, vb, vc])
shifts = {}
for atom in wo3.data["Atoms"]:
    label = atom[ct - 1]
    if label not in targets:
        continue
    delta = np.asarray(atom[cx : cx + 3], float) - start[label]
    delta -= np.round(delta)
    shifts[label] = float(np.linalg.norm(delta @ lattice))
result["wo3_tungsten_shift_A"] = shifts
result["frozen"] = [str(v) for v in project.get_Frozen()]
(outdir / "screen_final.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"metrics": result["metrics"], "shifts_A": shifts, "frozen": result["frozen"]}, indent=2))
