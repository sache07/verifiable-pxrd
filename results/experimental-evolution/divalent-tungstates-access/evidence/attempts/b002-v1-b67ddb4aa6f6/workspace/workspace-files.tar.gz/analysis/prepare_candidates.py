#!/usr/bin/env python3
"""Prepare chemically transformed prototype CIFs and GSAS-II input data."""

from pathlib import Path
import re

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def transformed_cif(cod_id: str, substitutions: dict[str, str], output: Path) -> None:
    structure = Structure.from_file(cod_path(cod_id), primitive=False)
    structure.replace_species(substitutions)
    # Retain the detected parent symmetry and site multiplicities.
    CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(output)
    reread = Structure.from_file(output, primitive=False)
    if reread.composition.reduced_formula != "ZnWO4":
        raise ValueError(f"Unexpected composition in {output}: {reread.composition}")
    if min(reread.distance_matrix[np.triu_indices(len(reread), 1)]) < 0.8:
        raise ValueError(f"Hard contact in {output}")


def main() -> None:
    outdir = ROOT / "analysis" / "candidates"
    outdir.mkdir(parents=True, exist_ok=True)

    candidates = {
        "znwo4_from_comoo4_7205001.cif": ("7205001", {"Co": "Zn", "Mo": "W"}),
        "znwo4_from_fenbo4_2002235.cif": ("2002235", {"Fe3+": "Zn2+", "Nb5+": "W6+"}),
        "znwo4_from_mnreo4_2100243.cif": ("2100243", {"Mn": "Zn", "Re": "W"}),
        "znwo4_from_cawo4_1546035.cif": ("1546035", {"Ca": "Zn"}),
        "znwo4_from_hgwo4_2012578.cif": ("2012578", {"Hg": "Zn"}),
        "znwo4_from_bawo4_1527204.cif": ("1527204", {"Ba": "Zn"}),
        "znwo4_from_znmoo4_1528282.cif": ("1528282", {"Mo": "W"}),
    }
    for name, (cod_id, substitutions) in candidates.items():
        transformed_cif(cod_id, substitutions, outdir / name)

    pattern = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    x, y = pattern.T
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(
        ROOT / "analysis" / "pattern.xye",
        np.column_stack((x, y, sigma)),
        fmt=("%.8f", "%.8f", "%.8f"),
        header="two_theta_deg intensity sigma",
        comments="# ",
    )


if __name__ == "__main__":
    main()
