#!/usr/bin/env python3
"""Repair CIF atom-type oxidation-state tokens unsupported by GSAS-II.

Only the atom-site type symbol is changed (for example W+5 -> W and O-2 -> O);
labels, coordinates, occupancies, symmetry and cell are preserved verbatim.
"""

from pathlib import Path
import re


ROOT = Path(__file__).resolve().parents[1]
LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(cod_id: str) -> Path:
    return LIBRARY / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    outdir = ROOT / "analysis" / "repaired_candidates"
    outdir.mkdir(parents=True, exist_ok=True)
    for cod_id in ["1528166", "1538315", "1538317", "2107065"]:
        text = cod_path(cod_id).read_text()
        repaired = re.sub(r"(?m)^(\s*\S+\s+)W\+[0-9]+(?=\s)", r"\1W", text)
        repaired = re.sub(r"(?m)^(\s*\S+\s+)O-[0-9]+(?=\s)", r"\1O", repaired)
        if repaired == text:
            raise RuntimeError(f"No charged atom-site types repaired in {cod_id}")
        (outdir / f"{cod_id}_neutral_types.cif").write_text(repaired)


if __name__ == "__main__":
    main()
