#!/usr/bin/env python3
"""Joint refinement of the supported ZnWO4 + WO3 + ZnO inventory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gsas_refine import weighted_metrics  # noqa: E402


def element(atom_type: str) -> str:
    match = re.match(r"[A-Z][a-z]?", atom_type)
    return match.group(0) if match else atom_type


def atoms(phase):
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    return [
        {
            "label": row[ct - 1],
            "type": row[ct],
            "element": element(row[ct]),
            "xyz": [float(v) for v in row[cx : cx + 3]],
            "occupancy": float(row[cx + 3]),
            "uiso": float(row[cia + 1]),
            "refine": row[ct + 1],
        }
        for row in phase.data["Atoms"]
    ]


def snapshot(project, ordered_names):
    phase_map = {p.name: p for p in project.phases()}
    if set(phase_map) != set(ordered_names):
        raise RuntimeError(f"Unexpected phase inventory: {list(phase_map)}")
    hist = project.histograms()[0]
    records = []
    for name in ordered_names:
        phase = phase_map[name]
        hap = phase.data["Histograms"][hist.name]
        record = {
            "name": name,
            "mass": float(phase.data["General"]["Mass"]),
            "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": atoms(phase),
            "use": bool(hap.get("Use", True)),
        }
        if not record["use"] or not np.isfinite(record["scale"]) or record["scale"] <= 0:
            raise RuntimeError(f"Invalid active phase: {record}")
        records.append(record)
    mass_scales = np.array([r["mass"] * r["scale"] for r in records], float)
    for record, fraction in zip(records, mass_scales / mass_scales.sum()):
        record["weight_fraction"] = float(fraction)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "metrics": weighted_metrics(hist),
        "phases": records,
        "instrument": {
            key: float(inst[key][1])
            for key in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"]
            if key in inst
        },
        "sample": {
            key: float(sample[key][0]) if isinstance(sample.get(key), list) else sample.get(key)
            for key in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
            if key in sample
        },
        "background": hist.data["Background"],
        "covariance": {
            "Rvals": cov.get("Rvals", {}),
            "varyList": [str(v) for v in cov.get("varyList", [])],
            "sig": [float(v) for v in cov.get("sig", [])],
        },
    }


def stage(project, ordered_names, outdir: Path, name: str, passes: int = 4):
    project.set_Controls("cycles", 12)
    for _ in range(passes):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rv.get("converged") and float(rv.get("Max shft/sig", 999.0)) < 1.0:
            break
    result = snapshot(project, ordered_names)
    project.save()
    shutil.copy2(project.filename, outdir / f"{name}.gpx")
    (outdir / f"{name}.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def run(base: Path, outdir: Path):
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    if len(project.phases()) != 3:
        raise RuntimeError("Expected exactly three phases")
    hist = project.histograms()[0]
    principal = next(p for p in project.phases() if p.name.startswith("ZnWO4__"))
    wo3 = next(p for p in project.phases() if "WO3" in p.name)
    zno = next(p for p in project.phases() if p.name.startswith("third__ZnO"))
    ordered = [principal.name, wo3.name, zno.name]
    project.set_Frozen()

    for index, phase in enumerate([principal, wo3, zno]):
        hap = phase.data["Histograms"][hist.name]
        if not hap.get("Use", True) or hap["Scale"][0] <= 0:
            raise RuntimeError(f"Inactive phase: {phase.name}")
        phase.clear_refinements({"Atoms": [a["label"] for a in atoms(phase)]})
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {"Scale": True, "Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][2] = False
        project.set_Controls("parmMin", 0.02, f"{index}:0:Size;i")
        project.set_Controls("parmMax", 5.0, f"{index}:0:Size;i")

    ppo = principal.data["Histograms"][hist.name]["Pref.Ori."]
    ppo[1] = max(float(ppo[1]), 0.7)
    ppo[2] = True
    ppo[3] = [1, 1, 1]
    project.set_Controls("parmMin", 0.5, "0:0:MD")
    project.set_Controls("parmMax", 2.0, "0:0:MD")
    hist.set_refinements({"Background": {"refine": True}})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    project.save()

    stage(project, ordered, outdir, "01_joint_phases")

    project.set_Controls("parmMin", 0.0, ":0:U")
    project.set_Controls("parmMax", 100.0, ":0:U")
    project.set_Controls("parmMin", 0.01, ":0:W")
    project.set_Controls("parmMax", 100.0, ":0:W")
    project.set_Controls("parmMin", 0.001, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    stage(project, ordered, outdir, "02_common_profile")

    # Revisit angular calibration by stable coordinate descent.
    project.set_Controls("parmMin", -0.5, ":0:Zero")
    project.set_Controls("parmMax", 0.5, ":0:Zero")
    project.set_Controls("parmMin", -1500.0, ":0:Shift")
    project.set_Controls("parmMax", 1500.0, ":0:Shift")
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, ordered, outdir, "03_zero")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    stage(project, ordered, outdir, "04_shift")
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, ordered, outdir, "05_zero")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

    # Limited heavy-atom coordinates only; oxygen frameworks stay at the
    # physically screened parent values.
    principal.set_refinements(
        {"Atoms": {a["label"]: "X" for a in atoms(principal) if a["element"] != "O"}}
    )
    stage(project, ordered, outdir, "06_principal_cations")
    wo3.set_refinements(
        {"Atoms": {a["label"]: "X" for a in atoms(wo3) if a["element"] != "O"}}
    )
    stage(project, ordered, outdir, "07_wo3_tungsten")

    # Only the oxygen internal z parameter is independent in wurtzite.
    zno_oxygen = next(a["label"] for a in atoms(zno) if a["element"] == "O")
    zno.set_refinements({"Atoms": {zno_oxygen: "X"}})
    stage(project, ordered, outdir, "08_zno_internal")

    project.set_Controls("parmMin", 0.3, ":0:Polariz.")
    project.set_Controls("parmMax", 1.0, ":0:Polariz.")
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    final = stage(project, ordered, outdir, "09_polarization")
    project.save()
    shutil.copy2(project.filename, outdir / "refined.gpx")
    (outdir / "refined.json").write_text(json.dumps(final, indent=2, allow_nan=False) + "\n")
    return final


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    result = run(args.base.resolve(), args.outdir.resolve())
    print(json.dumps({"metrics": result["metrics"], "fractions": {p["name"]: p["weight_fraction"] for p in result["phases"]}, "instrument": result["instrument"]}, indent=2))


if __name__ == "__main__":
    main()
