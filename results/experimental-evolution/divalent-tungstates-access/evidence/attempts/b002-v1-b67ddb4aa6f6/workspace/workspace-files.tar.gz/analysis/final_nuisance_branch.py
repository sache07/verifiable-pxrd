#!/usr/bin/env python3
"""Test one additional nuisance term from the same supported three-phase project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from joint_three_refine import snapshot, stage  # noqa: E402


def selected_phase(project, key: str):
    predicates = {
        "znwo4": lambda p: p.name.startswith("ZnWO4__"),
        "wo3": lambda p: "WO3" in p.name,
        "zno": lambda p: p.name.startswith("third__ZnO"),
    }
    matches = [p for p in project.phases() if predicates[key](p)]
    if len(matches) != 1:
        raise RuntimeError(f"Could not select {key} by identity: {[p.name for p in project.phases()]}")
    return matches[0]


def run(base: Path, outdir: Path, mode: str, phase_key: str | None, axis: list[int] | None, fixed_value: float | None):
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    hist = project.histograms()[0]
    ordered = [
        selected_phase(project, "znwo4").name,
        selected_phase(project, "wo3").name,
        selected_phase(project, "zno").name,
    ]
    for name in ordered:
        hap = project.phase(name).data["Histograms"][hist.name]
        if not hap.get("Use", True) or hap["Scale"][0] <= 0:
            raise RuntimeError(f"Inactive or nonpositive phase before branch: {name}")
    project.set_Frozen()

    if mode == "baseline":
        pass
    elif mode == "instrument_x":
        project.set_Controls("parmMin", 0.05, ":0:X")
        project.set_Controls("parmMax", 10.0, ":0:X")
        hist.set_refinements({"Instrument Parameters": ["X"]})
    elif mode == "mustrain":
        phase = selected_phase(project, phase_key)
        pid = phase.data["pId"]
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "value": 500.0, "refine": True}}, [hist]
        )
        project.set_Controls("parmMin", 0.0, f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, f"{pid}:0:Mustrain;i")
    elif mode == "texture":
        phase = selected_phase(project, phase_key)
        pid = phase.data["pId"]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, axis
        project.set_Controls("parmMin", 0.5, f"{pid}:0:MD")
        project.set_Controls("parmMax", 2.0, f"{pid}:0:MD")
    elif mode == "roughness":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.3, True]
        sample["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughA")
        project.set_Controls("parmMax", 0.99, ":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, ":0:SurfRoughB")
        project.set_Controls("parmMax", 2.0, ":0:SurfRoughB")
    elif mode == "roughness_a":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.3, True]
        sample["SurfRoughB"] = [fixed_value, False]
        project.set_Controls("parmMin", 0.05, ":0:SurfRoughA")
        project.set_Controls("parmMax", 0.6, ":0:SurfRoughA")
    elif mode == "roughness_b":
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [fixed_value, False]
        sample["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, ":0:SurfRoughB")
    elif mode == "uiso":
        phase = selected_phase(project, phase_key)
        pid = phase.data["pId"]
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        labels = []
        flags = {}
        for atom in phase.data["Atoms"]:
            label = atom[ct - 1]
            labels.append(label)
            flags[label] = "XU" if "X" in atom[ct + 1] else "U"
            atom[cia] = "I"
            atom[cia + 1] = 0.01
        phase.set_refinements({"Atoms": flags})
        variables = [f"{pid}::AUiso:{i}" for i in range(len(labels))]
        project.add_EquivConstr(variables, reloadIdx=True)
        for variable in variables:
            project.set_Controls("parmMin", 0.001, variable)
            project.set_Controls("parmMax", 0.03, variable)
    else:
        raise ValueError(mode)

    result = stage(project, ordered, outdir, "screen_final", passes=6)
    result["branch"] = {"mode": mode, "phase": phase_key, "axis": axis, "fixed_value": fixed_value}
    result["frozen"] = [str(v) for v in project.get_Frozen()]
    (outdir / "screen_final.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("mode", choices=["baseline", "instrument_x", "mustrain", "texture", "roughness", "roughness_a", "roughness_b", "uiso"])
    parser.add_argument("--phase", choices=["znwo4", "wo3", "zno"])
    parser.add_argument("--axis")
    parser.add_argument("--fixed-value", type=float)
    args = parser.parse_args()
    axis = None if args.axis is None else [int(v) for v in args.axis.split(",")]
    if args.mode in {"mustrain", "texture", "uiso"} and args.phase is None:
        parser.error("--phase is required")
    if args.mode == "texture" and (axis is None or len(axis) != 3 or not any(axis)):
        parser.error("--axis h,k,l is required")
    if args.mode in {"roughness_a", "roughness_b"} and args.fixed_value is None:
        parser.error("--fixed-value is required")
    result = run(args.base.resolve(), args.outdir.resolve(), args.mode, args.phase, axis, args.fixed_value)
    print(json.dumps({"metrics": result["metrics"], "branch": result["branch"], "frozen": result["frozen"]}, indent=2))


if __name__ == "__main__":
    main()
