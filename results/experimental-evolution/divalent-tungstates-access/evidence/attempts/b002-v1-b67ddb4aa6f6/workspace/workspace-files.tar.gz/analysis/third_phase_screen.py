#!/usr/bin/env python3
"""Test a third crystalline phase against the mature two-phase rollback."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gsas_refine import weighted_metrics  # noqa: E402


def atom_labels(phase):
    _, ct, _, _ = phase.data["General"]["AtomPtrs"]
    return [row[ct - 1] for row in phase.data["Atoms"]]


def snapshot(project, existing_names, trial_name):
    phases = {p.name: p for p in project.phases()}
    expected = set(existing_names) | {trial_name}
    if set(phases) != expected:
        raise RuntimeError(f"Unexpected inventory: {list(phases)}")
    hist = project.histograms()[0]
    records = []
    for name in [*existing_names, trial_name]:
        phase = phases[name]
        hap = phase.data["Histograms"][hist.name]
        record = {
            "name": name,
            "mass": float(phase.data["General"]["Mass"]),
            "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
            "size": hap["Size"],
            "use": bool(hap.get("Use", True)),
        }
        if not record["use"] or not np.isfinite(record["scale"]) or record["scale"] < 0:
            raise RuntimeError(f"Invalid phase: {record}")
        records.append(record)
    masses = np.array([r["mass"] * r["scale"] for r in records])
    for record, fraction in zip(records, masses / masses.sum()):
        record["weight_fraction"] = float(fraction)
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "metrics": weighted_metrics(hist),
        "phases": records,
        "covariance": {
            "Rvals": cov.get("Rvals", {}),
            "varyList": [str(v) for v in cov.get("varyList", [])],
        },
    }


def refine(project, existing_names, trial_name, outdir, stage):
    project.set_Controls("cycles", 10)
    for _ in range(3):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rv.get("converged") and float(rv.get("Max shft/sig", 999.0)) < 1.0:
            break
    result = snapshot(project, existing_names, trial_name)
    project.save(outdir / f"{stage}.gpx")
    (outdir / f"{stage}.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def run(base: Path, trial_cif: Path, label: str, outdir: Path):
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    if len(project.phases()) != 2:
        raise RuntimeError("Base must have exactly two phases")
    hist = project.histograms()[0]
    existing = project.phases()
    existing_names = [p.name for p in existing]
    project.set_Frozen()
    for phase in existing:
        hap = phase.data["Histograms"][hist.name]
        if not hap.get("Use", True) or hap["Scale"][0] <= 0:
            raise RuntimeError(f"Inactive existing phase: {phase.name}")
        phase.clear_refinements({"Cell": True, "Atoms": atom_labels(phase)})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L"]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": {"refine": True}})

    trial_name = f"third__{label}"
    trial = project.add_phase(str(trial_cif), phasename=trial_name, histograms=[hist], fmthint="CIF")
    if project.phase(trial_name).name != trial_name:
        raise RuntimeError("Trial identity lookup failed")
    thap = trial.data["Histograms"][hist.name]
    # Initialize to two mass percent, explicitly positive.
    existing_mass_scale = sum(
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in existing
    )
    thap["Scale"] = [max(0.02 * existing_mass_scale / trial.data["General"]["Mass"], 1e-8), True]
    thap["Size"][0] = "isotropic"
    thap["Size"][1][0] = 0.1
    thap["Size"][2] = [False, False, False]
    thap["Mustrain"][0] = "isotropic"
    thap["Mustrain"][1][0] = 0.0
    thap["Mustrain"][2] = [False, False, False]
    project.set_Controls("parmMin", 1e-12, "2:0:Scale")
    project.save()

    refine(project, existing_names, trial_name, outdir, "01_scale")
    trial.set_refinements({"Cell": True})
    refine(project, existing_names, trial_name, outdir, "02_cell")
    project.set_Controls("parmMin", 0.02, "2:0:Size;i")
    project.set_Controls("parmMax", 5.0, "2:0:Size;i")
    trial.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.1, "refine": True}}, [hist])
    final = refine(project, existing_names, trial_name, outdir, "03_profile")
    project.save(outdir / "screen_final.gpx")
    (outdir / "screen_final.json").write_text(json.dumps(final, indent=2, allow_nan=False) + "\n")
    return final


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("trial_cif", type=Path)
    parser.add_argument("label")
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    result = run(args.base.resolve(), args.trial_cif.resolve(), args.label, args.outdir.resolve())
    print(json.dumps({"metrics": result["metrics"], "trial": result["phases"][-1]}, indent=2))


if __name__ == "__main__":
    main()
