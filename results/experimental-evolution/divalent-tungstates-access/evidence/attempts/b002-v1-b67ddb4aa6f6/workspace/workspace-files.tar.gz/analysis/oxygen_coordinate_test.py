#!/usr/bin/env python3
"""Diagnostic principal-phase oxygen-coordinate branch from the supported model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from coordinate_refine import lattice_matrix  # noqa: E402
from joint_three_refine import atoms, stage  # noqa: E402


def run(base: Path, outdir: Path, oxygen_label: str | None = None):
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    hist = project.histograms()[0]
    principal = next(p for p in project.phases() if p.name.startswith("ZnWO4__"))
    wo3 = next(p for p in project.phases() if "WO3" in p.name)
    zno = next(p for p in project.phases() if p.name.startswith("third__ZnO"))
    ordered = [principal.name, wo3.name, zno.name]
    project.set_Frozen()
    start = {a["label"]: np.asarray(a["xyz"], float) for a in atoms(principal)}
    oxygen_labels = [a["label"] for a in atoms(principal) if a["element"] == "O"]
    if oxygen_label is not None:
        if oxygen_label not in oxygen_labels:
            raise ValueError(f"Unknown oxygen label {oxygen_label}; choices are {oxygen_labels}")
        oxygen_labels = [oxygen_label]
    principal.set_refinements({"Atoms": {label: "X" for label in oxygen_labels}})
    result = stage(project, ordered, outdir, "oxygen_trial", passes=6)
    matrix = lattice_matrix(result["phases"][0]["cell"])
    shifts = {}
    for atom in result["phases"][0]["atoms"]:
        delta = np.asarray(atom["xyz"]) - start[atom["label"]]
        delta -= np.round(delta)
        shifts[atom["label"]] = float(np.linalg.norm(delta @ matrix))
    result["site_shifts_A"] = shifts
    result["supported_shift_limit_A"] = 0.15
    result["supported"] = max(shifts.values()) <= 0.15
    (outdir / "oxygen_trial.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"metrics": result["metrics"], "site_shifts_A": shifts, "supported": result["supported"]}, indent=2))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--label")
    args = parser.parse_args()
    run(args.base.resolve(), args.outdir.resolve(), args.label)


if __name__ == "__main__":
    main()
