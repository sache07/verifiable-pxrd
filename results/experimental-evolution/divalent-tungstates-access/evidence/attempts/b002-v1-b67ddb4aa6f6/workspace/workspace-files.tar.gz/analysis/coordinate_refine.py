#!/usr/bin/env python3
"""Stage limited atomic-coordinate refinement for a two-phase model."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import re
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from multiphase_screen import snapshot  # noqa: E402


def atom_records(phase: G2.G2Phase) -> list[dict]:
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    return [
        {
            "label": row[ct - 1],
            "type": row[ct],
            "xyz": [float(v) for v in row[cx : cx + 3]],
            "occupancy": float(row[cx + 3]),
            "refine": row[ct + 1],
        }
        for row in phase.data["Atoms"]
    ]


def element_symbol(atom_type: str) -> str:
    match = re.match(r"[A-Z][a-z]?", atom_type)
    return match.group(0) if match else atom_type


def lattice_matrix(cell: list[float]) -> np.ndarray:
    a, b, c, alpha, beta, gamma = cell[:6]
    ar, br, gr = np.deg2rad([alpha, beta, gamma])
    va = np.array([a, 0.0, 0.0])
    vb = np.array([b * np.cos(gr), b * np.sin(gr), 0.0])
    cx = c * np.cos(br)
    cy = c * (np.cos(ar) - np.cos(br) * np.cos(gr)) / np.sin(gr)
    cz = math.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.vstack((va, vb, [cx, cy, cz]))


def max_site_shift(start: dict[str, np.ndarray], phase: G2.G2Phase) -> float:
    cell = [float(v) for v in phase.data["General"]["Cell"][1:]]
    matrix = lattice_matrix(cell)
    shifts = []
    for atom in atom_records(phase):
        if atom["label"] not in start:
            continue
        delta = np.asarray(atom["xyz"]) - start[atom["label"]]
        delta -= np.round(delta)
        shifts.append(float(np.linalg.norm(delta @ matrix)))
    return max(shifts, default=0.0)


def refine_stage(
    project: G2.G2Project,
    principal: G2.G2Phase,
    secondary: G2.G2Phase,
    outdir: Path,
    stage: str,
    starts: dict[str, dict[str, np.ndarray]],
) -> dict:
    project.set_Controls("cycles", 12)
    for _ in range(4):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rv.get("converged") and float(rv.get("Max shft/sig", 999.0)) < 1.0:
            break
    result = snapshot(project, principal.name, secondary.name)
    result["atoms"] = {
        principal.name: atom_records(principal),
        secondary.name: atom_records(secondary),
    }
    result["max_site_shift_A"] = {
        principal.name: max_site_shift(starts[principal.name], principal),
        secondary.name: max_site_shift(starts[secondary.name], secondary),
    }
    if result["max_site_shift_A"][principal.name] > 0.45:
        raise RuntimeError(f"Principal coordinate divergence in {stage}: {result['max_site_shift_A']}")
    if result["max_site_shift_A"][secondary.name] > 0.45:
        raise RuntimeError(f"Secondary coordinate divergence in {stage}: {result['max_site_shift_A']}")
    project.save(outdir / f"{stage}.gpx")
    (outdir / f"{stage}.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def run(base: Path, outdir: Path, cations_only: bool = False) -> dict:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    if len(project.phases()) != 2:
        raise RuntimeError("Expected exactly two phases")
    principal = next(p for p in project.phases() if p.name.startswith("ZnWO4__"))
    secondary = next(p for p in project.phases() if p.name != principal.name)
    hist = project.histograms()[0]
    for phase in [principal, secondary]:
        hap = phase.data["Histograms"][hist.name]
        if not hap.get("Use", True) or hap["Scale"][0] <= 0:
            raise RuntimeError(f"Inactive phase: {phase.name}")
    starts = {
        phase.name: {a["label"]: np.asarray(a["xyz"], float) for a in atom_records(phase)}
        for phase in [principal, secondary]
    }
    project.set_Frozen()

    principal_cations = [
        a["label"] for a in atom_records(principal) if element_symbol(a["type"]) != "O"
    ]
    secondary_cations = [
        a["label"] for a in atom_records(secondary) if element_symbol(a["type"]) != "O"
    ]
    principal_oxygens = [
        a["label"] for a in atom_records(principal) if element_symbol(a["type"]) == "O"
    ]

    principal.set_refinements({"Atoms": {label: "X" for label in principal_cations}})
    refine_stage(project, principal, secondary, outdir, "01_principal_cations", starts)

    secondary.set_refinements({"Atoms": {label: "X" for label in secondary_cations}})
    cation_result = refine_stage(project, principal, secondary, outdir, "02_secondary_cations", starts)

    if cations_only:
        project.save(outdir / "refined.gpx")
        (outdir / "refined.json").write_text(
            json.dumps(cation_result, indent=2, allow_nan=False) + "\n"
        )
        return cation_result

    principal.set_refinements({"Atoms": {label: "X" for label in principal_oxygens}})
    final = refine_stage(project, principal, secondary, outdir, "03_principal_oxygen", starts)
    project.save(outdir / "refined.gpx")
    (outdir / "refined.json").write_text(json.dumps(final, indent=2, allow_nan=False) + "\n")
    return final


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--cations-only", action="store_true")
    args = parser.parse_args()
    result = run(args.base.resolve(), args.outdir.resolve(), args.cations_only)
    print(json.dumps({"metrics": result["metrics"], "max_site_shift_A": result["max_site_shift_A"]}, indent=2))


if __name__ == "__main__":
    main()
