#!/usr/bin/env python3
"""Refine positional calibration and identifiable common profile terms in stages."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from multiphase_screen import snapshot  # noqa: E402


def stage(project, principal, secondary, outdir: Path, name: str) -> dict:
    project.set_Controls("cycles", 12)
    for _ in range(4):
        project.refine()
        rv = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        if rv.get("converged") and float(rv.get("Max shft/sig", 999.0)) < 1.0:
            break
    result = snapshot(project, principal.name, secondary.name)
    project.save(outdir / f"{name}.gpx")
    (outdir / f"{name}.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def run(base: Path, outdir: Path) -> dict:
    G2.SetPrintLevel("warn")
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(outdir / "working.gpx"))
    if len(project.phases()) != 2:
        raise RuntimeError("Expected exactly two phases")
    hist = project.histograms()[0]
    principal = next(p for p in project.phases() if p.name.startswith("ZnWO4__"))
    secondary = next(p for p in project.phases() if p.name != principal.name)
    project.set_Frozen()
    project.set_Controls("parmMin", -0.5, ":0:Zero")
    project.set_Controls("parmMax", 0.5, ":0:Zero")
    project.set_Controls("parmMin", -1500.0, ":0:Shift")
    project.set_Controls("parmMax", 1500.0, ":0:Shift")
    project.set_Controls("parmMin", 0.0, ":0:U")
    project.set_Controls("parmMax", 100.0, ":0:U")
    project.set_Controls("parmMin", 0.01, ":0:W")
    project.set_Controls("parmMax", 100.0, ":0:W")
    project.set_Controls("parmMin", 0.001, ":0:SH/L")
    project.set_Controls("parmMax", 0.2, ":0:SH/L")

    # Coordinate descent avoids the near-singularity of simultaneous zero and shift.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, principal, secondary, outdir, "01_zero")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    stage(project, principal, secondary, outdir, "02_shift")
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, principal, secondary, outdir, "03_zero")
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

    hist.set_refinements({"Instrument Parameters": ["W"]})
    stage(project, principal, secondary, outdir, "04_W")
    hist.set_refinements({"Instrument Parameters": ["U"]})
    stage(project, principal, secondary, outdir, "05_UW")
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    final = stage(project, principal, secondary, outdir, "06_UW_SHL")
    project.save(outdir / "refined.gpx")
    (outdir / "refined.json").write_text(json.dumps(final, indent=2, allow_nan=False) + "\n")
    return final


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    result = run(args.base.resolve(), args.outdir.resolve())
    print(json.dumps({"metrics": result["metrics"], "instrument": result["instrument"], "sample": result["sample"]}, indent=2))


if __name__ == "__main__":
    main()
