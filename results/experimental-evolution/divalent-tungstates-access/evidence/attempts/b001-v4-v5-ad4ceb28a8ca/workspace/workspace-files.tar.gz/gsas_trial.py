#!/usr/bin/env python3
"""Apply one physically scoped GSAS-II refinement trial to a checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def parse_assignment(text: str) -> tuple[str, float]:
    name, value = text.rsplit("=", 1)
    return name, float(value)


def set_bound(project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--uiso", action="append", default=[])
    parser.add_argument("--refine-uiso")
    parser.add_argument("--instrument", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--size")
    parser.add_argument("--fix-size", action="append", default=[])
    parser.add_argument("--strain")
    parser.add_argument("--fix-strain", action="append", default=[])
    parser.add_argument("--fix-instrument", action="append", default=[])
    parser.add_argument(
        "--uniaxial-strain", nargs=4, metavar=("PHASE", "H", "K", "L")
    )
    parser.add_argument(
        "--set-uniaxial-strain",
        nargs=6,
        metavar=("PHASE", "H", "K", "L", "EQUATORIAL", "AXIAL"),
    )
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--po", nargs=4, metavar=("PHASE", "H", "K", "L"))
    parser.add_argument(
        "--coordinate", nargs=3, metavar=("PHASE", "ATOM_LABEL", "WINDOW")
    )
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(Path(args.input).resolve()), newgpx=str(output))
    project.set_Controls("cycles", 18)
    project.set_Frozen()  # stale coordinate-limit freezes are no longer active
    hist = project.histogram(0)

    # A trial after coordinate refinement must not silently continue varying
    # atom positions. Explicit coordinate trials use a different script.
    for ph in project.phases():
        ph.set_refinements({"Atoms": {"all": " "}})

    for assignment in args.uiso:
        name, value = parse_assignment(assignment)
        if not 0.003 <= value <= 0.02:
            raise ValueError(f"Uiso outside physical range: {assignment}")
        for atom in project.phase(name).atoms():
            atom.uiso = value
            atom.refinement_flags = " "

    if args.refine_uiso:
        ph = project.phase(args.refine_uiso)
        for i, atom in enumerate(ph.atoms()):
            atom.refinement_flags = "U"
            set_bound(project, f"{ph.id}::AUiso:{i}", 0.003, 0.03)

    if args.instrument:
        hist.set_refinements(
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
        )
        for variable, low, high in [
            (":0:U", 0.0, 40.0),
            (":0:W", 2.0, 40.0),
            (":0:X", 0.1, 6.0),
            (":0:SH/L", 0.005, 0.10),
        ]:
            set_bound(project, variable, low, high)

    for name in args.fix_instrument:
        if name not in hist.InstrumentParameters:
            raise ValueError(f"Unknown instrument parameter: {name}")
        hist.InstrumentParameters[name][2] = False

    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        set_bound(project, ":0:Polariz.", 0.5, 1.0)

    if args.size:
        ph = project.phase(args.size)
        ph.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        set_bound(project, f"{ph.id}:{hist.id}:Size;i", 0.04, 1.5)

    for name in args.fix_size:
        project.phase(name).clear_HAP_refinements({"Size": True}, [hist])

    if args.strain:
        ph = project.phase(args.strain)
        ph.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
        set_bound(project, f"{ph.id}:{hist.id}:Mustrain;i", 300.0, 8000.0)

    for name in args.fix_strain:
        project.phase(name).clear_HAP_refinements({"Mustrain": True}, [hist])

    if args.uniaxial_strain:
        name, h, k, l = args.uniaxial_strain
        ph = project.phase(name)
        hap = ph.data["Histograms"][hist.name]["Mustrain"]
        # Start the axial term at the current isotropic value so the trial is
        # nested in, and directly comparable with, the accepted model.
        hap[1][1] = hap[1][0]
        ph.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": [int(h), int(k), int(l)],
                    "refine": True,
                }
            },
            [hist],
        )
        set_bound(project, f"{ph.id}:{hist.id}:Mustrain;i", 300.0, 8000.0)
        set_bound(project, f"{ph.id}:{hist.id}:Mustrain;a", 300.0, 8000.0)

    if args.set_uniaxial_strain:
        name, h, k, l, equat, axial = args.set_uniaxial_strain
        ph = project.phase(name)
        hap = ph.data["Histograms"][hist.name]["Mustrain"]
        hap[0] = "uniaxial"
        hap[1][0] = float(equat)
        hap[1][1] = float(axial)
        hap[2][0] = False
        hap[2][1] = False
        hap[3] = [int(h), int(k), int(l)]

    if args.roughness:
        hist.SampleParameters["SurfRoughA"][0] = 0.20
        hist.SampleParameters["SurfRoughB"][0] = 0.10
        hist.set_refinements(
            {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
        )
        set_bound(project, f":{hist.id}:SurfRoughA", 0.05, 0.60)
        set_bound(project, f":{hist.id}:SurfRoughB", 0.02, 0.50)

    if args.po:
        name, h, k, l = args.po
        ph = project.phase(name)
        hap = ph.data["Histograms"][hist.name]["Pref.Ori."]
        hap[0] = "MD"
        hap[1] = 1.0
        hap[2] = True
        hap[3] = [int(h), int(k), int(l)]
        set_bound(project, f"{ph.id}:{hist.id}:MD", 0.7, 1.4)

    if args.coordinate:
        name, label, window = args.coordinate
        ph = project.phase(name)
        atom = ph.atom(label)
        if atom is None:
            raise ValueError(f"Atom {label!r} not found in phase {name!r}")
        atom.refinement_flags = "X"
        atom_index = next(i for i, item in enumerate(ph.atoms()) if item.label == label)
        delta = float(window)
        for axis, value in zip("xyz", atom.coordinates):
            set_bound(
                project,
                f"{ph.id}::dA{axis}:{atom_index}",
                float(value) - delta,
                float(value) + delta,
            )

    project.save(str(output))
    project.refine(makeBack=False)

    result = {
        "output": str(output),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for ph in project.phases():
        hap = ph.data["Histograms"][hist.name]
        result["phases"][ph.name] = {
            "cell": ph.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": a.label,
                    "element": a.element,
                    "xyz": a.coordinates,
                    "uiso": a.uiso,
                }
                for a in ph.atoms()
            ],
        }
    summary = output.with_suffix(".json")
    with summary.open("w") as stream:
        json.dump(result, stream, indent=2, default=float)
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
