#!/usr/bin/env python3
"""Read-only diagnostics for the accepted full-grid GSAS-II checkpoint."""

from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2sc


project = G2sc.G2Project(str(Path(".tmp/three_phase/clean.gpx").resolve()))
hist = project.histogram(0)
x = np.asarray(hist.getdata("x"), dtype=float)
yobs = np.asarray(hist.getdata("yobs"), dtype=float)
ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
residual = yobs - ycalc
z = gaussian_filter1d(residual / np.sqrt(np.maximum(yobs, 1.0)), 1.5)

# Positive residual maxima are inspected only as a family audit. Isolated
# Poisson excursions are expected; an omitted phase would give several
# separated, consistently unmatched maxima.
indices, properties = find_peaks(z, height=2.2, prominence=1.5, distance=7)
order = indices[np.argsort(z[indices])[::-1]]

reflection_positions = {}
for name, block in hist.reflections().items():
    values = np.asarray(block["RefList"])
    reflection_positions[name] = np.asarray(values[:, 5], dtype=float)

print("histogram", hist.name)
print("residuals", hist.residuals)
print("mass_fractions", hist.ComputeMassFracs())
print("positive residual maxima (top 30)")
for i in order[:30]:
    nearest = []
    for name, positions in reflection_positions.items():
        j = int(np.argmin(np.abs(positions - x[i])))
        nearest.append((abs(float(positions[j] - x[i])), name, float(positions[j])))
    delta, name, position = min(nearest)
    print(
        f"{x[i]:9.4f}  z={z[i]:6.2f}  obs-calc={residual[i]:8.1f}  "
        f"nearest={name}:{position:9.4f}  delta={delta:7.4f}"
    )

unmatched = []
for i in order:
    delta = min(
        float(np.min(np.abs(positions - x[i])))
        for positions in reflection_positions.values()
    )
    if delta > 0.18:
        unmatched.append((float(x[i]), float(z[i]), float(residual[i]), delta))
print("unmatched_over_0.18_deg", unmatched)
