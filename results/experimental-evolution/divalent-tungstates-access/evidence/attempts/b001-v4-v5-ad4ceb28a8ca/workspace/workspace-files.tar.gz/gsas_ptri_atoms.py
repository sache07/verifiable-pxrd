#!/usr/bin/env python3
"""Comparable bounded atom-coordinate trials for the triclinic WO3 branch."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/ptri_three_phase/candidate.gpx"
OUT = ROOT / ".tmp/ptri_atoms"


def set_coordinate_bounds(project, phase, indices, window):
    for i in indices:
        xyz = phase.atoms()[i].coordinates
        for axis, value in zip("xyz", xyz):
            variable = f"{phase.id}::dA{axis}:{i}"
            project.set_Controls("parmMin", value - window, variable=variable)
            project.set_Controls("parmMax", value + window, variable=variable)


def refine_stage(project, hist, filename):
    path = OUT / filename
    project.save(str(path))
    project.refine(makeBack=False)
    print(filename, hist.residuals, "frozen", project.get_Frozen())
    return path


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})

    w_indices = [i for i, atom in enumerate(wo3.atoms()) if atom.element == "W"]
    for i in w_indices:
        wo3.atoms()[i].refinement_flags = "X"
    set_coordinate_bounds(project, wo3, w_indices, 0.015)
    heavy_path = refine_stage(project, hist, "01_heavy_W.gpx")
    for i in w_indices:
        wo3.atoms()[i].refinement_flags = " "
    for phase in project.phases():
        phase.export_CIF(str(OUT / f"01_{phase.name}.cif"))

    # Two coordinates in the lower-symmetry model reached the deliberately
    # broad parent window. Treat those sites as unsupported rather than as an
    # optimum, fix their complete positions, and replay the remaining heavy
    # sites to obtain a clean comparison checkpoint.
    limited_sites = {
        int(str(variable).rsplit(":", 1)[1])
        for variable in project.get_Frozen()
        if str(variable).startswith(f"{wo3.id}::dA")
    }
    project.set_Frozen()
    supported_w = [i for i in w_indices if i not in limited_sites]
    for i in supported_w:
        wo3.atoms()[i].refinement_flags = "X"
    set_coordinate_bounds(project, wo3, supported_w, 0.008)
    heavy_path = refine_stage(project, hist, "01b_heavy_clean.gpx")
    for i in supported_w:
        wo3.atoms()[i].refinement_flags = " "
    for phase in project.phases():
        phase.export_CIF(str(OUT / f"01b_{phase.name}.cif"))

    heavy = {
        "path": str(heavy_path),
        "fixed_limit_sites": sorted(limited_sites),
        "residuals": dict(hist.residuals),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "wo3_atoms": [
            {"label": atom.label, "element": atom.element, "xyz": atom.coordinates}
            for atom in wo3.atoms()
        ],
    }

    # This is a topology-coverage trial, not an automatically accepted model.
    # Refine all independent oxygen orbits only to test whether the topology
    # needs a supported light-atom relaxation; geometry decides acceptance.
    project.set_Frozen()
    o_indices = [i for i, atom in enumerate(wo3.atoms()) if atom.element == "O"]
    for i in o_indices:
        wo3.atoms()[i].refinement_flags = "X"
    set_coordinate_bounds(project, wo3, o_indices, 0.008)
    oxygen_path = refine_stage(project, hist, "02_oxygen_trial.gpx")
    for phase in project.phases():
        phase.export_CIF(str(OUT / f"02_{phase.name}.cif"))
    oxygen = {
        "path": str(oxygen_path),
        "residuals": dict(hist.residuals),
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "wo3_atoms": [
            {"label": atom.label, "element": atom.element, "xyz": atom.coordinates}
            for atom in wo3.atoms()
        ],
    }
    with (OUT / "summary.json").open("w") as stream:
        json.dump({"heavy": heavy, "oxygen_trial": oxygen}, stream, indent=2, default=float)


if __name__ == "__main__":
    main()
