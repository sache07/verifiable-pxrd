#!/usr/bin/env python3
"""Comparable physical relaxation of the triclinic WO3 topology branch."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


WORK = Path.cwd()
SRC = WORK / ".tmp/branches/wo3_ptri_2106293/final_branch.gpx"
OUT = WORK / ".tmp/ptri_comparison"


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(SRC), newgpx=str(OUT / "physical.gpx"))
    project.set_Controls("cycles", 20)
    project.set_Frozen()
    hist = project.histogram(0)
    ca = project.phase("CaWO4")
    wo = project.phase("WO3")
    for ph in project.phases():
        ph.set_refinements({"Atoms": {"all": " "}})
        ph.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])

    # Use the same accepted strong-phase structure and ADPs in both topology
    # comparisons so only WO3 topology is being tested.
    ca.atom("O1").coordinates = (0.1494957566, 0.0014785934, 0.2087637237)
    for atom, uiso in zip(ca.atoms(), (0.0138355702, 0.0136499205, 0.0118149860)):
        atom.uiso = uiso
    for atom in wo.atoms():
        atom.uiso = 0.003

    inst = hist.InstrumentParameters
    for name, value in {
        "Zero": -0.25,
        "Polariz.": 0.7266,
        "U": 15.6,
        "W": 2.08,
        "X": 5.52,
        "SH/L": 0.0383,
    }.items():
        inst[name][0] = value
        inst[name][1] = value
    hist.SampleParameters["Shift"][0] = 150.0
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements(
        {"Instrument Parameters": ["Polariz.", "U", "W", "X", "SH/L"]}
    )
    for variable, low, high in [
        (":0:Polariz.", 0.5, 1.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Shift", -800.0, 800.0),
    ]:
        bound(project, variable, low, high)

    ca_hap = ca.data["Histograms"][hist.name]
    wo_hap = wo.data["Histograms"][hist.name]
    ca_hap["Size"][0] = "isotropic"
    ca_hap["Size"][1][0] = 0.0754
    ca_hap["Size"][2][0] = True
    ca_hap["Mustrain"][0] = "isotropic"
    ca_hap["Mustrain"][1][0] = 300.0
    ca_hap["Mustrain"][2][0] = False
    wo_hap["Size"][0] = "isotropic"
    wo_hap["Size"][1][0] = 1.5
    wo_hap["Size"][2][0] = False
    wo_hap["Mustrain"][0] = "isotropic"
    wo_hap["Mustrain"][1][0] = 500.0
    wo_hap["Mustrain"][2][0] = True
    bound(project, "0:0:Size;i", 0.04, 1.5)
    bound(project, "1:0:Size;i", 0.04, 1.5)
    bound(project, "1:0:Mustrain;i", 300.0, 8000.0)

    project.save(str(OUT / "physical.gpx"))
    project.refine(makeBack=False)
    result = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "frozen": project.get_Frozen(),
        "cells": {ph.name: ph.get_cell() for ph in project.phases()},
        "profiles": {
            ph.name: {
                "size": ph.data["Histograms"][hist.name]["Size"],
                "mustrain": ph.data["Histograms"][hist.name]["Mustrain"],
            }
            for ph in project.phases()
        },
    }
    with (OUT / "summary.json").open("w") as stream:
        json.dump(result, stream, indent=2, default=float)
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
