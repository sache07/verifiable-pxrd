#!/usr/bin/env python3
"""Physically bounded coordinate refinement from the accepted two-phase fit."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


WORK = Path.cwd()
SOURCE = WORK / ".tmp/branches/wo3_p21c_2311041/06_phase_size.gpx"
OUT = WORK / ".tmp/physical_coordinates_v2"


def set_inst_value(entry, value: float) -> None:
    entry[0] = float(value)
    entry[1] = float(value)


def set_sample_value(entry, value: float) -> None:
    entry[0] = float(value)


def save_stage(project, hist, label: str) -> None:
    # Save to a new filename before refinement. GSAS-II refines in place, so
    # this keeps every preceding rollback point immutable.
    project.save(str(OUT / f"{label}.gpx"))
    project.refine(makeBack=False)
    print(f"STAGE {label}: {hist.residuals}")


def bound_coordinates(project, phase, atom_indices, limit=0.02):
    # GSAS-II names coordinate increments dAx/dAy/dAz, but its parameter-limit
    # check applies those limits to the resulting absolute Ax/Ay/Az values.
    for atom_index in atom_indices:
        xyz = phase.atoms()[atom_index].coordinates
        for axis, value in zip("xyz", xyz):
            var = f"{phase.id}::dA{axis}:{atom_index}"
            project.set_Controls(
                "parmMin", float(value) - float(limit), variable=var
            )
            project.set_Controls(
                "parmMax", float(value) + float(limit), variable=var
            )


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    project.set_Controls("cycles", 15)
    hist = project.histogram(0)
    cawo4 = project.phase("CaWO4")
    wo3 = project.phase("WO3")

    # Re-enter the physically allowed calibration/profile region before any
    # coordinates are varied. Zero and Shift are nearly collinear, so fix Zero
    # at the edge of its independently known range and refine Shift/cells.
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"],
        }
    )
    set_inst_value(hist.InstrumentParameters["Zero"], -0.25)
    set_inst_value(hist.InstrumentParameters["X"], 6.0)
    set_sample_value(hist.SampleParameters["Shift"], 250.0)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for ph in project.phases():
        ph.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
        ph.set_refinements({"Atoms": {"all": " "}})
    # A size above the lab range is indistinguishable from negligible size
    # broadening; use the physical upper bound until the later profile stage.
    wo3.data["Histograms"][hist.name]["Size"][1][0] = 1.5
    save_stage(project, hist, "01_calibration_cells")

    # Heavy-atom coordinates: only WO3 has non-special-position W sites.
    w_indices = []
    for i, atom in enumerate(wo3.atoms()):
        if atom.element == "W":
            atom.refinement_flags = "X"
            w_indices.append(i)
    bound_coordinates(project, wo3, w_indices, limit=0.015)
    save_stage(project, hist, "02_heavy_W")
    for i in w_indices:
        wo3.atoms()[i].refinement_flags = " "

    # Strong scheelite phase: refine its single oxygen orbit first.
    ca_o_indices = []
    for i, atom in enumerate(cawo4.atoms()):
        if atom.element == "O":
            atom.refinement_flags = "X"
            ca_o_indices.append(i)
    bound_coordinates(project, cawo4, ca_o_indices, limit=0.02)
    save_stage(project, hist, "03_CaWO4_O")
    for i in ca_o_indices:
        cawo4.atoms()[i].refinement_flags = " "

    # Light atoms in the secondary WO3 phase are a separate rollback point.
    wo_o_indices = []
    for i, atom in enumerate(wo3.atoms()):
        if atom.element == "O":
            atom.refinement_flags = "X"
            wo_o_indices.append(i)
    bound_coordinates(project, wo3, wo_o_indices, limit=0.015)
    save_stage(project, hist, "04_WO3_O")
    for i in wo_o_indices:
        wo3.atoms()[i].refinement_flags = " "

    project.save(str(OUT / "coordinate_candidate.gpx"))
    summary = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "cells": {ph.name: ph.get_cell() for ph in project.phases()},
        "atoms": {
            ph.name: [
                {
                    "label": a.label,
                    "element": a.element,
                    "xyz": a.coordinates,
                    "uiso": a.uiso,
                }
                for a in ph.atoms()
            ]
            for ph in project.phases()
        },
        "frozen": project.get_Frozen(),
    }
    with (OUT / "summary.json").open("w") as stream:
        json.dump(summary, stream, indent=2, default=float)
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
