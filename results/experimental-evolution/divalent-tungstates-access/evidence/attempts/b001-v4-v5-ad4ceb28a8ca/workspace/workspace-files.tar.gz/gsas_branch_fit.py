#!/usr/bin/env python3
"""Build and stage a comparable GSAS-II fit for a supplied COD phase set.

Run with the GSAS-II Python interpreter. This script is intentionally limited
to the common scale/background, calibration/cell and profile stages used for
phase-topology comparison. Structural-coordinate and specimen-effect tests are
performed from the best checkpoint in a separate script.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def parse_phase(text: str) -> tuple[str, str, float]:
    cod_id, name, size = text.split(":", 2)
    return cod_id, name, float(size)


def initialize_background(hist, ncoef: int = 18) -> None:
    x = np.asarray(hist.getdata("x"), dtype=float)
    y = np.asarray(hist.getdata("yobs"), dtype=float)
    baseline = percentile_filter(y, percentile=18, size=301, mode="nearest")
    xpos = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    coeffs = np.polynomial.chebyshev.chebfit(xpos, baseline, ncoef - 1)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": ncoef,
                "coeffs": [float(v) for v in coeffs],
            }
        }
    )


def set_current(inst_entry, value: float) -> None:
    inst_entry[0] = float(value)
    inst_entry[1] = float(value)


def snapshot(project, outdir: Path, stage: str) -> None:
    project.save(str(outdir / f"{stage}.gpx"))


def stage(project, hist, outdir: Path, label: str) -> None:
    project.refine(makeBack=False)
    snapshot(project, outdir, label)
    print(f"STAGE {label} residuals={hist.residuals}")


def summarize(project, hist, phase_specs, outdir: Path) -> dict:
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception as exc:
        mass_fracs = {"error": repr(exc)}
    phases = []
    for cod_id, name, _ in phase_specs:
        ph = project.phase(name)
        hap = ph.data["Histograms"][hist.name]
        phases.append(
            {
                "name": name,
                "cod_id": cod_id,
                "cell": ph.get_cell(),
                "composition": ph.composition,
                "hap_scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    summary = {
        "residuals": hist.residuals,
        "mass_fractions": mass_fracs,
        "instrument": {k: v for k, v in inst.items()},
        "sample": {k: v for k, v in sample.items()},
        "background": hist.Background,
        "phases": phases,
        "vary_list": project.get_VaryList(),
    }
    with (outdir / "summary.json").open("w") as stream:
        json.dump(summary, stream, indent=2, default=float)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--name", required=True)
    parser.add_argument(
        "--phase",
        action="append",
        required=True,
        help="COD_ID:phase_name:initial_size_micrometre",
    )
    parser.add_argument("--start-zero", type=float, default=-0.32)
    args = parser.parse_args()

    work = Path.cwd()
    outdir = work / ".tmp" / "branches" / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    phase_specs = [parse_phase(text) for text in args.phase]

    gpx_path = outdir / "working.gpx"
    project = G2sc.G2Project(newgpx=str(gpx_path))
    hist = project.add_powder_histogram(
        str(work / "inputs" / "pattern.csv"),
        str(work / "instrument.instprm"),
        fmthint="comma",
    )
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09455322)
    initialize_background(hist)

    # The histogram scale is fixed so all linked phase scales can be refined
    # without an exactly singular overall-scale/phase-scale combination.
    hist.SampleParameters["Scale"][1] = False
    set_current(hist.InstrumentParameters["Zero"], args.start_zero)

    for cod_id, name, initial_size in phase_specs:
        path = cod_path(cod_id)
        if not path.exists():
            raise FileNotFoundError(path)
        ph = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        ph.set_HAP_refinements(
            {
                "Scale": True,
                "Size": {
                    "type": "isotropic",
                    "value": initial_size,
                    "refine": False,
                },
            },
            [hist],
        )

    project.set_Controls("cycles", 12)
    snapshot(project, outdir, "00_initialized")

    # Complete replayable checkpoint: all phases, full grid, fixed initial
    # peak positions/profile; refine only scales and smooth background.
    stage(project, hist, outdir, "01_scales_background")

    # Instrument offset, then phase cells, then specimen displacement.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, hist, outdir, "02_zero")
    for ph in project.phases():
        ph.set_refinements({"Cell": True})
    stage(project, hist, outdir, "03_cells")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    stage(project, hist, outdir, "04_shift")

    # Use only the profile terms present in the synthetic lab model. V and Y
    # remain zero. Refine broad instrumental terms before phase-specific size.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    stage(project, hist, outdir, "05_instrument_profile")
    for ph in project.phases():
        ph.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    stage(project, hist, outdir, "06_phase_size")

    # Isotropic microstrain is a comparable test for every topology. A later
    # physical branch can reject it if the scale collapses or the value is
    # unsupported.
    for ph in project.phases():
        ph.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    stage(project, hist, outdir, "07_isotropic_mustrain")

    project.save(str(outdir / "final_branch.gpx"))
    summary = summarize(project, hist, phase_specs, outdir)
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    main()
