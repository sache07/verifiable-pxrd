#!/usr/bin/env python3
"""Export the accepted GSAS-II model and all user-facing numerical products."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path.cwd()
SOURCE = ROOT / ".tmp/three_phase/clean.gpx"
FINAL = ROOT / "final.gpx"
OBSERVED = ROOT / "inputs/pattern.csv"

PHASE_METADATA = {
    "CaWO4": {
        "name": "scheelite CaWO4",
        "formula": "CaWO4",
        "cif_path": "phase_CaWO4.cif",
        "reference": "COD 7219229",
    },
    "WO3": {
        "name": "monoclinic WO3",
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "reference": "COD 2311041",
    },
    "CaCO3": {
        "name": "calcite CaCO3",
        "formula": "CaCO3",
        "cif_path": "phase_CaCO3.cif",
        "reference": "COD 1547347",
    },
}


def finite(value: float) -> float:
    number = float(value)
    if not np.isfinite(number):
        raise ValueError(f"Non-finite output value: {number}")
    return number


def main() -> None:
    if not SOURCE.is_file():
        raise FileNotFoundError(SOURCE)

    # Saving through GSAS-II makes final.gpx the native, replayable project
    # from which the CIFs, fractions and profile below are all read.
    project = G2sc.G2Project(str(SOURCE.resolve()), newgpx=str(FINAL.resolve()))
    project.save(str(FINAL.resolve()))
    project = G2sc.G2Project(str(FINAL.resolve()))
    hist = project.histogram(0)

    if project.get_Frozen():
        raise RuntimeError(f"Final project has frozen variables: {project.get_Frozen()}")
    if set(phase.name for phase in project.phases()) != set(PHASE_METADATA):
        raise RuntimeError("Final phase inventory differs from the accepted inventory")

    x = np.asarray(hist.getdata("x"), dtype=float)
    yobs = np.asarray(hist.getdata("yobs"), dtype=float)
    ycalc = np.asarray(hist.getdata("ycalc"), dtype=float)
    difference = np.asarray(hist.getdata("residual"), dtype=float)
    public = np.loadtxt(OBSERVED, delimiter=",", skiprows=1, ndmin=2)
    if public.shape != (len(x), 2):
        raise RuntimeError("Observed pattern shape changed in the GSAS-II project")
    if not np.allclose(x, public[:, 0], rtol=0, atol=1e-9):
        raise RuntimeError("GSAS-II angle grid differs from inputs/pattern.csv")
    if not np.allclose(yobs, public[:, 1], rtol=0, atol=1e-9):
        raise RuntimeError("GSAS-II observations differ from inputs/pattern.csv")
    if not np.allclose(difference, yobs - ycalc, rtol=0, atol=1e-8):
        raise RuntimeError("Saved GSAS-II residual is not observed minus calculated")
    if not np.isfinite(ycalc).all() or np.any(ycalc < 0):
        raise RuntimeError("Calculated profile contains non-finite or negative values")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, yobs, ycalc, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.10g", "%.12g", "%.12g"],
    )

    raw_fractions = hist.ComputeMassFracs()
    total = sum(finite(raw_fractions[name][0]) for name in PHASE_METADATA)
    if total <= 0:
        raise RuntimeError("No positive modeled crystalline mass")

    rows = []
    for phase in project.phases():
        metadata = PHASE_METADATA[phase.name]
        cif = ROOT / metadata["cif_path"]
        phase.export_CIF(str(cif.resolve()))
        value, esd = raw_fractions[phase.name]
        cell = phase.get_cell()
        rows.append(
            {
                "name": metadata["name"],
                "formula": metadata["formula"],
                "phase_name_in_project": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": metadata["cif_path"],
                "weight_fraction": finite(value) / total,
                "weight_fraction_esd_formal": finite(esd) / total,
                "weight_percent": 100.0 * finite(value) / total,
                "reference_starting_model": metadata["reference"],
                "refined_cell": {
                    key: finite(cell[key])
                    for key in (
                        "length_a",
                        "length_b",
                        "length_c",
                        "angle_alpha",
                        "angle_beta",
                        "angle_gamma",
                        "volume",
                    )
                },
            }
        )

    residuals = hist.residuals
    rwp = finite(residuals["wR"])
    rexp = finite(residuals["wRmin"])
    result = {
        "analysis": "three-phase full-pattern GSAS-II Rietveld refinement",
        "refinement_histogram": hist.name,
        "fraction_basis": (
            "normalized over the modeled crystalline phases; no amorphous "
            "fraction was determined"
        ),
        "phases": rows,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": finite(residuals["R"]),
            "Rwp_background_subtracted_percent": finite(residuals["wRb"]),
            "Rp_background_subtracted_percent": finite(residuals["Rb"]),
            "Rexp_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "number_of_observations": int(len(x)),
            "profile_range_two_theta_deg": [finite(x[0]), finite(x[-1])],
            "difference_definition": "observed - calculated",
        },
        "files": {
            "project": "final.gpx",
            "profile": "fit.csv",
            "report": "report.md",
        },
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write("\n")

    if abs(sum(row["weight_fraction"] for row in rows) - 1.0) > 1e-12:
        raise RuntimeError("Exported crystalline fractions do not sum to one")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
