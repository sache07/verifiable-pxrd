#!/usr/bin/env python3
"""Add and physically stage residual calcite into the accepted model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


WORK = Path.cwd()
SRC = WORK / ".tmp/profile/wo001_clean.gpx"
OUT = WORK / ".tmp/three_phase"
CALCITE = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/1/54/73/1547347.cif"
)


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def stage(project, hist, label):
    project.save(str(OUT / f"{label}.gpx"))
    project.refine(makeBack=False)
    print(label, hist.residuals, hist.ComputeMassFracs())


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(SRC), newgpx=str(OUT / "working.gpx"))
    project.set_Controls("cycles", 18)
    project.set_Frozen()
    hist = project.histogram(0)

    # Freeze all specimen/profile and atom terms for an unbiased initial scale
    # test of the new phase; retain smooth background and all phase scales.
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Polariz.", "U", "W", "X", "SH/L"],
            "Sample Parameters": ["Shift"],
        }
    )
    for ph in project.phases():
        ph.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        ph.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
        ph.set_HAP_refinements({"Scale": True}, [hist])

    calcite = project.add_phase(
        str(CALCITE), phasename="CaCO3", histograms=[hist], fmthint="CIF"
    )
    calcite.set_refinements({"Cell": False, "Atoms": {"all": " "}})
    calcite.set_HAP_refinements(
        {
            "Scale": True,
            "Size": {"type": "isotropic", "value": 0.5, "refine": False},
            "Mustrain": {"type": "isotropic", "refine": False},
        },
        [hist],
    )
    calcite.data["Histograms"][hist.name]["Scale"][0] = 2.0

    stage(project, hist, "01_calcite_scale")

    # The coherent family must survive cell/calibration relaxation.
    for ph in project.phases():
        ph.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    bound(project, ":0:Shift", -800.0, 800.0)
    stage(project, hist, "02_cells_shift")

    calcite.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}, [hist]
    )
    bound(project, f"{calcite.id}:{hist.id}:Size;i", 0.04, 1.5)
    stage(project, hist, "03_calcite_size")

    calcite.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    bound(project, f"{calcite.id}:{hist.id}:Mustrain;i", 300.0, 8000.0)
    stage(project, hist, "04_calcite_strain")

    # Final joint relaxation in the physical lab ranges. CaWO4 strain remains
    # fixed at its supported lower bound; WO3 [001] uniaxial strain is retained.
    hist.set_refinements(
        {
            "Instrument Parameters": ["Polariz.", "U", "W", "X", "SH/L"],
            "Sample Parameters": ["Shift"],
        }
    )
    for variable, low, high in [
        (":0:Polariz.", 0.5, 1.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
    ]:
        bound(project, variable, low, high)
    cawo4 = project.phase("CaWO4")
    wo3 = project.phase("WO3")
    cawo4.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}, [hist]
    )
    cawo4.clear_HAP_refinements({"Mustrain": True}, [hist])
    wo3.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": [0, 0, 1],
                "refine": True,
            }
        },
        [hist],
    )
    wo3.clear_HAP_refinements({"Size": True}, [hist])
    bound(project, f"{cawo4.id}:{hist.id}:Size;i", 0.04, 1.5)
    bound(project, f"{wo3.id}:{hist.id}:Mustrain;i", 300.0, 8000.0)
    bound(project, f"{wo3.id}:{hist.id}:Mustrain;a", 300.0, 8000.0)
    stage(project, hist, "05_joint_profile")

    result = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for ph in project.phases():
        hap = ph.data["Histograms"][hist.name]
        result["phases"][ph.name] = {
            "cell": ph.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    with (OUT / "summary.json").open("w") as stream:
        json.dump(result, stream, indent=2, default=float)
    project.save(str(OUT / "candidate.gpx"))
    print(json.dumps(result, indent=2, default=float))


if __name__ == "__main__":
    main()
