import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("final_shift_local.gpx")
project.save("polished_final.gpx")
hist = project.histogram(0)
phases = project.phases()
znwo4, wo3, zno = phases


def clear_all():
    for phase in phases:
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
    )


clear_all()
records = []


def run(stage, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    weighted = [
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in phases
    ]
    records.append(
        {
            "stage": stage,
            "wR": hist.get_wR(),
            "fractions": [value / sum(weighted) for value in weighted],
        }
    )
    shutil.copy2(project.filename, f"polished_{stage}.gpx")


for phase in phases:
    phase.set_HAP_refinements({"Pref.Ori.": True})
run("texture", 15)
for phase in phases:
    phase.clear_HAP_refinements({"Pref.Ori.": True})

znwo4.set_refinements({"Atoms": {"all": "X"}})
run("znwo4_atoms", 15)
znwo4.clear_refinements({"Atoms": [atom.label for atom in znwo4.atoms()]})

for label in ("W1", "W2"):
    wo3.set_refinements({"Atoms": {label: "X"}})
    run(f"wo3_{label}", 15)
    wo3.clear_refinements({"Atoms": [label]})

zno.set_refinements({"Atoms": {"O": "X"}})
run("zno_O", 15)
zno.clear_refinements({"Atoms": ["O"]})

znwo4.set_HAP_refinements(
    {"Mustrain": {"type": "uniaxial", "direction": [1, 0, 0], "refine": True}}
)
run("znwo4_strain")
znwo4.clear_HAP_refinements({"Mustrain": True})

for index, phase in enumerate(phases):
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run(f"phase{index}_size")
    phase.clear_HAP_refinements({"Size": True})

for index, phase in ((1, wo3), (2, zno)):
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run(f"phase{index}_strain")
    phase.clear_HAP_refinements({"Mustrain": True})

for name in ("W", "SH/L"):
    hist.set_refinements({"Instrument Parameters": [name]})
    run("instrument_" + name.replace("/", "_"))
    hist.clear_refinements({"Instrument Parameters": [name]})

znwo4.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
run("znwo4_cell_zero", 15)
znwo4.clear_refinements({"Cell": True})
hist.clear_refinements({"Instrument Parameters": ["Zero"]})

for phase in (wo3, zno):
    phase.set_refinements({"Cell": True})
    run(phase.name + "_cell", 15)
    phase.clear_refinements({"Cell": True})

clear_all()
project.save("polished_final.gpx")

print(
    json.dumps(
        {
            "records": records,
            "final": {
                "wR": hist.get_wR(),
                "cells": [phase.get_cell() for phase in phases],
                "texture": [phase.data["Histograms"][hist.name]["Pref.Ori."][:4] for phase in phases],
                "atoms": {
                    phase.name: {
                        atom.label: list(atom.coordinates) for atom in phase.atoms()
                    }
                    for phase in phases
                },
            },
        },
        indent=2,
    )
)
