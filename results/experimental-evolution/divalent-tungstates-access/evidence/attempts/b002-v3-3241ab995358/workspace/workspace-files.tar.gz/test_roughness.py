import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
results = []
for index, (a, b) in enumerate([(0.10, 0.05), (0.30, 0.10), (0.50, 0.30)], start=1):
    project = G2.G2Project("uiso_best.gpx")
    project.save(f"roughness_{index}.gpx")
    hist = project.histogram(0)
    hist.SampleParameters["SurfRoughA"] = [a, False]
    hist.SampleParameters["SurfRoughB"] = [b, False]
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    results.append({
        "start": [a, b],
        "wR": hist.get_wR(),
        "A": hist.SampleParameters["SurfRoughA"][0],
        "B": hist.SampleParameters["SurfRoughB"][0],
    })
print(json.dumps(results, indent=2))
