import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
results = []
for shift in [-800, -700, -600, -500, -400, -300]:
    project = G2.G2Project("physical_04_SHL.gpx")
    project.save(f"physical_shift_{shift:+05d}.gpx")
    hist = project.histogram(0)
    phase = project.phase(0)
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    hist.SampleParameters["Shift"] = [float(shift), False]
    hist.InstrumentParameters["Zero"][1] = 0.366 + 0.00056 * shift
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    results.append({"shift_um": shift, "wR": hist.get_wR(), "zero_deg": hist.InstrumentParameters["Zero"][1], "cell": phase.get_cell()})
print(json.dumps(results, indent=2))
