import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


models = {
    "como": "candidate_znwo4_wolframite.cif",
    "cowo": "candidate_znwo4_cowo4_repaired.cif",
    "modern": "candidate_znwo4_modern_start.cif",
}
results = []
for name, model in models.items():
    project = G2.G2Project(newgpx=f"start_{name}.gpx")
    hist = project.add_powder_histogram("inputs/pattern.csv", "initial.instprm", fmthint="comma")
    phase = project.add_phase(model, phasename="ZnWO4_wolframite", histograms=[hist], fmthint="CIF")
    hist.set_refinements({
        "Limits": [9.90343322, 100.09455322],
        "Background": {"type": "chebyschev-1", "no. coeffs": 12, "coeffs": [900.0] + [0.0] * 11, "refine": True},
    })
    hist.SampleParameters["Scale"] = [1.0, True]
    hist.SampleParameters["Shift"] = [0.0, False]
    phase.data["Histograms"][hist.name]["Scale"] = [1.0, False]
    for key, value in {"U": 40.0, "W": 73.4, "X": 7.59, "SH/L": 0.0263}.items():
        hist.InstrumentParameters[key] = [value, value, False]
    project.set_Controls("cycles", 6)
    project.refine()
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 10)
    project.refine()
    phase.clear_refinements({"Cell": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 0.75
    hap["Pref.Ori."][3] = [1, 1, 1]
    phase.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    results.append({
        "model": name,
        "wR": hist.get_wR(),
        "ratio": hap["Pref.Ori."][1],
        "cell": phase.get_cell(),
        "zero": hist.InstrumentParameters["Zero"][1],
        "atoms": [{"label": a.label, "xyz": a.coordinates} for a in phase.atoms()],
    })
print(json.dumps(results, indent=2))
