import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("threephase_struct_wo3_W2.gpx")
project.save("threephase_textured.gpx")
hist = project.histogram(0)

for phase in project.phases():
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {"Size": True, "Mustrain": True, "Pref.Ori.": True}
    )
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
)
hist.clear_refinements(
    {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
)

axes = ([1, 1, 1], [1, 1, 0], [1, 0, 0])


def report(stage):
    weighted = [
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    print(
        json.dumps(
            {
                "stage": stage,
                "wR": hist.get_wR(),
                "fractions": [value / sum(weighted) for value in weighted],
                "texture": [
                    {
                        "phase": phase.name,
                        "ratio": phase.data["Histograms"][hist.name]["Pref.Ori."][1],
                        "axis": phase.data["Histograms"][hist.name]["Pref.Ori."][3],
                    }
                    for phase in project.phases()
                ],
            }
        )
    )
    shutil.copy2(project.filename, f"threephase_texture_applied_{stage}.gpx")


for index, axis in enumerate(axes):
    phase = project.phase(index)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][3] = axis
    if index == 2:
        hap["Pref.Ori."][1] = 1.0
    phase.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    phase.clear_HAP_refinements({"Pref.Ori.": True})
    report(f"phase_{index}")

# Verify that the three independently selected corrections are stable together.
for phase in project.phases():
    phase.set_HAP_refinements({"Pref.Ori.": True})
project.set_Controls("cycles", 15)
project.refine()
project.save()
for phase in project.phases():
    phase.clear_HAP_refinements({"Pref.Ori.": True})
report("joint")
project.save("threephase_textured.gpx")
