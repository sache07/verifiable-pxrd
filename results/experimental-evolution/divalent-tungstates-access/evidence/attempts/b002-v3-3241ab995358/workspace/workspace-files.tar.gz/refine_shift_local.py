import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("polished_final.gpx")
project.save("polished_shift.gpx")
hist = project.histogram(0)
for phase in project.phases():
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {"Size": True, "Mustrain": True, "Pref.Ori.": True}
    )
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
)
hist.clear_refinements(
    {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
)
hist.set_refinements({"Sample Parameters": ["Shift"]})
project.set_Controls("cycles", 15)
project.refine()
project.save()
hist.clear_refinements({"Sample Parameters": ["Shift"]})
project.save("polished_shift.gpx")
print(
    json.dumps(
        {
            "wR": hist.get_wR(),
            "shift_um": hist.SampleParameters["Shift"][0],
            "zero_deg": hist.InstrumentParameters["Zero"][1],
        },
        indent=2,
    )
)
