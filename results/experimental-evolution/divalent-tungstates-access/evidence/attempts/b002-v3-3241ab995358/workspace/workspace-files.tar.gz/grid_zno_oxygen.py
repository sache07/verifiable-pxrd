import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
source = "threephase_textured.gpx"
values = [0.372, 0.376, 0.380, 0.3821, 0.384, 0.388, 0.392, 0.396, 0.400, 0.404]
results = []


def clear(project):
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
    )


for value in values:
    filename = f"zno_oxygen_{value:.4f}.gpx"
    shutil.copy2(source, filename)
    project = G2.G2Project(filename)
    clear(project)
    oxygen = next(atom for atom in project.phase(2).atoms() if atom.label == "O")
    x, y, _ = oxygen.coordinates
    oxygen.coordinates = (x, y, value)
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    results.append({"z": value, "wR": project.histogram(0).get_wR(), "file": filename})

filename = "zno_oxygen_unconstrained.gpx"
shutil.copy2(source, filename)
project = G2.G2Project(filename)
clear(project)
zno = project.phase(2)
zno.set_refinements({"Atoms": {"O": "X"}})
project.set_Controls("cycles", 15)
project.refine()
project.save()
oxygen = next(atom for atom in zno.atoms() if atom.label == "O")

print(
    json.dumps(
        {
            "baseline_wR": G2.G2Project(source).histogram(0).get_wR(),
            "grid": results,
            "unconstrained": {
                "z": oxygen.coordinates[2],
                "wR": project.histogram(0).get_wR(),
                "file": filename,
            },
        },
        indent=2,
    )
)
