import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]
results = []
for axis in axes:
    tag = "".join(map(str, axis))
    project = G2.G2Project("controlled_04_X.gpx")
    project.save(f"texture_{tag}.gpx")
    hist = project.histogram(0)
    phase = project.phase(0)
    # Keep the physically clean isotropic profile and metric fixed while the
    # symmetry-allowed March-Dollase candidates are compared.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = axis
    phase.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    results.append({
        "axis": axis,
        "ratio": hap["Pref.Ori."][1],
        "wR": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
    })
print(json.dumps(results, indent=2))
