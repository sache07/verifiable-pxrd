import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("wo3_texture_110.gpx")
project.save("accepted_structure.gpx")
hist = project.histogram(0)
zn, wo3 = project.phases()
for phase in [zn, wo3]:
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
wo3.data["Histograms"][hist.name]["Pref.Ori."][1] = 1.4


def report(stage):
    scales = [p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    masses = [p.data["General"]["Mass"] for p in project.phases()]
    q = [a * b for a, b in zip(scales, masses)]
    out = {
        "stage": stage,
        "wR": hist.get_wR(),
        "fractions": [v / sum(q) for v in q],
        "zn_atoms": [{"label": a.label, "xyz": a.coordinates} for a in zn.atoms()],
        "md_zn": zn.data["Histograms"][hist.name]["Pref.Ori."],
        "md_wo3": wo3.data["Histograms"][hist.name]["Pref.Ori."],
    }
    print(json.dumps(out, indent=2))
    shutil.copy2(project.filename, f"accepted_{stage}.gpx")


def run(stage, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    report(stage)


run("00_clamped_texture", 10)
for index, label in enumerate(["W1", "Zn0", "O2", "O3"], start=1):
    zn.set_refinements({"Atoms": {label: "X"}})
    run(f"{index:02d}_{label}")
    zn.clear_refinements({"Atoms": [label]})
zn.set_refinements({"Atoms": {"all": "X"}})
run("05_all_zn", 15)
zn.clear_refinements({"Atoms": [a.label for a in zn.atoms()]})
project.save("accepted_structure.gpx")
