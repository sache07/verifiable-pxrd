import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
library = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(cod_id):
    return library / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


results = []
for cod_id in ("9004178", "1537875"):
    project = G2.G2Project("relaxed_model.gpx")
    project.save(f"zno_trial_{cod_id}.gpx")
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
    )
    phase = project.add_phase(
        str(cod_path(cod_id)),
        phasename=f"ZnO_{cod_id}",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    masses = [item.data["General"]["Mass"] for item in project.phases()]
    hap["Scale"] = [0.03 / 0.97 * masses[0] / masses[-1], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1200.0

    stages = []
    for stage in ("scale", "cell", "size", "strain"):
        if stage == "cell":
            phase.set_refinements({"Cell": True})
        elif stage == "size":
            phase.clear_refinements({"Cell": True})
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}
            )
        elif stage == "strain":
            phase.clear_HAP_refinements({"Size": True})
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
        project.set_Controls("cycles", 12)
        status = "ok"
        try:
            project.refine()
            project.save()
        except Exception as exc:
            status = f"failed: {exc}"
        weighted = [
            item.data["General"]["Mass"]
            * item.data["Histograms"][hist.name]["Scale"][0]
            for item in project.phases()
        ]
        total = sum(weighted)
        stages.append(
            {
                "stage": stage,
                "status": status,
                "wR": hist.get_wR(),
                "scale": hap["Scale"][0],
                "fraction": weighted[-1] / total if total else None,
                "cell": phase.get_cell(),
                "size": hap["Size"][1][0],
                "strain": hap["Mustrain"][1][0],
            }
        )
        if status != "ok":
            break
    results.append({"cod_id": cod_id, "stages": stages})

print(json.dumps({"baseline_wR": G2.G2Project("relaxed_model.gpx").histogram(0).get_wR(), "results": results}, indent=2))
