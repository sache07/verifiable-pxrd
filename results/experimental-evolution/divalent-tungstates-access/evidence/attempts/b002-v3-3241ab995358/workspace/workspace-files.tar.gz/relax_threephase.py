import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("zno_oxygen_unconstrained.gpx")
project.save("threephase_relaxed.gpx")
hist = project.histogram(0)
phases = project.phases()

for phase in phases:
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {"Size": True, "Mustrain": True, "Pref.Ori.": True}
    )
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
)
hist.clear_refinements(
    {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
)


def report(stage):
    weighted = [
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in phases
    ]
    print(
        json.dumps(
            {
                "stage": stage,
                "wR": hist.get_wR(),
                "fractions": [value / sum(weighted) for value in weighted],
                "cells": [phase.get_cell() for phase in phases],
                "instrument": {
                    name: hist.InstrumentParameters[name][1]
                    for name in ("Zero", "U", "W", "X", "SH/L", "Polariz.")
                },
                "profile": [
                    {
                        "size": phase.data["Histograms"][hist.name]["Size"][1][0],
                        "strain": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
                    }
                    for phase in phases
                ],
            }
        )
    )
    shutil.copy2(project.filename, f"threephase_relaxed_{stage}.gpx")


def run(stage, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    report(stage)


for index, phase in enumerate(phases):
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run(f"phase{index}_size")
    phase.clear_HAP_refinements({"Size": True})
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run(f"phase{index}_strain")
    phase.clear_HAP_refinements({"Mustrain": True})

for name in ("W", "SH/L"):
    hist.set_refinements({"Instrument Parameters": [name]})
    run("inst_" + name.replace("/", "_"))
    hist.clear_refinements({"Instrument Parameters": [name]})

phases[0].set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
run("phase0_cell_zero", 15)
phases[0].clear_refinements({"Cell": True})
hist.clear_refinements({"Instrument Parameters": ["Zero"]})

for index in (1, 2):
    phases[index].set_refinements({"Cell": True})
    run(f"phase{index}_cell", 15)
    phases[index].clear_refinements({"Cell": True})

project.save("threephase_relaxed.gpx")
