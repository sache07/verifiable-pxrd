import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("threephase_uiso.gpx")
project.save("threephase_structure.gpx")
hist = project.histogram(0)
znwo4, wo3, zno = project.phases()

for phase in project.phases():
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {"Size": True, "Mustrain": True, "Pref.Ori.": True}
    )
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
)
hist.clear_refinements(
    {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
)


def snapshot(stage):
    weighted = [
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in project.phases()
    ]
    print(
        json.dumps(
            {
                "stage": stage,
                "wR": hist.get_wR(),
                "fractions": [value / sum(weighted) for value in weighted],
                "atoms": {
                    phase.name: {
                        atom.label: list(atom.coordinates) for atom in phase.atoms()
                    }
                    for phase in project.phases()
                },
            }
        )
    )
    shutil.copy2(project.filename, f"threephase_struct_{stage}.gpx")


def refine_site(phase, label, stage, cycles=15):
    phase.set_refinements({"Atoms": {label: "X"}})
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    phase.clear_refinements({"Atoms": [label]})
    snapshot(stage)


for label in ("W1", "Zn0", "O2", "O3"):
    refine_site(znwo4, label, f"znwo4_{label}")

znwo4.set_refinements({"Atoms": {"all": "X"}})
project.set_Controls("cycles", 15)
project.refine()
project.save()
znwo4.clear_refinements({"Atoms": [atom.label for atom in znwo4.atoms()]})
snapshot("znwo4_all")

for label in ("W1", "W2"):
    refine_site(wo3, label, f"wo3_{label}")

# Hold Zn at z=0 to define the polar-axis origin; refine only the relative O z.
refine_site(zno, "O", "zno_O")

project.save("threephase_structure.gpx")
