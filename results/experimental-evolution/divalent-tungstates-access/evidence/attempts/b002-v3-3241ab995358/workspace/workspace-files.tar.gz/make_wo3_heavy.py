from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel("warn")
project = G2.G2Project("wo3_2311041.gpx")
project.save("two_phase_heavy.gpx")
hist = project.histogram(0)
zn, wo3 = project.phases()
for phase in [zn, wo3]:
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
labels = [a.label for a in wo3.atoms() if a.element == "W"]
wo3.set_refinements({"Atoms": {label: "X" for label in labels}})
project.set_Controls("cycles", 15)
project.refine()
wo3.clear_refinements({"Atoms": labels})
project.save()
print("wR", hist.get_wR())
for atom in wo3.atoms():
    print(atom.label, atom.element, atom.coordinates)
