import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("uiso_best.gpx")
project.save("final_profile_work.gpx")
hist = project.histogram(0)
zn, wo3 = project.phases()
for phase in [zn, wo3]:
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
hist.SampleParameters["SurfRoughA"] = [0.0, False]
hist.SampleParameters["SurfRoughB"] = [0.0, False]


def report(stage):
    scales = [p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    masses = [p.data["General"]["Mass"] for p in project.phases()]
    vals = [a * b for a, b in zip(scales, masses)]
    out = {
        "stage": stage,
        "wR": hist.get_wR(),
        "fractions": [v / sum(vals) for v in vals],
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
        "cells": [p.get_cell() for p in project.phases()],
        "profiles": [{"size": p.data["Histograms"][hist.name]["Size"], "strain": p.data["Histograms"][hist.name]["Mustrain"]} for p in project.phases()],
    }
    print(json.dumps(out, indent=2))
    shutil.copy2(project.filename, f"finalprof_{stage}.gpx")


def run(stage, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    report(stage)


for ptag, phase in [("zn", zn), ("wo3", wo3)]:
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run(f"{ptag}_size")
    phase.clear_HAP_refinements({"Size": True})
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run(f"{ptag}_strain")
    phase.clear_HAP_refinements({"Mustrain": True})

for name in ["W", "SH/L"]:
    hist.set_refinements({"Instrument Parameters": [name]})
    run("inst_" + name.replace("/", "_"))
    hist.clear_refinements({"Instrument Parameters": [name]})

zn.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
run("zn_cell_zero", 15)
zn.clear_refinements({"Cell": True})
hist.clear_refinements({"Instrument Parameters": ["Zero"]})

wo3.set_refinements({"Cell": True})
run("wo3_cell", 15)
wo3.clear_refinements({"Cell": True})
project.save("final_profile_work.gpx")
