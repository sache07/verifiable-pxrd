import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
results = []
for shift in range(-800, 801, 100):
    project = G2.G2Project("physical_05_joint.gpx")
    project.save(f"shift_{shift:+05d}.gpx")
    hist = project.histogram(0)
    phase = project.phase(0)
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = abs(hap["Mustrain"][1][0])
    hist.SampleParameters["Shift"] = [float(shift), False]
    hist.InstrumentParameters["Zero"][1] = 0.366 + 0.00056 * shift
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    results.append({
        "shift_um": shift,
        "wR": hist.get_wR(),
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "cell": phase.get_cell(),
    })
print(json.dumps(results, indent=2))
