import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(cod_id):
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


candidates = ["1528915", "2311041", "2106293", "2107312", "1563541", "1010618"]
results = []
for cod_id in candidates:
    project = G2.G2Project("physical_shift_-0600.gpx")
    project.save(f"wo3_{cod_id}.gpx")
    hist = project.histogram(0)
    zn = project.phase(0)
    zn.clear_refinements({"Cell": True, "Atoms": [a.label for a in zn.atoms()]})
    zn.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    hist.SampleParameters["Shift"][1] = False
    phase = project.add_phase(str(cod_path(cod_id)), phasename=f"WO3_{cod_id}", histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    mass_zn = zn.data["General"]["Mass"]
    mass_wo3 = phase.data["General"]["Mass"]
    hap["Scale"] = [(0.15 / 0.85) * mass_zn / mass_wo3, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1500.0
    phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 10)
    project.refine()
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.set_Controls("cycles", 10)
    project.refine()
    phase.clear_HAP_refinements({"Size": True})
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    scales = [p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    masses = [p.data["General"]["Mass"] for p in project.phases()]
    products = [s * m for s, m in zip(scales, masses)]
    fractions = [v / sum(products) for v in products]
    results.append({
        "cod_id": cod_id,
        "wR": hist.get_wR(),
        "fractions": fractions,
        "cell": phase.get_cell(),
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "scale": hap["Scale"],
    })
print(json.dumps(results, indent=2))
