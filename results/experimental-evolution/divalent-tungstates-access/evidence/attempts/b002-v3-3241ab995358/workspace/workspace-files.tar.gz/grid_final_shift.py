import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
source = "final_uiso.gpx"
base = G2.G2Project(source)
base_hist = base.histogram(0)
base_shift = float(base_hist.SampleParameters["Shift"][0])
base_zero = float(base_hist.InstrumentParameters["Zero"][1])
results = []

for shift in (-380,):
    filename = f"final_shift_{shift:+05d}.gpx"
    shutil.copy2(source, filename)
    project = G2.G2Project(filename)
    hist = project.histogram(0)
    phases = project.phases()
    for phase in phases:
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
    )
    hist.SampleParameters["Shift"] = [float(shift), False]
    hist.InstrumentParameters["Zero"][1] = base_zero + 0.00056 * (shift - base_shift)

    phases[0].set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 15)
    project.refine()
    phases[0].clear_refinements({"Cell": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

    for phase in phases[1:]:
        phase.set_refinements({"Cell": True})
        project.set_Controls("cycles", 12)
        project.refine()
        phase.clear_refinements({"Cell": True})

    phases[0].set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("cycles", 12)
    project.refine()
    phases[0].clear_refinements({"Cell": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    project.save()

    results.append(
        {
            "shift_um": shift,
            "wR": hist.get_wR(),
            "zero_deg": hist.InstrumentParameters["Zero"][1],
            "cells": [phase.get_cell() for phase in phases],
            "file": filename,
        }
    )

print(json.dumps({"baseline_wR": base_hist.get_wR(), "results": results}, indent=2))
