import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


def set_isotropic(atom, value):
    if atom.adp_flag != "I":
        atom.data[atom.cia] = "I"
    atom.data[atom.cia + 1] = float(value)


project = G2.G2Project("zno_trial_9004178.gpx")
project.save("threephase_uiso_base.gpx")
hist = project.histogram(0)
for phase in project.phases():
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {"Size": True, "Mustrain": True, "Pref.Ori.": True}
    )
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
)
hist.clear_refinements(
    {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
)

# The wurtzite transfer reference has anisotropic ADPs, while the measurement
# protocol varies one isotropic U value per phase. Convert it before comparison.
for atom in project.phase(2).atoms():
    set_isotropic(atom, 0.010)
project.set_Controls("cycles", 10)
project.refine()
project.save()

grids = {
    0: [0.0040, 0.0055, 0.0070, 0.0085, 0.0100],
    1: [0.0090, 0.0120, 0.0150, 0.0180, 0.0200],
    2: [0.0030, 0.0050, 0.0075, 0.0100, 0.0125, 0.0150, 0.0200],
}
records = []
running = "threephase_uiso_base.gpx"
for phase_index, values in grids.items():
    phase_records = []
    for value in values:
        filename = f"threephase_u{phase_index}_{value:.4f}.gpx"
        shutil.copy2(running, filename)
        trial = G2.G2Project(filename)
        for atom in trial.phase(phase_index).atoms():
            set_isotropic(atom, value)
        trial.set_Controls("cycles", 8)
        trial.refine()
        trial.save()
        phase_records.append(
            {"uiso": value, "wR": trial.histogram(0).get_wR(), "file": filename}
        )
    best = min(phase_records, key=lambda row: row["wR"])
    running = best["file"]
    records.append(
        {
            "phase_index": phase_index,
            "phase_name": G2.G2Project(running).phase(phase_index).name,
            "trials": phase_records,
            "best": best,
        }
    )

shutil.copy2(running, "threephase_uiso.gpx")
final = G2.G2Project("threephase_uiso.gpx")
print(
    json.dumps(
        {
            "converted_baseline_wR": G2.G2Project("threephase_uiso_base.gpx").histogram(0).get_wR(),
            "records": records,
            "final_wR": final.histogram(0).get_wR(),
        },
        indent=2,
    )
)
