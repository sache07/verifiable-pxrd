from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx="initial_test.gpx")
hist = project.add_powder_histogram(
    "inputs/pattern.csv", "initial.instprm", fmthint="comma"
)
phase = project.add_phase(
    "candidate_znwo4_wolframite.cif",
    phasename="ZnWO4_wolframite",
    histograms=[hist],
    fmthint="CIF",
)
print("histogram", hist.name, len(hist.data["data"][1][0]))
print("x range", hist.data["data"][1][0][0], hist.data["data"][1][0][-1])
print("observed endpoints", hist.data["data"][1][1][0], hist.data["data"][1][1][-1])
print("sample", hist.SampleParameters)
print("instrument", hist.InstrumentParameters)
print("background", hist.data["Background"])
print("cell", phase.get_cell())
print("atoms")
for atom in phase.atoms():
    print(atom.label, atom.element, atom.coordinates, atom.occupancy, atom.uiso)
print("hap", phase.data["Histograms"][hist.name])
project.save()
