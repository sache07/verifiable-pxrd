from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def substituted(cod_id: str, substitutions: dict[str, str], output: str) -> None:
    structure = Structure.from_file(cod_path(cod_id))
    structure.replace_species(substitutions)
    CifWriter(structure, symprec=0.01, significant_figures=10).write_file(output)


# Wolframite topology, transferred from CoMoO4 (COD 7205001).
substituted("7205001", {"Co": "Zn", "Mo": "W"}, "candidate_znwo4_wolframite.cif")

# Same-cation molybdate analogues for plausible off-stoichiometric Zn-W-O phases.
substituted("1534971", {"Mo": "W"}, "candidate_zn3w2o9.cif")
substituted("2222487", {"Mo": "W"}, "candidate_zn2w3o8.cif")

# A repaired wolframite coordinate start from the chemically closer historical
# CoWO4 record (COD 5910316). That CIF lists expanded atoms without occupancy
# metadata and is not directly parseable, so the four independent P2/c sites
# are reconstructed explicitly from its reported coordinates.
co_wo4_like = Structure.from_spacegroup(
    "P 2/c",
    Lattice.monoclinic(4.69, 5.72, 4.93, 90.6),
    ["Zn", "W", "O", "O"],
    [
        [0.5, 0.653, 0.25],
        [0.0, 0.180, 0.25],
        [0.220, 0.110, -0.040],
        [0.260, 0.380, 0.390],
    ],
)
CifWriter(co_wo4_like, symprec=0.01, significant_figures=10).write_file(
    "candidate_znwo4_cowo4_repaired.cif"
)

# A second physical start spanning modern wolframite oxygen coordinates.
zn_wo4_like = Structure.from_spacegroup(
    "P 2/c",
    Lattice.monoclinic(4.69, 5.72, 4.93, 90.6),
    ["Zn", "W", "O", "O"],
    [
        [0.5, 0.676, 0.25],
        [0.0, 0.180, 0.25],
        [0.217, 0.105, -0.065],
        [0.256, 0.381, 0.390],
    ],
)
CifWriter(zn_wo4_like, symprec=0.01, significant_figures=10).write_file(
    "candidate_znwo4_modern_start.cif"
)
