import csv
import json
from pathlib import Path

import numpy as np


replay_dir = Path(".tmp/replay_final")
with (replay_dir / "replay.json").open() as stream:
    replay = json.load(stream)
if replay.get("status") != "replayed" or replay.get("profile_review_flags"):
    raise ValueError(f"Final project did not pass clean replay: {replay}")

profile = np.load(replay_dir / "prediction.npz")
x = profile["x"]
observed = profile["observed"]
calculated = profile["predicted"]
background = profile["background"]
difference = observed - calculated

with open("fit.csv", "w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta", "observed", "calculated", "difference", "background"])
    writer.writerows(zip(x, observed, calculated, difference, background))

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
rwp = float(100.0 * np.sqrt(chi_square / denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
project_summary = json.loads(Path("final_project_summary.json").read_text())

phase_records = [
    {
        "name": "ZnWO4 (wolframite)",
        "formula": "ZnWO4",
        "space_group": "P 2/c",
        "cif_path": "phase_ZnWO4.cif",
        "weight_fraction": replay["phases"][0]["weight_fraction"],
    },
    {
        "name": "gamma-WO3 (monoclinic)",
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "phase_WO3.cif",
        "weight_fraction": replay["phases"][1]["weight_fraction"],
    },
    {
        "name": "ZnO (wurtzite)",
        "formula": "ZnO",
        "space_group": "P 63 m c",
        "cif_path": "phase_ZnO.cif",
        "weight_fraction": replay["phases"][2]["weight_fraction"],
    },
]

result = {
    "phases": phase_records,
    "fraction_basis": "normalized over the modeled crystalline phases",
    "fit_statistics": {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "GOF": project_summary["cached_GOF"],
        "chi_square": chi_square,
        "n_points": int(len(x)),
    },
    "refinement_histogram": replay["histogram"],
    "fit_csv": "fit.csv",
    "gsas_project": "final.gpx",
}
with open("result.json", "w") as stream:
    json.dump(result, stream, indent=2)
    stream.write("\n")

print(json.dumps(result, indent=2))
