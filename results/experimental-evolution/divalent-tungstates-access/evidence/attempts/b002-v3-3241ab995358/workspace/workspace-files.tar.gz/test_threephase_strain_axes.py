import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
source = "threephase_relaxed.gpx"
axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0]]
results = []
for phase_index in range(3):
    for axis in axes:
        tag = "".join(str(value) for value in axis)
        filename = f"threephase_strain_p{phase_index}_{tag}.gpx"
        shutil.copy2(source, filename)
        project = G2.G2Project(filename)
        hist = project.histogram(0)
        for phase in project.phases():
            phase.clear_refinements(
                {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
            )
            phase.clear_HAP_refinements(
                {"Size": True, "Mustrain": True, "Pref.Ori.": True}
            )
        hist.clear_refinements(
            {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
        )
        hist.clear_refinements(
            {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
        )
        phase = project.phase(phase_index)
        hap = phase.data["Histograms"][hist.name]
        strain = abs(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = strain
        hap["Mustrain"][1][1] = strain
        hap["Mustrain"][3] = axis
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
        )
        project.set_Controls("cycles", 15)
        status = "ok"
        try:
            project.refine()
            project.save()
        except Exception as exc:
            status = f"failed: {exc}"
        results.append(
            {
                "phase": phase.name,
                "axis": axis,
                "status": status,
                "wR": hist.get_wR(),
                "mustrain": hap["Mustrain"],
                "file": filename,
            }
        )

print(
    json.dumps(
        {
            "baseline_wR": G2.G2Project(source).histogram(0).get_wR(),
            "results": results,
        },
        indent=2,
    )
)
