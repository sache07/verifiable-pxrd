import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0]]
results = []
for axis in axes:
    tag = "".join(map(str, axis))
    project = G2.G2Project("physical_05_joint.gpx")
    project.save(f"strain_{tag}.gpx")
    hist = project.histogram(0)
    phase = project.phase(0)
    phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
    phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    hap = phase.data["Histograms"][hist.name]
    strain = abs(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = strain
    hap["Mustrain"][1][1] = strain
    hap["Mustrain"][3] = axis
    phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}})
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    results.append({
        "axis": axis,
        "wR": hist.get_wR(),
        "mustrain": hap["Mustrain"],
    })
print(json.dumps(results, indent=2))
