from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


def report(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    hap = phase.data["Histograms"][hist.name]
    print(json.dumps({
        "stage": label,
        "wR": hist.get_wR(),
        "cell": phase.get_cell(),
        "instrument": {k: v[1] for k, v in inst.items() if k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]},
        "shift_um": hist.SampleParameters["Shift"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "background": hist.data["Background"][0],
        "vary": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }, indent=2))


def cycle(project, label, n=10):
    project.set_Controls("cycles", n)
    project.save()
    project.refine()
    project.save()
    report(project, label)


project = G2.G2Project(newgpx="lebail.gpx")
hist = project.add_powder_histogram("inputs/pattern.csv", "initial.instprm", fmthint="comma")
phase = project.add_phase(
    "candidate_znwo4_modern_start.cif",
    phasename="ZnWO4_wolframite",
    histograms=[hist],
    fmthint="CIF",
)
hist.set_refinements({
    "Limits": [9.90343322, 100.09455322],
    "Background": {
        "type": "chebyschev-1",
        "no. coeffs": 12,
        "coeffs": [900.0] + [0.0] * 11,
        "refine": True,
    },
})
hist.SampleParameters["Scale"] = [1.0, True]
hist.SampleParameters["Gonio. radius"] = 200.0
hist.SampleParameters["Shift"] = [0.0, False]
phase.data["Histograms"][hist.name]["Scale"] = [1.0, False]
phase.set_refinements({"Cell": False, "LeBail": False})

cycle(project, "seed_reflections", 4)
phase.set_refinements({"Cell": True, "LeBail": True})
hist.set_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"]})
cycle(project, "lebail_initial", 15)
cycle(project, "lebail_repeat", 15)
project.save("lebail.gpx")
