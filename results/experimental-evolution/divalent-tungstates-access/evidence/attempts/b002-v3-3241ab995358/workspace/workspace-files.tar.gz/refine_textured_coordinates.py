import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


project = G2.G2Project("start_modern.gpx")
project.save("textured_coords.gpx")
hist = project.histogram(0)
phase = project.phase(0)
phase.clear_HAP_refinements({"Pref.Ori.": True})
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})


def record(stage):
    atoms = [{"label": a.label, "xyz": a.coordinates, "uiso": a.uiso} for a in phase.atoms()]
    out = {
        "stage": stage,
        "wR": hist.get_wR(),
        "atoms": atoms,
        "md": phase.data["Histograms"][hist.name]["Pref.Ori."],
    }
    print(json.dumps(out, indent=2))
    shutil.copy2(project.filename, f"textured_{stage}.gpx")


for index, label in enumerate(["W1", "Zn0", "O2", "O3"], start=1):
    phase.set_refinements({"Atoms": {label: "X"}})
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    record(f"{index:02d}_{label}")
    phase.clear_refinements({"Atoms": [label]})

phase.set_refinements({"Atoms": {"all": "X"}})
project.set_Controls("cycles", 15)
project.refine()
project.save()
record("05_all")
