import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
source = "threephase_struct_wo3_W2.gpx"
tests = [
    (0, [[1, 1, 1]], "znwo4"),
    (1, [[1, 1, 0]], "wo3"),
    (
        2,
        [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]],
        "zno",
    ),
]
results = []
for phase_index, axes, phase_tag in tests:
    for axis in axes:
        axis_tag = "".join(str(value) for value in axis)
        filename = f"threephase_texture_{phase_tag}_{axis_tag}.gpx"
        shutil.copy2(source, filename)
        project = G2.G2Project(filename)
        hist = project.histogram(0)
        for phase in project.phases():
            phase.clear_refinements(
                {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
            )
            phase.clear_HAP_refinements(
                {"Size": True, "Mustrain": True, "Pref.Ori.": True}
            )
        hist.clear_refinements(
            {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
        )
        hist.clear_refinements(
            {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
        )
        phase = project.phase(phase_index)
        hap = phase.data["Histograms"][hist.name]
        if phase_index == 2:
            hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][3] = axis
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("cycles", 15)
        project.refine()
        project.save()
        results.append(
            {
                "phase": phase.name,
                "axis": axis,
                "ratio": hap["Pref.Ori."][1],
                "wR": hist.get_wR(),
                "file": filename,
            }
        )

print(
    json.dumps(
        {
            "baseline_wR": G2.G2Project(source).histogram(0).get_wR(),
            "results": results,
        },
        indent=2,
    )
)
