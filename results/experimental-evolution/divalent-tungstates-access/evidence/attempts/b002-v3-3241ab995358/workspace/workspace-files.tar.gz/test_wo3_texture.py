import json

from GSASII import GSASIIscriptable as G2

G2.SetPrintLevel("warn")
results = []
for axis in [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]:
    tag = "".join(map(str, axis))
    project = G2.G2Project("two_phase_heavy.gpx")
    project.save(f"wo3_texture_{tag}.gpx")
    hist = project.histogram(0)
    zn, wo3 = project.phases()
    hap = wo3.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = axis
    wo3.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Controls("cycles", 12)
    project.refine()
    project.save()
    results.append({"axis": axis, "ratio": hap["Pref.Ori."][1], "wR": hist.get_wR()})
print(json.dumps(results, indent=2))
