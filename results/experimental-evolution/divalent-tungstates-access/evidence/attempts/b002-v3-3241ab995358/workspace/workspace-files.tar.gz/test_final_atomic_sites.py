import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
source = "final_profile_work.gpx"
base = G2.G2Project(source)
base_hist = base.histogram(0)
base_atoms = {
    phase.name: {atom.label: list(atom.coordinates) for atom in phase.atoms()}
    for phase in base.phases()
}

results = []
for phase_index, phase0 in enumerate(base.phases()):
    for atom0 in phase0.atoms():
        tag = f"site_{phase_index}_{atom0.label}"
        filename = f"{tag}.gpx"
        shutil.copy2(source, filename)
        project = G2.G2Project(filename)
        hist = project.histogram(0)
        phases = project.phases()
        for phase in phases:
            phase.clear_refinements(
                {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
            )
            phase.clear_HAP_refinements(
                {"Size": True, "Mustrain": True, "Pref.Ori.": True}
            )
        hist.clear_refinements(
            {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
        )
        hist.clear_refinements(
            {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
        )
        phase = phases[phase_index]
        phase.set_refinements({"Atoms": {atom0.label: "X"}})
        project.set_Controls("cycles", 15)
        status = "ok"
        try:
            project.refine()
            project.save()
        except Exception as exc:
            status = f"failed: {exc}"
        atom = next(item for item in phase.atoms() if item.label == atom0.label)
        start = base_atoms[phase.name][atom.label]
        delta = [((new - old + 0.5) % 1.0) - 0.5 for old, new in zip(start, atom.coordinates)]
        results.append(
            {
                "phase": phase.name,
                "atom": atom.label,
                "element": atom.element,
                "status": status,
                "wR": hist.get_wR(),
                "start": start,
                "refined": list(atom.coordinates),
                "delta_fractional": delta,
                "file": filename,
            }
        )

print(json.dumps({"baseline_wR": base_hist.get_wR(), "results": results}, indent=2))
