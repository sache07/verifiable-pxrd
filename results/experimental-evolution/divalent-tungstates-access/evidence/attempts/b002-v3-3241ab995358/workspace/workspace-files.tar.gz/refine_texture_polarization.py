import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("accepted_structure.gpx")
project.save("nuisance.gpx")
hist = project.histogram(0)
zn, wo3 = project.phases()


def report(stage):
    scales = [p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()]
    masses = [p.data["General"]["Mass"] for p in project.phases()]
    vals = [a * b for a, b in zip(scales, masses)]
    out = {
        "stage": stage,
        "wR": hist.get_wR(),
        "fractions": [v / sum(vals) for v in vals],
        "polarization": hist.InstrumentParameters["Polariz."][1],
        "md_zn": zn.data["Histograms"][hist.name]["Pref.Ori."],
        "md_wo3": wo3.data["Histograms"][hist.name]["Pref.Ori."],
    }
    print(json.dumps(out, indent=2))
    shutil.copy2(project.filename, f"nuisance_{stage}.gpx")


def run(stage, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    report(stage)


zn.set_HAP_refinements({"Pref.Ori.": True})
run("01_zn_texture")
zn.clear_HAP_refinements({"Pref.Ori.": True})

wo3.set_HAP_refinements({"Pref.Ori.": True})
run("02_wo3_texture")
wo3.clear_HAP_refinements({"Pref.Ori.": True})
ratio = wo3.data["Histograms"][hist.name]["Pref.Ori."][1]
if not 0.7 <= ratio <= 1.4:
    wo3.data["Histograms"][hist.name]["Pref.Ori."][1] = min(1.4, max(0.7, ratio))
    run("03_wo3_texture_clamped", 8)

hist.set_refinements({"Instrument Parameters": ["Polariz."]})
run("04_polarization")
hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
project.save("nuisance.gpx")
