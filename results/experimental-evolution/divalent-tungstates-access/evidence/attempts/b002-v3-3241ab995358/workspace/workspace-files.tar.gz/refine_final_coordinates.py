import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("final_profile_work.gpx")
project.save("final_coordinates_work.gpx")
hist = project.histogram(0)
zn, wo3 = project.phases()

for phase in (zn, wo3):
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {"Size": True, "Mustrain": True, "Pref.Ori.": True}
    )
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
)
hist.clear_refinements(
    {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
)


def snapshot(stage):
    scales = [phase.data["Histograms"][hist.name]["Scale"][0] for phase in (zn, wo3)]
    masses = [phase.data["General"]["Mass"] for phase in (zn, wo3)]
    weighted = [scale * mass for scale, mass in zip(scales, masses)]
    record = {
        "stage": stage,
        "wR": hist.get_wR(),
        "fractions": [value / sum(weighted) for value in weighted],
        "atoms": {
            phase.name: {
                atom.label: list(atom.coordinates) for atom in phase.atoms()
            }
            for phase in (zn, wo3)
        },
    }
    print(json.dumps(record))
    shutil.copy2(project.filename, f"finalcoord_{stage}.gpx")


def refine_site(phase, label, stage):
    phase.set_refinements({"Atoms": {label: "X"}})
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    phase.clear_refinements({"Atoms": [label]})
    snapshot(stage)


for label in ("W1", "Zn0", "O2", "O3"):
    refine_site(zn, label, f"zn_{label}")

zn.set_refinements({"Atoms": {"all": "X"}})
project.set_Controls("cycles", 15)
project.refine()
project.save()
zn.clear_refinements({"Atoms": [atom.label for atom in zn.atoms()]})
snapshot("zn_all")

for label in ("W1", "W2"):
    refine_site(wo3, label, f"wo3_{label}")

project.save("final_coordinates_work.gpx")
