import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
values = [0.003, 0.005, 0.0075, 0.010, 0.0125, 0.015, 0.020]

base = G2.G2Project("nuisance_04_polarization.gpx")
base.save("uiso_base.gpx")
hist = base.histogram(0)
zn, wo3 = base.phases()
hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
hist.InstrumentParameters["Polariz."][1] = 1.0
for atom in wo3.atoms():
    atom.uiso = 0.010
base.set_Controls("cycles", 8)
base.refine()
base.save()

zn_results = []
for value in values:
    project = G2.G2Project("uiso_base.gpx")
    project.save(f"uiso_zn_{value:.4f}.gpx")
    for atom in project.phase(0).atoms():
        atom.uiso = value
    project.set_Controls("cycles", 8)
    project.refine()
    project.save()
    zn_results.append({"uiso": value, "wR": project.histogram(0).get_wR(), "file": project.filename})

best_zn = min(zn_results, key=lambda row: row["wR"])
wo3_results = []
for value in values:
    project = G2.G2Project(best_zn["file"])
    project.save(f"uiso_wo3_{value:.4f}.gpx")
    for atom in project.phase(1).atoms():
        atom.uiso = value
    project.set_Controls("cycles", 8)
    project.refine()
    project.save()
    wo3_results.append({"uiso": value, "wR": project.histogram(0).get_wR(), "file": project.filename})

best_wo3 = min(wo3_results, key=lambda row: row["wR"])
shutil.copy2(best_wo3["file"], "uiso_best.gpx")
print(json.dumps({"zn": zn_results, "best_zn": best_zn, "wo3": wo3_results, "best_wo3": best_wo3}, indent=2))
