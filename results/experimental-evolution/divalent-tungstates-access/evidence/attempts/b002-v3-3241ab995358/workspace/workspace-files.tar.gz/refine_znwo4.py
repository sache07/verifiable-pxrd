from pathlib import Path
import json
import math
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def snapshot(project, stage):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    hap = phase.data["Histograms"][hist.name]
    record = {
        "stage": stage,
        "wR_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "cell": phase.get_cell(),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"]
        },
        "hap": {
            "Scale": hap["Scale"],
            "Size": hap["Size"],
            "Mustrain": hap["Mustrain"],
            "Pref.Ori.": hap["Pref.Ori."],
        },
        "background": hist.data["Background"],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": atom.coordinates,
                "occupancy": atom.occupancy,
                "uiso": atom.uiso,
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    print(json.dumps(plain(record), indent=2))
    Path("refinement_log.jsonl").open("a").write(json.dumps(plain(record)) + "\n")


def run_refinement(project, stage, cycles=8):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine()
    project.save()
    snapshot(project, stage)
    shutil.copy2(project.filename, f"stage_{stage}.gpx")


Path("refinement_log.jsonl").unlink(missing_ok=True)
project = G2.G2Project(newgpx="work.gpx")
hist = project.add_powder_histogram(
    "inputs/pattern.csv", "initial.instprm", fmthint="comma"
)
phase = project.add_phase(
    "candidate_znwo4_wolframite.cif",
    phasename="ZnWO4_wolframite",
    histograms=[hist],
    fmthint="CIF",
)

# Preserve the measured scan in full and use a smooth whole-pattern background.
hist.set_refinements({
    "Limits": [9.90343322, 100.09455322],
    "Background": {
        "type": "chebyschev-1",
        "no. coeffs": 12,
        "coeffs": [900.0] + [0.0] * 11,
        "refine": True,
    },
})
hist.SampleParameters["Scale"] = [1.0, True]
phase.data["Histograms"][hist.name]["Scale"] = [1.0, False]
run_refinement(project, "01_scale_background", cycles=6)

# Fit the monoclinic metric and a common angular zero first.
phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
run_refinement(project, "02_cell_zero", cycles=8)

# Resolve the Bragg-Brentano specimen displacement from the constant zero.
hist.set_refinements({"Sample Parameters": ["Shift"]})
run_refinement(project, "03_shift", cycles=8)

# Introduce physically generated profile terms with moderate starting values.
hap = phase.data["Histograms"][hist.name]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 0.30
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 2000.0
phase.set_HAP_refinements({
    "Size": {"type": "isotropic", "refine": True},
    "Mustrain": {"type": "isotropic", "refine": True},
})
hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
run_refinement(project, "04_profile", cycles=12)

# Heavy-atom shifts carry most of the intensity information.
phase.set_refinements({"Atoms": {"Zn0": "X", "W1": "X"}})
run_refinement(project, "05_heavy_coordinates", cycles=10)

# Oxygen coordinates are subsequently released from the analogue start.
phase.set_refinements({"Atoms": {"O2": "X", "O3": "X"}})
run_refinement(project, "06_oxygen_coordinates", cycles=12)

# A common isotropic displacement scale is represented by refining all site Uiso.
phase.set_refinements({"Atoms": {"all": "XU"}})
run_refinement(project, "07_coordinates_uiso", cycles=12)

project.save("work.gpx")
