import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
results = []
for cod_id in ["1528915", "2311041", "2106293"]:
    project = G2.G2Project(f"wo3_{cod_id}.gpx")
    project.save(f"wo3_coords_{cod_id}.gpx")
    hist = project.histogram(0)
    zn, phase = project.phases()
    for ph in [zn, phase]:
        ph.clear_refinements({"Cell": True, "Atoms": [a.label for a in ph.atoms()]})
        ph.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    labels_w = [a.label for a in phase.atoms() if a.element == "W"]
    labels_o = [a.label for a in phase.atoms() if a.element == "O"]
    phase.set_refinements({"Atoms": {label: "X" for label in labels_w}})
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    wR_heavy = hist.get_wR()
    phase.clear_refinements({"Atoms": labels_w})
    phase.set_refinements({"Atoms": {label: "X" for label in labels_o}})
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    wR_oxygen = hist.get_wR()
    phase.clear_refinements({"Atoms": labels_o})
    results.append({
        "cod_id": cod_id,
        "wR_heavy": wR_heavy,
        "wR_oxygen": wR_oxygen,
        "atoms": [{"label": a.label, "element": a.element, "xyz": a.coordinates} for a in phase.atoms()],
    })
print(json.dumps(results, indent=2))
