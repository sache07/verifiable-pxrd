import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("textured_05_all.gpx")
project.save("physical_profile.gpx")
hist = project.histogram(0)
phase = project.phase(0)
phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
phase.clear_HAP_refinements({"Pref.Ori.": True, "Size": True, "Mustrain": True})
hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
hap = phase.data["Histograms"][hist.name]

# Use one member of each exact instrument/specimen correlation. X is held at a
# small physical value while isotropic crystallite size carries the 1/cos term;
# U is held positive while microstrain carries the tan(theta) term.
for key, value in {"U": 10.0, "W": 20.0, "X": 1.0, "SH/L": 0.03}.items():
    hist.InstrumentParameters[key] = [value, value, False]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 0.10
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 2000.0


def report(stage):
    out = {
        "stage": stage,
        "wR": hist.get_wR(),
        "instrument": {k: hist.InstrumentParameters[k][1] for k in ["U", "W", "X", "SH/L"]},
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "md": hap["Pref.Ori."],
    }
    print(json.dumps(out, indent=2))
    shutil.copy2(project.filename, f"physical_{stage}.gpx")


def run(stage, cycles=10):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    report(stage)


phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
run("01_size")
phase.clear_HAP_refinements({"Size": True})

hist.set_refinements({"Instrument Parameters": ["W"]})
run("02_W")
hist.clear_refinements({"Instrument Parameters": ["W"]})

phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
run("03_strain")
phase.clear_HAP_refinements({"Mustrain": True})

hist.set_refinements({"Instrument Parameters": ["SH/L"]})
run("04_SHL")
hist.clear_refinements({"Instrument Parameters": ["SH/L"]})

# Joint replay of the nondegenerate physical profile terms.
phase.set_HAP_refinements({
    "Size": {"type": "isotropic", "refine": True},
    "Mustrain": {"type": "isotropic", "refine": True},
})
hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
run("05_joint", 15)
