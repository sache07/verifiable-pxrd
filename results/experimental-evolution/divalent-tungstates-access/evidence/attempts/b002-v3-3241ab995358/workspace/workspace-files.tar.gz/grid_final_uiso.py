import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


def set_uiso(phase, value):
    for atom in phase.atoms():
        if atom.adp_flag != "I":
            atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(value)


base = G2.G2Project("final_model_work.gpx")
base.save("final_uiso_base.gpx")
hist = base.histogram(0)
for phase in base.phases():
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {"Size": True, "Mustrain": True, "Pref.Ori.": True}
    )
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
)
hist.clear_refinements(
    {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
)
base.save()

grids = {
    0: [0.0060, 0.0065, 0.0070, 0.0075, 0.0080],
    1: [0.0140, 0.0160, 0.0180, 0.0200],
    2: [0.0140, 0.0160, 0.0180, 0.0200],
}
running = "final_uiso_base.gpx"
records = []
for phase_index, values in grids.items():
    trials = []
    for value in values:
        filename = f"final_u{phase_index}_{value:.4f}.gpx"
        shutil.copy2(running, filename)
        project = G2.G2Project(filename)
        set_uiso(project.phase(phase_index), value)
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        trials.append(
            {"uiso": value, "wR": project.histogram(0).get_wR(), "file": filename}
        )
    best = min(trials, key=lambda row: row["wR"])
    records.append(
        {
            "phase_index": phase_index,
            "phase_name": G2.G2Project(best["file"]).phase(phase_index).name,
            "trials": trials,
            "best": best,
        }
    )
    running = best["file"]

shutil.copy2(running, "final_uiso.gpx")
print(
    json.dumps(
        {
            "baseline_wR": G2.G2Project("final_uiso_base.gpx").histogram(0).get_wR(),
            "records": records,
            "final_wR": G2.G2Project("final_uiso.gpx").histogram(0).get_wR(),
        },
        indent=2,
    )
)
