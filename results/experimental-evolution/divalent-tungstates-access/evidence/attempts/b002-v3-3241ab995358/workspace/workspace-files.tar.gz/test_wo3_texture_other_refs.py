import json

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
results = []
for cod_id, use_heavy in [("1528915", True), ("2106293", False)]:
    base = G2.G2Project(f"wo3_{cod_id}.gpx")
    base.save(f"wo3_texture_base_{cod_id}.gpx")
    hist = base.histogram(0)
    zn, wo3 = base.phases()
    for phase in [zn, wo3]:
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]})
    if use_heavy:
        labels = [a.label for a in wo3.atoms() if a.element == "W"]
        wo3.set_refinements({"Atoms": {label: "X" for label in labels}})
        base.set_Controls("cycles", 15)
        base.refine()
        wo3.clear_refinements({"Atoms": labels})
        base.save()
    for axis in [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]:
        tag = "".join(map(str, axis))
        project = G2.G2Project(f"wo3_texture_base_{cod_id}.gpx")
        project.save(f"wo3_{cod_id}_texture_{tag}.gpx")
        hist = project.histogram(0)
        wo3 = project.phase(1)
        hap = wo3.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        wo3.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("cycles", 12)
        project.refine()
        project.save()
        results.append({"cod_id": cod_id, "axis": axis, "ratio": hap["Pref.Ori."][1], "wR": hist.get_wR()})
print(json.dumps(results, indent=2))
