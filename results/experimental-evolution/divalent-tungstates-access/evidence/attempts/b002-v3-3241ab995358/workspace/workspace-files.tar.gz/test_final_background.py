import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
source = "final_uiso.gpx"
base = G2.G2Project(source)
base_coeffs = list(base.histogram(0).data["Background"][0][3:])
results = []
for count in (8, 10, 12, 14, 16, 18):
    filename = f"final_background_{count}.gpx"
    shutil.copy2(source, filename)
    project = G2.G2Project(filename)
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements(
            {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
        )
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
    )
    coeffs = (base_coeffs + [0.0] * count)[:count]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": count,
                "coeffs": coeffs,
                "refine": True,
            }
        }
    )
    project.set_Controls("cycles", 15)
    project.refine()
    project.save()
    array = hist.data["data"][1]
    results.append(
        {
            "coefficients": count,
            "wR": hist.get_wR(),
            "background_min": float(np.min(array[4])),
            "background_max": float(np.max(array[4])),
            "file": filename,
        }
    )

print(json.dumps({"baseline_wR": base.histogram(0).get_wR(), "results": results}, indent=2))
