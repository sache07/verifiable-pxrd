import json
import shutil

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("final_coordinates_work.gpx")
project.save("relaxed_model.gpx")
hist = project.histogram(0)
zn, wo3 = project.phases()

for phase in (zn, wo3):
    phase.clear_refinements(
        {"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]}
    )
    phase.clear_HAP_refinements(
        {"Size": True, "Mustrain": True, "Pref.Ori.": True}
    )
hist.clear_refinements(
    {"Instrument Parameters": ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]}
)
hist.clear_refinements(
    {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
)


def snapshot(stage):
    masses = [phase.data["General"]["Mass"] for phase in (zn, wo3)]
    scales = [phase.data["Histograms"][hist.name]["Scale"][0] for phase in (zn, wo3)]
    weighted = [mass * scale for mass, scale in zip(masses, scales)]
    row = {
        "stage": stage,
        "wR": hist.get_wR(),
        "fractions": [value / sum(weighted) for value in weighted],
        "cells": [phase.get_cell() for phase in (zn, wo3)],
        "instrument": {
            name: hist.InstrumentParameters[name][1]
            for name in ("Zero", "U", "W", "X", "SH/L", "Polariz.")
        },
        "profile": [
            {
                "size": phase.data["Histograms"][hist.name]["Size"][1][0],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
            }
            for phase in (zn, wo3)
        ],
    }
    print(json.dumps(row))
    shutil.copy2(project.filename, f"relaxed_{stage}.gpx")


def run(stage, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    snapshot(stage)


for tag, phase in (("zn", zn), ("wo3", wo3)):
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run(f"{tag}_size")
    phase.clear_HAP_refinements({"Size": True})
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run(f"{tag}_strain")
    phase.clear_HAP_refinements({"Mustrain": True})

for name in ("W", "SH/L"):
    hist.set_refinements({"Instrument Parameters": [name]})
    run("inst_" + name.replace("/", "_"))
    hist.clear_refinements({"Instrument Parameters": [name]})

zn.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
run("zn_cell_zero", 15)
zn.clear_refinements({"Cell": True})
hist.clear_refinements({"Instrument Parameters": ["Zero"]})

wo3.set_refinements({"Cell": True})
run("wo3_cell", 15)
wo3.clear_refinements({"Cell": True})

project.save("relaxed_model.gpx")
