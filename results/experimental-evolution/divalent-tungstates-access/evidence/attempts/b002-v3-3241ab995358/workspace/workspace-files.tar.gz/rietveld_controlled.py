import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")


def plain(x):
    if isinstance(x, dict):
        return {str(k): plain(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [plain(v) for v in x]
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    return x


def state(project, label):
    hist = project.histogram(0)
    phase = project.phase(0)
    inst = hist.InstrumentParameters
    hap = phase.data["Histograms"][hist.name]
    record = {
        "stage": label,
        "wR": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "cell": phase.get_cell(),
        "instrument": {k: v[1] for k, v in inst.items() if k in ["Zero", "U", "V", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: (v[0] if isinstance(v, list) else v) for k, v in hist.SampleParameters.items() if k in ["Scale", "Shift", "SurfRoughA", "SurfRoughB"]},
        "hap": {"Size": hap["Size"], "Mustrain": hap["Mustrain"], "Pref.Ori.": hap["Pref.Ori."]},
        "atoms": [{"label": a.label, "xyz": a.coordinates, "uiso": a.uiso, "flags": a.refinement_flags} for a in phase.atoms()],
        "vary": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
    }
    record = plain(record)
    print(json.dumps(record, indent=2))
    with Path("controlled_log.jsonl").open("a") as stream:
        stream.write(json.dumps(record) + "\n")


def refine(project, label, cycles=8):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine()
    project.save()
    state(project, label)
    shutil.copy2(project.filename, f"controlled_{label}.gpx")


Path("controlled_log.jsonl").unlink(missing_ok=True)
project = G2.G2Project(newgpx="controlled.gpx")
hist = project.add_powder_histogram("inputs/pattern.csv", "initial.instprm", fmthint="comma")
phase = project.add_phase(
    "candidate_znwo4_modern_start.cif",
    phasename="ZnWO4_wolframite",
    histograms=[hist],
    fmthint="CIF",
)

hist.set_refinements({
    "Limits": [9.90343322, 100.09455322],
    "Background": {"type": "chebyschev-1", "no. coeffs": 12, "coeffs": [900.0] + [0.0] * 11, "refine": True},
})
hist.SampleParameters["Scale"] = [1.0, True]
hist.SampleParameters["Shift"] = [0.0, False]
hist.SampleParameters["Gonio. radius"] = 200.0
phase.data["Histograms"][hist.name]["Scale"] = [1.0, False]

# Effective isotropic profile starts. Only one side of each exact size/X and
# strain/U correlation is used in this single-phase fit.
hist.InstrumentParameters["U"] = [40.0, 40.0, False]
hist.InstrumentParameters["W"] = [20.0, 20.0, False]
hist.InstrumentParameters["X"] = [5.0, 5.0, False]
hist.InstrumentParameters["SH/L"] = [0.03, 0.03, False]
hap = phase.data["Histograms"][hist.name]
hap["Size"][1][0] = 1.0
hap["Mustrain"][1][0] = 0.0

refine(project, "01_scale_bg", 6)

phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
refine(project, "02_cell_zero", 10)
phase.clear_refinements({"Cell": True})
hist.clear_refinements({"Instrument Parameters": ["Zero"]})

for index, name in enumerate(["W", "X", "U", "SH/L"], start=3):
    hist.set_refinements({"Instrument Parameters": [name]})
    refine(project, f"{index:02d}_{name.replace('/', '_')}", 8)
    hist.clear_refinements({"Instrument Parameters": [name]})

# Repeat the metric and offset against the established peak widths.
phase.set_refinements({"Cell": True})
hist.set_refinements({"Instrument Parameters": ["Zero"]})
refine(project, "07_cell_zero_repeat", 10)
phase.clear_refinements({"Cell": True})
hist.clear_refinements({"Instrument Parameters": ["Zero"]})

# Heavy sites, then each oxygen substructure, with profile/calibration fixed.
for index, label in enumerate(["W1", "Zn0", "O2", "O3"], start=8):
    phase.set_refinements({"Atoms": {label: "X"}})
    refine(project, f"{index:02d}_{label}_xyz", 10)
    phase.clear_refinements({"Atoms": [label]})

# Joint coordinate replay after the one-site starts have settled.
phase.set_refinements({"Atoms": {"all": "X"}})
refine(project, "12_all_xyz", 12)
phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})

project.save("controlled.gpx")
