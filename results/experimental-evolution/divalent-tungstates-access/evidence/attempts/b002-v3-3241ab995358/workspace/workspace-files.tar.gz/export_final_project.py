import json

import numpy as np
from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project = G2.G2Project("polished_shift.gpx")
project.save("final.gpx")

# Reload exactly what will be submitted, then export its saved atomic models.
project = G2.G2Project("final.gpx")
hist = project.histogram(0)
phases = project.phases()
outputs = ["phase_ZnWO4.cif", "phase_WO3.cif", "phase_ZnO.cif"]
for phase, filename in zip(phases, outputs):
    phase.export_CIF(filename)

weighted = [
    phase.data["General"]["Mass"]
    * phase.data["Histograms"][hist.name]["Scale"][0]
    for phase in phases
]
fractions = [value / sum(weighted) for value in weighted]
array = hist.data["data"][1]
x, observed, calculated = array[0], array[1], array[3]
if len(x) != 8301 or not np.all(np.isfinite(calculated)):
    raise ValueError("Final project does not contain the complete finite fit grid")

rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
summary = {
    "project": "final.gpx",
    "histogram": hist.name,
    "cached_wR_percent": hist.get_wR(),
    "cached_GOF": rvals.get("GOF"),
    "phase_names": [phase.name for phase in phases],
    "cif_paths": outputs,
    "weight_fractions": fractions,
    "cells": [phase.get_cell() for phase in phases],
}
with open("final_project_summary.json", "w") as stream:
    json.dump(summary, stream, indent=2)
    stream.write("\n")
print(json.dumps(summary, indent=2))
