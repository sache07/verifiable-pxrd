#!/usr/bin/env python3
"""Build and incrementally refine a GSAS-II model for the supplied pattern.

This is an exploratory refinement driver. It deliberately logs the objective and
all nuisance parameters after each block so alternative physical models can be
compared from saved projects rather than from phase-only fits.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE_CIF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/1/52/02/1520200.cif"
)


def write_inputs(work: Path) -> tuple[Path, Path]:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    data = work / "pattern.xye"
    np.savetxt(data, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return data, inst


def snapshot(project: G2.G2Project, label: str, records: list[dict]) -> None:
    hist = project.histograms()[0]
    phase = project.phases()[0]
    hname = hist.name
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    hap = phase.data["Histograms"][hname]
    cov = project.data.get("Covariance", {}).get("data", {})
    row = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("GOF"),
        "Nobs": cov.get("Nobs"),
        "Nvars": len(cov.get("varyList", [])),
        "cell": phase.data["General"]["Cell"][1:7],
        "instrument": {k: inst[k][1] for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."] if k in inst},
        "sample": {k: sample[k][0] if isinstance(sample.get(k), list) else sample.get(k)
                   for k in ["Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "hap_scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "varyList": [str(v) for v in cov.get("varyList", [])],
    }
    records.append(row)
    print(json.dumps(row, indent=2, default=str), flush=True)


def run_refinement(project: G2.G2Project, label: str, records: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    snapshot(project, label, records)
    project.save()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--work", default=".tmp/mnwo4-basic")
    parser.add_argument("--background", type=int, default=12)
    args = parser.parse_args()

    G2.SetPrintLevel("all")
    work = (ROOT / args.work).resolve()
    work.mkdir(parents=True, exist_ok=True)
    data, inst_file = write_inputs(work)
    gpx = work / "trial.gpx"
    if gpx.exists():
        gpx.unlink()

    project = G2.G2Project(newgpx=str(gpx))
    phase = project.add_phase(str(SOURCE_CIF), phasename="MnWO4_wolframite", fmthint="CIF")
    hist = project.add_powder_histogram(str(data), str(inst_file), phases=[phase], fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": args.background,
            "coeffs": [1400.0] + [0.0] * (args.background - 1),
            "refine": True,
        },
    })
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][1][1] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][1][1] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    records: list[dict] = []

    phase.set_HAP_refinements({"Scale": True})
    run_refinement(project, "background_scale", records)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "cell_zero", records)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(project, "instrument_profile", records)

    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run_refinement(project, "isotropic_mustrain", records)

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_refinement(project, "polarization", records)

    (work / "history.json").write_text(json.dumps(records, indent=2, default=str) + "\n")
    print(f"Saved {gpx}")


if __name__ == "__main__":
    main()
