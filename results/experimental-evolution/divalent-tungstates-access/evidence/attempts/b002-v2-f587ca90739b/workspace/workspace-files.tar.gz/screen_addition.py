#!/usr/bin/env python3
"""Test one candidate phase in a frozen common multiphase GSAS-II state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


def fractions(project: G2.G2Project, histogram: str) -> dict[str, float]:
    raw = {
        phase.name: float(phase.data["General"]["Mass"])
        * float(phase.data["Histograms"][histogram]["Scale"][0])
        for phase in project.phases()
    }
    total = sum(raw.values())
    return {k: v / total for k, v in raw.items()}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("candidate")
    ap.add_argument("output")
    ap.add_argument("--name", required=True)
    ap.add_argument("--cell", action="store_true")
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    out = Path(args.output).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(args.base).resolve(), out)
    project = G2.G2Project(gpxfile=str(out))
    hist = project.histograms()[0]
    hname = hist.name

    trial = project.add_phase(
        str(Path(args.candidate).resolve()), phasename=args.name,
        histograms=[hist], fmthint="CIF",
    )
    # add_phase saves/reloads the project, so freeze the common state after the
    # candidate has been linked. Only the trial scale and optionally its lattice
    # are allowed to move in this diagnostic.
    hist = project.histograms()[0]
    hname = hist.name
    hist.clear_refinements({
        "Instrument Parameters": list(hist.data["Instrument Parameters"][0]),
        "Sample Parameters": [k for k, v in hist.data["Sample Parameters"].items() if isinstance(v, list) and len(v) > 1],
    })
    hist.clear_refinements({"Background": True})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True})
    hap = trial.data["Histograms"][hname]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = hap["Size"][1][1] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    trial.set_HAP_refinements({"Scale": True}, histograms=[hist])
    if args.cell:
        trial.set_refinements({"Cell": True})
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()

    hap = trial.data["Histograms"][hname]
    result = {
        "base": str(Path(args.base).resolve()),
        "candidate": str(Path(args.candidate).resolve()),
        "project": str(out),
        "name": trial.name,
        "Rwp_percent": hist.get_wR(),
        "candidate_scale": float(hap["Scale"][0]),
        "candidate_cell": [float(v) for v in trial.data["General"]["Cell"][1:7]],
        "weight_fractions": fractions(project, hname),
    }
    out.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
