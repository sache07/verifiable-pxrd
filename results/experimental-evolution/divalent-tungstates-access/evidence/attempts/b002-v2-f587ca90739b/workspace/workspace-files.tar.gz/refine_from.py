#!/usr/bin/env python3
"""Continue a saved GSAS-II project with explicit physical/profile options."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_three import fractions, set_bounds


def axis(text: str) -> list[int]:
    values = [int(v) for v in text.split(",")]
    if len(values) != 3 or values == [0, 0, 0]:
        raise ValueError("axis must be nonzero h,k,l")
    return values


def physicalize(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    limits = {
        "Zero": (-0.25, 0.25), "U": (0.0, 40.0), "W": (2.0, 40.0),
        "X": (0.1, 6.0), "SH/L": (0.005, 0.1), "Polariz.": (0.5, 0.999),
    }
    for key, (lo, hi) in limits.items():
        inst[key][1] = min(hi, max(lo, float(inst[key][1])))
    sample = hist.data["Sample Parameters"]
    sample["Shift"][0] = min(800.0, max(-800.0, float(sample["Shift"][0])))
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = max(1e-10, float(hap["Scale"][0]))
        hap["Size"][1][0] = min(1.5, max(0.04, float(hap["Size"][1][0])))
        hap["Mustrain"][1][0] = min(8000.0, max(0.0, float(hap["Mustrain"][1][0])))
        hap["Pref.Ori."][1] = min(1.4, max(0.7, float(hap["Pref.Ori."][1])))
    project.set_Frozen()
    set_bounds(project)


def summarize(project: G2.G2Project, output: Path) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    data = hist.data["data"][1]
    result = {
        "project": str(output),
        "Rwp_percent": float(hist.get_wR()),
        "weight_fractions": fractions(project, hist.name),
        "instrument": {key: float(inst[key][1]) for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "sample": {key: float(sample[key][0]) for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "background_min": float(np.min(data[4])),
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "size_model": hap["Size"][0],
            "microstrain_model": hap["Mustrain"][0],
            "preferred_orientation": [hap["Pref.Ori."][0], float(hap["Pref.Ori."][1]), bool(hap["Pref.Ori."][2]), list(hap["Pref.Ori."][3])],
        }
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("input")
    ap.add_argument("output")
    ap.add_argument("--cycles", type=int, default=15)
    ap.add_argument("--physical", action="store_true")
    ap.add_argument("--md", action="append", default=[], help="phase-index:h,k,l")
    ap.add_argument("--coordinates", action="append", type=int, default=[])
    ap.add_argument("--roughness", action="store_true")
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    phases = project.phases()
    if args.physical:
        physicalize(project)
    else:
        project.set_Frozen()
    for item in args.md:
        phase_text, axis_text = item.split(":", 1)
        phase = phases[int(phase_text)]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis(axis_text)
        phase.set_HAP_refinements({"Pref.Ori.": True})
    for phase_index in args.coordinates:
        phases[phase_index].set_refinements({"Atoms": {"all": "X"}})
    if args.roughness:
        sample = hist.data["Sample Parameters"]
        if sample["SurfRoughA"][0] <= 0:
            sample["SurfRoughA"][0] = 0.2
        if sample["SurfRoughB"][0] <= 0:
            sample["SurfRoughB"][0] = 0.1
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine()
    project.save()
    result = summarize(project, output)
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
