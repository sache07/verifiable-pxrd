#!/usr/bin/env python3
"""Staged common-state GSAS-II refinement for MnWO4 + WO3 + Mn2WO6."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_files(work: Path) -> tuple[Path, Path]:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    data = work / "pattern.xye"
    np.savetxt(
        data, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]),
        fmt="%.8f %.8f %.8f",
    )
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.70;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:25.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return data, inst


def fractions(project: G2.G2Project, hname: str) -> dict[str, float]:
    raw = {
        p.name: float(p.data["General"]["Mass"])
        * float(p.data["Histograms"][hname]["Scale"][0])
        for p in project.phases()
    }
    total = sum(raw.values())
    return {key: value / total for key, value in raw.items()}


def normalize_adps(phase: G2.G2Phase) -> None:
    # The synthetic source registration uses isotropic Uiso=0.005 A^2.
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = 0.005
        atom.refinement_flags = " "


def set_bounds(project: G2.G2Project) -> None:
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1),
        ":0:Polariz.": (0.5, 0.999),
        ":0:SurfRoughA": (0.0, 1.0),
        ":0:SurfRoughB": (0.0, 1.0),
    }
    for pid in range(3):
        bounds[f"{pid}:0:Scale"] = (1e-10, 1e5)
        bounds[f"{pid}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{pid}:0:Mustrain;i"] = (0.0, 8000.0)
        bounds[f"{pid}:0:MD"] = (0.7, 1.4)
    for variable, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)


def snapshot(project: G2.G2Project, label: str, history: list[dict]) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    profile = hist.data["data"][1]
    row = {
        "label": label,
        "Rwp_percent": float(hist.get_wR()),
        "weight_fractions": fractions(project, hist.name),
        "instrument": {
            key: float(inst[key][1])
            for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
            if key in inst
        },
        "sample": {
            key: float(sample[key][0])
            for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "background_min": float(np.min(profile[4])),
        "frozen": project.get_Frozen(),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "volume": float(phase.data["General"]["Cell"][7]),
            "scale": float(hap["Scale"][0]),
            "size": copy.deepcopy(hap["Size"]),
            "mustrain": copy.deepcopy(hap["Mustrain"]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        }
    history.append(row)
    print(json.dumps(row, indent=2, default=str), flush=True)


def refine(project: G2.G2Project, label: str, history: list[dict], cycles: int = 10) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    snapshot(project, label, history)


def parse_axis(text: str | None) -> list[int] | None:
    if text is None:
        return None
    axis = [int(v) for v in text.split(",")]
    if len(axis) != 3 or axis == [0, 0, 0]:
        raise ValueError("orientation axis must be nonzero h,k,l")
    return axis


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wo3", default="2311041")
    ap.add_argument("--third", default=str(ROOT / ".tmp/analogues/Mn2WO6_P212121_from_Y2WO6_1541070_scaled.cif"))
    ap.add_argument("--work", required=True)
    ap.add_argument("--background", type=int, default=12)
    ap.add_argument("--md1")
    ap.add_argument("--md2")
    ap.add_argument("--md3")
    ap.add_argument("--coordinates", action="store_true")
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    work = (ROOT / args.work).resolve()
    work.mkdir(parents=True, exist_ok=True)
    data, inst_file = prepare_files(work)
    gpx = work / "trial.gpx"
    gpx.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(gpx))
    phases = [
        project.add_phase(str(cif_path("1520200")), phasename="MnWO4_wolframite", fmthint="CIF"),
        project.add_phase(str(cif_path(args.wo3)), phasename=f"WO3_{args.wo3}", fmthint="CIF"),
        project.add_phase(str(Path(args.third).resolve()), phasename="Mn2WO6_P212121", fmthint="CIF"),
    ]
    for phase in phases:
        normalize_adps(phase)
    hist = project.add_powder_histogram(str(data), str(inst_file), phases=phases, fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1", "no. coeffs": args.background,
            "coeffs": [1200.0] + [0.0] * (args.background - 1), "refine": True,
        },
    })

    start_sizes = [0.5, 0.25, 0.12]
    start_strains = [500.0, 800.0, 1200.0]
    for phase, size, strain in zip(phases, start_sizes, start_strains):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = hap["Size"][1][1] = size
        hap["Size"][1][2] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = strain
        hap["Mustrain"][1][2] = 1.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        phase.set_HAP_refinements({"Scale": True})

    project.update_ids()
    set_bounds(project)
    history: list[dict] = []
    refine(project, "background_scales", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_zero", history)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "sample_shift", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "instrument_uwx", history, 12)

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine(project, "isotropic_sizes", history, 12)

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "isotropic_strains", history, 12)

    hist.set_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})
    refine(project, "axial_polarization", history, 12)

    for phase, text in zip(phases, [args.md1, args.md2, args.md3]):
        axis = parse_axis(text)
        if axis is not None:
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][3] = axis
            phase.set_HAP_refinements({"Pref.Ori.": True})
    if any((args.md1, args.md2, args.md3)):
        refine(project, "preferred_orientation", history, 12)

    if args.coordinates:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
            refine(project, f"coordinates_{phase.name}", history, 12)
        refine(project, "coordinates_joint", history, 15)

    project.save()
    (work / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    print(json.dumps({"gpx": str(gpx), "final": history[-1]}, indent=2, default=str))


if __name__ == "__main__":
    main()
