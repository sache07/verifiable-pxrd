#!/usr/bin/env python3
"""Common-state two-phase GSAS-II trials for MnWO4 + a WO3 prototype."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cif_path(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_files(work: Path) -> tuple[Path, Path]:
    x, y = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1).T
    data = work / "pattern.xye"
    np.savetxt(data, np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]), fmt="%.8f %.8f %.8f")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for lab Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.70;Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:10.0;V:0.0;W:10.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return data, inst


def phase_fraction(project: G2.G2Project, hist_name: str) -> dict[str, float]:
    raw = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        raw[phase.name] = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
    total = sum(raw.values())
    return {k: v / total for k, v in raw.items()}


def snapshot(project: G2.G2Project, label: str, history: list[dict]) -> None:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "weight_fractions": phase_fraction(project, hist.name),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."] if k in inst},
        "sample": {k: float(sample[k][0]) for k in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]},
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "volume": float(phase.data["General"]["Cell"][7]),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    history.append(row)
    print(json.dumps(row, indent=2, default=str), flush=True)


def refine(project: G2.G2Project, label: str, history: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    snapshot(project, label, history)
    project.save()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wo3", required=True, help="COD id for the WO3 prototype")
    ap.add_argument("--work", required=True)
    ap.add_argument("--background", type=int, default=12)
    args = ap.parse_args()

    G2.SetPrintLevel("warn")
    work = (ROOT / args.work).resolve()
    work.mkdir(parents=True, exist_ok=True)
    data, inst_file = prepare_files(work)
    gpx = work / "trial.gpx"
    gpx.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(gpx))
    phases = [
        project.add_phase(str(cif_path("1520200")), phasename="MnWO4_wolframite", fmthint="CIF"),
        project.add_phase(str(cif_path(args.wo3)), phasename=f"WO3_{args.wo3}", fmthint="CIF"),
    ]
    hist = project.add_powder_histogram(str(data), str(inst_file), phases=phases, fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
        "Background": {
            "type": "chebyschev-1", "no. coeffs": args.background,
            "coeffs": [1400.0] + [0.0] * (args.background - 1), "refine": True,
        },
    })
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = hap["Size"][1][1] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        phase.set_HAP_refinements({"Scale": True})

    history: list[dict] = []
    refine(project, "background_scales", history)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_zero", history)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "profile_uwx", history)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, "profile_shl", history)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization", history)

    (work / "history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    print(json.dumps({"gpx": str(gpx), "final": history[-1]}, indent=2, default=str))


if __name__ == "__main__":
    main()
