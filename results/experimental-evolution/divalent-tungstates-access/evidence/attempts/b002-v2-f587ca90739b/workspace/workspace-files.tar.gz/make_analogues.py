#!/usr/bin/env python3
"""Create chemistry-transferred Mn-W-O prototypes from COD analogues."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parent
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / ".tmp" / "analogues"


def source(cod_id: str) -> Path:
    return LIB / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def transfer(cod_id: str, old: str, new: str, output: str, lattice_scale: float = 1.0) -> None:
    structure = CifParser(source(cod_id), occupancy_tolerance=2).parse_structures(primitive=False)[0]
    structure.remove_oxidation_states()
    structure.replace_species({old: new})
    if lattice_scale != 1.0:
        structure.scale_lattice(structure.volume * lattice_scale**3)
    CifWriter(structure, symprec=1e-3, refine_struct=False, significant_figures=10).write_file(OUT / output)
    print(output, structure.composition, structure.get_space_group_info())


def transfer_map(
    cod_id: str,
    replacements: dict[str, str],
    output: str,
    target_cell: tuple[float, float, float] | None = None,
) -> None:
    """Transfer a framework with one or two substitutions onto a common cell."""
    structure = CifParser(source(cod_id), occupancy_tolerance=2).parse_structures(primitive=False)[0]
    structure.remove_oxidation_states()
    structure.replace_species(replacements)
    if target_cell is not None:
        structure = Structure(
            Lattice.orthorhombic(*target_cell), structure.species,
            structure.frac_coords, site_properties=structure.site_properties,
        )
    CifWriter(structure, symprec=1e-3, refine_struct=False, significant_figures=10).write_file(OUT / output)
    print(output, structure.composition, structure.get_space_group_info())


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    transfer("2310464", "Fe", "Mn", "Mn2WO6_ordered_Pbcn_from_Fe2WO6_2310464.cif")
    transfer("1565524", "Fe", "Mn", "Mn2WO6_disordered_Pbcn_from_Fe2WO6_1565524.cif")
    transfer("1563081", "Ca", "Mn", "Mn3WO6_P21c_from_Ca3WO6_1563081.cif")
    transfer("1527404", "Cu", "Mn", "Mn3WO6_Pa3_from_Cu3WO6_1527404.cif")
    transfer("1541070", "Y", "Mn", "Mn2WO6_P212121_from_Y2WO6_1541070_scaled.cif", 0.9625)
    transfer("1541070", "Y", "Mn", "Mn2WO6_P212121_from_Y2WO6_1541070.cif")
    transfer("2107328", "Bi", "Mn", "Mn2WO6_Pca21_from_Bi2WO6_2107328_scaled.cif", 0.945)
    transfer("1528730", "Bi", "Mn", "Mn2WO6_Aea2_from_Bi2WO6_1528730_scaled.cif", 0.9775)
    transfer("1008912", "V", "Mn", "Mn2WO6_P42mnm_from_V2WO6_1008912_scaled.cif", 1.07)
    transfer("1530909", "Cr", "Mn", "Mn2WO6_P42mnm_from_Cr2WO6_1530909_scaled.cif", 1.08)
    common_cell = (5.04618, 8.67536, 9.54448)
    transfer_map(
        "2213598", {"Y": "Mn", "Te": "W"},
        "Mn2WO6_P212121_from_Y2TeO6_2213598_commoncell.cif", common_cell,
    )
    transfer_map(
        "1535177", {"Gd": "Mn", "Te": "W"},
        "Mn2WO6_P212121_from_Gd2TeO6_1535177_commoncell.cif", common_cell,
    )
    transfer_map(
        "8100234", {"Nd": "Mn", "Te": "W"},
        "Mn2WO6_P212121_from_Nd2TeO6_8100234_commoncell.cif", common_cell,
    )


if __name__ == "__main__":
    main()
