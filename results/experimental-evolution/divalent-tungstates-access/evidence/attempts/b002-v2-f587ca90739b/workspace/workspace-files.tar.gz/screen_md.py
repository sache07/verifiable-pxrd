#!/usr/bin/env python3
"""Frozen-common-state March-Dollase axis screen."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2

from refine_three import fractions


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base")
    ap.add_argument("output")
    ap.add_argument("phase", type=int)
    ap.add_argument("axis")
    args = ap.parse_args()
    direction = [int(v) for v in args.axis.split(",")]

    G2.SetPrintLevel("warn")
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(Path(args.base).resolve(), output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Frozen()
    hist = project.histograms()[0]
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Instrument Parameters": list(hist.data["Instrument Parameters"][0]),
        "Sample Parameters": [
            key for key, value in hist.data["Sample Parameters"].items()
            if isinstance(value, list) and len(value) > 1
        ],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True,
        })
    target = project.phases()[args.phase]
    hap = target.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = direction
    target.set_HAP_refinements({"Scale": True, "Pref.Ori.": True})
    project.set_Controls("parmMin", 0.7, variable=f"{args.phase}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{args.phase}:0:MD")
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()
    result = {
        "phase": target.name,
        "axis": direction,
        "Rwp_percent": float(hist.get_wR()),
        "MD_ratio": float(hap["Pref.Ori."][1]),
        "weight_fractions": fractions(project, hist.name),
        "frozen": project.get_Frozen(),
    }
    output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
