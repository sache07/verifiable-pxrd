#!/usr/bin/env python3
"""Final common instrumental W and axial-divergence profile refinement."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT


SOURCE = ROOT / ".tmp" / "surface-bounded" / "rough-0.gpx"
OUT = ROOT / ".tmp" / "instrument-final"


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    gpx = G2.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    hist = gpx.histogram(0)

    # The roughness correction curve is reproducible but A and B are nearly
    # collinear at small B. Freeze its accepted profile before peak-shape work.
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    # The bounded roughness trial correctly stopped B at its laboratory lower
    # limit. Remove that trial-only frozen-variable marker now that B is fixed.
    gpx.set_Frozen()
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    gpx.set_Controls("parmMin", 0.1, variable=":0:W")
    gpx.set_Controls("parmMax", 100.0, variable=":0:W")
    gpx.set_Controls("parmMin", 0.0, variable=":0:SH/L")
    gpx.set_Controls("parmMax", 0.25, variable=":0:SH/L")

    rows = []
    for iteration in range(4):
        gpx.set_Controls("cycles", 30)
        gpx.refine()
        gpx.save()
        cov = gpx.data["Covariance"]["data"].get("Rvals", {})
        inst = hist.data["Instrument Parameters"][0]
        row = {
            "iteration": iteration,
            "W": inst["W"][1],
            "SH/L": inst["SH/L"][1],
            "rwp_percent": hist.get_wR(),
            "max_shift_over_esd": cov.get("Max shft/sig"),
            "converged": cov.get("converged"),
        }
        rows.append(row)
        shutil.copy2(gpx.filename, OUT / f"{iteration:02d}-profile.gpx")
        print(json.dumps(row), flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
