#!/usr/bin/env python3
"""Compare isotropic and uniaxial microstrain models from one converged GPX."""

from pathlib import Path
import argparse
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--tag", required=True)
    args = parser.parse_args()
    source = Path(args.source)
    out = ROOT / ".tmp" / f"strain-tests-{args.tag}"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    G2.SetPrintLevel("error")
    models = [("isotropic", None, 1.0)]
    for axis in ([1, 0, 0], [0, 1, 0], [0, 0, 1]):
        for ratio in (0.5, 2.0):
            models.append(("uniaxial", axis, ratio))
    results = []
    for model, axis, ratio in models:
        axis_text = "iso" if axis is None else "".join(map(str, axis))
        label = f"{axis_text}-{ratio:.1f}"
        dest = out / f"{label}.gpx"
        gpx = G2.G2Project(str(source), newgpx=str(dest))
        hist = gpx.histogram(0)
        phase = gpx.phase(args.phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = model
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][1][1] = 500.0 * ratio
        hap["Mustrain"][1][2] = 1.0
        if axis is not None:
            hap["Mustrain"][3] = list(axis)
        phase.set_HAP_refinements(
            {
                "Mustrain": (
                    {"type": "isotropic", "refine": True}
                    if model == "isotropic"
                    else {"type": "uniaxial", "direction": list(axis), "refine": True}
                )
            }
        )
        for key in ("Mustrain;i", "Mustrain;a"):
            variable = f"{args.phase}:0:{key}"
            gpx.set_Controls("parmMin", 0.0, variable=variable)
            gpx.set_Controls("parmMax", 20000.0, variable=variable)
        gpx.set_Controls("cycles", 20)
        gpx.refine()
        gpx.save()
        strain = hap["Mustrain"]
        row = {
            "model": model,
            "axis": axis,
            "start_ratio": ratio,
            "values": strain[1][:2],
            "rwp_percent": hist.get_wR(),
            "fractions": {key: value[0] for key, value in hist.ComputeMassFracs().items()},
            "gpx": str(dest),
        }
        results.append(row)
        print(json.dumps(row), flush=True)
    results.sort(key=lambda row: row["rwp_percent"])
    (out / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print("BEST", json.dumps(results[0]), flush=True)


if __name__ == "__main__":
    main()
