#!/usr/bin/env python3
"""Final, phasewise refinement trials for the accepted three-phase model."""

from __future__ import annotations

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT
from refine_multi_v2 import describe


SOURCE = ROOT / ".tmp" / "strain-tests-zno" / "iso-1.0.gpx"
OUT = ROOT / ".tmp" / "final-refinement"


def snapshot(gpx, hist, phases, log, label):
    gpx.save()
    path = OUT / f"{len(log):02d}-{label}.gpx"
    shutil.copy2(gpx.filename, path)
    row = describe(gpx, hist, phases, label)
    row["gpx"] = str(path)
    log.append(row)
    print(
        f"{label:28s} Rwp={row['rwp_percent']:.6f} "
        f"GOF={row['gof']!s:>10} shift/esd={row['max_shift_over_esd']!s:>10}",
        flush=True,
    )
    return row


def run(gpx, hist, phases, log, label, cycles=20):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    return snapshot(gpx, hist, phases, log, label)


def set_bounds(gpx):
    bounds = {
        ":0:Zero": (-1.0, 1.0),
        ":0:Shift": (-2000.0, 2000.0),
        ":0:Polariz.": (0.0, 1.0),
        ":0:U": (0.0, 100.0),
        ":0:W": (0.1, 100.0),
        ":0:X": (0.0, 20.0),
        ":0:SH/L": (0.0, 0.25),
        "0:0:MD": (0.4, 2.5),
        "1:0:MD": (0.4, 2.5),
        "2:0:MD": (0.4, 2.5),
    }
    for phase_id in range(3):
        bounds[f"{phase_id}:0:Size;i"] = (0.02, 5.0)
        bounds[f"{phase_id}:0:Mustrain;i"] = (0.0, 20000.0)
        bounds[f"{phase_id}:0:Mustrain;a"] = (0.0, 20000.0)
        for atom_id in range(12):
            bounds[f"{phase_id}::AUiso:{atom_id}"] = (0.001, 0.04)
    for variable, (lower, upper) in bounds.items():
        gpx.set_Controls("parmMin", lower, variable=variable)
        gpx.set_Controls("parmMax", upper, variable=variable)


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    gpx = G2.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    set_bounds(gpx)

    # Refine every observed bin. The source project omitted only the two short
    # edge intervals, but the submitted project must replay the complete grid.
    x = np.asarray(hist.data["data"][1][0], float)
    hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})

    log = []
    run(gpx, hist, phases, log, "full_grid_settle", cycles=30)

    # Freeze all atomic coordinates, retaining their accepted values. Refine
    # the six independent WO3 oxygen sites one at a time from the physical COD
    # start; this avoids a light-atom block outrunning the powder information.
    for phase in phases:
        for atom in phase.atoms():
            atom.refinement_flags = ""
    wo3 = phases[1]
    oxygen_labels = [atom.label for atom in wo3.atoms() if atom.element == "O"]
    for label in oxygen_labels:
        before = {
            atom.label: list(map(float, atom.coordinates)) for atom in wo3.atoms()
        }
        wo3.set_refinements({"Atoms": {label: "X"}})
        row = run(gpx, hist, phases, log, f"wo3_{label}", cycles=18)
        atom = next(atom for atom in wo3.atoms() if atom.label == label)
        row["coordinate_change"] = {
            "label": label,
            "from": before[label],
            "to": list(map(float, atom.coordinates)),
        }
        atom.refinement_flags = ""

    # Fresh full-grid replay with all atomic coordinates fixed at the accepted
    # sequential solution. Profile, calibration, scales and background settle.
    run(gpx, hist, phases, log, "oxygen_fixed_replay", cycles=30)

    arrays = hist.data["data"][1]
    np.savetxt(
        OUT / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[5], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    (OUT / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
    for phase in phases:
        phase.export_CIF(str(OUT / f"{phase.name}.cif"))


if __name__ == "__main__":
    main()
