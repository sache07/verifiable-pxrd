#!/usr/bin/env python3
"""Test the optional GSAS-II Suortti surface-roughness correction."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT


SOURCE = ROOT / ".tmp" / "uiso-refinement" / "03-uiso_fixed_replay.gpx"
OUT = ROOT / ".tmp" / "surface-tests"


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    starts = [(0.10, 0.03), (0.25, 0.10), (0.45, 0.30), (0.60, 0.50)]
    rows = []
    for i, (start_a, start_b) in enumerate(starts):
        dest = OUT / f"rough-{i}.gpx"
        gpx = G2.G2Project(str(SOURCE), newgpx=str(dest))
        hist = gpx.histogram(0)
        hist.SampleParameters["SurfRoughA"] = [start_a, True]
        hist.SampleParameters["SurfRoughB"] = [start_b, True]
        gpx.set_Controls("parmMin", 0.01, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMax", 0.95, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMin", 0.001, variable=":0:SurfRoughB")
        gpx.set_Controls("parmMax", 1.0, variable=":0:SurfRoughB")
        gpx.set_Controls("cycles", 30)
        gpx.refine()
        gpx.save()
        cov = gpx.data["Covariance"]["data"].get("Rvals", {})
        row = {
            "start": [start_a, start_b],
            "A": hist.SampleParameters["SurfRoughA"][0],
            "B": hist.SampleParameters["SurfRoughB"][0],
            "rwp_percent": hist.get_wR(),
            "max_shift_over_esd": cov.get("Max shft/sig"),
            "converged": cov.get("converged"),
            "gpx": str(dest),
        }
        rows.append(row)
        print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["rwp_percent"])
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
