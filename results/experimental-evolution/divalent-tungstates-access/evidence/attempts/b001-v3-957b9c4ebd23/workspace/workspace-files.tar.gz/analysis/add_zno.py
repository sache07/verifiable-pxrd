#!/usr/bin/env python3
"""Test and refine wurtzite ZnO in the stable ZnWO4 + WO3 project."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT
from refine_multi_v2 import describe


SOURCE = ROOT / ".tmp" / "bounded-2311041-100" / "trial.gpx"
OUT = ROOT / ".tmp" / "threephase-zno"


def clear_all_flags(hist, phases):
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in phases:
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def run(gpx, hist, phases, log, label, cycles=12):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, OUT / f"{len(log):02d}-{label}.gpx")
    row = describe(gpx, hist, phases, label)
    log.append(row)
    fr = ", ".join(
        f"{key}={value['value']:.5f}"
        for key, value in row["fractions"].items()
        if isinstance(value, dict) and "value" in value
    )
    print(f"{label:24s} Rwp={row['rwp_percent']:.5f} {fr}", flush=True)


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    gpx = G2.G2Project(str(SOURCE), newgpx=str(OUT / "trial.gpx"))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    clear_all_flags(hist, phases)
    zno = gpx.add_phase(
        str(ROOT / "analysis" / "zno_wurtzite_start.cif"),
        phasename="ZnO_wurtzite",
        histograms=[hist],
        fmthint="CIF",
    )
    phases = gpx.phases()
    for atom in zno.atoms():
        atom.uiso = 0.01
    hap = zno.data["Histograms"][hist.name]
    hap["Scale"] = [36.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.30
    hap["Size"][1][2] = 1.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][2] = 1.0
    for phase in phases[:2]:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    gpx.save()
    for variable, lower, upper in [
        ("2:0:Size;i", 0.02, 5.0),
        ("2:0:Mustrain;i", 0.0, 20000.0),
        ("2:0:Mustrain;a", 0.0, 20000.0),
        ("2:0:MD", 0.4, 2.5),
    ]:
        gpx.set_Controls("parmMin", lower, variable=variable)
        gpx.set_Controls("parmMax", upper, variable=variable)

    log = []
    run(gpx, hist, phases, log, "scales_only", cycles=8)

    # Re-enable a conservative common background and angular calibration update.
    hist.data["Background"][0][1] = True
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    zno.set_refinements({"Cell": True})
    run(gpx, hist, phases, log, "zno_cell_calibration", cycles=12)

    for phase in phases[:2]:
        phase.set_refinements({"Cell": True})
    run(gpx, hist, phases, log, "all_cells", cycles=10)

    zno.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.30, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    run(gpx, hist, phases, log, "zno_profile", cycles=12)

    # Refine the physically meaningful internal wurtzite coordinate; hold the origin at Zn z=0.
    zno.set_refinements({"Atoms": {"O1": "X"}})
    run(gpx, hist, phases, log, "zno_internal_coordinate", cycles=10)

    # Restore the accepted parameters in the first two phases and settle together.
    phases[0].set_refinements({"Atoms": {"all": "X"}})
    phases[1].set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    for phase in phases[:2]:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": (
                    {"type": "uniaxial", "direction": [1, 0, 0], "refine": True}
                    if phase is phases[0]
                    else {"type": "isotropic", "refine": True}
                ),
            }
        )
    phases[0].set_HAP_refinements({"Pref.Ori.": True})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(gpx, hist, phases, log, "three_phase_settle", cycles=16)

    arrays = hist.data["data"][1]
    np.savetxt(
        OUT / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[5], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    (OUT / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
    for phase in phases:
        phase.export_CIF(str(OUT / f"{phase.name}.cif"))
    print(json.dumps(log[-1], indent=2), flush=True)


if __name__ == "__main__":
    main()
