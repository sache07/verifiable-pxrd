#!/usr/bin/env python3
"""Staged instrumental-profile update without width-parameter compensation."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT


SOURCE = ROOT / ".tmp" / "surface-bounded" / "rough-0.gpx"
OUT = ROOT / ".tmp" / "profile-staged"


def clear_flags(hist, phases):
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in phases:
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def restore_model_flags(hist, phases):
    hist.data["Background"][0][1] = True
    hist.data["Instrument Parameters"][0]["Zero"][2] = True
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2][1] = True
    phases[0].data["Histograms"][hist.name]["Pref.Ori."][2] = True
    phases[1].data["Histograms"][hist.name]["Pref.Ori."][2] = True


def refine(gpx, hist, rows, label, cycles):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"].get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    row = {
        "stage": label,
        "W": inst["W"][1],
        "SH/L": inst["SH/L"][1],
        "rwp_percent": hist.get_wR(),
        "covariance_rwp_percent": cov.get("Rwp"),
        "max_shift_over_esd": cov.get("Max shft/sig"),
        "converged": cov.get("converged"),
        "aborted": cov.get("Aborted", False),
        "frozen": gpx.get_Frozen(),
    }
    rows.append(row)
    shutil.copy2(gpx.filename, OUT / f"{len(rows)-1:02d}-{label}.gpx")
    print(json.dumps(row), flush=True)


def profile_cycle(gpx, hist, phases, rows, cycle):
    clear_flags(hist, phases)
    hist.data["Instrument Parameters"][0]["W"][2] = True
    refine(gpx, hist, rows, f"cycle{cycle}_W_only", 16)

    hist.data["Instrument Parameters"][0]["W"][2] = False
    hist.data["Instrument Parameters"][0]["SH/L"][2] = True
    refine(gpx, hist, rows, f"cycle{cycle}_SHL_only", 16)

    hist.data["Instrument Parameters"][0]["SH/L"][2] = False
    restore_model_flags(hist, phases)
    refine(gpx, hist, rows, f"cycle{cycle}_model_settle", 30)


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    gpx = G2.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    gpx.set_Frozen()
    gpx.set_Controls("parmMin", 0.1, variable=":0:W")
    gpx.set_Controls("parmMax", 100.0, variable=":0:W")
    gpx.set_Controls("parmMin", 0.0, variable=":0:SH/L")
    gpx.set_Controls("parmMax", 0.25, variable=":0:SH/L")

    rows = []
    for cycle in range(5):
        profile_cycle(gpx, hist, phases, rows, cycle)
    refine(gpx, hist, rows, "fresh_model_replay", 30)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
