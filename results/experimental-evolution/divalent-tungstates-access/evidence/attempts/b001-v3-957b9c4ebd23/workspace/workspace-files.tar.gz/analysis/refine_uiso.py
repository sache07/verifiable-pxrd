#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter per accepted phase."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT
from refine_multi_v2 import describe


SOURCE = ROOT / ".tmp" / "final-refinement" / "07-oxygen_fixed_replay.gpx"
OUT = ROOT / ".tmp" / "uiso-refinement"


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    gpx = G2.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    rows = []

    for phase_id, phase in enumerate(phases):
        atoms = list(phase.atoms())
        for atom in atoms:
            atom.refinement_flags = "U"
        variables = tuple(f"{phase_id}::AUiso:{atom_id}" for atom_id in range(len(atoms)))
        if len(variables) > 1:
            gpx.add_EquivConstr(variables)
        for variable in variables:
            gpx.set_Controls("parmMin", 0.003, variable=variable)
            gpx.set_Controls("parmMax", 0.02, variable=variable)
        gpx.set_Controls("cycles", 24)
        gpx.refine()
        gpx.save()
        values = [float(atom.uiso) for atom in atoms]
        row = describe(gpx, hist, phases, f"uiso_{phase.name}")
        row["uiso"] = values
        rows.append(row)
        shutil.copy2(gpx.filename, OUT / f"{phase_id:02d}-{phase.name}.gpx")
        print(
            phase.name,
            f"Rwp={row['rwp_percent']:.6f}",
            f"shift/esd={row['max_shift_over_esd']}",
            "Uiso=" + ",".join(f"{value:.7f}" for value in values),
            flush=True,
        )
        for atom in atoms:
            atom.refinement_flags = ""

    # Replay with the three Uiso values fixed, preserving all other accepted flags.
    gpx.set_Controls("cycles", 30)
    gpx.refine()
    gpx.save()
    final = describe(gpx, hist, phases, "uiso_fixed_replay")
    rows.append(final)
    shutil.copy2(gpx.filename, OUT / "03-uiso_fixed_replay.gpx")
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(
        "fixed replay",
        f"Rwp={final['rwp_percent']:.6f}",
        f"shift/esd={final['max_shift_over_esd']}",
        flush=True,
    )


if __name__ == "__main__":
    main()
