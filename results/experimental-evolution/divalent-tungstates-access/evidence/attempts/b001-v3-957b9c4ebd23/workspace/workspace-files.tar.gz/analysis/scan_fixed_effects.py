#!/usr/bin/env python3
"""Zero-cycle scans of final weak effects, with every fit parameter fixed."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT
from refine_profile_staged import clear_flags


SOURCE = ROOT / ".tmp" / "stagewise-final" / "16-cycle2_cell1.gpx"
OUT = ROOT / ".tmp" / "fixed-scans"


def prepare(gpx):
    hist = gpx.histogram(0)
    phases = gpx.phases()
    clear_flags(hist, phases)
    gpx.set_Frozen()
    strain = phases[0].data["Histograms"][hist.name]["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = strain[1][1] = 0.0
    strain[2] = [False] * len(strain[2])
    strain[5] = [False] * len(strain[5])
    return hist, phases


def replay(tag, alter):
    dest = OUT / "trial.gpx"
    gpx = G2.G2Project(str(SOURCE), newgpx=str(dest))
    hist, phases = prepare(gpx)
    alter(hist, phases)
    gpx.set_Controls("cycles", 0)
    gpx.refine()
    return {"tag": tag, "rwp_percent": hist.get_wR()}


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    results = {"shl": [], "zno_texture": [], "roughness": []}

    for value in [0.023, 0.024, 0.025, 0.0255, 0.0258, 0.0260, 0.0265, 0.027, 0.028]:
        row = replay(
            f"SHL={value}",
            lambda hist, phases, value=value: hist.data["Instrument Parameters"][0]["SH/L"].__setitem__(1, value),
        )
        row["SH/L"] = value
        results["shl"].append(row)
        print(json.dumps(row), flush=True)

    for axis in ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 1, 1]):
        for ratio in (0.8, 0.9, 1.0, 1.1, 1.2):
            def alter(hist, phases, axis=axis, ratio=ratio):
                po = phases[2].data["Histograms"][hist.name]["Pref.Ori."]
                po[0] = "MD"
                po[1] = ratio
                po[2] = False
                po[3] = list(axis)
            row = replay(f"ZnO MD {axis} {ratio}", alter)
            row.update(axis=list(axis), ratio=ratio)
            results["zno_texture"].append(row)
            print(json.dumps(row), flush=True)

    for A, B in [(0.0, 0.0), (0.40649516520716983, 0.02), (0.50, 0.0248), (0.60, 0.0314)]:
        def alter(hist, phases, A=A, B=B):
            hist.SampleParameters["SurfRoughA"] = [A, False]
            hist.SampleParameters["SurfRoughB"] = [B, False]
        row = replay(f"roughness {A} {B}", alter)
        row.update(A=A, B=B)
        results["roughness"].append(row)
        print(json.dumps(row), flush=True)

    (OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
