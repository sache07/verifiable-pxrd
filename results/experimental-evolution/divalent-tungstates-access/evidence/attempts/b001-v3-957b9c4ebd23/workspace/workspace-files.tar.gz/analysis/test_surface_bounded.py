#!/usr/bin/env python3
"""Bounded, repeated surface-roughness trials to check reproducibility."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT


SOURCE = ROOT / ".tmp" / "uiso-refinement" / "03-uiso_fixed_replay.gpx"
OUT = ROOT / ".tmp" / "surface-bounded"


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    starts = [(0.08, 0.025), (0.30, 0.10), (0.55, 0.40)]
    rows = []
    for trial, (start_a, start_b) in enumerate(starts):
        dest = OUT / f"rough-{trial}.gpx"
        gpx = G2.G2Project(str(SOURCE), newgpx=str(dest))
        hist = gpx.histogram(0)
        hist.SampleParameters["SurfRoughA"] = [start_a, True]
        hist.SampleParameters["SurfRoughB"] = [start_b, True]
        gpx.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        gpx.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        gpx.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
        for iteration in range(5):
            gpx.set_Controls("cycles", 30)
            gpx.refine()
            gpx.save()
            cov = gpx.data["Covariance"]["data"].get("Rvals", {})
            row = {
                "trial": trial,
                "iteration": iteration,
                "start": [start_a, start_b],
                "A": hist.SampleParameters["SurfRoughA"][0],
                "B": hist.SampleParameters["SurfRoughB"][0],
                "rwp_percent": hist.get_wR(),
                "max_shift_over_esd": cov.get("Max shft/sig"),
                "converged": cov.get("converged"),
                "gpx": str(dest),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
