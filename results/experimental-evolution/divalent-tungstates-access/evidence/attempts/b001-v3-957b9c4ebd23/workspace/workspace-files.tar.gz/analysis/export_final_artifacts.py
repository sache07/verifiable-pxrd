#!/usr/bin/env python3
"""Install the independently replayed final project, CIFs and profile."""

from pathlib import Path
import json
import shutil

import numpy as np


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = ROOT / ".tmp" / "final-candidate" / "final.gpx"
REPLAY = ROOT / ".tmp" / "final-replay"


def main():
    report = json.loads((REPLAY / "replay.json").read_text())
    if report.get("status") != "replayed" or report.get("profile_review_flags"):
        raise RuntimeError(f"final native replay did not pass: {report}")

    shutil.copy2(CANDIDATE, ROOT / "final.gpx")
    names = ["ZnWO4_wolframite.cif", "WO3_monoclinic.cif", "ZnO_wurtzite.cif"]
    if len(report["phases"]) != len(names):
        raise RuntimeError("unexpected phase inventory in replay")
    for row, name in zip(report["phases"], names):
        shutil.copy2(REPLAY / row["cif"], ROOT / name)

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as data:
        x = data["x"]
        observed = data["observed"]
        calculated = data["predicted"]
        background = data["background"]
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.15g",
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    stats = {
        "rwp_percent": float(100 * np.sqrt(chi_square / np.sum(weights * observed**2))),
        "rp_percent": float(100 * np.sum(np.abs(difference)) / np.sum(observed)),
        "weighted_chi_square": chi_square,
        "n_points": int(len(x)),
        "phases": report["phases"],
        "project_sha256": report["project_sha256"],
    }
    (ROOT / ".tmp" / "final-statistics.json").write_text(json.dumps(stats, indent=2) + "\n")
    print(json.dumps(stats, indent=2))


if __name__ == "__main__":
    main()
