#!/usr/bin/env python3
"""Stable grouped settlement and fixed replay for the final physical model."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT
from refine_profile_staged import clear_flags


SOURCE = ROOT / ".tmp" / "uw-final" / "13-cycle4_W_only.gpx"
OUT = ROOT / ".tmp" / "stagewise-final"


def inactive_zn_strain(hist, phases):
    strain = phases[0].data["Histograms"][hist.name]["Mustrain"]
    strain[0] = "isotropic"
    # A numerically negligible epsilon avoids a GSAS-II HAP derivative
    # singularity at exactly zero when size is the only varied profile term.
    strain[1][0] = strain[1][1] = 0.1
    strain[2] = [False] * len(strain[2])
    strain[5] = [False] * len(strain[5])


def reset(hist, phases):
    clear_flags(hist, phases)
    inactive_zn_strain(hist, phases)
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False


def run(gpx, hist, phases, rows, label, cycles=16):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    gpx.save()
    cov = gpx.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    row = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "covariance_rwp_percent": cov.get("Rwp"),
        "max_shift_over_esd": cov.get("Max shft/sig"),
        "converged": cov.get("converged"),
        "aborted": cov.get("Aborted", False),
        "frozen": gpx.get_Frozen(),
    }
    rows.append(row)
    shutil.copy2(gpx.filename, OUT / f"{len(rows)-1:02d}-{label}.gpx")
    print(json.dumps(row), flush=True)
    if row["aborted"] or row["frozen"]:
        raise RuntimeError(f"unstable stage: {label}: {row}")


def scales_background(gpx, hist, phases, rows, cycle):
    reset(hist, phases)
    hist.data["Background"][0][1] = True
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    run(gpx, hist, phases, rows, f"cycle{cycle}_scales_background", 14)


def cells_and_calibration(gpx, hist, phases, rows, cycle):
    for phase_id, phase in enumerate(phases):
        reset(hist, phases)
        phase.data["General"]["Cell"][0] = True
        run(gpx, hist, phases, rows, f"cycle{cycle}_cell{phase_id}", 16)
    for key in ("Zero", "Shift"):
        reset(hist, phases)
        if key == "Zero":
            hist.data["Instrument Parameters"][0]["Zero"][2] = True
        else:
            hist.SampleParameters["Shift"][1] = True
        run(gpx, hist, phases, rows, f"cycle{cycle}_{key.lower()}", 16)


def intensity_and_profiles(gpx, hist, phases, rows, cycle):
    reset(hist, phases)
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    run(gpx, hist, phases, rows, f"cycle{cycle}_polarization", 14)

    # Profile values were already selected phasewise before the final common
    # U/W decomposition. Keep them fixed here: changing the ZnWO4 strain model
    # from uniaxial to inactive leaves GSAS-II's HAP derivative cache singular,
    # even though fixed forward replay is well defined and reproducible.
    return

    # Phase 0: size and the accepted [100] texture; strain is physically inactive.
    # Keep each profile degree of freedom in its own block; near the optimum,
    # simultaneous size/texture steps can trigger GSAS-II's lambda safeguard.
    reset(hist, phases)
    hap = phases[0].data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    run(gpx, hist, phases, rows, f"cycle{cycle}_size0", 18)
    reset(hist, phases)
    hap = phases[0].data["Histograms"][hist.name]
    hap["Pref.Ori."][2] = True
    run(gpx, hist, phases, rows, f"cycle{cycle}_texture0", 18)

    # Phase 1: size, [010] uniaxial strain and [010] texture.
    reset(hist, phases)
    hap = phases[1].data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    run(gpx, hist, phases, rows, f"cycle{cycle}_size1", 18)
    for component in (0, 1):
        reset(hist, phases)
        hap = phases[1].data["Histograms"][hist.name]
        hap["Mustrain"][2][component] = True
        run(gpx, hist, phases, rows, f"cycle{cycle}_strain1_{component}", 18)
    reset(hist, phases)
    hap = phases[1].data["Histograms"][hist.name]
    hap["Pref.Ori."][2] = True
    run(gpx, hist, phases, rows, f"cycle{cycle}_texture1", 18)

    # Phase 2: isotropic size and strain; its 16 reflections do not support texture.
    reset(hist, phases)
    hap = phases[2].data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    run(gpx, hist, phases, rows, f"cycle{cycle}_size2", 18)
    reset(hist, phases)
    hap = phases[2].data["Histograms"][hist.name]
    hap["Mustrain"][2][0] = True
    run(gpx, hist, phases, rows, f"cycle{cycle}_strain2", 18)


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    gpx = G2.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    gpx.set_Frozen()
    inactive_zn_strain(hist, phases)

    rows = []
    for cycle in range(3):
        scales_background(gpx, hist, phases, rows, cycle)
        cells_and_calibration(gpx, hist, phases, rows, cycle)
        intensity_and_profiles(gpx, hist, phases, rows, cycle)

    scales_background(gpx, hist, phases, rows, "final")
    reset(hist, phases)
    run(gpx, hist, phases, rows, "fixed_full_grid_replay", 0)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
