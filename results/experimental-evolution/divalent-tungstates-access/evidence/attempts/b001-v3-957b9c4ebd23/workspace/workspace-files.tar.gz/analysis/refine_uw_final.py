#!/usr/bin/env python3
"""Converge U/W after selecting the physically inactive ZnWO4 strain state."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT
from refine_profile_staged import clear_flags, restore_model_flags


SOURCE = ROOT / ".tmp" / "zero-zn-strain" / "13-cycle3_W_only.gpx"
OUT = ROOT / ".tmp" / "uw-final"


def inactive_zn_strain(hist, phases):
    strain = phases[0].data["Histograms"][hist.name]["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = strain[1][1] = 0.0
    strain[2] = [False] * len(strain[2])
    strain[5] = [False] * len(strain[5])


def restore(hist, phases):
    restore_model_flags(hist, phases)
    inactive_zn_strain(hist, phases)


def run(gpx, hist, phases, rows, label, cycles):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"].get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    row = {
        "stage": label,
        "U": inst["U"][1],
        "W": inst["W"][1],
        "SH/L": inst["SH/L"][1],
        "rwp_percent": hist.get_wR(),
        "covariance_rwp_percent": cov.get("Rwp"),
        "max_shift_over_esd": cov.get("Max shft/sig"),
        "converged": cov.get("converged"),
        "aborted": cov.get("Aborted", False),
        "frozen": gpx.get_Frozen(),
    }
    rows.append(row)
    shutil.copy2(gpx.filename, OUT / f"{len(rows)-1:02d}-{label}.gpx")
    print(json.dumps(row), flush=True)


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    gpx = G2.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    gpx.set_Frozen()
    for variable, low, high in [(":0:U", 0.0, 40.0), (":0:W", 2.0, 40.0)]:
        gpx.set_Controls("parmMin", low, variable=variable)
        gpx.set_Controls("parmMax", high, variable=variable)

    rows = []
    for cycle in range(5):
        for key in ("U", "W"):
            clear_flags(hist, phases)
            inactive_zn_strain(hist, phases)
            hist.data["Instrument Parameters"][0][key][2] = True
            run(gpx, hist, phases, rows, f"cycle{cycle}_{key}_only", 18)
        clear_flags(hist, phases)
        restore(hist, phases)
        run(gpx, hist, phases, rows, f"cycle{cycle}_model_settle", 30)
    run(gpx, hist, phases, rows, "fresh_model_replay", 30)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
