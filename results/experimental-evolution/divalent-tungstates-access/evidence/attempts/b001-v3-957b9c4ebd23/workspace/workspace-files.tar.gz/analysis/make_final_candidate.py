#!/usr/bin/env python3
"""Freeze the selected model and prepare it for independent native replay."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT
from refine_profile_staged import clear_flags


SOURCE = ROOT / ".tmp" / "stagewise-final" / "16-cycle2_cell1.gpx"
OUT = ROOT / ".tmp" / "final-candidate"
REPLAY = ROOT / ".tmp" / "final-replay"


def main():
    for folder in (OUT, REPLAY):
        if folder.exists():
            shutil.rmtree(folder)
        folder.mkdir(parents=True)
    G2.SetPrintLevel("error")
    candidate = OUT / "final.gpx"
    gpx = G2.G2Project(str(SOURCE), newgpx=str(candidate))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    clear_flags(hist, phases)
    gpx.set_Frozen()

    # The selected ZnWO4 state is the inactive-strain branch. Exact zero is
    # safe for fixed forward replay; the earlier 0.1 ppm epsilon was used only
    # to avoid a GSAS-II least-squares derivative singularity.
    strain = phases[0].data["Histograms"][hist.name]["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = strain[1][1] = 0.0
    strain[2] = [False] * len(strain[2])
    strain[5] = [False] * len(strain[5])

    x = hist.data["data"][1][0]
    hist.data["Limits"] = [(float(x[0]), float(x[-1])), [float(x[0]), float(x[-1])]]
    # Remove stale least-squares errors: final exports and replay use the saved
    # full-precision cells, atoms and profile parameters, not covariance arrays.
    gpx.data.setdefault("Covariance", {})["data"] = {}
    gpx.save()
    for phase in phases:
        phase.export_CIF(str(OUT / f"{phase.name}.cif"))

    request = {
        "project": str(candidate.resolve()),
        "observed": str((ROOT / "inputs" / "pattern.csv").resolve()),
        "histogram": hist.name,
    }
    (REPLAY / "request.json").write_text(json.dumps(request, indent=2) + "\n")
    print(json.dumps({"candidate": str(candidate), "histogram": hist.name}, indent=2))


if __name__ == "__main__":
    main()
