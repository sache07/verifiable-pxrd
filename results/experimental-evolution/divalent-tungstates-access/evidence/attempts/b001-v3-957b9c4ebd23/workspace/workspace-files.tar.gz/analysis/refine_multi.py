#!/usr/bin/env python3
"""Build a staged ZnWO4 + WO3 + ZnO GSAS-II refinement trial."""

from __future__ import annotations

from pathlib import Path
import argparse
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c05/cif"
)


def cod_path(record_id: str) -> Path:
    return LIB / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def stage(gpx, hist, phases, label, log, cycles=10):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    gpx.save()
    cov = gpx.data.get("Covariance", {}).get("data", {})
    mass_fracs = {}
    try:
        mass_fracs = {
            key: {"value": val[0], "esd": val[1]}
            for key, val in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        mass_fracs = {"error": repr(exc)}
    row = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "message": cov.get("Rvals", {}).get("msg"),
        "mass_fractions": mass_fracs,
        "instrument": {
            key: value[1]
            for key, value in hist.data["Instrument Parameters"][0].items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": {
            key: (value[0] if isinstance(value, list) else value)
            for key, value in hist.SampleParameters.items()
            if key in {"Scale", "Type", "Gonio. radius", "Shift", "SurfRoughA", "SurfRoughB"}
        },
        "phases": {},
        "vary_list": cov.get("varyList", []),
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(map(float, atom.coordinates)),
                    "uiso": float(atom.uiso),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    log.append(row)
    frac_text = ", ".join(
        f"{k}={v['value']:.4f}" for k, v in mass_fracs.items() if isinstance(v, dict) and "value" in v
    )
    print(f"{label:22s} Rwp={row['rwp_percent']:.5f} GOF={row['gof']!s:>10} {frac_text}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3-id", default="2311041", choices=["1528915", "2311041", "2106293"])
    parser.add_argument("--zno-id", default="9004178")
    parser.add_argument("--include-zno", action="store_true")
    parser.add_argument("--tag", default="multi")
    args = parser.parse_args()
    out = ROOT / ".tmp" / f"multi-{args.tag}"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    G2.SetPrintLevel("error")

    gpx = G2.G2Project(newgpx=str(out / "trial.gpx"))
    phase_specs = [
        (ROOT / "analysis" / "znwo4_start.cif", "ZnWO4_wolframite"),
        (cod_path(args.wo3_id), f"WO3_monoclinic_{args.wo3_id}"),
    ]
    if args.include_zno:
        phase_specs.append(
            (ROOT / "analysis" / "zno_wurtzite_start.cif", f"ZnO_wurtzite_{args.zno_id}")
        )
    phases = [
        gpx.add_phase(str(path), phasename=name, fmthint="CIF")
        for path, name in phase_specs
    ]
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "instrument.instprm"),
        phases=phases,
        fmthint="comma/tab/semicolon separated",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 16,
                "coeffs": [1200.0] + [0.0] * 15,
                "refine": True,
            },
        }
    )
    for phase, scale in zip(phases, [80.0, 25.0, 1.0]):
        for atom in phase.atoms():
            atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][1][2] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][1][2] = 1.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    log = []
    stage(gpx, hist, phases, "scale_background", log)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(gpx, hist, phases, "cells_zero", log, cycles=12)

    hist.SampleParameters["Shift"] = [0.0, False]
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    stage(gpx, hist, phases, "cells_zero_shift", log, cycles=12)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.30, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    stage(gpx, hist, phases, "isotropic_profiles", log, cycles=16)

    # The dominant wolframite h00 intensity enhancement is a clean [100] MD signature.
    znwo4_hap = phases[0].data["Histograms"][hist.name]
    znwo4_hap["Pref.Ori."][0] = "MD"
    znwo4_hap["Pref.Ori."][1] = 0.82
    znwo4_hap["Pref.Ori."][3] = [1, 0, 0]
    phases[0].set_HAP_refinements({"Pref.Ori.": True})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    stage(gpx, hist, phases, "znwo4_orientation", log, cycles=12)

    stage(gpx, hist, phases, "settle", log, cycles=16)

    arrays = hist.data["data"][1]
    np.savetxt(
        out / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[5], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    (out / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
    for phase in phases:
        phase.export_CIF(str(out / f"{phase.name}.cif"))
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
