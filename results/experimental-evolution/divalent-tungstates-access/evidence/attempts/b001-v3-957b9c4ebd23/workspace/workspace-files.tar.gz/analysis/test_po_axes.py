#!/usr/bin/env python3
"""Compare March-Dollase axes from the same converged three-phase project."""

from pathlib import Path
import argparse
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", default=str(ROOT / ".tmp" / "threephase-zno" / "trial.gpx"))
    parser.add_argument("--phase", type=int, default=1)
    parser.add_argument("--tag", default="wo3")
    args = parser.parse_args()
    source = Path(args.source)
    out = ROOT / ".tmp" / f"po-tests-{args.tag}"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    G2.SetPrintLevel("error")
    results = []
    for axis in ([1, 0, 0], [0, 1, 0], [0, 0, 1], [1, 1, 0], [1, 1, 1]):
        for start in (0.85, 1.15):
            label = "".join(map(str, axis)) + f"-{start:.2f}"
            dest = out / f"{label}.gpx"
            gpx = G2.G2Project(str(source), newgpx=str(dest))
            hist = gpx.histogram(0)
            phase = gpx.phase(args.phase)
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = start
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
            gpx.set_Controls("parmMin", 0.4, variable=f"{args.phase}:0:MD")
            gpx.set_Controls("parmMax", 2.5, variable=f"{args.phase}:0:MD")
            gpx.set_Controls("cycles", 16)
            gpx.refine()
            gpx.save()
            fractions = hist.ComputeMassFracs()
            row = {
                "axis": axis,
                "start": start,
                "ratio": hap["Pref.Ori."][1],
                "rwp_percent": hist.get_wR(),
                "fractions": {key: value[0] for key, value in fractions.items()},
                "gpx": str(dest),
            }
            results.append(row)
            print(json.dumps(row), flush=True)
    results.sort(key=lambda row: row["rwp_percent"])
    (out / "results.json").write_text(json.dumps(results, indent=2) + "\n")
    print("BEST", json.dumps(results[0]), flush=True)


if __name__ == "__main__":
    main()
