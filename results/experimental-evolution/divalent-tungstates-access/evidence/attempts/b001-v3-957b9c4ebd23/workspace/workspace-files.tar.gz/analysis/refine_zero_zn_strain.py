#!/usr/bin/env python3
"""Resolve common Gaussian profile against an inactive ZnWO4 strain model."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT
from refine_profile_staged import clear_flags, restore_model_flags


SOURCE = ROOT / ".tmp" / "profile-staged" / "15-fresh_model_replay.gpx"
OUT = ROOT / ".tmp" / "zero-zn-strain"


def set_zn_strain_inactive(hist, phases):
    strain = phases[0].data["Histograms"][hist.name]["Mustrain"]
    strain[0] = "isotropic"
    strain[1][0] = 0.0
    strain[1][1] = 0.0
    strain[2] = [False] * len(strain[2])
    strain[5] = [False] * len(strain[5])


def restore(hist, phases):
    restore_model_flags(hist, phases)
    set_zn_strain_inactive(hist, phases)


def run(gpx, hist, phases, rows, label, cycles):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    gpx.save()
    cov = gpx.data["Covariance"]["data"].get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    strains = [
        phase.data["Histograms"][hist.name]["Mustrain"][1][:2]
        for phase in phases
    ]
    row = {
        "stage": label,
        "U": inst["U"][1],
        "W": inst["W"][1],
        "SH/L": inst["SH/L"][1],
        "strains": strains,
        "rwp_percent": hist.get_wR(),
        "covariance_rwp_percent": cov.get("Rwp"),
        "max_shift_over_esd": cov.get("Max shft/sig"),
        "converged": cov.get("converged"),
        "aborted": cov.get("Aborted", False),
        "frozen": gpx.get_Frozen(),
    }
    rows.append(row)
    shutil.copy2(gpx.filename, OUT / f"{len(rows)-1:02d}-{label}.gpx")
    print(json.dumps(row), flush=True)


def one_cycle(gpx, hist, phases, rows, cycle):
    for key in ("U", "W", "SH/L"):
        clear_flags(hist, phases)
        set_zn_strain_inactive(hist, phases)
        hist.data["Instrument Parameters"][0][key][2] = True
        run(gpx, hist, phases, rows, f"cycle{cycle}_{key.replace('/', '')}_only", 18)
    clear_flags(hist, phases)
    restore(hist, phases)
    run(gpx, hist, phases, rows, f"cycle{cycle}_model_settle", 30)


def main():
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir(parents=True)
    G2.SetPrintLevel("error")
    gpx = G2.G2Project(str(SOURCE), newgpx=str(OUT / "working.gpx"))
    hist = gpx.histogram(0)
    phases = gpx.phases()
    hist.SampleParameters["SurfRoughA"][1] = False
    hist.SampleParameters["SurfRoughB"][1] = False
    gpx.set_Frozen()
    for variable, low, high in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:SH/L", 0.005, 0.10),
    ]:
        gpx.set_Controls("parmMin", low, variable=variable)
        gpx.set_Controls("parmMax", high, variable=variable)

    set_zn_strain_inactive(hist, phases)
    rows = []
    for cycle in range(4):
        one_cycle(gpx, hist, phases, rows, cycle)
    run(gpx, hist, phases, rows, "fresh_model_replay", 30)
    (OUT / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
