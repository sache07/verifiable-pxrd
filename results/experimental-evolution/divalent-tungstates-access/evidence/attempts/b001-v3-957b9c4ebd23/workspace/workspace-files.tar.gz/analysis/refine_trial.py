#!/usr/bin/env python3
"""Staged one-phase ZnWO4 Rietveld trial using the GSAS-II forward model."""

from __future__ import annotations

from pathlib import Path
import argparse
import json
import math
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def make_project(out: Path, strain_axis: tuple[int, int, int], po_axis: tuple[int, int, int]):
    out.mkdir(parents=True, exist_ok=True)
    gpx = G2.G2Project(newgpx=str(out / "trial.gpx"))
    phase = gpx.add_phase(
        str(ROOT / "analysis" / "znwo4_start.cif"),
        phasename="ZnWO4_wolframite",
        fmthint="CIF",
    )
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "instrument.instprm"),
        phases=[phase],
        fmthint="comma/tab/semicolon separated",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 16,
                "coeffs": [1200.0] + [0.0] * 15,
                "refine": True,
            },
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.25
    hap["Size"][1][1] = 0.25
    hap["Size"][1][2] = 1.0
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = 1800.0
    hap["Mustrain"][1][1] = 800.0
    hap["Mustrain"][1][2] = 1.0
    hap["Mustrain"][3] = list(strain_axis)
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 0.82
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = list(po_axis)
    return gpx, hist, phase


def finite(value):
    try:
        return math.isfinite(float(value))
    except Exception:
        return False


def snapshot(gpx, hist, phase, label):
    cov = gpx.data.get("Covariance", {}).get("data", {})
    hap = phase.data["Histograms"][hist.name]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.SampleParameters
    result = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "message": cov.get("Rvals", {}).get("msg"),
        "cell": phase.get_cell(),
        "instrument": {k: v[1] for k, v in inst.items() if isinstance(v, list) and len(v) > 1},
        "sample": {
            k: (v[0] if isinstance(v, list) else v)
            for k, v in sample.items()
            if k in {"Scale", "Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "scale": hap["Scale"][0],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "preferred_orientation": hap["Pref.Ori."],
        "atoms": [
            {
                "label": atom.label,
                "element": atom.element,
                "xyz": list(map(float, atom.coordinates)),
                "uiso": float(atom.uiso),
                "flags": atom.refinement_flags,
            }
            for atom in phase.atoms()
        ],
        "vary_list": cov.get("varyList", []),
        "frozen": gpx.get_Frozen(),
    }
    return result


def run_refinement(gpx, hist, phase, label, log, cycles=8):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    gpx.save()
    row = snapshot(gpx, hist, phase, label)
    log.append(row)
    print(
        f"{label:24s} Rwp={row['rwp_percent']:.5f} "
        f"GOF={row['gof']!s:>10} cell="
        f"{row['cell']['length_a']:.6f},{row['cell']['length_b']:.6f},"
        f"{row['cell']['length_c']:.6f},{row['cell']['angle_beta']:.5f}"
    )
    return row


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--strain-axis", default="100")
    parser.add_argument("--po-axis", default="100")
    parser.add_argument("--tag", default="one")
    args = parser.parse_args()
    strain_axis = tuple(map(int, args.strain_axis))
    po_axis = tuple(map(int, args.po_axis))
    out = ROOT / ".tmp" / f"trial-{args.tag}"
    if out.exists():
        shutil.rmtree(out)
    G2.SetPrintLevel("error")
    gpx, hist, phase = make_project(out, strain_axis, po_axis)
    log = []

    run_refinement(gpx, hist, phase, "scale_background", log)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(gpx, hist, phase, "cell_zero", log)

    # A common specimen displacement is separable from constant zero over a broad scan.
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_refinement(gpx, hist, phase, "cell_zero_shift", log)

    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.25, "refine": True},
            "Mustrain": {
                "type": "uniaxial",
                "direction": list(strain_axis),
                "refine": True,
            },
        }
    )
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(gpx, hist, phase, "profile", log, cycles=12)

    phase.set_HAP_refinements({"Pref.Ori.": True})
    run_refinement(gpx, hist, phase, "orientation", log)

    phase.set_refinements({"Atoms": {"Zn1": "X", "W1": "X"}})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run_refinement(gpx, hist, phase, "heavy_coordinates", log)

    phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    run_refinement(gpx, hist, phase, "all_coordinates", log, cycles=12)

    # The generator applies one phase-wide isotropic U value. Enforce that model.
    phase.set_refinements({"Atoms": {"all": "XU"}})
    gpx.add_EquivConstr(tuple(f"0::AUiso:{i}" for i in range(4)))
    run_refinement(gpx, hist, phase, "coordinates_uiso", log, cycles=12)

    hist.SampleParameters["SurfRoughA"] = [0.2, False]
    hist.SampleParameters["SurfRoughB"] = [0.08, False]
    hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    run_refinement(gpx, hist, phase, "surface_roughness", log, cycles=12)

    # Let all retained physical terms settle together.
    run_refinement(gpx, hist, phase, "full_replay", log, cycles=16)

    arrays = hist.data["data"][1]
    np.savetxt(
        out / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[5], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    (out / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
    phase.export_CIF(str(out / "ZnWO4.cif"))
    print(json.dumps(log[-1], indent=2))


if __name__ == "__main__":
    main()
