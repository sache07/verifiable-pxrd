#!/usr/bin/env python3
"""Build and inspect an initial one-phase GSAS-II refinement project."""

from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / ".tmp" / "initial"
OUT.mkdir(parents=True, exist_ok=True)

G2.SetPrintLevel("warn")
project = G2.G2Project(newgpx=str(OUT / "initial.gpx"))
phase = project.add_phase(
    str(ROOT / "analysis" / "znwo4_start.cif"),
    phasename="ZnWO4_wolframite",
    fmthint="CIF",
)
hist = project.add_powder_histogram(
    str(ROOT / "inputs" / "pattern.csv"),
    str(ROOT / "analysis" / "instrument.instprm"),
    phases=[phase],
    fmthint="comma/tab/semicolon separated",
)

hist.SampleParameters["Type"] = "Bragg-Brentano"
hist.SampleParameters["Gonio. radius"] = 200.0
hist.set_refinements(
    {
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1000.0] + [0.0] * 11,
            "refine": True,
        },
    }
)
phase.set_HAP_refinements({"Scale": True})
project.set_Controls("cycles", 8)
project.refine()
project.save()

summary = {
    "histogram": hist.name,
    "wR": hist.get_wR(),
    "cell": phase.get_cell(),
    "sample": hist.SampleParameters,
    "instrument": hist.data["Instrument Parameters"][0],
    "HAP": phase.getHAPvalues(hist.name),
    "atoms": [
        {
            "label": atom.label,
            "element": atom.element,
            "xyz": atom.coordinates,
            "uiso": atom.uiso,
            "flags": atom.refinement_flags,
        }
        for atom in phase.atoms()
    ],
    "residuals": hist.data["data"][0],
    "covariance": project.data.get("Covariance", {}).get("data", {}),
}

def serializable(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    raise TypeError(type(value).__name__)

print(json.dumps(summary, indent=2, default=serializable))
