#!/usr/bin/env python3
"""Physically bounded, phase-by-phase refinement of ZnWO4 + monoclinic WO3."""

from __future__ import annotations

from pathlib import Path
import argparse
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_multi import ROOT, cod_path


def describe(gpx, hist, phases, label):
    cov = gpx.data.get("Covariance", {}).get("data", {})
    fractions = {}
    try:
        fractions = {
            key: {"value": value[0], "esd": value[1]}
            for key, value in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        fractions = {"error": repr(exc)}
    row = {
        "stage": label,
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("Rvals", {}).get("GOF"),
        "max_shift_over_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "message": cov.get("Rvals", {}).get("msg"),
        "fractions": fractions,
        "frozen": gpx.get_Frozen(),
        "instrument": {
            key: value[1]
            for key, value in hist.data["Instrument Parameters"][0].items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": {
            key: (value[0] if isinstance(value, list) else value)
            for key, value in hist.SampleParameters.items()
            if key in {"Scale", "Type", "Gonio. radius", "Shift", "SurfRoughA", "SurfRoughB"}
        },
        "background": hist.data["Background"][0],
        "phases": {},
        "vary_list": cov.get("varyList", []),
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        row["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "mass": phase.data["General"]["Mass"],
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(map(float, atom.coordinates)),
                    "uiso": float(atom.uiso),
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    return row


def refine(gpx, hist, phases, out, log, label, cycles=10):
    gpx.set_Controls("cycles", cycles)
    gpx.refine()
    gpx.save()
    shutil.copy2(gpx.filename, out / f"{len(log):02d}-{label}.gpx")
    row = describe(gpx, hist, phases, label)
    log.append(row)
    fr = ", ".join(
        f"{key}={value['value']:.4f}"
        for key, value in row["fractions"].items()
        if isinstance(value, dict) and "value" in value
    )
    print(
        f"{label:26s} Rwp={row['rwp_percent']:.5f} "
        f"GOF={row['gof']!s:>10} shift/esd={row['max_shift_over_esd']!s:>9} {fr}",
        flush=True,
    )
    return row


def set_limits(gpx):
    limits = {
        ":0:Zero": (-1.0, 1.0),
        ":0:Shift": (-2000.0, 2000.0),
        ":0:Polariz.": (0.0, 1.0),
        ":0:U": (0.0, 100.0),
        ":0:W": (0.1, 100.0),
        ":0:SH/L": (0.0, 0.25),
        "0:0:MD": (0.4, 2.5),
    }
    for phase_id in (0, 1):
        for key in ("Size;i",):
            limits[f"{phase_id}:0:{key}"] = (0.02, 5.0)
        for key in ("Mustrain;i", "Mustrain;a"):
            limits[f"{phase_id}:0:{key}"] = (0.0, 20000.0)
    for variable, (lower, upper) in limits.items():
        gpx.set_Controls("parmMin", lower, variable=variable)
        gpx.set_Controls("parmMax", upper, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3-id", default="2311041", choices=["1528915", "2311041", "2106293"])
    parser.add_argument("--zn-strain-axis", default="100")
    parser.add_argument("--tag", default="bounded")
    args = parser.parse_args()
    zn_axis = [int(value) for value in args.zn_strain_axis]
    out = ROOT / ".tmp" / f"bounded-{args.tag}"
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    G2.SetPrintLevel("error")

    gpx = G2.G2Project(newgpx=str(out / "trial.gpx"))
    phases = [
        gpx.add_phase(
            str(ROOT / "analysis" / "znwo4_start.cif"),
            phasename="ZnWO4_wolframite",
            fmthint="CIF",
        ),
        gpx.add_phase(
            str(cod_path(args.wo3_id)),
            phasename=f"WO3_monoclinic_{args.wo3_id}",
            fmthint="CIF",
        ),
    ]
    hist = gpx.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "instrument.instprm"),
        phases=phases,
        fmthint="comma/tab/semicolon separated",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 16,
                "coeffs": [1200.0] + [0.0] * 15,
                "refine": True,
            },
        }
    )
    for phase, scale in zip(phases, [80.0, 20.0]):
        for atom in phase.atoms():
            atom.uiso = 0.01
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][1][2] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][1][2] = 1.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    gpx.save()
    set_limits(gpx)
    log = []

    refine(gpx, hist, phases, out, log, "scales_background", cycles=10)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(gpx, hist, phases, out, log, "cells_zero", cycles=12)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(gpx, hist, phases, out, log, "cells_zero_shift", cycles=12)

    zn_hap = phases[0].data["Histograms"][hist.name]
    zn_hap["Pref.Ori."][0] = "MD"
    zn_hap["Pref.Ori."][1] = 0.80
    zn_hap["Pref.Ori."][3] = [1, 0, 0]
    phases[0].set_HAP_refinements({"Pref.Ori.": True})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(gpx, hist, phases, out, log, "znwo4_orientation", cycles=12)

    phases[0].set_refinements({"Atoms": {"Zn1": "X", "W1": "X"}})
    refine(gpx, hist, phases, out, log, "znwo4_heavy_coords", cycles=12)

    phases[1].set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    refine(gpx, hist, phases, out, log, "wo3_heavy_coords", cycles=12)

    # Profile terms are added one phase at a time to avoid unstable compensation.
    zn_hap["Mustrain"][0] = "uniaxial"
    zn_hap["Mustrain"][1][0] = 1000.0
    zn_hap["Mustrain"][1][1] = 1000.0
    zn_hap["Mustrain"][3] = zn_axis
    phases[0].set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.30, "refine": True},
            "Mustrain": {"type": "uniaxial", "direction": zn_axis, "refine": True},
        }
    )
    refine(gpx, hist, phases, out, log, "znwo4_profile", cycles=12)

    phases[0].clear_HAP_refinements({"Size": True, "Mustrain": True})
    phases[1].set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.30, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    refine(gpx, hist, phases, out, log, "wo3_profile", cycles=12)

    phases[1].clear_HAP_refinements({"Size": True, "Mustrain": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    refine(gpx, hist, phases, out, log, "instrument_profile", cycles=12)

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    phases[0].set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "uniaxial", "direction": zn_axis, "refine": True},
        }
    )
    phases[1].set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    refine(gpx, hist, phases, out, log, "profiles_settle", cycles=12)

    # Refine wolframite oxygen sites individually; retain the source WO3 light atoms.
    phases[0].set_refinements({"Atoms": {"O1": "X"}})
    refine(gpx, hist, phases, out, log, "znwo4_O1", cycles=10)
    phases[0].set_refinements({"Atoms": {"O2": "X"}})
    refine(gpx, hist, phases, out, log, "znwo4_O2", cycles=12)

    refine(gpx, hist, phases, out, log, "full_settle", cycles=16)

    arrays = hist.data["data"][1]
    np.savetxt(
        out / "fit.csv",
        np.column_stack((arrays[0], arrays[1], arrays[3], arrays[5], arrays[4])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    (out / "stages.json").write_text(json.dumps(log, indent=2) + "\n")
    for phase in phases:
        phase.export_CIF(str(out / f"{phase.name}.cif"))
    print(json.dumps(log[-1], indent=2), flush=True)


if __name__ == "__main__":
    main()
