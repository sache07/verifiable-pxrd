#!/usr/bin/env python3
"""Run equal-checkpoint terminal nuisance/background comparisons."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

import work_refine as wr


def correlations(project: G2.G2Project, threshold: float = 0.70) -> list[dict]:
    covariance = project.data.get("Covariance", {}).get("data", {})
    names = list(covariance.get("varyList", []))
    matrix = np.asarray(covariance.get("covMatrix", []), float)
    if matrix.shape != (len(names), len(names)) or not names:
        return []
    sd = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(sd, sd)
    corr = np.divide(matrix, denom, out=np.zeros_like(matrix), where=denom > 0)
    records = []
    for i in range(len(names)):
        for j in range(i):
            if abs(corr[i, j]) >= threshold:
                records.append({
                    "absolute": float(abs(corr[i, j])),
                    "correlation": float(corr[i, j]),
                    "a": names[j],
                    "b": names[i],
                })
    return sorted(records, key=lambda row: row["absolute"], reverse=True)


def configure(project: G2.G2Project, kind: str, value: float | tuple[float, float] | int) -> None:
    wr.clear_flags(project)
    wr.enable_common(project)
    hist = project.histograms()[0]
    if kind == "polarization":
        hist.InstrumentParameters["Polariz."][1] = float(value)
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif kind == "roughness":
        a, b = value
        hist.SampleParameters["SurfRoughA"] = [float(a), True]
        hist.SampleParameters["SurfRoughB"] = [float(b), True]
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    elif kind == "background":
        order = int(value)
        background = hist.Background[0]
        coefficients = list(map(float, background[3:3 + int(background[2])]))
        coefficients = (coefficients + [0.0] * order)[:order]
        background[:] = [background[0], True, order, *coefficients]
    else:
        raise ValueError(kind)


def evaluate(source: Path, target: Path, kind: str, value, passes: int) -> dict:
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    wr.install_physical_bounds(project)
    history = []
    for _ in range(passes):
        configure(project, kind, value)
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        history.append({
            "Rwp_percent": float(project.histograms()[0].get_wR()),
            "GOF": rvals.get("GOF"),
            "converged": rvals.get("converged"),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "message": rvals.get("msg"),
            "frozen": list(project.get_Frozen()),
        })
    hist = project.histograms()[0]
    data = np.asarray(hist.data["data"][1], float)
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    result = {
        "kind": kind,
        "start_or_order": value,
        "project": str(target),
        "history": history,
        "Rwp_percent": float(hist.get_wR()),
        "chisq": float(rvals.get("chisq", np.nan)),
        "Nvars": int(rvals.get("Nvars", len(covariance.get("varyList", [])))),
        "fractions": {
            name: [float(pair[0]), float(pair[1])]
            for name, pair in hist.ComputeMassFracs().items()
        },
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "roughness": [
            float(hist.SampleParameters["SurfRoughA"][0]),
            float(hist.SampleParameters["SurfRoughB"][0]),
        ],
        "background_order": int(hist.Background[0][2]),
        "background_range": [float(data[4].min()), float(data[4].max())],
        "top_correlations": correlations(project)[:12],
        "frozen": list(project.get_Frozen()),
    }
    wr.clear_flags(project)
    project.save()
    return result


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output_json")
    parser.add_argument("--passes", type=int, default=3)
    parser.add_argument("--background-only", action="store_true")
    args = parser.parse_args()
    source = Path(args.source).resolve()
    output_json = Path(args.output_json).resolve()
    folder = output_json.parent / "nuisance_branches"
    folder.mkdir(parents=True, exist_ok=True)
    if args.background_only:
        specifications = [
            ("background", 28, "background_28"),
            ("background", 30, "background_30"),
            ("background", 32, "background_32"),
        ]
    else:
        specifications = [
            ("polarization", 0.70, "polarization"),
            ("roughness", (0.15, 0.05), "roughness_low"),
            ("roughness", (0.45, 0.25), "roughness_high"),
            ("background", 10, "background_10"),
            ("background", 12, "background_12"),
            ("background", 14, "background_14"),
        ]
    records = []
    for kind, value, token in specifications:
        target = folder / f"{token}.gpx"
        record = evaluate(source, target, kind, value, args.passes)
        records.append(record)
        print(json.dumps(record), flush=True)
    output_json.write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
