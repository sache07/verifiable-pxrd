#!/usr/bin/env python3
"""Equal-development March-Dollase axis scan for accepted phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import work_refine as wr


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def evaluate(source: Path, target: Path, phase_index: int, axis: list[int]) -> dict:
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    wr.clear_flags(project)
    wr.enable_common(project)
    project.index_ids()
    phase = project.phases()[phase_index]
    hist = project.histograms()[0]
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    variable = f"{phase.data['pId']}:0:MD"
    project.set_Controls("parmMin", 0.7, variable=variable)
    project.set_Controls("parmMax", 1.4, variable=variable)
    for _ in range(2):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    fractions = {k: float(v[0]) for k, v in hist.ComputeMassFracs().items()}
    record = {
        "phase": phase.name,
        "axis": list(axis),
        "MD": float(po[1]),
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions,
        "converged": bool(rvals.get("converged")),
        "max_shift_esd": float(rvals.get("Max shft/sig", 999.0)),
        "frozen": list(project.get_Frozen()),
        "project": str(target),
    }
    wr.clear_flags(project)
    project.save()
    return record


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output_json")
    parser.add_argument("--phase", type=int)
    args = parser.parse_args()
    source = Path(args.source).resolve()
    output_json = Path(args.output_json).resolve()
    folder = output_json.parent / "texture_branches"
    folder.mkdir(parents=True, exist_ok=True)
    probe = G2.G2Project(gpxfile=str(source))
    if args.phase is not None and not 0 <= args.phase < len(probe.phases()):
        raise SystemExit("--phase index is outside the project phase inventory")
    records = []
    selected = range(len(probe.phases())) if args.phase is None else [args.phase]
    for phase_index in selected:
        phase = probe.phases()[phase_index]
        for axis in AXES:
            token = "".join(map(str, axis))
            target = folder / f"{phase_index}_{phase.name}_{token}.gpx"
            records.append(evaluate(source, target, phase_index, list(axis)))
            print(json.dumps(records[-1]), flush=True)
    output_json.write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
