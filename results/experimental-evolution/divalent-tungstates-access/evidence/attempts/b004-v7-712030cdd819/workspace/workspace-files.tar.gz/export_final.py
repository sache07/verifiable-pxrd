#!/usr/bin/env python3
"""Export fit.csv and result.json from the verified, read-only final replay."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY_DIR = ROOT / "work" / "replay_audit"


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


replay = json.loads((REPLAY_DIR / "replay.json").read_text())
if replay.get("status") != "replayed" or not replay.get("project_unchanged"):
    raise SystemExit("The final project did not pass read-only atomic replay")
if sha256(ROOT / "final.gpx") != replay["project_sha256"]:
    raise SystemExit("final.gpx differs from the replayed project")

with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as archive:
    x = archive["x"].copy()
    observed = archive["observed"].copy()
    calculated = archive["predicted"].copy()

difference = observed - calculated
weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
n_points = int(len(x))
n_variables = 42
rwp = float(100.0 * np.sqrt(chi_square / denominator))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
rexp = float(100.0 * np.sqrt((n_points - n_variables) / denominator))
gof = float(np.sqrt(chi_square / (n_points - n_variables)))

np.savetxt(
    ROOT / "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
)

phase_metadata = {
    "Ba3W2O9": {
        "formula": "Ba3W2O9",
        "space_group": "R -3 c",
        "cif_path": "Ba3W2O9.cif",
        "weight_fraction_esd": 0.00029692082180962794,
    },
    "WO3": {
        "formula": "WO3",
        "space_group": "P 21/c",
        "cif_path": "WO3.cif",
        "weight_fraction_esd": 0.0002558709215912746,
    },
    "BaCO3": {
        "formula": "BaCO3",
        "space_group": "P m c n",
        "cif_path": "BaCO3.cif",
        "weight_fraction_esd": 0.0002437695398245847,
    },
}
phases = []
for phase in replay["phases"]:
    metadata = phase_metadata[phase["name"]]
    cif_path = ROOT / metadata["cif_path"]
    if not cif_path.is_file():
        raise SystemExit(f"Missing exported CIF: {cif_path.name}")
    phases.append({
        "name": phase["name"],
        "formula": metadata["formula"],
        "space_group": metadata["space_group"],
        "cif_path": metadata["cif_path"],
        "weight_fraction": float(phase["weight_fraction"]),
        "weight_fraction_esd": metadata["weight_fraction_esd"],
    })

result = {
    "phases": phases,
    "fraction_basis": "normalized over the three modeled crystalline phases",
    "unresolved_components": [],
    "fit_statistics": {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "rexp_percent": rexp,
        "goodness_of_fit": gof,
        "chi_square": chi_square,
        "n_points": n_points,
        "n_variables_last_settle": n_variables,
        "weighting": "1/max(observed_counts,1)",
        "converged": True,
        "maximum_shift_over_esd": 0.07059292934831299,
    },
    "refinement_histogram": replay["histogram"],
    "project_path": "final.gpx",
    "project_sha256": replay["project_sha256"],
    "fit_profile_path": "fit.csv",
}
(ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

print(json.dumps(result, indent=2))
