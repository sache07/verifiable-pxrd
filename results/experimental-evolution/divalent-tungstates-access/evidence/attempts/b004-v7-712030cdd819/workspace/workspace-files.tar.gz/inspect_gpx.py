#!/usr/bin/env python3
"""Print compact physical/refinement diagnostics for one or more GSAS-II projects."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def inspect(path: Path) -> dict:
    project = G2.G2Project(gpxfile=str(path))
    hist = project.histograms()[0]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    vary = list(covariance.get("varyList", []))
    cov = np.asarray(covariance.get("covMatrix", []), dtype=float)
    correlations = []
    if cov.shape == (len(vary), len(vary)) and len(vary):
        sd = np.sqrt(np.maximum(np.diag(cov), 0.0))
        denom = np.outer(sd, sd)
        corr = np.divide(cov, denom, out=np.zeros_like(cov), where=denom > 0)
        for i in range(len(vary)):
            for j in range(i):
                if abs(corr[i, j]) >= 0.70:
                    correlations.append(
                        [float(abs(corr[i, j])), float(corr[i, j]), vary[j], vary[i]]
                    )
        correlations.sort(reverse=True)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "uiso_range": [
                min(float(atom.uiso) for atom in phase.atoms()),
                max(float(atom.uiso) for atom in phase.atoms()),
            ],
        }
    return {
        "path": str(path),
        "Rwp_percent": float(hist.get_wR()),
        "Rvals": {
            key: rvals.get(key)
            for key in ["Rwp", "GOF", "chisq", "Nobs", "Nvars", "converged", "Max shft/sig", "msg"]
        },
        "fractions": {
            key: [float(value[0]), float(value[1])]
            for key, value in hist.ComputeMassFracs().items()
        },
        "instrument": {
            key: value[:3] if isinstance(value, list) else value
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            key: hist.SampleParameters.get(key)
            for key in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "background": hist.Background[0],
        "phases": phases,
        "varyList": vary,
        "top_correlations": correlations[:20],
        "frozen": list(project.get_Frozen()),
    }


G2.SetPrintLevel("error")
for filename in sys.argv[1:]:
    print(json.dumps(inspect(Path(filename).resolve()), indent=2, default=float))
