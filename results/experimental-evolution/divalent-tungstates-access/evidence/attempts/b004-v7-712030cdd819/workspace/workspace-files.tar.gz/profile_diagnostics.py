#!/usr/bin/env python3
"""Create a compact whole-pattern residual diagnostic from a GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("project")
    parser.add_argument("png")
    parser.add_argument("json")
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(Path(args.project).resolve()))
    data = np.asarray(project.histograms()[0].data["data"][1], float)
    x, observed, weights, calculated, background, difference = data
    standardized = difference * np.sqrt(weights)

    # Peak-width smoothing highlights coherent positive residuals without
    # mistaking individual Poisson points for missing reflections.
    smoothed = gaussian_filter1d(standardized, 2.0)
    peaks, properties = find_peaks(smoothed, prominence=2.0, height=2.0, distance=8)
    order = np.argsort(properties["prominences"])[::-1]
    residual_peaks = [
        {
            "two_theta_deg": float(x[peaks[index]]),
            "standardized_height_smoothed": float(properties["peak_heights"][index]),
            "prominence": float(properties["prominences"][index]),
            "raw_difference_counts": float(difference[peaks[index]]),
        }
        for index in order[:40]
    ]

    bins = np.linspace(x.min(), x.max(), 19)
    binned = []
    for low, high in zip(bins[:-1], bins[1:]):
        mask = (x >= low) & (x < high if high < bins[-1] else x <= high)
        binned.append({
            "range_deg": [float(low), float(high)],
            "standardized_mean": float(np.mean(standardized[mask])),
            "standardized_rms": float(np.sqrt(np.mean(standardized[mask] ** 2))),
        })

    figure, axes = plt.subplots(
        3, 1, figsize=(18, 10), sharex=True,
        gridspec_kw={"height_ratios": [3.2, 1.2, 1.2]},
    )
    axes[0].plot(x, observed, lw=0.55, color="#1f77b4", label="observed")
    axes[0].plot(x, calculated, lw=0.65, color="#e66101", label="calculated")
    axes[0].plot(x, background, lw=0.8, color="#5aae61", label="background")
    axes[0].set_ylabel("counts")
    axes[0].legend(loc="upper right")
    axes[1].plot(x, difference, lw=0.55, color="#2166ac")
    axes[1].axhline(0.0, color="black", lw=0.5)
    axes[1].set_ylabel("obs − calc")
    axes[2].plot(x, standardized, lw=0.45, color="#2166ac", alpha=0.85)
    axes[2].plot(x, smoothed, lw=0.8, color="#b2182b")
    axes[2].axhline(0.0, color="black", lw=0.5)
    axes[2].set_ylim(-12, 12)
    axes[2].set_ylabel("weighted residual")
    axes[2].set_xlabel(r"2θ (degrees)")
    figure.tight_layout()
    figure.savefig(Path(args.png).resolve(), dpi=170)
    plt.close(figure)

    report = {
        "project": str(Path(args.project).resolve()),
        "Rwp_percent": float(project.histograms()[0].get_wR()),
        "weighted_residual_mean": float(np.mean(standardized)),
        "weighted_residual_rms": float(np.sqrt(np.mean(standardized ** 2))),
        "background_range_counts": [float(background.min()), float(background.max())],
        "binned": binned,
        "positive_residual_peaks": residual_peaks,
    }
    Path(args.json).resolve().write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
