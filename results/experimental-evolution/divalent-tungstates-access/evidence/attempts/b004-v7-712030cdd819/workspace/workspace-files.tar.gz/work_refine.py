#!/usr/bin/env python3
"""Build and iteratively refine the candidate Ba3W2O9 + WO3 model.

This is an analysis driver, not the mandated final bounded-polish step.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
WORK = ROOT / "work"
INPUT = ROOT / "inputs" / "pattern.csv"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(identifier: str) -> Path:
    return COD / identifier[0] / identifier[1:3] / identifier[3:5] / f"{identifier}.cif"


PHASES = [
    ("Ba3W2O9", cod_path("1533878")),
    ("WO3", cod_path("2311041")),
]


def prepare_inputs() -> tuple[Path, Path]:
    WORK.mkdir(exist_ok=True)
    x, y = np.loadtxt(INPUT, delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = WORK / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst = WORK / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting instrument\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.220;Polariz.:0.70;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def build(path: Path) -> G2.G2Project:
    xye, inst = prepare_inputs()
    project = G2.G2Project(newgpx=str(path))
    phases = [
        project.add_phase(str(cif), phasename=name, fmthint="CIF")
        for name, cif in PHASES
    ]
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": {"low": 9.90343322, "high": 100.09455322},
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "coeffs": [1300.0, -400.0, 250.0, -120.0, 60.0, -30.0, 10.0, -5.0],
            "refine": False,
        },
    })
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.1, False]
        phase.setSampleProfile(hist, "size", "isotropic", 0.5, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 800.0, LGmix=1.0)
        for atom in phase.atoms():
            atom.uiso = 0.008
            atom.refinement_flags = " "
    project.set_Controls("cycles", 8)
    project.save()
    return project


def clear_flags(project: G2.G2Project) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.SampleParameters.values():
        if isinstance(item, list) and len(item) > 1 and isinstance(item[1], bool):
            item[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        phase.clear_HAP_refinements({
            "Scale": True,
            "Size": True,
            "Mustrain": True,
            "Pref.Ori.": True,
            "HStrain": True,
            "Extinction": True,
            "Babinet": ["BabA", "BabU"],
        })
        for atom in phase.atoms():
            atom.refinement_flags = " "


def enable_common(project: G2.G2Project, *, background=True, scales=True) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = background
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": scales})


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    try:
        fractions = {
            k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()
        }
    except Exception:
        weighted = {
            p.name: float(p.data["General"]["Mass"])
            * float(p.data["Histograms"][hist.name]["Scale"][0])
            for p in project.phases()
        }
        total = sum(weighted.values())
        fractions = {k: [v / total, None] for k, v in weighted.items()}
    out = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "fractions": fractions,
        "instrument": {
            k: v[:3] if isinstance(v, list) else v
            for k, v in hist.InstrumentParameters.items()
            if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
        },
        "sample": {
            k: hist.SampleParameters.get(k)
            for k in ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]
        },
        "background": hist.Background[0],
        "phases": {},
        "varyList": list(cov.get("varyList", [])),
        "variables": [float(v) for v in cov.get("variables", [])],
        "sig": [float(v) for v in cov.get("sig", [])],
        "frozen": list(project.get_Frozen()),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [
                {
                    "label": a.label,
                    "element": a.element,
                    "xyz": list(map(float, a.coordinates)),
                    "uiso": float(a.uiso),
                    "flags": a.refinement_flags,
                }
                for a in phase.atoms()
            ],
        }
    print(json.dumps(out, indent=2, default=float))
    return out


def run_refinement(project: G2.G2Project, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    summarize(project, label)


def install_physical_bounds(project: G2.G2Project) -> None:
    """Apply the laboratory ranges and positivity limits to active families."""
    project.index_ids()
    for name, (low, high) in {
        ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0),
        ":0:SurfRoughA": (0.0, 0.6),
        ":0:SurfRoughB": (0.0, 0.5),
    }.items():
        project.set_Controls("parmMin", low, variable=name)
        project.set_Controls("parmMax", high, variable=name)
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")


def install_coordinate_bounds(project: G2.G2Project, window_angstrom: float = 0.10) -> None:
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half_width = window_angstrom / float(length)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half_width, variable=variable)
                project.set_Controls("parmMax", float(value) + half_width, variable=variable)


def install_uiso_constraints(project: G2.G2Project) -> None:
    """Refine one physically shared isotropic displacement value per phase."""
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        variables = [f"{pid}::AUiso:{i}" for i, _ in enumerate(phase.atoms())]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)


def set_stage_flags(project: G2.G2Project, mode: str) -> None:
    clear_flags(project)
    enable_common(project)
    hist = project.histograms()[0]
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    if mode in {"settle", "instrument", "joint", "joint_texture", "terminal_terms", "shift"}:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    if mode in {"instrument", "joint", "joint_texture"}:
        hist.set_refinements({
            "Instrument Parameters": ["U", "W", "X", "SH/L"]
        })
    if mode == "terminal_terms":
        hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
    if mode == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    if mode in {"profiles", "joint", "joint_texture", "terminal_terms"}:
        for phase in project.phases():
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            })
    if mode in {"joint_texture", "terminal_terms"}:
        for phase in project.phases():
            hist = project.histograms()[0]
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            if mode == "terminal_terms" and abs(float(po[1]) - 1.0) <= 0.05:
                continue
            phase.set_HAP_refinements({"Pref.Ori.": True})
            variable = f"{phase.data['pId']}:0:MD"
            project.set_Controls("parmMin", 0.7, variable=variable)
            project.set_Controls("parmMax", 1.4, variable=variable)
    if mode in {"heavy", "oxygen", "coordinates"}:
        for phase in project.phases():
            for atom in phase.atoms():
                is_oxygen = atom.element.strip().upper() in {"O", "O-2"}
                active = (
                    mode == "coordinates"
                    or (mode == "oxygen" and is_oxygen)
                    or (mode == "heavy" and not is_oxygen)
                )
                atom.refinement_flags = "X" if active else " "
    if mode == "uiso":
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = "U"


def continue_sequence(source: Path, output: Path, mode: str, passes: int) -> None:
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    install_physical_bounds(project)
    if mode in {"heavy", "oxygen", "coordinates"}:
        install_coordinate_bounds(project)
    if mode == "uiso":
        install_uiso_constraints(project)
    for index in range(passes):
        set_stage_flags(project, mode)
        run_refinement(project, f"{mode}_{index + 1}", cycles=10)
    clear_flags(project)
    project.save()
    summarize(project, f"{mode}_final_frozen")


def add_baco3_sequence(source: Path, output: Path, passes: int) -> None:
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(cod_path("9010928")),
        phasename="BaCO3",
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    phase.setSampleProfile(hist, "size", "isotropic", 0.5, LGmix=1.0)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 800.0, LGmix=1.0)
    for atom in phase.atoms():
        atom.uiso = 0.008
        atom.refinement_flags = " "
    install_physical_bounds(project)
    for index in range(passes):
        clear_flags(project)
        enable_common(project)
        run_refinement(project, f"add_baco3_scale_{index + 1}", cycles=10)
    clear_flags(project)
    project.save()
    summarize(project, "add_baco3_final_frozen")


def basic_sequence(output: Path) -> None:
    project = build(output)
    hist = project.histograms()[0]

    clear_flags(project)
    enable_common(project)
    run_refinement(project, "background_scales")

    clear_flags(project)
    enable_common(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run_refinement(project, "cells_background_scales")

    clear_flags(project)
    enable_common(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "cells_zero_background_scales")

    # Freeze at the end of this diagnostic sequence.
    clear_flags(project)
    project.save()
    summarize(project, "basic_final_frozen")


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "command",
        choices=[
            "build", "basic", "summary", "settle", "instrument", "profiles", "joint",
            "heavy", "oxygen", "coordinates",
            "joint_texture",
            "terminal_terms",
            "add_baco3",
            "uiso",
            "shift",
        ],
    )
    parser.add_argument("project", nargs="?", default="work/two_phase.gpx")
    parser.add_argument("output", nargs="?")
    parser.add_argument("--passes", type=int, default=3)
    args = parser.parse_args()
    path = (ROOT / args.project).resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    if args.command == "build":
        project = build(path)
        summarize(project, "built")
    elif args.command == "basic":
        basic_sequence(path)
    elif args.command == "summary":
        summarize(G2.G2Project(gpxfile=str(path)), "loaded")
    elif args.command == "add_baco3":
        if not args.output:
            raise SystemExit("add_baco3 requires SOURCE.gpx OUTPUT.gpx")
        output = (ROOT / args.output).resolve()
        add_baco3_sequence(path, output, args.passes)
    else:
        if not args.output:
            raise SystemExit("continuation modes require SOURCE.gpx OUTPUT.gpx")
        output = (ROOT / args.output).resolve()
        continue_sequence(path, output, args.command, args.passes)


if __name__ == "__main__":
    main()
