#!/usr/bin/env python3
"""Converge the accepted cells, profiles, intensity terms and nuisance model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

import work_refine as wr
from nuisance_compare import correlations


def configure(project: G2.G2Project, stage: str) -> None:
    wr.clear_flags(project)
    wr.enable_common(project)
    hist = project.histograms()[0]

    if stage in {"intensity", "profile", "joint"}:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        for phase in project.phases():
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            if abs(float(po[1]) - 1.0) > 0.05:
                phase.set_HAP_refinements({"Pref.Ori.": True})

    if stage in {"profile", "joint"}:
        hist.set_refinements({"Instrument Parameters": ["U", "SH/L"]})
        for index, phase in enumerate(project.phases()):
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True},
            })
            if index == 0:
                phase.set_HAP_refinements({
                    "Mustrain": {
                        "type": "uniaxial",
                        "direction": [1, 0, 0],
                        "refine": True,
                    }
                })
            else:
                phase.set_HAP_refinements({
                    "Mustrain": {"type": "isotropic", "refine": True},
                })

    if stage in {"cell", "joint"}:
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        for phase in project.phases():
            phase.set_refinements({"Cell": True})


def run_stage(project: G2.G2Project, stage: str, records: list[dict], maximum: int) -> None:
    for pass_index in range(maximum):
        configure(project, stage)
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        record = {
            "stage": stage,
            "pass": pass_index + 1,
            "Rwp_percent": float(project.histograms()[0].get_wR()),
            "GOF": rvals.get("GOF"),
            "converged": rvals.get("converged"),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "message": rvals.get("msg"),
            "frozen": list(project.get_Frozen()),
        }
        records.append(record)
        print(json.dumps(record), flush=True)
        if pass_index >= 1 and record["converged"] and not record["frozen"]:
            shift = record["max_shift_esd"]
            if shift is not None and float(shift) < 0.10:
                break


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("audit")
    parser.add_argument(
        "--stages", default="intensity,profile,cell,joint",
        help="comma-separated sequence drawn from intensity,profile,cell,joint",
    )
    args = parser.parse_args()
    source = Path(args.source).resolve()
    output = Path(args.output).resolve()
    audit_path = Path(args.audit).resolve()
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    wr.install_physical_bounds(project)
    project.index_ids()
    hist = project.histograms()[0]

    # Accepted one-parameter nuisance and one-axis profile branches.
    hist.InstrumentParameters["Polariz."][1] = 0.6863524908597938
    ba_phase = project.phases()[0]
    ba_phase.setSampleProfile(
        hist, "microstrain", "uniaxial",
        1989.8521830388777, 1868.7523930069244, [1, 0, 0], 1.0,
    )
    pid = ba_phase.data["pId"]
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;{suffix}")

    records: list[dict] = []
    maxima = {"intensity": 4, "profile": 4, "cell": 4, "joint": 5}
    stages = [item.strip() for item in args.stages.split(",") if item.strip()]
    if not stages or any(stage not in maxima for stage in stages):
        raise SystemExit("--stages contains an unknown or empty stage sequence")
    for stage in stages:
        maximum = maxima[stage]
        run_stage(project, stage, records, maximum)

    final_covariance = project.data.get("Covariance", {}).get("data", {})
    final_rvals = final_covariance.get("Rvals", {})
    profile = ba_phase.data["Histograms"][hist.name]["Mustrain"]
    audit = {
        "source": str(source),
        "output": str(output),
        "records": records,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": final_rvals.get("GOF"),
        "fractions": {
            name: [float(pair[0]), float(pair[1])]
            for name, pair in hist.ComputeMassFracs().items()
        },
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "ba3w2o9_mustrain": {
            "axis": profile[3],
            "equatorial_ppm": float(profile[1][0]),
            "axial_ppm": float(profile[1][1]),
        },
        "top_correlations": correlations(project)[:20],
        "frozen": list(project.get_Frozen()),
    }
    wr.clear_flags(project)
    project.save()
    audit_path.write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps(audit, indent=2), flush=True)


if __name__ == "__main__":
    main()
