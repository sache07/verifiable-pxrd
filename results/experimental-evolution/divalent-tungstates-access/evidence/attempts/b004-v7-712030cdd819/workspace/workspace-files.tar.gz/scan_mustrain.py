#!/usr/bin/env python3
"""Equal-development uniaxial microstrain-axis scan for each accepted phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

import work_refine as wr
from nuisance_compare import correlations


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def evaluate(source: Path, target: Path, phase_index: int, axis: list[int]) -> dict:
    project = G2.G2Project(gpxfile=str(source), newgpx=str(target))
    wr.install_physical_bounds(project)
    project.index_ids()
    hist = project.histograms()[0]
    phase = project.phases()[phase_index]
    current = float(phase.data["Histograms"][hist.name]["Mustrain"][1][0])
    phase.setSampleProfile(hist, "microstrain", "uniaxial", current, current, axis, 1.0)
    pid = phase.data["pId"]
    for suffix in ("i", "a"):
        project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;{suffix}")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;{suffix}")
    history = []
    for _ in range(3):
        wr.clear_flags(project)
        wr.enable_common(project)
        phase.set_HAP_refinements({
            "Mustrain": {
                "type": "uniaxial",
                "direction": axis,
                "refine": True,
            }
        })
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", 10)
        project.save()
        project.refine(makeBack=False)
        project.save()
        covariance = project.data.get("Covariance", {}).get("data", {})
        rvals = covariance.get("Rvals", {})
        history.append({
            "Rwp_percent": float(hist.get_wR()),
            "converged": rvals.get("converged"),
            "max_shift_esd": rvals.get("Max shft/sig"),
            "message": rvals.get("msg"),
            "frozen": list(project.get_Frozen()),
        })
    profile = phase.data["Histograms"][hist.name]["Mustrain"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    result = {
        "phase": phase.name,
        "axis": axis,
        "equatorial_ppm": float(profile[1][0]),
        "axial_ppm": float(profile[1][1]),
        "axial_to_equatorial": float(profile[1][1] / profile[1][0]),
        "Rwp_percent": float(hist.get_wR()),
        "chisq": float(rvals.get("chisq", np.nan)),
        "history": history,
        "top_correlations": correlations(project)[:10],
        "frozen": list(project.get_Frozen()),
        "project": str(target),
    }
    wr.clear_flags(project)
    project.save()
    return result


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output_json")
    parser.add_argument("--phase", type=int)
    args = parser.parse_args()
    source = Path(args.source).resolve()
    output = Path(args.output_json).resolve()
    folder = output.parent / "mustrain_branches"
    folder.mkdir(parents=True, exist_ok=True)
    probe = G2.G2Project(gpxfile=str(source))
    indices = range(len(probe.phases())) if args.phase is None else [args.phase]
    records = []
    for index in indices:
        phase = probe.phases()[index]
        for axis in AXES:
            token = "".join(map(str, axis))
            target = folder / f"{index}_{phase.name}_{token}.gpx"
            record = evaluate(source, target, index, list(axis))
            records.append(record)
            print(json.dumps(record), flush=True)
    output.write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
