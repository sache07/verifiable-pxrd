#!/usr/bin/env python3
"""Build Mn2WO5 analogues from distinct A2BO5 topology parents."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
REFROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
MODELS = {
    # label: (COD parent, A species, B species, initial lattice-length scale)
    # Pnnm and P21/c are hydroxyl-arsenate parents. Replacing As(V) + OH-
    # by W(VI) + O2- gives the charge-balanced Mn2WO5 stoichiometry directly.
    "eveite_pnnm": ("9000178", "Mn", "As", 0.995),
    "olivenite_p21c": ("9011171", "Cu", "As", 1.015),
    "co2po5_i41amd": ("4337659", "Co", "P", 1.340),
    "pseudobrookite_cmcm": ("1011342", "Fe", "Ti", 0.900),
}


def cif_path(cod_id: str) -> Path:
    return REFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    for label, (cod_id, a_species, b_species, length_scale) in MODELS.items():
        structure = Structure.from_file(cif_path(cod_id))
        # Some COD files carry formal oxidation states while others do not.
        try:
            structure.remove_oxidation_states()
        except Exception:
            pass
        structure.replace_species({a_species: "Mn", b_species: "W"})
        structure.scale_lattice(structure.volume * length_scale**3)
        out = ROOT / "analysis" / f"Mn2WO5_from_{label}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=True).write_file(out)
        print(
            label,
            structure.composition.reduced_formula,
            structure.get_space_group_info(),
            "cell=",
            tuple(round(x, 5) for x in structure.lattice.abc),
            tuple(round(x, 5) for x in structure.lattice.angles),
            "V=",
            round(structure.volume, 5),
        )


if __name__ == "__main__":
    main()
