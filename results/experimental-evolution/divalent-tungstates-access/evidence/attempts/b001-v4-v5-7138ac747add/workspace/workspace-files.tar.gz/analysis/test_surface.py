#!/usr/bin/env python3
"""Test the documented Bragg-Brentano surface-roughness correction."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "strain_p0_100.gpx"),
        newgpx=str(ROOT / "analysis" / "surface_test.gpx"),
    )
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
        )
    hist.SampleParameters["SurfRoughA"] = [0.20, True]
    hist.SampleParameters["SurfRoughB"] = [0.10, True]
    for name, lo, hi in (("SurfRoughA", 0.05, 0.60), ("SurfRoughB", 0.02, 0.50)):
        project.set_Controls("parmMin", lo, f":0:{name}")
        project.set_Controls("parmMax", hi, f":0:{name}")
    project.refine()
    print("SURFACE", f"wR={hist.get_wR():.7f}",
          "A=", hist.SampleParameters["SurfRoughA"],
          "B=", hist.SampleParameters["SurfRoughB"],
          "mass=", hist.ComputeMassFracs())
    project.save()


if __name__ == "__main__":
    main()
