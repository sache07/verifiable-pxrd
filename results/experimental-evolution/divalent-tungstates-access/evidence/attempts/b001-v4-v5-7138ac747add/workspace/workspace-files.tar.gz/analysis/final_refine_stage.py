#!/usr/bin/env python3
"""Final staged refinement from the accepted physical structural checkpoint."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]


def checkpoint(project, label):
    project.save()
    shutil.copy2(project.filename, ROOT / "analysis" / f"final_{label}.gpx")


def status(project, label):
    hist = project.histogram(0)
    print(f"FINALSTAGE {label} wR={hist.get_wR():.8f}")
    print(" mass", hist.ComputeMassFracs())
    print(" inst", {k: v[1] for k, v in hist.InstrumentParameters.items()
                    if k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")})
    print(" shift", hist.SampleParameters["Shift"])
    for phase in project.phases():
        print(phase.name, phase.get_cell())


def refine(project, label):
    project.refine()
    status(project, label)
    checkpoint(project, label)


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "mainO_pnnmO.gpx"),
        newgpx=str(ROOT / "analysis" / "final_stage_work.gpx"),
    )
    project.set_Controls("cycles", 15)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
        )
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})

    # Final lattice pass with conservative phase-dependent metric windows.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        cell = phase.get_cell()
        avec = G2lat.cell2A(
            (cell["length_a"], cell["length_b"], cell["length_c"],
             cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"])
        )
        frac = 0.01 if phase.id < 2 else 0.03
        for idx, value in enumerate(avec):
            if abs(value) < 1e-10:
                continue
            lo, hi = sorted(((1-frac)*value, (1+frac)*value))
            project.set_Controls("parmMin", lo, f"{phase.id}::A{idx}")
            project.set_Controls("parmMax", hi, f"{phase.id}::A{idx}")
    refine(project, "cells")
    refine(project, "cells_stable")

    # Hold cells fixed and release only common profile terms not already on a
    # documented boundary. U=40 and X=0.1 remain fixed at their physical bounds.
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    for name, lo, hi in (("W", 2.0, 40.0), ("SH/L", 0.005, 0.10),
                         ("Polariz.", 0.5, 1.0)):
        project.set_Controls("parmMin", lo, f":0:{name}")
        project.set_Controls("parmMax", hi, f":0:{name}")
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L", "Polariz."]})
    refine(project, "profile")
    refine(project, "profile_stable")

    # One final displacement update with zero and all lattices fixed.
    hist.clear_refinements({"Instrument Parameters": ["W", "SH/L", "Polariz."]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.set_Controls("parmMin", -800.0, ":0:Shift")
    project.set_Controls("parmMax", 800.0, ":0:Shift")
    refine(project, "shift")
    refine(project, "shift_stable")


if __name__ == "__main__":
    main()
