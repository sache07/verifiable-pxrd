#!/usr/bin/env python3
"""Bounded heavy-atom coordinate tests from the best physical checkpoint."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
HEAVY = {
    0: ("Mn1", "W1"),
    1: ("W1", "W2"),
    2: ("Mn0", "Mn1", "W2"),
}


def prepare(project):
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
        )
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    return hist


def main():
    for pidx, labels in HEAVY.items():
        out = ROOT / "analysis" / f"heavy_p{pidx}.gpx"
        project = G2sc.G2Project(
            str(ROOT / "analysis" / "pnnm_cell_test3.gpx"), newgpx=str(out)
        )
        hist = prepare(project)
        phase = project.phase(pidx)
        initial = {a.label: tuple(a.coordinates) for a in phase.atoms()}
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        # GSAS-II's dA variables store the current fractional coordinate (the
        # name is historical), so limits must be centered on each coordinate.
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.label not in labels:
                continue
            for coord, value in zip("xyz", initial[atom.label]):
                project.set_Controls(
                    "parmMin", value - 0.008, f"{pidx}::dA{coord}:{atom_index}"
                )
                project.set_Controls(
                    "parmMax", value + 0.008, f"{pidx}::dA{coord}:{atom_index}"
                )
        project.refine()
        print("HEAVY", pidx, phase.name, f"wR={hist.get_wR():.7f}",
              "mass=", hist.ComputeMassFracs())
        for atom in phase.atoms():
            if atom.label in labels:
                print("MOVE", pidx, atom.label,
                      tuple(round(n-o, 7) for n, o in zip(atom.coordinates, initial[atom.label])),
                      tuple(round(n, 7) for n in atom.coordinates))
        phase.export_CIF(str(ROOT / "analysis" / f"heavy_p{pidx}.cif"))
        project.save()


if __name__ == "__main__":
    main()
