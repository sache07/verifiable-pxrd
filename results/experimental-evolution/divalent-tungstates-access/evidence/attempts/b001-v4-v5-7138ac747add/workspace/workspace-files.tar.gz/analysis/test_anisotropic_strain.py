#!/usr/bin/env python3
"""Screen one bounded uniaxial microstrain family at a time."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0))


def prepare(project):
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
        # Retain the accepted Pnnm texture value, but hold it fixed during
        # this one-family strain comparison.
        phase.clear_HAP_refinements({"Pref.Ori.": True}, [hist])
    return hist


def main():
    for pidx in range(3):
        for axis in AXES:
            tag = f"p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            out = ROOT / "analysis" / f"strain_{tag}.gpx"
            project = G2sc.G2Project(
                str(ROOT / "analysis" / "texture_p2_001.gpx"), newgpx=str(out)
            )
            hist = prepare(project)
            phase = project.phase(pidx)
            mu = phase.data["Histograms"][hist.name]["Mustrain"]
            initial = min(8000.0, max(300.0, float(mu[1][0])))
            mu[1][0] = mu[1][1] = initial
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "uniaxial", "direction": list(axis),
                               "refine": True}}, [hist]
            )
            for suffix in ("i", "a"):
                project.set_Controls("parmMin", 300.0, f"{pidx}:0:Mustrain;{suffix}")
                project.set_Controls("parmMax", 8000.0, f"{pidx}:0:Mustrain;{suffix}")
            project.refine()
            print(
                "STRAIN", tag, phase.name, axis,
                f"wR={hist.get_wR():.7f}",
                f"equ={mu[1][0]:.5f}", f"ax={mu[1][1]:.5f}",
                "mass=", hist.ComputeMassFracs(),
            )
            project.save()


if __name__ == "__main__":
    main()
