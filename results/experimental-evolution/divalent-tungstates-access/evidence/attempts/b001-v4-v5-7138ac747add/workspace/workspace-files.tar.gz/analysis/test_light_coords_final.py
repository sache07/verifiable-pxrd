#!/usr/bin/env python3
"""Limited, bounded oxygen-coordinate probes with phase-wise rollback."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def prepare(project):
    project.set_Controls("cycles", 12)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
        )
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})
    return hist


def main():
    for pidx in range(3):
        out = ROOT / "analysis" / f"light_p{pidx}.gpx"
        project = G2sc.G2Project(
            str(ROOT / "analysis" / "heavy_main_wo3_stable.gpx"), newgpx=str(out)
        )
        hist = prepare(project)
        phase = project.phase(pidx)
        labels = [a.label for a in phase.atoms() if a.element == "O"]
        initial = {a.label: tuple(a.coordinates) for a in phase.atoms()}
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        for atom_index, atom in enumerate(phase.atoms()):
            if atom.label not in labels:
                continue
            for coord, value in zip("xyz", initial[atom.label]):
                project.set_Controls(
                    "parmMin", value - 0.006, f"{pidx}::dA{coord}:{atom_index}"
                )
                project.set_Controls(
                    "parmMax", value + 0.006, f"{pidx}::dA{coord}:{atom_index}"
                )
        project.refine()
        print("LIGHT", pidx, phase.name, f"wR={hist.get_wR():.7f}",
              "mass=", hist.ComputeMassFracs())
        for atom in phase.atoms():
            if atom.label in labels:
                move = tuple(round(n-o, 7) for n, o in
                             zip(atom.coordinates, initial[atom.label]))
                print("OMOVE", pidx, atom.label, move)
        phase.export_CIF(str(ROOT / "analysis" / f"light_p{pidx}.cif"))
        project.save()


if __name__ == "__main__":
    main()
