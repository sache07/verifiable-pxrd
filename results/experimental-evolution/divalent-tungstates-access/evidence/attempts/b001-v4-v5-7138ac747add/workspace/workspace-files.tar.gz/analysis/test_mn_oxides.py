#!/usr/bin/env python3
"""Test chemically plausible Mn-oxide residual phases on one two-phase state."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
REFROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif")
BRANCHES = {
    "mn3o4_tetragonal": "9001963",
    "mn3o4_pbcm": "1541183",
    "mno_rocksalt": "1514108",
    "mn2o3_bixbyite": "1514230",
    "mno2_rutile": "1514110",
}


def cif_path(cod_id: str) -> Path:
    return REFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def status(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"STATUS {label} wR={hist.get_wR():.6f}")
    print(" mass", hist.ComputeMassFracs())
    print(" inst", {k: v[1] for k, v in hist.InstrumentParameters.items()
                     if k in ("Zero", "U", "W", "X", "SH/L")})
    for phase in project.phases():
        print(" ", phase.name, phase.get_cell(), phase.getHAPvalues(hist)["Scale"])


def run_branch(label: str, cod_id: str) -> None:
    out = ROOT / "analysis" / f"branch_{label}.gpx"
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "branch_wo3_p21c.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 6)
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    phase = project.add_phase(
        str(cif_path(cod_id)), phasename=label, histograms=[hist], fmthint="CIF"
    )
    phase.data["Histograms"][hist.name]["Scale"] = [8.0, True]
    project.save()
    project.refine()
    status(project, f"{label}-scale")
    phase.set_refinements({"Cell": True})
    project.refine()
    status(project, f"{label}-cell")
    project.save()


def main() -> None:
    for label, cod_id in BRANCHES.items():
        print(f"\n===== {label} {cod_id} =====")
        run_branch(label, cod_id)


if __name__ == "__main__":
    main()
