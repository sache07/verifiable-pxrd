#!/usr/bin/env python3
"""Export all submitted artifacts from the single final GSAS-II checkpoint."""

from pathlib import Path
import csv
import json

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
CIFS = {
    "MnWO4_wolframite": "phase_1_MnWO4_wolframite.cif",
    "WO3_monoclinic": "phase_2_WO3_monoclinic.cif",
    "Mn2WO5_Pnnm": "phase_3_Mn2WO5_Pnnm.cif",
}


def array(hist, name):
    return np.asarray(np.ma.filled(hist.getdata(name), np.nan), dtype=float)


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "full_grid.gpx"),
        newgpx=str(ROOT / "final.gpx"),
    )
    project.save()
    hist = project.histogram(0)

    for phase in project.phases():
        phase.export_CIF(str(ROOT / CIFS[phase.name]))

    x = array(hist, "x")
    observed = array(hist, "yobs")
    calculated = array(hist, "ycalc")
    background = array(hist, "background")
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(
            zip(x, observed, calculated, difference, background, strict=True)
        )

    cov = project.data["Covariance"]["data"]
    rvals = cov["Rvals"]
    summary = {
        "histogram": hist.name,
        "mass_fractions": hist.ComputeMassFracs(),
        "histogram_residuals": hist.residuals,
        "refinement": {
            "chi_square": rvals["chisq"],
            "n_observations": rvals["Nobs"],
            "n_variables": rvals["Nvars"],
            "goodness_of_fit": rvals["GOF"],
            "converged": rvals["converged"],
            "max_shift_over_esd": rvals["Max shft/sig"],
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "cifs": CIFS,
    }
    (ROOT / "analysis" / "final_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
