#!/usr/bin/env python3
"""Refine WO3 heavy and light coordinates from the physical P21/c branch."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def atom_table(phase):
    return {a.label: tuple(a.coordinates) for a in phase.atoms()}


def report(project, label, initial):
    hist = project.histogram(0)
    phase = project.phase("WO3_p21c")
    print(f"STATUS {label} wR={hist.get_wR():.7f} mass={hist.ComputeMassFracs()}")
    for atom in phase.atoms():
        old = initial[atom.label]
        new = tuple(atom.coordinates)
        delta = tuple(n - o for n, o in zip(new, old))
        print(atom.label, "xyz", new, "delta_frac", delta, "flags", atom.refinement_flags)


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "branch_wo3_p21c.gpx"),
        newgpx=str(ROOT / "analysis" / "wo3_coord_work.gpx"),
    )
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    # Isolate the structural test: retain the converged profile values but do
    # not let profile, zero, or cell terms compensate coordinate changes.
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Zero"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
    phase = project.phase("WO3_p21c")
    initial = atom_table(phase)
    project.save()
    project.refine()
    report(project, "baseline", initial)

    phase.set_refinements({"Atoms": {"W1": "X", "W2": "X"}})
    project.refine()
    report(project, "heavy", initial)
    project.save(str(ROOT / "analysis" / "wo3_coord_heavy.gpx"))
    phase.export_CIF(str(ROOT / "analysis" / "wo3_coord_heavy.cif"))

    phase.set_refinements({"Atoms": {"all": "X"}})
    project.refine()
    report(project, "all_atoms", initial)
    project.save(str(ROOT / "analysis" / "wo3_coord_all.gpx"))
    phase.export_CIF(str(ROOT / "analysis" / "wo3_coord_all.cif"))


if __name__ == "__main__":
    main()
