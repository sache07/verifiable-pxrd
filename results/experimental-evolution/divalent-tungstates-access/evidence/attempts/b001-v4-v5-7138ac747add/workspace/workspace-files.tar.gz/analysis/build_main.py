#!/usr/bin/env python3
"""Create and stage-refine an initial one-phase MnWO4 GSAS-II model."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
REFROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif")


def cif_path(cod_id: str) -> Path:
    return REFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"{label}: residuals={hist.residuals} wR={hist.get_wR():.5g}")
    print(" instrument", hist.InstrumentParameters)
    print(" sample", hist.SampleParameters)
    for phase in project.phases():
        print(" phase", phase.name, phase.get_cell(), phase.getHAPvalues(hist))


def main() -> None:
    out = ROOT / "analysis" / "main_only.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "cu_ka.instprm"),
        fmthint="comma",
    )
    phase = project.add_phase(
        str(cif_path("1520200")),
        phasename="MnWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )
    # The histogram-wide and per-phase scales are exactly correlated. Keep the
    # histogram scale fixed and use HAP phase scales for quantitative analysis.
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "refine": True,
            "no. coeffs": 10,
            "coeffs": [1800.0] + [0.0] * 9,
        },
    })
    phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()
    project.refine()
    summarize(project, "scale+background")

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    phase.set_refinements({"Cell": True})
    project.refine()
    summarize(project, "+zero+cell")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.refine()
    summarize(project, "+profile")
    project.save()


if __name__ == "__main__":
    main()
