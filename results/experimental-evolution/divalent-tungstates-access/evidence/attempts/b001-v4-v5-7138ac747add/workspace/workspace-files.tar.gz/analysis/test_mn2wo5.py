#!/usr/bin/env python3
"""Compare Mn2WO5 topology branches in one fixed multiphase state."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
MODELS = ["eveite_pnnm", "olivenite_p21c", "co2po5_i41amd", "pseudobrookite_cmcm"]


def status(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"STATUS {label} wR={hist.get_wR():.7f}")
    print(" mass", hist.ComputeMassFracs())
    print(
        " inst",
        {k: v[1] for k, v in hist.InstrumentParameters.items() if k in ("Zero", "U", "W", "X", "SH/L")},
    )
    for phase in project.phases():
        print(" ", phase.name, phase.get_cell(), phase.getHAPvalues(hist)["Scale"])


def run(label: str) -> None:
    out = ROOT / "analysis" / f"branch_mn2wo5_{label}.gpx"
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "branch_wo3_p21c.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 10)
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    phase = project.add_phase(
        str(ROOT / "analysis" / f"Mn2WO5_from_{label}.cif"),
        phasename=f"Mn2WO5_{label}",
        histograms=[hist],
        fmthint="CIF",
    )
    phase.data["Histograms"][hist.name]["Scale"] = [20.0, True]
    project.save()
    project.refine()
    status(project, f"{label}-scale")

    phase.set_refinements({"Cell": True})
    project.refine()
    status(project, f"{label}-cell")
    project.save()


def main() -> None:
    for label in MODELS:
        print(f"\n===== {label} =====")
        run(label)


if __name__ == "__main__":
    main()
