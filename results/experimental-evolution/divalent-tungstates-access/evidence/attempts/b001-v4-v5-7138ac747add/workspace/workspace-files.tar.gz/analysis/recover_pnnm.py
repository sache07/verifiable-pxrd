#!/usr/bin/env python3
"""Restart the transferred Pnnm cell from its indexed residual solution."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]


def checkpoint(project, label):
    project.save()
    shutil.copy2(project.filename, ROOT / "analysis" / f"pnnm_{label}.gpx")


def status(project, label):
    hist = project.histogram(0)
    print(f"STATUS {label} wR={hist.get_wR():.7f} mass={hist.ComputeMassFracs()}")
    print(" inst", {k: v[1] for k, v in hist.InstrumentParameters.items()
                    if k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")})
    print(" shift", hist.SampleParameters["Shift"])
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(phase.id, phase.name, phase.get_cell(), "scale", hap["Scale"],
              "size", hap["Size"][:3], "mu", hap["Mustrain"][:3])


def refine(project, label):
    project.refine()
    status(project, label)
    checkpoint(project, label)


def set_cell(phase, cell):
    avec = G2lat.cell2A(cell)
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(avec)


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "physical_profile.gpx"),
        newgpx=str(ROOT / "analysis" / "pnnm_recover_work.gpx"),
    )
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    # Clear limit-triggered freezes inherited from the exploratory run. We
    # explicitly fix or bound every term released below.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    phases = project.phases()
    for phase in phases:
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])

    target = project.phase("Mn2WO5_Pnnm")
    # Cell obtained by fitting the coherent residual family in the topology
    # comparison. It is only an indexed start; the coordinates remain those
    # of the physical eveite-derived parent.
    start_cell = (8.42862021, 8.92467870, 6.16875828, 90.0, 90.0, 90.0)
    set_cell(target, start_cell)
    hap = target.data["Histograms"][hist.name]
    hap["Size"][1][0] = 0.10
    hap["Mustrain"][1][0] = 3000.0
    target.set_refinements({"Cell": True})

    avec = G2lat.cell2A(start_cell)
    for idx, value in enumerate(avec):
        if abs(value) < 1e-10:
            continue
        lo, hi = sorted((0.94 * value, 1.06 * value))
        project.set_Controls("parmMin", lo, f"{target.id}::A{idx}")
        project.set_Controls("parmMax", hi, f"{target.id}::A{idx}")
    for variable, lo, hi in (
        (f"{target.id}:0:Size;i", 0.04, 1.5),
        (f"{target.id}:0:Mustrain;i", 300.0, 8000.0),
    ):
        project.set_Controls("parmMin", lo, variable)
        project.set_Controls("parmMax", hi, variable)

    checkpoint(project, "restart")
    refine(project, "cell")

    target.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True},
         "Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    refine(project, "broadening")

    # Re-optimize all cells and the bounded common profile from the recovered
    # Pnnm solution; calibration remains fixed at the physical checkpoint.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]}
    )
    refine(project, "profile")


if __name__ == "__main__":
    main()
