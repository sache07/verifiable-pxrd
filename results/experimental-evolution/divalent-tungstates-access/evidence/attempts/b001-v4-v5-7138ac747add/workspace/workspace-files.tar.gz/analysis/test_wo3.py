#!/usr/bin/env python3
"""Compare distinct WO3 topology branches from one MnWO4 checkpoint."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
REFROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif")
BRANCHES = {
    "p21c": "2311041",
    "pnma": "2107312",
    "pminus1": "2106293",
}


def cif_path(cod_id: str) -> Path:
    return REFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def status(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"STATUS {label} wR={hist.get_wR():.6f}")
    print("  mass", hist.ComputeMassFracs())
    for phase in project.phases():
        print(" ", phase.name, phase.get_cell(), phase.getHAPvalues(hist)["Scale"])


def run_branch(label: str, cod_id: str) -> None:
    out = ROOT / "analysis" / f"branch_wo3_{label}.gpx"
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "main_only.bak0.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 8)
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    phase = project.add_phase(
        str(cif_path(cod_id)),
        phasename=f"WO3_{label}",
        histograms=[hist],
        fmthint="CIF",
    )
    phase.data["Histograms"][hist.name]["Scale"] = [40.0, True]
    project.save()
    project.refine()
    status(project, f"{label}-scale")

    phase.set_refinements({"Cell": True})
    project.refine()
    status(project, f"{label}-cell")
    project.save()


def main() -> None:
    for label, cod_id in BRANCHES.items():
        print(f"\n===== {label} {cod_id} =====")
        run_branch(label, cod_id)


if __name__ == "__main__":
    main()
