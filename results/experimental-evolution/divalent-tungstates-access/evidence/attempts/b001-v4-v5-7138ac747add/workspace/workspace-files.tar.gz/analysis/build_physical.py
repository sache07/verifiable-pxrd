#!/usr/bin/env python3
"""Build the accepted three-phase model with physically bounded broadening."""

from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
REFROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cif_path(cod_id: str) -> Path:
    return REFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def checkpoint(project: G2sc.G2Project, label: str) -> None:
    project.save()
    shutil.copy2(project.filename, ROOT / "analysis" / f"physical_{label}.gpx")


def status(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(f"STATUS {label} wR={hist.get_wR():.7f} residuals={hist.residuals}")
    print(" mass", hist.ComputeMassFracs())
    print(
        " inst",
        {k: v[1] for k, v in hist.InstrumentParameters.items()
         if k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
    )
    print(
        " sample",
        {k: hist.SampleParameters[k] for k in
         ("Shift", "SurfRoughA", "SurfRoughB", "Gonio. radius")},
    )
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        print(
            " ", phase.id, phase.name, phase.get_cell(),
            "scale", hap["Scale"], "size", hap["Size"][:3],
            "mustrain", hap["Mustrain"][:3], "PO", hap["Pref.Ori."][:4],
        )


def refine(project: G2sc.G2Project, label: str) -> None:
    project.refine()
    status(project, label)
    checkpoint(project, label)


def set_bounds(project: G2sc.G2Project, phases) -> None:
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }
    for variable, (lower, upper) in bounds.items():
        project.set_Controls("parmMin", lower, variable)
        project.set_Controls("parmMax", upper, variable)
    for pid in range(3):
        for name, lower, upper in (
            ("Size;i", 0.04, 1.5),
            ("Mustrain;i", 300.0, 8000.0),
        ):
            variable = f"{pid}:0:{name}"
            project.set_Controls("parmMin", lower, variable)
            project.set_Controls("parmMax", upper, variable)
    # Reference mismatch is at most about 0.5% in length for this experiment.
    # Permit a conservative 1.5% length excursion (about 3% in reciprocal
    # metric coefficients), preventing calibration/profile errors from being
    # absorbed by nonphysical cells.
    for phase in phases:
        cell = phase.get_cell()
        avec = G2lat.cell2A(
            (
                cell["length_a"], cell["length_b"], cell["length_c"],
                cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
            )
        )
        for idx, value in enumerate(avec):
            if abs(value) < 1e-10:
                continue
            lo, hi = sorted((0.97 * value, 1.03 * value))
            project.set_Controls("parmMin", lo, f"{phase.id}::A{idx}")
            project.set_Controls("parmMax", hi, f"{phase.id}::A{idx}")


def main() -> None:
    out = ROOT / "analysis" / "physical_work.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    project.set_Controls("cycles", 12)
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "cu_ka.instprm"),
        fmthint="comma",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    for name, value in (("Zero", 0.0), ("U", 15.0), ("W", 15.0),
                        ("X", 2.0), ("SH/L", 0.03), ("Polariz.", 0.75)):
        hist.InstrumentParameters[name][1] = value
        hist.InstrumentParameters[name][2] = False
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
                "coeffs": [1700.0] + [0.0] * 11,
            },
        }
    )

    phase_specs = (
        (cif_path("1520200"), "MnWO4_wolframite", 210.0),
        (cif_path("2311041"), "WO3_monoclinic", 18.0),
        (ROOT / "analysis" / "Mn2WO5_from_eveite_pnnm.cif", "Mn2WO5_Pnnm", 10.0),
    )
    phases = []
    for path, name, scale in phase_specs:
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        phase.data["Histograms"][hist.name]["Scale"] = [scale, True]
        # Give the first scale fit a realistic width. These values are central
        # within the documented specimen ranges and are initially held fixed.
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.20
        hap["Size"][2][0] = False
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 2000.0
        hap["Mustrain"][2][0] = False
        phases.append(phase)

    set_bounds(project, phases)
    checkpoint(project, "start")
    refine(project, "scale_background")

    # Establish specimen broadening before allowing lattice/calibration shifts.
    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    refine(project, "size_mustrain")

    # Calibrate zero first with displacement held fixed, then displacement with
    # zero fixed. This avoids their near-exact low-angle correlation.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells_zero")

    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "cells_shift")

    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_rezero")

    # Release only the physically supported common instrument terms.
    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]}
    )
    refine(project, "profile")


if __name__ == "__main__":
    main()
