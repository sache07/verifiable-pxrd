#!/usr/bin/env python3
"""Screen one bounded March-Dollase family at a time."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1))


def prepare(project):
    project.set_Controls("cycles", 8)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."]}
    )
    hist.clear_refinements({"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
        )
    return hist


def main():
    for pidx in range(3):
        for axis in AXES:
            tag = f"p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            out = ROOT / "analysis" / f"texture_{tag}.gpx"
            project = G2sc.G2Project(
                str(ROOT / "analysis" / "physical_profile.gpx"), newgpx=str(out)
            )
            hist = prepare(project)
            phase = project.phase(pidx)
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
            project.set_Controls("parmMin", 0.7, f"{pidx}:0:MD")
            project.set_Controls("parmMax", 1.4, f"{pidx}:0:MD")
            project.refine()
            print(
                "TEXTURE", tag, phase.name, axis,
                f"wR={hist.get_wR():.7f}", f"MD={po[1]:.7f}",
                "mass=", hist.ComputeMassFracs(),
            )
            project.save()


if __name__ == "__main__":
    main()
