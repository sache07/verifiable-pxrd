#!/usr/bin/env python3
"""Build Mn3WO6 analogue models from distinct frozen-reference topologies."""

from pathlib import Path
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
REFROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06/cif")
MODELS = {
    # label: (COD parent, substituted species, initial isotropic lattice scale)
    "ca_p21c": ("1563081", "Ca", 1.085),
    "cu_pa3": ("1527404", "Cu", 0.970),
    "ba_p1": ("1534803", "Ba", 0.830),
}


def cif_path(cod_id: str) -> Path:
    return REFROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    for label, (cod_id, old, length_scale) in MODELS.items():
        structure = Structure.from_file(cif_path(cod_id))
        structure.replace_species({old: "Mn"})
        structure.scale_lattice(structure.volume * length_scale**3)
        out = ROOT / "analysis" / f"Mn3WO6_from_{label}.cif"
        # Standardize the setting so GSAS-II can map the listed operations.
        CifWriter(structure, symprec=1e-3, refine_struct=True).write_file(out)
        print(label, structure.composition.reduced_formula,
              structure.get_space_group_info(), structure.lattice, structure.volume)


if __name__ == "__main__":
    main()
