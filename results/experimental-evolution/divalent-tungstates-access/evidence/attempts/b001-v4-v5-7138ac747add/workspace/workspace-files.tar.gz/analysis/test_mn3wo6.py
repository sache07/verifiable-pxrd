#!/usr/bin/env python3
"""Test Mn3WO6 analogue topologies in the same two-phase refinement state."""

from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
MODELS = ["ca_p21c", "cu_pa3", "ba_p1"]


def status(project, label):
    hist = project.histogram(0)
    print(f"STATUS {label} wR={hist.get_wR():.7f}")
    print(" mass", hist.ComputeMassFracs())
    print(" inst", {k: v[1] for k, v in hist.InstrumentParameters.items()
                     if k in ("Zero", "U", "W", "X", "SH/L")})
    for phase in project.phases():
        print(" ", phase.name, phase.get_cell(), phase.getHAPvalues(hist)["Scale"])


def run(label):
    out = ROOT / "analysis" / f"branch_mn3wo6_{label}.gpx"
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "branch_wo3_p21c.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 8)
    hist = project.histogram(0)
    hist.SampleParameters["Scale"] = [1.0, False]
    phase = project.add_phase(
        str(ROOT / "analysis" / f"Mn3WO6_from_{label}.cif"),
        phasename=f"Mn3WO6_{label}", histograms=[hist], fmthint="CIF",
    )
    phase.data["Histograms"][hist.name]["Scale"] = [10.0, True]
    project.save()
    project.refine()
    status(project, f"{label}-scale")
    phase.set_refinements({"Cell": True})
    project.refine()
    status(project, f"{label}-cell")
    project.save()


def main():
    for label in MODELS:
        print(f"\n===== {label} =====")
        run(label)


if __name__ == "__main__":
    main()
