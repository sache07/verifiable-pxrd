#!/usr/bin/env python3
"""Probe symmetry-preserving Mn2WO5 coordinate refinements with rollback."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "branch_mn2wo5_eveite_pnnm.gpx"


def freeze_nonstructural(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements(
        {"Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Zero"]}
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})


def report(project: G2sc.G2Project, label: str, initial: dict) -> None:
    hist = project.histogram(0)
    phase = project.phase("Mn2WO5_eveite_pnnm")
    print(f"STATUS {label} wR={hist.get_wR():.7f} mass={hist.ComputeMassFracs()}")
    for atom in phase.atoms():
        old = initial[atom.label]
        new = tuple(atom.coordinates)
        delta = tuple(round(n - o, 7) for n, o in zip(new, old))
        print(atom.label, "xyz", tuple(round(v, 7) for v in new), "delta", delta)


def refine_branch(label: str, atom_flags: dict) -> None:
    out = ROOT / "analysis" / f"mn2wo5_coord_{label}.gpx"
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "mn2wo5_coord_heavy.gpx"), newgpx=str(out)
    )
    project.set_Controls("cycles", 12)
    freeze_nonstructural(project)
    phase = project.phase("Mn2WO5_eveite_pnnm")
    initial = {a.label: tuple(a.coordinates) for a in phase.atoms()}
    phase.set_refinements({"Atoms": atom_flags})
    project.refine()
    report(project, label, initial)
    phase.export_CIF(str(ROOT / "analysis" / f"mn2wo5_coord_{label}.cif"))
    project.save()


def main() -> None:
    # First refine all cation coordinates from the converged cell branch.
    project = G2sc.G2Project(
        str(BASE), newgpx=str(ROOT / "analysis" / "mn2wo5_coord_heavy.gpx")
    )
    project.set_Controls("cycles", 12)
    freeze_nonstructural(project)
    phase = project.phase("Mn2WO5_eveite_pnnm")
    initial = {a.label: tuple(a.coordinates) for a in phase.atoms()}
    phase.set_refinements(
        {"Atoms": {"Mn0": "X", "Mn1": "X", "W2": "X"}}
    )
    project.refine()
    report(project, "heavy", initial)
    phase.export_CIF(str(ROOT / "analysis" / "mn2wo5_coord_heavy.cif"))
    project.save()

    # Independent light-atom probes all restart from the heavy checkpoint.
    for atom in ("O3", "O4", "O5", "O6"):
        refine_branch(atom.lower(), {atom: "X"})
    refine_branch("all_oxygen", {a: "X" for a in ("O3", "O4", "O5", "O6")})


if __name__ == "__main__":
    main()
