#!/usr/bin/env python3
"""Test isolated, physically motivated specimen-profile terms."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "texture_accepted.gpx"


def open_candidate(tag):
    output = ROOT / "analysis" / f"profile_{tag}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 12
    hist.clear_refinements({
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
    return project, hist, output


def finish(project, hist, output, kind, details):
    project.save()
    project.do_refinements([{}])
    project.save()
    row = {
        "file": output.name,
        "kind": kind,
        "rwp": hist.get_wR(),
        "details": details(project, hist),
        "fractions": hist.ComputeMassFracs(),
    }
    print("PROFILE " + json.dumps(row, default=str))


def roughness():
    project, hist, output = open_candidate("roughness")
    hist.SampleParameters["SurfRoughA"] = [0.1, True]
    hist.SampleParameters["SurfRoughB"] = [0.1, True]
    finish(project, hist, output, "roughness", lambda p, h: {
        "A": h.SampleParameters["SurfRoughA"],
        "B": h.SampleParameters["SurfRoughB"],
    })


def isotropic_strain(phase_name):
    tag = phase_name.replace("R3bar_", "").lower() + "_strain"
    project, hist, output = open_candidate(tag)
    phase = project.phase(phase_name)
    phase.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True}
    }, [hist])
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 1000.0
    finish(project, hist, output, "isotropic_strain", lambda p, h: {
        "phase": phase_name,
        "mustrain": p.phase(phase_name).data["Histograms"][h.name]["Mustrain"],
    })


def mnwo4_size():
    project, hist, output = open_candidate("mnwo4_size")
    phase = project.phase("MnWO4")
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 1.5, "refine": True}
    }, [hist])
    finish(project, hist, output, "isotropic_size", lambda p, h: {
        "phase": "MnWO4",
        "size": p.phase("MnWO4").data["Histograms"][h.name]["Size"],
    })


def uniaxial_strain(phase_name, axis):
    axis_tag = "".join(str(v) for v in axis)
    tag = phase_name.replace("R3bar_", "").lower() + f"_uniax_{axis_tag}"
    project, hist, output = open_candidate(tag)
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"][hist.name]
    start = hap["Mustrain"][1][0]
    phase.set_HAP_refinements({
        "Mustrain": {"type": "uniaxial", "direction": axis}
    }, [hist])
    hap["Mustrain"][2][0] = True
    hap["Mustrain"][2][1] = True
    hap["Mustrain"][1][0] = start
    hap["Mustrain"][1][1] = start
    finish(project, hist, output, "uniaxial_strain", lambda p, h: {
        "phase": phase_name,
        "axis": axis,
        "mustrain": p.phase(phase_name).data["Histograms"][h.name]["Mustrain"],
    })


def main():
    roughness()
    mnwo4_size()
    isotropic_strain("MnWO4")
    isotropic_strain("R3bar_Mn3WO6")
    for axis in ((1, 0, 0), (0, 1, 0), (0, 0, 1), (0, 1, 1)):
        uniaxial_strain("WO3", axis)
    uniaxial_strain("R3bar_Mn3WO6", (0, 0, 1))


if __name__ == "__main__":
    main()
