#!/usr/bin/env python3
"""Sequentially reconcile only accepted structural and profile parameters."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
INST = ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")


def freeze(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 12
    hist.clear_refinements({
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        "Instrument Parameters": list(INST),
    })
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
    return hist


def snapshot(project, label):
    hist = project.histogram(0)
    print("STAGE " + json.dumps({
        "label": label,
        "rwp": hist.get_wR(),
        "fractions": hist.ComputeMassFracs(),
        "shift": hist.SampleParameters["Shift"],
        "instrument": {key: hist.InstrumentParameters[key] for key in INST},
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "po": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
    }, default=str))


def run(source, output, label, activate):
    project = G2sc.G2Project(
        str(ROOT / "analysis" / source),
        newgpx=str(ROOT / "analysis" / output),
    )
    hist = freeze(project)
    activate(project, hist)
    project.save()
    project.do_refinements([{}])
    project.save()
    snapshot(project, label)
    return output


def set_size(phase_name):
    def activate(project, hist):
        hap = project.phase(phase_name).data["Histograms"][hist.name]
        hap["Size"][2][0] = True
    return activate


def set_wo3_strain(project, hist):
    flags = project.phase("WO3").data["Histograms"][hist.name]["Mustrain"][2]
    flags[0] = flags[1] = True


def set_geometry(project, hist):
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.phase("WO3").data["Histograms"][hist.name]["Pref.Ori."][2] = True


def set_instrument(key):
    def activate(project, hist):
        hist.set_refinements({"Instrument Parameters": [key]})
    return activate


def main():
    source = "profile_wo3_uniax_100.gpx"
    source = run(source, "accepted_mnwo4_size.gpx", "mnwo4_size", set_size("MnWO4"))
    source = run(source, "accepted_geometry.gpx", "geometry_texture", set_geometry)
    source = run(source, "accepted_mnwo4_size2.gpx", "mnwo4_size_2", set_size("MnWO4"))
    source = run(source, "accepted_wo3_size.gpx", "wo3_size", set_size("WO3"))
    source = run(source, "accepted_wo3_strain.gpx", "wo3_uniaxial_strain", set_wo3_strain)
    source = run(source, "accepted_mn3wo6_size.gpx", "mn3wo6_size", set_size("R3bar_Mn3WO6"))
    for key in ("W", "X", "U", "SH/L", "Polariz."):
        output = f"accepted_inst_{key.replace('/', '').replace('.', '').lower()}.gpx"
        source = run(source, output, f"instrument_{key}", set_instrument(key))
    source = run(source, "accepted_geometry2.gpx", "geometry_texture_2", set_geometry)
    source = run(source, "accepted_mnwo4_size3.gpx", "mnwo4_size_3", set_size("MnWO4"))
    source = run(source, "accepted_wo3_size2.gpx", "wo3_size_2", set_size("WO3"))
    source = run(source, "accepted_wo3_strain2.gpx", "wo3_uniaxial_strain_2", set_wo3_strain)
    run(source, "accepted_model.gpx", "mn3wo6_size_2", set_size("R3bar_Mn3WO6"))


if __name__ == "__main__":
    main()
