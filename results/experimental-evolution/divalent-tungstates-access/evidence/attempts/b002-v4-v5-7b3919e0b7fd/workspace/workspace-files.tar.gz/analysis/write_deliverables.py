#!/usr/bin/env python3
"""Write the final frozen GPX, phase CIFs, fit profile, and result JSON."""

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc

from analysis.reconcile_accepted import freeze


ROOT = Path(__file__).resolve().parents[1]
PHASE_INFO = {
    "MnWO4": {
        "name": "MnWO4",
        "formula": "MnWO4",
        "cif": "phase_1_MnWO4.cif",
        "model_origin": "COD 1520200, refined",
    },
    "WO3": {
        "name": "WO3",
        "formula": "WO3",
        "cif": "phase_2_WO3.cif",
        "model_origin": "COD 2311041, refined",
    },
    "R3bar_Mn3WO6": {
        "name": "Mn3WO6",
        "formula": "Mn3WO6",
        "cif": "phase_3_Mn3WO6.cif",
        "model_origin": "R-3 A3BO6 analogue topology (COD 2242674), Mn/W substituted and refined",
    },
}


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "fullgrid_best.gpx"),
        newgpx=str(ROOT / "final.gpx"),
    )
    hist = freeze(project)
    hist.data["Background"][0][1] = False
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = False
    project.save()

    fractions = hist.ComputeMassFracs()
    phase_rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        original_name = phase.name
        phase.name = info["name"]
        phase.export_CIF(str(ROOT / info["cif"]))
        phase.name = original_name
        fraction, fraction_esd = fractions[original_name]
        row = dict(info)
        row.update({
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(fraction_esd),
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cell": {key: float(value) for key, value in phase.get_cell().items()},
        })
        phase_rows.append(row)

    x, observed, weights, calculated, background, stored_difference = (
        np.asarray(values) for values in hist.data["data"][1]
    )
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        for values in zip(x, observed, calculated, difference):
            writer.writerow([
                f"{values[0]:.8f}", f"{values[1]:.8f}",
                f"{values[2]:.8f}", f"{values[3]:.8f}",
            ])

    residuals = hist.residuals
    rwp = float(residuals["wR"])
    rexp = float(residuals["wRmin"])
    result = {
        "phases": phase_rows,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": float(residuals["R"]),
            "R_expected_percent": rexp,
            "goodness_of_fit": rwp / rexp,
            "reduced_chi_squared": (rwp / rexp) ** 2,
            "R_background_percent": float(residuals["Rb"]),
            "weighted_R_background_percent": float(residuals["wRb"]),
            "number_of_points": int(len(x)),
            "two_theta_min_deg": float(x[0]),
            "two_theta_max_deg": float(x[-1]),
        },
        "project": "final.gpx",
        "fit_profile": "fit.csv",
        "weight_fraction_basis": "normalized over modeled crystalline phases",
    }
    with (ROOT / "result.json").open("w") as stream:
        json.dump(result, stream, indent=2)
        stream.write("\n")

    print(json.dumps({
        "rwp": rwp,
        "rexp": rexp,
        "gof": rwp / rexp,
        "fractions": fractions,
        "n_points": len(x),
        "max_stored_difference_error": float(np.max(np.abs(stored_difference - difference))),
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
