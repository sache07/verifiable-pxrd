#!/usr/bin/env python3
"""Test whether a candidate lattice accounts for residual reflection positions."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cif")
    parser.add_argument("name")
    parser.add_argument("output")
    parser.add_argument("--scale", type=float, default=0.15)
    parser.add_argument("--size", type=float, default=0.06)
    parser.add_argument("--refine-cell", action="store_true")
    parser.add_argument("--refine-size", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(ROOT / "analysis" / "initial_2phase.gpx"),
        newgpx=str(ROOT / "analysis" / args.output),
    )
    hist = project.histogram(0)
    hist.SampleParameters["Scale"][1] = False
    hist.clear_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"],
    })
    for old_phase in project.phases():
        old_phase.set_refinements({"Cell": False})

    phase = project.add_phase(
        str(ROOT / args.cif), phasename=args.name, histograms=[hist]
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [args.scale, False]
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": args.size, "refine": False},
    }, [hist])
    project.data["Controls"]["data"]["max cyc"] = 1
    project.save()
    project.do_refinements([{}])  # create the reflection list

    phase.set_refinements({"LeBail": True})
    project.data["Controls"]["data"]["max cyc"] = 12
    project.do_refinements([{}])
    if args.refine_cell:
        phase.set_refinements({"Cell": True})
        project.do_refinements([{}])
    if args.refine_size:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": args.size, "refine": True},
        }, [hist])
        project.do_refinements([{}])
    project.save()
    print("TEST_RESULT " + json.dumps({
        "name": args.name,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "cell": phase.get_cell(),
        "size": hap["Size"][1][0],
        "sum_intensity": hist.residuals.get(f"{phase.id}:0:sumInt"),
    }, default=str))


if __name__ == "__main__":
    main()
