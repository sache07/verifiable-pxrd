#!/usr/bin/env python3
"""Reconcile lattice/zero displacement after selecting fixed phase Uiso values."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "uiso_best.gpx"),
        newgpx=str(ROOT / "analysis" / "uiso_cells.gpx"),
    )
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 12
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
    project.save()
    project.do_refinements([{}])
    project.save()
    print(json.dumps({
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "shift_um": hist.SampleParameters["Shift"][0],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
