#!/usr/bin/env python3
"""Coordinate-descent search for one physical isotropic U value per phase."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
GRID = (0.003, 0.005, 0.007, 0.010, 0.014, 0.018, 0.020)


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    project.data["Controls"]["data"]["max cyc"] = 12


def set_phase_uiso(phase, value):
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(value)


def evaluate(source, output, phase_name=None, value=None, normalize=False):
    project = G2sc.G2Project(str(ROOT / "analysis" / source),
                            newgpx=str(ROOT / "analysis" / output))
    prepare(project)
    if normalize:
        for phase in project.phases():
            set_phase_uiso(phase, 0.005)
    elif phase_name is not None:
        set_phase_uiso(project.phase(phase_name), value)
    project.save()
    project.do_refinements([{}])
    project.save()
    hist = project.histogram(0)
    return {
        "file": output,
        "phase": phase_name,
        "uiso": value,
        "rwp": hist.get_wR(),
        "fractions": hist.ComputeMassFracs(),
    }


def main():
    initial = evaluate(
        "reprofile_wo3_strain.gpx", "uiso_normalized.gpx", normalize=True
    )
    print("CANDIDATE " + json.dumps(initial, default=str))
    source = initial["file"]
    for phase_name in ("MnWO4", "WO3", "R3bar_Mn3WO6"):
        candidates = []
        for value in GRID:
            tag = phase_name.replace("R3bar_", "").lower()
            output = f"uiso_{tag}_{int(round(value * 1000)):03d}.gpx"
            result = evaluate(source, output, phase_name, value)
            candidates.append(result)
            print("CANDIDATE " + json.dumps(result, default=str))
        best = min(candidates, key=lambda row: row["rwp"])
        source = best["file"]
        print("SELECTED " + json.dumps(best, default=str))
    final = G2sc.G2Project(str(ROOT / "analysis" / source),
                          newgpx=str(ROOT / "analysis" / "uiso_best.gpx"))
    final.save()


if __name__ == "__main__":
    main()
