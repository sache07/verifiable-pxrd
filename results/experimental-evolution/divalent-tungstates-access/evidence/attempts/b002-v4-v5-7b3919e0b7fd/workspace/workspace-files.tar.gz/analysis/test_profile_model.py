#!/usr/bin/env python3
"""Fit phase sizes/strains with a bounded, fixed physical instrument start."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def report(project, label):
    hist = project.histogram(0)
    print("SNAPSHOT " + json.dumps({
        "label": label,
        "rwp": hist.get_wR(),
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1},
        "shift": hist.SampleParameters["Shift"],
        "phases": {
            p.name: {
                "cell": p.get_cell(),
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            } for p in project.phases()
        },
    }, default=str))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output")
    parser.add_argument("--u", type=float, default=10.0)
    parser.add_argument("--w", type=float, default=10.0)
    parser.add_argument("--x", type=float, default=1.0)
    parser.add_argument("--strain", action="store_true")
    args = parser.parse_args()

    project = G2sc.G2Project(
        str(ROOT / "analysis" / "test_r3_mn3wo6.gpx"),
        newgpx=str(ROOT / "analysis" / args.output),
    )
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 12
    for key, value in {
        "U": args.u, "V": 0.0, "W": args.w, "X": args.x, "SH/L": 0.02
    }.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False
    hist.set_refinements({"Sample Parameters": ["Shift"]})

    starts = {"MnWO4": 0.25, "WO3": 0.20, "R3bar_Mn3WO6": 0.05}
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        phase.set_HAP_refinements({
            "Size": {
                "type": "isotropic", "value": starts[phase.name], "refine": True
            }
        }, [hist])
    project.save()
    project.do_refinements([{}])
    report(project, "sizes")

    if args.strain:
        for phase in project.phases():
            phase.set_HAP_refinements({
                "Mustrain": {"type": "isotropic", "value": 1000.0, "refine": True}
            }, [hist])
        project.do_refinements([{}])
        report(project, "sizes_strain")
    project.save()


if __name__ == "__main__":
    main()
