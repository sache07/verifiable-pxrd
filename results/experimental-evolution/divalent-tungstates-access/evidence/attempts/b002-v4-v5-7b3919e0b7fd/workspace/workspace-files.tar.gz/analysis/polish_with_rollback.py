#!/usr/bin/env python3
"""Polish accepted parameters, retaining a stage only when Rwp improves."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from analysis.reconcile_accepted import (
    run,
    set_geometry,
    set_instrument,
    set_size,
    set_wo3_strain,
)


ROOT = Path(__file__).resolve().parents[1]


def rwp(filename):
    return G2sc.G2Project(str(ROOT / "analysis" / filename)).histogram(0).get_wR()


def accepted_stage(source, output, label, action):
    before = rwp(source)
    run(source, output, label, action)
    candidate = G2sc.G2Project(str(ROOT / "analysis" / output))
    hist = candidate.histogram(0)
    after = hist.get_wR()
    inst = hist.InstrumentParameters
    physical = (
        0.0 <= inst["U"][1] <= 40.0
        and 2.0 <= inst["W"][1] <= 40.0
        and 0.1 <= inst["X"][1] <= 6.0
        and 0.005 <= inst["SH/L"][1] <= 0.10
        and 0.5 <= inst["Polariz."][1] <= 1.0
        and abs(hist.SampleParameters["Shift"][0]) <= 800.0
    )
    for phase in candidate.phases():
        hap = phase.data["Histograms"][hist.name]
        physical = physical and 0.04 <= hap["Size"][1][0] <= 1.5
        physical = physical and 0.7 <= hap["Pref.Ori."][1] <= 1.4
        if phase.name == "WO3":
            physical = physical and all(300.0 <= value <= 8000.0
                                        for value in hap["Mustrain"][1][:2])
    accepted = after <= before + 1e-8 and physical
    print("DECISION " + json.dumps({
        "label": label, "source": source, "candidate": output,
        "rwp_before": before, "rwp_after": after,
        "physical": bool(physical), "accepted": bool(accepted),
    }))
    return output if accepted else source


def main():
    source = "iter2_w.gpx"
    stages = [
        ("rb_u1.gpx", "U_1", set_instrument("U")),
        ("rb_shl1.gpx", "SHL_1", set_instrument("SH/L")),
        ("rb_geo1.gpx", "geometry_1", set_geometry),
        ("rb_mnsize1.gpx", "MnWO4_size_1", set_size("MnWO4")),
        ("rb_wosize1.gpx", "WO3_size_1", set_size("WO3")),
        ("rb_wostrain1.gpx", "WO3_strain_1", set_wo3_strain),
        ("rb_mn3size1.gpx", "Mn3WO6_size_1", set_size("R3bar_Mn3WO6")),
        ("rb_pol1.gpx", "polarization_1", set_instrument("Polariz.")),
        ("rb_geo2.gpx", "geometry_2", set_geometry),
        ("rb_w2.gpx", "W_2", set_instrument("W")),
        ("rb_u2.gpx", "U_2", set_instrument("U")),
        ("rb_shl2.gpx", "SHL_2", set_instrument("SH/L")),
        ("rb_geo3.gpx", "geometry_3", set_geometry),
        ("rb_mnsize2.gpx", "MnWO4_size_2", set_size("MnWO4")),
        ("rb_wosize2.gpx", "WO3_size_2", set_size("WO3")),
        ("rb_wostrain2.gpx", "WO3_strain_2", set_wo3_strain),
        ("rb_mn3size2.gpx", "Mn3WO6_size_2", set_size("R3bar_Mn3WO6")),
        ("rb_pol2.gpx", "polarization_2", set_instrument("Polariz.")),
        ("rb_geo4.gpx", "geometry_4", set_geometry),
    ]
    for output, label, action in stages:
        source = accepted_stage(source, output, label, action)
    final = G2sc.G2Project(
        str(ROOT / "analysis" / source),
        newgpx=str(ROOT / "analysis" / "rollback_model.gpx"),
    )
    final.save()
    hist = final.histogram(0)
    print("FINAL " + json.dumps({
        "source": source,
        "rwp": hist.get_wR(),
        "fractions": hist.ComputeMassFracs(),
        "instrument": {key: value[1] for key, value in hist.InstrumentParameters.items()
                       if key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "shift": hist.SampleParameters["Shift"][0],
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"][1][0],
                "strain": phase.data["Histograms"][hist.name]["Mustrain"][:4],
                "po": phase.data["Histograms"][hist.name]["Pref.Ori."][:4],
            }
            for phase in final.phases()
        },
    }, default=str))


if __name__ == "__main__":
    main()
