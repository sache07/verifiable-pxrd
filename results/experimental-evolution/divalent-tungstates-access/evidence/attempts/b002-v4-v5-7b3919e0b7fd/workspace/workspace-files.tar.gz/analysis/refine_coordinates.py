#!/usr/bin/env python3
"""Refine cation then oxygen coordinates with profile terms held physical."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    project.phase("MnWO4").data["Histograms"][hist.name]["Size"][1][0] = 1.5
    project.data["Controls"]["data"]["max cyc"] = 12


def run_stage(source, output, label, select):
    project = G2sc.G2Project(str(ROOT / "analysis" / source),
                            newgpx=str(ROOT / "analysis" / output))
    prepare(project)
    for phase in project.phases():
        flags = {}
        for atom in phase.atoms():
            if select(phase.name, atom.element):
                flags[atom.label] = "X"
        if flags:
            phase.set_refinements({"Atoms": flags})
    project.save()
    project.do_refinements([{}])
    project.save()
    hist = project.histogram(0)
    print("SNAPSHOT " + json.dumps({
        "label": label,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "coordinates": {
            phase.name: {
                atom.label: {
                    "element": atom.element,
                    "xyz": atom.coordinates,
                    "flag": atom.refinement_flags,
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }, default=str))


def main():
    run_stage(
        "profile_u10w20.bak0.gpx", "coord_heavy.gpx", "heavy",
        lambda phase, element: element != "O",
    )
    run_stage(
        "coord_heavy.gpx", "coord_mnwo4_o.gpx", "mnwo4_oxygen",
        lambda phase, element: phase == "MnWO4" and element == "O",
    )
    run_stage(
        "coord_mnwo4_o.gpx", "coord_hidden_o.gpx", "mn3wo6_oxygen",
        lambda phase, element: phase == "R3bar_Mn3WO6" and element == "O",
    )
    run_stage(
        "coord_hidden_o.gpx", "coord_all.gpx", "wo3_oxygen",
        lambda phase, element: phase == "WO3" and element == "O",
    )


if __name__ == "__main__":
    main()
