#!/usr/bin/env python3
"""Test a physically screened scheelite MnWO4 analogue against the residual."""

from pathlib import Path
import json
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def show(project, label):
    hist = project.histogram(0)
    print(json.dumps({
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "haps": {
            p.name: {
                "scale": p.data["Histograms"][hist.name]["Scale"][0],
                "size": p.data["Histograms"][hist.name]["Size"],
            } for p in project.phases()
        },
    }, indent=2, default=str))


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "initial_2phase.gpx"),
        newgpx=str(ROOT / "analysis" / "scheelite_branch.gpx"),
    )
    hist = project.histogram(0)
    hist.SampleParameters["Scale"][1] = False
    hist.clear_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": False})

    phase = project.add_phase(
        str(ROOT / "analysis" / "candidates" / "scheelite_MnWO4.cif"),
        phasename="scheelite-MnWO4",
        histograms=[hist],
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][0] = 1.0
    phase.set_HAP_refinements({
        "Scale": True,
        "Size": {"type": "isotropic", "value": 0.05, "refine": False},
    }, [hist])
    project.save()
    project.do_refinements([{}])
    show(project, "scale")

    phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    show(project, "cell")

    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": 0.05, "refine": True}
    }, [hist])
    project.do_refinements([{}])
    show(project, "size")
    project.save()


if __name__ == "__main__":
    main()
