#!/usr/bin/env python3
"""Test one analogue-derived Mn-W-O phase against the two-phase checkpoint."""

import argparse
import json
from pathlib import Path
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("cif")
    parser.add_argument("name")
    parser.add_argument("output")
    parser.add_argument("--size", type=float, default=0.05)
    args = parser.parse_args()
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "initial_2phase.gpx"),
        newgpx=str(ROOT / "analysis" / args.output),
    )
    hist = project.histogram(0)
    hist.SampleParameters["Scale"][1] = False
    hist.clear_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"],
    })
    for old_phase in project.phases():
        old_phase.set_refinements({"Cell": False})

    phase = project.add_phase(
        str(ROOT / args.cif), phasename=args.name, histograms=[hist]
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"][0] = 0.5
    phase.set_HAP_refinements({
        "Scale": True,
        "Size": {"type": "isotropic", "value": args.size, "refine": False},
    }, [hist])
    project.save()
    project.do_refinements([{}])
    phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "value": args.size, "refine": True},
    }, [hist])
    project.do_refinements([{}])
    project.save()

    print("TEST_RESULT " + json.dumps({
        "name": args.name,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "candidate_cell": phase.get_cell(),
        "candidate_scale": hap["Scale"][0],
        "candidate_size": hap["Size"][1][0],
    }, default=str))


if __name__ == "__main__":
    main()
