#!/usr/bin/env python3
"""Reconcile the accepted WO3 [011] texture with cells and displacement."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "texture_wo3_011.gpx"),
        newgpx=str(ROOT / "analysis" / "texture_accepted.gpx"),
    )
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 12
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    hist.clear_refinements({
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": True, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = phase.name == "WO3"
    project.save()
    project.do_refinements([{}])
    project.save()
    print(json.dumps({
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "fractions": hist.ComputeMassFracs(),
        "shift_um": hist.SampleParameters["Shift"][0],
        "wo3_texture": project.phase("WO3").data["Histograms"][hist.name]["Pref.Ori."],
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }, indent=2, default=str))


if __name__ == "__main__":
    main()
