#!/usr/bin/env python3
"""Screen a small set of low-index March-Dollase axes one phase at a time."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "uiso_cells.gpx"
AXES = {
    "MnWO4": ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)),
    "WO3": ((1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1)),
    "R3bar_Mn3WO6": ((0, 0, 1), (1, 0, 0), (1, 1, 0), (1, 0, 1), (1, 0, 2)),
}


def prepare(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 12
    hist.clear_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
    return hist


def evaluate(phase_name, axis):
    axis_tag = "".join(str(v) for v in axis)
    output = ROOT / "analysis" / f"texture_{phase_name.lower()}_{axis_tag}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    hist = prepare(project)
    po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
    po[3] = list(axis)
    po[2] = True
    project.save()
    project.do_refinements([{}])
    project.save()
    po = project.phase(phase_name).data["Histograms"][hist.name]["Pref.Ori."]
    return {
        "file": output.name,
        "phase": phase_name,
        "axis": axis,
        "ratio": po[1],
        "rwp": hist.get_wR(),
        "fractions": hist.ComputeMassFracs(),
    }


def main():
    rows = []
    for phase_name, axes in AXES.items():
        for axis in axes:
            row = evaluate(phase_name, axis)
            rows.append(row)
            print("TEXTURE " + json.dumps(row, default=str))
    physical = [row for row in rows if 0.7 <= row["ratio"] <= 1.4]
    print("BEST " + json.dumps(min(physical, key=lambda row: row["rwp"]), default=str))


if __name__ == "__main__":
    main()
