#!/usr/bin/env python3
"""Final local coordinate-descent scan of one isotropic U value per phase."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
GRIDS = {
    "MnWO4": (0.003, 0.004, 0.005, 0.006, 0.007),
    "WO3": (0.004, 0.0055, 0.007, 0.0085, 0.010),
    "R3bar_Mn3WO6": (0.010, 0.012, 0.014, 0.016, 0.018),
}


def freeze(project):
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 12
    hist.clear_refinements({
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
    return hist


def set_uiso(phase, value):
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(value)


def evaluate(source, phase_name, value):
    tag = phase_name.replace("R3bar_", "").lower()
    output = f"final_u_{tag}_{int(round(value * 10000)):04d}.gpx"
    project = G2sc.G2Project(
        str(ROOT / "analysis" / source),
        newgpx=str(ROOT / "analysis" / output),
    )
    hist = freeze(project)
    set_uiso(project.phase(phase_name), value)
    project.save()
    project.do_refinements([{}])
    project.save()
    return {
        "file": output,
        "phase": phase_name,
        "uiso": value,
        "rwp": hist.get_wR(),
        "fractions": hist.ComputeMassFracs(),
    }


def main():
    source = "accepted_model.gpx"
    for phase_name, grid in GRIDS.items():
        rows = []
        for value in grid:
            row = evaluate(source, phase_name, value)
            rows.append(row)
            print("UISO " + json.dumps(row, default=str))
        best = min(rows, key=lambda row: row["rwp"])
        source = best["file"]
        print("SELECTED " + json.dumps(best, default=str))
    project = G2sc.G2Project(
        str(ROOT / "analysis" / source),
        newgpx=str(ROOT / "analysis" / "final_u_best.gpx"),
    )
    project.save()


if __name__ == "__main__":
    main()
