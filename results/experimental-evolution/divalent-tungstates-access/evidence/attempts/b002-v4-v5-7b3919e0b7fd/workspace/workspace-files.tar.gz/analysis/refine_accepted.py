#!/usr/bin/env python3
"""Refine calibration and common profile for the accepted three-phase model."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(project, label):
    hist = project.histogram(0)
    print("SNAPSHOT " + json.dumps({
        "label": label,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": hist.SampleParameters,
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
    }, default=str))


def refine(project, label):
    project.do_refinements([{}])
    snapshot(project, label)
    project.save()


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "test_r3_mn3wo6.gpx"),
        newgpx=str(ROOT / "analysis" / "refined_positions.gpx"),
    )
    hist = project.histogram(0)
    project.data["Controls"]["data"]["max cyc"] = 12

    # Reinitialize the profile to the physically allowed generator convention.
    # V is fixed at zero; U, W and X carry the Gaussian/Lorentzian widths.
    for key, value in {"U": 10.0, "V": 0.0, "W": 20.0, "X": 1.0, "SH/L": 0.02}.items():
        hist.InstrumentParameters[key][1] = value
        hist.InstrumentParameters[key][2] = False

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, "cells_shift")

    hist.set_refinements({"Instrument Parameters": ["W", "X"]})
    refine(project, "profile_wx")

    hist.set_refinements({"Instrument Parameters": ["U"]})
    refine(project, "profile_uwx")

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, "profile_shl")

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization")


if __name__ == "__main__":
    main()
