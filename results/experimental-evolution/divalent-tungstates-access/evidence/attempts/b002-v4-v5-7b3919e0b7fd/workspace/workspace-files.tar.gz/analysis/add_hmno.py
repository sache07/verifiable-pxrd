#!/usr/bin/env python3
"""Add the broadened hexagonal MnO residual phase to the two-phase model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
MNO = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/4/11/79/4117966.cif"
)


def report(project, label):
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "label": label,
                "residuals": hist.residuals,
                "mass_fractions": hist.ComputeMassFracs(),
                "phases": {
                    phase.name: {
                        "cell": phase.get_cell(),
                        "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                        "size": phase.data["Histograms"][hist.name]["Size"],
                    }
                    for phase in project.phases()
                },
            },
            indent=2,
            default=str,
        )
    )


def main():
    project = G2sc.G2Project(
        str(ROOT / "analysis" / "initial_2phase.gpx"),
        newgpx=str(ROOT / "analysis" / "three_phase.gpx"),
    )
    hist = project.histogram(0)
    # The absolute specimen scale is redundant with all phase scales.
    hist.SampleParameters["Scale"][1] = False

    # Freeze established position/profile parameters while the new phase scale
    # is introduced.
    hist.clear_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L"],
        }
    )
    for phase in project.phases():
        phase.set_refinements({"Cell": False})

    mno = project.add_phase(str(MNO), phasename="h-MnO", histograms=[hist])
    mno_hap = mno.data["Histograms"][hist.name]
    mno_hap["Scale"][0] = 1.0
    mno.set_HAP_refinements(
        {"Scale": True, "Size": {"type": "isotropic", "value": 0.05, "refine": False}},
        [hist],
    )
    project.save()
    project.do_refinements([{}])
    report(project, "scale")

    mno.set_refinements({"Cell": True})
    project.do_refinements([{}])
    report(project, "cell")

    mno.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 0.05, "refine": True}}, [hist]
    )
    project.do_refinements([{}])
    report(project, "size")
    project.save()


if __name__ == "__main__":
    main()
