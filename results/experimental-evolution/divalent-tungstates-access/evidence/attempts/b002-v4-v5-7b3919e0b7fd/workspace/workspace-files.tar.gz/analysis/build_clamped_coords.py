#!/usr/bin/env python3
"""Project unbounded coordinate directions onto modest Cartesian displacement balls."""

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def frac_distance(delta, cell):
    a, b, c = (cell["length_a"], cell["length_b"], cell["length_c"])
    al, be, ga = np.radians([
        cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]
    ])
    metric = np.array([
        [a * a, a * b * np.cos(ga), a * c * np.cos(be)],
        [a * b * np.cos(ga), b * b, b * c * np.cos(al)],
        [a * c * np.cos(be), b * c * np.cos(al), c * c],
    ])
    return float(np.sqrt(delta @ metric @ delta))


def prepare(project):
    hist = project.histogram(0)
    hist.clear_refinements({
        "Sample Parameters": ["Shift"],
        "Instrument Parameters": ["U", "V", "W", "X", "Y", "SH/L", "Polariz."],
    })
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    project.phase("MnWO4").data["Histograms"][hist.name]["Size"][1][0] = 1.5
    project.data["Controls"]["data"]["max cyc"] = 12


def target_project(phase_name, element, targets):
    if element != "O":
        return targets["heavy"]
    if phase_name == "MnWO4":
        return targets["mnwo4_o"]
    if phase_name == "R3bar_Mn3WO6":
        return targets["hidden_o"]
    return targets["wo3_o"]


def main():
    targets = {
        "heavy": G2sc.G2Project(str(ROOT / "analysis" / "coord_heavy.gpx")),
        "mnwo4_o": G2sc.G2Project(str(ROOT / "analysis" / "coord_mnwo4_o.gpx")),
        "hidden_o": G2sc.G2Project(str(ROOT / "analysis" / "coord_hidden_o.gpx")),
        "wo3_o": G2sc.G2Project(str(ROOT / "analysis" / "coord_all.gpx")),
    }
    for cap in (0.04, 0.06, 0.08, 0.10, 0.15):
        tag = f"{int(round(cap * 100)):02d}"
        project = G2sc.G2Project(
            str(ROOT / "analysis" / "profile_u10w20.bak0.gpx"),
            newgpx=str(ROOT / "analysis" / f"coord_clamp_{tag}.gpx"),
        )
        prepare(project)
        applied = {}
        for phase in project.phases():
            applied[phase.name] = {}
            cell = phase.get_cell()
            for atom in phase.atoms():
                target = target_project(phase.name, atom.element, targets)
                other = target.phase(phase.name).atom(atom.label)
                start = np.array(atom.coordinates, dtype=float)
                delta = np.array(other.coordinates, dtype=float) - start
                delta -= np.round(delta)
                distance = frac_distance(delta, cell)
                factor = min(1.0, cap / distance) if distance > 0 else 1.0
                atom.coordinates = start + factor * delta
                applied[phase.name][atom.label] = {
                    "target_displacement_A": distance,
                    "applied_displacement_A": distance * factor,
                }
        project.save()
        project.do_refinements([{}])
        project.save()
        hist = project.histogram(0)
        print("SNAPSHOT " + json.dumps({
            "cap_A": cap,
            "rwp": hist.get_wR(),
            "residuals": hist.residuals,
            "mass_fractions": hist.ComputeMassFracs(),
            "applied": applied,
        }, default=str))


if __name__ == "__main__":
    main()
