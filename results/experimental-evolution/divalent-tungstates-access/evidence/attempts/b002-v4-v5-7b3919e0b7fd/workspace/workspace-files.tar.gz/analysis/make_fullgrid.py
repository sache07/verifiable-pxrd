#!/usr/bin/env python3
"""Expand to the complete measured grid and polish the accepted model once."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc

from analysis.polish_with_rollback import accepted_stage, rwp
from analysis.reconcile_accepted import (
    freeze,
    set_geometry,
    set_instrument,
    set_size,
    set_wo3_strain,
)


ROOT = Path(__file__).resolve().parents[1]


def main():
    base = G2sc.G2Project(
        str(ROOT / "analysis" / "converged_finalrange.gpx"),
        newgpx=str(ROOT / "analysis" / "fullgrid_base.gpx"),
    )
    hist = freeze(base)
    x = hist.data["data"][1][0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    base.save()
    base.do_refinements([{}])
    base.save()
    print("FULLGRID_BASE " + json.dumps({
        "rwp": hist.get_wR(), "limits": hist.data["Limits"],
        "n_points": len(x), "fractions": hist.ComputeMassFracs(),
    }, default=str))

    source = "fullgrid_base.gpx"
    stages = [
        ("fg_geo1.gpx", "fullgrid_geometry_1", set_geometry),
        ("fg_w.gpx", "fullgrid_W", set_instrument("W")),
        ("fg_u.gpx", "fullgrid_U", set_instrument("U")),
        ("fg_shl.gpx", "fullgrid_SHL", set_instrument("SH/L")),
        ("fg_geo2.gpx", "fullgrid_geometry_2", set_geometry),
        ("fg_wosize.gpx", "fullgrid_WO3_size", set_size("WO3")),
        ("fg_wostrain.gpx", "fullgrid_WO3_strain", set_wo3_strain),
        ("fg_mn3size.gpx", "fullgrid_Mn3WO6_size", set_size("R3bar_Mn3WO6")),
        ("fg_geo3.gpx", "fullgrid_geometry_3", set_geometry),
    ]
    for output, label, action in stages:
        source = accepted_stage(source, output, label, action)

    final = G2sc.G2Project(
        str(ROOT / "analysis" / source),
        newgpx=str(ROOT / "analysis" / "fullgrid_best.gpx"),
    )
    final.save()
    hist = final.histogram(0)
    print("FULLGRID_FINAL " + json.dumps({
        "source": source, "rwp": rwp(source),
        "limits": hist.data["Limits"], "fractions": hist.ComputeMassFracs(),
        "residuals": hist.residuals,
    }, default=str))


if __name__ == "__main__":
    main()
