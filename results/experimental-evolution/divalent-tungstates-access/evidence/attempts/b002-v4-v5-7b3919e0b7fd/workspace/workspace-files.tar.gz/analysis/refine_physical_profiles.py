#!/usr/bin/env python3
"""Add only supported specimen/profile complexity to the physical model."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]


def snapshot(project, label):
    hist = project.histogram(0)
    print("SNAPSHOT " + json.dumps({
        "label": label,
        "rwp": hist.get_wR(),
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1},
        "sample": hist.SampleParameters,
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "po": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
    }, default=str))


def open_stage(source, output):
    project = G2sc.G2Project(str(ROOT / "analysis" / source),
                            newgpx=str(ROOT / "analysis" / output))
    project.data["Controls"]["data"]["max cyc"] = 12
    for phase in project.phases():
        phase.set_refinements({"Atoms": {"all": " "}})
    return project


def run(project, label):
    project.save()
    project.do_refinements([{}])
    project.save()
    snapshot(project, label)


def main():
    project = open_stage("coord_clamp_08.gpx", "physical_sizes.gpx")
    hist = project.histogram(0)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        refine_size = phase.name != "MnWO4"
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": hap["Size"][1][0],
                     "refine": refine_size}
        }, [hist])
    project.phase("MnWO4").data["Histograms"][hist.name]["Size"][1][0] = 1.5
    run(project, "sizes_cells_shift")

    project = open_stage("physical_sizes.gpx", "physical_wo3_strain.gpx")
    hist = project.histogram(0)
    wo3 = project.phase("WO3")
    wo3.set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "value": 5000.0, "refine": True}
    }, [hist])
    run(project, "wo3_strain")

    project = open_stage("physical_wo3_strain.gpx", "physical_polarization.gpx")
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(project, "polarization")

    project = open_stage("physical_polarization.gpx", "physical_shl.gpx")
    hist = project.histogram(0)
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    run(project, "shl_test")


if __name__ == "__main__":
    main()
