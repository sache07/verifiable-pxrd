#!/usr/bin/env python3
"""Build and refine the initial MnWO4 + WO3 GSAS-II model."""

from pathlib import Path
import json

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
REF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cod_path(cod_id: str) -> Path:
    return REF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project, label: str) -> None:
    hist = project.histogram(0)
    values = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: value[1]
            for key, value in hist.InstrumentParameters.items()
            if isinstance(value, list) and len(value) > 1
        },
        "sample": hist.SampleParameters,
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        values["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    print(json.dumps(values, indent=2, default=str))


def main() -> None:
    out = ROOT / "analysis" / "initial_2phase.gpx"
    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "analysis" / "cu_ka.instprm"),
        fmthint="comma/tab/semicolon",
    )
    mnwo4 = project.add_phase(
        str(cod_path("1520200")), phasename="MnWO4", histograms=[hist]
    )
    wo3 = project.add_phase(
        str(cod_path("2311041")), phasename="WO3", histograms=[hist]
    )

    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "refine": True,
                "no. coeffs": 12,
                "coeffs": [1300.0] + [0.0] * 11,
            },
        }
    )
    for phase in (mnwo4, wo3):
        phase.set_HAP_refinements({"Scale": True}, [hist])

    project.data["Controls"]["data"]["max cyc"] = 12
    project.save()
    project.do_refinements([{}])
    snapshot(project, "scale_background")

    # The common angular offset is predominantly specimen displacement in this
    # Bragg-Brentano scan. Refine it before changing the cells.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.do_refinements([{}])
    snapshot(project, "shift")

    for phase in (mnwo4, wo3):
        phase.set_refinements({"Cell": True})
    project.do_refinements([{}])
    snapshot(project, "cells")

    # Start with the stable Gaussian instrumental terms; phase broadening is
    # tested only after the position model is established.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W"]})
    project.do_refinements([{}])
    snapshot(project, "instrument_uvw")

    project.save()


if __name__ == "__main__":
    main()
