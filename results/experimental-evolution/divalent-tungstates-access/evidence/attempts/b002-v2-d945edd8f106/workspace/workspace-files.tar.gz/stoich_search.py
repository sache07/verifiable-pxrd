#!/usr/bin/env python
"""Search plausible Mn-W-O stoichiometries by cross-chemistry prototype transfer."""

from __future__ import annotations

import gzip
import json
import warnings
from collections import defaultdict
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy.ndimage import gaussian_filter1d


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02")
L1, L2 = 1.540598, 1.544426
TARGETS = {
    "MnWO4": (1, 1, 4),
    "Mn2WO5": (2, 1, 5),
    "Mn3WO6": (3, 1, 6),
    "Mn2WO6": (2, 1, 6),
    "MnW2O7": (1, 2, 7),
    "Mn3W2O9": (3, 2, 9),
    "MnWO5": (1, 1, 5),
    "MnW2O8": (1, 2, 8),
}


def cif_path(cod_id: str) -> Path:
    return RESOURCE / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def reduced_signature(formula: str) -> tuple[list[tuple[str, float]], float] | None:
    try:
        comp = Composition(formula).reduced_composition
    except Exception:
        return None
    oxygen = float(comp.get_el_amt_dict().get("O", 0))
    cations = sorted((str(element), float(amount)) for element, amount in comp.items() if str(element) != "O")
    if len(cations) != 2:
        return None
    return cations, oxygen


def assignments(cations: list[tuple[str, float]], target: tuple[int, int, int]) -> list[dict[str, str]]:
    mn, w, _ = target
    amounts = [value for _, value in cations]
    names = [name for name, _ in cations]
    if sorted(amounts) != sorted([float(mn), float(w)]):
        return []
    if mn != w:
        mn_name = names[amounts.index(float(mn))]
        w_name = names[amounts.index(float(w))]
        return [{mn_name: "Mn", w_name: "W"}]
    return [{names[0]: "Mn", names[1]: "W"}, {names[0]: "W", names[1]: "Mn"}]


def scaled_angles(base: np.ndarray, scale: float, wavelength: float) -> np.ndarray:
    d = L1 / (2 * np.sin(np.deg2rad(base / 2)))
    arg = wavelength / (2 * d * scale)
    out = np.full_like(arg, np.nan)
    valid = arg < 1
    out[valid] = 2 * np.rad2deg(np.arcsin(arg[valid]))
    return out


def main() -> None:
    data = np.loadtxt(ROOT / "trials" / "combo_add_MnO2_rutile" / "profile.csv", delimiter=",", skiprows=1)
    x, obs, _, residual, _ = data.T
    step = float(np.median(np.diff(x)))
    weight = 1 / np.maximum(obs, 1)
    smoothed = gaussian_filter1d(residual, 0.08 / step)
    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)
    calc = XRDCalculator(wavelength=L1)
    warnings.simplefilter("ignore")
    found: dict[str, list[dict]] = defaultdict(list)
    seen = set()
    for system, rows in index.items():
        elements = system.split("-")
        if len(elements) != 3 or "O" not in elements:
            continue
        for formula, cod_id, sg, quality in rows:
            signature = reduced_signature(formula)
            if signature is None:
                continue
            cations, oxygen = signature
            for target_name, target in TARGETS.items():
                if abs(oxygen - target[2]) > 1e-6:
                    continue
                for replacement in assignments(cations, target):
                    key = (target_name, cod_id, tuple(sorted(replacement.items())))
                    if key in seen:
                        continue
                    seen.add(key)
                    try:
                        structure = Structure.from_file(cif_path(cod_id), primitive=False)
                        if len(structure) > 160:
                            continue
                        structure.remove_oxidation_states()
                        structure.replace_species(replacement)
                        reduced, factor = structure.composition.get_reduced_composition_and_factor()
                        expected = Composition({"Mn": target[0], "W": target[1], "O": target[2]}).reduced_composition
                        if not reduced.almost_equals(expected, rtol=0, atol=1e-4):
                            continue
                        pattern = calc.get_pattern(structure, two_theta_range=(7, 120))
                    except Exception:
                        continue
                    base_angles = np.asarray(pattern.x, float)
                    intensities = np.asarray(pattern.y, float)
                    keep = intensities >= 0.4
                    base_angles, intensities = base_angles[keep], intensities[keep]
                    molecular_mass = float(expected.weight)
                    best = (-np.inf, None, None, None)
                    for scale in np.linspace(0.90, 1.10, 101):
                        volume_per_formula = structure.volume * scale**3 / float(factor)
                        density = molecular_mass * 1.66053906660 / volume_per_formula
                        if not 3.0 <= density <= 10.0:
                            continue
                        angles = scaled_angles(base_angles, scale, L1)
                        valid = np.isfinite(angles) & (angles >= x[0]) & (angles <= x[-1])
                        if valid.sum() < 5:
                            continue
                        values = np.interp(angles[valid], x, smoothed)
                        line_score = float(np.dot(intensities[valid], values) / np.sqrt(np.dot(intensities[valid], intensities[valid])))
                        if line_score > best[0]:
                            best = (line_score, scale, density, volume_per_formula)
                    if best[1] is None:
                        continue
                    found[target_name].append(
                        {
                            "target": target_name,
                            "cod_id": cod_id,
                            "formula": formula,
                            "space_group_number": sg,
                            "quality": quality,
                            "replacement": replacement,
                            "atoms": len(structure),
                            "parent_cell": list(structure.lattice.parameters),
                            "formula_factor": float(factor),
                            "line_score": best[0],
                            "scale": best[1],
                            "density": best[2],
                            "volume_per_formula": best[3],
                            "base_angles": base_angles,
                            "intensities": intensities,
                        }
                    )

    # Full-profile score for each stoichiometry's strongest line matches.
    output: dict[str, list[dict]] = {}
    for target_name, rows in found.items():
        rows.sort(key=lambda row: row["line_score"], reverse=True)
        for row in rows[:60]:
            best = (-np.inf, None, None)
            for scale in np.linspace(max(0.88, row["scale"] - 0.02), min(1.12, row["scale"] + 0.02), 41):
                sticks = np.zeros_like(x)
                for wavelength, ratio in ((L1, 1.0), (L2, 0.5)):
                    aa = scaled_angles(row["base_angles"], scale, wavelength)
                    valid = np.isfinite(aa) & (aa >= x[0]) & (aa <= x[-1])
                    pos = (aa[valid] - x[0]) / step
                    low = np.floor(pos).astype(int)
                    frac = pos - low
                    np.add.at(sticks, low, ratio * row["intensities"][valid] * (1 - frac))
                    ok = low + 1 < len(x)
                    np.add.at(sticks, low[ok] + 1, ratio * row["intensities"][valid][ok] * frac[ok])
                basis = gaussian_filter1d(sticks, 0.075 / step)
                denominator = float(np.dot(weight * basis, basis))
                amplitude = max(0.0, float(np.dot(weight * residual, basis)) / denominator) if denominator else 0.0
                improvement = amplitude * amplitude * denominator
                if improvement > best[0]:
                    best = (improvement, scale, amplitude)
            row.update(profile_improvement=best[0], profile_scale=best[1], amplitude=best[2])
        ranked = sorted(rows[:60], key=lambda row: row["profile_improvement"], reverse=True)
        cleaned = []
        for row in ranked:
            cleaned.append({key: value for key, value in row.items() if key not in {"base_angles", "intensities"}})
        output[target_name] = cleaned

    (ROOT / "trials" / "stoich_search.json").write_text(json.dumps(output, indent=2) + "\n")
    for target_name in TARGETS:
        print(f"\n## {target_name}")
        for row in output.get(target_name, [])[:20]:
            print(
                f"{row['cod_id']} {row['formula']:14s} SG={row['space_group_number']:3d} "
                f"map={row['replacement']} s={row['profile_scale']:.4f} dens={row['density']:.2f} "
                f"profile={row['profile_improvement']:.0f} line={row['line_score']:.0f}"
            )


if __name__ == "__main__":
    main()
