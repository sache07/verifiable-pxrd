#!/usr/bin/env python
"""Ordinary sequential refinement from the stable, physically screened WO3 model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_wo3_replacement import freeze


START = Path("trials/wo3_physical_test/cell.gpx")
OUTDIR = Path("trials/physical_ordinary")
ACTIVE = ("MnWO4", "WO3_physical", "Mn2WO5_P21c")


def stats(project: G2.G2Project, stage: str, path: Path) -> dict:
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    phases = []
    masses = []
    for name in ACTIVE:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass)
        phases.append(
            {
                "name": name,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "md_ratio": float(hap["Pref.Ori."][1]),
                "md_axis": list(hap["Pref.Ori."][3]),
            }
        )
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / sum(masses)
    return {
        "stage": stage,
        "project": str(path),
        "rwp_percent": hist.get_wR(),
        "gof": cov.get("GOF"),
        "max_shift_esd": cov.get("Max shft/sig"),
        "converged": cov.get("converged"),
        "phases": phases,
    }


def run_stage(source: Path, index: int, label: str, activate) -> tuple[Path, dict]:
    output = OUTDIR / f"{index:02d}_{label}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    freeze(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for name in ACTIVE:
        project.phase(name).data["Histograms"][hist.name]["Scale"][1] = True
    activate(project, hist)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = stats(project, label, output)
    print(json.dumps(row))
    return output, row


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    source = START
    current_rwp = G2.G2Project(gpxfile=str(source)).histogram(0).get_wR()
    reports = []
    stages = []
    stages.append(("background", lambda p, h: None))
    for phase in ACTIVE:
        stages.append(
            (
                "cell_" + phase,
                lambda p, h, phase=phase: p.phase(phase).data["General"]["Cell"].__setitem__(0, True),
            )
        )
    for parameter in ("U", "W", "X", "SH/L", "Polariz."):
        stages.append(
            (
                "inst_" + parameter.replace("/", "").replace(".", ""),
                lambda p, h, parameter=parameter: h.data["Instrument Parameters"][0][parameter].__setitem__(2, True),
            )
        )
    for phase in ACTIVE:
        stages.append(
            (
                "size_" + phase,
                lambda p, h, phase=phase: p.phase(phase).data["Histograms"][h.name]["Size"][2].__setitem__(0, True),
            )
        )
    for phase in ACTIVE:
        stages.append(
            (
                "strain_" + phase,
                lambda p, h, phase=phase: p.phase(phase).data["Histograms"][h.name]["Mustrain"][2].__setitem__(0, True),
            )
        )
    for phase in ("WO3_physical", "Mn2WO5_P21c"):
        stages.append(
            (
                "texture_" + phase,
                lambda p, h, phase=phase: p.phase(phase).data["Histograms"][h.name]["Pref.Ori."].__setitem__(2, True),
            )
        )

    for index, (label, activate) in enumerate(stages, 1):
        output, row = run_stage(source, index, label, activate)
        reports.append(row)
        # Least-squares stages should not worsen the objective. Retain the
        # prior saved state if a boundary/ill-conditioned step does so.
        if row["rwp_percent"] <= current_rwp + 1e-6:
            source = output
            current_rwp = row["rwp_percent"]

    for repeat in range(2):
        output, row = run_stage(source, len(stages) + repeat + 1, f"stable_{repeat + 1}", lambda p, h: None)
        reports.append(row)
        if row["rwp_percent"] <= current_rwp + 1e-6:
            source = output
            current_rwp = row["rwp_percent"]
    (OUTDIR / "summary.json").write_text(
        json.dumps({"selected_project": str(source), "stages": reports}, indent=2) + "\n"
    )
    print(json.dumps({"selected_project": str(source)}))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
