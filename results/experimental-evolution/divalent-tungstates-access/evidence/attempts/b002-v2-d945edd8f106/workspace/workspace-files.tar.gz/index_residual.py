#!/usr/bin/env python
"""Autoindex the coherent residual-peak subset with GSAS-II's indexing engine."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIindex as IDX


LAMBDA = 1.540598
POSITIONS = [
    19.85706,
    20.38951,
    25.43152,
    28.63167,
    31.77750,
    32.48381,
    35.09175,
    45.67562,
    46.47974,
    54.40134,
    55.28152,
    56.47682,
    59.32382,
    66.41958,
    70.14675,
]
INTENSITIES = [3600, 4170, 430, 4100, 1530, 775, 4030, 1500, 2280, 2000, 1440, 795, 560, 675, 600]


def d_spacing(position: float) -> float:
    return LAMBDA / (2 * np.sin(np.deg2rad(position / 2)))


def main() -> None:
    peaks = [
        [position, intensity, True, False, 0, 0, 0, d_spacing(position), 0.0]
        for position, intensity in zip(POSITIONS, INTENSITIES)
    ]
    names = [
        "Cubic-F", "Cubic-I", "Cubic-P", "Trigonal-R", "Hexagonal-P",
        "Tetragonal-I", "Tetragonal-P", "Orthorhombic-F", "Orthorhombic-I",
        "Orthorhombic-A", "Orthorhombic-B", "Orthorhombic-C", "Orthorhombic-P",
        "Monoclinic-I", "Monoclinic-A", "Monoclinic-C", "Monoclinic-P", "Triclinic",
    ]
    all_cells = []
    # Search from low volume upward. One lattice per call keeps time bounded and evidence explicit.
    for index in range(3, 17):
        controls = [0, 0.0, 5, 50.0, 0, "P1", 1.0, 1.0, 1.0, 90.0, 90.0, 90.0, 1.0, "P 1"]
        bravais = [False] * 18
        bravais[index] = True
        print(f"\n### {names[index]}")
        try:
            ok, dmin, cells = IDX.DoIndexPeaks(
                [row.copy() for row in peaks], controls, bravais, None,
                ifX20=True, timeout=20, M20_min=4.0, X20_max=12,
            )
        except Exception as exc:
            print(f"ERROR {exc}")
            continue
        for cell in cells:
            all_cells.append(
                {
                    "m20": float(cell[0]),
                    "x20": int(cell[1]),
                    "bravais_index": int(cell[2]),
                    "bravais": names[int(cell[2])],
                    "a": float(cell[3]),
                    "b": float(cell[4]),
                    "c": float(cell[5]),
                    "alpha": float(cell[6]),
                    "beta": float(cell[7]),
                    "gamma": float(cell[8]),
                    "volume": float(cell[9]),
                }
            )
    all_cells.sort(key=lambda row: row["m20"], reverse=True)
    Path("trials/residual_indexing.json").write_text(json.dumps(all_cells, indent=2) + "\n")
    print("\n### BEST")
    print(json.dumps(all_cells[:40], indent=2))


if __name__ == "__main__":
    main()
