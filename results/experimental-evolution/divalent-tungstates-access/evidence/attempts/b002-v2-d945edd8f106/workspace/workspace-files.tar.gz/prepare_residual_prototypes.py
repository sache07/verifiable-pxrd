#!/usr/bin/env python
"""Prepare Mn2WO5 prototype transfers selected by the residual search."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
OUT = ROOT / "trials" / "residual_prototypes"

# The scales are the isotropic lattice multipliers selected against the residual
# profile.  Both distinct high-ranking symmetries are retained, along with two
# independent Pnnm parents so that a parent-specific coordinate arrangement is
# not mistaken for evidence for the space group.
MODELS = [
    ("Mn2WO5_P21c_Cu2AsO5", "9011171", {"Cu": "Mn", "As": "W"}, 1.036),
    ("Mn2WO5_Pnnm_Mn2AsO5", "9000178", {"As": "W"}, 1.020),
    ("Mn2WO5_Pnnm_Cu2AsO5", "9015082", {"Cu": "Mn", "As": "W"}, 1.038),
    ("Mn3WO6_R3_Cd3TeO6", "2242674", {"Cd": "Mn", "Te": "W"}, 0.971),
    ("Mn3WO6_C2c_Zn3TeO6", "2211529", {"Zn": "Mn", "Te": "W"}, 1.007),
    ("Mn2WO6_P212121_Y2WO6", "1541070", {"Y": "Mn"}, 0.968),
    ("MnWO5_P21c_AmWO5", "1551090", {"Am": "Mn"}, 0.975),
]


def cif_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = []
    for name, cod_id, replacements, scale in MODELS:
        source = cif_path(cod_id)
        structure = Structure.from_file(source, primitive=False)
        structure.remove_oxidation_states()
        structure.replace_species(replacements)
        structure.lattice = Lattice(structure.lattice.matrix * scale)
        destination = OUT / f"{name}.cif"
        CifWriter(structure, symprec=0.001, significant_figures=10).write_file(destination)
        manifest.append(
            {
                "name": name,
                "cod_id": cod_id,
                "parent": str(source),
                "replacement": replacements,
                "residual_lattice_scale": scale,
                "target_formula": structure.composition.reduced_formula,
                "space_group": structure.get_space_group_info(),
                "cell": list(structure.lattice.parameters),
                "density_g_cm3": float(structure.density),
                "cif": str(destination),
            }
        )
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
