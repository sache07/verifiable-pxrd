#!/usr/bin/env python
"""Summarize a GSAS-II powder project's residual and phase fractions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("gpx", type=Path)
    parser.add_argument("--csv", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.gpx))
    hist = project.histogram(0)
    arrays = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    x, obs, weight, calc, background, difference = arrays
    rows = np.column_stack((x, obs, calc, difference, background))
    if args.csv:
        np.savetxt(args.csv, rows, delimiter=",", header="two_theta_deg,observed,calculated,difference,background", comments="")
    peaks, props = find_peaks(difference, prominence=100.0, distance=4, width=2)
    ranked = peaks[np.argsort(difference[peaks])[::-1]]
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    report = {
        "rwp_percent": hist.get_wR(),
        "residual_rms": float(np.sqrt(np.mean(difference**2))),
        "phases": [
            {
                "name": phase.name,
                "weight_fraction": mass / sum(masses),
                "cell": phase.get_cell(),
            }
            for phase, mass in zip(project.phases(), masses)
        ],
        "largest_positive_residual_peaks": [
            {"two_theta_deg": float(x[i]), "difference": float(difference[i]), "observed": float(obs[i]), "calculated": float(calc[i])}
            for i in ranked[:100]
        ],
    }
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
