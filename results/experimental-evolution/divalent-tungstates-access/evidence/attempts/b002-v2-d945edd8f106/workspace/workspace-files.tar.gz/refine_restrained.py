#!/usr/bin/env python
"""Refine one oxide phase's coordinates while preserving its starting bonds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIspc as G2spc


def starting_bond_restraints(phase, cutoffs: dict[str, float], esds: dict[str, float]) -> list:
    atoms = phase.atoms()
    general = phase.data["General"]
    amat, _ = G2lat.cell2AB(general["Cell"][1:7])
    sgdata = general["SGData"]
    units = np.asarray([[h, k, l] for h in range(-2, 3) for k in range(-2, 3) for l in range(-2, 3)])
    restraints = []
    seen = set()
    for origin in atoms:
        cutoff = cutoffs.get(origin.element)
        if cutoff is None:
            continue
        for target in atoms:
            if target.element != "O":
                continue
            for txyz, op, tunit, _ in G2spc.GenAtom(target.coordinates, sgdata, False, Move=False):
                delta = (np.asarray(txyz) - np.asarray(origin.coordinates)) + units
                cart = np.inner(amat, delta)
                distances = np.sqrt(np.sum(cart**2, axis=0))
                for index in np.flatnonzero((distances > 0.5) & (distances < cutoff)):
                    unit = units[index] + tunit
                    opstr = f"{op}+{unit[0]},{unit[1]},{unit[2]}" if np.any(unit) else str(op)
                    key = (origin.ranId, target.ranId, "1", opstr)
                    if key in seen:
                        continue
                    seen.add(key)
                    restraints.append(
                        [[origin.ranId, target.ranId], ["1", opstr], float(distances[index]), float(esds[origin.element])]
                    )
    return restraints


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--cycles", type=int, default=20)
    parser.add_argument("--shift-factor", type=float, default=0.25)
    parser.add_argument("--weight", type=float, default=1000.0)
    parser.add_argument("--mn-cutoff", type=float, default=2.70)
    parser.add_argument("--w-cutoff", type=float, default=2.15)
    parser.add_argument("--mn-esd", type=float, default=0.05)
    parser.add_argument("--w-esd", type=float, default=0.03)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.output))
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["shift factor"] = args.shift_factor
    project.set_Frozen()
    hist = project.histogram(0)
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase_index, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = "X" if phase_index == args.phase else " "

    phase = project.phase(args.phase)
    bonds = starting_bond_restraints(
        phase,
        {"Mn": args.mn_cutoff, "W": args.w_cutoff},
        {"Mn": args.mn_esd, "W": args.w_esd},
    )
    project.data["Restraints"]["data"][phase.name] = {
        "Bond": {"wtFactor": float(args.weight), "Range": 1.1, "Bonds": bonds, "Use": True}
    }
    before = {atom.label: list(atom.coordinates) for atom in phase.atoms()}
    project.save()
    project.refine(makeBack=False)
    project.save()
    result = {
        "phase": phase.name,
        "bond_restraints": len(bonds),
        "weight": args.weight,
        "rwp_percent": float(hist.get_wR()),
        "coordinates": [
            {"atom": atom.label, "before": before[atom.label], "after": list(atom.coordinates)} for atom in phase.atoms()
        ],
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
