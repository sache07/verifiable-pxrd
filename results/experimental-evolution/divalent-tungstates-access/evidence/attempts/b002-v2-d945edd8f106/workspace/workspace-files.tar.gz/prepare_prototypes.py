#!/usr/bin/env python
"""Create target-composition CIFs from selected analogue frameworks."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
OUT = ROOT / "trials" / "prototypes"


MODELS = [
    ("Mn3O4_tetragonal", "9001963", {}),
    ("Mn3O4_orthorhombic", "9001302", {}),
    ("Mn3O4_orthorhombic_alt", "1541183", {}),
    ("Mn2O3_bixbyite", "1514230", {}),
    ("MnO_rocksalt", "1514108", {}),
    ("Mn2WO6_trirutile", "1530909", {"Cr": "Mn"}),
    ("Mn2WO6_Pbcn", "2310464", {"Fe": "Mn"}),
    ("Mn3WO6_P21c", "1563081", {"Ca": "Mn"}),
    ("Mn3WO6_Pa3", "1527404", {"Cu": "Mn"}),
    ("MnWO4_Pnna", "9007595", {"Sn": "Mn"}),
    ("MnWO4_fergusonite_Ca", "1546035", {"Ca": "Mn"}),
    ("MnWO4_fergusonite_Sr", "1546037", {"Sr": "Mn"}),
    ("MnWO4_fergusonite_Hg", "2012578", {"Hg": "Mn"}),
    ("MnWO4_scheelite", "7219229", {"Ca": "Mn"}),
    ("MnW2O6_trirutile", "1531374", {"Ta": "W"}),
    ("MnW2O6_Pbcn", "8103683", {"Ta": "W"}),
]


def cif_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = []
    for name, cod_id, replacements in MODELS:
        structure = Structure.from_file(cif_path(cod_id), primitive=False)
        structure.remove_oxidation_states()
        if replacements:
            structure.replace_species(replacements)
        destination = OUT / f"{name}.cif"
        CifWriter(structure, symprec=0.001, significant_figures=10).write_file(destination)
        manifest.append(
            {
                "name": name,
                "cod_id": cod_id,
                "parent": str(cif_path(cod_id)),
                "replacement": replacements,
                "target_formula": structure.composition.reduced_formula,
                "space_group": structure.get_space_group_info(),
                "cell": list(structure.lattice.parameters),
                "cif": str(destination),
            }
        )
    (OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
