#!/usr/bin/env python
"""Build reproducible GSAS-II trial refinements for the supplied PXRD scan."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")


def cod_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_instrument(path: Path) -> None:
    path.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha1+2 Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def summarize(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    total = sum(masses)
    for row, value in zip(phases, masses):
        row["weight_fraction"] = value / total if total else 0.0
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "label": label,
        "rwp_percent": hist.get_wR(),
        "phases": phases,
        "instrument": {k: v for k, v in inst.items() if k in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}},
        "sample": {k: sample.get(k) for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius")},
        "background": hist.data["Background"],
    }
    print(json.dumps(result, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)))
    return result


def refine(project: G2.G2Project, label: str) -> None:
    project.refine(makeBack=False)
    project.save()
    summarize(project, label)


def build(output: Path, ids: list[str], names: list[str], fractions: list[float]) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    instrument = output.parent / "instrument.instprm"
    write_instrument(instrument)
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(instrument),
        fmthint="comma",
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    phases = []
    for cod_id, name in zip(ids, names):
        source = Path(cod_id) if cod_id.lower().endswith(".cif") else cod_path(cod_id)
        phase = project.add_phase(str(source), phasename=name, histograms=[hist], fmthint="CIF")
        phases.append(phase)
    project.set_Controls("cycles", 10)

    # Put all phases on a common physically meaningful starting scale and profile.
    for phase, fraction in zip(phases, fractions):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * fraction / float(phase.data["General"]["Mass"]), False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = 0.01

    b0 = float(np.percentile(hist.data["data"][1][1], 20))
    hist.set_refinements(
        {
            "Limits": [10.0, 100.05],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [b0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save()
    refine(project, "background_scales")

    # Common angular corrections are refined before lattice parameters.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "zero")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "zero_shift")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "instrument_profile")

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.5, "refine": True}}, [hist])
    refine(project, "sizes")
    refine(project, "repeat")

    summary = summarize(project, "final")
    (output.parent / "summary.json").write_text(json.dumps(summary, indent=2, default=lambda obj: obj.tolist() if hasattr(obj, "tolist") else str(obj)) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--names", nargs="+", required=True)
    parser.add_argument("--fractions", nargs="+", type=float, required=True)
    args = parser.parse_args()
    if not (len(args.ids) == len(args.names) == len(args.fractions)):
        parser.error("--ids, --names and --fractions must have equal lengths")
    fractions = np.asarray(args.fractions, float)
    fractions /= fractions.sum()
    G2.SetPrintLevel("warn")
    build(args.output, args.ids, args.names, fractions.tolist())


if __name__ == "__main__":
    main()
