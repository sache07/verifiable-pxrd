#!/usr/bin/env python
"""Refine selected atomic-coordinate subsets in one phase of a saved project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--elements", nargs="+", required=True)
    parser.add_argument("--cycles", type=int, default=8)
    parser.add_argument("--shift-factor", type=float, default=0.5)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.output))
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["shift factor"] = args.shift_factor
    project.set_Frozen()
    hist = project.histogram(0)
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    before = {}
    selected = set(args.elements)
    for phase_index, phase in enumerate(project.phases()):
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            before[f"{phase_index}:{atom.label}"] = list(atom.coordinates)
            atom.refinement_flags = "X" if phase_index == args.phase and atom.element in selected else " "
    project.save()
    project.refine(makeBack=False)
    project.save()
    after = {
        f"{phase_index}:{atom.label}": list(atom.coordinates)
        for phase_index, phase in enumerate(project.phases())
        for atom in phase.atoms()
    }
    row = {
        "phase": project.phase(args.phase).name,
        "elements": sorted(selected),
        "rwp_percent": float(hist.get_wR()),
        "frozen": project.get_Frozen(),
        "coordinates": [
            {"atom": key, "before": before[key], "after": after[key]}
            for key in before
            if before[key] != after[key]
        ],
    }
    print(json.dumps(row, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
