#!/usr/bin/env python
"""Continue the physical-WO3 W-coordinate refinement from a saved branch."""

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    source = Path("trials/wo3_physical_test/W.gpx")
    reports = []
    for suffix in ("W_b", "W_c"):
        output = Path("trials/wo3_physical_test") / f"{suffix}.gpx"
        project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
        project.set_Controls("cycles", 12)
        project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        row = {
            "project": str(output),
            "rwp_percent": project.histogram(0).get_wR(),
            "gof": cov.get("GOF"),
            "max_shift_esd": cov.get("Max shft/sig"),
            "converged": cov.get("converged"),
        }
        reports.append(row)
        print(json.dumps(row))
        source = output
    Path("trials/wo3_physical_test/W_continue.json").write_text(json.dumps(reports, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
