#!/usr/bin/env python
"""Print basic crystallographic and powder-line summaries for candidate CIFs."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02")
INDEX = ROOT / "index.json.gz"
CIFS = ROOT / "cif"


def cif_path(cod_id: str) -> Path:
    return CIFS / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    calc = XRDCalculator(wavelength=1.540598)
    for system in ("Mn-O-W", "O-W", "Mn-O"):
        print(f"\n## {system}")
        for formula, cod_id, sg, quality in index[system]:
            path = cif_path(cod_id)
            try:
                structure = Structure.from_file(path)
                pattern = calc.get_pattern(structure, two_theta_range=(9.5, 100.5))
                ranked = sorted(zip(pattern.y, pattern.x), reverse=True)[:12]
                lines = " ".join(f"{angle:.2f}({inten:.0f})" for inten, angle in ranked)
                lat = structure.lattice
                print(
                    f"{cod_id} {formula:14s} SG={sg:3d} "
                    f"a,b,c={lat.a:.3f},{lat.b:.3f},{lat.c:.3f} "
                    f"angles={lat.alpha:.1f},{lat.beta:.1f},{lat.gamma:.1f} :: {lines}"
                )
            except Exception as exc:
                print(f"{cod_id} {formula:14s} ERROR {exc}")


if __name__ == "__main__":
    main()
