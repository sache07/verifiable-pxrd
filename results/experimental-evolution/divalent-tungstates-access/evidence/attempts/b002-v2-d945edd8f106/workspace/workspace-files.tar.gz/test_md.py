#!/usr/bin/env python
"""Compare March-Dollase axes in otherwise frozen copies of one GSAS project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def freeze(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    rows = []
    for phase_index in range(len(G2.G2Project(gpxfile=str(args.base)).phases())):
        for axis in AXES:
            name = "p%d_%d%d%d" % (phase_index, *axis)
            destination = args.output / f"{name}.gpx"
            project = G2.G2Project(gpxfile=str(args.base), newgpx=str(destination))
            project.set_Controls("cycles", 5)
            project.set_Frozen()
            freeze(project)
            hist = project.histogram(0)
            phase = project.phase(phase_index)
            md = phase.data["Histograms"][hist.name]["Pref.Ori."]
            md[0] = "MD"
            md[1] = 1.0
            md[2] = True
            md[3] = list(axis)
            project.save()
            project.refine(makeBack=False)
            project.save()
            row = {
                "phase_index": phase_index,
                "phase": phase.name,
                "axis": list(axis),
                "ratio": float(md[1]),
                "rwp_percent": float(hist.get_wR()),
                "frozen": project.get_Frozen(),
                "gpx": str(destination),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    (args.output / "results.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
