#!/usr/bin/env python
"""Rank exact Mn-O and W-O references against the current common-state residual."""

from __future__ import annotations

import argparse
import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d


RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02")
L1, L2 = 1.540598, 1.544426


def path_for(cod_id: str) -> Path:
    return RESOURCE / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def shift_angles(base: np.ndarray, scale: float, wavelength: float) -> np.ndarray:
    d = L1 / (2 * np.sin(np.deg2rad(base / 2)))
    return 2 * np.rad2deg(np.arcsin(np.minimum(0.999999, wavelength / (2 * d * scale))))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", nargs="?", default="trials/add_MnO_rocksalt/profile.csv")
    parser.add_argument("--output", default="trials/exact_oxide_ranking.json")
    args = parser.parse_args()
    data = np.loadtxt(args.profile, delimiter=",", skiprows=1)
    x, obs, _, residual, _ = data.T
    step = float(np.median(np.diff(x)))
    weight = 1 / np.maximum(obs, 1)
    with gzip.open(RESOURCE / "index.json.gz", "rt") as handle:
        index = json.load(handle)
    calc = XRDCalculator(wavelength=L1)
    warnings.simplefilter("ignore")
    rows = []
    for system in ("Mn-O", "O-W"):
        for formula, cod_id, sg, quality in index[system]:
            try:
                structure = Structure.from_file(path_for(cod_id), primitive=False)
                pattern = calc.get_pattern(structure, two_theta_range=(7, 120))
            except Exception:
                continue
            angles = np.asarray(pattern.x)
            intensities = np.asarray(pattern.y)
            best = (-np.inf, None, None)
            for scale in np.linspace(0.965, 1.035, 71):
                sticks = np.zeros_like(x)
                for wavelength, ratio in ((L1, 1.0), (L2, 0.5)):
                    aa = shift_angles(angles, scale, wavelength)
                    valid = (aa >= x[0]) & (aa <= x[-1])
                    pos = (aa[valid] - x[0]) / step
                    low = np.floor(pos).astype(int)
                    frac = pos - low
                    np.add.at(sticks, low, ratio * intensities[valid] * (1 - frac))
                    ok = low + 1 < len(x)
                    np.add.at(sticks, low[ok] + 1, ratio * intensities[valid][ok] * frac[ok])
                basis = gaussian_filter1d(sticks, 0.08 / step)
                den = float(np.dot(weight * basis, basis))
                amp = max(0.0, float(np.dot(weight * residual, basis)) / den) if den else 0.0
                improvement = amp * amp * den
                if improvement > best[0]:
                    best = (improvement, scale, amp)
            rows.append({"system": system, "formula": formula, "cod_id": cod_id, "sg": sg, "quality": quality,
                         "improvement": best[0], "scale": best[1], "amplitude": best[2]})
    rows.sort(key=lambda row: row["improvement"], reverse=True)
    Path(args.output).write_text(json.dumps(rows, indent=2) + "\n")
    for row in rows:
        print(row)


if __name__ == "__main__":
    main()
