#!/usr/bin/env python
"""Replace the suspect 1960 WO3 coordinates in the converged common project."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


BASE = Path("trials/final_work_m2w_size_b.gpx")
CANDIDATE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/2/31/10/2311041.cif"
)
OUTDIR = Path("trials/wo3_physical_test")


def freeze(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False


def rows(project: G2.G2Project) -> list[dict]:
    hist = project.histogram(0)
    out = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out.append(
            {
                "name": phase.name,
                "use": hap.get("Use", True),
                "scale": float(hap["Scale"][0]),
                "mass_scale": float(phase.data["General"]["Mass"] * hap["Scale"][0]),
                "cell": phase.get_cell(),
            }
        )
    return out


def refine(project: G2.G2Project, stage: str) -> dict:
    project.refine(makeBack=False)
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "stage": stage,
        "rwp_percent": project.histogram(0).get_wR(),
        "gof": cov.get("GOF"),
        "max_shift_esd": cov.get("Max shft/sig"),
        "phases": rows(project),
    }
    print(json.dumps(result, indent=2))
    return result


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    cell_file = OUTDIR / "cell.gpx"
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(cell_file))
    project.set_Controls("cycles", 12)
    freeze(project)
    hist = project.histogram(0)
    old = project.phase("WO3")
    old_hap = old.data["Histograms"][hist.name]
    old_mass_scale = float(old.data["General"]["Mass"] * old_hap["Scale"][0])

    new = project.add_phase(str(CANDIDATE), phasename="WO3_physical", histograms=[hist], fmthint="CIF")
    new_hap = copy.deepcopy(old_hap)
    new_hap["Scale"] = [old_mass_scale / float(new.data["General"]["Mass"]), True]
    new_hap["Use"] = True
    # The old fitted [001] direction maps to [-101] in COD 2311041's setting.
    new_hap["Pref.Ori."][3] = [-1, 0, 1]
    new.data["Histograms"][hist.name] = new_hap
    for atom in new.atoms():
        atom.data[atom.cia] = "I"
        atom.uiso = 0.02
        atom.refinement_flags = " "

    old_hap["Scale"] = [0.0, False]
    old_hap["Use"] = False
    for name in ("MnWO4", "Mn2WO5_P21c"):
        project.phase(name).data["Histograms"][hist.name]["Scale"][1] = True
    new.data["General"]["Cell"][0] = True
    project.save()
    reports = [refine(project, "physical_WO3_cell"), refine(project, "physical_WO3_cell_repeat")]

    w_file = OUTDIR / "W.gpx"
    project = G2.G2Project(gpxfile=str(cell_file), newgpx=str(w_file))
    project.phase("WO3_physical").data["General"]["Cell"][0] = False
    for atom in project.phase("WO3_physical").atoms():
        atom.refinement_flags = "X" if atom.element == "W" else " "
    reports += [refine(project, "physical_WO3_W"), refine(project, "physical_WO3_W_repeat")]
    (OUTDIR / "summary.json").write_text(json.dumps(reports, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
