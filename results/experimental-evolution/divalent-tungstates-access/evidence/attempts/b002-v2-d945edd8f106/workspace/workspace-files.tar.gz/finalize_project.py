#!/usr/bin/env python
"""Freeze the selected physical state, remove inactive trials, and export final CIFs."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_wo3_replacement import freeze


SOURCE = Path("trials/final_sweep2/16_stable.gpx")
FINAL = Path("final.gpx")


def main() -> None:
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    hist = project.histogram(0)
    freeze(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist.data["Limits"] = [
        (float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])),
        [float(hist.data["data"][1][0][0]), float(hist.data["data"][1][0][-1])],
    ]

    # Remove the superseded 1960 WO3 trial entirely; it was already disabled
    # and at zero scale in the selected refinement.
    project.data["Phases"].pop("WO3", None)
    hist.data["Reflection Lists"].pop("WO3", None)
    for names in project.names:
        if names and names[0] == "Phases" and "WO3" in names:
            names.remove("WO3")
    project.save()

    exports = {
        "MnWO4": Path("phase_1_MnWO4.cif"),
        "WO3_physical": Path("phase_2_WO3.cif"),
        "Mn2WO5_P21c": Path("phase_3_Mn2WO5.cif"),
    }
    for name, output in exports.items():
        project.phase(name).export_CIF(str(output))
        print(name, output)
    print(FINAL)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
