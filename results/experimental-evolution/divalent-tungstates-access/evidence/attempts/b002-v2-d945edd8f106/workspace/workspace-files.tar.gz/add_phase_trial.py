#!/usr/bin/env python
"""Add one candidate to a frozen common multiphase GSAS-II state and test it."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def phase_rows(project: G2.G2Project) -> list[dict]:
    hist = project.histogram(0)
    masses = []
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(mass_scale)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_scale": mass_scale,
                "cell": phase.get_cell(),
                "size_um": float(hap["Size"][1][0]),
            }
        )
    total = sum(max(0.0, value) for value in masses)
    for row, value in zip(rows, masses):
        row["weight_fraction"] = max(0.0, value) / total if total else 0.0
    return rows


def summarize(project: G2.G2Project, stage: str) -> dict:
    result = {"stage": stage, "rwp_percent": project.histogram(0).get_wR(), "phases": phase_rows(project)}
    print(json.dumps(result, indent=2))
    return result


def freeze_common_state(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for key, value in hist.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False


def run(base: Path, candidate: Path, output: Path, name: str) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(base), newgpx=str(output))
    project.set_Controls("cycles", 8)
    freeze_common_state(project)
    hist = project.histogram(0)
    baseline = summarize(project, "common_base")
    old_mass_scale = sum(max(0.0, row["mass_scale"]) for row in baseline["phases"])

    candidate_phase = project.add_phase(str(candidate), phasename=name, histograms=[hist], fmthint="CIF")
    hap = candidate_phase.data["Histograms"][hist.name]
    hap["Scale"] = [old_mass_scale * 0.05 / 0.95 / float(candidate_phase.data["General"]["Mass"]), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    for atom in candidate_phase.atoms():
        atom.data[atom.cia] = "I"
        atom.uiso = 0.01
        atom.refinement_flags = " "

    # Existing scales may relax, but every structural/nuisance parameter stays frozen.
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    project.save()
    project.refine(makeBack=False)
    scale_only = summarize(project, "scale_only")

    candidate_phase.data["General"]["Cell"][0] = True
    project.refine(makeBack=False)
    cell = summarize(project, "candidate_cell")

    project.refine(makeBack=False)
    final = summarize(project, "repeat")
    project.save()
    report = {"candidate": str(candidate), "name": name, "stages": [baseline, scale_only, cell, final]}
    (output.parent / "trial.json").write_text(json.dumps(report, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    run(args.base, args.candidate, args.output, args.name)


if __name__ == "__main__":
    main()
