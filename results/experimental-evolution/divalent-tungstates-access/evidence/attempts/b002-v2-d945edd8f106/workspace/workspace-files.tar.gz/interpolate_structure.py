#!/usr/bin/env python
"""Line-search between a physical model and a profile-directed coordinate trial."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--fraction", type=float, required=True)
    args = parser.parse_args()
    if not 0 <= args.fraction <= 1:
        parser.error("--fraction must lie in [0,1]")

    project = G2.G2Project(gpxfile=str(args.base), newgpx=str(args.output))
    target = G2.G2Project(gpxfile=str(args.target))
    project.set_Controls("cycles", 8)
    project.set_Frozen()
    hist = project.histogram(0)
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    project.data["Restraints"]["data"] = {}
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "

    base_atoms = project.phase(args.phase).atoms()
    target_atoms = target.phase(args.phase).atoms()
    if [atom.label for atom in base_atoms] != [atom.label for atom in target_atoms]:
        raise ValueError("phase atom order differs")
    shifts = []
    for atom, other in zip(base_atoms, target_atoms):
        start = np.asarray(atom.coordinates, float)
        delta = np.asarray(other.coordinates, float) - start
        delta -= np.round(delta)
        atom.coordinates = start + args.fraction * delta
        shifts.append({"atom": atom.label, "fractional_shift": (args.fraction * delta).tolist()})
    project.save()
    project.refine(makeBack=False)
    project.save()
    print(json.dumps({"fraction": args.fraction, "rwp_percent": float(hist.get_wR()), "shifts": shifts}, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
