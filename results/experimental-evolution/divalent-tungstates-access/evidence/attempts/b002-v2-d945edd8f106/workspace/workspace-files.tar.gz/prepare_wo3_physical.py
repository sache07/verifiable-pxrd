#!/usr/bin/env python
"""Transform the physically sound Loopstra WO3 model into the fitted cell setting."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


SOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/2/31/10/2311041.cif"
)
OUTPUT = Path("trials/wo3_physical_2311041.cif")
ALT_SOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/1/56/35/1563541.cif"
)
ALT_OUTPUT = Path("trials/wo3_altmono_1563541_clean.cif")


def main() -> None:
    structure = Structure.from_file(SOURCE)
    # A' = A + C, B' = B, C' = -A. This unimodular transformation gives
    # the ~7.30 x 7.54 x 7.69 A, beta ~90.91 deg setting used in the fit.
    structure.make_supercell([[1, 0, 1], [0, 1, 0], [-1, 0, 0]])
    OUTPUT.write_text(
        str(CifWriter(structure, symprec=1e-3, refine_struct=False, significant_figures=10))
    )
    print(OUTPUT)
    print(structure.lattice)
    print(structure.get_space_group_info())

    # This source encodes atom types as the nonstandard strings W+ and O-;
    # remove oxidation labels so GSAS-II uses the correct W and O form factors.
    alternate = Structure.from_file(ALT_SOURCE)
    alternate.remove_oxidation_states()
    ALT_OUTPUT.write_text(
        str(CifWriter(alternate, symprec=1e-3, refine_struct=False, significant_figures=10))
    )
    print(ALT_OUTPUT)


if __name__ == "__main__":
    main()
