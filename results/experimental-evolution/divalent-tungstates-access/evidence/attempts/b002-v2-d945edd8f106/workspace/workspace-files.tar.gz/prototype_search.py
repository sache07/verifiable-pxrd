#!/usr/bin/env python
"""Residual-directed search of ABO4 prototype frameworks in the supplied COD subset."""

from __future__ import annotations

import gzip
import json
import re
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import minimize


WORK = Path(__file__).resolve().parent
RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02")
INDEX = RESOURCE / "index.json.gz"
CIFS = RESOURCE / "cif"
L1 = 1.540598
L2 = 1.544426


def cif_path(cod_id: str) -> Path:
    return CIFS / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def is_abo4(formula: str) -> bool:
    try:
        comp = Composition(formula).fractional_composition
    except Exception:
        return False
    if len(comp) != 3 or abs(comp.get_atomic_fraction("O") - 4 / 6) > 1e-5:
        return False
    return all(abs(value - 1 / 6) < 1e-5 for element, value in comp.items() if str(element) != "O")


def mappings(elements: list[str]) -> list[dict[str, str]]:
    cations = [element for element in elements if element != "O"]
    if "Mn" in cations and "W" in cations:
        return [{}]
    if "W" in cations:
        return [{next(element for element in cations if element != "W"): "Mn"}]
    if "Mn" in cations:
        return [{next(element for element in cations if element != "Mn"): "W"}]
    return [
        {cations[0]: "Mn", cations[1]: "W"},
        {cations[0]: "W", cations[1]: "Mn"},
    ]


def transformed(structure: Structure, replacement: dict[str, str]) -> Structure:
    result = structure.copy()
    result.remove_oxidation_states()
    if replacement:
        result.replace_species(replacement)
    return result


def angles_for_scale(base_angles: np.ndarray, scale: float, wavelength: float = L1) -> np.ndarray:
    d = L1 / (2 * np.sin(np.deg2rad(base_angles / 2)))
    arg = wavelength / (2 * d * scale)
    result = np.full_like(arg, np.nan)
    valid = arg < 1
    result[valid] = 2 * np.rad2deg(np.arcsin(arg[valid]))
    return result


def main() -> None:
    profile = np.loadtxt(WORK / "trials" / "base_1528915" / "profile.csv", delimiter=",", skiprows=1)
    x, obs, _, residual, _ = profile.T
    step = float(np.median(np.diff(x)))
    weights = 1 / np.maximum(obs, 1)
    residual_smooth = gaussian_filter1d(residual, 0.09 / step)
    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    records = []
    calc = XRDCalculator(wavelength=L1)
    warnings.simplefilter("ignore")
    for system, rows in index.items():
        elements = system.split("-")
        if len(elements) != 3 or "O" not in elements:
            continue
        for formula, cod_id, sg_number, quality in rows:
            if not is_abo4(formula):
                continue
            try:
                parent = Structure.from_file(cif_path(cod_id), primitive=False)
            except Exception:
                continue
            if len(parent) > 128:
                continue
            for replacement in mappings(elements):
                try:
                    target = transformed(parent, replacement)
                    if target.composition.reduced_formula != "MnWO4":
                        continue
                    pattern = calc.get_pattern(target, two_theta_range=(7, 120))
                except Exception:
                    continue
                base_angles = np.asarray(pattern.x, float)
                intensities = np.asarray(pattern.y, float)
                keep = intensities >= 0.5
                base_angles, intensities = base_angles[keep], intensities[keep]
                # Fast line-residual screen over isotropic lattice scale.
                best = (-np.inf, None)
                for scale in np.linspace(0.72, 1.28, 113):
                    angles = angles_for_scale(base_angles, scale)
                    valid = np.isfinite(angles) & (angles >= x[0]) & (angles <= x[-1])
                    if valid.sum() < 4:
                        continue
                    values = np.interp(angles[valid], x, residual_smooth)
                    score = float(np.dot(intensities[valid], values) / np.sqrt(np.dot(intensities[valid], intensities[valid])))
                    if score > best[0]:
                        best = (score, scale)
                records.append(
                    {
                        "cod_id": cod_id,
                        "formula": formula,
                        "space_group_number": sg_number,
                        "quality": quality,
                        "replacement": replacement,
                        "atoms": len(target),
                        "line_score": best[0],
                        "coarse_scale": best[1],
                        "base_angles": base_angles,
                        "intensities": intensities,
                        "parent_cell": list(parent.lattice.parameters),
                    }
                )

    records.sort(key=lambda row: row["line_score"], reverse=True)

    # Full profile least-squares score for the strongest line-matching prototypes.
    def profile_score(row: dict, parameters: np.ndarray) -> tuple[float, float, np.ndarray]:
        scale, offset = parameters
        if not 0.68 <= scale <= 1.32 or not -0.35 <= offset <= 0.35:
            return -np.inf, 0.0, np.zeros_like(x)
        a1 = angles_for_scale(row["base_angles"], scale, L1) + offset
        a2 = angles_for_scale(row["base_angles"], scale, L2) + offset
        sticks = np.zeros_like(x)
        for angles, ratio in ((a1, 1.0), (a2, 0.5)):
            valid = np.isfinite(angles) & (angles >= x[0]) & (angles <= x[-1])
            positions = (angles[valid] - x[0]) / step
            low = np.floor(positions).astype(int)
            frac = positions - low
            np.add.at(sticks, low, ratio * row["intensities"][valid] * (1 - frac))
            high_ok = low + 1 < len(sticks)
            np.add.at(sticks, low[high_ok] + 1, ratio * row["intensities"][valid][high_ok] * frac[high_ok])
        basis = gaussian_filter1d(sticks, 0.075 / step)
        denom = float(np.dot(weights * basis, basis))
        amplitude = max(0.0, float(np.dot(weights * residual, basis)) / denom) if denom else 0.0
        improvement = amplitude * amplitude * denom
        return improvement, amplitude, basis

    for row in records[:120]:
        start = np.array([row["coarse_scale"], 0.0])
        result = minimize(lambda p: -profile_score(row, p)[0], start, method="Nelder-Mead", options={"maxiter": 100, "xatol": 2e-5, "fatol": 1e-3})
        improvement, amplitude, _ = profile_score(row, result.x)
        row.update(profile_improvement=improvement, amplitude=amplitude, best_scale=float(result.x[0]), best_offset_deg=float(result.x[1]))

    profiled = sorted((row for row in records if "profile_improvement" in row), key=lambda row: row["profile_improvement"], reverse=True)
    output = []
    for row in profiled:
        cleaned = {key: value for key, value in row.items() if key not in {"base_angles", "intensities"}}
        output.append(cleaned)
    (WORK / "trials" / "prototype_search.json").write_text(json.dumps(output, indent=2) + "\n")
    for row in output[:60]:
        print(
            f"{row['cod_id']} {row['formula']:14s} SG={row['space_group_number']:3d} "
            f"map={row['replacement']} scale={row['best_scale']:.5f} offset={row['best_offset_deg']:.4f} "
            f"improvement={row['profile_improvement']:.1f} line={row['line_score']:.1f} cell={row['parent_cell'][:3]}"
        )


if __name__ == "__main__":
    main()
