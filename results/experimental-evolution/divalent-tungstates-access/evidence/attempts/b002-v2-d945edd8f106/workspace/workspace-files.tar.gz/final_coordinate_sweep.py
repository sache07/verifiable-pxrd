#!/usr/bin/env python
"""One final coordinate-descent sweep over accepted nuisance/profile terms."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_physical_model import ACTIVE, stats
from test_wo3_replacement import freeze


OUTDIR = Path("trials/final_sweep")


def run(source: Path, index: int, label: str, activate) -> tuple[Path, dict]:
    output = OUTDIR / f"{index:02d}_{label}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    freeze(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for name in ACTIVE:
        project.phase(name).data["Histograms"][hist.name]["Scale"][1] = True
    activate(project, hist)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = stats(project, label, output)
    print(json.dumps(row), flush=True)
    return output, row


def main() -> None:
    global OUTDIR
    parser = argparse.ArgumentParser()
    parser.add_argument("--start", type=Path, default=Path("trials/physical_polish/19_stable_2.gpx"))
    parser.add_argument("--outdir", type=Path, default=OUTDIR)
    args = parser.parse_args()
    OUTDIR = args.outdir
    OUTDIR.mkdir(parents=True, exist_ok=True)
    source = args.start
    current = G2.G2Project(gpxfile=str(source)).histogram(0).get_wR()
    reports = []
    stages = [
        ("shift", lambda p, h: h.data["Sample Parameters"]["Shift"].__setitem__(1, True)),
    ]
    for phase in ACTIVE:
        stages.append(("cell_" + phase, lambda p, h, phase=phase: p.phase(phase).data["General"]["Cell"].__setitem__(0, True)))
    for parameter in ("U", "W", "X", "SH/L", "Polariz."):
        stages.append(("inst_" + parameter.replace("/", "").replace(".", ""),
                       lambda p, h, parameter=parameter: h.data["Instrument Parameters"][0][parameter].__setitem__(2, True)))
    for phase in ACTIVE:
        stages.append(("size_" + phase,
                       lambda p, h, phase=phase: p.phase(phase).data["Histograms"][h.name]["Size"][2].__setitem__(0, True)))
    stages += [
        ("strain_WO3", lambda p, h: p.phase("WO3_physical").data["Histograms"][h.name]["Mustrain"][2].__setitem__(0, True)),
        ("texture_WO3", lambda p, h: p.phase("WO3_physical").data["Histograms"][h.name]["Pref.Ori."].__setitem__(2, True)),
        ("texture_Mn2WO5", lambda p, h: p.phase("Mn2WO5_P21c").data["Histograms"][h.name]["Pref.Ori."].__setitem__(2, True)),
        ("stable", lambda p, h: None),
    ]
    for index, (label, activate) in enumerate(stages, 1):
        output, row = run(source, index, label, activate)
        reports.append(row)
        if row["rwp_percent"] <= current + 1e-6:
            source, current = output, row["rwp_percent"]
    summary = {"selected_project": str(source), "rwp_percent": current, "stages": reports}
    (OUTDIR / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
