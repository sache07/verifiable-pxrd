#!/usr/bin/env python
"""Bounded cleanup and a second sequential pass for the physical three-phase model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_physical_model import ACTIVE, stats
from test_wo3_replacement import freeze


START = Path("trials/physical_ordinary/19_stable_2.gpx")
OUTDIR = Path("trials/physical_polish")


def prepare(project: G2.G2Project) -> None:
    freeze(project)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for name in ACTIVE:
        project.phase(name).data["Histograms"][hist.name]["Scale"][1] = True


def run(source: Path, index: int, label: str, activate=None, mutate=None) -> tuple[Path, dict]:
    output = OUTDIR / f"{index:02d}_{label}.gpx"
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    project.set_Controls("cycles", 12)
    prepare(project)
    hist = project.histogram(0)
    if mutate:
        mutate(project, hist)
    if activate:
        activate(project, hist)
    project.save()
    project.refine(makeBack=False)
    project.save()
    row = stats(project, label, output)
    print(json.dumps(row), flush=True)
    return output, row


def main() -> None:
    OUTDIR.mkdir(parents=True, exist_ok=True)
    reports = []

    # The synthetic experiment permits either inactive strain (0) or >=300 ppm.
    # Compare both physical endpoints after scale/background relaxation.
    strain_trials = []
    for index, value in enumerate((0.0, 300.0), 1):
        output, row = run(
            START,
            index,
            f"MnWO4_strain_{int(value)}",
            mutate=lambda p, h, value=value: p.phase("MnWO4").data["Histograms"][h.name]["Mustrain"][1].__setitem__(0, value),
        )
        reports.append(row)
        strain_trials.append((row["rwp_percent"], output, value))
    _, source, selected_strain = min(strain_trials)
    current_rwp = min(x[0] for x in strain_trials)

    stages = [
        ("sample_shift", lambda p, h: h.data["Sample Parameters"]["Shift"].__setitem__(1, True)),
        ("cell_MnWO4", lambda p, h: p.phase("MnWO4").data["General"]["Cell"].__setitem__(0, True)),
        ("cell_WO3", lambda p, h: p.phase("WO3_physical").data["General"]["Cell"].__setitem__(0, True)),
        ("cell_Mn2WO5", lambda p, h: p.phase("Mn2WO5_P21c").data["General"]["Cell"].__setitem__(0, True)),
    ]
    for parameter in ("U", "W", "X", "SH/L", "Polariz."):
        stages.append(
            (
                "inst_" + parameter.replace("/", "").replace(".", ""),
                lambda p, h, parameter=parameter: h.data["Instrument Parameters"][0][parameter].__setitem__(2, True),
            )
        )
    for phase in ACTIVE:
        stages.append(
            (
                "size_" + phase,
                lambda p, h, phase=phase: p.phase(phase).data["Histograms"][h.name]["Size"][2].__setitem__(0, True),
            )
        )
    stages += [
        (
            "strain_WO3",
            lambda p, h: p.phase("WO3_physical").data["Histograms"][h.name]["Mustrain"][2].__setitem__(0, True),
        ),
        (
            "texture_WO3",
            lambda p, h: p.phase("WO3_physical").data["Histograms"][h.name]["Pref.Ori."].__setitem__(2, True),
        ),
        (
            "texture_Mn2WO5",
            lambda p, h: p.phase("Mn2WO5_P21c").data["Histograms"][h.name]["Pref.Ori."].__setitem__(2, True),
        ),
    ]
    for index, (label, activate) in enumerate(stages, 3):
        output, row = run(source, index, label, activate=activate)
        reports.append(row)
        if row["rwp_percent"] <= current_rwp + 1e-6:
            source, current_rwp = output, row["rwp_percent"]

    for repeat in range(2):
        index = len(stages) + 3 + repeat
        output, row = run(source, index, f"stable_{repeat + 1}")
        reports.append(row)
        if row["rwp_percent"] <= current_rwp + 1e-6:
            source, current_rwp = output, row["rwp_percent"]

    summary = {
        "selected_project": str(source),
        "selected_MnWO4_microstrain_ppm": selected_strain,
        "rwp_percent": current_rwp,
        "stages": reports,
    }
    (OUTDIR / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
