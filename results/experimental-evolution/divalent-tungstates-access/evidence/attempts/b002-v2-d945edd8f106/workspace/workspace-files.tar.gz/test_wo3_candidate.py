#!/usr/bin/env python
"""Test a WO3 reference by replacing WO3 in one frozen common multiphase state."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_wo3_replacement import freeze, rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--name", required=True)
    parser.add_argument("--texture-axis", nargs=3, type=int, default=[0, 0, 1])
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(
        gpxfile="trials/final_work_m2w_size_b.gpx", newgpx=str(args.output)
    )
    project.set_Controls("cycles", 12)
    freeze(project)
    hist = project.histogram(0)
    old = project.phase("WO3")
    old_hap = old.data["Histograms"][hist.name]
    old_mass_scale = float(old.data["General"]["Mass"] * old_hap["Scale"][0])
    new = project.add_phase(
        str(args.candidate), phasename=args.name, histograms=[hist], fmthint="CIF"
    )
    # Keep symmetry-dependent strain arrays created for this candidate, while
    # transferring only the scalar profile/texture state from the common fit.
    hap = copy.deepcopy(new.data["Histograms"][hist.name])
    hap["Scale"] = [old_mass_scale / float(new.data["General"]["Mass"]), True]
    hap["Use"] = True
    hap["Pref.Ori."] = copy.deepcopy(old_hap["Pref.Ori."])
    hap["Pref.Ori."][3] = list(args.texture_axis)
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = float(old_hap["Size"][1][0])
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = float(old_hap["Mustrain"][1][0])
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    new.data["Histograms"][hist.name] = hap
    for atom in new.atoms():
        atom.data[atom.cia] = "I"
        atom.uiso = 0.02
        atom.refinement_flags = " "
    old_hap["Scale"] = [0.0, False]
    old_hap["Use"] = False
    for name in ("MnWO4", "Mn2WO5_P21c"):
        project.phase(name).data["Histograms"][hist.name]["Scale"][1] = True
    new.data["General"]["Cell"][0] = True
    reports = []
    for stage in ("cell", "repeat"):
        project.refine(makeBack=False)
        project.save()
        cov = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
        report = {
            "stage": stage,
            "rwp_percent": project.histogram(0).get_wR(),
            "gof": cov.get("GOF"),
            "max_shift_esd": cov.get("Max shft/sig"),
            "phases": rows(project),
        }
        reports.append(report)
        print(json.dumps(report))
    (args.output.parent / "summary.json").write_text(json.dumps(reports, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
