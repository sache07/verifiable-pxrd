#!/usr/bin/env python
"""Build a physically bounded, staged GSAS-II multiphase refinement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RESOURCE = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")


def cod_path(value: str) -> Path:
    if value.lower().endswith(".cif"):
        return Path(value)
    return RESOURCE / value[0] / value[1:3] / value[3:5] / f"{value}.cif"


def write_instrument(path: Path) -> None:
    path.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha1+2 Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def phase_rows(project: G2.G2Project) -> list[dict]:
    hist = project.histogram(0)
    rows, masses = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(max(0.0, mass_scale))
        rows.append(
            {
                "name": phase.name,
                "weight_fraction": None,
                "scale": float(hap["Scale"][0]),
                "cell": phase.get_cell(),
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "md_ratio": float(hap["Pref.Ori."][1]),
                "md_axis": list(hap["Pref.Ori."][3]),
            }
        )
    total = sum(masses)
    for row, value in zip(rows, masses):
        row["weight_fraction"] = value / total if total else 0.0
    return rows


def summary(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    rwp = hist.get_wR()
    shifts = np.asarray(cov.get("Lastshft", np.nan), float)
    max_shift = float(np.nanmax(np.abs(shifts))) if shifts.size else float("nan")
    result = {
        "stage": stage,
        "rwp_percent": float(rwp) if rwp is not None else float("nan"),
        "gof": float(cov.get("Rvals", {}).get("GOF", np.nan)),
        "instrument": {key: float(inst[key][1]) for key in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {
            key: float(sample[key][0])
            for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "phases": phase_rows(project),
        "frozen": project.get_Frozen(),
        "max_shift_esd": max_shift,
    }
    print(
        f"{stage:24s} Rwp={result['rwp_percent']:8.4f} "
        f"shift/esd={result['max_shift_esd']:9.3g} frozen={result['frozen']}"
    )
    return result


def refine(project: G2.G2Project, stages: list[dict], label: str) -> None:
    project.refine(makeBack=False)
    project.save()
    stages.append(summary(project, label))


def set_limits(project: G2.G2Project, phase_count: int) -> None:
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0),
        ":0:SurfRoughA": (0.0, 0.6),
        ":0:SurfRoughB": (0.0, 0.5),
    }
    for pid in range(phase_count):
        bounds[f"{pid}:0:Scale"] = (0.0, 1.0e6)
        bounds[f"{pid}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{pid}:0:Mustrain;i"] = (0.0, 8000.0)
        bounds[f"{pid}:0:MD"] = (0.7, 1.4)
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def set_inst_flags(hist, keys: set[str]) -> None:
    for key, value in hist.data["Instrument Parameters"][0].items():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = key in keys


def set_sample_flags(hist, keys: set[str]) -> None:
    for key, value in hist.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = key in keys


def build(output: Path, ids: list[str], names: list[str], fractions: list[float]) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    instrument_path = output.parent / "instrument.instprm"
    write_instrument(instrument_path)

    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(ROOT / "inputs" / "pattern.csv"), str(instrument_path), fmthint="comma")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]

    phases = []
    for source_id, name in zip(ids, names):
        phase = project.add_phase(str(cod_path(source_id)), phasename=name, histograms=[hist], fmthint="CIF")
        phases.append(phase)

    project.set_Controls("cycles", 8)
    for phase, fraction in zip(phases, fractions):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 * fraction / float(phase.data["General"]["Mass"]), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = 0.008
            atom.refinement_flags = " "

    x = np.asarray(hist.data["data"][1][0], float)
    y = np.asarray(hist.data["data"][1][1], float)
    b0 = float(np.percentile(y, 12))
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [b0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    set_inst_flags(hist, set())
    set_sample_flags(hist, set())
    project.save()
    project.index_ids()
    set_limits(project, len(phases))
    stages = [summary(project, "initial")]

    refine(project, stages, "background_scales")
    refine(project, stages, "background_scales_repeat")

    set_inst_flags(hist, {"Zero"})
    refine(project, stages, "zero")

    set_sample_flags(hist, {"Shift"})
    refine(project, stages, "zero_shift")

    set_inst_flags(hist, set())
    set_sample_flags(hist, set())
    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    refine(project, stages, "cells")

    for phase in phases:
        phase.data["General"]["Cell"][0] = False
    set_inst_flags(hist, {"W"})
    refine(project, stages, "instrument_W")

    set_inst_flags(hist, set())
    for phase in phases:
        phase.data["Histograms"][hist.name]["Size"][2][0] = True
    refine(project, stages, "phase_sizes")

    set_inst_flags(hist, {"U", "W", "X", "SH/L"})
    refine(project, stages, "instrument_profile")

    set_inst_flags(hist, set())
    for phase in phases:
        phase.data["Histograms"][hist.name]["Mustrain"][2][0] = True
    refine(project, stages, "phase_strain")

    for phase in phases:
        phase.data["General"]["Cell"][0] = True
    set_inst_flags(hist, {"Zero", "Polariz.", "U", "W", "X", "SH/L"})
    set_sample_flags(hist, {"Shift"})
    refine(project, stages, "joint_physical")
    refine(project, stages, "joint_repeat")

    (output.parent / "stages.json").write_text(json.dumps(stages, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--ids", nargs="+", required=True)
    parser.add_argument("--names", nargs="+", required=True)
    parser.add_argument("--fractions", nargs="+", type=float, required=True)
    args = parser.parse_args()
    if not (len(args.ids) == len(args.names) == len(args.fractions)):
        parser.error("--ids, --names and --fractions must have equal lengths")
    fractions = np.asarray(args.fractions, float)
    fractions /= fractions.sum()
    G2.SetPrintLevel("warn")
    build(args.output, args.ids, args.names, fractions.tolist())


if __name__ == "__main__":
    main()
