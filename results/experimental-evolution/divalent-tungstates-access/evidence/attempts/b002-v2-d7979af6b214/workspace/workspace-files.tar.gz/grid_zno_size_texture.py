#!/usr/bin/env python3
"""Fresh GSAS-II replay grid for ZnO size and March-Dollase texture."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/three_zno_cells_converged.gpx"
OUTPUT = ROOT / "trials/three_zno_full_grid.gpx"
RESULT = ROOT / "trials/zno_size_texture_grid.json"
SIZES = [0.04, 0.05, 0.07, 0.10, 0.15, 0.25, 0.50, 1.00, 1.50]
RATIOS = [0.70, 0.80, 0.90, 1.00, 1.10, 1.20, 1.30, 1.40]
AXES = [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]]


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUTPUT))
    freeze(project)
    hist = project.histograms()[0]
    zno = project.phase("ZnO_wurtzite")
    hap = zno.data["Histograms"][hist.name]
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][2] = False
    project.set_Controls("cycles", 0)

    rows = []
    best = None
    for axis in AXES:
        hap["Pref.Ori."][3] = axis
        for size in SIZES:
            hap["Size"][1][0] = size
            hap["Size"][1][1] = size
            for ratio in RATIOS:
                hap["Pref.Ori."][1] = ratio
                project.refine()
                rwp = float(hist.get_wR())
                row = {
                    "axis": axis,
                    "size_um": size,
                    "md_ratio": ratio,
                    "rwp_percent": rwp,
                }
                rows.append(row)
                if best is None or rwp < best[0]:
                    best = (rwp, list(axis), size, ratio)

    assert best is not None
    hap["Pref.Ori."][3] = best[1]
    hap["Size"][1][0] = best[2]
    hap["Size"][1][1] = best[2]
    hap["Pref.Ori."][1] = best[3]
    project.refine()
    replay = float(hist.get_wR())
    project.save(str(OUTPUT))
    result = {
        "source": str(SOURCE.relative_to(ROOT)),
        "project": str(OUTPUT.relative_to(ROOT)),
        "best": {
            "axis": best[1],
            "size_um": best[2],
            "md_ratio": best[3],
            "rwp_percent": replay,
        },
        "rows": rows,
    }
    RESULT.write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result["best"], sort_keys=True))


if __name__ == "__main__":
    main()
