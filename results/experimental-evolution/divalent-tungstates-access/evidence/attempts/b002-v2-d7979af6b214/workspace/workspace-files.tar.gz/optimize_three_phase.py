#!/usr/bin/env python3
"""Optimize and compare physical broadening/texture choices for ZnO."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import enable_intensity, freeze


ROOT = Path(__file__).resolve().parent
START = ROOT / "trials/common_three_zno.gpx"


def bounds(project) -> None:
    project.index_ids()
    hist = project.histograms()[0]
    for phase in project.phases():
        project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{phase.id}:{hist.id}:Size;i")
        project.set_Controls("parmMin", 300.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{phase.id}:{hist.id}:Mustrain;i")
        project.set_Controls("parmMin", 0.7, variable=f"{phase.id}:{hist.id}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{phase.id}:{hist.id}:MD")
    project.set_Controls("parmMin", 0.5, variable=f":{hist.id}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hist.id}:Polariz.")


def snapshot(project, label: str, path: Path) -> dict:
    hist = project.histograms()[0]
    row = {
        "stage": label,
        "project": str(path.relative_to(ROOT)),
        "rwp_percent": float(hist.get_wR()),
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain": float(hap["Mustrain"][1][0]),
            "md_ratio": float(hap["Pref.Ori."][1]),
            "md_axis": list(hap["Pref.Ori."][3]),
        })
    return row


def run(source: Path, output: Path, label: str, configure, cycles: int = 24) -> dict:
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    freeze(project)
    bounds(project)
    configure(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    freeze(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    row = snapshot(project, label, output)
    print(label, row["rwp_percent"])
    return row


def config_cells(project) -> None:
    enable_intensity(project)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def config_zno_size(project) -> None:
    enable_intensity(project)
    zno = project.phase("ZnO_wurtzite")
    zno.data["Histograms"][project.histograms()[0].name]["Size"][2][0] = True


def config_zno_size_strain(project) -> None:
    config_zno_size(project)
    zno = project.phase("ZnO_wurtzite")
    hap = zno.data["Histograms"][project.histograms()[0].name]
    hap["Mustrain"][1][0] = max(300.0, hap["Mustrain"][1][0])
    hap["Mustrain"][2][0] = True


def config_texture(axis) -> callable:
    def inner(project) -> None:
        enable_intensity(project)
        zno = project.phase("ZnO_wurtzite")
        hap = zno.data["Histograms"][project.histograms()[0].name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
    return inner


def main() -> None:
    G2.SetPrintLevel("warn")
    log = []
    converged = ROOT / "trials/three_zno_cells_converged.gpx"
    log.append(run(START, converged, "cells_converged", config_cells, cycles=36))

    size = ROOT / "trials/three_zno_size.gpx"
    log.append(run(converged, size, "zno_size", config_zno_size, cycles=24))
    size_strain = ROOT / "trials/three_zno_size_strain.gpx"
    log.append(run(converged, size_strain, "zno_size_strain", config_zno_size_strain, cycles=28))

    # Select the lower-Rwp physical broadening branch for common-state texture tests.
    broad = min(log[-2:], key=lambda x: x["rwp_percent"])
    broad_path = ROOT / broad["project"]
    for axis in ([0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]):
        tag = "".join(str(x) for x in axis)
        out = ROOT / "trials" / f"three_zno_po_{tag}.gpx"
        log.append(run(broad_path, out, f"zno_po_{tag}", config_texture(axis), cycles=24))

    (ROOT / "trials/optimize_three_phase.json").write_text(
        json.dumps(log, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
