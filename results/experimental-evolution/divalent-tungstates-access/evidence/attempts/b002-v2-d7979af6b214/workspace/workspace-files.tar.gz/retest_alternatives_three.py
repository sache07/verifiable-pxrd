#!/usr/bin/env python3
"""Retest same-stoichiometry alternatives in the refined three-phase state."""

from __future__ import annotations

import json

import prototype_common_grid as grid


def main() -> None:
    grid.G2.SetPrintLevel("warn")
    grid.BASE = grid.ROOT / "trials/three_zno_grid_refined.gpx"
    results = [grid.screen(spec) for spec in grid.CANDIDATES[:2]]
    path = grid.ROOT / "trials/prototype_retest_three.json"
    path.write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")
    for row in results:
        print(row["name"], "scale=", row["best_scale"],
              "Rwp=", row["best_rwp_percent"], "collapsed=", row["scale_collapsed"])


if __name__ == "__main__":
    main()
