#!/usr/bin/env python3
"""Build chemically targeted prototype-transfer CIFs for this Zn/W/O pattern."""

from pathlib import Path
import warnings

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod_path(record_id: str) -> Path:
    return ROOT / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def transfer(record_id: str, substitutions: dict[str, str], output: str) -> None:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(cod_path(record_id), primitive=False)
    structure.remove_oxidation_states()
    structure.replace_species(substitutions)
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    CifWriter(structure, symprec=1e-3, significant_figures=10).write_file(output)
    print(output, structure.composition, structure.get_space_group_info(symprec=1e-3))


def main() -> None:
    # Wolframite: two-element transfer from CoMoO4, with a cell and framework
    # already very close to ambient ZnWO4.
    transfer("7205001", {"Co": "Zn", "Mo": "W"}, "candidates/znwo4_wolframite.cif")
    # Independent wolframite transfer retained to test coordinate-model sensitivity.
    transfer("2100243", {"Mn": "Zn", "Re": "W"}, "candidates/znwo4_wolframite_mnreo4.cif")
    # Distinct same-stoichiometry alternatives required for prototype screening.
    transfer("1549132", {"Cd": "Zn"}, "candidates/znwo4_scheelite.cif")
    transfer("1528282", {"Mo": "W"}, "candidates/znwo4_triclinic.cif")


if __name__ == "__main__":
    main()
