#!/usr/bin/env python3
"""Ordinary refinement from the selected bounded physical-calibration state."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import enable_intensity, freeze
from optimize_three_phase import bounds, snapshot


ROOT = Path(__file__).resolve().parent
START = ROOT / "trials/physical_wo3_O_descent.gpx"


def clear_frozen(project) -> None:
    frozen = project.data["Controls"]["data"].setdefault("parmFrozen", {})
    frozen["FrozenList"] = []


def common_bounds(project) -> None:
    bounds(project)
    hist = project.histograms()[0]
    wo3 = project.phase("WO3_monoclinic")
    project.set_Controls("parmMin", 300.0, variable=f"{wo3.id}:{hist.id}:Mustrain;a")
    project.set_Controls("parmMax", 8000.0, variable=f"{wo3.id}:{hist.id}:Mustrain;a")
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:U")
    project.set_Controls("parmMax", 40.0, variable=f":{hist.id}:U")
    project.set_Controls("parmMin", 0.005, variable=f":{hist.id}:SH/L")
    project.set_Controls("parmMax", 0.10, variable=f":{hist.id}:SH/L")
    project.set_Controls("parmMin", -800.0, variable=f":{hist.id}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hist.id}:Shift")


def enable_all_intensity(project) -> None:
    enable_intensity(project)
    hist = project.histograms()[0]
    project.phase("ZnO_wurtzite").data["Histograms"][hist.name]["Pref.Ori."][2] = True


def config_cells_shift(project) -> None:
    enable_all_intensity(project)
    hist = project.histograms()[0]
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def config_profile(project) -> None:
    enable_all_intensity(project)
    hist = project.histograms()[0]
    hist.InstrumentParameters["U"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    znwo4 = project.phase("ZnWO4_wolframite")
    wo3 = project.phase("WO3_monoclinic")
    znwo4.data["Histograms"][hist.name]["Size"][2][0] = True
    hap = wo3.data["Histograms"][hist.name]
    hap["Size"][2][0] = True
    hap["Mustrain"][2][0] = True
    if hap["Mustrain"][0] == "uniaxial":
        hap["Mustrain"][2][1] = True


def config_zn_coordinates(project) -> None:
    phase = project.phase("ZnWO4_wolframite")
    for atom in phase.atoms():
        atom.refinement_flags = "X"


def run(source: Path, output: Path, label: str, configure, iterations=1, cycles=48) -> dict:
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    for _ in range(iterations):
        freeze(project)
        clear_frozen(project)
        common_bounds(project)
        configure(project)
        project.set_Controls("cycles", cycles)
        project.refine()
    freeze(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    row = snapshot(project, label, output)
    hist = project.histograms()[0]
    row["instrument"] = {
        k: float(hist.InstrumentParameters[k][1])
        for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
    }
    row["sample_shift_um"] = float(hist.SampleParameters["Shift"][0])
    print(label, row["rwp_percent"])
    return row


def main() -> None:
    G2.SetPrintLevel("warn")
    paths = [
        ROOT / "trials/final_physical_cells.gpx",
        ROOT / "trials/final_physical_profile.gpx",
        ROOT / "trials/final_physical_zncoords.gpx",
        ROOT / "trials/final_physical_refined.gpx",
    ]
    log = [
        run(START, paths[0], "cells_shift", config_cells_shift, iterations=2, cycles=72),
        run(paths[0], paths[1], "profile", config_profile, iterations=2, cycles=48),
        run(paths[1], paths[2], "zn_coordinates", config_zn_coordinates, iterations=2, cycles=48),
        run(paths[2], paths[3], "final_cells_shift", config_cells_shift, iterations=2, cycles=72),
    ]
    (ROOT / "trials/finalize_physical_model.json").write_text(
        json.dumps(log, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
