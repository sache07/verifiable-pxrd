#!/usr/bin/env python3
"""Write neutral-species CIFs for GSAS-II replacement tests."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)
IDS = ["1004057", "1521532", "1521533", "1563541", "2311041", "2106293", "2107312"]


def cod(record_id: str) -> Path:
    return LIB / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def main() -> None:
    for rid in IDS:
        structure = Structure.from_file(cod(rid), primitive=False)
        structure.remove_oxidation_states()
        out = ROOT / "candidates" / f"wo3_{rid}_neutral.cif"
        CifWriter(structure, symprec=1e-4, significant_figures=10).write_file(out)
        print(out, structure.composition, structure.get_space_group_info(symprec=1e-3))


if __name__ == "__main__":
    main()
