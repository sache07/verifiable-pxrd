#!/usr/bin/env python3
"""Run the full ZnO size/texture replay grid from the final physical state."""

import grid_zno_size_texture as grid


if __name__ == "__main__":
    grid.SOURCE = grid.ROOT / "trials/final_physical_refined.gpx"
    grid.OUTPUT = grid.ROOT / "trials/final_zno_full_grid.gpx"
    grid.RESULT = grid.ROOT / "trials/final_zno_full_grid.json"
    grid.main()
