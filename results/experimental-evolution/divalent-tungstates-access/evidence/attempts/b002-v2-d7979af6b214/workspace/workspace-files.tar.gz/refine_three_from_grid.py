#!/usr/bin/env python3
"""Resume ordinary refinement from the best fresh ZnO grid state."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import enable_intensity, freeze
from optimize_three_phase import bounds, snapshot


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/three_zno_full_grid.gpx"
OUT1 = ROOT / "trials/three_zno_grid_intensity_cells.gpx"
OUT2 = ROOT / "trials/three_zno_grid_profile.gpx"
OUT3 = ROOT / "trials/three_zno_grid_refined.gpx"


def enable_all_intensity(project) -> None:
    enable_intensity(project)
    hist = project.histograms()[0]
    project.phase("ZnO_wurtzite").data["Histograms"][hist.name]["Pref.Ori."][2] = True


def replay(project) -> None:
    freeze(project)
    project.set_Controls("cycles", 0)
    project.refine()


def stage(source: Path, output: Path, label: str, configure, cycles: int) -> dict:
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    freeze(project)
    bounds(project)
    hist = project.histograms()[0]
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:U")
    project.set_Controls("parmMax", 40.0, variable=f":{hist.id}:U")
    project.set_Controls("parmMin", 0.005, variable=f":{hist.id}:SH/L")
    project.set_Controls("parmMax", 0.10, variable=f":{hist.id}:SH/L")
    configure(project)
    project.set_Controls("cycles", cycles)
    project.refine()
    replay(project)
    project.save(str(output))
    row = snapshot(project, label, output)
    row["instrument"] = {
        k: float(hist.InstrumentParameters[k][1])
        for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L")
    }
    print(label, row["rwp_percent"])
    return row


def config_cells(project) -> None:
    enable_all_intensity(project)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True


def config_profile(project) -> None:
    enable_all_intensity(project)
    hist = project.histograms()[0]
    hist.data["Instrument Parameters"][0]["U"][2] = True
    hist.data["Instrument Parameters"][0]["SH/L"][2] = True
    znwo4, wo3, _ = project.phases()
    h0 = znwo4.data["Histograms"][hist.name]
    h1 = wo3.data["Histograms"][hist.name]
    h0["Size"][2][0] = True
    h1["Size"][2][0] = True
    h1["Mustrain"][2][0] = True


def main() -> None:
    G2.SetPrintLevel("warn")
    log = [
        stage(SOURCE, OUT1, "grid_intensity_cells", config_cells, 40),
        stage(OUT1, OUT2, "profile", config_profile, 36),
        stage(OUT2, OUT3, "final_cells_intensity", config_cells, 36),
    ]
    (ROOT / "trials/refine_three_from_grid.json").write_text(
        json.dumps(log, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
