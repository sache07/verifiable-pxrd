#!/usr/bin/env python3
"""Common-state full replacements for the physically suspect old WO3 model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/angle_ridge_p0d25.gpx"
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)
IDS = ["1004057", "1521532", "1521533", "1563541", "2311041", "2106293", "2107312"]


def cod(record_id: str) -> Path:
    return LIB / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def one(rid: str) -> dict:
    out = ROOT / "trials" / f"replace_wo3_{rid}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(out))
    freeze(project)
    hist = project.histograms()[0]
    old = project.phase("WO3_monoclinic")
    old_hap = old.data["Histograms"][hist.name]
    old_mass_scale = old.data["General"]["Mass"] * old_hap["Scale"][0]
    old_hap["Scale"] = [0.0, False]
    phase = project.add_phase(
        str(ROOT / "candidates" / f"wo3_{rid}_neutral.cif"),
        phasename=f"WO3_replacement_{rid}", histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [old_mass_scale / phase.data["General"]["Mass"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = old_hap["Size"][1][0]
    hap["Size"][1][1] = old_hap["Size"][1][0]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 900.0
    hap["Mustrain"][1][1] = 900.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = old_hap["Pref.Ori."][1]
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = list(old_hap["Pref.Ori."][3])
    phase.data["General"]["Cell"][0] = True
    project.index_ids()
    project.set_Controls("parmMin", 0.0, variable=f"{phase.id}:{hist.id}:Scale")
    for _ in range(2):
        project.set_Controls("cycles", 48)
        project.refine()
        # Cell and scale remain the only varied terms for the next iteration.
        freeze(project)
        phase.data["General"]["Cell"][0] = True
        hap["Scale"][1] = True
    freeze(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(out))
    masses = [
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ]
    return {
        "record_id": rid,
        "status": "completed",
        "project": str(out.relative_to(ROOT)),
        "rwp_percent": float(hist.get_wR()),
        "scale": float(hap["Scale"][0]),
        "weight_fraction": float(masses[-1] / sum(masses)),
        "cell": phase.get_cell(),
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    rows = []
    for rid in IDS:
        try:
            rows.append(one(rid))
        except Exception as exc:
            rows.append({"record_id": rid, "status": "unknown_failed_or_aborted",
                         "error": f"{type(exc).__name__}: {exc}"})
    rows.sort(key=lambda x: x.get("rwp_percent", float("inf")))
    (ROOT / "trials/wo3_replacements.json").write_text(
        json.dumps(rows, indent=2, allow_nan=False) + "\n"
    )
    for row in rows:
        print(row)


if __name__ == "__main__":
    main()
