#!/usr/bin/env python3
"""Fresh sequential full grids for triclinic WO3 and ZnO texture/size."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/triclinic_wo3_physical_refined.gpx"
OUTPUT = ROOT / "trials/triclinic_final_profile_grid.gpx"
RATIOS = [0.70, 0.80, 0.90, 1.00, 1.10, 1.20, 1.30, 1.40]
FINE_RATIOS = [round(0.70 + 0.05 * i, 2) for i in range(15)]
SIZES = [0.04, 0.05, 0.07, 0.09, 0.12, 0.20, 0.50, 1.00, 1.50]
AXES_WO3 = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]
AXES_ZNO = [[0, 0, 1], [1, 0, 0], [1, 1, 0], [1, 1, 1]]


def replay(project) -> float:
    project.set_Controls("cycles", 0)
    project.refine()
    return float(project.histograms()[0].get_wR())


def axis_ratio_grid(project, phase, axes, ratios, label, rows) -> tuple[list[int], float, float]:
    hist = project.histograms()[0]
    hap = phase.data["Histograms"][hist.name]
    best = None
    for axis in axes:
        hap["Pref.Ori."][3] = list(axis)
        for ratio in ratios:
            hap["Pref.Ori."][1] = ratio
            rwp = replay(project)
            row = {"grid": label, "axis": list(axis), "md_ratio": ratio,
                   "size_um": float(hap["Size"][1][0]), "rwp_percent": rwp}
            rows.append(row)
            if best is None or rwp < best[0]:
                best = (rwp, list(axis), ratio)
    assert best is not None
    hap["Pref.Ori."][3] = best[1]
    hap["Pref.Ori."][1] = best[2]
    replay(project)
    return best[1], best[2], best[0]


def size_grid(project, phase, sizes, label, rows) -> tuple[float, float]:
    hist = project.histograms()[0]
    hap = phase.data["Histograms"][hist.name]
    best = None
    for size in sizes:
        hap["Size"][1][0] = size
        hap["Size"][1][1] = size
        rwp = replay(project)
        row = {"grid": label, "axis": list(hap["Pref.Ori."][3]),
               "md_ratio": float(hap["Pref.Ori."][1]), "size_um": size,
               "rwp_percent": rwp}
        rows.append(row)
        if best is None or rwp < best[0]:
            best = (rwp, size)
    assert best is not None
    hap["Size"][1][0] = best[1]
    hap["Size"][1][1] = best[1]
    replay(project)
    return best[1], best[0]


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUTPUT))
    freeze(project)
    old = project.phase("WO3_monoclinic")
    old.data["Histograms"][project.histograms()[0].name]["Use"] = False
    wo3 = project.phase("WO3_replacement_2106293")
    zno = project.phase("ZnO_wurtzite")
    rows = []

    axis_ratio_grid(project, wo3, AXES_WO3, RATIOS, "wo3_axis_ratio", rows)
    size_grid(project, wo3, SIZES, "wo3_size", rows)
    # Refine the ratio grid spacing at the selected WO3 axis/size.
    axis_ratio_grid(project, wo3, [wo3.data["Histograms"][project.histograms()[0].name]["Pref.Ori."][3]],
                    FINE_RATIOS, "wo3_ratio_fine", rows)

    axis_ratio_grid(project, zno, AXES_ZNO, RATIOS, "zno_axis_ratio", rows)
    size_grid(project, zno, SIZES, "zno_size", rows)
    axis_ratio_grid(project, zno, [zno.data["Histograms"][project.histograms()[0].name]["Pref.Ori."][3]],
                    FINE_RATIOS, "zno_ratio_fine", rows)

    # Replay WO3 once more after the ZnO choice to close the sequential loop.
    axis_ratio_grid(project, wo3, AXES_WO3, RATIOS, "wo3_axis_ratio_recheck", rows)
    project.save(str(OUTPUT))
    hist = project.histograms()[0]
    result = {
        "source": str(SOURCE.relative_to(ROOT)),
        "project": str(OUTPUT.relative_to(ROOT)),
        "rwp_percent": float(hist.get_wR()),
        "wo3": {
            "size_um": float(wo3.data["Histograms"][hist.name]["Size"][1][0]),
            "md_ratio": float(wo3.data["Histograms"][hist.name]["Pref.Ori."][1]),
            "axis": list(wo3.data["Histograms"][hist.name]["Pref.Ori."][3]),
        },
        "zno": {
            "size_um": float(zno.data["Histograms"][hist.name]["Size"][1][0]),
            "md_ratio": float(zno.data["Histograms"][hist.name]["Pref.Ori."][1]),
            "axis": list(zno.data["Histograms"][hist.name]["Pref.Ori."][3]),
        },
        "rows": rows,
    }
    (ROOT / "trials/triclinic_final_profile_grid.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps({k: v for k, v in result.items() if k != "rows"}, indent=2))


if __name__ == "__main__":
    main()
