#!/usr/bin/env python3
"""Remove the disabled WO3 trial object and rename the selected phase cleanly."""

from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/triclinic_postgrid_final.gpx"
OUTPUT = ROOT / "trials/triclinic_clean.gpx"
OLD = "WO3_monoclinic"
SELECTED = "WO3_replacement_2106293"
NEW = "WO3_triclinic"


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUTPUT))
    hist = project.histograms()[0]
    phases = project.data["Phases"]
    if OLD in phases:
        del phases[OLD]
    selected = phases.pop(SELECTED)
    selected["General"]["Name"] = NEW
    phases[NEW] = selected

    phase_names = project.names[-1]
    phase_names[:] = [name for name in phase_names if name != OLD]
    phase_names[phase_names.index(SELECTED)] = NEW
    reflections = hist.data["Reflection Lists"]
    reflections.pop(OLD, None)
    if SELECTED in reflections:
        reflections[NEW] = reflections.pop(SELECTED)

    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.data["Covariance"]["data"] = {}
    project.save(str(OUTPUT))

    # Reload to force GSAS-II to rebuild phase/histogram IDs and reflections.
    clean = G2.G2Project(gpxfile=str(OUTPUT))
    clean.update_ids()
    freeze(clean)
    clean.set_Controls("cycles", 0)
    clean.refine()
    clean.save(str(OUTPUT))
    print("phases", [phase.name for phase in clean.phases()])
    print("Rwp", clean.histograms()[0].get_wR())


if __name__ == "__main__":
    main()
