#!/usr/bin/env python3
"""Profile the bounded zero/shift ridge with cells reoptimized at each zero."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze
from refine_three_from_grid import config_cells


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/angle_physical_shift_refine2.gpx"
ZEROS = [-0.10, -0.05, 0.0, 0.05, 0.10, 0.15, 0.20, 0.25]


def one(zero: float) -> dict:
    tag = f"{zero:+.2f}".replace("+", "p").replace("-", "m").replace(".", "d")
    out = ROOT / "trials" / f"angle_ridge_{tag}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(out))
    hist = project.histograms()[0]
    # Preserve approximately the same low-angle correction as the converged
    # +0.25 deg / -235 um state before reoptimizing the cells and shift.
    hist.InstrumentParameters["Zero"][1] = zero
    hist.InstrumentParameters["Zero"][2] = False
    hist.SampleParameters["Shift"] = [-235.3565 - (0.25 - zero) * 1400.0, False]
    for _ in range(2):
        freeze(project)
        config_cells(project)
        hist.SampleParameters["Shift"][1] = True
        project.set_Controls("parmMin", -800.0, variable=f":{hist.id}:Shift")
        project.set_Controls("parmMax", 800.0, variable=f":{hist.id}:Shift")
        project.set_Controls("cycles", 72)
        project.refine()
    freeze(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(out))
    return {
        "zero_deg": zero,
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "rwp_percent": float(hist.get_wR()),
        "project": str(out.relative_to(ROOT)),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    rows = [one(zero) for zero in ZEROS]
    rows.sort(key=lambda x: x["rwp_percent"])
    (ROOT / "trials/physical_angle_ridge.json").write_text(
        json.dumps(rows, indent=2, allow_nan=False) + "\n"
    )
    for row in rows:
        print(row["zero_deg"], row["shift_um"], row["rwp_percent"])


if __name__ == "__main__":
    main()
