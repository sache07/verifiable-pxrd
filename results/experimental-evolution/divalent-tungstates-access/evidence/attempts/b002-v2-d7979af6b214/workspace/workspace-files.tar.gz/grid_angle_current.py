#!/usr/bin/env python3
"""Fresh physical zero/displacement grid from the current structural model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/wo3_uniax_001_iter3.gpx"
OUTPUT = ROOT / "trials/angle_current_grid_best.gpx"
ZEROS = [-0.25, -0.125, 0.0, 0.125, 0.25]
SHIFTS = [-800.0, -600.0, -400.0, -200.0, 0.0, 200.0, 400.0, 600.0, 800.0]


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(OUTPUT))
    freeze(project)
    hist = project.histograms()[0]
    rows = []
    best = None
    for zero in ZEROS:
        hist.InstrumentParameters["Zero"][1] = zero
        hist.InstrumentParameters["Zero"][2] = False
        for shift in SHIFTS:
            hist.SampleParameters["Shift"] = [shift, False]
            project.set_Controls("cycles", 0)
            project.refine()
            rwp = float(hist.get_wR())
            rows.append({"zero_deg": zero, "shift_um": shift, "rwp_percent": rwp})
            if best is None or rwp < best[0]:
                best = (rwp, zero, shift)
    assert best is not None
    hist.InstrumentParameters["Zero"][1] = best[1]
    hist.SampleParameters["Shift"] = [best[2], False]
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(OUTPUT))
    result = {
        "source": str(SOURCE.relative_to(ROOT)),
        "project": str(OUTPUT.relative_to(ROOT)),
        "best": {"rwp_percent": float(hist.get_wR()), "zero_deg": best[1], "shift_um": best[2]},
        "rows": rows,
    }
    (ROOT / "trials/angle_current_grid.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(result["best"])


if __name__ == "__main__":
    main()
