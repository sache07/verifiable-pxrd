#!/usr/bin/env python3
"""Screen additional phases in one frozen multiphase GSAS-II state.

The candidate contribution is evaluated on a nonnegative fixed-scale grid.
Only the candidate cell is varied, on an explicit finite grid; the accepted
phases, background, instrument, texture and all other nuisance values remain
exactly those in trials/common_best_clean.gpx.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
BASE = ROOT / "trials/common_best_clean.gpx"
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)


def cod(record_id: str) -> Path:
    return LIB / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


CANDIDATES = [
    {
        "name": "ZnWO4_scheelite",
        "cif": ROOT / "candidates/znwo4_scheelite.cif",
        # CdWO4 -> ZnWO4 transfer requires a notably smaller cell. Search a
        # broad tetragonal a/c grid around the transferred reference.
        "cells": [(fa, fa, fc) for fa in np.linspace(0.86, 1.02, 9)
                  for fc in np.linspace(0.88, 1.04, 9)],
    },
    {
        "name": "ZnWO4_triclinic",
        "cif": ROOT / "candidates/znwo4_triclinic.cif",
        # ZnMoO4 -> ZnWO4: retain the triclinic metric shape and search its
        # volume over more than the expected substitution mismatch.
        "cells": [(f, f, f) for f in np.linspace(0.94, 1.06, 13)],
    },
    {
        "name": "ZnO_wurtzite_precursor",
        "cif": cod("9004178"),
        # Same chemistry as the precursor; this spans normal reference and
        # synthesis-dependent lattice variation by a very generous margin.
        "cells": [(f, f, f) for f in np.linspace(0.97, 1.03, 13)],
    },
]


def set_cell(phase, cell0, factors) -> None:
    a, b, c, al, be, ga = cell0
    cell = [a * factors[0], b * factors[1], c * factors[2], al, be, ga]
    phase.data["General"]["Cell"][1:7] = cell
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def fixed_replay(project, phase, scale: float) -> tuple[float, np.ndarray]:
    hist = project.histograms()[0]
    phase.data["Histograms"][hist.name]["Scale"] = [float(scale), False]
    project.set_Controls("cycles", 0)
    project.refine()
    return float(hist.get_wR()), np.asarray(hist.data["data"][1][3], dtype=float).copy()


def profile_rwp(obs: np.ndarray, weights: np.ndarray, calc: np.ndarray) -> float:
    """GSAS-II Rwp for this full-range, unmasked histogram."""
    return float(100.0 * np.sqrt(
        np.sum(weights * (obs - calc) ** 2) / np.sum(weights * obs ** 2)
    ))


def screen(spec: dict) -> dict:
    out = ROOT / "trials" / f"grid_{spec['name']}.gpx"
    project = G2.G2Project(gpxfile=str(BASE))
    # Redirect autosaves before adding a phase, preserving the common source.
    project.save(str(out))
    hist = project.histograms()[0]
    candidate = project.add_phase(
        str(spec["cif"]), phasename=spec["name"], histograms=[hist], fmthint="CIF"
    )
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [0.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.1
    hap["Size"][1][1] = 0.1
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

    cell_dict = candidate.get_cell()
    cell0 = [cell_dict[k] for k in (
        "length_a", "length_b", "length_c", "angle_alpha", "angle_beta", "angle_gamma"
    )]
    obs = np.asarray(hist.data["data"][1][1], dtype=float)
    weights = np.asarray(hist.data["data"][1][2], dtype=float)
    trials = []
    best = None

    for factors in spec["cells"]:
        set_cell(candidate, cell0, factors)
        r0, calc0 = fixed_replay(project, candidate, 0.0)
        _, calc1 = fixed_replay(project, candidate, 1.0)
        unit = calc1 - calc0
        denom = float(np.sum(weights * unit * unit))
        numer = float(np.sum(weights * unit * (obs - calc0)))
        projected = max(0.0, numer / denom) if denom > 0 else 0.0

        # Evaluate the boundary and a fixed nonnegative scale grid surrounding
        # the projected least-squares optimum. If it projects to zero, retain
        # explicit positive probes so a boundary result is verifiable.
        if projected > 0:
            scales = [0.0, 0.25 * projected, 0.5 * projected,
                      projected, 1.5 * projected, 2.0 * projected]
        else:
            scales = [0.0, 0.01, 0.05, 0.1, 0.5, 1.0]
        rows = []
        for scale in scales:
            # With extinction disabled, a HAP scale multiplies the candidate
            # profile exactly. Evaluate every fixed scale from the two fresh
            # GSAS-II profiles above; the selected endpoint is replayed below.
            rwp = profile_rwp(obs, weights, calc0 + scale * unit)
            rows.append({"scale": float(scale), "rwp_percent": rwp})
            item = (rwp, factors, scale)
            if best is None or item[0] < best[0]:
                best = item
        trials.append({
            "cell_factors": [float(x) for x in factors],
            "projected_nonnegative_scale": float(projected),
            "scale_grid": rows,
            "rwp_at_zero_percent": r0,
        })

    assert best is not None
    # Leave the trial project at its best fresh-replayed grid point.
    set_cell(candidate, cell0, best[1])
    final_rwp, _ = fixed_replay(project, candidate, best[2])
    # Also replay a strictly positive scale at the selected metric, providing
    # a direct check of the boundary direction when the optimum is zero.
    positive_scale = 0.01 if best[2] == 0 else max(0.01, 0.25 * best[2])
    positive_rwp, _ = fixed_replay(project, candidate, positive_scale)
    final_rwp, _ = fixed_replay(project, candidate, best[2])
    project.save(str(out))
    return {
        "name": spec["name"],
        "cif": str(Path(spec["cif"]).resolve()),
        "common_source": str(BASE.relative_to(ROOT)),
        "grid_project": str(out.relative_to(ROOT)),
        "source_cell": cell_dict,
        "best_rwp_percent": final_rwp,
        "best_cell_factors": [float(x) for x in best[1]],
        "best_scale": float(best[2]),
        "scale_collapsed": bool(best[2] == 0.0),
        "positive_scale_replay": {
            "scale": float(positive_scale),
            "rwp_percent": float(positive_rwp),
        },
        "trials": trials,
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    results = [screen(spec) for spec in CANDIDATES]
    path = ROOT / "trials/prototype_common_grid.json"
    path.write_text(json.dumps(results, indent=2, allow_nan=False) + "\n")
    for row in results:
        print(row["name"], "scale=", row["best_scale"],
              "Rwp=", row["best_rwp_percent"], "collapsed=", row["scale_collapsed"])


if __name__ == "__main__":
    main()
