#!/usr/bin/env python3
"""Common-state nonnegative-scale screen of ordinary W-O and Zn-O references."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/finalcycle_refined.gpx"
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)
INDEX = LIB.parent / "index.json.gz"
EXCLUDE = {"1528915", "9004178"}


def cod(record_id: str) -> Path:
    return LIB / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def replay(project, phase, scale: float) -> tuple[float, np.ndarray]:
    hist = project.histograms()[0]
    phase.data["Histograms"][hist.name]["Scale"] = [float(scale), False]
    project.set_Controls("cycles", 0)
    project.refine()
    return float(hist.get_wR()), np.asarray(hist.data["data"][1][3], float).copy()


def one(row) -> dict:
    formula, rid, sg, quality = row
    out = ROOT / ".tmp" / f"ordinary_{rid}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(out))
    freeze(project)
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(cod(rid)), phasename=f"candidate_{rid}", histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [0.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.1
    hap["Size"][1][1] = 0.1
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False

    r0, calc0 = replay(project, phase, 0.0)
    _, calc1 = replay(project, phase, 1.0)
    obs = np.asarray(hist.data["data"][1][1], float)
    weights = np.asarray(hist.data["data"][1][2], float)
    unit = calc1 - calc0
    denom = float(np.sum(weights * unit * unit))
    numer = float(np.sum(weights * unit * (obs - calc0)))
    scale = max(0.0, numer / denom) if denom > 0 else 0.0
    rwp, _ = replay(project, phase, scale)
    masses = [
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ]
    project.save(str(out))
    return {
        "formula": formula,
        "record_id": rid,
        "space_group_number_index": sg,
        "index_quality": quality,
        "status": "completed",
        "source_cif": str(cod(rid)),
        "trial_project": str(out.relative_to(ROOT)),
        "rwp_zero_percent": r0,
        "rwp_projected_percent": rwp,
        "delta_rwp_percent": rwp - r0,
        "projected_scale": scale,
        "projected_weight_fraction": masses[-1] / sum(masses) if sum(masses) > 0 else None,
        "cell": phase.get_cell(),
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    (ROOT / ".tmp").mkdir(exist_ok=True)
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    rows = []
    seen = set()
    for key in ("O-W", "O-Zn"):
        for row in index.get(key, []):
            if row[1] in EXCLUDE or row[1] in seen:
                continue
            seen.add(row[1])
            try:
                rows.append(one(row))
            except Exception as exc:
                rows.append({
                    "formula": row[0],
                    "record_id": row[1],
                    "space_group_number_index": row[2],
                    "index_quality": row[3],
                    "status": "unknown_failed_or_aborted",
                    "error": f"{type(exc).__name__}: {exc}",
                })
    rows.sort(key=lambda x: x.get("rwp_projected_percent", float("inf")))
    path = ROOT / "trials/ordinary_reference_screen.json"
    path.write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")
    for row in rows:
        print(row["record_id"], row["formula"], row["status"],
              row.get("rwp_projected_percent"), row.get("projected_weight_fraction"))


if __name__ == "__main__":
    main()
