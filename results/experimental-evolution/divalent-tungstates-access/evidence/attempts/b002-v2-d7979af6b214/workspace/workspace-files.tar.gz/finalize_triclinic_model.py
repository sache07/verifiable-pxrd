#!/usr/bin/env python3
"""Ordinary refinement from the selected triclinic-WO3 profile grid."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze
from optimize_three_phase import bounds, snapshot


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/triclinic_final_profile_grid.gpx"
WO3 = "WO3_replacement_2106293"


def prep(project) -> None:
    freeze(project)
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    bounds(project)
    hist = project.histograms()[0]
    project.set_Controls("parmMin", 0.0, variable=f":{hist.id}:U")
    project.set_Controls("parmMax", 40.0, variable=f":{hist.id}:U")
    project.set_Controls("parmMin", 0.005, variable=f":{hist.id}:SH/L")
    project.set_Controls("parmMax", 0.10, variable=f":{hist.id}:SH/L")
    project.set_Controls("parmMin", -800.0, variable=f":{hist.id}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hist.id}:Shift")
    # The physical comparison selected zero microstrain for all three phases.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap.get("Use", True):
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]


def enable_intensity(project, cells=False, shift=False) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    hist.InstrumentParameters["Polariz."][2] = True
    hist.SampleParameters["Shift"][1] = bool(shift)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if not hap.get("Use", True) or hap["Scale"][0] <= 1e-10:
            continue
        hap["Scale"][1] = True
        hap["Pref.Ori."][2] = True
        phase.data["General"]["Cell"][0] = bool(cells)


def config_cells(project) -> None:
    enable_intensity(project, cells=True, shift=True)


def config_profile(project) -> None:
    enable_intensity(project)
    hist = project.histograms()[0]
    hist.InstrumentParameters["U"][2] = True
    hist.InstrumentParameters["SH/L"][2] = True
    project.phase("ZnWO4_wolframite").data["Histograms"][hist.name]["Size"][2][0] = True
    project.phase(WO3).data["Histograms"][hist.name]["Size"][2][0] = True


def config_zncoords(project) -> None:
    for atom in project.phase("ZnWO4_wolframite").atoms():
        atom.refinement_flags = "X"


def run(source: Path, output: Path, label: str, configure, iterations=2, cycles=48) -> dict:
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(output))
    hist = project.histograms()[0]
    project.phase("WO3_monoclinic").data["Histograms"][hist.name]["Use"] = False
    for _ in range(iterations):
        prep(project)
        configure(project)
        project.set_Controls("cycles", cycles)
        project.refine()
    prep(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(output))
    row = snapshot(project, label, output)
    row["sample_shift_um"] = float(hist.SampleParameters["Shift"][0])
    row["zero_deg"] = float(hist.InstrumentParameters["Zero"][1])
    print(label, row["rwp_percent"])
    return row


def main() -> None:
    G2.SetPrintLevel("warn")
    p1 = ROOT / "trials/triclinic_postgrid_cells.gpx"
    p2 = ROOT / "trials/triclinic_postgrid_profile.gpx"
    p3 = ROOT / "trials/triclinic_postgrid_zncoords.gpx"
    p4 = ROOT / "trials/triclinic_postgrid_final.gpx"
    rows = [
        run(SOURCE, p1, "cells", config_cells, cycles=72),
        run(p1, p2, "profile", config_profile),
        run(p2, p3, "zncoords", config_zncoords),
        run(p3, p4, "final", config_cells, cycles=72),
    ]
    (ROOT / "trials/finalize_triclinic_model.json").write_text(
        json.dumps(rows, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
