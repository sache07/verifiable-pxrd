#!/usr/bin/env python3
"""Freeze the selected GSAS-II state and export consistent final artifacts."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/triclinic_clean.gpx"
FINAL = ROOT / "final.gpx"
CIFS = {
    "ZnWO4_wolframite": ROOT / "phase_ZnWO4_wolframite.cif",
    "WO3_triclinic": ROOT / "phase_WO3_triclinic.cif",
    "ZnO_wurtzite": ROOT / "phase_ZnO_wurtzite.cif",
}


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    project.save(str(FINAL))
    freeze(project)
    project.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(FINAL))

    hist = project.histograms()[0]
    arrays = [np.asarray(v, dtype=float) for v in hist.data["data"][1]]
    x, observed, weights, calculated, background, difference = arrays
    # Preserve the exact public observations in the reported profile.
    public = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    if not np.allclose(x, public[:, 0], rtol=0, atol=1e-8):
        raise RuntimeError("Final project grid differs from inputs/pattern.csv")
    if not np.allclose(observed, public[:, 1], rtol=0, atol=1e-6):
        raise RuntimeError("Final project observations differ from inputs/pattern.csv")
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    masses = []
    phases = []
    for phase in project.phases():
        if phase.name not in CIFS:
            raise RuntimeError(f"Unexpected final phase: {phase.name}")
        phase.export_CIF(str(CIFS[phase.name]), quickmode=True)
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass_scale)
        phases.append({
            "name": phase.name,
            "cif_path": CIFS[phase.name].name,
            "scale": float(hap["Scale"][0]),
            "cell_mass": float(phase.data["General"]["Mass"]),
            "mass_scale": mass_scale,
            "cell": phase.get_cell(),
        })
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / sum(masses)

    chi_square = float(np.sum(weights * difference * difference))
    denominator = float(np.sum(weights * observed * observed))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    summary = {
        "histogram": hist.name,
        "bins": len(x),
        "rwp_percent": rwp,
        "rp_percent": float(hist.residuals["R"]),
        "rwp_min_percent": float(hist.residuals["wRmin"]),
        "goodness_of_fit": rwp / float(hist.residuals["wRmin"]),
        "chi_square": chi_square,
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "sample_shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": phases,
    }
    print(json.dumps(summary, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
