#!/usr/bin/env python3
"""Greedy, fresh-replayed WO3 oxygen coordinate moves capped at 0.05 A."""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from add_zno_refine import freeze


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/angle_ridge_p0d25.gpx"
OUTPUT = ROOT / "trials/physical_wo3_O_descent.gpx"
LIMIT_A = 0.05


def atom_by_label(phase, label):
    return next(atom for atom in phase.atoms() if atom.label == label)


def cartesian_delta(frac_delta, cell) -> np.ndarray:
    a, b, c, _, beta, _ = cell
    beta = math.radians(beta)
    dx, dy, dz = frac_delta
    return np.array([a * dx + c * math.cos(beta) * dz,
                     b * dy,
                     c * math.sin(beta) * dz])


def clamp_from_reference(reference, proposed, cell) -> tuple[np.ndarray, float, float]:
    delta = np.asarray(proposed, float) - np.asarray(reference, float)
    delta -= np.round(delta)
    distance = float(np.linalg.norm(cartesian_delta(delta, cell)))
    factor = min(1.0, LIMIT_A / distance) if distance > 0 else 1.0
    target = np.asarray(reference, float) + factor * delta
    applied = float(np.linalg.norm(cartesian_delta(factor * delta, cell)))
    return target, distance, applied


def fresh(path: Path) -> float:
    project = G2.G2Project(gpxfile=str(path))
    freeze(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(path))
    return float(project.histograms()[0].get_wR())


def propose(current: Path, label: str, reference) -> dict:
    trial = ROOT / ".tmp" / f"wo3_direction_{label}.gpx"
    project = G2.G2Project(gpxfile=str(current))
    project.save(str(trial))
    freeze(project)
    phase = project.phase("WO3_monoclinic")
    atom_by_label(phase, label).refinement_flags = "X"
    project.set_Controls("cycles", 1)
    project.refine()
    proposed = np.asarray(atom_by_label(phase, label).coordinates, float)

    cell = phase.data["General"]["Cell"][1:7]
    target, raw_distance, applied_distance = clamp_from_reference(reference, proposed, cell)
    evaluation = ROOT / ".tmp" / f"wo3_eval_{label}.gpx"
    check = G2.G2Project(gpxfile=str(current))
    check.save(str(evaluation))
    freeze(check)
    atom_by_label(check.phase("WO3_monoclinic"), label).coordinates = target
    check.set_Controls("cycles", 0)
    check.refine()
    check.save(str(evaluation))
    return {
        "label": label,
        "reference_fractional": list(map(float, reference)),
        "unbounded_fractional": proposed.tolist(),
        "applied_fractional": target.tolist(),
        "unbounded_displacement_A": raw_distance,
        "applied_displacement_A": applied_distance,
        "rwp_percent": float(check.histograms()[0].get_wR()),
        "project": evaluation,
    }


def main() -> None:
    G2.SetPrintLevel("warn")
    (ROOT / ".tmp").mkdir(exist_ok=True)
    base = G2.G2Project(gpxfile=str(SOURCE))
    phase = base.phase("WO3_monoclinic")
    references = {
        atom.label: np.asarray(atom.coordinates, float)
        for atom in phase.atoms() if atom.element == "O"
    }
    current = SOURCE
    current_rwp = float(base.histograms()[0].get_wR())
    remaining = set(references)
    log = []

    while remaining:
        candidates = [propose(current, label, references[label]) for label in sorted(remaining)]
        best = min(candidates, key=lambda x: x["rwp_percent"])
        for row in candidates:
            row["selected_this_round"] = row is best
            row["accepted"] = False
        if best["rwp_percent"] >= current_rwp - 1e-9:
            log.extend(candidates)
            break
        best["accepted"] = True
        current_rwp = best["rwp_percent"]
        current = best["project"]
        remaining.remove(best["label"])
        log.extend(candidates)
        print("accepted", best["label"], current_rwp,
              "move_A", best["applied_displacement_A"])

    final = G2.G2Project(gpxfile=str(current))
    final.save(str(OUTPUT))
    freeze(final)
    final.set_Controls("cycles", 0)
    final.refine()
    final.save(str(OUTPUT))
    result = {
        "source": str(SOURCE.relative_to(ROOT)),
        "project": str(OUTPUT.relative_to(ROOT)),
        "limit_A": LIMIT_A,
        "final_rwp_percent": float(final.histograms()[0].get_wR()),
        "accepted_labels": sorted({row["label"] for row in log if row["accepted"]}),
        "trials": [
            {**row, "project": str(row["project"].relative_to(ROOT))}
            for row in log
        ],
    }
    (ROOT / "trials/bounded_wo3_coordinate_descent.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print("final", result["final_rwp_percent"], result["accepted_labels"])


if __name__ == "__main__":
    main()
