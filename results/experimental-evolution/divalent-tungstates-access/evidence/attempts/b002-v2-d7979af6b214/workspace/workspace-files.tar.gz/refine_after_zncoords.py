#!/usr/bin/env python3
"""Refit ordinary nuisance terms after converged wolframite coordinates."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2

from refine_three_from_grid import ROOT, config_cells, config_profile, stage


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / "trials/three_zno_zncoords_iter2.gpx"
    out1 = ROOT / "trials/postcoords_cells.gpx"
    out2 = ROOT / "trials/postcoords_profile.gpx"
    out3 = ROOT / "trials/postcoords_refined.gpx"
    log = [
        stage(source, out1, "postcoords_cells", config_cells, 36),
        stage(out1, out2, "postcoords_profile", config_profile, 36),
        stage(out2, out3, "postcoords_final", config_cells, 36),
    ]
    (ROOT / "trials/refine_after_zncoords.json").write_text(
        json.dumps(log, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
