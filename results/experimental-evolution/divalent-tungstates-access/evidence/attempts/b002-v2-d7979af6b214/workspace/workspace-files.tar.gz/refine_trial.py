#!/usr/bin/env python3
"""Run a staged GSAS-II trial refinement from a small JSON configuration.

This is an exploratory/finalization helper and must be run with GSAS2_PYTHON.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIpath


def instrument_text() -> str:
    return (
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.15;Polariz.:0.80;Azimuth:0.0\n"
        "U:20.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    ip = hist.InstrumentParameters
    sp = hist.SampleParameters
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "mass": phase.data["General"]["Mass"],
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    return {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {k: ip[k][1] for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L") if k in ip},
        "sample": {
            k: sp[k][0] if isinstance(sp.get(k), list) else sp.get(k)
            for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius")
            if k in sp
        },
        "phases": phases,
        "vary_list": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "gsas_revision": GSASIIpath.GetVersionNumber(),
    }


def refine_stage(project: G2.G2Project, label: str, log: list[dict], cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    record = snapshot(project, label)
    log.append(record)
    print(label, json.dumps(record["residuals"], sort_keys=True))


def configure_hap(phase, hist_name: str, scale: float = 1.0) -> None:
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [float(scale), False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.5
    hap["Size"][1][1] = 0.5
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]


def run(config_path: Path) -> None:
    config_path = config_path.resolve()
    cfg = json.loads(config_path.read_text())
    root = config_path.parent
    output = (root / cfg["output"]).resolve()
    work = output.with_suffix("")
    work.mkdir(parents=True, exist_ok=True)

    pattern = (root / cfg.get("pattern", "inputs/pattern.csv")).resolve()
    x, y = np.loadtxt(pattern, delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    data_path = work / "observed.xye"
    np.savetxt(data_path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    inst_path = work / "instrument.instprm"
    inst_path.write_text(instrument_text())

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(str(data_path), str(inst_path), fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    if "Scale" in hist.SampleParameters:
        hist.SampleParameters["Scale"][1] = False
    if "Shift" in hist.SampleParameters:
        hist.SampleParameters["Shift"] = [0.0, False]
    if "Transparency" in hist.SampleParameters:
        hist.SampleParameters["Transparency"] = [0.0, False]
    if "SurfRoughA" in hist.SampleParameters:
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
    if "SurfRoughB" in hist.SampleParameters:
        hist.SampleParameters["SurfRoughB"] = [0.0, False]

    phases = []
    for i, item in enumerate(cfg["phases"]):
        phase = project.add_phase(
            str((root / item["cif"]).resolve()),
            phasename=item["name"],
            histograms=[hist],
            fmthint="CIF",
        )
        configure_hap(phase, hist.name, item.get("initial_scale", 1.0 / len(cfg["phases"])))
        phases.append(phase)

    n_background = int(cfg.get("background_coeffs", 12))
    coeffs = [float(np.percentile(y, 30))] + [0.0] * (n_background - 1)
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": n_background,
                "coeffs": coeffs,
                "refine": True,
            },
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})

    log: list[dict] = [snapshot(project, "initial")]
    refine_stage(project, "background_scale", log)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_stage(project, "cell_zero", log, cycles=12)

    # The physical specimen displacement is distinguishable from a constant
    # zero over this broad angular range; refine it only after cells stabilize.
    if cfg.get("refine_shift", False) and "Shift" in hist.SampleParameters:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        refine_stage(project, "cell_zero_shift", log, cycles=12)

    # For a single pattern, instrument U vs. phase microstrain and instrument
    # X vs. phase size are exactly or nearly collinear. Keep the representative
    # starting U/X fixed and refine the phase broadening below.
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    refine_stage(project, "instrument_profile", log, cycles=12)

    if cfg.get("refine_size_strain", True):
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                }
            )
        refine_stage(project, "size_strain", log, cycles=12)

    if cfg.get("refine_atoms", False):
        for phase, item in zip(phases, cfg["phases"]):
            if item.get("refine_atoms", True):
                phase.set_refinements({"Atoms": {"all": item.get("atom_flags", "X")}})
        refine_stage(project, "atoms_uiso", log, cycles=16)

    project.save(str(output))
    (output.with_suffix(".log.json")).write_text(json.dumps(log, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    run(Path(sys.argv[1]))
