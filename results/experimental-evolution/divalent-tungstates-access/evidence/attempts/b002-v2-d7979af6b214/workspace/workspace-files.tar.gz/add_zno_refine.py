#!/usr/bin/env python3
"""Add the common-state ZnO signal and perform controlled ordinary refinement."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "trials/common_best_clean.gpx"
OUTPUT = ROOT / "trials/common_three_zno.gpx"
ZNO = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif/9/00/41/9004178.cif"
)


def freeze(project) -> None:
    hist = project.histograms()[0]
    bkg = hist.data["Background"][0]
    bkg[1] = False
    for val in hist.data["Instrument Parameters"][0].values():
        if isinstance(val, list) and len(val) > 2 and isinstance(val[2], bool):
            val[2] = False
    for val in hist.data["Sample Parameters"].values():
        if isinstance(val, list) and len(val) > 1 and isinstance(val[1], bool):
            val[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Pref.Ori."][2] = False


def enable_intensity(project) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    hist.data["Instrument Parameters"][0]["Polariz."][2] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        if phase.name != "ZnO_wurtzite":
            hap["Pref.Ori."][2] = True


def refine_and_replay(project, label: str, log: list[dict], cycles: int = 16) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    freeze(project)
    project.set_Controls("cycles", 0)
    project.refine()
    hist = project.histograms()[0]
    row = {
        "stage": label,
        "rwp_percent": float(hist.get_wR()),
        "phases": [],
        "polarization": float(hist.InstrumentParameters["Polariz."][1]),
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        })
    log.append(row)
    print(label, row["rwp_percent"])


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE))
    # Redirect all autosaves before changing the accepted two-phase source.
    project.save(str(OUTPUT))
    hist = project.histograms()[0]
    freeze(project)
    zno = project.add_phase(
        str(ZNO), phasename="ZnO_wurtzite", histograms=[hist], fmthint="CIF"
    )
    hap = zno.data["Histograms"][hist.name]
    hap["Scale"] = [11.78680126106356, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.1
    hap["Size"][1][1] = 0.1
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]

    log: list[dict] = []
    refine_and_replay(project, "three_phase_start", log, cycles=0)

    enable_intensity(project)
    refine_and_replay(project, "intensity", log)

    enable_intensity(project)
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = True
    refine_and_replay(project, "cells_intensity", log, cycles=20)

    project.save(str(OUTPUT))
    OUTPUT.with_suffix(".log.json").write_text(
        json.dumps(log, indent=2, allow_nan=False) + "\n"
    )


if __name__ == "__main__":
    main()
