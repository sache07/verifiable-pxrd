#!/usr/bin/env python3
"""Export the accepted GSAS-II checkpoint and its submitted profiles."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "work" / "final_physical2.gpx"
FINAL_GPX = ROOT / "final.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
    project.save(str(FINAL_GPX))
    histogram = project.histogram(0)

    cif_paths = {
        "CaWO4_scheelite": ROOT / "CaWO4_scheelite.cif",
        "WO3_monoclinic": ROOT / "WO3_monoclinic.cif",
    }
    for phase in project.phases():
        phase.export_CIF(str(cif_paths[phase.name]), quickmode=True)

    x, observed, _weight, calculated, _background, stored_difference = (
        np.asarray(v, dtype=float) for v in histogram.data["data"][1]
    )
    difference = observed - calculated
    with (ROOT / "fit.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(
            zip(
                (f"{value:.8f}" for value in x),
                (f"{value:.8f}" for value in observed),
                (f"{value:.8f}" for value in calculated),
                (f"{value:.8f}" for value in difference),
            )
        )

    print(
        json.dumps(
            {
                "gpx": str(FINAL_GPX),
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "cells": {phase.name: phase.get_cell() for phase in project.phases()},
                "points": len(x),
                "stored_difference_max_delta": float(
                    np.max(np.abs(stored_difference - difference))
                ),
                "frozen": project.get_Frozen(),
            },
            indent=2,
            default=float,
        )
    )


if __name__ == "__main__":
    main()
