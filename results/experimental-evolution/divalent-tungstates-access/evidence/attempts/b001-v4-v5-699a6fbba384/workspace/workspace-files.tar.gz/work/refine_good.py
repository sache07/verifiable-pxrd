#!/usr/bin/env python3
"""Refine the physically screened CaWO4 + WO3 model with stable staging."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARAM = ROOT / "work" / "CuKa_lab.instprm"
CAWO4 = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif/7/21/92/7219229.cif"
)
WO3 = ROOT / "work" / "WO3_2311041_niggli.cif"


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def set_limit(project, var, lo, hi):
    project.set_Controls("parmMin", lo, variable=var)
    project.set_Controls("parmMax", hi, variable=var)


def summary(project, label):
    hist = project.histogram(0)
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
            }
        )
    try:
        mass_fracs = hist.ComputeMassFracs()
    except Exception as err:
        mass_fracs = {"error": repr(err)}
    result = {
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": mass_fracs,
        "instrument": {
            k: v[1]
            for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) > 1
        },
        "sample": {
            k: v[0]
            for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and v
        },
        "phases": phases,
        "frozen": project.get_Frozen(),
    }
    print("SNAPSHOT " + json.dumps(result, default=str), flush=True)


def refine(project, output, label, cycles=8):
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    summary(project, label)
    project.save(str(output))
    shutil.copy2(output, output.with_name(output.stem + f"_{label}.gpx"))


def main():
    output = Path(sys.argv[1] if len(sys.argv) > 1 else ROOT / "work" / "good.gpx").resolve()
    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), str(IPARAM), fmthint="comma/tab/semicolon separated"
    )
    hist.Limits("lower", float(hist.data["data"][1][0][0]))
    hist.Limits("upper", float(hist.data["data"][1][0][-1]))
    ca = project.add_phase(
        str(CAWO4), phasename="CaWO4_scheelite", histograms=[hist], fmthint="CIF"
    )
    wo = project.add_phase(
        str(WO3), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF"
    )

    hist.SampleParameters["Scale"][:] = [1.0, False]
    hist.SampleParameters["Shift"][:] = [200.0, False]
    hist.InstrumentParameters["Zero"][1:] = [-0.25, False]
    for key, value in {"U": 15.0, "V": 0.0, "W": 12.0, "X": 1.5, "SH/L": 0.02}.items():
        hist.InstrumentParameters[key][1] = value

    # Position-derived metric starts remain within 0.5% of the physical parents.
    set_cell(ca, [5.23561, 5.23561, 11.33167, 90.0, 90.0, 90.0])
    set_cell(wo, [7.3105, 7.5517, 7.6888, 90.0, 90.9147, 90.0])

    ca_hap = ca.data["Histograms"][hist.name]
    wo_hap = wo.data["Histograms"][hist.name]
    ca_hap["Size"][1][0] = 0.085
    ca_hap["Mustrain"][1][0] = 700.0
    wo_hap["Size"][1][0] = 1.0
    wo_hap["Mustrain"][1][0] = 500.0
    for phase in project.phases():
        for atom in phase.atoms():
            if atom.adp_flag == "I" and atom.uiso <= 0:
                atom.uiso = 0.01
    project.save()

    for var, lo, hi in [
        (":0:Zero", -0.35, 0.35),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 45.0),
        (":0:W", 1.0, 45.0),
        (":0:X", 0.05, 7.0),
        (":0:SH/L", 0.002, 0.12),
        (":0:Polariz.", 0.45, 1.0),
        ("0:0:Scale", 0.0, 100.0),
        ("1:0:Scale", 0.0, 100.0),
        ("0:0:Size;i", 0.04, 2.0),
        ("1:0:Size;i", 0.04, 2.0),
        ("0:0:Mustrain;i", 0.0, 10000.0),
        ("1:0:Mustrain;i", 0.0, 10000.0),
    ]:
        set_limit(project, var, lo, hi)

    project.set_refinement(
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": 16,
                },
                "Scale": True,
            }
        }
    )
    refine(project, output, "01_scale_background", 6)

    project.set_refinement({"set": {"Cell": True}})
    refine(project, output, "02_cells", 8)

    project.set_refinement(
        {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}}
    )
    refine(project, output, "03_profile", 10)

    ca.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": ca_hap["Size"][1][0], "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    refine(project, output, "04_cawo4_width", 10)

    wo.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": wo_hap["Size"][1][0], "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    refine(project, output, "05_wo3_width", 10)

    # Calibrate only after both metrics and widths are stable.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, output, "06_zero", 8)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, output, "07_shift_joint", 12)
    project.save(str(output))


if __name__ == "__main__":
    main()
