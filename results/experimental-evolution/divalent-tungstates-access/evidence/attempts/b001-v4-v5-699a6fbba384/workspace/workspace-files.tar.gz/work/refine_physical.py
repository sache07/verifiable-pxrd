#!/usr/bin/env python3
"""Build a bounded, staged GSAS-II two-phase checkpoint.

Usage: refine_physical.py OUTPUT.gpx WO3_COD_ID
"""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARAM = ROOT / "work" / "CuKa_lab.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def serializable_snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    out = {
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": {},
        "instrument": {
            k: v[1]
            for k, v in hist.InstrumentParameters.items()
            if isinstance(v, list) and len(v) > 1
        },
        "sample": {
            k: v[0]
            for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and v
        },
        "phases": [],
        "frozen": project.get_Frozen() if hasattr(project, "get_Frozen") else [],
    }
    try:
        out["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as err:
        out["mass_fraction_error"] = repr(err)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": a.label,
                        "element": a.element,
                        "xyz": a.coordinates,
                        "uiso": a.uiso,
                        "flags": a.refinement_flags,
                    }
                    for a in phase.atoms()
                ],
            }
        )
    print("SNAPSHOT " + json.dumps(out, default=str), flush=True)
    return out


def set_limit(project: G2sc.G2Project, variable: str, lower: float, upper: float) -> None:
    project.set_Controls("parmMin", lower, variable=variable)
    project.set_Controls("parmMax", upper, variable=variable)


def save_checkpoint(project: G2sc.G2Project, output: Path, label: str) -> None:
    project.save(str(output))
    checkpoint = output.with_name(output.stem + f"_{label}.gpx")
    shutil.copy2(output, checkpoint)


def refine(project: G2sc.G2Project, output: Path, label: str, cycles: int = 10) -> None:
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    serializable_snapshot(project, label)
    save_checkpoint(project, output, label)


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    output = Path(sys.argv[1]).resolve()
    wo3_id = sys.argv[2]

    project = G2sc.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(PATTERN), str(IPARAM), fmthint="comma/tab/semicolon separated"
    )
    hist.Limits("lower", float(hist.data["data"][1][0][0]))
    hist.Limits("upper", float(hist.data["data"][1][0][-1]))
    ca = project.add_phase(
        str(cod_path("7219229")),
        phasename="CaWO4_scheelite",
        histograms=[hist],
        fmthint="CIF",
    )
    wo = project.add_phase(
        str(cod_path(wo3_id)),
        phasename=f"WO3_{wo3_id}",
        histograms=[hist],
        fmthint="CIF",
    )

    # Remove the redundant histogram-scale degree of freedom. Phase scales alone
    # carry the quantitative information in this single-histogram refinement.
    hist.SampleParameters["Scale"][:] = [1.0, False]
    for phase in project.phases():
        for atom in phase.atoms():
            if atom.adp_flag == "I" and atom.uiso <= 0:
                atom.uiso = 0.01

    # Physically motivated starts. WO3 lines are visibly narrower than CaWO4.
    inst = hist.InstrumentParameters
    for key, value in {"U": 15.0, "V": 0.0, "W": 12.0, "X": 1.5, "SH/L": 0.02}.items():
        inst[key][1] = value
    ca_hap = ca.data["Histograms"][hist.name]
    wo_hap = wo.data["Histograms"][hist.name]
    ca_hap["Size"][1][0] = 0.12
    ca_hap["Mustrain"][1][0] = 1800.0
    wo_hap["Size"][1][0] = 1.0
    wo_hap["Mustrain"][1][0] = 500.0
    project.save()

    # Bounds reflect the stated laboratory envelope and keep profile/correction
    # terms meaningful while the structural metric is settling.
    for variable, lo, hi in [
        (":0:Zero", -0.30, 0.30),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 45.0),
        (":0:W", 1.0, 45.0),
        (":0:X", 0.05, 7.0),
        (":0:SH/L", 0.002, 0.12),
        (":0:Polariz.", 0.45, 1.0),
        ("0:0:Scale", 0.0, 100.0),
        ("1:0:Scale", 0.0, 100.0),
        ("0:0:Size;i", 0.04, 2.0),
        ("1:0:Size;i", 0.04, 2.0),
        ("0:0:Mustrain;i", 50.0, 10000.0),
        ("1:0:Mustrain;i", 50.0, 10000.0),
    ]:
        set_limit(project, variable, lo, hi)

    project.set_refinement(
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": 16,
                },
                "Scale": True,
            }
        }
    )
    refine(project, output, "01_scale_background", 8)

    project.set_refinement(
        {"set": {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}}
    )
    refine(project, output, "02_calibration", 10)

    project.set_refinement({"set": {"Cell": True}})
    refine(project, output, "03_cells", 10)

    project.set_refinement(
        {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}}
    )
    refine(project, output, "04_instrument_profile", 10)

    # Add the phase-dependent broadening one phase at a time.
    ca.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": ca_hap["Size"][1][0], "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    refine(project, output, "05_cawo4_broadening", 12)

    wo.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": wo_hap["Size"][1][0], "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    refine(project, output, "06_wo3_broadening", 12)

    # A final joint pass rebalances scale, cell, calibration and width after all
    # supported terms are present.
    refine(project, output, "07_joint", 15)
    project.save(str(output))


if __name__ == "__main__":
    main()
