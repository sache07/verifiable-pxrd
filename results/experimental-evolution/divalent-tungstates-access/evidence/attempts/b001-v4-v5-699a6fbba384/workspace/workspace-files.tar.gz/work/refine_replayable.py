#!/usr/bin/env python3
"""Continue the last boundary-free checkpoint without frozen-limit artifacts."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def main():
    if len(sys.argv) != 3:
        raise SystemExit("refine_replayable.py INPUT.gpx OUTPUT.gpx")
    source, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)
    ca, wo = project.phases()
    project.set_Frozen()

    # The CaWO4 isotropic microstrain refined statistically to zero in the
    # boundary-free checkpoint. Fix it at zero rather than allowing a negative
    # broadening term that makes saved and replayed profiles disagree.
    ca_hap = ca.data["Histograms"][hist.name]
    ca_hap["Mustrain"][1][0] = 0.0
    ca.clear_HAP_refinements({"Mustrain": True}, [hist])

    # Use the independently stable zero estimate and determine specimen height
    # from the full angular range with zero held fixed.
    hist.InstrumentParameters["Zero"][1:] = [-0.2355, False]
    hist.SampleParameters["Shift"][1] = True
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.save(str(output))
    project.set_Controls("cycles", 12)
    project.do_refinements([{}])
    project.save(str(output))

    result = {
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "frozen": project.get_Frozen(),
        "zero": hist.InstrumentParameters["Zero"],
        "shift": hist.SampleParameters["Shift"],
        "instrument": {
            k: hist.InstrumentParameters[k]
            for k in ["U", "V", "W", "X", "SH/L"]
        },
        "cells": {p.name: p.get_cell() for p in project.phases()},
        "widths": {
            p.name: {
                "size": p.data["Histograms"][hist.name]["Size"],
                "mustrain": p.data["Histograms"][hist.name]["Mustrain"],
            }
            for p in project.phases()
        },
    }
    print(json.dumps(result, default=str), flush=True)


if __name__ == "__main__":
    main()
