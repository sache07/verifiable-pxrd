#!/usr/bin/env python3
"""Screen one WO3 isotropic broadening contribution at a time."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / "work" / "replayable_shift.gpx"


def run(kind: str) -> None:
    output = ROOT / "work" / f"{SOURCE.stem}_wo_{kind}.gpx"
    project = G2sc.G2Project(str(SOURCE), newgpx=str(output))
    histogram = project.histogram(0)
    wo3 = project.phase(1)
    project.set_Frozen()

    wo3.clear_HAP_refinements({"Size": True, "Mustrain": True}, [histogram])
    if kind == "size":
        wo3.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 1.0, "refine": True}},
            [histogram],
        )
    elif kind == "mustrain":
        wo3.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "value": 500.0, "refine": True}},
            [histogram],
        )
    else:
        raise ValueError(kind)

    project.set_Controls("cycles", 12)
    project.do_refinements([{}])
    hap = wo3.data["Histograms"][histogram.name]
    print(
        json.dumps(
            {
                "branch": kind,
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "frozen": project.get_Frozen(),
            },
            indent=2,
            default=float,
        )
    )
    project.save(str(output))


if __name__ == "__main__":
    run("size")
    run("mustrain")
