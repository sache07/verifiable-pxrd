#!/usr/bin/env python3
"""Create and stage a GSAS-II Rietveld trial from frozen COD references.

Usage: refine_trial.py OUTPUT.gpx CODID:PHASENAME [CODID:PHASENAME ...]
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
IPARAM = ROOT / "work" / "CuKa_lab.instprm"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project: G2sc.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    record = {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {
            key: val[1]
            for key, val in hist.InstrumentParameters.items()
            if isinstance(val, list) and len(val) > 1
        },
        "sample": {
            key: val[0]
            for key, val in hist.SampleParameters.items()
            if isinstance(val, list) and val
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        record["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    print("SNAPSHOT " + json.dumps(record, default=str), flush=True)
    return record


def refine(project: G2sc.G2Project, label: str) -> None:
    project.set_Controls("cycles", 8)
    project.do_refinements([{}])
    snapshot(project, label)
    project.save()


def main() -> None:
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    out = Path(sys.argv[1]).resolve()
    specs = [arg.split(":", 1) for arg in sys.argv[2:]]

    project = G2sc.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(
        str(PATTERN), str(IPARAM), fmthint="comma/tab/semicolon separated"
    )
    hist.Limits("lower", float(hist.data["data"][1][0][0]))
    hist.Limits("upper", float(hist.data["data"][1][0][-1]))
    for cod_id, name in specs:
        project.add_phase(
            str(cod_path(cod_id)),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
    project.save()
    snapshot(project, "created")

    # Establish phase scales and a smooth whole-pattern background first.
    project.set_refinement(
        {
            "set": {
                "Background": {
                    "type": "chebyschev-1",
                    "refine": True,
                    "no. coeffs": 16,
                },
                "Scale": True,
            }
        }
    )
    refine(project, "background_scales")

    # Separate constant angular calibration and Bragg-Brentano specimen height.
    project.set_refinement(
        {"set": {"Instrument Parameters": ["Zero"], "Sample Parameters": ["Shift"]}}
    )
    refine(project, "zero_shift")

    # Refine all symmetry-allowed metric terms, then global profile terms.
    project.set_refinement({"set": {"Cell": True}})
    refine(project, "cells")
    project.set_refinement(
        {"set": {"Instrument Parameters": ["U", "W", "X", "SH/L"]}}
    )
    refine(project, "profile")

    project.save(str(out))


if __name__ == "__main__":
    main()
