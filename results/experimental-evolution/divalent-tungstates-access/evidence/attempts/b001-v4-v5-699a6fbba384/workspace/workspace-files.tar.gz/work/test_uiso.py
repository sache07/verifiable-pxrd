#!/usr/bin/env python3
"""Test one common isotropic displacement parameter per physical phase."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "work" / "polarization.gpx"
OUTPUT = ROOT / "work" / "uiso.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    project.set_Frozen()

    for phase_index, (phase, start) in enumerate(zip(project.phases(), (0.012, 0.010))):
        variables = []
        for atom_index, atom in enumerate(phase.atoms()):
            atom.uiso = start
            atom.refinement_flags = atom.refinement_flags.replace("U", "") + "U"
            variables.append(f"{phase_index}::AUiso:{atom_index}")
            project.set_Controls("parmMin", 0.003, variable=variables[-1])
            project.set_Controls("parmMax", 0.030, variable=variables[-1])
        project.add_EquivConstr(tuple(variables), reloadIdx=(phase_index == 0))

    project.set_Controls("cycles", 10)
    project.do_refinements([{}])
    histogram = project.histogram(0)
    summary = {
        "residuals": histogram.residuals,
        "mass_fractions": histogram.ComputeMassFracs(),
        "uiso": [[a.uiso for a in p.atoms()] for p in project.phases()],
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(summary, indent=2, default=float))
    project.save(str(OUTPUT))


if __name__ == "__main__":
    main()
