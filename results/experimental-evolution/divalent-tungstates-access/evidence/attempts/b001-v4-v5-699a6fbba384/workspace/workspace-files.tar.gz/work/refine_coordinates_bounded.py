#!/usr/bin/env python3
"""Bounded coordinate tests around the physical parent structures."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def set_limit(project, var, limit):
    project.set_Controls("parmMin", -limit, variable=var)
    project.set_Controls("parmMax", limit, variable=var)


def report(project, label):
    hist = project.histogram(0)
    print(
        "SNAPSHOT "
        + json.dumps(
            {
                "label": label,
                "residuals": hist.residuals,
                "mass_fractions": hist.ComputeMassFracs(),
                "atoms": {
                    phase.name: [
                        [a.label, a.element, list(a.coordinates), a.uiso]
                        for a in phase.atoms()
                    ]
                    for phase in project.phases()
                },
                "frozen": project.get_Frozen(),
            },
            default=str,
        ),
        flush=True,
    )


def refine(project, output, label, cycles=10):
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    report(project, label)
    project.save(str(output))
    shutil.copy2(output, output.with_name(output.stem + f"_{label}.gpx"))


def main():
    if len(sys.argv) != 3:
        raise SystemExit("refine_coordinates_bounded.py INPUT.gpx OUTPUT.gpx")
    project = G2sc.G2Project(sys.argv[1], newgpx=sys.argv[2])
    output = Path(sys.argv[2]).resolve()
    hist = project.histogram(0)
    ca, wo = project.phases()

    # clear_refinements returns immediately for Background, so use distinct calls.
    hist.clear_refinements({"Background": True})
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"],
            "Sample Parameters": ["Shift"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])

    # Bounds are fractional-coordinate shifts around the screened parent. The
    # maximum corresponds to about 0.06--0.08 A in these cells.
    for atom_index in range(2):
        for axis in "xyz":
            set_limit(project, f"1::dA{axis}:{atom_index}", 0.010)
    for axis in "xyz":
        set_limit(project, f"0::dA{axis}:2", 0.008)
    for atom_index in range(2, 8):
        for axis in "xyz":
            set_limit(project, f"1::dA{axis}:{atom_index}", 0.010)
    project.save(str(output))

    for atom in wo.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    refine(project, output, "01_W", 10)

    for atom in ca.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine(project, output, "02_CaWO4_O", 10)

    for atom in wo.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    refine(project, output, "03_WO3_O", 12)


if __name__ == "__main__":
    main()
