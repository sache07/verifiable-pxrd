#!/usr/bin/env python3
"""Create the final boundary-free physical checkpoint."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "work" / "replayable_shift.gpx"
OUTPUT = ROOT / "work" / "final_physical.gpx"


def main() -> None:
    project = G2sc.G2Project(str(SOURCE), newgpx=str(OUTPUT))
    histogram = project.histogram(0)
    wo3 = project.phase(1)
    project.set_Frozen()

    # The isolated broadening trials returned 1.003 um size from a 1.000 um
    # start and drove microstrain to its zero lower bound. Keep the former
    # fixed and represent the latter as a fixed zero, not a frozen variable.
    hap = wo3.data["Histograms"][histogram.name]
    hap["Size"][1][0] = 1.0
    hap["Mustrain"][1][0] = 0.0
    wo3.clear_HAP_refinements({"Size": True, "Mustrain": True}, [histogram])

    project.set_Controls("cycles", 12)
    project.do_refinements([{}])
    project.save(str(OUTPUT))

    print(
        json.dumps(
            {
                "residuals": histogram.residuals,
                "mass_fractions": histogram.ComputeMassFracs(),
                "frozen": project.get_Frozen(),
                "cells": {p.name: p.get_cell() for p in project.phases()},
                "wo3_size": hap["Size"],
                "wo3_mustrain": hap["Mustrain"],
            },
            indent=2,
            default=float,
        )
    )


if __name__ == "__main__":
    main()
