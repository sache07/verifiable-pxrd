#!/usr/bin/env python3
"""Staged coordinate refinement with checkpoints for the accepted phases."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


def snapshot(project, label):
    hist = project.histogram(0)
    out = {
        "label": label,
        "residuals": hist.residuals,
        "mass_fractions": hist.ComputeMassFracs(),
        "atoms": {
            phase.name: [
                [a.label, a.element, list(a.coordinates), a.uiso, a.refinement_flags]
                for a in phase.atoms()
            ]
            for phase in project.phases()
        },
        "vary": [str(v) for v in (project.get_VaryList() or [])],
        "frozen": project.get_Frozen(),
    }
    print("SNAPSHOT " + json.dumps(out, default=str), flush=True)


def run(project, output, label, cycles=8):
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.do_refinements([{}])
    snapshot(project, label)
    project.save(str(output))
    shutil.copy2(output, output.with_name(output.stem + f"_{label}.gpx"))


def main():
    if len(sys.argv) != 3:
        raise SystemExit("refine_coordinates.py INPUT.gpx OUTPUT.gpx")
    source, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)
    ca, wo = project.phases()

    # Hold calibration, metrics, widths and background while testing coordinate
    # information. Keep the two phase scales active.
    # clear_refinements exits after processing Background, so this must be a
    # separate call from the instrument/sample flags.
    hist.clear_refinements({"Background": True})
    hist.clear_refinements(
        {
            "Instrument Parameters": ["Zero", "U", "W", "X", "SH/L"],
            "Sample Parameters": ["Shift"],
        }
    )
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [hist])
        phase.set_HAP_refinements({"Scale": True}, [hist])
    project.save(str(output))

    # Heavy atoms in the monoclinic phase carry most of the intensity leverage.
    for atom in wo.atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    run(project, output, "01_wo3_W", 8)

    # Test the single scheelite oxygen orbit separately.
    for atom in ca.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    run(project, output, "02_cawo4_O", 8)

    # Finally allow the six independent WO3 oxygen orbits to adjust.
    for atom in wo.atoms():
        if atom.element == "O":
            atom.refinement_flags = "X"
    run(project, output, "03_wo3_O", 10)


if __name__ == "__main__":
    main()
