#!/usr/bin/env python3
"""Develop the 1966 WO3 parent to the same physical checkpoint."""

from __future__ import annotations

import json
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "work" / "checkpoints"
COORD_RE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def state(project, label):
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(json.dumps({
        "label": label,
        "Rwp": hist.get_wR(),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
    }), flush=True)


def run(project, label, cycles=10):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save(str(OUT / f"alt_{label}.gpx"))
    project.refine(makeBack=False)
    project.save()
    state(project, label)


def coordinate_snapshot(project):
    return {
        (int(phase.data["pId"]), i): tuple(atom.coordinates)
        for phase in project.phases()
        for i, atom in enumerate(phase.atoms())
    }


def install_coordinate_bounds(project, source):
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for i, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", source[(pid, i)], lengths):
                variable = f"{pid}::dA{axis}:{i}"
                project.set_Controls("parmMin", value - 0.10 / length, variable=variable)
                project.set_Controls("parmMax", value + 0.10 / length, variable=variable)


def reject_bound_atoms(project, source, predicate):
    rejected = set()
    for variable in project.get_Frozen():
        match = COORD_RE.match(str(variable))
        if match:
            rejected.add((int(match.group(1)), int(match.group(2))))
    for phase in project.phases():
        pid = int(phase.data["pId"])
        for i, atom in enumerate(phase.atoms()):
            key = (pid, i)
            if key in rejected:
                atom.coordinates = source[key]
                atom.refinement_flags = " "
            else:
                atom.refinement_flags = "X" if predicate(atom) else " "
    return rejected


def main():
    project = G2.G2Project(gpxfile=str(OUT / "alt0_1966.gpx"))
    hist = project.histograms()[0]

    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    run(project, "1_scale_background", 8)

    hist = project.histograms()[0]
    hist.data["Sample Parameters"]["Shift"][1] = True
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    run(project, "2_shift", 8)

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "3_cells", 10)
    run(project, "3b_cells_settle", 10)

    # Give both reference parents the same bounded coordinate opportunity.
    source = coordinate_snapshot(project)
    install_coordinate_bounds(project, source)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element != "O" else " "
    run(project, "4_heavy_trial", 12)
    rejected_heavy = reject_bound_atoms(project, source, lambda atom: atom.element != "O")
    print("rejected_heavy", sorted(rejected_heavy), flush=True)
    run(project, "4b_heavy_interior", 12)
    run(project, "4c_heavy_settle", 10)

    oxygen_source = coordinate_snapshot(project)
    # Bounds stay centered on the common pre-coordinate checkpoint, as for the
    # first parent; oxygen_source is used only for whole-atom rollback.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.element == "O" else " "
    run(project, "5_oxygen_trial", 15)
    rejected_oxygen = reject_bound_atoms(project, oxygen_source, lambda atom: atom.element == "O")
    print("rejected_oxygen", sorted(rejected_oxygen), flush=True)
    run(project, "5b_oxygen_interior", 12)
    run(project, "5c_coordinate_settle", 10)

    # Phase broadening under supplied specimen bounds.
    hist = project.histograms()[0]
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2][0] = True
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    run(project, "6_phase_profile", 15)

    # A size term that reaches a tested bound is rolled back and disabled.
    frozen = {str(item) for item in project.get_Frozen()}
    for phase in project.phases():
        pid = phase.data["pId"]
        if f"{pid}:0:Size;i" in frozen:
            hap = phase.data["Histograms"][project.histograms()[0].name]
            hap["Size"][1][0] = 1.0
            hap["Size"][2][0] = False

    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["U"][2] = True
    inst["W"][2] = True
    inst["X"][1] = 1.0
    inst["X"][2] = False
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    run(project, "7_joint_profile", 15)
    run(project, "7b_profile_settle", 10)

    # The accepted Ba3W2O9 axis is independent of the WO3 parent choice.
    hist = project.histograms()[0]
    phase = project.phase("Ba3W2O9")
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[1], po[2], po[3] = 1.0, True, [1, 1, 0]
    project.set_Controls("parmMin", 0.7, variable=f"{phase.data['pId']}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase.data['pId']}:0:MD")
    run(project, "8_ba3_texture", 12)
    run(project, "8b_ba3_texture_settle", 10)


if __name__ == "__main__":
    main()
