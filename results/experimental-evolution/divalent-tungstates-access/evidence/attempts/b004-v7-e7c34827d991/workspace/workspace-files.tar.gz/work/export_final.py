#!/usr/bin/env python3
"""Read-only export of the accepted final GSAS-II project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"
PHASE_INFO = {
    "Ba3W2O9": {
        "formula": "Ba3W2O9",
        "cif": "phase_Ba3W2O9.cif",
        "reference_cod_id": "1533878",
        "space_group_number": 167,
    },
    "WO3": {
        "formula": "WO3",
        "cif": "phase_WO3.cif",
        "reference_cod_id": "2311041",
        "space_group_number": 14,
    },
    "BaCO3": {
        "formula": "BaCO3",
        "cif": "phase_BaCO3.cif",
        "reference_cod_id": "9010928",
        "space_group_number": 62,
    },
}


def cell_text(name: str, cell: dict[str, float]) -> str:
    if name == "Ba3W2O9":
        return f"a={cell['length_a']:.5f}, c={cell['length_c']:.5f} Å"
    if name == "WO3":
        return (f"a={cell['length_a']:.5f}, b={cell['length_b']:.5f}, "
                f"c={cell['length_c']:.5f} Å, β={cell['angle_beta']:.5f}°")
    return (f"a={cell['length_a']:.5f}, b={cell['length_b']:.5f}, "
            f"c={cell['length_c']:.5f} Å")


def main() -> None:
    project = G2.G2Project(gpxfile=str(PROJECT))
    hist = project.histograms()[0]
    arrays = [np.asarray(item, dtype=float) for item in hist.data["data"][1][:6]]
    x, observed, weights, calculated, _background, stored_difference = arrays
    difference = observed - calculated
    if not np.array_equal(stored_difference, difference):
        raise RuntimeError("saved GSAS-II difference array is inconsistent")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("calculated profile is not finite and nonnegative")

    raw_fractions = hist.ComputeMassFracs()
    fraction_sum = sum(float(value[0]) for value in raw_fractions.values())
    if abs(fraction_sum - 1.0) > 1e-10:
        raise RuntimeError(f"crystalline weight fractions sum to {fraction_sum}")

    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    chi_square = float(np.sum(weights * difference * difference))
    rwp = float(100.0 * np.sqrt(chi_square / np.sum(weights * observed * observed)))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    if abs(rwp - float(hist.get_wR())) > 1e-10:
        raise RuntimeError("recomputed and saved Rwp disagree")

    cells: dict[str, dict[str, float]] = {}
    rows = []
    for phase in project.phases():
        if phase.name not in PHASE_INFO:
            raise RuntimeError(f"unexpected phase {phase.name}")
        info = PHASE_INFO[phase.name]
        fraction, esd = raw_fractions[phase.name]
        cell = {key: float(value) for key, value in phase.get_cell().items()}
        cells[phase.name] = cell
        rows.append({
            "name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "space_group_number": info["space_group_number"],
            "cif_path": info["cif"],
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(esd),
            "reference_cod_id": info["reference_cod_id"],
            "unit_cell": cell,
        })

    # Export the saved atoms rather than any stale coordinate entries that may
    # remain in a covariance record from an earlier refinement stage. This is
    # an in-memory export safeguard; final.gpx is never saved or changed here.
    project.data["Covariance"]["data"] = {}
    for phase in project.phases():
        phase.export_CIF(str(ROOT / PHASE_INFO[phase.name]["cif"]))

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        writer.writerows(zip(x, observed, calculated, difference))

    result = {
        "schema_version": 1,
        "project_path": "final.gpx",
        "refinement_histogram": hist.name,
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": rows,
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "GOF": float(rvals["GOF"]),
            "chi_square": chi_square,
            "n_observations": int(rvals["Nobs"]),
            "n_refined_parameters": int(rvals["Nvars"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "converged": bool(rvals["converged"]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    fractions = {row["name"]: row for row in rows}
    report = f"""# Powder XRD phase analysis

## Result

The pattern is described by three crystalline phases. Weight fractions are normalized over these modeled crystalline phases; they do not measure amorphous material.

| Phase | Space group | Refined cell | Crystalline weight fraction |
|---|---|---|---:|
| Ba₃W₂O₉ | R−3c (No. 167) | {cell_text('Ba3W2O9', cells['Ba3W2O9'])} | {100*fractions['Ba3W2O9']['weight_fraction']:.4f} ± {100*fractions['Ba3W2O9']['weight_fraction_esd']:.4f} wt% |
| WO₃ | P2₁/c (No. 14) | {cell_text('WO3', cells['WO3'])} | {100*fractions['WO3']['weight_fraction']:.4f} ± {100*fractions['WO3']['weight_fraction_esd']:.4f} wt% |
| BaCO₃ | Pmcn setting of No. 62 | {cell_text('BaCO3', cells['BaCO3'])} | {100*fractions['BaCO3']['weight_fraction']:.4f} ± {100*fractions['BaCO3']['weight_fraction_esd']:.4f} wt% |

The final fit has Rwp = {rwp:.5f}%, Rp = {rp:.5f}%, GOF = {float(rvals['GOF']):.4f}, and χ² = {chi_square:.2f} for {int(rvals['Nobs']):,} observations. The quoted fraction uncertainties are formal one-standard-deviation scale/covariance estimates; model and texture systematics are larger than those formal errors.

## Evidence

- Ba₃W₂O₉ (starting COD 1533878) accounts for the dominant broad family at approximately 16.42, 17.72, 26.20, 27.70, 30.78, 32.99, 37.60, 40.75, and 42.96° 2θ.
- Monoclinic WO₃ accounts for the characteristic 23.35/23.82/24.61° triplet and its higher-angle family. Equally developed WO₃ parents were compared: the 1966 neutron topology (COD 2311041) reached about 3.7% Rwp before final polish, versus about 5.0% for the 1960 parent (COD 1528915), so the latter basin was discarded.
- Orthorhombic BaCO₃ (starting COD 9010928) is supported by a narrow, positive family near 19.69, 24.13, 34.81, 42.23, and 45.07° 2θ. Its refined contribution remains positive across that family.
- The phase inventory gives Ba:W ≈ 1.02:1 on a molar basis, consistent with the stated 1:1 BaCO₃/WO₃ precursor ratio. No independent coherent family remains for BaWO₄ or another crystalline phase.

## Model completion and checks

Cells, scales, a 12-term smooth background, bounded specimen displacement, profile terms, and supported March–Dollase texture were developed before the required polish. Ba₃W₂O₉ and WO₃ prefer [110] texture axes; minor BaCO₃ prefers [001]. Isotropic strain is retained because deleting it produces large, reproducible fit losses, while tested uniaxial axes were not distinguishable within uncertainty. Surface roughness was discarded because all physical starts ran to bounds or became singular. Joint zero/displacement and polarization/Uiso alternatives were also rejected as inseparable; zero was fixed at 0°, polarization at 0.7, and the bounded displacement is −398.79 μm.

The single supplied bounded polish selected its all-coordinate branch. It converged with maximum shift/esd {float(rvals['Max shft/sig']):.3f}, no frozen variables, no catastrophic contacts, no pair contraction over 0.18 Å, and no fraction collapse. A fresh native GSAS-II replay regenerated reflections without optimization, left `final.gpx` unchanged, raised no profile-review flags, and reproduced Rwp to better than 0.000001 percentage point.

## Remaining uncertainty

The phase identities and three-phase fraction vector are well supported, but the formal fraction errors do not include uncertainty from correlated texture, Uiso, background, or overlapping peaks. The WO₃ coherent-domain size could not be determined reliably (its test reached a bound and was rolled back), and anisotropic strain is not resolved. Oxygen coordinates—especially in 4.8 wt% BaCO₃—should be regarded as bounded powder refinements rather than single-crystal precision. No amorphous fraction can be inferred from this refinement.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
