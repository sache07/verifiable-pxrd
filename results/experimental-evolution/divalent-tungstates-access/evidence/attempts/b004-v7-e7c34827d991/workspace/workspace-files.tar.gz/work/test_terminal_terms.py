#!/usr/bin/env python3
"""Compare equally developed bounded profile/specimen branches before polish."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "work" / "terminal_tests"
BASE = ROOT / "work" / "checkpoints" / "alt_uiso_settle.gpx"


def correlations(project: G2.G2Project) -> list[dict]:
    data = project.data.get("Covariance", {}).get("data", {})
    variables = [str(v) for v in data.get("varyList", [])]
    matrix = np.asarray(data.get("covMatrix", []), dtype=float)
    if matrix.shape != (len(variables), len(variables)) or not len(variables):
        return []
    sigma = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    denom = np.outer(sigma, sigma)
    with np.errstate(invalid="ignore", divide="ignore"):
        corr = matrix / denom
    pairs = []
    for i in range(len(variables)):
        for j in range(i):
            value = float(corr[i, j])
            if math.isfinite(value):
                pairs.append({"abs": abs(value), "value": value,
                              "a": variables[i], "b": variables[j]})
    return sorted(pairs, key=lambda row: row["abs"], reverse=True)


def summary(project: G2.G2Project, label: str, values: dict) -> dict:
    hist = project.histograms()[0]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    pairs = correlations(project)
    return {
        "label": label,
        "Rwp": float(hist.get_wR()),
        "chi2": float(rvals.get("chisq", float("nan"))),
        "GOF": float(rvals.get("GOF", float("nan"))),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        "nvars": int(rvals.get("Nvars", 0)),
        "frozen": [str(v) for v in project.get_Frozen()],
        "values": values,
        "top_correlations": pairs[:12],
    }


def run_branch(label: str, configure, value_reader, base: Path = BASE) -> dict:
    project = G2.G2Project(gpxfile=str(base))
    path = OUT / f"{label}.gpx"
    # set_Controls writes the currently named project, so isolate the branch
    # before changing flags or limits.
    project.save(str(path))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    configure(project)
    project.set_Controls("cycles", 15)
    project.save()
    project.refine(makeBack=False)
    project.save()
    # Equal second checkpoint lets new and existing terms settle together.
    project.set_Controls("cycles", 12)
    project.refine(makeBack=False)
    project.save()
    result = summary(project, label, value_reader(project))
    (OUT / f"{label}.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
    return result


def instrument_tests(base: Path) -> None:
    def polariz(project):
        inst = project.histograms()[0].data["Instrument Parameters"][0]
        inst["Polariz."][2] = True
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    run_branch("instrument_polarization", polariz,
               lambda p: {"polarization": p.histograms()[0].data["Instrument Parameters"][0]["Polariz."][1]}, base)

    def shl(project):
        inst = project.histograms()[0].data["Instrument Parameters"][0]
        inst["SH/L"][2] = True
        project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
        project.set_Controls("parmMax", 0.10, variable=":0:SH/L")

    run_branch("instrument_shl", shl,
               lambda p: {"SH_L": p.histograms()[0].data["Instrument Parameters"][0]["SH/L"][1]}, base)


def strain_tests(base: Path) -> None:
    for phase_name in ("Ba3W2O9", "WO3", "BaCO3"):
        for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0]):
            axis_text = "".join(str(v) for v in axis)
            label = f"strain_{phase_name.lower()}_{axis_text}"

            def configure(project, phase_name=phase_name, axis=axis):
                hist = project.histograms()[0]
                phase = project.phase(phase_name)
                hap = phase.data["Histograms"][hist.name]
                equatorial = float(hap["Mustrain"][1][0])
                hap["Mustrain"][0] = "uniaxial"
                hap["Mustrain"][1][0] = equatorial
                hap["Mustrain"][1][1] = equatorial
                hap["Mustrain"][2][0] = True
                hap["Mustrain"][2][1] = True
                hap["Mustrain"][3] = list(axis)
                pid = phase.data["pId"]
                for suffix in ("i", "a"):
                    project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;{suffix}")
                    project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;{suffix}")

            def reader(project, phase_name=phase_name):
                hist = project.histograms()[0]
                values = project.phase(phase_name).data["Histograms"][hist.name]["Mustrain"]
                return {"phase": phase_name, "model": values[0], "equatorial": values[1][0],
                        "axial": values[1][1], "axis": values[3]}

            run_branch(label, configure, reader, base)


def texture_tests(base: Path) -> None:
    for axis in ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]):
        axis_text = "".join(str(v) for v in axis)
        label = f"texture_baco3_{axis_text}"

        def configure(project, axis=axis):
            hist = project.histograms()[0]
            phase = project.phase("BaCO3")
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")

        def reader(project):
            hist = project.histograms()[0]
            values = project.phase("BaCO3").data["Histograms"][hist.name]["Pref.Ori."]
            return {"ratio": values[1], "axis": values[3]}

        run_branch(label, configure, reader, base)


def roughness_tests(base: Path) -> None:
    starts = ((0.10, 0.03), (0.20, 0.10), (0.40, 0.30), (0.55, 0.45))
    for index, (start_a, start_b) in enumerate(starts, start=1):
        label = f"roughness_start{index}"

        def configure(project, start_a=start_a, start_b=start_b):
            sample = project.histograms()[0].data["Sample Parameters"]
            sample["SurfRoughA"] = [start_a, True]
            sample["SurfRoughB"] = [start_b, True]
            project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
            project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
            project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
            project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")

        def reader(project):
            sample = project.histograms()[0].data["Sample Parameters"]
            return {"A": sample["SurfRoughA"][0], "B": sample["SurfRoughB"][0]}

        run_branch(label, configure, reader, base)


def strain_necessity_tests(base: Path) -> None:
    """Set one strain contribution to zero and reoptimize size/profile terms."""
    for phase_name in ("Ba3W2O9", "WO3", "BaCO3"):
        label = f"no_strain_{phase_name.lower()}"

        def configure(project, phase_name=phase_name):
            hist = project.histograms()[0]
            hap = project.phase(phase_name).data["Histograms"][hist.name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][1][1] = 0.0
            hap["Mustrain"][2] = [False, False, False]

        def reader(project, phase_name=phase_name):
            hist = project.histograms()[0]
            hap = project.phase(phase_name).data["Histograms"][hist.name]
            return {"phase": phase_name, "size": hap["Size"][1][0],
                    "strain": hap["Mustrain"][1][0]}

        run_branch(label, configure, reader, base)


def control_test(base: Path) -> None:
    run_branch("control_settle", lambda project: None,
               lambda project: {"note": "no added parameter"}, base)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("group", choices=("instrument", "strain", "texture", "roughness", "necessity", "control", "all"))
    parser.add_argument("--base", type=Path, default=BASE)
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if args.group in ("instrument", "all"):
        instrument_tests(args.base)
    if args.group in ("strain", "all"):
        strain_tests(args.base)
    if args.group in ("texture", "all"):
        texture_tests(args.base)
    if args.group in ("roughness", "all"):
        roughness_tests(args.base)
    if args.group in ("necessity", "all"):
        strain_necessity_tests(args.base)
    if args.group in ("control", "all"):
        control_test(args.base)


if __name__ == "__main__":
    main()
