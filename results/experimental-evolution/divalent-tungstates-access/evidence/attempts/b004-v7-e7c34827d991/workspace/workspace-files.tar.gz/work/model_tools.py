#!/usr/bin/env python3
"""Build, inspect and export the local GSAS-II powder model."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
INSTPRM = ROOT / "work" / "instrument.instprm"

PHASES = {
    "ba3w2o9": ("1533878", "Ba3W2O9"),
    "wo3_1960": ("1528915", "WO3"),
    "wo3_1966": ("2311041", "WO3"),
    "baco3": ("9010928", "BaCO3"),
    "bawo4": ("1527204", "BaWO4"),
    "ba3wo6": ("1534803", "Ba3WO6"),
    "bao2": ("1010113", "BaO2"),
}


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def read_pattern() -> tuple[np.ndarray, np.ndarray]:
    rows = np.genfromtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", names=True)
    return np.asarray(rows["two_theta_deg"], float), np.asarray(rows["intensity"], float)


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    try:
        values = hist.ComputeMassFracs()
    except Exception:
        values = {}
    if values:
        return {str(k): float(v[0]) for k, v in values.items()}
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if not hap or not hap.get("Use", True):
            continue
        weighted[phase.name] = max(0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(weighted.values())
    return {k: v / total for k, v in weighted.items()} if total > 0 else {}


def build(output: Path, phase_keys: list[str]) -> None:
    project = G2.G2Project(newgpx=str(output))
    phases = []
    for key in phase_keys:
        cod_id, name = PHASES[key]
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, fmthint="CIF"
        )
        phases.append(phase)
        for atom in phase.atoms():
            if atom.adp_flag == "I" and atom.uiso <= 0:
                atom.uiso = 0.01

    x, y = read_pattern()
    hist = project.add_simulated_powder_histogram(
        "observed", str(INSTPRM), float(x[0]), float(x[-1]),
        Npoints=len(x), phases=phases,
    )
    data = hist.data["data"]
    data[0]["Dummy"] = False
    data[1][0] = x.copy()
    data[1][1] = y.copy()
    data[1][2] = 1.0 / np.maximum(y, 1.0)
    for array in data[1][3:]:
        array[:] = 0.0
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"][0] = -400.0

    # A smooth starting background. Refinement replaces these coefficients.
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1100.0, -400.0, 250.0, -120.0] + [0.0] * 8,
            "refine": False,
        }
    })

    # Keep positive phase scales and initialize comparable contributions.
    project.index_ids()
    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        phase.set_refinements({"LeBail": False})
        project.set_Controls("parmMin", 0.0, variable=f"{phase.data['pId']}:0:Scale")

    project.set_Controls("cycles", 8)
    project.save()
    inspect_project(output, verbose=True)


def convergence(project: G2.G2Project) -> dict:
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "Rwp": rvals.get("Rwp"),
        "GOF": rvals.get("GOF"),
        "Nvars": rvals.get("Nvars"),
    }


def inspect_project(path: Path, verbose: bool = False) -> dict:
    project = G2.G2Project(gpxfile=str(path))
    hist = project.histograms()[0]
    report = {
        "project": str(path),
        "histogram": hist.name,
        "Rwp_percent": None if hist.get_wR() is None else float(hist.get_wR()),
        "convergence": convergence(project),
        "mass_fractions": mass_fractions(project),
        "background": hist.data["Background"],
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "phases": {},
        "frozen": [str(v) for v in project.get_Frozen()],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        report["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap.get("Scale"),
            "size": hap.get("Size"),
            "mustrain": hap.get("Mustrain"),
            "pref_ori": hap.get("Pref.Ori."),
            "hstrain": hap.get("HStrain"),
            "atoms": [
                {
                    "label": atom.label,
                    "element": atom.element,
                    "xyz": list(atom.coordinates),
                    "uiso": atom.uiso if atom.adp_flag == "I" else atom.ADP,
                    "flags": atom.refinement_flags,
                }
                for atom in phase.atoms()
            ],
        }
    if verbose:
        print(json.dumps(report, indent=2, default=str))
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("build")
    p.add_argument("output", type=Path)
    p.add_argument("phases", nargs="+", choices=sorted(PHASES))
    p = sub.add_parser("inspect")
    p.add_argument("project", type=Path)
    args = parser.parse_args()
    if args.command == "build":
        build(args.output, args.phases)
    elif args.command == "inspect":
        inspect_project(args.project, verbose=True)


if __name__ == "__main__":
    main()
