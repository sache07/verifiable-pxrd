#!/usr/bin/env python3
"""Export the accepted GSAS-II model and machine-readable deliverables."""

from __future__ import annotations

import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp/full_grid_scale_final/scale_background.gpx"
FINAL_GPX = ROOT / "final.gpx"

PHASE_INFO = [
    {
        "name": "MnWO4 (wolframite)",
        "formula": "MnWO4",
        "cod_id": "1520200",
        "cif_path": "phase_MnWO4.cif",
    },
    {
        "name": "Mn3WO6 (rhombohedral)",
        "formula": "Mn3WO6",
        "cod_id": "2002703",
        "cif_path": "phase_Mn3WO6.cif",
    },
    {
        "name": "WO3 (monoclinic)",
        "formula": "WO3",
        "cod_id": "2311041",
        "cif_path": "phase_WO3.cif",
    },
]


def main() -> None:
    shutil.copy2(SOURCE, FINAL_GPX)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(FINAL_GPX))
    histogram = project.histogram(0)

    if len(project.phases()) != len(PHASE_INFO):
        raise RuntimeError(f"expected 3 phases, found {len(project.phases())}")

    fractions_raw = histogram.ComputeMassFracs()
    values = [float(fractions_raw[phase.name][0]) for phase in project.phases()]
    esds = [float(fractions_raw[phase.name][1]) for phase in project.phases()]
    total = sum(values)
    fractions = [value / total for value in values]

    phase_results = []
    for phase, info, fraction, esd in zip(project.phases(), PHASE_INFO, fractions, esds):
        cif_path = ROOT / info["cif_path"]
        phase.export_CIF(str(cif_path))
        cell = {key: float(value) for key, value in phase.get_cell().items()}
        phase_results.append(
            {
                **info,
                "project_phase_name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "weight_fraction": fraction,
                "weight_percent": 100.0 * fraction,
                "formal_weight_fraction_esd": esd / total,
                "cell": cell,
            }
        )

    arrays = histogram.data["data"][1]
    two_theta = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    weights = np.asarray(arrays[2], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    difference = observed - calculated

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "difference"])
        writer.writerows(
            (f"{x:.8f}", f"{yo:.8f}", f"{yc:.8f}", f"{dy:.8f}")
            for x, yo, yc, dy in zip(two_theta, observed, calculated, difference)
        )

    rvals = project.data["Covariance"]["data"]["Rvals"]
    rwp = float(rvals["Rwp"])
    gof = float(rvals["GOF"])
    rp = float(histogram.data["data"][0]["R"])
    fit_statistics = {
        "Rwp_percent": rwp,
        "Rp_percent": rp,
        "GOF": gof,
        "R_expected_percent": rwp / gof,
        "weighted_chi_square": float(rvals["chisq"]),
        "n_observations_refined": int(rvals["Nobs"]),
        "n_variables_last_refinement": int(rvals["Nvars"]),
        "n_profile_points_exported": int(two_theta.size),
        "two_theta_refinement_range_deg": [
            float(histogram.data["Limits"][1][0]),
            float(histogram.data["Limits"][1][1]),
        ],
        "converged": bool(rvals.get("converged", False)),
        "weighting": "sigma_i=sqrt(max(observed_counts_i,1)); w_i=1/sigma_i^2",
    }

    result = {
        "phases": phase_results,
        "weight_fraction_basis": "normalized over the three modeled crystalline phases",
        "weight_fraction_sum": sum(item["weight_fraction"] for item in phase_results),
        "fit_statistics": fit_statistics,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    # A simple reaction-scale consistency check used in the report.
    molar_mass = {"MnWO4": 302.774, "Mn3WO6": 444.648, "WO3": 231.837}
    formula_moles = {
        info["formula"]: fraction / molar_mass[info["formula"]]
        for info, fraction in zip(PHASE_INFO, fractions)
    }
    mn_moles = formula_moles["MnWO4"] + 3.0 * formula_moles["Mn3WO6"]
    w_moles = sum(formula_moles.values())
    summary = {
        "fit_statistics": fit_statistics,
        "fractions": {item["formula"]: item["weight_fraction"] for item in phase_results},
        "Mn_to_W_atomic_ratio_from_crystalline_inventory": mn_moles / w_moles,
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
