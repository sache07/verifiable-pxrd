#!/usr/bin/env python3
"""Build and refine trial GSAS-II multiphase models for the supplied scan."""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

PHASES = {
    "MnWO4": ("1520200", "wolframite MnWO4"),
    "Mn3WO6": ("2002703", "rhombohedral Mn3WO6"),
    "WO3_mono": ("1528915", "monoclinic WO3"),
    "WO3_tri": ("2106293", "triclinic WO3"),
    "WO3_pnma": ("2107312", "orthorhombic WO3"),
    "WO3_mono_small": ("1563541", "monoclinic WO3 small cell"),
    "WO3_mono66": ("2311041", "monoclinic WO3 (1966)"),
    "Mn3O4_tet": ("9001963", "tetragonal Mn3O4"),
    "Mn3O4_ortho": ("1541183", "orthorhombic Mn3O4"),
}


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_inputs(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    raw = np.genfromtxt(ROOT / "inputs/pattern.csv", delimiter=",", names=True)
    x = np.asarray(raw["two_theta_deg"], dtype=float)
    y = np.asarray(raw["intensity"], dtype=float)
    # Original uncertainties were not supplied. Counting-statistical weights are
    # the least-assumptive choice for the raw counts.
    sig = np.sqrt(np.maximum(y, 1.0))
    xye = work / "pattern.xye"
    np.savetxt(xye, np.column_stack([x, y, sig]), fmt="%.8f %.8f %.8f")
    inst = work / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def metric(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    arr = hist.data["data"][1]
    x, yo, w, yc, bkg, yd = [np.asarray(a, dtype=float) for a in arr[:6]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    resid = yo[use] - yc[use]
    # Rwp from arrays is included as an independently transparent check.
    den = float(np.sum(w[use] * yo[use] ** 2))
    rwp_arr = 100.0 * math.sqrt(float(np.sum(w[use] * resid**2)) / den)
    wr = hist.get_wR()
    rp = hist.data["data"][0].get("R", float("nan"))
    out = {
        "Rwp_percent": float(wr) if wr is not None else float("nan"),
        "Rwp_array_percent": rwp_arr,
        "Rp_percent": float(rp) if rp is not None else float("nan"),
        "GOF": float(project.data["Covariance"]["data"].get("Rvals", {}).get("GOF", float("nan"))),
        "Nobs": int(np.count_nonzero(use)),
        "max_abs_difference": float(np.max(np.abs(resid))),
    }
    try:
        out["mass_fractions"] = {
            k: {"value": float(v[0]), "esd": float(v[1])}
            for k, v in hist.ComputeMassFracs().items()
        }
    except Exception as exc:
        out["mass_fraction_error"] = repr(exc)
    return out


def phase_state(project: G2.G2Project) -> dict:
    out = {}
    hname = project.histogram(0).name
    for phase in project.phases():
        hap = phase.data["Histograms"][hname]
        out[phase.name] = {
            "cell": phase.get_cell(),
            "scale": list(hap["Scale"]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return out


def snapshot(project: G2.G2Project, outdir: Path, tag: str, history: list[dict]) -> None:
    gpx = outdir / f"{tag}.gpx"
    project.save(str(gpx))
    rec = {"tag": tag, **metric(project), "phase_state": phase_state(project)}
    history.append(rec)
    (outdir / "history.json").write_text(json.dumps(history, indent=2, allow_nan=True) + "\n")
    print(json.dumps({k: v for k, v in rec.items() if k != "phase_state"}, indent=2))


def refine(project: G2.G2Project, outdir: Path, tag: str, history: list[dict]) -> None:
    project.set_Controls("cycles", 8)
    project.refine()
    snapshot(project, outdir, tag, history)


def build(outdir: Path, keys: list[str]) -> G2.G2Project:
    xye, inst = make_inputs(outdir)
    project = G2.G2Project(newgpx=str(outdir / "trial.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 6,
                "coeffs": [4000.0, 0.0, 0.0, 0.0, 0.0, 0.0],
                "refine": False,
            },
        }
    )
    for key in keys:
        cod_id, name = PHASES[key]
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=f"{name} [COD {cod_id}]", histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Extinction"] = [0.0, False]
    # Broad physical bounds. Out-of-range variables are pinned and frozen by
    # GSAS-II, which prevents a better numerical fit from becoming a bad model.
    project.set_Controls("parmMin", 0.0, variable="*:0:Scale")
    project.set_Controls("parmMin", 0.01, variable="*:0:Size;i")
    project.set_Controls("parmMax", 10.0, variable="*:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable="*:0:Mustrain;i")
    project.set_Controls("parmMax", 10000.0, variable="*:0:Mustrain;i")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    project.set_Controls("parmMin", 2.0, variable=":0:W")
    project.set_Controls("parmMax", 40.0, variable=":0:W")
    project.set_Controls("parmMin", 0.1, variable=":0:X")
    project.set_Controls("parmMax", 6.0, variable=":0:X")
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.1, variable=":0:SH/L")
    project.save()
    return project


def run(outdir: Path, keys: list[str]) -> None:
    if outdir.exists():
        shutil.rmtree(outdir)
    outdir.mkdir(parents=True)
    G2.SetPrintLevel("warn")
    project = build(outdir, keys)
    hist = project.histogram(0)
    history: list[dict] = []
    snapshot(project, outdir, "00_setup", history)

    # Establish scales and a smooth baseline before metric/nonlinear terms.
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, outdir, "01_scale_background", history)

    # Correct the common Bragg-Brentano specimen displacement and unit cells.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, outdir, "02_shift", history)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, outdir, "03_cells", history)

    # Instrument profile first, then phase-specific broadening.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, outdir, "04_instrument", history)
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
            }
        )
    refine(project, outdir, "05_phase_size", history)
    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, outdir, "06_phase_mustrain", history)

    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    refine(project, outdir, "07_axial", history)

    # Add only modest smooth-background flexibility after all peak families are represented.
    hist.set_refinements({"Background": {"no. coeffs": 10, "refine": True}})
    refine(project, outdir, "08_background10", history)

    project.save(str(outdir / "best.gpx"))
    (outdir / "summary.json").write_text(
        json.dumps({"phases": keys, "metrics": metric(project), "state": phase_state(project)}, indent=2, allow_nan=True)
        + "\n"
    )


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("outdir", type=Path)
    ap.add_argument("phases", nargs="+", choices=sorted(PHASES))
    args = ap.parse_args()
    run(args.outdir.resolve(), args.phases)


if __name__ == "__main__":
    main()
