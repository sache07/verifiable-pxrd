#!/usr/bin/env python3
"""Recalculate a frozen GSAS-II project and compare its stored profile."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from model_step import freeze_model
from rietveld_stage import metric


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("replay", type=Path)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    source = G2.G2Project(str(args.source.resolve()))
    before = metric(source)
    calc_before = np.asarray(source.histogram(0).data["data"][1][3], dtype=float).copy()

    replay = G2.G2Project(str(args.source.resolve()), newgpx=str(args.replay.resolve()))
    freeze_model(replay)
    replay.set_Controls("cycles", 0)
    replay.save()
    replay.refine()
    replay.save()

    after = metric(replay)
    calc_after = np.asarray(replay.histogram(0).data["data"][1][3], dtype=float)
    result = {
        "source": str(args.source.resolve()),
        "replay": str(args.replay.resolve()),
        "before": before,
        "after": after,
        "delta_Rwp_percent": after["Rwp_percent"] - before["Rwp_percent"],
        "max_abs_delta_calculated": float(np.max(np.abs(calc_after - calc_before))),
    }
    print(json.dumps(result, indent=2, allow_nan=True))


if __name__ == "__main__":
    main()
