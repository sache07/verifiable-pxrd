#!/usr/bin/env python3
"""Screen the allowed March-Dollase axes from a physical GSAS-II checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from rietveld_stage import metric


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def one(base: Path, root: Path, phase_index: int, axis: list[int]) -> dict:
    tag = f"p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
    outdir = root / tag
    outdir.mkdir(parents=True, exist_ok=True)
    outfile = outdir / "texture.gpx"
    project = G2.G2Project(str(base), newgpx=str(outfile))
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    po = phase.data["Histograms"][hist.name]["Pref.Ori."]
    po[0] = "MD"
    po[1] = 1.0
    po[2] = True
    po[3] = list(axis)
    project.set_Controls("parmMin", 0.7, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase_index}:0:MD")
    project.set_Controls("cycles", 6)
    project.save()
    project.refine()
    project.save()
    result = {
        "tag": tag,
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": axis,
        "ratio": float(po[1]),
        "ratio_refined": bool(po[2]),
        "metrics": metric(project),
        "frozen": project.get_Frozen(),
        "project": str(outfile),
    }
    (outdir / "summary.json").write_text(json.dumps(result, indent=2, allow_nan=True) + "\n")
    print(json.dumps(result), flush=True)
    return result


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("--phase", type=int)
    ap.add_argument("--axis", nargs=3, type=int)
    ap.add_argument("--all", action="store_true")
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    if args.all:
        results = [one(args.base.resolve(), args.outdir.resolve(), p, list(axis)) for p in range(3) for axis in AXES]
        (args.outdir / "all.json").write_text(json.dumps(results, indent=2, allow_nan=True) + "\n")
    else:
        if args.phase is None or args.axis is None:
            ap.error("provide --all or both --phase and --axis")
        one(args.base.resolve(), args.outdir.resolve(), args.phase, list(args.axis))


if __name__ == "__main__":
    main()
