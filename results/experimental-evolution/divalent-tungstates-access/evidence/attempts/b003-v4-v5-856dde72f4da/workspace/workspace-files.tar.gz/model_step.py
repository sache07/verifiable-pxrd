#!/usr/bin/env python3
"""Apply one controlled refinement step to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from rietveld_stage import cod_path, metric, phase_state


TEXTURES = {0: [1, 1, 1], 2: [0, 1, 0]}


def atom_state(project: G2.G2Project) -> dict:
    return {
        phase.name: {
            atom.label: {
                "element": atom.element,
                "coordinates": list(atom.coordinates),
                "refinement_flags": atom.refinement_flags,
                "occupancy": float(atom.occupancy),
            }
            for atom in phase.atoms()
        }
        for phase in project.phases()
    }


def set_coord_bounds(project: G2.G2Project, phase_ids: list[int], width: float = 0.02) -> None:
    axes = ("x", "y", "z")
    for pid in phase_ids:
        phase = project.phase(pid)
        for atom_index, atom in enumerate(phase.atoms()):
            for axis, start in zip(axes, atom.coordinates):
                variable = f"{pid}::dA{axis}:{atom_index}"
                # GSAS-II looks up a dA limit but applies it to the absolute A
                # coordinate, so limits must be centered on the starting value.
                project.set_Controls("parmMin", float(start) - width, variable=variable)
                project.set_Controls("parmMax", float(start) + width, variable=variable)


def freeze_model(project: G2.G2Project) -> None:
    """Turn off all existing flags so a branch tests only its new parameter(s)."""
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2 and isinstance(value[2], bool):
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = ""
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["HStrain"][1] = [False for _ in hap["HStrain"][1]]


def apply(project: G2.G2Project, action: str) -> None:
    hist = project.histogram(0)
    if action not in ("textures", "textures_all"):
        freeze_model(project)
    if action in ("textures", "textures_all", "textures_fixed", "textures_fixed_all"):
        # Reset texture choices so this step is reproducible from an untextured checkpoint.
        for phase in project.phases():
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[0], po[1], po[2], po[3] = "MD", 1.0, False, [0, 0, 1]
        choices = dict(TEXTURES)
        if action in ("textures_all", "textures_fixed_all"):
            choices[1] = [1, 1, 0]
        for pid, axis in choices.items():
            phase = project.phase(pid)
            po = phase.data["Histograms"][hist.name]["Pref.Ori."]
            po[1], po[2], po[3] = 1.0, True, list(axis)
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        # Keep coherent-domain sizes within the broad specimen range for this lab.
        if action in ("textures", "textures_all"):
            for pid in range(len(project.phases())):
                project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
    elif action.startswith("heavy"):
        all_selected = {0: {"Mn1", "W1"}, 1: {"Mn1", "W1", "W2"}, 2: {"W1", "W2"}}
        if action == "heavy":
            selected = all_selected
        else:
            pid = int(action[-1])
            selected = {pid: all_selected[pid]}
        for pid, labels in selected.items():
            phase = project.phase(pid)
            for label in labels:
                phase.atom(label).refinement_flags = "X"
        set_coord_bounds(project, list(selected), width=0.005)
    elif action.startswith("oxygen"):
        pid = int(action[-1])
        phase = project.phase(pid)
        for atom in phase.atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
        set_coord_bounds(project, [pid], width=0.005)
    elif action == "add_mn3o4":
        phase = project.add_phase(
            str(cod_path("9001963")),
            phasename="tetragonal Mn3O4 test [COD 9001963]",
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [0.5, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.2
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        project.set_Controls("parmMin", 0.0, variable="3:0:Scale")
    elif action == "scale_background":
        hist.data["Background"][0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    elif action == "cells_shift":
        hist.data["Sample Parameters"]["Shift"][1] = True
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    elif action == "profile":
        hist.data["Instrument Parameters"][0]["W"][2] = True
        for pid, phase in enumerate(project.phases()):
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][2][0] = True
            project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.phase(2).data["Histograms"][hist.name]["Mustrain"][2][0] = True
    elif action == "texture_existing":
        for pid, phase in enumerate(project.phases()):
            phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
    elif action == "calibration":
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
        hist.data["Sample Parameters"]["Shift"][1] = True
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")
        project.set_Controls("parmMin", -800.0, variable=":0:Shift")
        project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    elif action == "polarization":
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    elif action in ("joint_intensity", "full_grid_joint", "joint_all"):
        # Final coordinate-descent consolidation: refine the mutually coupled
        # intensity terms together after each has been independently supported.
        if action in ("full_grid_joint", "joint_all"):
            hist.data["Limits"][1] = list(hist.data["Limits"][0])
        hist.data["Background"][0][1] = True
        hist.data["Instrument Parameters"][0]["Polariz."][2] = True
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        for pid, phase in enumerate(project.phases()):
            phase.data["Histograms"][hist.name]["Scale"][1] = True
            phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        if action == "joint_all":
            hist.data["Sample Parameters"]["Shift"][1] = True
            for phase in project.phases():
                phase.data["General"]["Cell"][0] = True
    elif action == "surface":
        hist.data["Sample Parameters"]["SurfRoughA"] = [0.1, True]
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.6, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    elif action == "mustrain_p0_fixed":
        ms = project.phase(0).data["Histograms"][hist.name]["Mustrain"]
        ms[0] = "uniaxial"
        ms[1][0] = 300.0
        ms[1][1] = 75.0
        ms[2] = [False for _ in ms[2]]
        ms[3] = [0, 0, 1]
    else:
        raise ValueError(action)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument(
        "action",
        choices=[
            "textures", "textures_all", "textures_fixed", "textures_fixed_all",
            "heavy", "heavy0", "heavy1", "heavy2",
            "oxygen0", "oxygen1", "oxygen2", "add_mn3o4",
            "scale_background", "cells_shift", "profile",
            "texture_existing", "calibration", "polarization", "surface",
            "mustrain_p0_fixed", "joint_intensity", "full_grid_joint", "joint_all",
        ],
    )
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    outfile = (args.outdir / f"{args.action}.gpx").resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.base.resolve()), newgpx=str(outfile))
    apply(project, args.action)
    project.set_Controls("cycles", 12)
    project.save()
    project.refine()
    project.save()
    result = {
        "action": args.action,
        "project": str(outfile),
        "metrics": metric(project),
        "phase_state": phase_state(project),
        "atom_state": atom_state(project),
        "frozen": project.get_Frozen(),
        "vary_list": project.data["Covariance"]["data"].get("varyList", []),
    }
    (args.outdir / f"{args.action}.json").write_text(json.dumps(result, indent=2, allow_nan=True) + "\n")
    print(json.dumps({k: v for k, v in result.items() if k not in ("phase_state", "atom_state", "vary_list")}, indent=2))


if __name__ == "__main__":
    main()
