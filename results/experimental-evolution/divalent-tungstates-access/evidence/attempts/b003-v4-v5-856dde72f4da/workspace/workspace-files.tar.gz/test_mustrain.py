#!/usr/bin/env python3
"""Test one bounded uniaxial microstrain model from a replayable checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from model_step import freeze_model
from rietveld_stage import metric


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("outdir", type=Path)
    ap.add_argument("phase", type=int)
    ap.add_argument("axis", nargs=3, type=int)
    args = ap.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    tag = f"p{args.phase}_{''.join(map(str,args.axis))}"
    outfile = (args.outdir / f"{tag}.gpx").resolve()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(str(args.base.resolve()), newgpx=str(outfile))
    freeze_model(project)
    hist = project.histogram(0)
    phase = project.phase(args.phase)
    ms = phase.data["Histograms"][hist.name]["Mustrain"]
    ms[0] = "uniaxial"
    ms[1][0] = 500.0
    ms[1][1] = 500.0
    ms[2][0] = True
    ms[2][1] = True
    ms[3] = list(args.axis)
    for name in ("Mustrain;i", "Mustrain;a"):
        project.set_Controls("parmMin", 0.0, variable=f"{args.phase}:0:{name}")
        project.set_Controls("parmMax", 8000.0, variable=f"{args.phase}:0:{name}")
    project.set_Controls("cycles", 10)
    project.save()
    project.refine()
    project.save()
    result = {
        "tag": tag,
        "phase": phase.name,
        "axis": args.axis,
        "mustrain": ms,
        "metrics": metric(project),
        "frozen": project.get_Frozen(),
        "project": str(outfile),
    }
    (args.outdir / f"{tag}.json").write_text(json.dumps(result, indent=2, allow_nan=True) + "\n")
    print(json.dumps(result, indent=2, allow_nan=True))


if __name__ == "__main__":
    main()
