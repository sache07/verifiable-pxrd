#!/usr/bin/env python3
"""Build Mn2WO5 trial models from every accessible ordered A2BO5 framework."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

from pymatgen.core import Composition, Structure
from pymatgen.io.cif import CifParser, CifWriter


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/index.json.gz"
)
CIFS = INDEX.parent / "cif"
OUTPUT = Path("analysis/a2bo5_trials")
TARGET_VOLUME_PER_FORMULA = 123.0


def cod_path(record: str) -> Path:
    return CIFS / record[0] / record[1:3] / record[3:5] / f"{record}.cif"


def reduced_counts(formula: str) -> dict[str, float]:
    return Composition(formula).reduced_composition.get_el_amt_dict()


def read_structure(path: Path) -> Structure:
    try:
        return Structure.from_file(path, primitive=False)
    except (ValueError, KeyError, IndexError):
        return CifParser(path, occupancy_tolerance=2.1).parse_structures(primitive=False)[0]


def main() -> None:
    OUTPUT.mkdir(parents=True, exist_ok=True)
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)

    candidates = []
    for system, records in index.items():
        elements = system.split("-")
        if len(elements) != 3 or "O" not in elements:
            continue
        for formula, record, listed_sg, r_factor in records:
            try:
                counts = reduced_counts(formula)
            except Exception:
                continue
            if len(counts) != 3 or abs(counts.get("O", 0.0) - 5.0) > 1e-6:
                continue
            cations = {element: amount for element, amount in counts.items() if element != "O"}
            if sorted(cations.values()) != [1.0, 2.0]:
                continue
            candidates.append((formula, str(record), listed_sg, r_factor, cations))

    manifest = []
    for formula, record, listed_sg, r_factor, cations in candidates:
        source = cod_path(record)
        try:
            structure = read_structure(source)
            if not structure.is_ordered:
                raise ValueError("disordered structure")
            structure.remove_oxidation_states()
            substitutions = {
                element: ("Mn" if abs(amount - 2.0) < 1e-6 else "W")
                for element, amount in cations.items()
            }
            structure.replace_species(substitutions)
            if structure.composition.reduced_formula != "Mn2WO5":
                raise ValueError(f"unexpected substituted formula {structure.composition.reduced_formula}")
            _, z = structure.composition.get_reduced_composition_and_factor()
            target_volume = TARGET_VOLUME_PER_FORMULA * float(z)
            structure.scale_lattice(target_volume)
            sg_symbol, sg_number = structure.get_space_group_info(symprec=0.001)
            path = OUTPUT / f"{record}.cif"
            CifWriter(structure, symprec=0.001, significant_figures=10).write_file(path)
            manifest.append(
                {
                    "cod_id": record,
                    "parent_formula": formula,
                    "parent_space_group_listed": listed_sg,
                    "parent_r_factor": r_factor,
                    "substitutions": substitutions,
                    "trial_space_group": sg_symbol,
                    "trial_space_group_number": sg_number,
                    "z": float(z),
                    "cell": [*structure.lattice.abc, *structure.lattice.angles],
                    "cif": str(path),
                }
            )
        except Exception as error:
            manifest.append(
                {
                    "cod_id": record,
                    "parent_formula": formula,
                    "parent_space_group_listed": listed_sg,
                    "status": "skipped",
                    "error": f"{type(error).__name__}: {error}",
                }
            )

    Path("analysis/a2bo5_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    accepted = [row for row in manifest if "cif" in row]
    print(f"inventory={len(candidates)} written={len(accepted)} skipped={len(manifest)-len(accepted)}")
    counts: dict[str, int] = {}
    for row in accepted:
        key = f"{row['trial_space_group']} ({row['trial_space_group_number']})"
        counts[key] = counts.get(key, 0) + 1
    for key, count in sorted(counts.items(), key=lambda item: (-item[1], item[0])):
        print(f"{count:3d} {key}")


if __name__ == "__main__":
    main()
