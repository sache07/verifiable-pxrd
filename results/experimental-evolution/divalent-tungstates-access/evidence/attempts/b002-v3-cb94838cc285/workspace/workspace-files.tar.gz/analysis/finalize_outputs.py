#!/usr/bin/env python3
"""Create submission tables from the independently replayed final project."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
REPLAY = ROOT / ".tmp" / "replay_final"


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"final project did not replay: {replay}")
    if replay.get("profile_review_flags"):
        raise RuntimeError(f"replay profile review flags: {replay['profile_review_flags']}")

    arrays = np.load(REPLAY / "prediction.npz")
    x = arrays["x"]
    observed = arrays["observed"]
    calculated = arrays["predicted"]
    background = arrays["background"]
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_chi_square = float(np.sum(weights * difference**2))
    rwp = float(
        100.0
        * np.sqrt(weighted_chi_square / np.sum(weights * observed**2))
    )
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta_deg", "observed", "calculated", "background", "difference"]
        )
        writer.writerows(
            zip(x, observed, calculated, background, difference, strict=True)
        )

    project = G2.G2Project(gpxfile=str(ROOT / "final.gpx"))
    histogram = project.histograms()[0]
    gof = float(
        project.data["Covariance"]["data"]["Rvals"]["GOF"]
    )
    cifs = {
        "MnWO4": "phase_mnwo4.cif",
        "WO3": "phase_wo3.cif",
        "Mn2WO5": "phase_mn2wo5.cif",
    }
    names = {
        "MnWO4": "MnWO4 (wolframite)",
        "WO3": "WO3 (monoclinic)",
        "Mn2WO5": "Mn2WO5 (analogue-derived)",
    }
    formulas = {"MnWO4": "MnWO4", "WO3": "WO3", "Mn2WO5": "Mn2WO5"}

    phase_rows = []
    for row in replay["phases"]:
        name = row["name"]
        phase = project.phase(name)
        phase_rows.append(
            {
                "name": names[name],
                "formula": formulas[name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif": cifs[name],
                "weight_fraction": float(row["weight_fraction"]),
            }
        )
    fraction_sum = sum(row["weight_fraction"] for row in phase_rows)
    if abs(fraction_sum - 1.0) > 1e-12:
        raise RuntimeError(f"phase fractions do not sum to one: {fraction_sum}")

    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "GOF": gof,
            "weighted_chi_square": weighted_chi_square,
            "n_points": int(len(x)),
            "weighting": "1/max(observed_counts, 1)",
        },
        "project": "final.gpx",
        "refinement_histogram": histogram.name,
        "profile": "fit.csv",
        "verification": {
            "status": replay["status"],
            "project_sha256": replay["project_sha256"],
            "parameters_optimized_during_replay": replay["parameters_optimized"],
            "evaluation_grid": replay["evaluation_grid"],
            "profile_review_flags": replay["profile_review_flags"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
