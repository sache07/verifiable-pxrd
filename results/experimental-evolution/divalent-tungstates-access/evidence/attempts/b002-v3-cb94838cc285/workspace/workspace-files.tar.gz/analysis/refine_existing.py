#!/usr/bin/env python3
"""Apply one controlled refinement step to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def parse_atom_spec(text: str) -> tuple[str, list[str], str]:
    phase, labels, flags = text.split(":", 2)
    return phase, [v for v in labels.split(",") if v], flags


def parse_phase_value(text: str) -> tuple[str, float]:
    phase, value = text.split(":", 1)
    return phase, float(value)


def parse_key_value(text: str) -> tuple[str, float]:
    key, value = text.split(":", 1)
    return key, float(value)


def parse_uniaxial(text: str) -> tuple[str, list[int], float, float]:
    phase, axis, equatorial, axial = text.split(":", 3)
    return phase, [int(value) for value in axis.split(",")], float(equatorial), float(axial)


def snapshot(project: G2.G2Project) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "zero_deg": float(inst["Zero"][1]),
        "instrument": {key: float(value[1]) for key, value in inst.items() if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (int, float))},
        "sample": {key: value for key, value in sample.items() if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius"}},
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        atoms = []
        for atom in phase.data["Atoms"]:
            atoms.append(
                {
                    "label": atom[ct - 1],
                    "type": atom[ct],
                    "flags": atom[ct + 1],
                    "xyz": [float(v) for v in atom[cx : cx + 3]],
                    "occupancy": float(atom[cx + 3]),
                    "adp_type": atom[cia],
                    "adp": [float(v) for v in atom[cia + 1 : cia + 8]],
                }
            )
        result["phases"].append(
            {
                "name": phase.name,
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
                "atoms": atoms,
            }
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cycles", type=int, default=16)
    parser.add_argument("--clear-atoms", action="store_true")
    parser.add_argument("--atom", action="append", type=parse_atom_spec, default=[])
    parser.add_argument("--set-all-uiso", action="append", type=parse_phase_value, default=[])
    parser.add_argument("--instrument", default="")
    parser.add_argument("--clear-instrument", action="store_true")
    parser.add_argument("--set-inst", action="append", type=parse_key_value, default=[])
    parser.add_argument("--sample", default="")
    parser.add_argument("--clear-sample", action="store_true")
    parser.add_argument("--set-sample", action="append", type=parse_key_value, default=[])
    parser.add_argument("--size", action="append", type=parse_phase_value, default=[])
    parser.add_argument("--mustrain", action="append", type=parse_phase_value, default=[])
    parser.add_argument("--fixed-size", action="append", type=parse_phase_value, default=[])
    parser.add_argument("--fixed-mustrain", action="append", type=parse_phase_value, default=[])
    parser.add_argument("--uniaxial-mustrain", action="append", type=parse_uniaxial, default=[])
    parser.add_argument("--fixed-uniaxial-mustrain", action="append", type=parse_uniaxial, default=[])
    parser.add_argument("--prefori", action="append", default=[], help="PHASE:h,k,l:ratio")
    parser.add_argument("--fixed-prefori", action="append", default=[], help="PHASE:h,k,l:ratio")
    parser.add_argument("--background-coeffs", type=int)
    parser.add_argument("--background-type")
    parser.add_argument("--clear-profile", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = project.histograms()[0]

    if args.clear_atoms:
        for phase in project.phases():
            for atom in phase.atoms():
                atom.refinement_flags = " "
    for phase_name, labels, flags in args.atom:
        project.phase(phase_name).set_refinements({"Atoms": {label: flags for label in labels}})

    for phase_name, value in args.set_all_uiso:
        phase = project.phase(phase_name)
        _, _, _, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[cia] = "I"
            atom[cia + 1] = value
            atom[cia + 2 : cia + 8] = [0.0] * 6

    if args.clear_instrument:
        inst = hist.data["Instrument Parameters"][0]
        hist.clear_refinements({"Instrument Parameters": [key for key, value in inst.items() if isinstance(value, list) and len(value) > 2]})
    for key, value in args.set_inst:
        hist.data["Instrument Parameters"][0][key][1] = value
    if args.instrument:
        hist.set_refinements({"Instrument Parameters": [v for v in args.instrument.split(",") if v]})
    if args.clear_sample:
        sample = hist.data["Sample Parameters"]
        hist.clear_refinements({"Sample Parameters": [key for key, value in sample.items() if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool)]})
    for key, value in args.set_sample:
        hist.data["Sample Parameters"][key][0] = value
    if args.sample:
        hist.set_refinements({"Sample Parameters": [v for v in args.sample.split(",") if v]})
    if args.background_coeffs is not None or args.background_type:
        settings = {"refine": True}
        if args.background_coeffs is not None:
            settings["no. coeffs"] = args.background_coeffs
        if args.background_type:
            settings["type"] = args.background_type
        hist.set_refinements({"Background": settings})

    if args.clear_profile:
        for phase in project.phases():
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist])
    for phase_name, value in args.size:
        project.phase(phase_name).set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": value, "refine": True}}, [hist]
        )
    for phase_name, value in args.mustrain:
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = value
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, [hist])
    for phase_name, value in args.fixed_size:
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = value
        hap["Size"][2] = [False] * len(hap["Size"][2])
    for phase_name, value in args.fixed_mustrain:
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = value
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    for phase_name, axis, equatorial, axial in args.uniaxial_mustrain:
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0:2] = [equatorial, axial]
        hap["Mustrain"][3] = axis
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}, [hist]
        )
    for phase_name, axis, equatorial, axial in args.fixed_uniaxial_mustrain:
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0:2] = [equatorial, axial]
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][3] = axis
    for item in args.prefori:
        phase_name, axis, ratio = item.split(":", 2)
        hkl = [int(v) for v in axis.split(",")]
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(ratio)
        hap["Pref.Ori."][3] = hkl
        phase.set_HAP_refinements({"Pref.Ori.": True}, [hist])
    for item in args.fixed_prefori:
        phase_name, axis, ratio = item.split(":", 2)
        hkl = [int(v) for v in axis.split(",")]
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = float(ratio)
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = hkl

    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(str(args.output.resolve()))
    report = snapshot(project)
    args.output.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps({k: report[k] for k in ("Rwp_percent", "GOF", "zero_deg")}))

    hist = project.histograms()[0]
    arrays = np.column_stack(
        (hist.getdata("x"), hist.getdata("yobs"), hist.getdata("ycalc"), hist.getdata("background"), hist.getdata("residual"))
    )
    with args.output.with_suffix(".csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
        writer.writerows(arrays)


if __name__ == "__main__":
    main()
