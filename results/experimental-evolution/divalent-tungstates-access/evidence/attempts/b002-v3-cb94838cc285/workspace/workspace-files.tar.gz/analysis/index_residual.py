#!/usr/bin/env python3
"""Index a selected coherent family from the two-phase residual profile."""

from __future__ import annotations

import argparse
import math

from GSASII import GSASIIindex as G2index


WAVELENGTH = 1.540598
GONIOMETER_RADIUS_MM = 200.0

# Peak maxima selected from positive residuals that recur as resolved shoulders
# or isolated lines. Variants permit sensitivity checks when overlap makes a
# member questionable.
PEAK_SETS = {
    "full": [
        19.8462, 20.4221, 22.9540, 23.2039, 25.4207, 28.6914,
        31.7558, 32.4838, 33.0597, 33.4183, 33.9290, 34.2985,
        35.1135, 41.6442, 45.6865, 46.4906, 50.5546, 54.4557,
        55.2598, 56.4551, 59.3456, 66.3978,
    ],
    "clean": [
        19.8462, 20.4221, 25.4207, 28.6914, 31.7558, 32.4838,
        35.1135, 41.6442, 45.6865, 46.4906, 50.5546, 54.4557,
        55.2598, 56.4551, 59.3456, 66.3978,
    ],
    "strong": [
        19.8462, 20.4221, 22.9540, 23.2039, 28.6914, 31.7558,
        32.4838, 33.4183, 35.1135, 41.6442, 45.6865, 46.4906,
        54.4557, 55.2598, 56.4551, 59.3456, 66.3978,
    ],
}


def angular_correction(two_theta: float, zero: float, shift_um: float) -> float:
    theta = math.radians(two_theta / 2.0)
    return zero - 0.09 / (math.pi * GONIOMETER_RADIUS_MM) * 4.0 * shift_um * math.cos(theta)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--set", choices=PEAK_SETS, default="clean")
    parser.add_argument("--bravais", required=True, help="comma-separated GSAS-II Bravais indices")
    parser.add_argument("--volume", type=float, default=50.0)
    parser.add_argument("--ncno", type=int, default=6)
    parser.add_argument("--timeout", type=float, default=30.0)
    parser.add_argument("--zero", type=float, default=0.07206998)
    parser.add_argument("--shift", type=float, default=248.94249)
    args = parser.parse_args()

    peaks = []
    for position in PEAK_SETS[args.set]:
        ideal = position - angular_correction(position, args.zero, args.shift)
        d_obs = WAVELENGTH / (2.0 * math.sin(math.radians(ideal / 2.0)))
        peaks.append([position, 1000.0, True, False, 0, 0, 0, d_obs, 0.0])

    bravais = [False] * 18
    for value in args.bravais.split(","):
        bravais[int(value)] = True
    controls = [0, 0.0, args.ncno, args.volume, 0, "P1", 1.0, 1.0, 1.0, 90.0, 90.0, 90.0, 1.0, "P 1"]
    ok, dmin, cells = G2index.DoIndexPeaks(
        peaks,
        controls,
        bravais,
        None,
        ifX20=True,
        timeout=args.timeout,
        M20_min=1.5,
        return_Nc=True,
    )
    print("OK", ok, "dmin", dmin, "n_cells", len(cells))
    for cell in G2index.sortM20(cells)[:30]:
        print("CELL", cell)


if __name__ == "__main__":
    main()
