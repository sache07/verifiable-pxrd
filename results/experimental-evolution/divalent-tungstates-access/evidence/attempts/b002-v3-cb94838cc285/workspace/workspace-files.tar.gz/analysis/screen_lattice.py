#!/usr/bin/env python3
"""Coarse lattice adaptation of analogue patterns against the unmodeled profile."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Lattice, Structure
from scipy.ndimage import gaussian_filter1d
from scipy.optimize import differential_evolution


LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cell_kind(
    structure: Structure, relative_bound: float, angle_bound: float, sigma_max: float
) -> tuple[str, np.ndarray, list[tuple[float, float]]]:
    number = structure.get_space_group_info(symprec=0.001)[1]
    a, b, c = structure.lattice.abc
    alpha, beta, gamma = structure.lattice.angles
    if 195 <= number <= 230:
        return "cubic", np.array([a]), [
            ((1.0 - relative_bound) * a, (1.0 + relative_bound) * a),
            (0.025, sigma_max),
        ]
    if 75 <= number <= 142:
        return "tetragonal", np.array([a, c]), [
            ((1.0 - relative_bound) * a, (1.0 + relative_bound) * a),
            ((1.0 - relative_bound) * c, (1.0 + relative_bound) * c),
            (0.025, sigma_max),
        ]
    if 143 <= number <= 194:
        return "hexagonal", np.array([a, c]), [
            ((1.0 - relative_bound) * a, (1.0 + relative_bound) * a),
            ((1.0 - relative_bound) * c, (1.0 + relative_bound) * c),
            (0.025, sigma_max),
        ]
    if 16 <= number <= 74:
        return "orthorhombic", np.array([a, b, c]), [
            ((1.0 - relative_bound) * a, (1.0 + relative_bound) * a),
            ((1.0 - relative_bound) * b, (1.0 + relative_bound) * b),
            ((1.0 - relative_bound) * c, (1.0 + relative_bound) * c),
            (0.025, sigma_max),
        ]
    if 3 <= number <= 15:
        return "monoclinic", np.array([a, b, c, beta]), [
            ((1.0 - relative_bound) * a, (1.0 + relative_bound) * a),
            ((1.0 - relative_bound) * b, (1.0 + relative_bound) * b),
            ((1.0 - relative_bound) * c, (1.0 + relative_bound) * c),
            (beta - angle_bound, beta + angle_bound),
            (0.025, sigma_max),
        ]
    raise ValueError(f"unsupported space group {number}")


def lattice(kind: str, values: np.ndarray) -> Lattice:
    if kind == "cubic":
        return Lattice.cubic(values[0])
    if kind == "tetragonal":
        return Lattice.tetragonal(values[0], values[1])
    if kind == "hexagonal":
        return Lattice.hexagonal(values[0], values[1])
    if kind == "orthorhombic":
        return Lattice.orthorhombic(*values[:3])
    if kind == "monoclinic":
        return Lattice.monoclinic(values[0], values[1], values[2], values[3])
    raise ValueError(kind)


def angular_correction(two_theta: np.ndarray, zero: float, shift_um: float) -> np.ndarray:
    theta = np.deg2rad(two_theta / 2.0)
    return zero - 9e-2 / (np.pi * 200.0) * 4.0 * shift_um * np.cos(theta)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--zero", type=float, required=True)
    parser.add_argument("--shift", type=float, required=True)
    parser.add_argument("--relative-bound", type=float, default=0.10)
    parser.add_argument("--angle-bound", type=float, default=5.0)
    parser.add_argument("--sigma-max", type=float, default=0.28)
    parser.add_argument("--maxiter", type=int, default=90)
    parser.add_argument("cifs", nargs="+", type=Path)
    args = parser.parse_args()

    data = np.loadtxt(args.profile, delimiter=",", skiprows=1)
    x, y, current, background, _ = data.T
    weight = 1.0 / np.maximum(y, 1.0)
    rootw = np.sqrt(weight)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    # Refit the current total Bragg signal and a smooth background for every
    # candidate. Residualizing candidate vectors against this fixed subspace
    # makes the nonlinear lattice screen inexpensive and fair.
    base = np.column_stack((current - background, np.polynomial.chebyshev.chebvander(t, 10)))
    q, _ = np.linalg.qr(base * rootw[:, None], mode="reduced")
    yw = y * rootw
    y_perp = yw - q @ (q.T @ yw)
    base_loss = float(y_perp @ y_perp)
    denominator = float(np.sum(weight * y * y))
    dx = float(np.median(np.diff(x)))

    for cif in args.cifs:
        try:
            structure = Structure.from_file(cif, primitive=False)
            kind, initial, bounds = cell_kind(
                structure, args.relative_bound, args.angle_bound, args.sigma_max
            )
        except Exception as error:
            print(cif.stem, "skipped=", type(error).__name__, str(error))
            continue
        pattern = XRDCalculator(wavelength=LAMBDA1).get_pattern(structure, two_theta_range=(9.5, 101.0), scaled=True)
        lines: list[tuple[tuple[int, int, int], float]] = []
        for intensity, group in zip(pattern.y, pattern.hkls):
            if intensity < 0.25:
                continue
            multiplicity = sum(item["multiplicity"] for item in group)
            for item in group:
                hkl = tuple(item["hkl"])
                if len(hkl) != 3:
                    continue
                lines.append((hkl, float(intensity) * item["multiplicity"] / multiplicity))
        if not lines:
            print(cif.stem, "skipped= no three-index reflections")
            continue

        cache: dict[tuple[float, ...], tuple[float, float, np.ndarray]] = {}

        def make_profile(values: np.ndarray) -> np.ndarray:
            lat = lattice(kind, values)
            sigma = float(values[-1])
            impulse = np.zeros_like(x)
            for hkl, intensity in lines:
                d = lat.d_hkl(hkl)
                for wavelength, ratio in ((LAMBDA1, 1.0), (LAMBDA2, 0.5)):
                    arg = wavelength / (2.0 * d)
                    if arg >= 1.0:
                        continue
                    pos = 2.0 * np.degrees(np.arcsin(arg))
                    pos += float(angular_correction(np.array([pos]), args.zero, args.shift)[0])
                    u = (pos - x[0]) / dx
                    i = int(np.floor(u))
                    f = u - i
                    if 0 <= i < len(x):
                        impulse[i] += ratio * intensity * (1.0 - f)
                    if 0 <= i + 1 < len(x):
                        impulse[i + 1] += ratio * intensity * f
            return gaussian_filter1d(impulse, sigma / dx, mode="constant")

        def objective(values: np.ndarray) -> float:
            p = make_profile(values) * rootw
            p -= q @ (q.T @ p)
            denom = float(p @ p)
            amplitude = max(float(p @ y_perp) / denom, 0.0) if denom > 0 else 0.0
            improvement = amplitude * amplitude * denom
            return -improvement

        result = differential_evolution(
            objective,
            bounds,
            seed=7,
            popsize=12,
            maxiter=args.maxiter,
            polish=True,
            workers=1,
            updating="immediate",
            tol=1e-7,
        )
        p0 = make_profile(result.x) * rootw
        p = p0 - q @ (q.T @ p0)
        pnorm = float(p @ p)
        amplitude = max(float(p @ y_perp) / pnorm, 0.0) if pnorm > 0 else 0.0
        loss = base_loss - amplitude * amplitude * float(p @ p)
        print(
            cif.stem,
            "kind=", kind,
            "initial=", np.round(initial, 6).tolist(),
            "best=", np.round(result.x, 6).tolist(),
            "amplitude=", round(amplitude, 6),
            "Rwp=", round(100.0 * np.sqrt(loss / denominator), 5),
            "base_Rwp=", round(100.0 * np.sqrt(base_loss / denominator), 5),
        )


if __name__ == "__main__":
    main()
