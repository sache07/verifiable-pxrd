#!/usr/bin/env python3
"""Fast uniform-scale screen before expensive anisotropic lattice adaptation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.ndimage import gaussian_filter1d


LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def angular_correction(two_theta: float, zero: float, shift_um: float) -> float:
    theta = np.deg2rad(two_theta / 2.0)
    return float(zero - 9e-2 / (np.pi * 200.0) * 4.0 * shift_um * np.cos(theta))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--profile", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--zero", type=float, required=True)
    parser.add_argument("--shift", type=float, required=True)
    args = parser.parse_args()

    data = np.loadtxt(args.profile, delimiter=",", skiprows=1)
    x, observed, current, background, _ = data.T
    weights = 1.0 / np.maximum(observed, 1.0)
    rootw = np.sqrt(weights)
    t = 2.0 * (x - x[0]) / (x[-1] - x[0]) - 1.0
    base = np.column_stack((current - background, np.polynomial.chebyshev.chebvander(t, 10)))
    q, _ = np.linalg.qr(base * rootw[:, None], mode="reduced")
    yw = observed * rootw
    y_perp = yw - q @ (q.T @ yw)
    base_loss = float(y_perp @ y_perp)
    denominator = float(np.sum(weights * observed * observed))
    dx = float(np.median(np.diff(x)))

    scales = np.linspace(0.86, 1.14, 57)
    sigmas = np.array([0.08, 0.14, 0.21, 0.30, 0.42])
    manifest = json.loads(args.manifest.read_text())
    results = []
    for index, row in enumerate(item for item in manifest if "cif" in item):
        structure = Structure.from_file(row["cif"], primitive=False)
        pattern = XRDCalculator(wavelength=LAMBDA1).get_pattern(
            structure, two_theta_range=(8.0, 105.0), scaled=True
        )
        lines = []
        for position, intensity in zip(pattern.x, pattern.y):
            if intensity < 0.15:
                continue
            d = LAMBDA1 / (2.0 * np.sin(np.deg2rad(position / 2.0)))
            lines.append((float(d), float(intensity)))

        best = None
        for scale in scales:
            impulse = np.zeros_like(x)
            for d0, intensity in lines:
                d = d0 * scale
                for wavelength, ratio in ((LAMBDA1, 1.0), (LAMBDA2, 0.5)):
                    argument = wavelength / (2.0 * d)
                    if argument >= 1.0:
                        continue
                    position = 2.0 * np.degrees(np.arcsin(argument))
                    position += angular_correction(position, args.zero, args.shift)
                    u = (position - x[0]) / dx
                    left = int(np.floor(u))
                    fraction = u - left
                    if 0 <= left < len(x):
                        impulse[left] += ratio * intensity * (1.0 - fraction)
                    if 0 <= left + 1 < len(x):
                        impulse[left + 1] += ratio * intensity * fraction
            for sigma in sigmas:
                vector = gaussian_filter1d(impulse, sigma / dx, mode="constant") * rootw
                vector -= q @ (q.T @ vector)
                norm = float(vector @ vector)
                amplitude = max(float(vector @ y_perp) / norm, 0.0) if norm > 0 else 0.0
                loss = base_loss - amplitude * amplitude * norm
                candidate = (loss, float(scale), float(sigma), float(amplitude))
                if best is None or candidate[0] < best[0]:
                    best = candidate
        loss, scale, sigma, amplitude = best
        result = {
            **row,
            "uniform_scale": scale,
            "sigma_deg": sigma,
            "amplitude": amplitude,
            "Rwp_percent": 100.0 * np.sqrt(loss / denominator),
            "base_Rwp_percent": 100.0 * np.sqrt(base_loss / denominator),
        }
        results.append(result)
        if (index + 1) % 20 == 0:
            print(f"screened {index + 1}", flush=True)

    results.sort(key=lambda item: item["Rwp_percent"])
    args.output.write_text(json.dumps(results, indent=2) + "\n")
    for rank, row in enumerate(results[:30], 1):
        print(
            f"{rank:2d} {row['cod_id']} {row['parent_formula']:12s} "
            f"{row['trial_space_group']:10s} Rwp={row['Rwp_percent']:.4f} "
            f"scale={row['uniform_scale']:.3f} sigma={row['sigma_deg']:.2f}"
        )


if __name__ == "__main__":
    main()
