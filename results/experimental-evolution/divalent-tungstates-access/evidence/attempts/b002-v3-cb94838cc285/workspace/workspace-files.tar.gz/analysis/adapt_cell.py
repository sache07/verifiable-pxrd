#!/usr/bin/env python3
"""Write a symmetry-clean CIF after replacing a prototype lattice."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from pymatgen.core import Lattice, Structure


RUNTIME = Path(__file__).resolve().parents[1] / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("destination", type=Path)
    parser.add_argument("cell", nargs=6, type=float, metavar=("A", "B", "C", "ALPHA", "BETA", "GAMMA"))
    args = parser.parse_args()

    source = Structure.from_file(args.source, primitive=False)
    lattice = Lattice.from_parameters(*args.cell)
    adapted = Structure(
        lattice,
        source.species_and_occu,
        source.frac_coords,
        coords_are_cartesian=False,
        site_properties=source.site_properties,
    )
    args.destination.parent.mkdir(parents=True, exist_ok=True)
    write_synthetic_model(adapted, args.destination, symprec=0.001)
    print(adapted.composition.reduced_formula, adapted.get_space_group_info(symprec=0.001), adapted.lattice)


if __name__ == "__main__":
    main()
