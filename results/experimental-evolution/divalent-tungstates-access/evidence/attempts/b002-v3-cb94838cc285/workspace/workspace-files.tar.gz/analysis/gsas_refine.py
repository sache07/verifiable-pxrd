#!/usr/bin/env python3
"""Build and stage a compact GSAS-II powder refinement.

This script is intentionally explicit: it creates a project from the public
grid, links one or more CIF phases, and performs only the refinement stages
requested on the command line.  It is used for candidate screening as well as
for the final replayable project.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def read_pattern(path: Path) -> tuple[np.ndarray, np.ndarray]:
    values = np.loadtxt(path, delimiter=",", skiprows=1)
    return values[:, 0], values[:, 1]


def write_xye(path: Path, x: np.ndarray, y: np.ndarray) -> None:
    # Poisson weights are appropriate for the supplied raw count data.
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(path, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")


def write_inst(path: Path, args: argparse.Namespace) -> None:
    path.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        f"Lam1:{args.lam1};Lam2:{args.lam2};I(L2)/I(L1):{args.ka2_ratio}\n"
        f"Zero:{args.zero};Polariz.:{args.polarization};Azimuth:0.0\n"
        f"U:{args.U};V:{args.V};W:{args.W};X:{args.X};Y:0.0;Z:0.0;SH/L:{args.shl}\n"
    )


def phase_arg(text: str) -> tuple[str, Path]:
    try:
        name, path = text.split("=", 1)
    except ValueError as exc:
        raise argparse.ArgumentTypeError("phase must be NAME=PATH") from exc
    return name, Path(path).resolve()


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    row = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}).get("GOF"),
        "zero_deg": float(inst["Zero"][1]),
        "U": float(inst["U"][1]),
        "V": float(inst["V"][1]),
        "W": float(inst["W"][1]),
        "X": float(inst["X"][1]),
        "SH_L": float(inst["SH/L"][1]),
        "polarization": float(inst["Polariz."][1]),
        "shift_um": float(sample["Shift"][0]),
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"].append(
            {
                "name": phase.name,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "mass": float(phase.data["General"]["Mass"]),
                "scale": float(hap["Scale"][0]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "pref_ori": hap["Pref.Ori."],
            }
        )
    return row


def run_refinement(project: G2.G2Project, history: list[dict], label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    history.append(snapshot(project, label))
    print(json.dumps(history[-1], default=str))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--phase", type=phase_arg, action="append", required=True)
    parser.add_argument("--stages", default="scale,cell,shift,profile")
    parser.add_argument("--background-coeffs", type=int, default=10)
    parser.add_argument("--low", type=float, default=10.0)
    parser.add_argument("--high", type=float, default=100.0)
    parser.add_argument("--lam1", type=float, default=1.540598)
    parser.add_argument("--lam2", type=float, default=1.544426)
    parser.add_argument("--ka2-ratio", type=float, default=0.5)
    parser.add_argument("--zero", type=float, default=0.0)
    parser.add_argument("--polarization", type=float, default=0.7)
    parser.add_argument("--U", type=float, default=10.0)
    parser.add_argument("--V", type=float, default=0.0)
    parser.add_argument("--W", type=float, default=10.0)
    parser.add_argument("--X", type=float, default=1.0)
    parser.add_argument("--shl", type=float, default=0.02)
    args = parser.parse_args()

    args.project = args.project.resolve()
    args.project.parent.mkdir(parents=True, exist_ok=True)
    x, y = read_pattern(args.pattern)
    xye = args.project.with_suffix(".xye")
    inst = args.project.with_suffix(".instprm")
    write_xye(xye, x, y)
    write_inst(inst, args)

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.project))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    # Replace parsed coordinates/counts with the public values to preserve the
    # exact submission grid and observations used by independent replay.
    hist.data["data"][1][0] = np.ma.array(x.copy())
    hist.data["data"][1][1] = np.ma.array(y.copy())
    hist.data["data"][1][2] = np.ma.array(1.0 / np.maximum(y, 1.0))
    hist.data["data"][1][3:] = [np.zeros_like(x) for _ in range(3)]
    hist.data["Limits"] = [[float(x[0]), float(x[-1])], [args.low, args.high]]
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]

    phases = []
    for name, path in args.phase:
        phase = project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        phase.data["Histograms"][hist.name]["Scale"][0] = 10000.0 / (
            len(args.phase) * max(float(phase.data["General"]["Mass"]), 1.0)
        )
        phases.append(phase)

    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_coeffs,
                "coeffs": [float(np.percentile(y, 10))] + [0.0] * (args.background_coeffs - 1),
                "refine": True,
            }
        }
    )
    history: list[dict] = [snapshot(project, "created")]
    requested = {s.strip() for s in args.stages.split(",") if s.strip()}

    if "scale" in requested:
        for phase in phases:
            phase.set_HAP_refinements({"Scale": True}, [hist])
        run_refinement(project, history, "scale_background", 12)

    if "cell" in requested:
        for phase in phases:
            phase.set_refinements({"Cell": True})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        run_refinement(project, history, "cell_zero", 12)

    if "shift" in requested:
        # Zero and specimen displacement have distinct angular dependence. Keep
        # both active only after the phase cells have approached the data.
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        run_refinement(project, history, "cell_zero_shift", 12)

    if "profile" in requested:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
        for phase in phases:
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "value": 1.0, "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                [hist],
            )
        run_refinement(project, history, "profile", 16)

    project.save(str(args.project))
    args.project.with_suffix(".history.json").write_text(json.dumps(history, indent=2, default=str) + "\n")
    hist = project.histograms()[0]
    arrays = np.column_stack(
        (
            hist.getdata("x"),
            hist.getdata("yobs"),
            hist.getdata("ycalc"),
            hist.getdata("background"),
            hist.getdata("residual"),
        )
    )
    with args.project.with_suffix(".profile.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["two_theta_deg", "observed", "calculated", "background", "difference"])
        writer.writerows(arrays)


if __name__ == "__main__":
    main()
