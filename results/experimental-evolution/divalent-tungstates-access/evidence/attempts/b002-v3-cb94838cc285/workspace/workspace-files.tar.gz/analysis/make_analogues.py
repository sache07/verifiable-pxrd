#!/usr/bin/env python3
"""Create Mn-W-O analogue starts from selected cross-chemistry prototypes."""

from pathlib import Path
import sys

from pymatgen.core import Structure
from pymatgen.io.cif import CifParser


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif")
RUNTIME = Path(__file__).resolve().parents[1] / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


PROTOTYPES = {
    "mn2wo6_pbcn_super": ("2310464", {"Fe": "Mn"}),
    "mn8w4o24_pbcn_sub": ("1565524", {"Fe": "Mn"}),
    "mn2wo6_trirutile": ("1530909", {"Cr": "Mn"}),
    "mn2wo6_ta2mno6_trirutile": ("1531374", {"Ta": "Mn", "Mn": "W"}),
    "mn3wo6_p21c": ("1563081", {"Ca": "Mn"}),
    "mn3wo6_pa3": ("1527404", {"Cu": "Mn"}),
    "mn3wo6_p1": ("1534803", {"Ba": "Mn"}),
    "mn3wo6_pnma": ("1563543", {"Sc": "Mn"}),
    "mn3w2o9_c2c": ("2311977", {"Sr": "Mn"}),
    "mn3w2o9_r3c": ("1533878", {"Ba": "Mn"}),
    "mn3w2o9_zn3mo2o9": ("1534971", {"Zn": "Mn", "Mo": "W"}),
    "mn3w2o9_cu3mo2o9_pnma": ("2006589", {"Cu": "Mn", "Mo": "W"}),
    "mn3w2o9_cu3mo2o9_pna21": ("2106214", {"Cu": "Mn", "Mo": "W"}),
    "mn2wo5_mn2bio5": ("9008146", {"Bi": "W"}),
    "mn2wo5_mn2aso5_p21c": ("9009577", {"As": "W"}),
    "mn2wo5_mn2aso5_pnnm": ("9000178", {"As": "W"}),
    "mn2wo5_sr2mno5_pnnm": ("1512486", {"Sr": "Mn", "Mn": "W"}),
    "mn2wo5_cu2po5_pnnm_a": ("9016468", {"Cu": "Mn", "P": "W"}),
    "mn2wo5_cu2po5_pnnm_b": ("1528172", {"Cu": "Mn", "P": "W"}),
    "mn2wo5_co2aso5_pnnm": ("1524664", {"Co": "Mn", "As": "W"}),
    "mn2wo5_al2sio5_pnnm": ("2101671", {"Al": "Mn", "Si": "W"}),
    "mn2wo5_cu2aso5_pnnm": ("9015082", {"Cu": "Mn", "As": "W"}),
    "mn2wo5_zn2aso5_pnnm": ("9015147", {"Zn": "Mn", "As": "W"}),
    "mn2wo5_fe2po5_p21c": ("1008736", {"Fe": "Mn", "P": "W"}),
    "mn2wo5_fe2po5_i4mcm": ("1545074", {"Fe": "Mn", "P": "W"}),
    "mn2wo5_fe2po5_cc": ("7001234", {"Fe": "Mn", "P": "W"}),
    "mn3w2o8_mn3v2o8": ("1519052", {"V": "W"}),
    "mn3w2o8_mn3aso4_2a": ("1560681", {"As": "W"}),
    "mn3w2o8_mn3aso4_2b": ("1560682", {"As": "W"}),
    "mn3w2o8_mn3cr2o8": ("7222202", {"Cr": "W"}),
    "mn6wo12_r3": ("4001207", {"Sc": "Mn"}),
}


def cod_path(record: str) -> Path:
    return ROOT / record[0] / record[1:3] / record[3:5] / f"{record}.cif"


def main() -> None:
    out = Path("analysis/analogues")
    out.mkdir(parents=True, exist_ok=True)
    for name, (record, substitutions) in PROTOTYPES.items():
        source = cod_path(record)
        try:
            structure = Structure.from_file(source, primitive=False)
        except ValueError:
            structure = CifParser(source, occupancy_tolerance=2.1).parse_structures(primitive=False)[0]
        parent_formula = structure.composition.reduced_formula
        structure.remove_oxidation_states()
        structure.replace_species(substitutions)
        path = out / f"{name}.cif"
        write_synthetic_model(structure, path, symprec=0.001)
        print(
            name,
            record,
            parent_formula,
            "->",
            structure.composition.reduced_formula,
            structure.get_space_group_info(symprec=0.001),
            tuple(round(v, 6) for v in (*structure.lattice.abc, *structure.lattice.angles)),
        )


if __name__ == "__main__":
    main()
