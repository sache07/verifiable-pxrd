#!/usr/bin/env python3
"""Test W and then U from the stable profile checkpoint, keeping X fixed."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SRC = Path("trials/instrument_refinement/02_Polariz..gpx")
OUT = Path("trials/instrument_no_x")
OUT.mkdir(parents=True, exist_ok=True)
p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(OUT / "working.gpx"))
h = p.histogram(0)


def bound(name, lo, hi):
    p.set_Controls("parmMin", lo, variable=name)
    p.set_Controls("parmMax", hi, variable=name)


# X was weakly determined and caused an SVD warning in the exploratory branch.
h.data["Instrument Parameters"][0]["X"][2] = False
bound(":0:W", 2.0, 40.0)
bound(":0:U", 0.0, 40.0)

for idx, key in enumerate(("W", "U"), 1):
    h.set_refinements({"Instrument Parameters": [key]})
    for _ in range(2):
        p.set_Controls("cycles", 12)
        p.refine()
    p.save()
    shutil.copy2(p.filename, OUT / f"{idx:02d}_{key}.gpx")
    print(
        "RESULT",
        json.dumps(
            {
                "step": key,
                "wR": h.get_wR(),
                "instrument": {
                    k: h.data["Instrument Parameters"][0][k][1]
                    for k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")
                },
                "fractions": h.ComputeMassFracs(),
                "frozen": [
                    str(v)
                    for v in p.data["Controls"]["data"]
                    .get("parmFrozen", {})
                    .get("FrozenList", [])
                ],
                "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
            },
            default=float,
        ),
    )

shutil.copy2(p.filename, OUT / "candidate.gpx")
