#!/usr/bin/env python3
"""Fresh physically constrained CaWO4 + monoclinic WO3 refinement."""

import json
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
OUT = Path("trials/fresh_physical")
OUT.mkdir(parents=True, exist_ok=True)


def cod(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_cell(phase, cell):
    phase.data["General"]["Cell"][1:7] = list(cell)
    phase.data["General"]["Cell"][7] = G2lat.calc_V(G2lat.cell2A(cell))


def set_background(hist, n=16):
    x, y = (np.asarray(v) for v in hist.data["data"][1][:2])
    b = gaussian_filter1d(
        percentile_filter(y, percentile=8, size=401, mode="nearest"), 120
    )
    t = -1 + 2 * (x - x[0]) / (x[-1] - x[0])
    c = np.polynomial.chebyshev.chebfit(t, b, n - 1)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": n,
                "coeffs": c.tolist(),
                "refine": True,
            }
        }
    )


def bound(project, name, lo, hi):
    project.set_Controls("parmMin", lo, variable=name)
    project.set_Controls("parmMax", hi, variable=name)


def snapshot(project, label):
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    h = project.histogram(0)
    info = {
        "step": label,
        "wR": h.get_wR(),
        "zero": h.data["Instrument Parameters"][0]["Zero"][1],
        "shift": h.data["Sample Parameters"]["Shift"][0],
        "instrument": {
            k: h.data["Instrument Parameters"][0][k][1]
            for k in ("U", "W", "X", "SH/L", "Polariz.")
        },
        "phases": [],
        "rvals": project.data["Covariance"]["data"].get("Rvals", {}),
    }
    for p in project.phases():
        hap = p.data["Histograms"][h.name]
        info["phases"].append(
            {
                "name": p.name,
                "cell": p.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][0],
                "strain": hap["Mustrain"][1][0],
            }
        )
    print("RESULT", json.dumps(info, default=float))
    return info


project = G2sc.G2Project(newgpx=str(OUT / "working.gpx"))
hist = project.add_powder_histogram(
    "inputs/pattern.csv", "cu_ka.instprm", fmthint="comma"
)
hist.set_refinements({"Limits": [10.0, 100.0]})
hist.data["Sample Parameters"]["Scale"] = [1.0, False]
hist.data["Sample Parameters"]["Shift"] = [169.2253, False]
hist.data["Instrument Parameters"][0]["Zero"][1] = -0.25
set_background(hist)

ca = project.add_phase(
    str(cod("7219229")), phasename="CaWO4", histograms=[hist], fmthint="CIF"
)
wo = project.add_phase(
    str(cod("1528915")), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF"
)

# Cells come from a robust fit to 27 CaWO4 and 8 isolated WO3 line centers.
set_cell(ca, [5.23654847, 5.23654847, 11.33331000, 90.0, 90.0, 90.0])
set_cell(wo, [7.31381043, 7.55579633, 7.69514282, 90.0, 91.05770529, 90.0])

for p, scale, size, strain in (
    (ca, 15.0, 0.10, 1500.0),
    (wo, 1.5, 0.80, 500.0),
):
    hap = p.data["Histograms"][hist.name]
    hap["Scale"] = [scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = size
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = strain
    for atom in p.atoms():
        if atom.uiso <= 0:
            atom.uiso = 0.01

for p in project.phases():
    bound(project, f"{p.id}:0:Scale", 0.0, 100.0)
    bound(project, f"{p.id}:0:Size;i", 0.04, 1.5)
    bound(project, f"{p.id}:0:Mustrain;i", 1.0, 8000.0)

project.save()
snapshot(project, "01_scales_background")

# Release only one supported profile contribution at a time.
ca.set_HAP_refinements(
    {"Size": {"type": "isotropic", "refine": True}}, [hist]
)
snapshot(project, "02_ca_size")
ca.set_HAP_refinements(
    {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
)
snapshot(project, "03_ca_strain")
wo.set_HAP_refinements(
    {"Size": {"type": "isotropic", "refine": True}}, [hist]
)
snapshot(project, "04_wo_size")
wo.set_HAP_refinements(
    {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
)
snapshot(project, "05_wo_strain")

shutil.copy2(project.filename, OUT / "candidate.gpx")
