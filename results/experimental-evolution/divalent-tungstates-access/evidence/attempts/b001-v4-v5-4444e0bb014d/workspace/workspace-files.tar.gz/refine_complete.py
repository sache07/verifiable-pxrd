#!/usr/bin/env python3
"""Create the clean accepted three-phase project and jointly refine it."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SRC = Path("trials/wo3_compare_2311041/candidate.gpx")
OUT = Path("trials/complete_inventory")
OUT.mkdir(parents=True, exist_ok=True)
p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(OUT / "working.gpx"))
h = p.histogram(0)

# Remove the disabled checkpoint phase and rename the accepted WO3 model.
del p.data["Phases"]["WO3_monoclinic"]
p.data["Phases"]["WO3"] = p.data["Phases"].pop("WO3_candidate_2311041")
p.data["Phases"]["WO3"]["General"]["Name"] = "WO3"
for row in p.names:
    if row and row[0] == "Phases":
        row.remove("WO3_monoclinic")
        row[row.index("WO3_candidate_2311041")] = "WO3"
        break
del h.data["Reflection Lists"]["WO3_monoclinic"]
h.data["Reflection Lists"]["WO3"] = h.data["Reflection Lists"].pop(
    "WO3_candidate_2311041"
)
p.update_ids()

h.set_refinements({"Sample Parameters": ["Shift"]})
for ph in p.phases():
    ph.set_refinements({"Cell": True})
    ph.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [h],
    )

for label in ("01_joint", "02_joint_continue"):
    p.set_Controls("cycles", 15)
    p.refine()
    p.save()
    shutil.copy2(p.filename, OUT / f"{label}.gpx")
    print(
        "RESULT",
        json.dumps(
            {
                "step": label,
                "wR": h.get_wR(),
                "fractions": h.ComputeMassFracs(),
                "shift": h.data["Sample Parameters"]["Shift"][0],
                "phases": [
                    {
                        "name": ph.name,
                        "cell": ph.get_cell(),
                        "scale": ph.data["Histograms"][h.name]["Scale"],
                        "size": ph.data["Histograms"][h.name]["Size"][1][0],
                        "strain": ph.data["Histograms"][h.name]["Mustrain"][1][0],
                    }
                    for ph in p.phases()
                ],
                "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
            },
            default=float,
        ),
    )

shutil.copy2(p.filename, OUT / "candidate.gpx")
