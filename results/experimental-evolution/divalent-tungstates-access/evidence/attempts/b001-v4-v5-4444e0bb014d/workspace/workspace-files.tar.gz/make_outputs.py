#!/usr/bin/env python3
"""Create the requested deliverables from the accepted full-grid project."""

import csv
import json
import re
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("trials/final_joint/11_replay_converged.gpx")
FINAL = Path("final.gpx")

p = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
h = p.histogram(0)

# Remove only stale per-phase summary entries left by an earlier comparison
# phase. The project tree and reflection lists already contain exactly the
# three accepted phases; this keeps the histogram summary equally clean.
valid_phase_ids = {str(phase.id) for phase in p.phases()}
summary = h.data["data"][0]
for key in list(summary):
    match = re.match(r"^(\d+):", str(key))
    if match and match.group(1) not in valid_phase_ids:
        del summary[key]
p.save()

phase_info = {
    "CaWO4": {
        "display_name": "calcium tungstate (scheelite)",
        "formula": "CaWO4",
        "cif": "CaWO4.cif",
    },
    "CaCO3_calcite": {
        "display_name": "calcium carbonate (calcite)",
        "formula": "CaCO3",
        "cif": "CaCO3_calcite.cif",
    },
    "WO3": {
        "display_name": "tungsten trioxide (monoclinic)",
        "formula": "WO3",
        "cif": "WO3.cif",
    },
}

fractions = h.ComputeMassFracs()
normalizer = sum(value[0] for value in fractions.values())
phases_json = []
for phase in p.phases():
    info = phase_info[phase.name]
    phase.export_CIF(info["cif"])
    fraction, esd = fractions[phase.name]
    cell = phase.get_cell()
    phases_json.append(
        {
            "name": info["display_name"],
            "project_phase_name": phase.name,
            "formula": info["formula"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
            "cif_path": info["cif"],
            "weight_fraction": fraction / normalizer,
            "weight_fraction_esd": esd / normalizer,
            "cell": {
                "a_angstrom": cell["length_a"],
                "b_angstrom": cell["length_b"],
                "c_angstrom": cell["length_c"],
                "alpha_deg": cell["angle_alpha"],
                "beta_deg": cell["angle_beta"],
                "gamma_deg": cell["angle_gamma"],
                "volume_angstrom3": cell["volume"],
            },
        }
    )

_, profile, _ = h.data["data"]
x, observed, weights, calculated, background, difference = (
    np.asarray(row, dtype=float) for row in profile
)
with Path("fit.csv").open("w", newline="", encoding="utf-8") as fp:
    writer = csv.writer(fp)
    writer.writerow(
        [
            "two_theta_deg",
            "observed",
            "calculated",
            "difference_observed_minus_calculated",
            "background",
        ]
    )
    for row in zip(x, observed, calculated, difference, background):
        writer.writerow(
            [f"{row[0]:.8f}"] + [f"{value:.8f}" for value in row[1:]]
        )

rvals = p.data["Covariance"]["data"]["Rvals"]
hist_stats = h.data["data"][0]
result = {
    "project_path": str(FINAL),
    "profile_path": "fit.csv",
    "weight_fraction_basis": "normalized over modeled crystalline phases",
    "phases": phases_json,
    "fit_statistics": {
        "Rwp_percent": float(rvals["Rwp"]),
        "Rp_percent": float(hist_stats["R"]),
        "Rexp_percent": float(hist_stats["wRmin"]),
        "GOF": float(rvals["GOF"]),
        "reduced_chi_squared": float(rvals["GOF"] ** 2),
        "chi_squared": float(rvals["chisq"]),
        "Nobs": int(rvals["Nobs"]),
        "Nvars": int(rvals["Nvars"]),
        "durbin_watson": float(hist_stats["Durbin-Watson"]),
    },
    "profile_grid": {
        "points": int(len(x)),
        "two_theta_min_deg": float(x[0]),
        "two_theta_max_deg": float(x[-1]),
        "all_points_modeled": bool(np.count_nonzero(calculated) == len(x)),
        "difference_definition": "observed - calculated",
    },
}
Path("result.json").write_text(
    json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
)

print(json.dumps(result, indent=2))
