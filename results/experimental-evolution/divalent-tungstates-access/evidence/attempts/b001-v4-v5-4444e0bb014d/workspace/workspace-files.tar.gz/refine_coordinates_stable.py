#!/usr/bin/env python3
"""Refine heavy then dominant-phase light coordinates with profiles fixed."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SRC = Path("trials/instrument_refinement/02_Polariz..gpx")
OUT = Path("trials/coordinate_staged")
OUT.mkdir(parents=True, exist_ok=True)
p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(OUT / "working.gpx"))
h = p.histogram(0)


def bound(name, lo, hi):
    p.set_Controls("parmMin", lo, variable=name)
    p.set_Controls("parmMax", hi, variable=name)


def freeze_nonstructural_shape():
    """Keep the previously accepted peak positions and shapes fixed."""
    h.clear_refinements({"Sample Parameters": ["Shift"]})
    h.clear_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})
    for phase in p.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True}, [h])
        for atom in phase.atoms():
            atom.refinement_flags = " "
    p.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []


def set_coordinate_stage(phase_name, elements, half_width=0.02):
    for phase in p.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = p.phase(phase_name)
    start = {}
    for i, atom in enumerate(phase.atoms()):
        if atom.element not in elements:
            continue
        start[atom.label] = list(atom.coordinates)
        atom.refinement_flags = "X"
        for axis, value in zip("xyz", atom.coordinates):
            bound(f"{phase.id}::A{axis}:{i}", value - half_width, value + half_width)
    return phase, start


def refine_stage(index, label, phase_name, elements):
    phase, start = set_coordinate_stage(phase_name, elements)
    p.set_Controls("cycles", 15)
    p.refine()
    p.save()
    checkpoint = OUT / f"{index:02d}_{label}.gpx"
    shutil.copy2(p.filename, checkpoint)
    result = {
        "step": label,
        "checkpoint": str(checkpoint),
        "wR": h.get_wR(),
        "fractions": h.ComputeMassFracs(),
        "start": start,
        "finish": {
            atom.label: list(atom.coordinates)
            for atom in phase.atoms()
            if atom.element in elements
        },
        "short_distances": {ph.name: ph.ShortDistances() for ph in p.phases()},
        "frozen": [
            str(v)
            for v in p.data["Controls"]["data"]
            .get("parmFrozen", {})
            .get("FrozenList", [])
        ],
        "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
    }
    print("RESULT", json.dumps(result, default=float))


freeze_nonstructural_shape()
refine_stage(1, "WO3_W", "WO3", {"W"})
refine_stage(2, "CaWO4_O", "CaWO4", {"O"})
