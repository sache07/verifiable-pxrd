#!/usr/bin/env python3
"""Build a two-phase GSAS-II checkpoint for candidate WO3 structures."""

import argparse
import json
import os
import shutil
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter

from GSASII import GSASIIscriptable as G2sc


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def set_chebyshev_background(hist, ncoeff=16):
    x, y = (np.asarray(a) for a in hist.data["data"][1][:2])
    baseline = percentile_filter(y, percentile=8, size=401, mode="nearest")
    baseline = gaussian_filter1d(baseline, 120)
    t = -1.0 + 2.0 * (x - x[0]) / (x[-1] - x[0])
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, ncoeff - 1)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": ncoeff,
                "coeffs": coeffs.tolist(),
                "refine": True,
            }
        }
    )


def summary(project):
    hist = project.histogram(0)
    out = {
        "wR_percent": hist.get_wR(),
        "shift_um": hist.data["Sample Parameters"]["Shift"][0],
        "zero_deg": hist.data["Instrument Parameters"][0]["Zero"][1],
        "instrument": {
            k: hist.data["Instrument Parameters"][0][k][1]
            for k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"].append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
            }
        )
    cov = project.data.get("Covariance", {}).get("data", {})
    out["covariance_Rvals"] = cov.get("Rvals", {})
    return out


def run_refinement(project, outdir, label):
    project.set_Controls("cycles", 8)
    project.refine()
    project.save()
    shutil.copy2(project.filename, outdir / f"{label}.gpx")
    info = summary(project)
    print("STEP", label, json.dumps(info, default=float))
    return info


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", required=True)
    parser.add_argument("--cawo4", default="7219229")
    parser.add_argument("--name", required=True)
    parser.add_argument("--profile", action="store_true")
    args = parser.parse_args()

    outdir = Path("trials") / args.name
    outdir.mkdir(parents=True, exist_ok=True)
    work = outdir / "working.gpx"
    project = G2sc.G2Project(newgpx=str(work))
    hist = project.add_powder_histogram(
        "inputs/pattern.csv", "cu_ka.instprm", fmthint="comma"
    )
    hist.set_refinements({"Limits": [10.0, 100.0]})
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    # A peak-position least-squares estimate from the strong CaWO4 family
    # provides a physical start while leaving calibration free below.
    hist.data["Sample Parameters"]["Shift"] = [180.0, False]
    hist.data["Instrument Parameters"][0]["Zero"][1] = -0.24
    set_chebyshev_background(hist)

    ca = project.add_phase(
        str(cod_path(args.cawo4)),
        phasename=f"CaWO4_{args.cawo4}",
        histograms=[hist],
        fmthint="CIF",
    )
    wo = project.add_phase(
        str(cod_path(args.wo3)),
        phasename=f"WO3_{args.wo3}",
        histograms=[hist],
        fmthint="CIF",
    )
    for phase, scale, size, strain in (
        (ca, 7.0, 0.4, 2500.0),
        (wo, 2.0, 0.8, 1200.0),
    ):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
        for atom in phase.atoms():
            atom.uiso = 0.01

    # Apply the generator's physical ranges before any variables are released.
    bound(project, ":0:Shift", -800.0, 800.0)
    bound(project, ":0:Zero", -0.25, 0.25)
    for key, lo, hi in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.1),
    ):
        bound(project, f":0:{key}", lo, hi)
    for phase in project.phases():
        bound(project, f"{phase.id}:0:Scale", 0.0, 100.0)
        bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
        bound(project, f"{phase.id}:0:Mustrain;i", 1.0, 8000.0)

    # Scale and background are fit first at the physically estimated alignment.
    project.save()
    run_refinement(project, outdir, "01_scale_background_shift")

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    hist.set_refinements(
        {
            "Sample Parameters": ["Shift"],
            "Instrument Parameters": ["Zero"],
        }
    )
    run_refinement(project, outdir, "02_cells")

    if args.profile:
        hist.set_refinements(
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
        )
        run_refinement(project, outdir, "03_instrument_profile")
        for phase in project.phases():
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                [hist],
            )
        run_refinement(project, outdir, "04_phase_profile")

    final = outdir / "candidate.gpx"
    shutil.copy2(project.filename, final)
    with open(outdir / "summary.json", "w") as handle:
        json.dump(summary(project), handle, indent=2, default=float)


if __name__ == "__main__":
    main()
