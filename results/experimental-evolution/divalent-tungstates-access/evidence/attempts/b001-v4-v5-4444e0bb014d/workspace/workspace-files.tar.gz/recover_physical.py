#!/usr/bin/env python3
"""Recover a physical profile model from the bounded cell checkpoint."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path("trials/wo3_1528915_bounded/02_cells.gpx")
OUT = Path("trials/physical_recovery")
OUT.mkdir(parents=True, exist_ok=True)
WORK = OUT / "working.gpx"


def save_step(project, label):
    project.set_Controls("cycles", 10)
    project.refine()
    project.save()
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    hist = project.histogram(0)
    report = {
        "label": label,
        "wR": hist.get_wR(),
        "shift": hist.data["Sample Parameters"]["Shift"][0],
        "zero": hist.data["Instrument Parameters"][0]["Zero"][1],
        "inst": {
            k: hist.data["Instrument Parameters"][0][k][1]
            for k in ("U", "W", "X", "SH/L")
        },
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "scale": p.data["Histograms"][hist.name]["Scale"][0],
                "size": p.data["Histograms"][hist.name]["Size"][1][0],
                "strain": p.data["Histograms"][hist.name]["Mustrain"][1][0],
            }
            for p in project.phases()
        ],
        "Rvals": project.data["Covariance"]["data"].get("Rvals", {}),
    }
    print(json.dumps(report, default=float))


project = G2sc.G2Project(gpxfile=str(SOURCE), newgpx=str(WORK))
hist = project.histogram(0)

# The offset reached the known laboratory lower limit. Hold it there and let
# the cells and physically bounded specimen displacement settle once more.
hist.clear_refinements({"Instrument Parameters": ["Zero"]})
hist.data["Instrument Parameters"][0]["Zero"][1] = -0.25
save_step(project, "01_recalibrated")

# Peak positions are now fixed before profile-shape refinement so profile/cell
# covariance cannot drive a monoclinic angle into an implausible setting.
hist.clear_refinements({"Sample Parameters": ["Shift"]})
for phase in project.phases():
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
save_step(project, "02_phase_profile")

# Release supported common instrumental width terms one at a time, repeating
# after GSAS-II freezes a term at a physical limit if needed.
for idx, key in enumerate(("X", "W", "U"), start=3):
    hist.set_refinements({"Instrument Parameters": [key]})
    save_step(project, f"{idx:02d}_instrument_{key}")

shutil.copy2(project.filename, OUT / "candidate.gpx")
