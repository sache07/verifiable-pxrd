import numpy as np
from scipy.ndimage import percentile_filter, gaussian_filter1d
from scipy.signal import find_peaks, peak_widths

data = np.genfromtxt("inputs/pattern.csv", delimiter=",", names=True)
x = data["two_theta_deg"]
y = data["intensity"]

# A broad lower-envelope estimate is sufficient for peak-family inspection.
base = percentile_filter(y, percentile=15, size=401, mode="nearest")
base = gaussian_filter1d(base, 120)
signal = gaussian_filter1d(y - base, 1.2)
noise = np.sqrt(np.maximum(gaussian_filter1d(y, 30), 1.0))
peaks, props = find_peaks(signal / noise, prominence=4.0, distance=6)
prom = props["prominences"] * noise[peaks]
width = peak_widths(signal, peaks, rel_height=0.5)[0] * np.median(np.diff(x))

order = np.argsort(prom)[::-1]
print(f"points={len(x)} range={x[0]:.8f}..{x[-1]:.8f} step={np.median(np.diff(x)):.8f}")
print(f"counts min/median/max={y.min():.1f}/{np.median(y):.1f}/{y.max():.1f}")
print("rank  2theta       d_A       intensity  excess   prominence FWHM_deg")
lam = 1.540598
for rank, j in enumerate(order[:140], 1):
    i = peaks[j]
    d = lam / (2 * np.sin(np.deg2rad(x[i] / 2)))
    print(f"{rank:3d} {x[i]:11.6f} {d:9.5f} {y[i]:10.1f} {signal[i]:8.1f} {prom[j]:10.1f} {width[j]:8.4f}")
