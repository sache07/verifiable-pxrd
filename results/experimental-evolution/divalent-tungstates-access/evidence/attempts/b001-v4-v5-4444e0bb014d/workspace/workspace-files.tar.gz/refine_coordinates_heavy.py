#!/usr/bin/env python3
"""Bounded refinement of the heavy-atom coordinates in accepted WO3."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SRC = Path("trials/instrument_refinement/02_Polariz..gpx")
OUT = Path("trials/coordinate_refinement")
OUT.mkdir(parents=True, exist_ok=True)
p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(OUT / "working.gpx"))
h = p.histogram(0)


def bound(name, lo, hi):
    p.set_Controls("parmMin", lo, variable=name)
    p.set_Controls("parmMax", hi, variable=name)


# Calcite's isotropic strain reached the physically allowed ceiling in the
# preceding profile refinement. Keep that value, but do not repeatedly try to
# refine it past the boundary.
calcite = p.phase("CaCO3_calcite")
calcite.clear_HAP_refinements({"Mustrain": True}, [h])
p.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []

wo3 = p.phase("WO3")
start = {}
for i, atom in enumerate(wo3.atoms()):
    if atom.element != "W":
        continue
    start[atom.label] = list(atom.coordinates)
    atom.refinement_flags = "X"
    for axis, value in zip("xyz", atom.coordinates):
        bound(f"{wo3.id}::A{axis}:{i}", value - 0.02, value + 0.02)

p.set_Controls("cycles", 15)
p.refine()
p.save()
shutil.copy2(p.filename, OUT / "01_W_heavy.gpx")

result = {
    "step": "WO3 W coordinates",
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "start": start,
    "finish": {
        atom.label: list(atom.coordinates)
        for atom in wo3.atoms()
        if atom.element == "W"
    },
    "short_distances": {ph.name: ph.ShortDistances() for ph in p.phases()},
    "frozen": [
        str(v)
        for v in p.data["Controls"]["data"]
        .get("parmFrozen", {})
        .get("FrozenList", [])
    ],
    "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
}
print("RESULT", json.dumps(result, default=float))
