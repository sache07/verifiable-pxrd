#!/usr/bin/env python3
"""Test supported common instrument-profile complexity one term at a time."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SRC = Path("trials/complete_inventory/candidate.gpx")
OUT = Path("trials/instrument_refinement")
OUT.mkdir(parents=True, exist_ok=True)
p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(OUT / "working.gpx"))
h = p.histogram(0)


def bound(name, lo, hi):
    p.set_Controls("parmMin", lo, variable=name)
    p.set_Controls("parmMax", hi, variable=name)


for key, lo, hi in (
    ("SH/L", 0.005, 0.1),
    ("Polariz.", 0.5, 1.0),
    ("X", 0.1, 6.0),
    ("W", 2.0, 40.0),
    ("U", 0.0, 40.0),
):
    bound(f":0:{key}", lo, hi)

for idx, key in enumerate(("SH/L", "Polariz.", "X", "W", "U"), 1):
    h.set_refinements({"Instrument Parameters": [key]})
    for _ in range(2):
        p.set_Controls("cycles", 12)
        p.refine()
    p.save()
    shutil.copy2(p.filename, OUT / f"{idx:02d}_{key.replace('/', '_')}.gpx")
    print(
        "RESULT",
        json.dumps(
            {
                "step": key,
                "wR": h.get_wR(),
                "instrument": {
                    k: h.data["Instrument Parameters"][0][k][1]
                    for k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")
                },
                "fractions": h.ComputeMassFracs(),
                "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
            },
            default=float,
        ),
    )

shutil.copy2(p.filename, OUT / "candidate.gpx")
