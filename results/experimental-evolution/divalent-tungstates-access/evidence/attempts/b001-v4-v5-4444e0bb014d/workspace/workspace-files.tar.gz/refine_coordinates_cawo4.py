#!/usr/bin/env python3
"""Bounded oxygen-coordinate refinement for the dominant CaWO4 phase."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SRC = Path("trials/coordinate_refinement/01_W_heavy.gpx")
OUT = Path("trials/coordinate_refinement")
p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(OUT / "working_cawo4.gpx"))
h = p.histogram(0)


def bound(name, lo, hi):
    p.set_Controls("parmMin", lo, variable=name)
    p.set_Controls("parmMax", hi, variable=name)


# Hold the completed heavy-atom stage while introducing the dominant-phase
# oxygen coordinates.
for atom in p.phase("WO3").atoms():
    atom.refinement_flags = " "

phase = p.phase("CaWO4")
start = {}
for i, atom in enumerate(phase.atoms()):
    if atom.element != "O":
        continue
    start[atom.label] = list(atom.coordinates)
    atom.refinement_flags = "X"
    for axis, value in zip("xyz", atom.coordinates):
        bound(f"{phase.id}::A{axis}:{i}", value - 0.02, value + 0.02)

p.set_Controls("cycles", 15)
p.refine()
p.save()
shutil.copy2(p.filename, OUT / "02_CaWO4_O.gpx")

result = {
    "step": "CaWO4 O coordinates",
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "start": start,
    "finish": {
        atom.label: list(atom.coordinates)
        for atom in phase.atoms()
        if atom.element == "O"
    },
    "short_distances": {ph.name: ph.ShortDistances() for ph in p.phases()},
    "frozen": [
        str(v)
        for v in p.data["Controls"]["data"]
        .get("parmFrozen", {})
        .get("FrozenList", [])
    ],
    "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
}
print("RESULT", json.dumps(result, default=float))
