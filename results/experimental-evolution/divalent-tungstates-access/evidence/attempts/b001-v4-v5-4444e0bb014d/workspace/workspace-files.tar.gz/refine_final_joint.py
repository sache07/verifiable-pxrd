#!/usr/bin/env python3
"""Final joint refinement from the accepted physical coordinate checkpoint."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SRC = Path("trials/coordinate_staged/03_CaWO4_O_continue.gpx")
OUT = Path("trials/final_joint")
OUT.mkdir(parents=True, exist_ok=True)
p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(OUT / "working.gpx"))
h = p.histogram(0)

# Coordinates have been accepted at the preceding bounded checkpoints. Keep
# them fixed while the coupled peak positions, shapes, scales and background
# are brought back into equilibrium.
for phase in p.phases():
    for atom in phase.atoms():
        atom.refinement_flags = " "
    phase.set_refinements({"Cell": True})
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {
                "type": "isotropic",
                "refine": phase.name != "CaCO3_calcite",
            },
        },
        [h],
    )

h.set_refinements({"Sample Parameters": ["Shift"]})
h.set_refinements({"Instrument Parameters": ["SH/L", "Polariz."]})
p.data["Controls"]["data"].setdefault("parmFrozen", {})["FrozenList"] = []

p.set_Controls("cycles", 15)
p.refine()
p.save()
shutil.copy2(p.filename, OUT / "01_joint.gpx")

result = {
    "wR": h.get_wR(),
    "fractions": h.ComputeMassFracs(),
    "instrument": {
        key: h.data["Instrument Parameters"][0][key]
        for key in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")
    },
    "sample": {
        key: h.data["Sample Parameters"][key]
        for key in ("Shift", "SurfRoughA", "SurfRoughB")
    },
    "phases": [
        {
            "name": phase.name,
            "cell": phase.get_cell(),
            "size": phase.data["Histograms"][h.name]["Size"],
            "mustrain": phase.data["Histograms"][h.name]["Mustrain"],
            "short_distances": phase.ShortDistances(),
        }
        for phase in p.phases()
    ],
    "frozen": [
        str(v)
        for v in p.data["Controls"]["data"]
        .get("parmFrozen", {})
        .get("FrozenList", [])
    ],
    "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
}
print("RESULT", json.dumps(result, default=float))
