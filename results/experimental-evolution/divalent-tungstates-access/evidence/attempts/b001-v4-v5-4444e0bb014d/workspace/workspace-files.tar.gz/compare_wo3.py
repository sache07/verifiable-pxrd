#!/usr/bin/env python3
"""Replace WO3 in the complete model and compare exact-composition references."""

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
SRC = Path("trials/with_calcite/06_joint_continue.gpx")


def cod_path(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def bound(project, name, lo, hi):
    project.set_Controls("parmMin", lo, variable=name)
    project.set_Controls("parmMax", hi, variable=name)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cod_id")
    args = ap.parse_args()
    out = Path("trials") / f"wo3_compare_{args.cod_id}"
    out.mkdir(parents=True, exist_ok=True)
    p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(out / "working.gpx"))
    h = p.histogram(0)

    # Freeze accepted components and disable the incumbent WO3 contribution.
    h.clear_refinements({"Sample Parameters": ["Shift"]})
    for ph in p.phases():
        ph.clear_refinements({"Cell": True})
        ph.clear_HAP_refinements({"Size": True, "Mustrain": True}, [h])
        if ph.name == "WO3_monoclinic":
            ph.data["Histograms"][h.name]["Use"] = False
            ph.data["Histograms"][h.name]["Scale"] = [0.0, False]

    cand = p.add_phase(
        str(cod_path(args.cod_id)),
        phasename=f"WO3_candidate_{args.cod_id}",
        histograms=[h],
        fmthint="CIF",
    )
    hap = cand.data["Histograms"][h.name]
    hap["Scale"] = [1.9, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.36
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1900.0
    for atom in cand.atoms():
        try:
            if atom.uiso <= 0:
                atom.uiso = 0.01
        except Exception:
            pass

    bound(p, f"{cand.id}:0:Scale", 0.0, 100.0)
    bound(p, f"{cand.id}:0:Size;i", 0.04, 1.5)
    bound(p, f"{cand.id}:0:Mustrain;i", 1.0, 8000.0)
    for i, value in enumerate(G2lat.cell2A(cand.data["General"]["Cell"][1:7])):
        if abs(value) > 0.002:
            lo, hi = value * 0.98, value * 1.02
        elif abs(value) > 1e-7:
            lo, hi = value * 0.5, value * 1.5
        else:
            lo, hi = -0.0002, 0.0002
        if lo > hi:
            lo, hi = hi, lo
        bound(p, f"{cand.id}::A{i}", lo, hi)

    p.save()
    p.set_Controls("cycles", 10)
    p.refine()
    cand.set_refinements({"Cell": True})
    p.refine()
    cand.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [h],
    )
    p.set_Controls("cycles", 15)
    p.refine()
    p.refine()
    p.save()
    shutil.copy2(p.filename, out / "candidate.gpx")
    result = {
        "cod_id": args.cod_id,
        "wR": h.get_wR(),
        "cell": cand.get_cell(),
        "scale": hap["Scale"],
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "short_distances": cand.ShortDistances(),
        "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
    }
    with open(out / "summary.json", "w") as fp:
        json.dump(result, fp, indent=2, default=float)
    print("SUMMARY", json.dumps(result, default=float))


if __name__ == "__main__":
    main()
