#!/usr/bin/env python3
"""Add and physically refine residual calcite to the accepted two-phase model."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


SRC = Path("trials/position_refined/continued_checkpoint.gpx")
OUT = Path("trials/with_calcite")
OUT.mkdir(parents=True, exist_ok=True)
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif/1/54/73/1547347.cif")


def bound(project, name, lo, hi):
    project.set_Controls("parmMin", lo, variable=name)
    project.set_Controls("parmMax", hi, variable=name)


def cell_bounds(project, phase):
    cell = phase.data["General"]["Cell"][1:7]
    for i, value in enumerate(G2lat.cell2A(cell)):
        if abs(value) > 0.002:
            lo, hi = value * 0.98, value * 1.02
        elif abs(value) > 1e-7:
            lo, hi = value * 0.5, value * 1.5
        else:
            lo, hi = -0.0002, 0.0002
        if lo > hi:
            lo, hi = hi, lo
        bound(project, f"{phase.id}::A{i}", lo, hi)


def step(project, label, cycles=10):
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    shutil.copy2(project.filename, OUT / f"{label}.gpx")
    h = project.histogram(0)
    info = {
        "step": label,
        "wR": h.get_wR(),
        "mass_fractions": h.ComputeMassFracs(),
        "shift": h.data["Sample Parameters"]["Shift"][0],
        "phases": [],
        "rvals": project.data["Covariance"]["data"].get("Rvals", {}),
    }
    for ph in project.phases():
        hap = ph.data["Histograms"][h.name]
        info["phases"].append(
            {
                "name": ph.name,
                "cell": ph.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][0],
                "strain": hap["Mustrain"][1][0],
            }
        )
    print("RESULT", json.dumps(info, default=float))


p = G2sc.G2Project(gpxfile=str(SRC), newgpx=str(OUT / "working.gpx"))
h = p.histogram(0)

# Hold the accepted two-phase geometry/profile while the residual phase obtains
# a positive scale from its full reflection family.
h.clear_refinements({"Sample Parameters": ["Shift"]})
for ph in p.phases():
    ph.clear_refinements({"Cell": True})
    ph.clear_HAP_refinements({"Size": True, "Mustrain": True}, [h])

calcite = p.add_phase(
    str(COD), phasename="CaCO3_calcite", histograms=[h], fmthint="CIF"
)
hap = calcite.data["Histograms"][h.name]
hap["Scale"] = [1.0, True]
hap["Size"][0] = "isotropic"
hap["Size"][1][0] = 0.5
hap["Mustrain"][0] = "isotropic"
hap["Mustrain"][1][0] = 500.0

bound(p, f"{calcite.id}:0:Scale", 0.0, 100.0)
bound(p, f"{calcite.id}:0:Size;i", 0.04, 1.5)
bound(p, f"{calcite.id}:0:Mustrain;i", 1.0, 8000.0)
cell_bounds(p, calcite)
p.save()
step(p, "01_scale")

calcite.set_refinements({"Cell": True})
step(p, "02_cell")
calcite.set_HAP_refinements(
    {"Size": {"type": "isotropic", "refine": True}}, [h]
)
step(p, "03_size")
calcite.set_HAP_refinements(
    {"Mustrain": {"type": "isotropic", "refine": True}}, [h]
)
step(p, "04_strain")

# Release the accepted parameters together from the complete inventory.
h.set_refinements({"Sample Parameters": ["Shift"]})
for ph in p.phases():
    ph.set_refinements({"Cell": True})
    ph.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [h],
    )
step(p, "05_joint", cycles=15)
step(p, "06_joint_continue", cycles=15)
shutil.copy2(p.filename, OUT / "candidate.gpx")
