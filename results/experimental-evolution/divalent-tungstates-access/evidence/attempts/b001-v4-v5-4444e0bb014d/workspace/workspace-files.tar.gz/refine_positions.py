#!/usr/bin/env python3
"""Refine physical cells/height from the stable fixed-position profile."""

import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc
from GSASII import GSASIIlattice as G2lat


src = Path("trials/fresh_physical/05_wo_strain.gpx")
out = Path("trials/position_refined")
out.mkdir(parents=True, exist_ok=True)
p = G2sc.G2Project(gpxfile=str(src), newgpx=str(out / "working.gpx"))
h = p.histogram(0)


def bounds(name, lo, hi):
    p.set_Controls("parmMin", lo, variable=name)
    p.set_Controls("parmMax", hi, variable=name)


bounds(":0:Shift", -800.0, 800.0)
h.set_refinements({"Sample Parameters": ["Shift"]})

for ph in p.phases():
    A = G2lat.cell2A(ph.data["General"]["Cell"][1:7])
    ph.set_refinements({"Cell": True})
    for i, value in enumerate(A):
        # Symmetry-fixed components will not enter the vary list. Diagonal
        # reciprocal terms are allowed 1.5%; monoclinic shear is allowed 50%.
        if abs(value) > 0.002:
            lo, hi = value * 0.985, value * 1.015
        elif abs(value) > 1e-7:
            lo, hi = value * 0.5, value * 1.5
        else:
            lo, hi = -0.0002, 0.0002
        if lo > hi:
            lo, hi = hi, lo
        bounds(f"{ph.id}::A{i}", lo, hi)

p.set_Controls("cycles", 12)
p.refine()
p.save()
shutil.copy2(p.filename, out / "candidate.gpx")

info = {
    "wR": h.get_wR(),
    "shift": h.data["Sample Parameters"]["Shift"][0],
    "cells": {ph.name: ph.get_cell() for ph in p.phases()},
    "rvals": p.data["Covariance"]["data"].get("Rvals", {}),
}
print(json.dumps(info, default=float, indent=2))
