import gzip
import json
from pathlib import Path

from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure

INDEX = Path("<HOME>/.local/share/characterizagent/backends/dara/venv/lib/python3.11/site-packages/dara/data/cod_filtered_info_2024.json.gz")
ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")

with gzip.open(INDEX, "rt") as handle:
    index = json.load(handle)


def cif_path(cod_id):
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


calc = XRDCalculator(wavelength="CuKa1", symprec=0)
for key in ("Ca-O-W", "O-W", "Ca-O", "C-Ca-O"):
    print(f"\n### {key}")
    for formula, cod_id, sg, quality in index[key]:
        if key == "O-W" and formula not in {"WO3"}:
            continue
        if key == "C-Ca-O" and "CaCO3" not in formula:
            continue
        try:
            s = Structure.from_file(cif_path(cod_id), primitive=False)
            pat = calc.get_pattern(s, two_theta_range=(10, 100), scaled=True)
            peaks = sorted(zip(pat.y, pat.x), reverse=True)[:12]
            peaktext = " ".join(f"{x:.3f}:{y:.0f}" for y, x in peaks)
            print(
                f"{cod_id} {s.composition.reduced_formula:12s} "
                f"SG={s.get_space_group_info()[0]:10s}/{s.get_space_group_info()[1]:3d} "
                f"abc={s.lattice.a:.4f},{s.lattice.b:.4f},{s.lattice.c:.4f} "
                f"ang={s.lattice.alpha:.2f},{s.lattice.beta:.2f},{s.lattice.gamma:.2f} "
                f"rho={s.density:.3f} q={quality} peaks {peaktext}"
            )
        except Exception as exc:
            print(f"{cod_id} ERROR {exc}")
