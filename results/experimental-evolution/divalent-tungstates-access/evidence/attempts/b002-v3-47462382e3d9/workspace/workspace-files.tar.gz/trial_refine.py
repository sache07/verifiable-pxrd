#!/usr/bin/env python3
"""Build and run a staged GSAS-II powder refinement for candidate phases."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def write_inputs(root: Path) -> tuple[Path, Path]:
    data = np.loadtxt(root / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    xye = root / "diagnostics" / "pattern.xye"
    np.savetxt(xye, np.column_stack((data, np.sqrt(np.maximum(data[:, 1], 1.0)))),
               fmt=["%.8f", "%.8f", "%.8f"])
    inst = root / "diagnostics" / "initial.instprm"
    inst.write_text(
        "# GSAS-II initial Cu Kalpha laboratory profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:-0.02;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        amount = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(max(amount, 0.0))
        phases.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        })
    total = sum(masses)
    for row, amount in zip(phases, masses):
        row["weight_fraction"] = amount / total if total else 0.0
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    return {
        "label": label,
        "residuals": hist.residuals,
        "instrument": {k: inst[k] for k in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.") if k in inst},
        "sample": {k: sample[k] for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type") if k in sample},
        "background": hist.Background,
        "phases": phases,
    }


def refine(project: G2.G2Project, label: str, history: list[dict]) -> None:
    project.refine()
    state = snapshot(project, label)
    history.append(state)
    print(json.dumps({"label": label, "residuals": state["residuals"],
                      "fractions": {p["name"]: p["weight_fraction"] for p in state["phases"]}},
                     allow_nan=False), flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phase", nargs="+", help="NAME=CIF")
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--quick", action="store_true")
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    args.output.parent.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(root)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(args.output.resolve()))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    phases = []
    for spec in args.phase:
        name, cif = spec.split("=", 1)
        phases.append(project.add_phase(str(Path(cif).resolve()), phasename=name,
                                        histograms=[hist], fmthint="CIF"))

    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Limits": [float(np.loadtxt(xye)[:, 0].min()), float(np.loadtxt(xye)[:, 0].max())],
                          "Background": {"type": "chebyschev-1", "no. coeffs": 8,
                                         "coeffs": [1400.0] + [0.0] * 7, "refine": True}})
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 100.0
        phase.set_HAP_refinements({"Scale": True})

    project.set_Controls("cycles", 8)
    history: list[dict] = []
    refine(project, "scale_background", history)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, "cells_zero", history)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
    refine(project, "instrument_profile", history)

    if args.quick:
        project.save()
        args.output.with_suffix(".json").write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")
        return

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True},
                                   "Mustrain": {"type": "isotropic", "refine": True}})
    refine(project, "phase_profiles", history)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "specimen_shift", history)

    if args.coordinates:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "XU"}})
        refine(project, "coordinates_uiso", history)

    project.save()
    args.output.with_suffix(".json").write_text(json.dumps(history, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
