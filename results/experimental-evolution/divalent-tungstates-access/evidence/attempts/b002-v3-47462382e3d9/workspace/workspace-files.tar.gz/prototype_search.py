#!/usr/bin/env python3
"""Screen cross-chemistry oxide frameworks against an unassigned PXRD family."""

from __future__ import annotations

import gzip
import json
import math
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from pymatgen.io.cif import CifWriter
from scipy.signal import find_peaks


ROOT = Path(__file__).resolve().parent
LIB = (ROOT / "../../../resources/b002-c02/cif").resolve()
INDEX = (ROOT / "../../../resources/b002-c02/index.json.gz").resolve()
OUT = ROOT / "diagnostics" / "prototype_candidates"

TARGETS = {
    "Mn3WO6": ((3.0, 1.0, 6.0), 3.0, 1.0),
    "Mn2WO5": ((2.0, 1.0, 5.0), 2.0, 1.0),
    "Mn3W2O9": ((3.0, 2.0, 9.0), 3.0, 2.0),
}


def cif_path(cid: str) -> Path:
    return LIB / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def reduced_amounts(formula: str):
    comp = Composition(formula).reduced_composition.get_el_amt_dict()
    if len(comp) != 3 or "O" not in comp:
        return None
    return comp


def target_mapping(amounts: dict[str, float], target: tuple[float, float, float]):
    non_o = [(el, value) for el, value in amounts.items() if el != "O"]
    if abs(amounts["O"] - target[2]) > 1e-5:
        return None
    if sorted(round(v, 6) for _, v in non_o) != sorted(round(v, 6) for v in target[:2]):
        return None
    # The target tuples used here have distinct cation counts.
    source_mn = next(el for el, value in non_o if abs(value - target[0]) < 1e-5)
    source_w = next(el for el, value in non_o if abs(value - target[1]) < 1e-5)
    return {source_mn: "Mn", source_w: "W"}


def score_pattern(sticks: np.ndarray, residual_peaks: np.ndarray):
    # The first seven are the low-angle family-defining peaks; later residual
    # peaks provide confirmation but include more overlap/profile uncertainty.
    family = np.array([19.85706, 20.38951, 25.43152, 31.77750,
                       32.48381, 35.09175, 46.51233])
    family_weight = np.array([2.7, 4.5, .75, 1.2, .8, 3.8, 1.8])
    best = None
    theta0 = np.deg2rad(sticks[:, 0] / 2)
    dproxy = 1.0 / np.sin(theta0)
    inten = np.maximum(sticks[:, 1], 0) / 100.0
    for scale in np.linspace(0.78, 1.22, 177):
        theta = np.arcsin(np.clip(1.0 / (dproxy * scale), 0, 1))
        base = np.rad2deg(2 * theta)
        for shift in np.linspace(-0.18, 0.18, 37):
            pos = base + shift
            visible = (pos >= 9.9) & (pos <= 100.1) & (inten >= .004)
            p = pos[visible]
            ii = inten[visible]
            if not len(p):
                continue
            dfam = np.abs(family[:, None] - p[None, :])
            # Reward each family line only when a nontrivial predicted line lands on it.
            line_match = np.max((ii[None, :] ** .45) * np.exp(-.5 * (dfam / .13) ** 2), axis=1)
            coverage = float(np.sum(family_weight * line_match))
            # Additional residual peaks reward corroborating lines.
            dres = np.abs(p[:, None] - residual_peaks[:, 0][None, :])
            j = np.argmin(dres, axis=1)
            near = np.exp(-.5 * (dres[np.arange(len(p)), j] / .15) ** 2)
            corroboration = float(np.sum(ii ** .55 * near * np.sqrt(residual_peaks[j, 1] / 1000.0)))
            # Penalize strong low-angle lines for which no observed peak exists.
            low = p < 55
            penalty = float(np.sum(ii[low] ** .55 * (1.0 - near[low])))
            value = coverage + .35 * corroboration - .45 * penalty
            trial = (value, coverage, corroboration, penalty, scale, shift, line_match.tolist())
            if best is None or trial[0] > best[0]:
                best = trial
    return best


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    with np.load(ROOT / "diagnostics" / "replay_two" / "prediction.npz") as z:
        x, observed, calculated = z["x"], z["observed"], z["predicted"]
    residual = observed - calculated
    peaks, props = find_peaks(residual, prominence=220, distance=4, width=1)
    residual_peaks = np.column_stack((x[peaks], props["prominences"]))

    rows = []
    seen = set()
    calc = XRDCalculator(wavelength=1.540598, symprec=0)
    for chemistry_rows in index.values():
        for formula, cid, reported_sg, rvalue in chemistry_rows:
            if cid in seen:
                continue
            seen.add(cid)
            try:
                amounts = reduced_amounts(formula)
            except Exception:
                continue
            if amounts is None:
                continue
            for target_name, (ratio, _, _) in TARGETS.items():
                mapping = target_mapping(amounts, ratio)
                if mapping is None:
                    continue
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore")
                        parent = Structure.from_file(cif_path(cid), primitive=False)
                    child = parent.copy()
                    child.remove_oxidation_states()
                    child.replace_species(mapping)
                    pattern = calc.get_pattern(child, two_theta_range=(9.5, 100.5))
                    sticks = np.column_stack((pattern.x, pattern.y))
                    best = score_pattern(sticks, residual_peaks)
                    if best is None:
                        continue
                    out_cif = OUT / f"{target_name}_{cid}.cif"
                    CifWriter(child, symprec=None, refine_struct=False).write_file(out_cif)
                    rows.append({
                        "target": target_name,
                        "parent_id": cid,
                        "parent_formula": formula,
                        "parent_space_group_number": reported_sg,
                        "substitutions": mapping,
                        "candidate_cif": str(out_cif.relative_to(ROOT)),
                        "score": best[0],
                        "family_coverage": best[1],
                        "corroboration": best[2],
                        "unmatched_penalty": best[3],
                        "isotropic_lattice_scale": best[4],
                        "zero_shift_deg": best[5],
                        "family_line_matches": best[6],
                        "parent_cell": list(parent.lattice.parameters),
                        "candidate_composition": child.composition.formula,
                    })
                except Exception as exc:
                    rows.append({"target": target_name, "parent_id": cid,
                                 "parent_formula": formula, "error": str(exc)})
                break

    valid = [row for row in rows if "score" in row]
    valid.sort(key=lambda row: row["score"], reverse=True)
    (OUT / "ranking.json").write_text(json.dumps(valid, indent=2, allow_nan=False) + "\n")
    for row in valid[:60]:
        print(f"{row['score']:8.3f} {row['target']:9s} parent={row['parent_id']} "
              f"{row['parent_formula']:15s} SG={row['parent_space_group_number']:3d} "
              f"scale={row['isotropic_lattice_scale']:.4f} shift={row['zero_shift_deg']:+.3f} "
              f"lines={np.round(row['family_line_matches'], 2)}")


if __name__ == "__main__":
    main()
