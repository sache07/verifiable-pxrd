from pathlib import Path

from GSASII import GSASIIscriptable as G2


root = Path(__file__).resolve().parent
source = root / "diagnostics" / "c2c_zero.gpx"
project_path = root / "final.gpx"

project = G2.G2Project(gpxfile=str(source), newgpx=str(project_path))
project.save()

# Export directly from the saved phase dictionaries. The covariance block only
# describes the last refinement stage and can otherwise substitute stale values
# for parameters refined in earlier stages during CIF export.
project.data["Covariance"]["data"] = {}
exports = {
    "MnWO4": root / "MnWO4.cif",
    "WO3": root / "WO3.cif",
    "Mn3WO6": root / "Mn3WO6.cif",
}
for phase_name, destination in exports.items():
    project.phase(phase_name).export_CIF(str(destination))

print(project_path)
for destination in exports.values():
    print(destination)
