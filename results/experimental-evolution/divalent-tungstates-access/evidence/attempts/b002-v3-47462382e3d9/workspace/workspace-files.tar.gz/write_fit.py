from pathlib import Path

import numpy as np


root = Path(__file__).resolve().parent
with np.load(root / "diagnostics" / "replay_submitted" / "prediction.npz") as replay:
    two_theta = replay["x"]
    observed = replay["observed"]
    calculated = replay["predicted"]

difference = observed - calculated
np.savetxt(
    root / "fit.csv",
    np.column_stack((two_theta, observed, calculated, difference)),
    delimiter=",",
    header="two_theta,observed,calculated,difference",
    comments="",
    fmt="%.12g",
)

weights = 1.0 / np.maximum(observed, 1.0)
chi_square = float(np.sum(weights * difference**2))
rwp = float(100.0 * np.sqrt(chi_square / np.sum(weights * observed**2)))
rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
number_parameters = 24
gof = float(np.sqrt(chi_square / (len(observed) - number_parameters)))
print(f"Rwp_percent={rwp:.12g}")
print(f"Rp_percent={rp:.12g}")
print(f"chi_square={chi_square:.12g}")
print(f"GOF={gof:.12g}")
print(f"observations={len(observed)}")
print(f"parameters={number_parameters}")
