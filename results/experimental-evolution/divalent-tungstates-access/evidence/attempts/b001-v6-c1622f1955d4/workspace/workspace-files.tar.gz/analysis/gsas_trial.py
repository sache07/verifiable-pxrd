#!/usr/bin/env python3
"""Build and refine a trial multiphase GSAS-II model for candidate screening."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_data(inputs: Path, work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    xye = work / "pattern.xye"
    with (inputs / "pattern.csv").open(newline="") as source, xye.open("w") as target:
        rows = csv.DictReader(source)
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            target.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for laboratory Cu Kalpha data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.7;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def set_bounds(project: G2.G2Project, phase_names: list[str], histogram) -> None:
    project.index_ids()
    hid = histogram.id
    for phase_name in phase_names:
        phase = project.phase(phase_name)
        pid = phase.id
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", 1.0e5, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.03, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 2.0, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 10000.0, variable=f"{pid}:{hid}:Mustrain;i")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.008 * abs(float(value)), 0.0002)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
    bounds = {
        "Zero": (-0.25, 0.25),
        "U": (0.0, 40.0),
        "W": (2.0, 40.0),
        "X": (0.1, 6.0),
        "SH/L": (0.005, 0.10),
        "Polariz.": (0.5, 1.0),
    }
    for name, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")


def rvals(project: G2.G2Project, histogram) -> dict:
    data = project.data.get("Covariance", {}).get("data", {})
    values = data.get("Rvals", {})
    return {
        "Rwp": float(histogram.get_wR() or values.get("Rwp", float("nan"))),
        "GOF": float(values.get("GOF", float("nan"))),
        "chisq": float(values.get("chisq", float("nan"))),
        "converged": bool(values.get("converged", False)),
        "max_shift_esd": None if values.get("Max shft/sig") is None else float(values["Max shft/sig"]),
    }


def refine_once(project: G2.G2Project, label: str, records: list[dict], cycles: int = 8) -> None:
    project.data["Controls"]["data"]["max cyc"] = cycles
    project.refine()
    hist = project.histogram(0)
    record = {"step": label, **rvals(project, hist)}
    record["zero"] = float(hist.InstrumentParameters["Zero"][1])
    record["shift_um"] = float(hist.SampleParameters["Shift"][0])
    records.append(record)
    print(json.dumps(record, sort_keys=True))


def build_trial(out: Path, inputs: Path, candidates: list[tuple[str, str]], screen: bool = False) -> dict:
    G2.SetPrintLevel("error")
    work = out.parent / (out.stem + "_work")
    xye, inst = prepare_data(inputs, work)
    project = G2.G2Project(newgpx=str(out))
    phases = []
    for name, cod_id in candidates:
        phases.append(project.add_phase(str(cod_path(cod_id)), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [780.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": {"low": 9.95, "high": 100.05},
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 8,
            "coeffs": [1800.0, -700.0, 450.0, -300.0, 180.0, -100.0, 50.0, -20.0],
            "refine": True,
        },
    })
    for i, phase in enumerate(phases):
        mass = float(phase.data["General"]["Mass"])
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [5000.0 / mass, True]
        phase.setSampleProfile(hist.name, "size", "isotropic", 0.3, LGmix=1.0)
        phase.setSampleProfile(hist.name, "microstrain", "isotropic", 1000.0, LGmix=1.0)
        phase.set_HAP_refinements({"Scale": True})
    set_bounds(project, [p.name for p in phases], hist)
    project.set_Controls("cycles", 8)
    records: list[dict] = []

    cycles = 5 if screen else 8
    refine_once(project, "scale_background", records, cycles)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_once(project, "zero", records, cycles)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine_once(project, "cells", records, cycles)

    if screen:
        project.save()
        return write_summary(out, project, candidates, records)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_once(project, "shift_zero_cells", records)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_once(project, "instrument_profile", records)

    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    refine_once(project, "sizes", records)

    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine_once(project, "microstrain", records)

    project.save()
    return write_summary(out, project, candidates, records)


def write_summary(out: Path, project: G2.G2Project, candidates: list[tuple[str, str]], records: list[dict]) -> dict:
    hist = project.histogram(0)
    phases = project.phases()
    summary = {
        "project": str(out),
        "candidates": [{"name": n, "cod_id": c} for n, c in candidates],
        "records": records,
        "instrument": {k: v for k, v in hist.InstrumentParameters.items()},
        "sample": hist.SampleParameters,
        "phases": [],
    }
    try:
        fractions = hist.ComputeMassFracs()
    except Exception:
        fractions = {}
    for phase in phases:
        summary["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
            "mass_fraction": None if phase.name not in fractions else float(fractions[phase.name][0]),
            "size": phase.data["Histograms"][hist.name]["Size"],
            "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
        })
    summary_path = out.with_suffix(".summary.json")
    summary_path.write_text(json.dumps(summary, indent=2, default=str) + "\n")
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--inputs", type=Path, default=Path("inputs"))
    parser.add_argument("--cuwo4", default="4000806")
    parser.add_argument("--wo3", default="1528915")
    parser.add_argument("--cuo", default="1011194")
    parser.add_argument("--without-cuo", action="store_true")
    parser.add_argument("--with-cu3wo6", action="store_true")
    parser.add_argument("--with-cu2wo4", action="store_true")
    parser.add_argument("--screen", action="store_true")
    args = parser.parse_args()
    candidates = [("CuWO4", args.cuwo4), ("WO3", args.wo3)]
    if args.with_cu3wo6:
        candidates.append(("Cu3WO6", "1527404"))
    if args.with_cu2wo4:
        candidates.append(("Cu2WO4", "2002403"))
    if not args.without_cuo:
        candidates.append(("CuO", args.cuo))
    build_trial(args.out.resolve(), args.inputs.resolve(), candidates, screen=args.screen)


if __name__ == "__main__":
    main()
