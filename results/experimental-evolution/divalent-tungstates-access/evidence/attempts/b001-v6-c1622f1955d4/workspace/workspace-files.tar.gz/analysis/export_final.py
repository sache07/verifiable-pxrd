#!/usr/bin/env python3
"""Export the accepted replayed GSAS-II project into the requested deliverables."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
import shutil

import numpy as np
from pymatgen.core import Structure


ROOT = Path(__file__).resolve().parents[1]
REPLAY = ROOT / "analysis" / "final_replay"
COD_IDS = {
    "CuWO4": "4000806",
    "WO3": "2311041",
    "Cu3WO6": "1527404",
    "CuO": "1011194",
}
OUTPUT_CIFS = {
    "CuWO4": "CuWO4.cif",
    "WO3": "WO3.cif",
    "Cu3WO6": "Cu3WO6.cif",
    "CuO": "CuO.cif",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError("final.gpx did not replay successfully")
    final_gpx = ROOT / "final.gpx"
    if sha256(final_gpx) != replay["project_sha256"]:
        raise RuntimeError("final.gpx changed after replay")

    phase_rows = []
    for index, phase in enumerate(replay["phases"]):
        name = phase["name"]
        destination = ROOT / OUTPUT_CIFS[name]
        shutil.copy2(REPLAY / phase["cif"], destination)
        structure = Structure.from_file(destination, primitive=False)
        cell = structure.lattice.parameters
        phase_rows.append({
            "name": name,
            "formula": structure.composition.reduced_formula,
            "cif_path": destination.name,
            "weight_fraction": float(phase["weight_fraction"]),
            "weight_percent": 100.0 * float(phase["weight_fraction"]),
            "reference": {"database": "COD", "id": COD_IDS[name]},
            "space_group": {
                "symbol": structure.get_space_group_info()[0],
                "number": int(structure.get_space_group_info()[1]),
            },
            "refined_cell": {
                "a_angstrom": float(cell[0]),
                "b_angstrom": float(cell[1]),
                "c_angstrom": float(cell[2]),
                "alpha_deg": float(cell[3]),
                "beta_deg": float(cell[4]),
                "gamma_deg": float(cell[5]),
                "volume_angstrom3": float(structure.volume),
            },
        })

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as archive:
        x = archive["x"].copy()
        observed = archive["observed"].copy()
        calculated = archive["predicted"].copy()
        background = archive["background"].copy()
    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    weighted_chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(weighted_chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream, lineterminator="\n")
        writer.writerow(["two_theta", "observed", "calculated", "difference", "background"])
        for row in zip(x, observed, calculated, difference, background):
            writer.writerow([f"{row[0]:.8f}", f"{row[1]:.8f}", f"{row[2]:.8f}", f"{row[3]:.8f}", f"{row[4]:.8f}"])

    fit_statistics = {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "weighted_chi_square": weighted_chi_square,
        "mean_weighted_squared_residual": weighted_chi_square / len(x),
        "n_points": int(len(x)),
        "weighting": "1/max(observed_counts,1)",
        "profile_scope": "native GSAS-II replay on the complete original grid; no parameters optimized during replay",
    }
    result = {
        "schema_version": 1,
        "refinement_histogram": replay["histogram"],
        "phases": phase_rows,
        "fit_statistics": fit_statistics,
        "calibration": {
            "zero_deg": float(replay["instrument"]["Zero"][1]),
            "sample_displacement_um": 511.097810807107,
            "goniometer_radius_mm": 200.0,
        },
        "quantification_basis": "weight fractions normalized over the four modeled crystalline phases; amorphous content is not quantified",
        "project": {
            "path": "final.gpx",
            "sha256": replay["project_sha256"],
            "native_replay_status": replay["status"],
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")

    table = "\n".join(
        f"| {row['name']} | {row['space_group']['symbol']} ({row['space_group']['number']}) | "
        f"{row['reference']['id']} | {row['weight_percent']:.2f} |"
        for row in phase_rows
    )
    report = f"""# Powder XRD phase analysis

The accepted model contains four crystalline phases. Fractions are normalized only over those modeled crystalline phases.

| Phase | Space group | Frozen COD reference | wt% |
|---|---:|---:|---:|
{table}

## Evidence

The precursor chemistry (CuO + WO3, 700 °C) first supports copper tungstate and residual precursor models. Triclinic CuWO4 accounts for the strong 18.81°, 29.09°, 30.08°, and 31.4–31.5° families. Monoclinic WO3 accounts for the 22.67°, 23.07–23.13°, and 23.89° family. A separate coherent set at 15.20°, 19.80°, 32.50°, 33.79°, 49.70°, 57.60°, and 63.29° requires cubic Cu3WO6. The weak but reproducible CuO pair near 35.10° and 38.32°, together with additional higher-angle lines, gives a positive minor CuO scale. No coherent residual reflection family remained after these four phases were included.

Exact-composition frozen references were compared under matched nuisance refinements. COD 4000806 (P-1 CuWO4) decisively outperformed the monoclinic CuWO4 alternative. COD 2311041 gave the best physical monoclinic WO3 model; tetragonal, hexagonal, and orthorhombic WO3 references left whole-family residuals. COD 1527404 supplies the Cu3WO6 topology, and the higher-symmetry C2/c CuO model (COD 1011194) was retained because C2/c and Cc CuO were profile-indistinguishable at this abundance.

The final bounded coordinate polish selected its converged all-coordinate branch. Its geometry audit found no catastrophic contacts and retained all phase fractions. Shortest refined cation–oxygen distances are chemically plausible for these oxides (approximately 1.94 Å Cu–O in CuWO4, 1.70 Å W–O in WO3, 1.90 Å Cu–O in Cu3WO6, and 1.94 Å Cu–O in CuO).

## Fit and uncertainty

Native replay of `final.gpx` over all {len(x)} measured points gives Rwp = {rwp:.3f}% and Rp = {rp:.3f}% with 1/max(Iobs,1) weighting. The background remains positive over the full scan. The required staged coordinate polish selected its physical all-coordinate branch without geometry or phase-fraction audit violations. A subsequent residual check showed that the Cu3WO6 peaks had been over-broadened; correcting that crystallite-size term and allowing supported CuWO4/Cu3WO6 microstrain terms before the final scale/background settle reduced reflection-centered residuals. This profile completion changed the Cu3WO6 estimate by about 1.6 wt% relative to the coordinate-polished checkpoint, which is a useful indication of systematic quantitative uncertainty.

The major-phase inventory is well supported, but the fit remains above the counting-noise floor and residual intensity errors are centered mainly on accepted reflections. Consequently, refined oxygen coordinates and specimen/profile terms should not be interpreted as high-precision crystallography. The approximately 2.4 wt% CuO fraction is the least reliable quantitative value because its peaks overlap the major phases; its presence is supported, but its exact fraction and the C2/c versus Cc distortion cannot be determined reliably from this pattern. The monoclinic WO3 topology is secure, while its exact oxygen positions and choice among closely related monoclinic settings carry residual model uncertainty. No amorphous fraction can be inferred from this crystalline-only normalization.
"""
    (ROOT / "report.md").write_text(report)


if __name__ == "__main__":
    main()
