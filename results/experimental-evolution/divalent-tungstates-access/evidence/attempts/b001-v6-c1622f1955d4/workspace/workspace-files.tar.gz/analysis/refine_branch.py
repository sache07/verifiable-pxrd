#!/usr/bin/env python3
"""Run a controlled GSAS-II branch from an existing physical checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def histogram(project: G2.G2Project):
    return max(project.histograms(), key=lambda h: len(h.data["data"][1][1]))


def clear_flags(project: G2.G2Project) -> None:
    hist = histogram(project)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        for value in hap.get("Babinet", {}).values():
            if isinstance(value, list) and len(value) > 1:
                value[1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def set_bounds(project: G2.G2Project) -> None:
    hist = histogram(project)
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    hid = hist.id
    for phase in project.phases():
        pid = phase.id
        hap = phase.data["Histograms"][hist.name]
        scale = max(float(hap["Scale"][0]), 1.0e-9)
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMax", 5.0 * scale, variable=f"{pid}:{hid}:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:{hid}:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:{hid}:MD")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.006 * abs(float(value)), 0.00015)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
        for index, atom in enumerate(phase.atoms()):
            project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.02, variable=f"{pid}::AUiso:{index}")
    bounds = {
        "Zero": (-0.25, 0.25), "U": (0.0, 40.0), "W": (2.0, 40.0),
        "X": (0.1, 6.0), "SH/L": (0.005, 0.10), "Polariz.": (0.5, 1.0),
    }
    for name, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=f":{hid}:{name}")
        project.set_Controls("parmMax", high, variable=f":{hid}:{name}")
    project.set_Controls("parmMin", -800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMax", 800.0, variable=f":{hid}:Shift")
    project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughA")
    project.set_Controls("parmMax", 0.8, variable=f":{hid}:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughB")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:SurfRoughB")


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = histogram(project)
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(0.0, float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def summarize(project: G2.G2Project, output: Path, mode: str) -> dict:
    hist = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    branch_status = project.data.get("Controls", {}).get("data", {}).get("branch_refinement_status", {})
    result = {
        "mode": mode,
        "project": str(output),
        "rwp": float(hist.get_wR()),
        "gof": None if rvals.get("GOF") is None else float(rvals["GOF"]),
        "converged": bool(branch_status.get("converged", rvals.get("converged", False))),
        "max_shift_esd": branch_status.get("max_shift_esd", None if rvals.get("Max shft/sig") is None else float(rvals["Max shft/sig"])),
        "rwp_before_replay_recalculation": branch_status.get("rwp_before_replay_recalculation"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "zero": float(hist.InstrumentParameters["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in ["U", "V", "W", "X", "SH/L", "Polariz."]},
        "background": [float(v) for v in hist.Background[0][3:]],
        "fractions": mass_fractions(project),
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "preferred_orientation_ratio": float(hap["Pref.Ori."][1]),
            "preferred_orientation_axis": list(hap["Pref.Ori."][3]),
            "uiso": [float(atom.uiso) for atom in phase.atoms()],
        }
    output.with_suffix(".summary.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return result


def configure_common(project: G2.G2Project, scales: bool, background: bool) -> None:
    hist = histogram(project)
    hist.Background[0][1] = background
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = scales


def run(args) -> dict:
    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    hist = histogram(project)
    clear_flags(project)
    # Stabilize specimen terms that were numerically unidentifiable in the broad first pass.
    if project.phase("Cu3WO6") is not None:
        value = project.phase("Cu3WO6").data["Histograms"][hist.name]["Size"][1][0]
        project.phase("Cu3WO6").data["Histograms"][hist.name]["Size"][1][0] = min(1.5, max(0.04, float(value)))
    if project.phase("CuO") is not None:
        value = project.phase("CuO").data["Histograms"][hist.name]["Size"][1][0]
        project.phase("CuO").data["Histograms"][hist.name]["Size"][1][0] = min(1.5, max(0.04, float(value)))
    set_bounds(project)
    configure_common(project, args.scales, args.background)

    if args.fixed_zero is not None:
        hist.InstrumentParameters["Zero"][1] = float(args.fixed_zero)
        hist.InstrumentParameters["Zero"][2] = False
    elif args.refine_zero:
        hist.InstrumentParameters["Zero"][2] = True
    if args.refine_shift:
        hist.SampleParameters["Shift"][1] = True
    if args.refine_cells:
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    if args.instrument:
        for key in args.instrument.split(","):
            hist.InstrumentParameters[key][2] = True
    if args.size:
        for name in args.size.split(","):
            project.phase(name).data["Histograms"][hist.name]["Size"][2][0] = True
    if args.microstrain:
        for name in args.microstrain.split(","):
            project.phase(name).data["Histograms"][hist.name]["Mustrain"][2][0] = True
    if args.po_phase:
        phase = project.phase(args.po_phase)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = [int(v) for v in args.po_axis.split(",")]
    if args.surface_roughness:
        hist.SampleParameters["SurfRoughA"] = [0.2, True]
        hist.SampleParameters["SurfRoughB"] = [0.1, True]
    if args.polarization:
        hist.InstrumentParameters["Polariz."][2] = True
    if args.uiso:
        # The generator assigns one scalar Uiso per phase; enforce that same model.
        project.data["Constraints"]["data"]["Phase"] = [
            c for c in project.data["Constraints"]["data"]["Phase"]
            if not (isinstance(c, list) and any("AUiso" in str(v) for v in c))
        ]
        project.index_ids()
        for name in args.uiso.split(","):
            phase = project.phase(name)
            pid = phase.id
            atoms = phase.atoms()
            values = [float(atom.uiso) for atom in atoms]
            start = min(0.02, max(0.003, values[0])) if values and max(values) - min(values) < 1.0e-8 else 0.005
            for atom in atoms:
                atom.uiso = start
                atom.refinement_flags = "U"
            if len(atoms) > 1:
                project.add_EquivConstr([f"{pid}::AUiso:{i}" for i in range(len(atoms))])

    project.set_Controls("cycles", args.cycles)
    project.save()
    project.refine()
    refinement_rvals = dict(project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}))
    if args.uiso:
        for name in args.uiso.split(","):
            atoms = project.phase(name).atoms()
            common = min(0.02, max(0.003, float(np.median([atom.uiso for atom in atoms]))))
            for atom in atoms:
                atom.uiso = common
    # GSAS-II can retain the last-cycle arrays when a bounded parameter is clipped.
    # Recalculate with every flag off so the saved profile exactly matches the
    # parameter values that a replay will use.
    clear_flags(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.data.setdefault("Controls", {}).setdefault("data", {})["branch_refinement_status"] = {
        "converged": bool(refinement_rvals.get("converged", False)),
        "max_shift_esd": None if refinement_rvals.get("Max shft/sig") is None else float(refinement_rvals["Max shft/sig"]),
        "rwp_before_replay_recalculation": None if refinement_rvals.get("Rwp") is None else float(refinement_rvals["Rwp"]),
    }
    project.save()
    result = summarize(project, args.output.resolve(), args.mode)
    print(json.dumps({k: result[k] for k in ["mode", "project", "rwp", "converged", "max_shift_esd", "zero", "shift_um", "fractions"]}, sort_keys=True))
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--mode", default="branch")
    parser.add_argument("--cycles", type=int, default=12)
    parser.add_argument("--scales", action="store_true")
    parser.add_argument("--background", action="store_true")
    parser.add_argument("--fixed-zero", type=float)
    parser.add_argument("--refine-zero", action="store_true")
    parser.add_argument("--refine-shift", action="store_true")
    parser.add_argument("--refine-cells", action="store_true")
    parser.add_argument("--instrument", help="comma-separated GSAS-II instrument names")
    parser.add_argument("--size", help="comma-separated phase names")
    parser.add_argument("--microstrain", help="comma-separated phase names")
    parser.add_argument("--po-phase")
    parser.add_argument("--po-axis", default="0,0,1")
    parser.add_argument("--surface-roughness", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--uiso", help="comma-separated phase names")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    run(args)


if __name__ == "__main__":
    main()
