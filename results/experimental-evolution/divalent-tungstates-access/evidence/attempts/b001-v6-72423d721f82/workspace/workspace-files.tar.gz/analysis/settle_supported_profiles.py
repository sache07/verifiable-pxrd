#!/usr/bin/env python3
"""Jointly settle retained isotropic and uniaxial profile parameters."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from effect_branch import clear_flags, fractions


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: settle_supported_profiles.py INPUT.gpx OUTPUT.gpx")
    source, output = map(lambda item: Path(item).resolve(), sys.argv[1:])
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    project.index_ids()
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        if hap["Mustrain"][0] == "uniaxial":
            # The equatorial WO3 component is at its physically imposed
            # generator ceiling; retain it and refine only the supported axial
            # contrast to avoid an out-of-bounds trial profile.
            hap["Mustrain"][2] = [False, True, False]
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;a")
            project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        else:
            if float(hap["Mustrain"][1][0]) >= 7999.0:
                # Do not generate an unphysical trial profile beyond the
                # calibrated isotropic ceiling for a broad minor phase.
                hap["Mustrain"][2] = [False, False, False]
            else:
                hap["Mustrain"][2] = [True, False, False]
                project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
                project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("cycles", 24)
    project.save()
    project.refine(makeBack=False)
    clear_flags(project)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(json.dumps({
        "output": str(output),
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(rvals["GOF"]),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "fractions": fractions(project),
        "profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "mustrain_type": phase.data["Histograms"][hist.name]["Mustrain"][0],
                "equatorial_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "axial_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][1]),
            }
            for phase in project.phases()
        },
    }))


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
