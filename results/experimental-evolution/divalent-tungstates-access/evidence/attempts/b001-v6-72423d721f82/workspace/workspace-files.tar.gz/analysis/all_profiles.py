#!/usr/bin/env python3
"""Jointly settle all ordinary isotropic phase-profile terms."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from effect_branch import clear_flags, fractions


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: all_profiles.py INPUT.gpx OUTPUT.gpx")
    source, output = map(lambda item: Path(item).resolve(), sys.argv[1:])
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    project.index_ids()
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = min(float(hap["Mustrain"][1][0]), 7900.0)
        hap["Mustrain"][1][1] = hap["Mustrain"][1][0]
        hap["Mustrain"][2] = [True, False, False]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("cycles", 20)
    project.save()
    project.refine(makeBack=False)
    clear_flags(project)
    project.save()
    arrays = hist.data["data"][1]
    if len(arrays[0]) != 8301:
        raise RuntimeError(f"histogram truncated to {len(arrays[0])} points")
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(json.dumps({
        "output": str(output),
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(rvals["GOF"]),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "fractions": fractions(project),
        "profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "microstrain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
            }
            for phase in project.phases()
        },
    }))


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
