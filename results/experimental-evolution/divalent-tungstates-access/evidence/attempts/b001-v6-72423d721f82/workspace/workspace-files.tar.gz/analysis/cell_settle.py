#!/usr/bin/env python3
"""Jointly settle all phase cells with scales and background."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from effect_branch import clear_flags, fractions


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: cell_settle.py INPUT.gpx OUTPUT.gpx")
    source, output = map(lambda item: Path(item).resolve(), sys.argv[1:])
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})
    project.set_Controls("cycles", 20)
    project.save()
    project.refine(makeBack=False)
    clear_flags(project)
    project.save()
    if len(hist.data["data"][1][0]) != 8301:
        raise RuntimeError("histogram grid changed")
    for phase in project.phases():
        if phase.ShortDistances(useAll=False):
            raise RuntimeError(f"catastrophic contact in {phase.name}")
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(json.dumps({
        "output": str(output),
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(rvals["GOF"]),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "fractions": fractions(project),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
    }))


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
