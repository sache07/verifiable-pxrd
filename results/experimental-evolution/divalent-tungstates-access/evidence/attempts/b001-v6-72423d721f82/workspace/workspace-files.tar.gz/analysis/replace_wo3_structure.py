#!/usr/bin/env python3
"""Replace only the WO3 atomic model with the physical neutron reference."""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
REFERENCE = ROOT / "analysis" / "WO3_P21c_physical_neutron.cif"


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: replace_wo3_structure.py INPUT.gpx OUTPUT.gpx")
    source, output = map(lambda item: Path(item).resolve(), sys.argv[1:])

    template_project = G2.G2Project(newgpx=str(ROOT / "analysis" / "_wo3_template.gpx"))
    template = template_project.add_phase(
        str(REFERENCE), phasename="WO3_template", fmthint="CIF"
    )
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    matches = [phase for phase in project.phases() if phase.name == "WO3_monoclinic"]
    if len(matches) != 1:
        raise RuntimeError(f"expected one WO3 phase, found {len(matches)}")
    target = matches[0]

    old_cell = deepcopy(target.data["General"]["Cell"])
    old_histograms = target.data["Histograms"]
    old_pid = target.data["pId"]
    old_ranid = target.data["ranId"]

    target.data["General"] = deepcopy(template.data["General"])
    target.data["General"]["Name"] = "WO3_monoclinic"
    # The setting is the same near-orthogonal P21/n setting; retain the
    # already indexed specimen metric while replacing only local geometry.
    target.data["General"]["Cell"] = old_cell
    target.data["Atoms"] = deepcopy(template.data["Atoms"])
    target.data["Drawing"] = deepcopy(template.data["Drawing"])
    target.data["Histograms"] = old_histograms
    target.data["pId"] = old_pid
    target.data["ranId"] = old_ranid

    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    project.save()
    print(
        {
            "output": str(output),
            "cell": target.get_cell(),
            "atoms": [
                (atom.label, atom.element, tuple(float(v) for v in atom.coordinates))
                for atom in target.atoms()
            ],
            "short_distances": target.ShortDistances(useAll=False),
        }
    )


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
