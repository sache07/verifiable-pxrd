#!/usr/bin/env python3
"""Physically bounded GSAS-II inventory screening for the Mn-W-O specimen."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)


def cod(record: str) -> Path:
    return LIB / record[0] / record[1:3] / record[3:5] / f"{record}.cif"


PHASES = {
    "mnwo4": ("MnWO4_wolframite", cod("1520200"), 150.0),
    "mn2wo6": (
        "Mn2WO6_Pbcn",
        ROOT / "analysis" / "Mn2WO6_Pbcn_analogue.cif",
        6.0,
    ),
    "mn3wo6": (
        "Mn3WO6_R-3",
        ROOT / "analysis" / "Mn3WO6_R-3_analogue.cif",
        15.0,
    ),
    "wo3": ("WO3_monoclinic", cod("1528915"), 4.0),
    "mn3o4": ("Mn3O4_hausmannite", cod("9001963"), 4.0),
    "mno": ("MnO_rocksalt", cod("1514108"), 4.0),
    "mn2o3": ("Mn2O3_bixbyite", cod("1010586"), 4.0),
}


def make_xye() -> Path:
    source = ROOT / "inputs" / "pattern.csv"
    output = ROOT / "analysis" / "pattern.xye"
    with source.open(newline="") as inp, output.open("w") as out:
        for row in csv.DictReader(inp):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            out.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return output


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    try:
        values = hist.ComputeMassFracs()
    except Exception:
        values = {}
    if values:
        return {str(name): float(value[0]) for name, value in values.items()}
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    return {key: value / total for key, value in weighted.items()}


def clear_structural_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}, [hist]
        )


def report(project: G2.G2Project, stage: str) -> None:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    result = {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "fractions": fractions(project),
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
        },
        "sample": {
            key: float(value[0])
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
            and isinstance(value, list)
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size_um": float(
                    phase.data["Histograms"][hist.name]["Size"][1][0]
                ),
                "microstrain_ppm": float(
                    phase.data["Histograms"][hist.name]["Mustrain"][1][0]
                ),
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(result, default=float), flush=True)


def run(project: G2.G2Project, stage: str, cycles: int = 5) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    report(project, stage)


def bounds(project: G2.G2Project) -> None:
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    for name, lower, upper in (
        ("Zero", -0.25, 0.25),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
        ("Shift", -800.0, 800.0),
    ):
        project.set_Controls("parmMin", lower, variable=f":0:{name}")
        project.set_Controls("parmMax", upper, variable=f":0:{name}")


def build(output: Path, inventory: list[str]) -> G2.G2Project:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(make_xye()),
        str(ROOT / "analysis" / "instrument.instprm"),
        fmthint="xye",
    )
    hist.set_refinements({"Limits": [10.0, 100.05]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-600.0, False]
    for key in inventory:
        name, path, start_scale = PHASES[key]
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [start_scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1800.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    project.save()
    bounds(project)
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--inventory",
        default="mnwo4,mn2wo6",
        help="comma-separated keys: " + ",".join(PHASES),
    )
    args = parser.parse_args()
    inventory = [item.strip() for item in args.inventory.split(",") if item.strip()]
    if not inventory or any(item not in PHASES for item in inventory):
        raise SystemExit(f"invalid inventory {inventory}")
    project = build(args.output.resolve(), inventory)
    hist = project.histogram(0)
    run(project, "background_scales", 6)

    # Shift=-600 um already reproduces the common angle-dependent displacement.
    # Keep it fixed while each lattice is placed, avoiding zero/cell/height drift.
    for phase in project.phases():
        clear_structural_flags(project)
        phase.set_refinements({"Cell": True})
        run(project, f"cell_{phase.name}", 6)
    clear_structural_flags(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "all_cells", 5)

    # Fit phase broadening against a fixed, physical instrument checkpoint.
    clear_structural_flags(project)
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    run(project, "microstrain", 6)
    clear_structural_flags(project)
    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.30, "refine": True}},
            [hist],
        )
    run(project, "size", 6)

    # Then let the Gaussian instrument terms and axial divergence settle.
    clear_structural_flags(project)
    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "SH/L", "Polariz."]}
    )
    run(project, "instrument_polarization", 6)

    # Refine the bounded angular zero with specimen height held fixed.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "zero", 5)
    clear_structural_flags(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "cell_settle", 6)


if __name__ == "__main__":
    main()
