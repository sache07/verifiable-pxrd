#!/usr/bin/env python3
"""Test one bounded specimen effect from a common full-grid checkpoint."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    values = hist.ComputeMassFracs()
    return {str(name): float(value[0]) for name, value in values.items()}


def main() -> None:
    if len(sys.argv) not in (4, 6):
        raise SystemExit(
            "usage: effect_branch.py INPUT.gpx OUTPUT.gpx none | "
            "effect_branch.py INPUT.gpx OUTPUT.gpx "
            "{md,mustrain,mustrain_axial,iso_mustrain,iso_size} PHASE AXIS"
        )
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    effect = sys.argv[3]
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    project.index_ids()
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True

    tested = None
    if effect != "none":
        phase_index = int(sys.argv[4])
        axis = [int(item) for item in sys.argv[5].split(",")]
        if len(axis) != 3:
            raise ValueError(f"invalid axis: {axis}")
        phase = project.phases()[phase_index]
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        if effect == "md":
            hap["Pref.Ori."][0] = "MD"
            current_ratio = float(hap["Pref.Ori."][1])
            hap["Pref.Ori."][1] = (
                current_ratio if 0.7 <= current_ratio <= 1.4 else 1.0
            )
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        elif effect == "mustrain":
            was_uniaxial = hap["Mustrain"][0] == "uniaxial"
            value = float(hap["Mustrain"][1][0])
            # Move an exactly clipped isotropic starting value just inside its
            # permitted interval so that both uniaxial components can move.
            value = min(value, 7900.0)
            hap["Mustrain"][0] = "uniaxial"
            hap["Mustrain"][1][0] = value
            if not was_uniaxial:
                hap["Mustrain"][1][1] = value
            hap["Mustrain"][2] = [True, True, False]
            hap["Mustrain"][3] = axis
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;a")
            project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        elif effect == "mustrain_axial":
            if hap["Mustrain"][0] != "uniaxial":
                raise ValueError("mustrain_axial requires an existing uniaxial model")
            hap["Mustrain"][2] = [False, True, False]
            hap["Mustrain"][3] = axis
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;a")
            project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        elif effect == "iso_mustrain":
            value = min(float(hap["Mustrain"][1][0]), 7900.0)
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = value
            hap["Mustrain"][1][1] = value
            hap["Mustrain"][2] = [True, False, False]
            project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        elif effect == "iso_size":
            hap["Size"][0] = "isotropic"
            hap["Size"][2] = [True, False, False]
            project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        else:
            raise ValueError(f"unknown effect: {effect}")
        tested = {"phase_index": phase_index, "phase": phase.name, "axis": axis}

    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    clear_flags(project)
    project.save()

    arrays = hist.data["data"][1]
    if len(arrays[0]) != 8301:
        raise RuntimeError(f"histogram truncated to {len(arrays[0])} points")
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    details = {}
    if tested:
        phase = project.phases()[tested["phase_index"]]
        hap = phase.data["Histograms"][hist.name]
        if effect == "md":
            details = {"md_ratio": float(hap["Pref.Ori."][1])}
        elif effect in {"mustrain", "mustrain_axial"}:
            details = {
                "equatorial_ppm": float(hap["Mustrain"][1][0]),
                "axial_ppm": float(hap["Mustrain"][1][1]),
            }
        elif effect == "iso_mustrain":
            details = {"isotropic_ppm": float(hap["Mustrain"][1][0])}
        elif effect == "iso_size":
            details = {"isotropic_size_um": float(hap["Size"][1][0])}
    print(
        json.dumps(
            {
                "output": str(output),
                "effect": effect,
                "tested": tested,
                "Rwp_percent": float(hist.get_wR()),
                "GOF": float(rvals.get("GOF", float("nan"))),
                "converged": bool(rvals.get("converged", False)),
                "max_shift_esd": rvals.get("Max shft/sig"),
                "frozen": [str(item) for item in project.get_Frozen()],
                "fractions": fractions(project),
                **details,
            },
            allow_nan=False,
        )
    )


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
