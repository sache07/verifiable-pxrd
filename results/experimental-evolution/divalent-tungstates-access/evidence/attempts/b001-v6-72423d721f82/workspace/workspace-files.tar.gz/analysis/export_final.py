#!/usr/bin/env python3
"""Export all public deliverables from the exact submitted GSAS-II project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
CIF_NAMES = {
    "Mn3WO6_R-3": "Mn3WO6_R-3.cif",
    "MnWO4_wolframite": "MnWO4_wolframite.cif",
    "WO3_monoclinic": "WO3_monoclinic.cif",
}


def main() -> None:
    project = G2.G2Project(str(ROOT / "final.gpx"))
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    x, observed, weight, calculated, background, difference = [
        np.asarray(item, dtype=float) for item in arrays
    ]
    if len(x) != 8301 or not np.allclose(difference, observed - calculated):
        raise RuntimeError("saved full-grid profile is incomplete or inconsistent")
    if np.any(calculated < 0) or np.any(background < 0):
        raise RuntimeError("negative calculated intensity or background")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.10g", "%.10g", "%.10g"),
    )

    fractions = {
        str(name): (float(value[0]), float(value[1]))
        for name, value in hist.ComputeMassFracs().items()
    }
    phase_records = []
    for phase in project.phases():
        filename = CIF_NAMES[phase.name]
        phase.export_CIF(str(ROOT / filename))
        hap = phase.data["Histograms"][hist.name]
        phase_records.append(
            {
                "name": phase.name,
                "cif": filename,
                "weight_fraction": fractions[phase.name][0],
                "weight_fraction_esd": fractions[phase.name][1],
                "cell": phase.get_cell(),
                "size_um": float(hap["Size"][1][0]),
                "microstrain_type": hap["Mustrain"][0],
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "short_distances": phase.ShortDistances(useAll=False),
            }
        )

    rvals = project.data["Covariance"]["data"]["Rvals"]
    direct_rwp = 100.0 * np.sqrt(
        np.sum(weight * (observed - calculated) ** 2)
        / np.sum(weight * observed**2)
    )
    direct_rp = 100.0 * np.sum(np.abs(observed - calculated)) / np.sum(observed)
    summary = {
        "histogram": hist.name,
        "points": len(x),
        "limits_deg": [float(x[0]), float(x[-1])],
        "Rwp_percent": float(rvals["Rwp"]),
        "Rwp_direct_percent": float(direct_rwp),
        "Rp_percent": float(direct_rp),
        "GOF": float(rvals["GOF"]),
        "chi_squared": float(rvals["chisq"]),
        "N_observations": int(rvals["Nobs"]),
        "N_variables": int(rvals["Nvars"]),
        "converged": bool(rvals["converged"]),
        "max_shift_esd": float(rvals["Max shft/sig"]),
        "frozen": [str(item) for item in project.get_Frozen()],
        "background_min": float(np.min(background)),
        "calculated_min": float(np.min(calculated)),
        "instrument": {
            key: float(hist.InstrumentParameters[key][1])
            for key in ("Zero", "Polariz.", "U", "W", "X", "SH/L")
        },
        "sample_shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": phase_records,
    }
    (ROOT / "analysis" / "final_summary.json").write_text(
        json.dumps(summary, indent=2, default=float) + "\n"
    )
    print(json.dumps(summary, indent=2, default=float))


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
