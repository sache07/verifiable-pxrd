#!/usr/bin/env python3
"""Settle selected bounded instrument/specimen terms on a fixed phase model."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from effect_branch import clear_flags, fractions


BOUNDS = {
    "Zero": (-0.25, 0.25),
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.1, 6.0),
    "SH/L": (0.005, 0.10),
    "Polariz.": (0.5, 1.0),
    "Shift": (-800.0, 800.0),
}


def main() -> None:
    if len(sys.argv) != 4:
        raise SystemExit(
            "usage: instrument_branch.py INPUT.gpx OUTPUT.gpx PARAM[,PARAM...]"
        )
    source, output = map(lambda item: Path(item).resolve(), sys.argv[1:3])
    parameters = sys.argv[3].split(",")
    unknown = set(parameters) - set(BOUNDS)
    if unknown:
        raise ValueError(f"unknown parameter(s): {sorted(unknown)}")
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    instrument = [item for item in parameters if item != "Shift"]
    if instrument:
        hist.set_refinements({"Instrument Parameters": instrument})
    if "Shift" in parameters:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    for name in parameters:
        lower, upper = BOUNDS[name]
        project.set_Controls("parmMin", lower, variable=f":0:{name}")
        project.set_Controls("parmMax", upper, variable=f":0:{name}")
    project.set_Controls("cycles", 20)
    project.save()
    project.refine(makeBack=False)
    clear_flags(project)
    project.save()
    arrays = hist.data["data"][1]
    if len(arrays[0]) != 8301:
        raise RuntimeError(f"histogram truncated to {len(arrays[0])} points")
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    values = {}
    for name in parameters:
        if name == "Shift":
            values[name] = float(hist.SampleParameters[name][0])
        else:
            values[name] = float(hist.InstrumentParameters[name][1])
    print(json.dumps({
        "output": str(output),
        "parameters": parameters,
        "values": values,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(rvals["GOF"]),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "fractions": fractions(project),
    }))


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
