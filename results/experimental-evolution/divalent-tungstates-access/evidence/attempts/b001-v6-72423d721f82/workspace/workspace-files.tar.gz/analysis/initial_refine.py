#!/usr/bin/env python3
"""Build exploratory GSAS-II fits for the ordinary Mn-W-O inventory."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
MNWO4 = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif/1/52/02/1520200.cif"
)
MN2WO6 = ROOT / "analysis" / "Mn2WO6_Pbcn_analogue.cif"


def make_xye() -> Path:
    source = ROOT / "inputs" / "pattern.csv"
    output = ROOT / "analysis" / "pattern.xye"
    with source.open(newline="") as inp, output.open("w") as out:
        for row in csv.DictReader(inp):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            out.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return output


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    try:
        values = hist.ComputeMassFracs()
        if values:
            return {str(k): float(v[0]) for k, v in values.items()}
    except Exception:
        pass
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    return {k: v / total for k, v in weighted.items()} if total else weighted


def state(project: G2.G2Project, stage: str) -> None:
    hist = project.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    payload = {
        "stage": stage,
        "Rwp": hist.get_wR(),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "fractions": mass_fractions(project),
        "instrument": {
            key: value[1]
            for key, value in inst.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
        },
        "sample": {
            key: value[0] if isinstance(value, list) else value
            for key, value in sample.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": phase.data["Histograms"][hist.name]["Scale"][0],
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
            }
            for phase in project.phases()
        },
    }
    print(json.dumps(payload, default=float), flush=True)


def run(project: G2.G2Project, stage: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()
    project.refine(makeBack=False)
    project.save()
    state(project, stage)


def build(output: Path, two_phase: bool) -> G2.G2Project:
    G2.SetPrintLevel("warn")
    xye = make_xye()
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(xye), str(ROOT / "analysis" / "instrument.instprm"), fmthint="xye"
    )
    hist.set_refinements({"Limits": [10.0, 100.05]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    # The common positive peak displacement is initially represented by a
    # physically plausible negative specimen-height shift at R=200 mm.
    hist.SampleParameters["Shift"] = [-600.0, False]
    phase_specs = [("MnWO4_wolframite", MNWO4)]
    if two_phase:
        phase_specs.append(("Mn2WO6_Pbcn", MN2WO6))
    phases = []
    for name, path in phase_specs:
        phase = project.add_phase(
            str(path), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        phases.append(phase)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1800.0] + [0.0] * 9,
                "refine": True,
            }
        }
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    project.save()
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    project.set_Controls("parmMin", -1.0, variable=":0:Zero")
    project.set_Controls("parmMax", 1.0, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for name, lower, upper in (
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
    ):
        project.set_Controls("parmMin", lower, variable=f":0:{name}")
        project.set_Controls("parmMax", upper, variable=f":0:{name}")
    return project


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("--one-phase", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    project = build(output, not args.one_phase)
    run(project, "background_scales", 12)
    project.histogram(0).set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "specimen_shift", 10)
    project.histogram(0).set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "zero", 10)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "cells", 12)
    project.histogram(0).set_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
    )
    run(project, "instrument", 12)
    for phase in project.phases():
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.3, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run(project, "profiles", 12)


if __name__ == "__main__":
    main()
