#!/usr/bin/env python3
"""Build a bounded, full-grid Mn3WO6 + MnWO4 GSAS-II checkpoint."""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
LIB = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
OUTPUT = ROOT / "analysis" / "checkpoint.gpx"


def make_xye() -> Path:
    output = ROOT / "analysis" / "pattern.xye"
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as inp, output.open(
        "w"
    ) as out:
        for row in csv.DictReader(inp):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            out.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")
    return output


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histogram(0)
    try:
        values = hist.ComputeMassFracs()
    except Exception:
        values = {}
    if values:
        return {str(name): float(value[0]) for name, value in values.items()}
    weighted = {
        phase.name: max(
            0.0,
            float(phase.data["General"]["Mass"])
            * float(phase.data["Histograms"][hist.name]["Scale"][0]),
        )
        for phase in project.phases()
    }
    total = sum(weighted.values())
    return {name: value / total for name, value in weighted.items()}


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def validate(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    arrays = hist.data["data"][1]
    if len(arrays[0]) != 8301:
        raise RuntimeError(f"histogram truncated to {len(arrays[0])} points")
    if abs(float(arrays[0][0]) - 9.90343322) > 1e-7:
        raise RuntimeError("histogram low-angle grid changed")
    if abs(float(arrays[0][-1]) - 100.09455322) > 1e-7:
        raise RuntimeError("histogram high-angle grid changed")
    for phase in project.phases():
        cell = phase.get_cell()
        if min(cell["length_a"], cell["length_b"], cell["length_c"], cell["volume"]) <= 0:
            raise RuntimeError(f"invalid cell for {phase.name}: {cell}")
        if phase.ShortDistances(useAll=False):
            raise RuntimeError(
                f"catastrophic contact in {phase.name}: {phase.ShortDistances(useAll=False)}"
            )


def summary(project: G2.G2Project, stage: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "stage": stage,
        "n_points": len(hist.data["data"][1][0]),
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": mass_fractions(project),
        "instrument": {
            key: float(value[1])
            for key, value in hist.InstrumentParameters.items()
            if key in {"Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."}
        },
        "sample": {
            key: float(value[0])
            for key, value in hist.SampleParameters.items()
            if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB"}
            and isinstance(value, list)
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size_um": float(
                    phase.data["Histograms"][hist.name]["Size"][1][0]
                ),
                "microstrain_ppm": float(
                    phase.data["Histograms"][hist.name]["Mustrain"][1][0]
                ),
            }
            for phase in project.phases()
        },
    }


def run(project: G2.G2Project, stage: str, cycles: int = 5) -> None:
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    validate(project)
    record = summary(project, stage)
    print(json.dumps(record, default=float), flush=True)
    shutil.copy2(project.filename, ROOT / "analysis" / f"checkpoint_{stage}.gpx")


def install_bounds(project: G2.G2Project) -> None:
    project.index_ids()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 5000.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A(
            [
                cell["length_a"],
                cell["length_b"],
                cell["length_c"],
                cell["angle_alpha"],
                cell["angle_beta"],
                cell["angle_gamma"],
            ]
        )
        for index, value in enumerate(reciprocal):
            value = float(value)
            span = max(0.04 * abs(value), 0.001)
            project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
    for name, lower, upper in (
        ("Zero", -0.25, 0.25),
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
        ("Shift", -800.0, 800.0),
    ):
        project.set_Controls("parmMin", lower, variable=f":0:{name}")
        project.set_Controls("parmMax", upper, variable=f":0:{name}")


def build() -> G2.G2Project:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(OUTPUT))
    hist = project.add_powder_histogram(
        str(make_xye()),
        str(ROOT / "analysis" / "instrument.instprm"),
        fmthint="xye",
    )
    hist.set_refinements({"Limits": [10.0, 100.05]})
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [-600.0, False]
    inst = hist.InstrumentParameters
    inst["U"][1] = 20.0
    inst["W"][1] = 30.0
    inst["X"][1] = 1.0
    inst["SH/L"][1] = 0.03
    principal = project.add_phase(
        str(ROOT / "analysis" / "Mn3WO6_R-3_analogue.cif"),
        phasename="Mn3WO6_R-3",
        histograms=[hist],
        fmthint="CIF",
    )
    minor = project.add_phase(
        str(LIB / "1/52/02/1520200.cif"),
        phasename="MnWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )
    for phase, scale, strain in ((principal, 800.0, 1000.0), (minor, 100.0, 3000.0)):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1800.0] + [0.0] * 11,
                "refine": True,
            }
        }
    )
    project.save()
    install_bounds(project)
    validate(project)
    return project


def main() -> None:
    project = build()
    hist = project.histogram(0)
    phases = project.phases()
    run(project, "scales_background", 8)

    clear_flags(project)
    phases[0].set_refinements({"Cell": True})
    run(project, "principal_cell", 6)
    clear_flags(project)
    phases[1].set_refinements({"Cell": True})
    run(project, "minor_cell", 6)

    clear_flags(project)
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "shift", 5)
    clear_flags(project)
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "zero", 5)
    clear_flags(project)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run(project, "cells_settle", 6)

    clear_flags(project)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    run(project, "instrument", 6)
    for index, phase in enumerate(phases):
        clear_flags(project)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
        run(project, f"strain_{index}", 6)
    for index, phase in enumerate(phases):
        clear_flags(project)
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
        run(project, f"size_{index}", 6)

    clear_flags(project)
    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "SH/L", "Polariz."]}
    )
    for phase in phases:
        phase.set_refinements({"Cell": True})
    run(project, "ordinary_settle", 8)
    clear_flags(project)
    project.save()
    validate(project)
    shutil.copy2(project.filename, ROOT / "analysis" / "physical_checkpoint.gpx")


if __name__ == "__main__":
    main()
