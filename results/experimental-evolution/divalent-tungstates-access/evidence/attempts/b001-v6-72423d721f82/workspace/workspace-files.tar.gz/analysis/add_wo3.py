#!/usr/bin/env python3
"""Add independently indexed monoclinic WO3 to the physical checkpoint."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "physical_checkpoint.gpx"
OUTPUT = ROOT / "analysis" / "three_phase_checkpoint.gpx"
WO3 = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif/1/52/89/1528915.cif"
)


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project: G2.G2Project) -> dict[str, float]:
    values = project.histogram(0).ComputeMassFracs()
    return {str(name): float(value[0]) for name, value in values.items()}


def validate(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    x = hist.data["data"][1][0]
    if len(x) != 8301 or abs(float(x[-1]) - 100.09455322) > 1e-7:
        raise RuntimeError(f"histogram grid corrupted: n={len(x)}, max={x[-1]}")
    for phase in project.phases():
        if phase.ShortDistances(useAll=False):
            raise RuntimeError(f"catastrophic contacts in {phase.name}")


def run(project: G2.G2Project, stage: str, cycles: int = 6) -> None:
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    validate(project)
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp_percent": hist.get_wR(),
                "converged": rvals.get("converged"),
                "max_shift_esd": rvals.get("Max shft/sig"),
                "frozen": project.get_Frozen(),
                "fractions": fractions(project),
                "cells": {p.name: p.get_cell() for p in project.phases()},
                "profiles": {
                    p.name: {
                        "size": p.data["Histograms"][hist.name]["Size"][1][0],
                        "strain": p.data["Histograms"][hist.name]["Mustrain"][1][0],
                    }
                    for p in project.phases()
                },
            },
            default=float,
        ),
        flush=True,
    )
    shutil.copy2(project.filename, ROOT / "analysis" / f"three_{stage}.gpx")


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    hist = project.histogram(0)
    clear_flags(project)
    phase = project.add_phase(
        str(WO3), phasename="WO3_monoclinic", histograms=[hist], fmthint="CIF"
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [10.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 5000.0
    project.save()
    project.index_ids()
    pid = int(phase.data["pId"])
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
    project.set_Controls("parmMax", 5000.0, variable=f"{pid}:0:Scale")
    project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    cell = phase.get_cell()
    reciprocal = G2lat.cell2A(
        [
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ]
    )
    for index, value in enumerate(reciprocal):
        value = float(value)
        span = max(0.03 * abs(value), 0.001)
        project.set_Controls("parmMin", value - span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMax", value + span, variable=f"{pid}::A{index}")
    validate(project)

    run(project, "scales", 8)
    clear_flags(project)
    phase.set_refinements({"Cell": True})
    run(project, "wo3_cell", 6)
    clear_flags(project)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
    )
    run(project, "wo3_strain", 6)
    clear_flags(project)
    phase.set_HAP_refinements(
        {"Size": {"type": "isotropic", "refine": True}}, [hist]
    )
    run(project, "wo3_size", 6)

    clear_flags(project)
    for item in project.phases():
        item.set_refinements({"Cell": True})
    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "SH/L", "Polariz."]}
    )
    run(project, "settle", 8)
    clear_flags(project)
    project.save()
    validate(project)


if __name__ == "__main__":
    main()
