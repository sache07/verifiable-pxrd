#!/usr/bin/env python3
"""Jointly settle preselected non-unity March-Dollase terms."""

from __future__ import annotations

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

from effect_branch import clear_flags, fractions


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("usage: settle_existing_md.py INPUT.gpx OUTPUT.gpx")
    source, output = map(lambda item: Path(item).resolve(), sys.argv[1:])
    project = G2.G2Project(gpxfile=str(source), newgpx=str(output))
    clear_flags(project)
    project.index_ids()
    hist = project.histogram(0)
    hist.Background[0][1] = True
    selected = []
    for phase in project.phases():
        pid = int(phase.data["pId"])
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        ratio = float(hap["Pref.Ori."][1])
        if abs(ratio - 1.0) < 0.02:
            continue
        hap["Pref.Ori."][2] = True
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        selected.append(phase.name)
    if not selected:
        raise RuntimeError("no non-unity March-Dollase terms selected")
    project.set_Controls("cycles", 20)
    project.save()
    project.refine(makeBack=False)
    clear_flags(project)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    print(json.dumps({
        "output": str(output),
        "selected": selected,
        "Rwp_percent": float(hist.get_wR()),
        "GOF": float(rvals["GOF"]),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in project.get_Frozen()],
        "fractions": fractions(project),
        "md": {
            phase.name: {
                "ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "axis": phase.data["Histograms"][hist.name]["Pref.Ori."][3],
            }
            for phase in project.phases()
            if abs(float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]) - 1.0) >= 0.02
        },
    }))


if __name__ == "__main__":
    G2.SetPrintLevel("error")
    main()
