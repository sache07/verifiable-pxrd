#!/usr/bin/env python3
"""Evaluate one fixed Mn2WO5 isotropic size/strain checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project):
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--size", type=float, required=True)
    parser.add_argument("--strain", type=float, required=True)
    parser.add_argument("--axial-strain", type=float)
    parser.add_argument("--axis", nargs=3, type=int, default=[0, 0, 1])
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    clear_flags(project)
    hist = project.histogram(0)
    phase = project.phases()[2]
    hap = phase.data["Histograms"][hist.name]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size
    hap["Size"][1][1] = args.size
    hap["Mustrain"][0] = "uniaxial" if args.axial_strain is not None else "isotropic"
    hap["Mustrain"][1][0] = args.strain
    hap["Mustrain"][1][1] = args.strain if args.axial_strain is None else args.axial_strain
    hap["Mustrain"][3] = list(args.axis)
    project.set_Controls("cycles", 10)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "size_um": args.size,
        "microstrain_ppm": args.strain,
        "axial_microstrain_ppm": args.strain if args.axial_strain is None else args.axial_strain,
        "microstrain_axis": list(args.axis),
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "candidate_scale": float(hap["Scale"][0]),
        "fractions": {
            str(name): float(value[0])
            for name, value in hist.ComputeMassFracs().items()
        },
    }
    output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
