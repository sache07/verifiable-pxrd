#!/usr/bin/env python3
"""Revisit bounded coordinates after the accepted profile model is in place."""

from __future__ import annotations

import json
from pathlib import Path
import re
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIstrMain as G2st


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
SOURCE = WORK / "uiso_selected.gpx"
OUTPUT = WORK / "preterminal_coordinates.gpx"
AUDIT = WORK / "preterminal_coordinates.json"
COORD_RE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def hist(project):
    return project.histogram(0)


def clear_flags(project):
    h = hist(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_scales_background(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True


def coordinates(project):
    return {
        (int(phase.data["pId"]), index): tuple(float(v) for v in atom.coordinates)
        for phase in project.phases()
        for index, atom in enumerate(phase.atoms())
    }


def install_bounds(project, source):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    h = hist(project)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        scale = float(phase.data["Histograms"][h.name]["Scale"][0])
        project.set_Controls("parmMin", 0.25 * scale, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 5.0 * scale, variable=f"{pid}:0:Scale")
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.005 * abs(float(value)), 0.0002)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", source[(pid, index)], lengths):
                half = 0.08 / float(length)
                project.set_Controls("parmMin", value - half, variable=f"{pid}::dA{axis}:{index}")
                project.set_Controls("parmMax", value + half, variable=f"{pid}::dA{axis}:{index}")


def mass_fractions(project):
    return {str(k): float(v[0]) for k, v in hist(project).ComputeMassFracs().items()}


def state(project, label):
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    item = {
        "stage": label,
        "Rwp_percent": float(hist(project).get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": mass_fractions(project),
    }
    print(json.dumps(item), flush=True)
    return item


def run(project, label, records, cycles=8):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = state(project, label)
    records.append(record)
    return record


def frozen_atoms(record):
    result = set()
    for variable in record["frozen"]:
        match = COORD_RE.match(str(variable))
        if match:
            result.add((int(match.group(1)), int(match.group(2))))
    return result


def activate(project, selected):
    for phase in project.phases():
        pid = int(phase.data["pId"])
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "X" if (pid, index) in selected else " "


def reload(path):
    project = G2.G2Project(gpxfile=str(path), newgpx=str(OUTPUT))
    clear_flags(project)
    return project


def refine_group(project, label, selected, excluded, source, records):
    selected = set(selected) - excluded
    if not selected:
        return project, excluded
    checkpoint = WORK / f".{label}_pre.gpx"
    clear_flags(project)
    enable_scales_background(project)
    activate(project, selected)
    project.save()
    shutil.copy2(OUTPUT, checkpoint)
    starting_rwp = float(hist(project).get_wR())
    last = None
    for pass_index in range(6):
        last = run(project, f"{label}_{pass_index + 1}", records, cycles=8)
        hits = frozen_atoms(last)
        if hits:
            excluded.update(hits)
            selected -= hits
            for phase in project.phases():
                pid = int(phase.data["pId"])
                for index, atom in enumerate(phase.atoms()):
                    key = (pid, index)
                    if key in hits:
                        atom.coordinates = source[key]
            clear_flags(project)
            enable_scales_background(project)
            activate(project, selected)
            if not selected:
                break
            continue
        maximum = last["max_shift_esd"]
        if last["converged"] and maximum is not None and float(maximum) <= 1.0:
            break
    if (
        last is None
        or last["frozen"]
        or not last["converged"]
        or last["max_shift_esd"] is None
        or float(last["max_shift_esd"]) > 1.0
        or float(hist(project).get_wR()) > starting_rwp + 0.005
    ):
        records.append({"stage": label + "_rollback", "reason": "unstable coordinate group"})
        excluded.update(selected)
        project = reload(checkpoint)
    return project, excluded


def geometry(project):
    result = {}
    for phase in project.phases():
        controls, data = phase.InitDisAgl(False)
        controls["Factors"] = [1.25, 0.0]
        _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
        atoms = phase.atoms()
        pair_min = {}
        for center, rows in distances.items():
            for row in rows:
                other = int(row[0])
                pair = "-".join(sorted((atoms[center].element, atoms[other].element)))
                distance = float(row[-2])
                pair_min[pair] = min(pair_min.get(pair, distance), distance)
        result[phase.name] = {
            "pair_min_A": pair_min,
            "catastrophic_contacts": [list(item) for item in phase.ShortDistances(useAll=False)],
        }
    return result


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    clear_flags(project)
    source = coordinates(project)
    install_bounds(project, source)
    records = [state(project, "source")]
    excluded = set()

    for phase in project.phases():
        pid = int(phase.data["pId"])
        heavy = {
            (pid, index) for index, atom in enumerate(phase.atoms())
            if atom.element.strip().upper() not in {"O", "O-2"}
        }
        oxygen = {
            (pid, index) for index, atom in enumerate(phase.atoms())
            if atom.element.strip().upper() in {"O", "O-2"}
        }
        project, excluded = refine_group(project, f"phase_{pid}_heavy", heavy, excluded, source, records)
        project, excluded = refine_group(project, f"phase_{pid}_oxygen", oxygen, excluded, source, records)

    project, excluded = refine_group(
        project, "joint_coordinates", set(source) - excluded, excluded, source, records
    )

    clear_flags(project)
    enable_scales_background(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    settle = run(project, "cell_scale_background_settle_1", records, cycles=10)
    if settle["max_shift_esd"] is None or float(settle["max_shift_esd"]) > 1.0:
        run(project, "cell_scale_background_settle_2", records, cycles=10)
    clear_flags(project)
    project.save()
    payload = {
        "records": records,
        "excluded_coordinate_atoms": [list(item) for item in sorted(excluded)],
        "final": state(project, "preterminal_coordinates"),
        "geometry": geometry(project),
    }
    AUDIT.write_text(json.dumps(payload, indent=2) + "\n")


if __name__ == "__main__":
    main()
