#!/usr/bin/env python3
"""Evaluate a fixed phase-wide isotropic displacement parameter."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def prepare(project):
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def set_phase_uiso(phase, value):
    cia = phase.data["General"]["AtomPtrs"][3]
    for atom in phase.atoms():
        atom.data[cia] = "I"
        atom.data[cia + 1] = float(value)
        for offset in range(2, 8):
            atom.data[cia + offset] = 0.0


def phase_uiso(phase):
    cia = phase.data["General"]["AtomPtrs"][3]
    return [float(atom.data[cia + 1]) for atom in phase.atoms()]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--phase", required=True, help="phase index or 'all'")
    parser.add_argument("--value", type=float, required=True)
    args = parser.parse_args()
    if not 0.003 <= args.value <= 0.020:
        raise SystemExit("Uiso outside the laboratory range")
    G2.SetPrintLevel("error")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    prepare(project)
    selected = range(len(project.phases())) if args.phase == "all" else [int(args.phase)]
    for index in selected:
        set_phase_uiso(project.phases()[index], args.value)
    for cycles in (12, 8):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
    hist = project.histogram(0)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "selected": args.phase,
        "value_A2": args.value,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "phase_Uiso_A2": {
            phase.name: phase_uiso(phase) for phase in project.phases()
        },
        "fractions": {
            str(name): float(value[0])
            for name, value in hist.ComputeMassFracs().items()
        },
    }
    output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
