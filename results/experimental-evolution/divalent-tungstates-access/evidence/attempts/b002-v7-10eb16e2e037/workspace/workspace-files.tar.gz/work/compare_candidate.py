#!/usr/bin/env python3
"""Add and equally develop one missing-reference candidate in GSAS-II."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def histogram(project):
    return project.histogram(0)


def clear_flags(project):
    hist = histogram(project)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
        })


def enable_scale_background(project):
    hist = histogram(project)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def mass_fractions(project):
    values = histogram(project).ComputeMassFracs()
    return {str(k): float(v[0]) for k, v in values.items()}


def snapshot(project, label, records, candidate):
    hist = histogram(project)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    cell = candidate.get_cell()
    item = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": mass_fractions(project),
        "candidate": {
            "cell": cell,
            "density_g_cm3": float(
                candidate.data["General"]["Mass"] * 1.66053906660 / cell["volume"]
            ),
            "scale": candidate.data["Histograms"][hist.name]["Scale"][0],
            "size_um": candidate.data["Histograms"][hist.name]["Size"][1][0],
            "short_distances": [list(x) for x in candidate.ShortDistances(useAll=False)],
        },
    }
    print(json.dumps(item), flush=True)
    records.append(item)


def refine(project, label, records, candidate, cycles=8):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    snapshot(project, label, records, candidate)


def install_bounds(project, candidate):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hist = histogram(project)
    for phase in project.phases():
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        scale = max(float(hap["Scale"][0]), 1e-6)
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(10 * scale, 100.0),
                             variable=f"{pid}:0:Scale")
    pid = candidate.data["pId"]
    cell = candidate.get_cell()
    reciprocal = G2lat.cell2A([
        cell["length_a"], cell["length_b"], cell["length_c"],
        cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
    ])
    for index, value in enumerate(reciprocal):
        span = max(0.12 * abs(float(value)), 0.002)
        project.set_Controls("parmMin", float(value) - span,
                             variable=f"{pid}::A{index}")
        project.set_Controls("parmMax", float(value) + span,
                             variable=f"{pid}::A{index}")
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    for index, atom in enumerate(candidate.atoms()):
        for axis, value, length in zip("xyz", atom.coordinates, lengths):
            half = 0.10 / float(length)
            project.set_Controls("parmMin", float(value) - half,
                                 variable=f"{pid}::dA{axis}:{index}")
            project.set_Controls("parmMax", float(value) + half,
                                 variable=f"{pid}::dA{axis}:{index}")
    project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("base_gpx")
    parser.add_argument("candidate_cif")
    parser.add_argument("name")
    parser.add_argument("output_gpx")
    parser.add_argument("--cell-scale", type=float, default=1.0)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    output = Path(args.output_gpx).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.base_gpx).resolve()),
                           newgpx=str(output))
    clear_flags(project)
    hist = histogram(project)
    candidate = project.add_phase(str(Path(args.candidate_cif).resolve()),
                                  phasename=args.name, histograms=[hist],
                                  fmthint="CIF")
    if args.cell_scale != 1.0:
        cell = candidate.data["General"]["Cell"]
        for index in (1, 2, 3):
            cell[index] *= args.cell_scale
        cell[7] *= args.cell_scale ** 3
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.12
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    install_bounds(project, candidate)

    records = []
    enable_scale_background(project)
    refine(project, "scale_background", records, candidate, cycles=8)

    candidate.set_refinements({"Cell": True})
    refine(project, "cell_adaptation", records, candidate, cycles=10)

    for atom in candidate.atoms():
        atom.refinement_flags = " " if atom.element.strip().upper() == "O" else "X"
    refine(project, "heavy_coordinate_adaptation", records, candidate, cycles=8)

    for atom in candidate.atoms():
        atom.refinement_flags = "X" if atom.element.strip().upper() == "O" else " "
    refine(project, "oxygen_coordinate_adaptation", records, candidate, cycles=8)

    for atom in candidate.atoms():
        atom.refinement_flags = "X"
    refine(project, "joint_coordinate_settle", records, candidate, cycles=8)
    for atom in candidate.atoms():
        atom.refinement_flags = " "
    shutil.copy2(output, output.with_name(output.stem + "_pre_nuisance.gpx"))

    candidate.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True}
    })
    refine(project, "candidate_size", records, candidate, cycles=10)
    refine(project, "final_settle", records, candidate, cycles=10)
    output.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
