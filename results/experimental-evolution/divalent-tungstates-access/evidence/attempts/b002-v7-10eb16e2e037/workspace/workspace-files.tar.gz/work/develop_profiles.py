#!/usr/bin/env python3
"""Develop bounded instrumental and per-phase isotropic peak profiles."""

from __future__ import annotations

import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
SOURCE = WORK / "complete_structural_checkpoint.gpx"
OUTPUT = WORK / "profile_checkpoint.gpx"
AUDIT = WORK / "profile_checkpoint.json"


def hist(project):
    return project.histogram(0)


def clear_flags(project):
    h = hist(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        if len(hap["Size"]) > 5:
            hap["Size"][5] = [False] * len(hap["Size"][5])
        if len(hap["Mustrain"]) > 5:
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_scales_background(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True


def install_bounds(project):
    controls = project.data["Controls"]["data"]
    # Coordinate and cell bounds are no longer relevant; retain only terms
    # that are actively tested in this stage.
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    limits = {
        "U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
        "SH/L": (0.005, 0.10), "Polariz.": (0.5, 1.0),
    }
    for name, (lower, upper) in limits.items():
        project.set_Controls("parmMin", lower, variable=f":0:{name}")
        project.set_Controls("parmMax", upper, variable=f":0:{name}")
    project.index_ids()
    h = hist(project)
    for phase in project.phases():
        pid = phase.data["pId"]
        scale = float(phase.data["Histograms"][h.name]["Scale"][0])
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(5.0 * scale, 100.0), variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")


def correlations(project):
    data = project.data.get("Covariance", {}).get("data", {})
    names = list(data.get("varyList", []))
    covariance = np.asarray(data.get("covMatrix", []), dtype=float)
    if covariance.shape != (len(names), len(names)) or not names:
        return []
    sigma = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    denominator = sigma[:, None] * sigma[None, :]
    matrix = np.divide(covariance, denominator, out=np.zeros_like(covariance), where=denominator > 0)
    result = []
    for i in range(len(names)):
        for j in range(i):
            result.append((abs(float(matrix[i, j])), names[j], names[i]))
    return sorted(result, reverse=True)


def state(project, label):
    h = hist(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    item = {
        "stage": label,
        "Rwp_percent": float(h.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "instrument": {
            name: float(h.InstrumentParameters[name][1])
            for name in ("U", "W", "X", "SH/L", "Polariz.")
        },
        "phases": {},
        "top_correlations": [
            {"absolute": value, "left": left, "right": right}
            for value, left, right in correlations(project)[:12]
        ],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][h.name]
        item["phases"][phase.name] = {
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "scale": float(hap["Scale"][0]),
        }
    print(json.dumps(item), flush=True)
    return item


def run(project, label, records, cycles=10):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = state(project, label)
    records.append(record)
    return record


def reload_from(path):
    project = G2.G2Project(gpxfile=str(path), newgpx=str(OUTPUT))
    clear_flags(project)
    install_bounds(project)
    return project


def trial(project, label, records, activate, validate, min_gain=0.01, cycles=12):
    checkpoint = WORK / f".{label}_checkpoint.gpx"
    clear_flags(project)
    project.save()
    shutil.copy2(OUTPUT, checkpoint)
    start = float(hist(project).get_wR())
    enable_scales_background(project)
    activate(project)
    record = run(project, label, records, cycles=cycles)
    accepted = (
        not record["frozen"]
        and record["converged"]
        and validate(project, record)
        and start - record["Rwp_percent"] >= min_gain
    )
    if accepted:
        # One repeat is a replay-stability check with identical flags.
        repeat = run(project, label + "_repeat", records, cycles=8)
        accepted = (
            not repeat["frozen"]
            and repeat["converged"]
            and validate(project, repeat)
            and repeat["Rwp_percent"] <= record["Rwp_percent"] + 0.01
        )
    if not accepted:
        records.append({
            "stage": label + "_rollback",
            "reason": "no stable interior improvement",
            "candidate": record,
        })
        return reload_from(checkpoint), False
    clear_flags(project)
    project.save()
    return project, True


def instrument_activate(*names):
    def activate(project):
        for name in names:
            hist(project).InstrumentParameters[name][2] = True
    return activate


def interior_instrument(*names):
    bounds = {"U": (0, 40), "W": (2, 40), "X": (.1, 6), "SH/L": (.005, .1), "Polariz.": (.5, 1)}
    def validate(project, _):
        h = hist(project)
        return all(
            bounds[name][0] + .01 * (bounds[name][1] - bounds[name][0])
            < float(h.InstrumentParameters[name][1])
            < bounds[name][1] - .01 * (bounds[name][1] - bounds[name][0])
            for name in names
        )
    return validate


def phase_profile_activate(index, size=False, strain=False):
    def activate(project):
        hap = project.phases()[index].data["Histograms"][hist(project).name]
        if size:
            hap["Size"][0] = "isotropic"
            hap["Size"][2][0] = True
        if strain:
            hap["Mustrain"][0] = "isotropic"
            if float(hap["Mustrain"][1][0]) < 300.0:
                hap["Mustrain"][1][0] = 1000.0
                hap["Mustrain"][1][1] = 1000.0
            hap["Mustrain"][2][0] = True
    return activate


def phase_profile_valid(index, size=False, strain=False):
    def validate(project, record):
        hap = project.phases()[index].data["Histograms"][hist(project).name]
        if size and not 0.045 < float(hap["Size"][1][0]) < 1.45:
            return False
        if strain and not 320.0 < float(hap["Mustrain"][1][0]) < 7800.0:
            return False
        active = []
        pid = project.phases()[index].data["pId"]
        if size:
            active.append(f"{pid}:0:Size;i")
        if strain:
            active.append(f"{pid}:0:Mustrain;i")
        for row in record["top_correlations"]:
            if row["absolute"] >= 0.95 and row["left"] in active and row["right"] in active:
                return False
        return True
    return validate


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    clear_flags(project)
    install_bounds(project)
    records = [state(project, "profile_source")]

    # Estimate the common instrumental envelope first while inherited effective
    # phase sizes remain fixed. Each family is then fixed before phase-specific
    # broadening is developed, avoiding exact common/phase degeneracies.
    project, _ = trial(
        project, "instrument_U_W", records,
        instrument_activate("U", "W"), interior_instrument("U", "W"), min_gain=.02,
    )
    project, _ = trial(
        project, "instrument_X", records,
        instrument_activate("X"), interior_instrument("X"), min_gain=.02,
    )
    project, _ = trial(
        project, "instrument_SHL", records,
        instrument_activate("SH/L"), interior_instrument("SH/L"), min_gain=.01,
    )

    # Isotropic size and strain are tested separately phase-by-phase. A term
    # that collapses to an inactive value or a laboratory bound is removed.
    for index, phase in enumerate(project.phases()):
        project, _ = trial(
            project, f"phase_{index}_{phase.name}_size", records,
            phase_profile_activate(index, size=True),
            phase_profile_valid(index, size=True), min_gain=.01,
        )
        project, strain_kept = trial(
            project, f"phase_{index}_{phase.name}_strain", records,
            phase_profile_activate(index, strain=True),
            phase_profile_valid(index, strain=True), min_gain=.01,
        )
        if strain_kept:
            project, _ = trial(
                project, f"phase_{index}_{phase.name}_size_strain", records,
                phase_profile_activate(index, size=True, strain=True),
                phase_profile_valid(index, size=True, strain=True), min_gain=.005,
            )

    # With phase profiles fixed, permit a final independent common-envelope
    # update. No instrument/phase profile terms are co-refined here.
    project, _ = trial(
        project, "instrument_U_W_final", records,
        instrument_activate("U", "W"), interior_instrument("U", "W"), min_gain=.01,
    )
    project, _ = trial(
        project, "instrument_X_final", records,
        instrument_activate("X"), interior_instrument("X"), min_gain=.01,
    )
    project, _ = trial(
        project, "instrument_SHL_final", records,
        instrument_activate("SH/L"), interior_instrument("SH/L"), min_gain=.005,
    )

    clear_flags(project)
    enable_scales_background(project)
    run(project, "profile_scale_background_settle", records, cycles=10)
    clear_flags(project)
    project.save()
    AUDIT.write_text(json.dumps({"records": records, "final": state(project, "profile_checkpoint")}, indent=2) + "\n")


if __name__ == "__main__":
    main()
