#!/usr/bin/env python3
"""Put Mn2WO5 topology starts on comparable, physically plausible metrics."""

from __future__ import annotations

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
CANDIDATES = ROOT / "candidates"

# Fitted before any coordinate or profile refinement in the successful Pnnm
# basin. Both independent Pnnm starts use this exact metric.
PNNM_LATTICE = Lattice.orthorhombic(8.673353, 8.923454, 6.299126)
TARGET_VOLUME = PNNM_LATTICE.volume


def write_with_lattice(source: Path, destination: Path, lattice: Lattice) -> None:
    structure = Structure.from_file(source, primitive=False)
    structure = Structure(
        lattice,
        structure.species,
        structure.frac_coords,
        site_properties=structure.site_properties,
    )
    CifWriter(
        structure,
        symprec=1e-3,
        refine_struct=False,
        significant_figures=10,
    ).write_file(destination)


def main() -> None:
    for stem in ("pnnm_mn2aso5", "pnnm_cu2po5"):
        write_with_lattice(
            CANDIDATES / f"{stem}.cif",
            CANDIDATES / f"{stem}_common.cif",
            PNNM_LATTICE,
        )

    source = CANDIDATES / "cmcm_pseudobrookite.cif"
    structure = Structure.from_file(source, primitive=False)
    factor = (TARGET_VOLUME / structure.volume) ** (1.0 / 3.0)
    write_with_lattice(
        source,
        CANDIDATES / "cmcm_pseudobrookite_common_density.cif",
        Lattice.from_parameters(
            structure.lattice.a * factor,
            structure.lattice.b * factor,
            structure.lattice.c * factor,
            structure.lattice.alpha,
            structure.lattice.beta,
            structure.lattice.gamma,
        ),
    )


if __name__ == "__main__":
    main()
