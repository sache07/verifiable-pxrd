#!/usr/bin/env python3
"""Create composition-adapted Mn2WO5 trial models from analogue parents."""

from __future__ import annotations

import json
from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


LIBRARY = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


TRIALS = {
    "pnnm_mn2aso5": {
        "id": "9000178",
        "substitutions": {"As": "W"},
        "screen_cell_scale": 1.00504,
        "basis": "Mn2AsO4(OH) Pnnm parent; implicit H omitted by the COD model",
    },
    "pnnm_cu2po5": {
        "id": "9016468",
        "substitutions": {"Cu": "Mn", "P": "W"},
        "screen_cell_scale": 1.18038,
        "basis": "Cu2PO5 Pnnm parent",
    },
    "cmcm_pseudobrookite": {
        "id": "2002318",
        "substitutions": {"Ti4+": "Mn", "Fe2+": "W"},
        "screen_cell_scale": 0.88150,
        "basis": "FeTi2O5 Cmcm pseudobrookite parent",
    },
}


def cod_path(cid: str) -> Path:
    return LIBRARY / cid[0] / cid[1:3] / cid[3:5] / f"{cid}.cif"


def main() -> None:
    output = Path("work/candidates")
    output.mkdir(parents=True, exist_ok=True)
    provenance = {}
    for name, record in TRIALS.items():
        source = cod_path(record["id"])
        structure = Structure.from_file(source, primitive=False)
        structure.replace_species(record["substitutions"])
        target = output / f"{name}.cif"
        CifWriter(structure, symprec=1e-3, refine_struct=False).write_file(target)
        provenance[name] = {
            **record,
            "source": str(source),
            "output": str(target),
            "target_formula": structure.composition.reduced_formula,
            "unscaled_cell": structure.lattice.parameters,
            "unscaled_volume_A3": structure.volume,
        }
    (output / "provenance.json").write_text(
        json.dumps(provenance, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
