#!/usr/bin/env python3
"""Read-only export of the accepted final project and replayed profile."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"
REPLAY = ROOT / "work" / "replay_check"
OUTPUTS = ["MnWO4.cif", "WO3.cif", "Mn2WO5.cif"]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    before = digest(PROJECT)
    replay_report = json.loads((REPLAY / "replay.json").read_text())
    if replay_report.get("status") != "replayed":
        raise RuntimeError("accepted project has no successful read-only replay")
    if replay_report.get("project_sha256") != before:
        raise RuntimeError("replay was not generated from the accepted final.gpx")

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(PROJECT))
    hist = project.histogram(replay_report["histogram"])
    phases = project.phases()
    if len(phases) != len(OUTPUTS):
        raise RuntimeError("unexpected phase count")
    for phase, filename in zip(phases, OUTPUTS):
        phase.export_CIF(str(ROOT / filename))

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as replay:
        x = np.asarray(replay["x"], dtype=float)
        observed = np.asarray(replay["observed"], dtype=float)
        calculated = np.asarray(replay["predicted"], dtype=float)
    supplied = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, supplied[:, 0]) or not np.array_equal(observed, supplied[:, 1]):
        raise RuntimeError("replay profile does not cover the original observed grid")
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f"],
    )

    fractions = hist.ComputeMassFracs()
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference ** 2))
    denominator = float(np.sum(weights * observed ** 2))
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    summary = {
        "project_sha256": before,
        "project_unchanged": digest(PROJECT) == before,
        "histogram": hist.name,
        "points": int(len(x)),
        "profile": {
            "Rwp_percent": float(100.0 * np.sqrt(chi_square / denominator)),
            "Rp_percent": float(100.0 * np.sum(np.abs(difference)) / np.sum(observed)),
            "chi_square": chi_square,
            "saved_GOF": rvals.get("GOF"),
            "saved_Rwp_percent": float(hist.get_wR()),
            "Nobs": rvals.get("Nobs"),
            "Nvars": rvals.get("Nvars"),
        },
        "phases": [],
    }
    for phase, filename in zip(phases, OUTPUTS):
        value = fractions[phase.name]
        hap = phase.data["Histograms"][hist.name]
        cia = phase.data["General"]["AtomPtrs"][3]
        summary["phases"].append({
            "name": phase.name,
            "cif_path": filename,
            "weight_fraction": float(value[0]),
            "weight_fraction_esd": float(value[1]),
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_model": hap["Mustrain"][0],
            "microstrain_ppm": [float(v) for v in hap["Mustrain"][1][:2]],
            "preferred_orientation_ratio": float(hap["Pref.Ori."][1]),
            "preferred_orientation_axis": list(hap["Pref.Ori."][3]),
            "Uiso_A2": [float(atom.data[cia + 1]) for atom in phase.atoms()],
        })
    (ROOT / "work" / "export_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n"
    )
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
