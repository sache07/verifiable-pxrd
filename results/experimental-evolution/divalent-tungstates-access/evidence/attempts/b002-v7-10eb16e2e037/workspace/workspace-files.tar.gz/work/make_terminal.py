#!/usr/bin/env python3
"""Create the terminal pre-polish project and audit its physical state."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIstrMain as G2st


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "work" / "terminal_SHL_0p04.gpx"
OUTPUT = ROOT / "final.gpx"
AUDIT = ROOT / "work" / "terminal_audit.json"


def hist(project):
    return project.histogram(0)


def clear_flags(project):
    h = hist(project)
    h.Background[0][1] = False
    for value in h.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in h.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][h.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_terminal_settle(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][h.name]["Scale"][1] = True
        phase.set_refinements({"Cell": True})


def install_bounds(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    h = hist(project)
    for phase in project.phases():
        pid = phase.data["pId"]
        scale = float(phase.data["Histograms"][h.name]["Scale"][0])
        project.set_Controls("parmMin", 0.25 * scale, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 5.0 * scale, variable=f"{pid}:0:Scale")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.005 * abs(float(value)), 0.0002)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")


def mass_fractions(project):
    return {str(k): float(v[0]) for k, v in hist(project).ComputeMassFracs().items()}


def convergence(project):
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "Rwp_percent": float(hist(project).get_wR()),
        "GOF": rvals.get("GOF"),
        "chi_square": rvals.get("chisq"),
        "Nobs": rvals.get("Nobs"),
        "Nvars": rvals.get("Nvars"),
        "frozen": list(project.get_Frozen()),
    }


def run(project, label, records):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 10)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = {"stage": label, **convergence(project), "fractions": mass_fractions(project)}
    records.append(record)
    print(json.dumps(record), flush=True)
    return record


def geometry(project):
    result = {}
    for phase in project.phases():
        controls, data = phase.InitDisAgl(False)
        controls["Factors"] = [1.25, 0.0]
        _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
        atoms = phase.atoms()
        pair_min = {}
        for center, rows in distances.items():
            for row in rows:
                other = int(row[0])
                pair = "-".join(sorted((atoms[center].element, atoms[other].element)))
                distance = float(row[-2])
                pair_min[pair] = min(pair_min.get(pair, distance), distance)
        result[phase.name] = {
            "pair_min_A": pair_min,
            "catastrophic_contacts": [list(item) for item in phase.ShortDistances(useAll=False)],
        }
    return result


def active_flags(project):
    result = []
    h = hist(project)
    if h.Background[0][1]:
        result.append("background")
    for name, value in h.InstrumentParameters.items():
        if isinstance(value, list) and len(value) > 2 and value[2]:
            result.append("instrument:" + name)
    for name, value in h.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool) and value[1]:
            result.append("sample:" + name)
    for phase in project.phases():
        if any(atom.refinement_flags.strip() for atom in phase.atoms()):
            result.append("coordinates:" + phase.name)
        hap = phase.data["Histograms"][h.name]
        if hap["Scale"][1]:
            result.append("scale:" + phase.name)
        if any(hap["Size"][2]) or any(hap["Mustrain"][2]) or hap["Pref.Ori."][2]:
            result.append("profile:" + phase.name)
    return result


def physical_parameters(project):
    h = hist(project)
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][h.name]
        cia = phase.data["General"]["AtomPtrs"][3]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "size_um": float(hap["Size"][1][0]),
            "microstrain_model": hap["Mustrain"][0],
            "microstrain_ppm": [float(v) for v in hap["Mustrain"][1][:2]],
            "preferred_orientation": {
                "ratio": float(hap["Pref.Ori."][1]),
                "axis": list(hap["Pref.Ori."][3]),
            },
            "Uiso_A2": [float(atom.data[cia + 1]) for atom in phase.atoms()],
        }
    return {
        "instrument": {
            name: float(h.InstrumentParameters[name][1])
            for name in ("Zero", "U", "W", "X", "SH/L", "Polariz.")
        },
        "sample": {
            name: float(h.SampleParameters[name][0])
            for name in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": phases,
    }


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(OUTPUT))
    clear_flags(project)
    install_bounds(project)
    enable_terminal_settle(project)
    records = []
    first = run(project, "terminal_settle_1", records)
    if first["max_shift_esd"] is None or float(first["max_shift_esd"]) > 1.0:
        run(project, "terminal_settle_2", records)
    # Identical replay is required even when the first pass was nominally
    # converged; this catches saved-state drift before the one-time polish.
    run(project, "terminal_replay", records)
    clear_flags(project)
    project.save()
    final = convergence(project)
    payload = {
        "source": str(SOURCE),
        "output": str(OUTPUT),
        "records": records,
        "final": final,
        "fractions": mass_fractions(project),
        "geometry": geometry(project),
        "parameters": physical_parameters(project),
        "active_refinement_flags": active_flags(project),
    }
    problems = []
    if final["frozen"]:
        problems.append("frozen variables remain")
    if payload["active_refinement_flags"]:
        problems.append("active refinement flags remain")
    if any(value["catastrophic_contacts"] for value in payload["geometry"].values()):
        problems.append("catastrophic contact")
    if not final["converged"] or final["max_shift_esd"] is None or float(final["max_shift_esd"]) > 1.0:
        problems.append("terminal replay did not converge")
    payload["problems"] = problems
    AUDIT.write_text(json.dumps(payload, indent=2) + "\n")
    if problems:
        raise RuntimeError("terminal audit failed: " + "; ".join(problems))
    print(json.dumps({"terminal": True, **final, "fractions": payload["fractions"]}))


if __name__ == "__main__":
    main()
