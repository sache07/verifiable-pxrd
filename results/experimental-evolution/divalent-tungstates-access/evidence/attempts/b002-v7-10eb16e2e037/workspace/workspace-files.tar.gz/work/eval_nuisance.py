#!/usr/bin/env python3
"""Evaluate one bounded global profile/specimen nuisance branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


BOUNDS = {
    "U": (0.0, 40.0), "W": (2.0, 40.0), "X": (0.1, 6.0),
    "SH/L": (0.005, 0.10), "Polariz.": (0.5, 1.0),
    "SurfRoughA": (0.05, 0.6), "SurfRoughB": (0.02, 0.5),
}


def prepare(project, mode, starts):
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Pref.Ori."][2] = False
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    if mode == "roughness":
        for name, start in zip(("SurfRoughA", "SurfRoughB"), starts):
            hist.SampleParameters[name] = [float(start), True]
            project.set_Controls("parmMin", BOUNDS[name][0], variable=f":0:{name}")
            project.set_Controls("parmMax", BOUNDS[name][1], variable=f":0:{name}")
    else:
        if mode not in BOUNDS or mode.startswith("Surf"):
            raise ValueError(mode)
        if starts:
            hist.InstrumentParameters[mode][1] = float(starts[0])
        hist.InstrumentParameters[mode][2] = True
        project.set_Controls("parmMin", BOUNDS[mode][0], variable=f":0:{mode}")
        project.set_Controls("parmMax", BOUNDS[mode][1], variable=f":0:{mode}")


def target_correlations(project, targets):
    data = project.data.get("Covariance", {}).get("data", {})
    names = list(data.get("varyList", []))
    covariance = np.asarray(data.get("covMatrix", []), dtype=float)
    if covariance.shape != (len(names), len(names)):
        return []
    sigma = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    rows = []
    for target in targets:
        if target not in names:
            continue
        i = names.index(target)
        for j, other in enumerate(names):
            if i == j or sigma[i] <= 0 or sigma[j] <= 0:
                continue
            rows.append((abs(float(covariance[i, j] / (sigma[i] * sigma[j]))), target, other))
    return sorted(rows, reverse=True)[:10]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--mode", required=True)
    parser.add_argument("--start", nargs="*", type=float, default=[])
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    prepare(project, args.mode, args.start)
    for cycles in (12, 8):
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        project.set_Controls("cycles", cycles)
        project.save()
        project.refine(makeBack=False)
        project.save()
    hist = project.histogram(0)
    if args.mode == "roughness":
        parameters = {
            name: float(hist.SampleParameters[name][0])
            for name in ("SurfRoughA", "SurfRoughB")
        }
        targets = [":0:SurfRoughA", ":0:SurfRoughB"]
    else:
        parameters = {args.mode: float(hist.InstrumentParameters[args.mode][1])}
        targets = [f":0:{args.mode}"]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "mode": args.mode,
        "starts": args.start,
        "parameters": parameters,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "correlations": target_correlations(project, targets),
        "fractions": {
            str(name): float(value[0])
            for name, value in hist.ComputeMassFracs().items()
        },
    }
    output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
