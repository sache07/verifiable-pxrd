#!/usr/bin/env python3
"""Build a comparable exploratory GSAS-II refinement from supplied CIFs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def state(project, label):
    hist = project.histogram(0)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    item = {
        "label": label,
        "Rwp_percent": hist.get_wR(),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "zero_deg": hist.InstrumentParameters["Zero"][1],
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        item["phases"][phase.name] = {
            "scale": hap["Scale"][0],
            "cell": phase.get_cell(),
            "size_um": hap["Size"][1][0],
            "microstrain_ppm": hap["Mustrain"][1][0],
        }
    print(json.dumps(item), flush=True)
    return item


def refine(project, label, records, cycles=8):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(state(project, label))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("output")
    parser.add_argument("--phase", action="append", nargs=3,
                        metavar=("NAME", "CIF", "SIZE_UM"), required=True)
    args = parser.parse_args()
    output = Path(args.output).resolve()
    G2.SetPrintLevel("warn")

    project = G2.G2Project(newgpx=str(output))
    phases = []
    for name, cif, _ in args.phase:
        phases.append(project.add_phase(str(Path(cif).resolve()), phasename=name,
                                        fmthint="CIF"))
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("work/instrument.instprm").resolve()), phases=phases)
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 12,
            "coeffs": [1400.0] + [0.0] * 11, "refine": True,
        }
    })

    project.index_ids()
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    for phase, (_, _, size) in zip(phases, args.phase):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [20.0 / max(len(phases), 1), True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(size)
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][1][1] = 0.0
        hap["Mustrain"][2] = [False, False, False]
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 1000.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")

    records = []
    refine(project, "scale_background", records)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells_zero", records, cycles=12)

    for phase in phases:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True}
        })
    refine(project, "isotropic_sizes", records, cycles=12)
    refine(project, "settle", records, cycles=12)

    output.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
