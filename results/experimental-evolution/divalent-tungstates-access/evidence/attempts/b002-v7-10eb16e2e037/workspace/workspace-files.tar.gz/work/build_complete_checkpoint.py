#!/usr/bin/env python3
"""Build a clean three-phase structural checkpoint before profile refinement."""

from __future__ import annotations

import json
from pathlib import Path
import re
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat
from GSASII import GSASIIstrMain as G2st


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
BASE = WORK / "trial_wo3_1528915.gpx"
CANDIDATE = WORK / "candidates" / "pnnm_mn2aso5_common.cif"
OUTPUT = WORK / "complete_structural_checkpoint.gpx"
AUDIT = WORK / "complete_structural_checkpoint.json"

COORDINATE_WINDOW_A = 0.10
COORD_RE = re.compile(r"^(\d+)::dA[xyz]:(\d+)$")


def histogram(project):
    return project.histogram(0)


def clear_flags(project):
    hist = histogram(project)
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        if isinstance(hap.get("Scale"), list):
            hap["Scale"][1] = False
        for key in ("Size", "Mustrain"):
            value = hap.get(key)
            if isinstance(value, list) and len(value) > 2:
                value[2] = [False] * len(value[2])
            if isinstance(value, list) and len(value) > 5:
                value[5] = [False] * len(value[5])
        if "Pref.Ori." in hap:
            hap["Pref.Ori."][2] = False
        if "HStrain" in hap:
            hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        if "Extinction" in hap:
            hap["Extinction"][1] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def enable_scales_background(project):
    hist = histogram(project)
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def reset_limits(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}


def mass_fractions(project):
    return {
        str(name): float(value[0])
        for name, value in histogram(project).ComputeMassFracs().items()
    }


def covariance_correlations(project):
    data = project.data.get("Covariance", {}).get("data", {})
    names = list(data.get("varyList", []))
    covariance = np.asarray(data.get("covMatrix", []), dtype=float)
    if covariance.shape != (len(names), len(names)) or not len(names):
        return []
    sigma = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    denominator = sigma[:, None] * sigma[None, :]
    correlation = np.divide(
        covariance,
        denominator,
        out=np.zeros_like(covariance),
        where=denominator > 0,
    )
    rows = []
    for i in range(len(names)):
        for j in range(i):
            rows.append((abs(float(correlation[i, j])), names[j], names[i]))
    return sorted(rows, reverse=True)


def geometry(project):
    result = {}
    for phase in project.phases():
        controls, data = phase.InitDisAgl(False)
        controls["Factors"] = [1.25, 0.0]
        _, distances, _ = G2st.RetDistAngle(controls, data, dmin=0.01)
        atoms = phase.atoms()
        pair_minima = {}
        for center, rows in distances.items():
            for row in rows:
                other = int(row[0])
                pair = "-".join(sorted((atoms[center].element, atoms[other].element)))
                distance = float(row[-2])
                pair_minima[pair] = min(pair_minima.get(pair, distance), distance)
        result[phase.name] = {
            "pair_min_A": pair_minima,
            "catastrophic_contacts": [list(item) for item in phase.ShortDistances(useAll=False)],
        }
    return result


def state(project, label):
    hist = histogram(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    item = {
        "stage": label,
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "fractions": mass_fractions(project),
        "zero_deg": float(hist.InstrumentParameters["Zero"][1]),
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "top_correlations": [
            {"absolute": value, "left": left, "right": right}
            for value, left, right in covariance_correlations(project)[:12]
        ],
    }
    print(json.dumps(item), flush=True)
    return item


def run(project, label, records, cycles=10):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    records.append(state(project, label))
    return records[-1]


def install_bounds(project, source_coordinates):
    project.index_ids()
    hist = histogram(project)
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")
    for phase in project.phases():
        pid = phase.data["pId"]
        scale = max(float(phase.data["Histograms"][hist.name]["Scale"][0]), 1e-6)
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", max(5.0 * scale, 100.0), variable=f"{pid}:0:Scale")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A([
            cell["length_a"], cell["length_b"], cell["length_c"],
            cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
        ])
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for index, atom in enumerate(phase.atoms()):
            source = source_coordinates[(int(pid), index)]
            for axis, value, length in zip("xyz", source, lengths):
                half = COORDINATE_WINDOW_A / float(length)
                project.set_Controls("parmMin", value - half, variable=f"{pid}::dA{axis}:{index}")
                project.set_Controls("parmMax", value + half, variable=f"{pid}::dA{axis}:{index}")


def coordinate_sources(project):
    return {
        (int(phase.data["pId"]), index): tuple(float(x) for x in atom.coordinates)
        for phase in project.phases()
        for index, atom in enumerate(phase.atoms())
    }


def coordinate_atoms(record):
    result = set()
    for variable in record.get("frozen", []):
        match = COORD_RE.match(str(variable))
        if match:
            result.add((int(match.group(1)), int(match.group(2))))
    return result


def set_coordinate_flags(project, active):
    for phase in project.phases():
        pid = int(phase.data["pId"])
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "X" if (pid, index) in active else " "


def refine_coordinate_group(project, label, selected, excluded, sources, records):
    selected = set(selected) - set(excluded)
    if not selected:
        return excluded
    stage_start = WORK / f".{label}_start.gpx"
    clear_flags(project)
    enable_scales_background(project)
    set_coordinate_flags(project, selected)
    project.save()
    shutil.copy2(project.filename, stage_start)
    start_rwp = float(histogram(project).get_wR())
    for pass_index in range(4):
        record = run(project, f"{label}_{pass_index + 1}", records, cycles=8)
        hits = coordinate_atoms(record)
        if hits:
            excluded.update(hits)
            for phase in project.phases():
                pid = int(phase.data["pId"])
                for index, atom in enumerate(phase.atoms()):
                    key = (pid, index)
                    if key in hits:
                        atom.coordinates = sources[key]
            clear_flags(project)
            enable_scales_background(project)
            selected -= hits
            set_coordinate_flags(project, selected)
            if not selected:
                break
            continue
        maximum = record.get("max_shift_esd")
        if record["converged"] and maximum is not None and float(maximum) <= 1.0:
            break
    if float(histogram(project).get_wR()) > start_rwp + 0.01:
        project = G2.G2Project(gpxfile=str(stage_start), newgpx=str(OUTPUT))
        excluded.update(selected)
    return excluded


def main():
    G2.SetPrintLevel("warn")
    records = []
    project = G2.G2Project(gpxfile=str(BASE), newgpx=str(OUTPUT))
    clear_flags(project)
    reset_limits(project)
    hist = histogram(project)
    candidate = project.add_phase(
        str(CANDIDATE), phasename="Mn2WO5", histograms=[hist], fmthint="CIF"
    )
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [5.8, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.12
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][1][1] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    sources = coordinate_sources(project)
    install_bounds(project, sources)

    clear_flags(project)
    enable_scales_background(project)
    for index in range(3):
        record = run(project, f"scale_background_{index + 1}", records, cycles=8)
        maximum = record.get("max_shift_esd")
        if record["converged"] and maximum is not None and float(maximum) <= 1.0:
            break

    clear_flags(project)
    enable_scales_background(project)
    hist.InstrumentParameters["Zero"][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    for index in range(3):
        record = run(project, f"cells_zero_{index + 1}", records, cycles=10)
        maximum = record.get("max_shift_esd")
        if record["converged"] and maximum is not None and float(maximum) <= 1.0:
            break

    pre_shift = WORK / "complete_pre_shift.gpx"
    clear_flags(project)
    project.save()
    shutil.copy2(OUTPUT, pre_shift)
    pre_shift_rwp = float(histogram(project).get_wR())
    enable_scales_background(project)
    hist.InstrumentParameters["Zero"][2] = True
    hist.SampleParameters["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    shift_record = run(project, "cells_zero_shift", records, cycles=12)
    shift_correlations = [
        row for row in shift_record["top_correlations"]
        if "Shift" in (row["left"], row["right"])
    ]
    shift_ok = (
        not shift_record["frozen"]
        and abs(shift_record["shift_um"]) < 760.0
        and pre_shift_rwp - shift_record["Rwp_percent"] >= 0.02
        and (not shift_correlations or shift_correlations[0]["absolute"] < 0.95)
    )
    if not shift_ok:
        records.append({
            "stage": "shift_rollback",
            "reason": "insufficient independent interior improvement",
            "candidate": shift_record,
        })
        project = G2.G2Project(gpxfile=str(pre_shift), newgpx=str(OUTPUT))
        hist = histogram(project)

    # Coordinates are now developed phasewise. Bound-hit atoms return to their
    # source positions and remain fixed; numerical failure is not used as phase
    # rejection.
    excluded = set()
    for phase in project.phases():
        pid = int(phase.data["pId"])
        heavy = {
            (pid, index) for index, atom in enumerate(phase.atoms())
            if atom.element.strip().upper() not in {"O", "O-2"}
        }
        oxygen = {
            (pid, index) for index, atom in enumerate(phase.atoms())
            if atom.element.strip().upper() in {"O", "O-2"}
        }
        excluded = refine_coordinate_group(
            project, f"phase_{pid}_heavy", heavy, excluded, sources, records
        )
        excluded = refine_coordinate_group(
            project, f"phase_{pid}_oxygen", oxygen, excluded, sources, records
        )

    all_atoms = set(sources) - excluded
    excluded = refine_coordinate_group(
        project, "joint_coordinates", all_atoms, excluded, sources, records
    )
    clear_flags(project)
    enable_scales_background(project)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, "structural_settle", records, cycles=10)
    clear_flags(project)
    project.save()

    payload = {
        "records": records,
        "excluded_coordinate_atoms": [list(item) for item in sorted(excluded)],
        "final": state(project, "complete_structural_checkpoint"),
        "geometry": geometry(project),
    }
    AUDIT.write_text(json.dumps(payload, indent=2) + "\n")


if __name__ == "__main__":
    main()
