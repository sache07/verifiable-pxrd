#!/usr/bin/env python3
"""Evaluate one bounded March-Dollase phase/axis branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def clear_and_enable(project, phase_index, axis, ratio):
    hist = project.histogram(0)
    hist.Background[0][1] = True
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for index, phase in enumerate(project.phases()):
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = True
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        hap["Pref.Ori."][2] = False
        if index == phase_index:
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = ratio
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = list(axis)
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    pid = project.phases()[phase_index].data["pId"]
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")


def correlation(project, target):
    data = project.data.get("Covariance", {}).get("data", {})
    names = list(data.get("varyList", []))
    covariance = np.asarray(data.get("covMatrix", []), dtype=float)
    if target not in names or covariance.shape != (len(names), len(names)):
        return None
    i = names.index(target)
    sigma = np.sqrt(np.maximum(np.diag(covariance), 0.0))
    values = []
    for j, name in enumerate(names):
        if i == j or sigma[i] <= 0 or sigma[j] <= 0:
            continue
        values.append((abs(float(covariance[i, j] / (sigma[i] * sigma[j]))), name))
    return max(values, default=(0.0, None))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("source")
    parser.add_argument("output")
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", nargs=3, type=int, required=True)
    parser.add_argument("--start", type=float, required=True)
    args = parser.parse_args()
    G2.SetPrintLevel("error")
    output = Path(args.output).resolve()
    project = G2.G2Project(gpxfile=str(Path(args.source).resolve()), newgpx=str(output))
    clear_and_enable(project, args.phase, args.axis, args.start)
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    # Replay the same active model once to distinguish a settled basin from an
    # early numerical improvement.
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 8)
    project.refine(makeBack=False)
    project.save()
    hist = project.histogram(0)
    phase = project.phases()[args.phase]
    hap = phase.data["Histograms"][hist.name]
    pid = phase.data["pId"]
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    record = {
        "phase_index": args.phase,
        "phase": phase.name,
        "axis": list(args.axis),
        "start": args.start,
        "ratio": float(hap["Pref.Ori."][1]),
        "Rwp_percent": float(hist.get_wR()),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "maximum_MD_correlation": correlation(project, f"{pid}:0:MD"),
        "fractions": {
            str(name): float(value[0])
            for name, value in hist.ComputeMassFracs().items()
        },
    }
    output.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
