#!/usr/bin/env python3
"""Build and moderately refine a GSAS-II project for a COD phase set.

This is an analysis helper, not a source of specimen-specific reference data.
It imports the original scan, applies Poisson weights, and performs the same
conservative screening sequence for each candidate inventory.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_support_files(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    raw = np.loadtxt(ROOT / "inputs/pattern.csv", delimiter=",", skiprows=1)
    xye = work / "pattern.xye"
    # GSAS-II's xye reader expects sigma, not inverse variance.
    np.savetxt(xye, np.column_stack((raw[:, 0], raw[:, 1], np.sqrt(np.maximum(raw[:, 1], 1.0)))),
               fmt=["%.8f", "%.8f", "%.8f"])
    inst = work / "instrument.instprm"
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def phase_mass(phase) -> float:
    return float(phase.data["General"]["Mass"])


def fractions(project, hist) -> dict[str, float]:
    vals = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        vals[phase.name] = max(0.0, phase_mass(phase) * float(hap["Scale"][0]))
    total = sum(vals.values())
    return {k: v / total for k, v in vals.items()} if total > 0 else vals


def state(project, hist, stage: str) -> dict:
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    inst = hist.InstrumentParameters
    samp = hist.SampleParameters
    return {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": project.get_Frozen(),
        "fractions": fractions(project, hist),
        "zero_deg": inst["Zero"][1],
        "shift_um": samp["Shift"][0],
        "profile": {k: inst[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.") if k in inst},
        "cells": {p.name: p.get_cell() for p in project.phases()},
    }


def refine(project, hist, stage: str, records: list[dict], cycles: int = 6) -> None:
    project.set_Controls("cycles", cycles)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()
    project.refine(makeBack=False)
    project.save()
    rec = state(project, hist, stage)
    records.append(rec)
    print(json.dumps(rec), flush=True)


def set_bounds(project, hist) -> None:
    project.index_ids()
    hid = hist.id
    # Bounds reflect the frozen laboratory specification, with a small margin
    # on nuisance profile values for numerical screening.
    bounds = {
        f":{hid}:Zero": (-0.25, 0.25),
        f":{hid}:Shift": (-800.0, 800.0),
        f":{hid}:U": (0.0, 40.0),
        f":{hid}:W": (2.0, 40.0),
        f":{hid}:X": (0.1, 6.0),
        f":{hid}:SH/L": (0.005, 0.10),
        f":{hid}:Polariz.": (0.5, 1.0),
    }
    for phase in project.phases():
        pid = phase.id
        bounds[f"{pid}:{hid}:Scale"] = (0.0, 1.0e7)
        bounds[f"{pid}:{hid}:Size;i"] = (0.04, 1.5)
        bounds[f"{pid}:{hid}:Mustrain;i"] = (0.0, 8000.0)
    for var, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, variable=var)
        project.set_Controls("parmMax", hi, variable=var)


def clear_all(project, hist) -> None:
    # Do this directly. The scriptable clear_refinements method returns early
    # after a boolean Background request and otherwise leaves later sections
    # in the same dictionary untouched.
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True, "Extinction": True,
        })
        for atom in phase.atoms():
            atom.refinement_flags = " "


def build(out: Path, ids: list[str], names: list[str], shift: float) -> tuple[object, object]:
    support = out.parent / f".{out.stem}_support"
    xye, inst = prepare_support_files(support)
    project = G2.G2Project(newgpx=str(out))
    phases = []
    for cid, name in zip(ids, names):
        phases.append(project.add_phase(str(cod_path(cid)), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [float(shift), False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    # A smooth decaying starting background. Refinement determines all terms.
    hist.set_refinements({"Background": {
        "type": "chebyschev-1", "no. coeffs": 15,
        "coeffs": [2500.0, -1200.0] + [0.0] * 13, "refine": False,
    }})
    for phase in phases:
        for atom in phase.atoms():
            # Normalize source ADPs to the isotropic specimen model used by
            # the synthetic laboratory. GSAS keeps the six anisotropic slots,
            # but ignores them once the flag is changed to isotropic.
            atom.data[atom.cia] = "I"
            atom.uiso = 0.01
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [10000.0 / phase_mass(phase), False]
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": False}})
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]
    set_bounds(project, hist)
    clear_all(project, hist)
    project.save()
    return project, hist


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("out", type=Path)
    parser.add_argument("ids", nargs="+")
    parser.add_argument("--names", nargs="+")
    parser.add_argument("--profile", action="store_true", help="include a modest profile refinement")
    parser.add_argument("--shift", type=float, default=800.0,
                        help="fixed starting specimen displacement in micrometres")
    parser.add_argument("--refine-shift", action="store_true")
    args = parser.parse_args()
    names = args.names or [f"phase_{cid}" for cid in args.ids]
    if len(names) != len(args.ids):
        raise SystemExit("--names must match ids")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project, hist = build(args.out, args.ids, names, args.shift)
    records: list[dict] = []

    # Linear terms first.
    hist.set_refinements({"Background": True})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, hist, "background_scales", records)

    # Fit the common angular calibration before phase cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, hist, "zero", records)
    if args.refine_shift:
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        refine(project, hist, "zero_shift", records)

    # Reference mismatch is symmetry-preserving, so cell refinement is valid.
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, hist, "cells", records, cycles=8)

    if args.profile:
        hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
        refine(project, hist, "instrument_profile", records, cycles=8)
        for phase in project.phases():
            phase.set_HAP_refinements({
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            })
        refine(project, hist, "phase_profiles", records, cycles=8)

    clear_all(project, hist)
    project.save()
    summary = {
        "ids": args.ids,
        "names": names,
        "project": str(args.out),
        "records": records,
        "final": state(project, hist, "final"),
    }
    args.out.with_suffix(".json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
