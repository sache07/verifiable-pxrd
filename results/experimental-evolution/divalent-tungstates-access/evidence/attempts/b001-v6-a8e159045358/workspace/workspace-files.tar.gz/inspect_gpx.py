#!/usr/bin/env python3
"""Print compact diagnostics for one or more GSAS-II projects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("projects", type=Path, nargs="+")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    for path in args.projects:
        project = G2.G2Project(gpxfile=str(path))
        hist = project.histogram(0)
        x, obs, weights, calc, bkg, diff = map(np.asarray, hist.data["data"][1][:6])
        lo, hi = hist.data["Limits"][1]
        use = (x >= lo) & (x <= hi)
        coeffs = list(map(float, hist.Background[0][3:]))
        bins = []
        for left in np.arange(np.ceil(lo / 5) * 5, hi, 5):
            take = use & (x >= left) & (x < left + 5)
            if not np.any(take):
                continue
            bins.append({
                "range": [float(left), float(min(left + 5, hi))],
                "median_observed": float(np.median(obs[take])),
                "median_background": float(np.median(bkg[take])),
                "median_difference": float(np.median(diff[take])),
                "mean_difference": float(np.mean(diff[take])),
            })
        cov = project.data.get("Covariance", {}).get("data", {})
        rvals = cov.get("Rvals", {})
        out = {
            "project": str(path),
            "Rwp_percent": float(hist.get_wR()),
            "GOF": float(rvals.get("GOF", np.nan)),
            "background_type": hist.Background[0][0],
            "background_coefficients": coeffs,
            "background_min_max": [float(np.min(bkg[use])), float(np.max(bkg[use]))],
            "difference_bins": bins,
        }
        print(json.dumps(out))


if __name__ == "__main__":
    main()
