#!/usr/bin/env python3
"""Test one physically motivated ordinary GSAS-II refinement branch."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_screen import clear_all, fractions, set_bounds, state


def enable_linear(project, hist) -> None:
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--surface", action="store_true")
    group.add_argument("--polarization", action="store_true")
    group.add_argument("--shift", action="store_true")
    group.add_argument("--uiso-all", action="store_true")
    group.add_argument("--uiso-polar", action="store_true")
    group.add_argument("--po", nargs=4, metavar=("PHASE", "H", "K", "L"))
    group.add_argument("--uniax", nargs=4, metavar=("PHASE", "H", "K", "L"))
    group.add_argument("--background-coeffs", type=int)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    clear_all(project, hist)
    set_bounds(project, hist)
    enable_linear(project, hist)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    label = "branch"

    if args.surface:
        label = "surface_roughness"
        hist.SampleParameters["SurfRoughA"] = [0.30, True]
        hist.SampleParameters["SurfRoughB"] = [0.10, True]
        hid = hist.id
        for var, lo, hi in ((f":{hid}:SurfRoughA", 0.05, 0.60),
                            (f":{hid}:SurfRoughB", 0.02, 0.50)):
            project.set_Controls("parmMin", lo, variable=var)
            project.set_Controls("parmMax", hi, variable=var)
    elif args.polarization:
        label = "polarization"
        hist.InstrumentParameters["Polariz."][2] = True
    elif args.shift:
        label = "specimen_shift"
        # Move slightly inside the generation bound so the derivative remains
        # active if the optimum is close to the upper edge.
        hist.SampleParameters["Shift"][0] = min(790.0, hist.SampleParameters["Shift"][0])
        hist.SampleParameters["Shift"][1] = True
    elif args.uiso_all or args.uiso_polar:
        label = "phasewise_common_uiso_polarization" if args.uiso_polar else "phasewise_common_uiso"
        project.data["Constraints"]["data"]["Phase"] = []
        if args.uiso_polar:
            hist.InstrumentParameters["Polariz."][2] = True
        for phase in project.phases():
            variables = []
            for index, atom in enumerate(phase.atoms()):
                atom.data[atom.cia] = "I"
                atom.refinement_flags = "U"
                variables.append(f"{phase.id}::AUiso:{index}")
                project.set_Controls("parmMin", 0.003, variable=variables[-1])
                project.set_Controls("parmMax", 0.020, variable=variables[-1])
            if len(variables) > 1:
                project.add_EquivConstr(variables)
    elif args.po:
        name, h, k, l = args.po
        axis = [int(h), int(k), int(l)]
        label = f"po_{name}_{h}{k}{l}"
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = axis
        var = f"{phase.id}:{hist.id}:MD"
        project.set_Controls("parmMin", 0.70, variable=var)
        project.set_Controls("parmMax", 1.40, variable=var)
    elif args.uniax:
        name, h, k, l = args.uniax
        axis = [int(h), int(k), int(l)]
        label = f"uniax_{name}_{h}{k}{l}"
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        base = max(float(hap["Mustrain"][1][0]), 1.0)
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = base
        hap["Mustrain"][1][1] = min(1.25 * base, 7900.0)
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = axis
        for suffix in ("i", "a"):
            var = f"{phase.id}:{hist.id}:Mustrain;{suffix}"
            project.set_Controls("parmMin", 0.0, variable=var)
            project.set_Controls("parmMax", 8000.0, variable=var)
    elif args.background_coeffs is not None:
        n = args.background_coeffs
        label = f"background_{n}"
        old = list(hist.Background[0][3:])
        hist.set_refinements({"Background": {
            "type": "chebyschev-1", "no. coeffs": n,
            "coeffs": (old + [0.0] * n)[:n], "refine": True,
        }})

    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rec = state(project, hist, label)
    rec["sample"] = {
        "Shift": hist.SampleParameters["Shift"][0],
        "SurfRoughA": hist.SampleParameters["SurfRoughA"][0],
        "SurfRoughB": hist.SampleParameters["SurfRoughB"][0],
    }
    rec["polarization"] = hist.InstrumentParameters["Polariz."][1]
    rec["phase_terms"] = {
        p.name: {
            "uiso": [a.ADP for a in p.atoms()],
            "po_ratio": p.data["Histograms"][hist.name]["Pref.Ori."][1],
            "po_axis": p.data["Histograms"][hist.name]["Pref.Ori."][3],
            "mustrain_type": p.data["Histograms"][hist.name]["Mustrain"][0],
            "mustrain_values": p.data["Histograms"][hist.name]["Mustrain"][1][:2],
            "mustrain_axis": p.data["Histograms"][hist.name]["Mustrain"][3],
        } for p in project.phases()
    }
    print(json.dumps(rec), flush=True)
    clear_all(project, hist)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()
    args.output.with_suffix(".json").write_text(json.dumps({
        "source": str(args.source), "output": str(args.output),
        "record": rec, "fractions": fractions(project, hist),
    }, indent=2) + "\n")


if __name__ == "__main__":
    main()
