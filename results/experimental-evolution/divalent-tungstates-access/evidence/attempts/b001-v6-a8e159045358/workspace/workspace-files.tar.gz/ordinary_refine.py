#!/usr/bin/env python3
"""Stabilize ordinary non-coordinate terms in a selected GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from gsas_screen import clear_all, fractions, set_bounds, state


def run(project, hist, name: str, records: list[dict], cycles: int = 8) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rec = state(project, hist, name)
    records.append(rec)
    print(json.dumps(rec), flush=True)


def enable_linear(project, hist) -> None:
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(args.source), newgpx=str(args.output))
    hist = project.histogram(0)
    set_bounds(project, hist)
    records: list[dict] = []

    clear_all(project, hist)
    enable_linear(project, hist)
    run(project, hist, "linear_settle", records, 8)

    # Refine phase metrics with the physically selected specimen displacement
    # fixed. The common zero remains observable from the full angular range.
    clear_all(project, hist)
    enable_linear(project, hist)
    hist.InstrumentParameters["Zero"][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, hist, "cell_zero_settle", records, 12)

    # Common instrumental profile with phase broadening held fixed.
    clear_all(project, hist)
    enable_linear(project, hist)
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    run(project, hist, "instrument_settle", records, 10)

    # Refine only interior phase-profile terms one phase at a time. Terms on a
    # physical limit are retained at that limit rather than left singular.
    for phase in project.phases():
        clear_all(project, hist)
        enable_linear(project, hist)
        hap = phase.data["Histograms"][hist.name]
        size = float(hap["Size"][1][0])
        strain = float(hap["Mustrain"][1][0])
        if 0.04001 < size < 1.49999:
            hap["Size"][2][0] = True
        if 0.001 < strain < 7999.99:
            hap["Mustrain"][2][0] = True
        if hap["Size"][2][0] or hap["Mustrain"][2][0]:
            run(project, hist, f"profile_{phase.name}", records, 10)

    # One common-profile pass after the phasewise terms have stabilized.
    clear_all(project, hist)
    enable_linear(project, hist)
    for key in ("U", "W", "X", "SH/L"):
        hist.InstrumentParameters[key][2] = True
    run(project, hist, "instrument_resettle", records, 10)

    clear_all(project, hist)
    enable_linear(project, hist)
    hist.InstrumentParameters["Zero"][2] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    run(project, hist, "final_ordinary_settle", records, 12)

    clear_all(project, hist)
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.save()
    result = {
        "source": str(args.source),
        "output": str(args.output),
        "records": records,
        "final": state(project, hist, "final"),
        "fractions": fractions(project, hist),
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
