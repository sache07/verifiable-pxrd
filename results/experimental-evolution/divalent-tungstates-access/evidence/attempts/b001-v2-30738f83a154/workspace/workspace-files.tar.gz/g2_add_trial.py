"""Add one candidate phase to a frozen common GSAS-II state and test its scale."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(project):
    hist = project.histograms()[0]
    x, y, w, calc = [np.asarray(v, float) for v in hist.data["data"][1][:4]]
    return float(100 * np.sqrt(np.sum((y - calc) ** 2 / np.maximum(y, 1)) / np.sum(y)))


def phase_summary(project):
    hist = project.histograms()[0]
    vals = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        vals.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_scale": float(hap["Scale"][0] * phase.data["General"]["Mass"]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "size": [hap["Size"][0], [float(v) for v in hap["Size"][1]]],
                "mustrain": [hap["Mustrain"][0], [float(v) for v in hap["Mustrain"][1]]],
            }
        )
    positive = [max(v["mass_scale"], 0) for v in vals]
    total = sum(positive)
    for rec, value in zip(vals, positive):
        rec["weight_fraction"] = value / total if total else None
    return vals


def freeze_existing(project):
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for hap in phase.data["Histograms"].values():
            hap["Scale"][1] = False
            hap["Size"][2] = [False] * len(hap["Size"][2])
            hap["Size"][5] = [False] * len(hap["Size"][5])
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
            hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
            hap["Pref.Ori."][2] = False


def fit(project, label, out):
    project.set_Controls("cycles", 10)
    project.refine()
    rec = {"stage": label, "rwp_percent": rwp(project), "phases": phase_summary(project)}
    print(json.dumps(rec, sort_keys=True))
    shutil.copy2(project.filename, out / f"{label}.gpx")
    return rec


def main():
    if len(sys.argv) != 6:
        raise SystemExit("usage: g2_add_trial.py BASE.gpx OUTDIR NAME CIF MODE")
    base, out, name, cif, mode = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4]), sys.argv[5]
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(base.resolve()))
    project.save(str((out / "trial.gpx").resolve()))
    freeze_existing(project)
    before = {"stage": "common_state", "rwp_percent": rwp(project), "phases": phase_summary(project)}
    print(json.dumps(before, sort_keys=True))
    hist = project.histograms()[0]
    candidate = project.add_phase(str(cif.resolve()), phasename=name, histograms=[hist], fmthint="CIF")
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"][0] = 1.0
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    candidate.set_HAP_refinements({"Scale": True})
    history = [before, fit(project, "candidate_scale", out)]
    if mode in {"cell", "profile", "full"}:
        candidate = project.phase(name)
        candidate.set_refinements({"Cell": True})
        history.append(fit(project, "candidate_cell", out))
    if mode in {"profile", "full"}:
        candidate = project.phase(name)
        candidate.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 1.0, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        history.append(fit(project, "candidate_profile", out))
    project.save(str(out / "trial.gpx"))
    (out / "summary.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
