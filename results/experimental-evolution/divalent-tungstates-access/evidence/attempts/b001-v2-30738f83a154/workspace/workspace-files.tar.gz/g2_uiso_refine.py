"""Refine one physically bounded scalar Uiso per phase."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import clear_flags, physical_limits, set_limit, summary


def prepare(project):
    clear_flags(project)
    physical_limits(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.set_Frozen()


def run(project, cycles=18):
    project.set_Controls("cycles", cycles)
    project.refine()


def safe(value):
    return value.replace("/", "_").replace(" ", "_")


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_uiso_refine.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    current = out / "accepted_0.gpx"
    shutil.copy2(base, current)
    initial = G2.G2Project(gpxfile=str(current))
    initial_record = summary(initial, "initial")
    current_rwp = initial_record["rwp_percent"]
    records = [initial_record]
    accepted = []
    fractions = {item["name"]: item["weight_fraction"] for item in initial_record["phases"]}

    for step, phase_name in enumerate(sorted(fractions, key=fractions.get, reverse=True), 1):
        path = out / f"trial_{step}_{safe(phase_name)}.gpx"
        trial = G2.G2Project(gpxfile=str(current))
        trial.save(str(path))
        prepare(trial)
        phase = trial.phase(phase_name)
        pid = int(phase.data["pId"])
        phase.set_refinements({"Atoms": {"all": "U"}})
        variables = []
        for atom_index in range(len(phase.atoms())):
            variable = f"{pid}::AUiso:{atom_index}"
            variables.append(variable)
            set_limit(trial, variable, 0.003, 0.020)
        trial.add_EquivConstr(tuple(variables))
        trial.set_Frozen()
        run(trial)
        record = summary(trial, f"uiso:{phase_name}")
        uiso = float(phase.atoms()[0].data[phase.data["General"]["AtomPtrs"][3] + 1])
        record.update(phase=phase_name, uiso_A2=uiso)
        records.append(record)
        if record["rwp_percent"] < current_rwp - 0.003:
            current = out / f"accepted_{step}.gpx"
            shutil.copy2(path, current)
            current_rwp = record["rwp_percent"]
            accepted.append({"phase": phase_name, "uiso_A2": uiso, "rwp_percent": current_rwp})

    shutil.copy2(current, out / "best.gpx")
    result = {"initial": initial_record, "accepted": accepted, "final_rwp_percent": current_rwp, "trials": records}
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
