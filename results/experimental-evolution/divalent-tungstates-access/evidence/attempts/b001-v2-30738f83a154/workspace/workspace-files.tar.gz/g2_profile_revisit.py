"""Re-equilibrate phase size and physically valid isotropic strain states."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import clear_flags, physical_limits, set_limit, summary


ACTIVE_STARTS = (300.0, 2000.0, 6000.0)


def prepare(project):
    clear_flags(project)
    physical_limits(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.set_Frozen()


def run(project, cycles=18):
    project.set_Controls("cycles", cycles)
    project.refine()


def safe(value):
    return value.replace("/", "_").replace(" ", "_")


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_profile_revisit.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    current = out / "accepted_0.gpx"
    shutil.copy2(base, current)
    initial = G2.G2Project(gpxfile=str(current))
    initial_record = summary(initial, "initial")
    current_rwp = initial_record["rwp_percent"]
    records = [initial_record]
    accepted = []

    names = [phase.name for phase in initial.phases()]
    order = sorted(names, key=lambda name: ("Mn3WO6" not in name, name != "WO3", name))
    for step, phase_name in enumerate(order, 1):
        candidates = []
        for label, start in [("inactive", 0.0)] + [(f"active_{int(v)}", v) for v in ACTIVE_STARTS]:
            path = out / f"trial_{step}_{safe(phase_name)}_{label}.gpx"
            trial = G2.G2Project(gpxfile=str(current))
            trial.save(str(path))
            prepare(trial)
            phase = trial.phase(phase_name)
            pid = int(phase.data["pId"])
            hap = phase.data["Histograms"][trial.histograms()[0].name]
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = start
            hap["Mustrain"][1][1] = start
            if label == "inactive":
                phase.clear_HAP_refinements({"Mustrain": True})
            else:
                set_limit(trial, f"{pid}:0:Mustrain;i", 300.0, 8000.0)
                phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
            # Revisit size jointly because it is correlated with Lorentzian strain.
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
            trial.set_Frozen()
            run(trial)
            record = summary(trial, f"{phase_name}:{label}")
            record.update(phase=phase_name, model=label)
            records.append(record)
            candidates.append((record, path))

        best_record, best_path = min(candidates, key=lambda item: item[0]["rwp_percent"])
        if best_record["rwp_percent"] < current_rwp - 0.01:
            current = out / f"accepted_{step}.gpx"
            shutil.copy2(best_path, current)
            current_rwp = best_record["rwp_percent"]
            accepted.append(
                {"phase": phase_name, "model": best_record["model"], "rwp_percent": current_rwp}
            )

    shutil.copy2(current, out / "best.gpx")
    result = {"initial": initial_record, "accepted": accepted, "final_rwp_percent": current_rwp, "trials": records}
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
