"""Common-state replacement test for a physically sound WO3 reference."""

from pathlib import Path
import copy
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import clear_flags, physical_limits, set_limit, summary


def main():
    if len(sys.argv) != 5:
        raise SystemExit("usage: g2_replace_wo3.py BASE.gpx OUTDIR NAME CIF")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    name = sys.argv[3]
    cif = Path(sys.argv[4]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    path = out / "working.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(base))
    project.save(str(path))
    clear_flags(project)
    physical_limits(project)
    hist = project.histograms()[0]
    old = project.phase("WO3")
    old_hap = copy.deepcopy(old.data["Histograms"][hist.name])
    old_uiso = float(old.atoms()[0].data[old.data["General"]["AtomPtrs"][3] + 1])
    old_hap["Scale"] = [0.0, False]
    old.data["Histograms"][hist.name]["Scale"] = [0.0, False]

    candidate = project.add_phase(str(cif), phasename=name, histograms=[hist], fmthint="CIF")
    # Transfer the established specimen profile and mass scale, but retain the
    # candidate's own cell and atoms.
    candidate_hap = candidate.data["Histograms"][hist.name]
    for key in ["Size", "Mustrain", "Pref.Ori."]:
        candidate_hap[key] = copy.deepcopy(old_hap[key])
    candidate_hap["Scale"] = [
        float(26.591746109646536 * old.data["General"]["Mass"] / candidate.data["General"]["Mass"]),
        True,
    ]
    cia = candidate.data["General"]["AtomPtrs"][3]
    for atom in candidate.atoms():
        atom.data[cia] = "I"
        atom.data[cia + 1] = old_uiso
        atom.refinement_flags = " "
    pid = int(candidate.data["pId"])
    set_limit(project, f"{pid}:0:Scale", 0.0, 1e6)
    set_limit(project, f"{pid}:0:Size;i", 0.04, 1.5)
    set_limit(project, f"{pid}:0:Mustrain;i", 300.0, 8000.0)
    set_limit(project, f"{pid}:0:Mustrain;a", 75.0, 32000.0)
    set_limit(project, f"{pid}:0:MD", 0.7, 1.4)
    project.set_Frozen()
    history = []

    candidate.set_refinements({"Cell": True})
    project.set_Controls("cycles", 30)
    project.refine()
    history.append(summary(project, "replacement_scale_cell"))

    candidate.clear_refinements({"Cell": True})
    hap = candidate.data["Histograms"][hist.name]
    candidate.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    candidate.set_HAP_refinements(
        {"Mustrain": {"type": hap["Mustrain"][0], "refine": True}}
    )
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    project.refine()
    history.append(summary(project, "replacement_profile"))
    project.save()
    shutil.copy2(path, out / "best.gpx")
    (out / "summary.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    main()
