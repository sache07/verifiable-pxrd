from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from scipy.ndimage import gaussian_filter1d, percentile_filter
from scipy.signal import find_peaks, peak_widths


data = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1)
x, y = data.T
step = float(np.median(np.diff(x)))

# A broad rolling percentile is used only to expose the peak inventory; the
# background used for refinement is handled in GSAS-II.
background = percentile_filter(y, percentile=20, size=401, mode="nearest")
net = gaussian_filter1d(y - background, 1.2)
peaks, props = find_peaks(net, prominence=150, distance=max(2, round(0.06 / step)))
width_samples = peak_widths(net, peaks, rel_height=0.5)[0]
order = np.argsort(props["prominences"])[::-1]

print("rank,two_theta,intensity,net_height,prominence,fwhm_deg")
for rank, idx in enumerate(order[:100], 1):
    i = peaks[idx]
    print(
        f"{rank},{x[i]:.6f},{y[i]:.1f},{net[i]:.1f},"
        f"{props['prominences'][idx]:.1f},{width_samples[idx] * step:.4f}"
    )

fig, axes = plt.subplots(2, 1, figsize=(14, 8), constrained_layout=True)
axes[0].plot(x, y, lw=0.55, color="black")
axes[0].plot(x, background, lw=0.8, color="tab:orange")
axes[0].set(xlim=(x[0], x[-1]), ylabel="counts")
axes[1].plot(x, net, lw=0.55, color="black")
axes[1].plot(x[peaks], net[peaks], ".", ms=3, color="tab:red")
axes[1].set(xlim=(x[0], x[-1]), xlabel=r"$2\theta$ (deg)", ylabel="net counts")
fig.savefig("pattern_diagnostic.png", dpi=180)
