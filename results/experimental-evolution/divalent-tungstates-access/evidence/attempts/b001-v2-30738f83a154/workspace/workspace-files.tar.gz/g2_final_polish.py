"""Ordinary staged refinement with physical-state checks and rollback."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import clear_flags, physical_limits, set_limit, summary


def prepare(project):
    clear_flags(project)
    physical_limits(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        pid = int(phase.data["pId"])
        set_limit(project, f"{pid}:0:Mustrain;i", 300.0, 8000.0)
        set_limit(project, f"{pid}:0:Mustrain;a", 75.0, 32000.0)
        for atom_index in range(len(phase.atoms())):
            set_limit(project, f"{pid}::AUiso:{atom_index}", 0.003, 0.020)
    project.set_Frozen()


def valid(project, record):
    if record["background_min"] < -1e-6 or record["calculated_min"] < 0:
        return False
    instrument = record["instrument"]
    if not (-0.250001 <= instrument["Zero"] <= 0.250001):
        return False
    if not (0.499999 <= instrument["Polariz."] <= 1.000001):
        return False
    sample = record["sample"]
    if not (-800.001 <= sample["Shift"] <= 800.001):
        return False
    if not (0.0 <= sample["SurfRoughA"] <= 0.600001 and 0.019999 <= sample["SurfRoughB"] <= 0.500001):
        return False
    for phase_record in record["phases"]:
        size = phase_record["size"][1][0]
        if not 0.039999 <= size <= 1.500001:
            return False
        model, values, _axis = phase_record["mustrain"]
        equatorial = values[0]
        if not 299.999 <= equatorial <= 8000.001:
            return False
        if model == "uniaxial":
            ratio = values[1] / equatorial
            if not 0.249999 <= ratio <= 4.000001:
                return False
        ratio = phase_record["preferred_orientation"][0]
        if not 0.699999 <= ratio <= 1.400001:
            return False
    for phase in project.phases():
        cia = phase.data["General"]["AtomPtrs"][3]
        if any(not 0.002999 <= atom.data[cia + 1] <= 0.020001 for atom in phase.atoms()):
            return False
    return True


def configure(project, label):
    hist = project.histograms()[0]
    if label == "texture":
        for phase in project.phases():
            phase.set_HAP_refinements({"Pref.Ori.": True})
    elif label == "roughness":
        hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
    elif label == "polarization":
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    elif label == "uiso":
        for phase in project.phases():
            phase.set_refinements({"Atoms": {"all": "U"}})
    elif label == "sizes":
        for phase in project.phases():
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif label == "microstrain":
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            phase.set_HAP_refinements({"Mustrain": {"type": hap["Mustrain"][0], "refine": True}})
    elif label == "gaussian_profile":
        hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    elif label == "lorentzian_profile":
        hist.set_refinements({"Instrument Parameters": ["X"]})
    elif label == "cells":
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
    elif label == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif label == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    elif label == "scale_background":
        pass
    else:
        raise ValueError(label)
    project.set_Frozen()


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_final_polish.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    current = out / "accepted_0.gpx"
    shutil.copy2(base, current)
    baseline_project = G2.G2Project(gpxfile=str(current))
    baseline = summary(baseline_project, "baseline")
    current_rwp = baseline["rwp_percent"]
    records = [dict(baseline, accepted=True)]
    accepted_count = 0
    stages = [
        "scale_background",
        "texture",
        "roughness",
        "polarization",
        "uiso",
        "sizes",
        "microstrain",
        "gaussian_profile",
        "lorentzian_profile",
        "cells",
        "shift",
        "zero",
        "scale_background",
    ]
    for number, label in enumerate(stages, 1):
        path = out / f"trial_{number:02d}_{label}.gpx"
        trial = G2.G2Project(gpxfile=str(current))
        trial.save(str(path))
        prepare(trial)
        configure(trial, label)
        trial.set_Controls("cycles", 20 if label in {"uiso", "sizes", "microstrain", "cells"} else 14)
        trial.refine()
        record = summary(trial, label)
        accept = valid(trial, record) and record["rwp_percent"] <= current_rwp + 1e-6
        record["accepted"] = accept
        records.append(record)
        if accept:
            accepted_count += 1
            current = out / f"accepted_{accepted_count}.gpx"
            shutil.copy2(path, current)
            current_rwp = record["rwp_percent"]

    shutil.copy2(current, out / "best.gpx")
    final = G2.G2Project(gpxfile=str(out / "best.gpx"))
    result = {
        "baseline": baseline,
        "final": summary(final, "final"),
        "accepted_stages": [record["stage"] for record in records[1:] if record["accepted"]],
        "history": records,
    }
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
