"""Build a first-pass one-phase GSAS-II refinement for phase discovery."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RUN = ROOT / "scratch_one_phase"
RUN.mkdir(exist_ok=True)
PATTERN = ROOT / "inputs" / "pattern.csv"
CIF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif/1/52/02/1520200.cif"
)


def prepare_inputs():
    a = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    x, y = a.T
    sig = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(RUN / "pattern.xye", np.column_stack([x, y, sig]), fmt="%.8f %.8f %.8f")
    (RUN / "instrument.instprm").write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.35;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return x, y


def quality(project, label):
    hist = project.histograms()[0]
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    rwp = 100 * np.sqrt(np.sum((y - calc) ** 2 / np.maximum(y, 1)) / np.sum(y))
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    vals = {
        "label": label,
        "rwp_percent": float(rwp),
        "zero": float(inst["Zero"][1]),
        "U": float(inst["U"][1]),
        "V": float(inst["V"][1]),
        "W": float(inst["W"][1]),
        "X": float(inst["X"][1]),
        "SH/L": float(inst["SH/L"][1]),
        "shift_um": float(sample["Shift"][0]),
        "background_min": float(np.min(bkg)),
        "calculated_min": float(np.min(calc)),
    }
    ph = project.phases()[0]
    vals["cell"] = [float(v) for v in ph.data["General"]["Cell"][1:]]
    vals["hap_scale"] = float(ph.data["Histograms"][hist.name]["Scale"][0])
    print(json.dumps(vals, sort_keys=True))


def cycle(project, label):
    project.set_Controls("cycles", 6)
    project.refine()
    quality(project, label)


def main():
    G2.SetPrintLevel("warn")
    x, y = prepare_inputs()
    gpx = RUN / "one_phase.gpx"
    if gpx.exists():
        gpx.unlink()
    project = G2.G2Project(newgpx=str(gpx))
    phase = project.add_phase(str(CIF), phasename="MnWO4_wolframite", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(RUN / "pattern.xye"), str(RUN / "instrument.instprm"),
        phases=[phase], fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [float(np.percentile(y, 15))] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    phase.set_HAP_refinements({"Scale": True})
    cycle(project, "scale_background")

    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    cycle(project, "zero")

    phase = project.phases()[0]
    phase.set_refinements({"Cell": True})
    cycle(project, "cell")

    hist = project.histograms()[0]
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    cycle(project, "shift")

    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    cycle(project, "instrument_profile")

    phase = project.phases()[0]
    hap = phase.data["Histograms"][project.histograms()[0].name]
    hap["Size"][1][0] = 1.0
    hap["Mustrain"][1][0] = 1000.0
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 1.0, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    cycle(project, "phase_broadening")

    project.save(str(gpx))
    project.phases()[0].export_CIF(str(RUN / "MnWO4_one_phase.cif"))
    hist = project.histograms()[0]
    arrays = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    np.savetxt(
        RUN / "fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4]]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )


if __name__ == "__main__":
    main()
