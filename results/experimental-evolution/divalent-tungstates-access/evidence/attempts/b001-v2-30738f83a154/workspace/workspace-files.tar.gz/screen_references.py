"""Summarize and score chemically ordinary reference phases against the data."""

from pathlib import Path
import gzip
import json

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d, percentile_filter


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
CIF_ROOT = INDEX.parent / "cif"


def cif_path(cod_id):
    s = str(cod_id)
    return CIF_ROOT / s[0] / s[1:3] / s[3:5] / f"{s}.cif"


def main():
    index = json.load(gzip.open(INDEX, "rt"))
    x, y = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1).T
    baseline = percentile_filter(y, percentile=20, size=401, mode="nearest")
    net = np.maximum(gaussian_filter1d(y - baseline, 1.5), 0)
    calc = XRDCalculator(wavelength="CuKa1")
    requested = []
    for system, formulas in {
        "Mn-O-W": {"MnWO4"},
        "Mn-O": {"Mn3O4", "MnO", "Mn2O3", "MnO2"},
        "O-W": {"WO3", "W18O49", "W10O29", "W17O47", "W3O8", "W3O10", "WO2"},
    }.items():
        for formula, cod_id, sg, rf in index.get(system, []):
            if formula in formulas:
                requested.append((formula, str(cod_id), sg, rf))

    for formula, cod_id, sg_index, rf in requested:
        path = cif_path(cod_id)
        try:
            structure = CifParser(path, occupancy_tolerance=2).parse_structures(primitive=False)[0]
            pattern = calc.get_pattern(structure, two_theta_range=(9.9, 100.1))
        except Exception as exc:
            print(json.dumps({"formula": formula, "cod": cod_id, "error": str(exc)}))
            continue
        sticks_x = np.asarray(pattern.x)
        sticks_y = np.asarray(pattern.y)
        # Position-only/intensity-weighted score. A common +0.3 degree offset is
        # expected; optimize a small rigid offset for this screening step.
        best = None
        for offset in np.linspace(-0.2, 0.7, 181):
            vals = np.interp(sticks_x + offset, x, net, left=0, right=0)
            score = float(np.sum(sticks_y * vals) / max(np.sum(sticks_y), 1))
            if best is None or score > best[0]:
                best = (score, float(offset))
        top = np.argsort(sticks_y)[::-1][:12]
        rec = {
            "formula": formula,
            "cod": cod_id,
            "sg_index": sg_index,
            "sg_parsed": structure.get_space_group_info(),
            "cell": [round(v, 5) for v in structure.lattice.abc]
            + [round(v, 4) for v in structure.lattice.angles],
            "volume": round(structure.volume, 5),
            "score": round(best[0], 2),
            "offset": round(best[1], 3),
            "top_sticks": [
                [round(float(sticks_x[i]), 3), round(float(sticks_y[i]), 1)] for i in top
            ],
        }
        print(json.dumps(rec))


if __name__ == "__main__":
    main()
