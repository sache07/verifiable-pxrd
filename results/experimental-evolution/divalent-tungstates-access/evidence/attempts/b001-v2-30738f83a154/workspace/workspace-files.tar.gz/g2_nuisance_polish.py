"""Converge accepted texture, then compare bounded polarization/roughness models."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import clear_flags, physical_limits, summary


def prepare(project, texture=False):
    clear_flags(project)
    physical_limits(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if texture:
            phase.set_HAP_refinements({"Pref.Ori.": True})
    project.set_Frozen()


def run(project, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_nuisance_polish.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    records = []

    texture_path = out / "texture_converged.gpx"
    project = G2.G2Project(gpxfile=str(base))
    project.save(str(texture_path))
    prepare(project, texture=True)
    run(project, 24)
    records.append(summary(project, "texture_converged"))

    # Polarization is a whole-pattern angular intensity correction and is
    # determined before comparing the two surface-roughness states.
    for phase in project.phases():
        phase.clear_HAP_refinements({"Pref.Ori.": True})
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Frozen()
    run(project, 16)
    records.append(summary(project, "polarization"))
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    project.save()

    roughness_trials = []
    starts = [(0.0, 0.0), (0.08, 0.03), (0.15, 0.08), (0.35, 0.18), (0.55, 0.40)]
    for index, (a0, b0) in enumerate(starts):
        path = out / f"roughness_{index}.gpx"
        trial = G2.G2Project(gpxfile=str(texture_path))
        # texture_path has been updated in place through the polarization stage.
        trial.save(str(path))
        prepare(trial, texture=False)
        sample = trial.histograms()[0].data["Sample Parameters"]
        sample["SurfRoughA"][0] = a0
        sample["SurfRoughB"][0] = b0
        if a0 == 0.0 and b0 == 0.0:
            run(trial, 12)
        else:
            trial.histograms()[0].set_refinements(
                {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
            )
            trial.set_Frozen()
            run(trial, 20)
        record = summary(trial, f"roughness_{index}")
        record["start"] = [a0, b0]
        roughness_trials.append((record, path))
        records.append(record)

    best_record, best_path = min(roughness_trials, key=lambda item: item[0]["rwp_percent"])
    shutil.copy2(best_path, out / "best.gpx")
    result = {"history": records, "best": best_record, "best_project": str(best_path)}
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
