"""Residual-directed screen of AB(O4) framework transfers to MnWO4.

This is a broad search step. Ranked candidates are subsequently tested as
atomic phases in the same multiphase GSAS-II project.
"""

from pathlib import Path
import gzip
import json
import math
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
CIF_ROOT = INDEX.parent / "cif"
FIT = Path("scratch_mnwo4_wo3/fit.csv")


def cif_path(cod_id):
    s = str(cod_id)
    return CIF_ROOT / s[0] / s[1:3] / s[3:5] / f"{s}.cif"


def is_ab_o4(formula):
    try:
        comp = Composition(formula).fractional_composition.get_el_amt_dict()
    except Exception:
        return False
    non_o = [e for e in comp if e != "O"]
    return (
        len(non_o) == 2
        and abs(comp.get("O", 0) - 4 / 6) < 1e-6
        and all(abs(comp[e] - 1 / 6) < 1e-6 for e in non_o)
    )


def mappings(elements):
    a, b = elements
    if set(elements) == {"Mn", "W"}:
        return [({"Mn": "Mn", "W": "W"}, 0)]
    if "W" in elements:
        other = a if b == "W" else b
        return [({"W": "W", other: "Mn"}, 1)]
    if "Mn" in elements:
        other = a if b == "Mn" else b
        return [({"Mn": "Mn", other: "W"}, 1)]
    return [({a: "Mn", b: "W"}, 2), ({a: "W", b: "Mn"}, 2)]


def transformed_positions(two_theta, scale, offset):
    arg = np.sin(np.deg2rad(two_theta / 2)) / scale
    valid = np.abs(arg) < 1
    out = np.full_like(two_theta, np.nan, dtype=float)
    out[valid] = np.rad2deg(2 * np.arcsin(arg[valid])) + offset
    return out


def main():
    x, observed, calculated, residual, background = np.loadtxt(FIT, delimiter=",", skiprows=1).T
    step = float(np.median(np.diff(x)))
    # Dot product of a candidate Gaussian profile and the residual can be
    # sampled from this convolution. Two widths cover sharp and broad phases.
    smoothed = {
        fwhm: gaussian_filter1d(residual, (fwhm / 2.35482) / step)
        for fwhm in (0.22, 0.45)
    }
    index = json.load(gzip.open(INDEX, "rt"))
    rows = []
    for system, records in index.items():
        elements = system.split("-")
        if "O" not in elements or len(elements) != 3:
            continue
        for formula, cod_id, sg_index, r_factor in records:
            if is_ab_o4(formula):
                rows.append((formula, str(cod_id), sg_index, r_factor, [e for e in elements if e != "O"]))
    calc = XRDCalculator(wavelength="CuKa1")
    results = []
    errors = 0
    for num, (formula, cod_id, sg_index, r_factor, elements) in enumerate(rows, 1):
        path = cif_path(cod_id)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                source = CifParser(path, occupancy_tolerance=1.5).parse_structures(primitive=False)[0]
            if len(source) > 400:
                continue
        except Exception:
            errors += 1
            continue
        for mapping, substitutions in mappings(elements):
            try:
                target = source.copy()
                target.remove_oxidation_states()
                target.replace_species({Element(k): Element(v) for k, v in mapping.items() if k != v})
                amounts = target.composition.get_el_amt_dict()
                if set(amounts) != {"Mn", "W", "O"}:
                    continue
                ratio = amounts["Mn"] / amounts["W"]
                if not 0.999 < ratio < 1.001 or not 3.999 < amounts["O"] / amounts["W"] < 4.001:
                    continue
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    pattern = calc.get_pattern(target, two_theta_range=(7, 115))
            except Exception:
                errors += 1
                continue
            px = np.asarray(pattern.x, float)
            py = np.asarray(pattern.y, float)
            keep = py >= 0.35
            px, py = px[keep], py[keep]
            if len(px) < 3:
                continue
            best = None
            for scale in np.linspace(0.82, 1.18, 145):
                for offset in (0.25, 0.32, 0.39, 0.46, 0.53):
                    tx = transformed_positions(px, scale, offset)
                    inside = np.isfinite(tx) & (tx >= x[0]) & (tx <= x[-1])
                    if inside.sum() < 3:
                        continue
                    ii = py[inside]
                    tt = tx[inside]
                    denom = math.sqrt(float(np.sum(ii * ii)))
                    for fwhm, curve in smoothed.items():
                        dot = float(np.sum(ii * np.interp(tt, x, curve)))
                        score = dot / max(denom, 1e-12)
                        if best is None or score > best[0]:
                            best = (score, float(scale), float(offset), float(fwhm), tt, ii)
            if best is None:
                continue
            score, scale, offset, fwhm, tt, ii = best
            order = np.argsort(ii)[::-1][:15]
            try:
                parsed_sg = target.get_space_group_info()
            except Exception:
                parsed_sg = ("unknown", int(sg_index))
            results.append(
                {
                    "score": score,
                    "source_formula": formula,
                    "cod_id": cod_id,
                    "source_path": str(path),
                    "source_sg_index": sg_index,
                    "parsed_space_group": list(parsed_sg),
                    "r_factor": r_factor,
                    "mapping": mapping,
                    "substitutions": substitutions,
                    "isotropic_cell_scale": scale,
                    "offset_deg": offset,
                    "screen_fwhm_deg": fwhm,
                    "source_cell": list(source.lattice.abc) + list(source.lattice.angles),
                    "target_composition": target.composition.formula,
                    "target_sites": len(target),
                    "top_transformed_sticks": [
                        [float(tt[i]), float(ii[i])] for i in order
                    ],
                }
            )
        if num % 50 == 0:
            print(f"screened {num}/{len(rows)} references", flush=True)
    results.sort(key=lambda r: r["score"], reverse=True)
    output = {"references_considered": len(rows), "parse_errors": errors, "results": results}
    Path("prototype_screen.json").write_text(json.dumps(output, indent=2) + "\n")
    for rec in results[:80]:
        print(json.dumps({k: rec[k] for k in ["score", "source_formula", "cod_id", "parsed_space_group", "mapping", "substitutions", "isotropic_cell_scale", "offset_deg", "screen_fwhm_deg", "top_transformed_sticks"]}))


if __name__ == "__main__":
    main()
