"""Build chemically plausible Mn-W-O residual-phase prototype transfers."""

from pathlib import Path
import json
import sys
import warnings

import numpy as np
from pymatgen.core import Element
from pymatgen.io.cif import CifParser


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model


def cod_path(cod):
    code = str(cod)
    return ROOT / code[0] / code[1:3] / code[3:5] / f"{code}.cif"


CANDIDATES = [
    # Exact Mn framework with the single chemically conservative Te(VI)->W(VI)
    # replacement. This is the leading residual-indexing solution.
    ("r3_Mn3WO6", "2211528", {"Te": "W"}, 1.0025),
    # Distinct monoclinic polymorphs of the same M3TeO6 family.
    ("c2c_Mn3WO6_from_Co", "2015468", {"Co": "Mn", "Te": "W"}, 1.0025),
    ("c2c_Mn3WO6_from_Zn", "2211529", {"Zn": "Mn", "Te": "W"}, 1.0075),
    # Charge-balanced alternative composition matching the same low-angle pair.
    ("pnnm_Mn2WO5", "9000178", {"As": "W"}, 1.0075),
    # Mn(III)2WO6 is charge balanced and occurs in more than one oxide family;
    # keep both an orthorhombic and a tetragonal framework in the trial set.
    ("p212121_Mn2WO6", "1541070", {"Y": "Mn"}, 0.9550),
    ("p4nmm_Mn2WO6", "1563285", {"Y": "Mn"}, 0.9150),
    # Reduced Mn-W-O possibilities selected by the residual-stick screen. These
    # are retained for common-state testing, but require stricter geometry and
    # unmatched-reflection scrutiny than the charge-balanced candidates above.
    ("p3m1_MnW2O6", "1530311", {"Ni": "Mn", "I": "W"}, 1.1300),
    ("p4cc_MnW2O6", "2101589", {"V": "Mn", "Se": "W"}, 0.7850),
]


def geometry(structure):
    distances = structure.distance_matrix.copy()
    distances[distances < 1e-8] = np.inf
    oxygen = [i for i, site in enumerate(structure) if site.species_string == "O"]
    result = {
        "minimum_contact_A": float(np.min(distances)),
        "minimum_O_O_A": float(np.min(distances[np.ix_(oxygen, oxygen)])),
        "coordination": {},
    }
    for element in ("Mn", "W"):
        shells = []
        for i, site in enumerate(structure):
            if site.species_string != element:
                continue
            nearest = sorted(float(distances[i, j]) for j in oxygen)
            shells.append(
                {
                    "nearest_O_A": nearest[:8],
                    "O_within_2.7_A": sum(value <= 2.7 for value in nearest),
                }
            )
        result["coordination"][element] = shells
    return result


def main():
    out = Path("offstoich_transfers")
    out.mkdir(exist_ok=True)
    records = []
    for name, cod, mapping, scale in CANDIDATES:
        source = cod_path(cod)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = CifParser(source, occupancy_tolerance=1.5).parse_structures(
                primitive=False
            )[0]
        structure.remove_oxidation_states()
        structure.replace_species(
            {Element(old): Element(new) for old, new in mapping.items()}
        )
        structure.scale_lattice(structure.volume * scale**3)
        destination = out / f"{name}.cif"
        write_synthetic_model(structure, destination, symprec=0.001)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            check = CifParser(destination).parse_structures(primitive=False)[0]
        record = {
            "name": name,
            "source_cod": cod,
            "source_path": str(source),
            "mapping": mapping,
            "isotropic_scale": scale,
            "output": str(destination),
            "composition": check.composition.formula,
            "space_group": check.get_space_group_info(),
            "cell": list(check.lattice.abc) + list(check.lattice.angles),
            "density_g_cm3": check.density,
            "geometry": geometry(check),
        }
        records.append(record)
        print(json.dumps(record))
    (out / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
