"""Screen charge-balanced Mn-W-O off-stoichiometric framework transfers."""

from pathlib import Path
import gzip
import json
import math
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
CIF_ROOT = INDEX.parent / "cif"

# Reduced source cation populations and oxygen population. Each mapping tuple
# gives the desired target species for the less- and more-populated cations.
TARGETS = {
    ((1.0, 2.0), 5.0): [("W", "Mn", "Mn2WO5")],
    ((1.0, 2.0), 6.0): [("W", "Mn", "Mn2WO6"), ("Mn", "W", "MnW2O6")],
    ((1.0, 3.0), 6.0): [("W", "Mn", "Mn3WO6")],
    ((1.0, 2.0), 7.0): [("Mn", "W", "MnW2O7"), ("W", "Mn", "Mn2WO7")],
    ((2.0, 3.0), 9.0): [("W", "Mn", "Mn3W2O9")],
    ((2.0, 3.0), 11.0): [("Mn", "W", "Mn2W3O11")],
}


def cif_path(cod_id):
    s = str(cod_id)
    return CIF_ROOT / s[0] / s[1:3] / s[3:5] / f"{s}.cif"


def source_signature(formula):
    try:
        comp = Composition(formula).get_reduced_composition_and_factor()[0].get_el_amt_dict()
    except Exception:
        return None
    cations = [(e, float(v)) for e, v in comp.items() if e != "O"]
    if len(cations) != 2:
        return None
    cations.sort(key=lambda item: item[1])
    key = (tuple(round(v, 6) for _, v in cations), round(float(comp.get("O", 0)), 6))
    if key not in TARGETS:
        return None
    return key, cations


def shifted(px, scale, offset):
    arg = np.sin(np.deg2rad(px / 2)) / scale
    valid = np.abs(arg) < 1
    out = np.full_like(px, np.nan)
    out[valid] = np.rad2deg(2 * np.arcsin(arg[valid])) + offset
    return out


def main():
    x, observed, calculated, residual, background = np.loadtxt(
        "scratch_mnwo4_wo3/fit.csv", delimiter=",", skiprows=1
    ).T
    step = float(np.median(np.diff(x)))
    curves = {f: gaussian_filter1d(residual, (f / 2.35482) / step) for f in (0.22, 0.45)}
    index = json.load(gzip.open(INDEX, "rt"))
    rows = []
    for system, records in index.items():
        if "O" not in system.split("-") or len(system.split("-")) != 3:
            continue
        for formula, cod_id, sg_index, r_factor in records:
            sig = source_signature(formula)
            if sig is not None:
                rows.append((formula, str(cod_id), sg_index, r_factor, sig))
    calc = XRDCalculator(wavelength="CuKa1")
    results, errors = [], 0
    for num, (formula, cod_id, sg_index, r_factor, sig) in enumerate(rows, 1):
        key, cations = sig
        source_path = cif_path(cod_id)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                source = CifParser(source_path, occupancy_tolerance=1.5).parse_structures(primitive=False)[0]
            if len(source) > 500:
                continue
        except Exception:
            errors += 1
            continue
        for low_target, high_target, target_formula in TARGETS[key]:
            mapping = {cations[0][0]: low_target, cations[1][0]: high_target}
            try:
                target = source.copy()
                target.remove_oxidation_states()
                target.replace_species({Element(k): Element(v) for k, v in mapping.items()})
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    pattern = calc.get_pattern(target, two_theta_range=(7, 115))
            except Exception:
                errors += 1
                continue
            px, py = np.asarray(pattern.x, float), np.asarray(pattern.y, float)
            keep = py >= 0.35
            px, py = px[keep], py[keep]
            if len(px) < 3:
                continue
            best = None
            for scale in np.linspace(0.72, 1.30, 233):
                for offset in (0.25, 0.32, 0.39, 0.46, 0.53):
                    tx = shifted(px, scale, offset)
                    inside = np.isfinite(tx) & (tx >= x[0]) & (tx <= x[-1])
                    if inside.sum() < 3:
                        continue
                    tt, ii = tx[inside], py[inside]
                    denom = math.sqrt(float(np.sum(ii * ii)))
                    for fwhm, curve in curves.items():
                        score = float(np.sum(ii * np.interp(tt, x, curve))) / max(denom, 1e-12)
                        if best is None or score > best[0]:
                            best = (score, float(scale), float(offset), float(fwhm), tt, ii)
            if best is None:
                continue
            score, scale, offset, fwhm, tt, ii = best
            order = np.argsort(ii)[::-1][:20]
            try:
                parsed_sg = target.get_space_group_info()
            except Exception:
                parsed_sg = ("unknown", int(sg_index))
            results.append(
                {
                    "score": score,
                    "target_formula": target_formula,
                    "source_formula": formula,
                    "cod_id": cod_id,
                    "source_path": str(source_path),
                    "parsed_space_group": list(parsed_sg),
                    "source_sg_index": sg_index,
                    "r_factor": r_factor,
                    "mapping": mapping,
                    "substitutions": sum(k != v for k, v in mapping.items()),
                    "isotropic_cell_scale": scale,
                    "offset_deg": offset,
                    "screen_fwhm_deg": fwhm,
                    "source_cell": list(source.lattice.abc) + list(source.lattice.angles),
                    "target_sites": len(target),
                    "top_transformed_sticks": [[float(tt[i]), float(ii[i])] for i in order],
                }
            )
        if num % 100 == 0:
            print(f"screened {num}/{len(rows)} references", flush=True)
    results.sort(key=lambda r: r["score"], reverse=True)
    Path("ternary_prototype_screen.json").write_text(
        json.dumps({"references_considered": len(rows), "parse_errors": errors, "results": results}, indent=2) + "\n"
    )
    for rec in results[:120]:
        print(json.dumps({k: rec[k] for k in ["score", "target_formula", "source_formula", "cod_id", "parsed_space_group", "mapping", "substitutions", "isotropic_cell_scale", "offset_deg", "screen_fwhm_deg", "top_transformed_sticks"]}))


if __name__ == "__main__":
    main()
