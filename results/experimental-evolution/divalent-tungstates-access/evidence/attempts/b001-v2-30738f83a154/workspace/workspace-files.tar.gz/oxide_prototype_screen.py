"""Residual-directed one/two-substitution framework screen for Mn3O4."""

from pathlib import Path
import gzip
import json
import math
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d


INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/index.json.gz"
)
CIF_ROOT = INDEX.parent / "cif"


def cif_path(cod_id):
    s = str(cod_id)
    return CIF_ROOT / s[0] / s[1:3] / s[3:5] / f"{s}.cif"


def is_m3o4_stoich(formula):
    try:
        comp = Composition(formula).fractional_composition.get_el_amt_dict()
    except Exception:
        return False
    cations = [e for e in comp if e != "O"]
    return (
        1 <= len(cations) <= 2
        and abs(sum(comp[e] for e in cations) - 3 / 7) < 1e-6
        and abs(comp.get("O", 0) - 4 / 7) < 1e-6
    )


def shifted(px, scale, offset):
    arg = np.sin(np.deg2rad(px / 2)) / scale
    valid = np.abs(arg) < 1
    out = np.full_like(px, np.nan)
    out[valid] = np.rad2deg(2 * np.arcsin(arg[valid])) + offset
    return out


def main():
    x, observed, calculated, residual, background = np.loadtxt(
        "scratch_mnwo4_wo3/fit.csv", delimiter=",", skiprows=1
    ).T
    step = float(np.median(np.diff(x)))
    curves = {f: gaussian_filter1d(residual, (f / 2.35482) / step) for f in (0.22, 0.45)}
    index = json.load(gzip.open(INDEX, "rt"))
    rows = []
    for system, records in index.items():
        elements = system.split("-")
        if "O" not in elements or len(elements) > 3:
            continue
        for formula, cod_id, sg_index, r_factor in records:
            if is_m3o4_stoich(formula):
                rows.append((formula, str(cod_id), sg_index, r_factor, [e for e in elements if e != "O"]))
    calc = XRDCalculator(wavelength="CuKa1")
    results, errors = [], 0
    for num, (formula, cod_id, sg_index, r_factor, elements) in enumerate(rows, 1):
        source_path = cif_path(cod_id)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                source = CifParser(source_path, occupancy_tolerance=1.5).parse_structures(primitive=False)[0]
            if len(source) > 400:
                continue
            target = source.copy()
            target.remove_oxidation_states()
            target.replace_species({Element(e): Element("Mn") for e in elements if e != "Mn"})
            amounts = target.composition.get_el_amt_dict()
            if set(amounts) != {"Mn", "O"} or not 1.332 < amounts["O"] / amounts["Mn"] < 1.334:
                continue
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                pattern = calc.get_pattern(target, two_theta_range=(7, 115))
        except Exception:
            errors += 1
            continue
        px, py = np.asarray(pattern.x, float), np.asarray(pattern.y, float)
        keep = py >= 0.35
        px, py = px[keep], py[keep]
        if len(px) < 3:
            continue
        best = None
        for scale in np.linspace(0.72, 1.28, 225):
            for offset in (0.25, 0.32, 0.39, 0.46, 0.53):
                tx = shifted(px, scale, offset)
                inside = np.isfinite(tx) & (tx >= x[0]) & (tx <= x[-1])
                if inside.sum() < 3:
                    continue
                tt, ii = tx[inside], py[inside]
                denom = math.sqrt(float(np.sum(ii * ii)))
                for fwhm, curve in curves.items():
                    score = float(np.sum(ii * np.interp(tt, x, curve))) / max(denom, 1e-12)
                    if best is None or score > best[0]:
                        best = (score, float(scale), float(offset), float(fwhm), tt, ii)
        if best is None:
            continue
        score, scale, offset, fwhm, tt, ii = best
        order = np.argsort(ii)[::-1][:18]
        try:
            parsed_sg = target.get_space_group_info()
        except Exception:
            parsed_sg = ("unknown", int(sg_index))
        results.append(
            {
                "score": score,
                "source_formula": formula,
                "cod_id": cod_id,
                "source_path": str(source_path),
                "source_sg_index": sg_index,
                "parsed_space_group": list(parsed_sg),
                "r_factor": r_factor,
                "substitutions": sum(e != "Mn" for e in elements),
                "source_elements": elements,
                "isotropic_cell_scale": scale,
                "offset_deg": offset,
                "screen_fwhm_deg": fwhm,
                "source_cell": list(source.lattice.abc) + list(source.lattice.angles),
                "target_sites": len(target),
                "top_transformed_sticks": [[float(tt[i]), float(ii[i])] for i in order],
            }
        )
        if num % 100 == 0:
            print(f"screened {num}/{len(rows)} references", flush=True)
    results.sort(key=lambda r: r["score"], reverse=True)
    Path("oxide_prototype_screen.json").write_text(
        json.dumps({"references_considered": len(rows), "parse_errors": errors, "results": results}, indent=2) + "\n"
    )
    for rec in results[:100]:
        print(json.dumps({k: rec[k] for k in ["score", "source_formula", "cod_id", "parsed_space_group", "substitutions", "isotropic_cell_scale", "offset_deg", "screen_fwhm_deg", "top_transformed_sticks"]}))


if __name__ == "__main__":
    main()
