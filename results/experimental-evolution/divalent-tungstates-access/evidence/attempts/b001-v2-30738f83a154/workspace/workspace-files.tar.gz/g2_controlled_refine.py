"""Physically bounded staged refinement of an accepted multiphase project.

Usage: gsas-python g2_controlled_refine.py BASE.gpx OUTDIR
"""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from GSASII import GSASIIscriptable as G2


def arrays(project):
    return [np.asarray(value, float) for value in project.histograms()[0].data["data"][1][:6]]


def summary(project, label):
    hist = project.histograms()[0]
    x, obs, weights, calc, bkg, diff = arrays(project)
    loss = float(np.sum((obs - calc) ** 2 / np.maximum(obs, 1.0)))
    denom = float(np.sum(obs))
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(mass_scale, 0.0))
        phases.append(
            {
                "name": phase.name,
                "mass_scale": mass_scale,
                "scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "size": [str(hap["Size"][0]), [float(v) for v in hap["Size"][1]]],
                "mustrain": [
                    str(hap["Mustrain"][0]),
                    [float(v) for v in hap["Mustrain"][1]],
                    list(hap["Mustrain"][3]),
                ],
                "preferred_orientation": [
                    float(hap["Pref.Ori."][1]),
                    list(hap["Pref.Ori."][3]),
                ],
            }
        )
    total = sum(masses)
    for record, mass in zip(phases, masses):
        record["weight_fraction"] = mass / total if total else None
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    covariance = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": label,
        "rwp_percent": float(100 * np.sqrt(loss / denom)),
        "chi_square_sum": loss,
        "reduced_chi_square": float(loss / max(len(obs) - len(covariance.get("varyList", [])), 1)),
        "background_min": float(np.min(bkg)),
        "calculated_min": float(np.min(calc)),
        "instrument": {
            key: float(inst[key][1])
            for key in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]
        },
        "sample": {
            key: float(sample[key][0])
            for key in ["Shift", "SurfRoughA", "SurfRoughB", "Scale"]
        },
        "phases": phases,
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(result, sort_keys=True), flush=True)
    return result


def save_stage(project, out, label, history):
    record = summary(project, label)
    history.append(record)
    shutil.copy2(project.filename, out / f"stage_{label}.gpx")
    return record


def refine(project, out, label, history, cycles=6):
    project.set_Controls("cycles", cycles)
    project.refine()
    return save_stage(project, out, label, history)


def clear_flags(project):
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
            }
        )
    project.set_Frozen()


def set_limit(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def physical_limits(project):
    # Bounds are the declared ranges of the synthetic laboratory, widened only
    # where zero microstrain is the valid inactive state.
    for variable, low, high in [
        (":0:Zero", -0.25, 0.25),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:Shift", -800.0, 800.0),
        (":0:SurfRoughA", 0.0, 0.60),
        (":0:SurfRoughB", 0.02, 0.50),
    ]:
        set_limit(project, variable, low, high)
    for phase in project.phases():
        pid = int(phase.data["pId"])
        set_limit(project, f"{pid}:0:Scale", 0.0, 1.0e6)
        set_limit(project, f"{pid}:0:Size;i", 0.04, 1.50)
        set_limit(project, f"{pid}:0:Mustrain;i", 0.0, 8000.0)
        set_limit(project, f"{pid}:0:Mustrain;a", 0.0, 8000.0)
        set_limit(project, f"{pid}:0:MD", 0.70, 1.40)


def standardize_adps(project):
    # Registered generator models use one scalar Uiso per phase. Convert legacy
    # anisotropic/zero-valued source CIF fields to that same starting convention.
    for phase in project.phases():
        cia = phase.data["General"]["AtomPtrs"][3]
        for atom in phase.atoms():
            atom.data[cia] = "I"
            atom.data[cia + 1] = 0.005
            atom.refinement_flags = " "


def reset_profiles(project):
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "W": 10.0, "X": 1.0, "SH/L": 0.03}.items():
        inst[key][1] = value
    # Keep the starting total low-angle shift close to the accepted common
    # state while separating the bounded zero and specimen-displacement terms.
    inst["Zero"][1] = 0.15
    hist.data["Sample Parameters"]["Shift"][0] = -400.0
    hist.data["Sample Parameters"]["SurfRoughA"][0] = 0.10
    hist.data["Sample Parameters"]["SurfRoughB"][0] = 0.10
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = [0, 0, 1]


def residual_peaks(project):
    x, obs, weights, calc, bkg, diff = arrays(project)
    smooth = gaussian_filter1d(obs - calc, 1.2)
    peaks, properties = find_peaks(smooth, prominence=100.0, distance=5)
    order = np.argsort(properties["prominences"])[::-1]
    return [
        {
            "two_theta_deg": float(x[peaks[i]]),
            "height": float(smooth[peaks[i]]),
            "prominence": float(properties["prominences"][i]),
        }
        for i in order[:50]
    ]


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_controlled_refine.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    working = out / "working.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(base))
    project.save(str(working))
    project.index_ids()
    clear_flags(project)
    standardize_adps(project)
    reset_profiles(project)
    physical_limits(project)
    history = []
    save_stage(project, out, "reset", history)

    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    refine(project, out, "scale_background", history, 8)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, out, "position_terms", history, 8)

    # Lattice, zero and specimen displacement are nearly collinear if moved
    # together. Alternate them in separate least-squares blocks.
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    project.set_Frozen()

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    refine(project, out, "cells", history, 8)

    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})
    project.set_Frozen()
    refine(project, out, "gaussian_profile", history, 8)

    hist.clear_refinements({"Instrument Parameters": ["U", "W", "SH/L"]})

    hist.set_refinements({"Instrument Parameters": ["X"]})
    project.set_Frozen()
    refine(project, out, "lorentzian_profile", history, 8)
    hist.clear_refinements({"Instrument Parameters": ["X"]})

    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": 0.30, "refine": True}}
        )
    project.set_Frozen()
    refine(project, out, "sizes", history, 10)

    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True})
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    project.set_Frozen()
    refine(project, out, "microstrain", history, 10)

    # Re-equilibrate each profile family once after all broadening terms exist.
    for phase in project.phases():
        phase.clear_HAP_refinements({"Mustrain": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "SH/L", "X"]})
    project.set_Frozen()
    refine(project, out, "instrument_revisit", history, 8)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "SH/L", "X"]})

    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    project.set_Frozen()
    refine(project, out, "sizes_revisit", history, 8)
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.set_Frozen()
    refine(project, out, "microstrain_revisit", history, 8)
    for phase in project.phases():
        phase.clear_HAP_refinements({"Mustrain": True})

    # Keep the bounded zero at its accepted value and update displacement, then
    # update cells in a separate block.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    project.set_Frozen()
    refine(project, out, "shift_revisit", history, 6)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.set_Frozen()
    refine(project, out, "cells_revisit", history, 8)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    project.set_Frozen()
    refine(project, out, "equilibrated", history, 8)
    project.save(str(working))

    final = history[-1]
    final["residual_peaks"] = residual_peaks(project)
    (out / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    (out / "summary.json").write_text(json.dumps(final, indent=2) + "\n")


if __name__ == "__main__":
    main()
