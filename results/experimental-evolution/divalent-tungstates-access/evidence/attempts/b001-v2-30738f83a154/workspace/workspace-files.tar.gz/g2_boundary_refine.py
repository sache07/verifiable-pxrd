"""Refine roughness A while holding a boundary-optimum B exactly fixed."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import summary
from g2_final_polish import prepare


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_boundary_refine.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    path = out / "best.gpx"
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(base))
    project.save(str(path))
    prepare(project)
    hist = project.histograms()[0]
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughB"][0] = 0.5
    sample["SurfRoughB"][1] = False
    hist.set_refinements({"Sample Parameters": ["SurfRoughA"]})
    project.set_Frozen()
    project.set_Controls("cycles", 40)
    project.refine()
    result = summary(project, "roughness_A_with_B_fixed")
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
