"""Create selected MnWO4 prototype-transfer CIFs for common-state trials."""

from pathlib import Path
import json
import sys
import warnings

import numpy as np
from pymatgen.core import Element
from pymatgen.io.cif import CifParser


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c06/cif"
)
sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model


def path(cod):
    s = str(cod)
    return ROOT / s[0] / s[1:3] / s[3:5] / f"{s}.cif"


CANDIDATES = [
    ("p1_BaGeO4", "1530605", {"Ba": "Mn", "Ge": "W"}, 1.1575),
    ("p21m_TiPO4_inverse", "1001530", {"P": "Mn", "Ti": "W"}, 0.9925),
    ("p21m_TiPO4_chemical", "1001530", {"P": "W", "Ti": "Mn"}, 0.8575),
    ("c2c_CaWO4", "1546035", {"Ca": "Mn"}, 0.8500),
    ("pnma_MnPO4", "1529150", {"P": "W"}, 1.0000),
    ("i41a_CdWO4", "1549132", {"Cd": "Mn"}, 0.8350),
    ("p1_ZnWO4", "2101690", {"Zn": "Mn"}, 1.0400),
    ("c2m_AlWO4", "1544388", {"Al": "Mn"}, 0.9900),
    ("pnna_SnWO4", "9007595", {"Sn": "Mn"}, 0.9825),
    ("pnma_BaCrO4", "5910178", {"Ba": "Mn", "Cr": "W"}, 0.9800),
    ("cmcm_CrCdO4", "1008084", {"Cd": "Mn", "Cr": "W"}, 1.1125),
    ("pbcn_ZrTiO4", "1538358", {"Ti": "Mn", "Zr": "W"}, 0.8700),
]


def geometry(structure):
    matrix = structure.distance_matrix.copy()
    matrix[matrix < 1e-8] = np.inf
    min_pair = np.unravel_index(np.argmin(matrix), matrix.shape)
    o = [i for i, site in enumerate(structure) if site.species_string == "O"]
    oo = matrix[np.ix_(o, o)]
    oo_pair = np.unravel_index(np.argmin(oo), oo.shape)
    coordination = {}
    for species in ("Mn", "W"):
        values = []
        for i, site in enumerate(structure):
            if site.species_string != species:
                continue
            d = sorted(float(matrix[i, j]) for j in o)
            values.append({"nearest_O_A": d[:8], "O_within_2.7_A": sum(v <= 2.7 for v in d)})
        coordination[species] = values
    return {
        "minimum_contact_A": float(matrix[min_pair]),
        "minimum_contact_species": [structure[min_pair[0]].species_string, structure[min_pair[1]].species_string],
        "minimum_O_O_A": float(oo[oo_pair]),
        "coordination": coordination,
    }


def main():
    out = Path("transfers")
    out.mkdir(exist_ok=True)
    records = []
    for name, cod, mapping, scale in CANDIDATES:
        src = path(cod)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = CifParser(src, occupancy_tolerance=1.5).parse_structures(primitive=False)[0]
        structure.remove_oxidation_states()
        structure.replace_species({Element(k): Element(v) for k, v in mapping.items()})
        structure.scale_lattice(structure.volume * scale ** 3)
        dest = out / f"{name}.cif"
        write_synthetic_model(structure, dest, symprec=0.001)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            check = CifParser(dest).parse_structures(primitive=False)[0]
        rec = {
            "name": name,
            "source_cod": cod,
            "source_path": str(src),
            "mapping": mapping,
            "isotropic_scale": scale,
            "output": str(dest),
            "composition": check.composition.formula,
            "space_group": check.get_space_group_info(),
            "cell": list(check.lattice.abc) + list(check.lattice.angles),
            "density_g_cm3": check.density,
            "geometry": geometry(check),
        }
        records.append(rec)
        print(json.dumps(rec))
    (out / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
