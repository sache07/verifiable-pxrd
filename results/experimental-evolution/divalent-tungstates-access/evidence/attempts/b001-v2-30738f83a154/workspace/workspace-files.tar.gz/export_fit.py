"""Export the independently replayed full-grid profile as fit.csv."""

from pathlib import Path
import sys

import numpy as np


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: export_fit.py PREDICTION.npz FIT.csv")
    source = Path(sys.argv[1])
    target = Path(sys.argv[2])
    with np.load(source, allow_pickle=False) as data:
        x = data["x"]
        observed = data["observed"]
        calculated = data["predicted"]
        background = data["background"]
    table = np.column_stack(
        [x, observed, calculated, observed - calculated, background]
    )
    np.savetxt(
        target,
        table,
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )
    print(f"wrote {len(table)} rows to {target}")


if __name__ == "__main__":
    main()
