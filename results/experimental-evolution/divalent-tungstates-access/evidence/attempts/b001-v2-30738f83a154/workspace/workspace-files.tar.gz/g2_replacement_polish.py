"""Replay-safe ordinary polish after replacing the unphysical WO3 reference."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import clear_flags, physical_limits, set_limit, summary


def active_phases(project):
    hist = project.histograms()[0]
    return [p for p in project.phases() if p.data["Histograms"][hist.name]["Scale"][0] > 1e-8]


def prepare(project):
    clear_flags(project)
    physical_limits(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if phase.name == "WO3":
            hap["Scale"] = [0.0, False]
            continue
        phase.set_HAP_refinements({"Scale": True})
        pid = int(phase.data["pId"])
        set_limit(project, f"{pid}:0:Mustrain;i", 300.0, 8000.0)
        set_limit(project, f"{pid}:0:Mustrain;a", 75.0, 32000.0)
    project.set_Frozen()


def configure(project, label):
    hist = project.histograms()[0]
    phases = active_phases(project)
    if label == "texture":
        for phase in phases:
            phase.set_HAP_refinements({"Pref.Ori.": True})
    elif label == "roughness_A":
        hist.data["Sample Parameters"]["SurfRoughB"] = [0.5, False]
        hist.set_refinements({"Sample Parameters": ["SurfRoughA"]})
    elif label == "sizes":
        for phase in phases:
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    elif label == "microstrain":
        for phase in phases:
            model = phase.data["Histograms"][hist.name]["Mustrain"][0]
            phase.set_HAP_refinements({"Mustrain": {"type": model, "refine": True}})
    elif label == "gaussian_profile":
        # U is already at its physical upper boundary; refine only the interior terms.
        hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    elif label == "lorentzian_profile":
        hist.set_refinements({"Instrument Parameters": ["X"]})
    elif label == "cells":
        for phase in phases:
            phase.set_refinements({"Cell": True})
    elif label == "shift":
        hist.set_refinements({"Sample Parameters": ["Shift"]})
    elif label == "zero":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
    elif label == "scale_background":
        pass
    else:
        raise ValueError(label)
    project.set_Frozen()


def valid(project, record):
    if record["background_min"] < 0 or record["calculated_min"] < 0:
        return False
    for phase in active_phases(project):
        hap = phase.data["Histograms"][project.histograms()[0].name]
        if not 0.04 - 1e-8 <= hap["Size"][1][0] <= 1.5 + 1e-8:
            return False
        eq = hap["Mustrain"][1][0]
        if not 300 - 1e-6 <= eq <= 8000 + 1e-6:
            return False
        # Permit pronounced but finite anisotropy; the WO3 replacement enters
        # the common-state fit at a reproducible ratio near 0.18.
        if hap["Mustrain"][0] == "uniaxial" and not 0.125 - 1e-6 <= hap["Mustrain"][1][1] / eq <= 8 + 1e-6:
            return False
        if not 0.7 - 1e-6 <= hap["Pref.Ori."][1] <= 1.4 + 1e-6:
            return False
    return True


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_replacement_polish.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    current = out / "accepted_0.gpx"
    project = G2.G2Project(gpxfile=str(base))
    project.phase("WO3").data["Histograms"][project.histograms()[0].name]["Scale"] = [0.0, False]
    project.save(str(current))
    baseline = summary(project, "baseline")
    current_rwp = baseline["rwp_percent"]
    history = [dict(baseline, accepted=True)]
    accepted_count = 0
    stages = ["scale_background", "texture", "roughness_A", "sizes", "microstrain",
              "gaussian_profile", "lorentzian_profile", "cells", "shift", "zero", "scale_background"]
    for number, label in enumerate(stages, 1):
        trial_path = out / f"trial_{number:02d}_{label}.gpx"
        trial = G2.G2Project(gpxfile=str(current))
        trial.save(str(trial_path))
        prepare(trial)
        configure(trial, label)
        trial.set_Controls("cycles", 28)
        trial.refine()
        record = summary(trial, label)
        accept = not record["frozen"] and valid(trial, record) and record["rwp_percent"] <= current_rwp + 1e-7
        record["accepted"] = accept
        history.append(record)
        if accept:
            # refine() updates the in-memory project; persist that exact state
            # before promoting it to the accepted chain.
            trial.save(str(trial_path))
            accepted_count += 1
            current = out / f"accepted_{accepted_count}.gpx"
            shutil.copy2(trial_path, current)
            current_rwp = record["rwp_percent"]
    shutil.copy2(current, out / "best.gpx")
    final = G2.G2Project(gpxfile=str(out / "best.gpx"))
    result = {"baseline": baseline, "final": summary(final, "final"), "history": history}
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
