"""Promote the selected replay-safe state and disable the rejected WO3 model."""

from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: finalize_project.py SELECTED.gpx FINAL.gpx")
    selected = Path(sys.argv[1]).resolve()
    final = Path(sys.argv[2]).resolve()
    shutil.copy2(selected, final)

    project = G2.G2Project(gpxfile=str(final))
    hist = project.histograms()[0]
    rejected = project.phase("WO3")
    hap = rejected.data["Histograms"][hist.name]
    hap["Scale"] = [0.0, False]
    rejected.clear_HAP_refinements(
        {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True, "HStrain": True}
    )
    rejected.data["General"]["Cell"][0] = False
    rejected.set_refinements({"Atoms": {"all": " "}})
    project.set_Frozen()
    project.save(str(final))

    check = G2.G2Project(gpxfile=str(final))
    saved = check.phase("WO3").data["Histograms"][check.histograms()[0].name]["Scale"]
    if saved[0] != 0.0 or saved[1]:
        raise RuntimeError(f"rejected WO3 model was not disabled: {saved!r}")
    print(f"saved {final} with rejected WO3 scale {saved[0]:.1f}")


if __name__ == "__main__":
    main()
