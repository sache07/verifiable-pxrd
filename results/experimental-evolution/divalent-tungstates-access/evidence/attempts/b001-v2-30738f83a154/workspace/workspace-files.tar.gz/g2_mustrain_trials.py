"""Greedy common-state tests for the allowed uniaxial microstrain models."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import clear_flags, physical_limits, set_limit, summary


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])
START_RATIOS = (0.5, 2.0)


def prepare(project):
    clear_flags(project)
    physical_limits(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        pid = int(phase.data["pId"])
        set_limit(project, f"{pid}:0:Mustrain;i", 300.0, 8000.0)
        # The laboratory draws axial/equatorial ratios through 4, so the axial
        # component can legitimately exceed the equatorial 8000 ppm ceiling.
        set_limit(project, f"{pid}:0:Mustrain;a", 75.0, 32000.0)
    project.set_Frozen()


def run(project, cycles=16):
    project.set_Controls("cycles", cycles)
    project.refine()


def safe(value):
    return value.replace("/", "_").replace(" ", "_")


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_mustrain_trials.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    current = out / "accepted_0.gpx"
    shutil.copy2(base, current)
    baseline_project = G2.G2Project(gpxfile=str(current))
    baseline = summary(baseline_project, "baseline")
    current_rwp = baseline["rwp_percent"]
    records = [baseline]
    accepted = []

    # Test the boundary-limited residual phase first, then each ordinary phase.
    names = [phase.name for phase in baseline_project.phases()]
    order = sorted(names, key=lambda name: ("Mn3WO6" not in name, name != "WO3", name))
    for step, phase_name in enumerate(order, 1):
        candidates = []
        for axis in AXES:
            for ratio in START_RATIOS:
                path = out / f"trial_{step}_{safe(phase_name)}_{''.join(map(str, axis))}_{ratio:g}.gpx"
                trial = G2.G2Project(gpxfile=str(current))
                trial.save(str(path))
                prepare(trial)
                phase = trial.phase(phase_name)
                hap = phase.data["Histograms"][trial.histograms()[0].name]
                equatorial = float(hap["Mustrain"][1][0])
                hap["Mustrain"][1][1] = min(32000.0, max(0.0, equatorial * ratio))
                phase.set_HAP_refinements(
                    {
                        "Mustrain": {
                            "type": "uniaxial",
                            "direction": list(axis),
                            "refine": True,
                        }
                    }
                )
                trial.set_Frozen()
                run(trial, 18)
                record = summary(trial, f"{phase_name}:{axis}:{ratio:g}")
                record.update(phase=phase_name, axis=list(axis), start_ratio=ratio)
                records.append(record)
                candidates.append((record, path))

        physical_candidates = []
        for record, path in candidates:
            phase_record = next(p for p in record["phases"] if p["name"] == phase_name)
            equatorial, axial = phase_record["mustrain"][1][:2]
            ratio = axial / equatorial
            record["final_axial_ratio"] = ratio
            record["physically_valid"] = (
                300.0 - 1e-6 <= equatorial <= 8000.0 + 1e-6
                and 0.25 - 1e-6 <= ratio <= 4.0 + 1e-6
            )
            if record["physically_valid"]:
                physical_candidates.append((record, path))
        if not physical_candidates:
            continue
        best_record, best_path = min(physical_candidates, key=lambda item: item[0]["rwp_percent"])
        # Require a visible improvement; otherwise retain the simpler isotropic state.
        if best_record["rwp_percent"] < current_rwp - 0.015:
            current = out / f"accepted_{step}.gpx"
            shutil.copy2(best_path, current)
            current_rwp = best_record["rwp_percent"]
            accepted.append(
                {
                    "phase": phase_name,
                    "axis": best_record["axis"],
                    "rwp_percent": current_rwp,
                }
            )

    shutil.copy2(current, out / "best.gpx")
    result = {"baseline": baseline, "accepted": accepted, "final_rwp_percent": current_rwp, "trials": records}
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
