"""Alternate the two remaining improving intensity corrections to convergence."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import summary
from g2_final_polish import configure, prepare, valid


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_intensity_converge.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    current = out / "accepted_0.gpx"
    shutil.copy2(base, current)
    project = G2.G2Project(gpxfile=str(current))
    initial = summary(project, "initial")
    current_rwp = initial["rwp_percent"]
    records = [dict(initial, accepted=True)]
    accepted_count = 0

    for number, label in enumerate(["texture", "roughness"] * 3, 1):
        path = out / f"trial_{number:02d}_{label}.gpx"
        trial = G2.G2Project(gpxfile=str(current))
        trial.save(str(path))
        prepare(trial)
        configure(trial, label)
        trial.set_Controls("cycles", 28)
        trial.refine()
        record = summary(trial, f"{label}_{number}")
        accept = valid(trial, record) and record["rwp_percent"] < current_rwp - 1e-5
        record["accepted"] = accept
        records.append(record)
        if accept:
            accepted_count += 1
            current = out / f"accepted_{accepted_count}.gpx"
            shutil.copy2(path, current)
            current_rwp = record["rwp_percent"]

    shutil.copy2(current, out / "best.gpx")
    final = G2.G2Project(gpxfile=str(out / "best.gpx"))
    result = {"initial": initial, "final": summary(final, "final"), "history": records}
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
