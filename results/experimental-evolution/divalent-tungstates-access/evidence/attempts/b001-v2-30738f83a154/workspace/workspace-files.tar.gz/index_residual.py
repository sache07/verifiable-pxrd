"""Index the strongest coherent peaks left by the MnWO4 + WO3 model."""

import json
import math

from GSASII import GSASIIindex as IDX


POSITIONS = [
    20.32431122,
    20.87849762,
    29.14782762,
    32.25561842,
    35.62420162,
    46.19720922,
    47.01218922,
    54.90120482,
    56.99841002,
    59.91060602,
    64.87655482,
    66.96289962,
    70.64660922,
    74.86277162,
    79.37232842,
]
INTENSITIES = [7662, 8390, 7714, 3425, 9112, 2877, 4248, 3130, 1410, 671, 1220, 1211, 928, 610, 654]
ZERO = 0.39
WAVELENGTH = 1.540598


def d_spacing(position):
    theta = math.radians((position - ZERO) / 2)
    return WAVELENGTH / (2 * math.sin(theta))


def main():
    peaks = [
        [pos, inten, True, False, 0, 0, 0, d_spacing(pos), 0.0]
        for pos, inten in zip(POSITIONS, INTENSITIES)
    ]
    names = [
        "Cubic-F", "Cubic-I", "Cubic-P", "Trigonal-R", "Hexagonal-P",
        "Tetragonal-I", "Tetragonal-P", "Orthorhombic-F", "Orthorhombic-I",
        "Orthorhombic-A", "Orthorhombic-B", "Orthorhombic-C", "Orthorhombic-P",
        "Monoclinic-I", "Monoclinic-A", "Monoclinic-C", "Monoclinic-P", "Triclinic",
    ]
    all_cells = []
    for i in [0, 1, 2, 4, 5, 6, 7, 8, 11, 12, 15, 16]:
        bravais = [False] * 18
        bravais[i] = True
        for start_volume in [100]:
            controls = [0, ZERO, 5, start_volume]
            print(f"SEARCH {names[i]} start_volume={start_volume}", flush=True)
            ok, dmin, cells = IDX.DoIndexPeaks(
                [p[:] for p in peaks], controls, bravais, None,
                ifX20=True, timeout=20, M20_min=4.0, return_Nc=True,
            )
            for cell in cells:
                all_cells.append({"bravais": names[i], "start_volume": start_volume, "cell": cell})
    all_cells.sort(key=lambda r: r["cell"][0], reverse=True)
    with open("residual_indexing.json", "w") as stream:
        json.dump(all_cells, stream, indent=2)
        stream.write("\n")
    print("TOP RESULTS")
    for rec in all_cells[:80]:
        print(json.dumps(rec))


if __name__ == "__main__":
    main()
