"""Grid-test allowed March-Dollase axes from one fixed physical project."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from g2_controlled_refine import summary


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def prepare(project):
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_HAP_refinements(
            {"Scale": True, "Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
    project.set_Frozen()


def refine(project):
    project.set_Controls("cycles", 8)
    project.refine()


def safe_name(value):
    return value.replace("/", "_").replace(" ", "_")


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_md_trials.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    baseline_project = G2.G2Project(gpxfile=str(base))
    baseline = summary(baseline_project, "baseline")
    records = []
    best_axes = {}
    phase_names = [phase.name for phase in baseline_project.phases()]
    for phase_name in phase_names:
        phase_trials = []
        for axis in AXES:
            destination = out / f"trial_{safe_name(phase_name)}_{''.join(map(str, axis))}.gpx"
            project = G2.G2Project(gpxfile=str(base))
            project.save(str(destination))
            prepare(project)
            phase = project.phase(phase_name)
            hap = phase.data["Histograms"][project.histograms()[0].name]
            hap["Pref.Ori."][3] = list(axis)
            phase.set_HAP_refinements({"Pref.Ori.": True})
            refine(project)
            record = summary(project, f"{phase_name}:{axis}")
            record["phase"] = phase_name
            record["axis"] = list(axis)
            phase_trials.append(record)
            records.append(record)
        best = min(phase_trials, key=lambda item: item["rwp_percent"])
        best_axes[phase_name] = best["axis"]

    combined_path = out / "combined.gpx"
    combined = G2.G2Project(gpxfile=str(base))
    combined.save(str(combined_path))
    prepare(combined)
    for phase_name, axis in best_axes.items():
        phase = combined.phase(phase_name)
        hap = phase.data["Histograms"][combined.histograms()[0].name]
        hap["Pref.Ori."][3] = list(axis)
        phase.set_HAP_refinements({"Pref.Ori.": True})
    refine(combined)
    combined_record = summary(combined, "combined")
    combined_record["axes"] = best_axes
    shutil.copy2(combined.filename, out / "best.gpx")
    result = {
        "baseline": baseline,
        "trials": records,
        "best_axes": best_axes,
        "combined": combined_record,
    }
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
