"""Repeat a candidate-only scale test from several small positive starts."""

from pathlib import Path
import json
import math
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from g2_add_trial import freeze_existing, phase_summary, rwp


def main():
    if len(sys.argv) != 5:
        raise SystemExit("usage: g2_precursor_scale.py BASE.gpx CIF NAME OUTDIR")
    base, cif, name, out = Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3], Path(sys.argv[4])
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    records = []
    for index, seed in enumerate((0.001, 0.01, 0.1, 0.5), 1):
        path = (out / f"seed_{index}.gpx").resolve()
        project = G2.G2Project(gpxfile=str(base.resolve()))
        project.save(str(path))
        freeze_existing(project)
        hist = project.histograms()[0]
        candidate = project.add_phase(str(cif.resolve()), phasename=name, histograms=[hist], fmthint="CIF")
        hap = candidate.data["Histograms"][hist.name]
        hap["Scale"] = [seed, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        pid = int(candidate.data["pId"])
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 10.0, variable=f"{pid}:0:Scale")
        project.set_Controls("cycles", 20)
        project.set_Frozen()
        error = None
        try:
            project.refine()
        except Exception as exc:
            error = f"{type(exc).__name__}: {exc}"
        calc = np.asarray(hist.data["data"][1][3], float)
        record = {
            "seed": seed,
            "error": error,
            "frozen": project.get_Frozen(),
            "rwp_percent": rwp(project) if np.all(np.isfinite(calc)) else None,
            "calculated_min": float(np.min(calc)) if np.all(np.isfinite(calc)) else None,
            "candidate": next(p for p in phase_summary(project) if p["name"] == name),
        }
        record["successful"] = (
            error is None
            and not record["frozen"]
            and record["rwp_percent"] is not None
            and math.isfinite(record["rwp_percent"])
            and record["rwp_percent"] < 10.0
            and record["calculated_min"] >= 0.0
        )
        records.append(record)
        print(json.dumps(record, sort_keys=True), flush=True)
    (out / "summary.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
