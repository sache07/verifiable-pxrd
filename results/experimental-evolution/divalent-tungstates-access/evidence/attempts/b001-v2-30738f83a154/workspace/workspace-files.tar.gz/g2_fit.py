"""Reusable staged GSAS-II Rietveld fit for candidate phase sets.

Usage:
    gsas-python g2_fit.py OUTDIR NAME=CIF [NAME=CIF ...]
"""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter1d
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"


def prep(run):
    x, y = np.loadtxt(PATTERN, delimiter=",", skiprows=1).T
    np.savetxt(
        run / "pattern.xye",
        np.column_stack([x, y, np.sqrt(np.maximum(y, 1.0))]),
        fmt="%.8f %.8f %.8f",
    )
    (run / "instrument.instprm").write_text(
        "#GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.30;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return x, y


def metrics(project, label):
    hist = project.histograms()[0]
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    weights = 1 / np.maximum(y, 1)
    loss = float(np.sum(weights * (y - calc) ** 2))
    rwp = float(100 * np.sqrt(loss / np.sum(weights * y * y)))
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(max(mass_scale, 0.0))
        phases.append(
            {
                "name": phase.name,
                "mass_scale": mass_scale,
                "hap_scale": float(hap["Scale"][0]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "size": [str(hap["Size"][0]), [float(v) for v in hap["Size"][1]], list(hap["Size"][2])],
                "mustrain": [str(hap["Mustrain"][0]), [float(v) for v in hap["Mustrain"][1]], list(hap["Mustrain"][2])],
                "md": [float(hap["Pref.Ori."][1]), list(hap["Pref.Ori."][3])],
            }
        )
    total = sum(masses)
    for phase, value in zip(phases, masses):
        phase["weight_fraction"] = value / total if total else None
    rec = {
        "label": label,
        "rwp_percent": rwp,
        "chi_square_sum": loss,
        "background_min": float(np.min(bkg)),
        "calculated_min": float(np.min(calc)),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "sample": {"Shift": float(sample["Shift"][0]), "Scale": float(sample["Scale"][0])},
        "phases": phases,
    }
    print(json.dumps(rec, sort_keys=True))
    return rec


def run_cycle(project, run, label, cycles=6):
    project.set_Controls("cycles", cycles)
    project.refine()
    rec = metrics(project, label)
    shutil.copy2(project.filename, run / f"stage_{label}.gpx")
    return rec


def main():
    if len(sys.argv) < 4:
        raise SystemExit("usage: g2_fit.py OUTDIR NAME=CIF NAME=CIF [...]")
    run = Path(sys.argv[1]).resolve()
    specs = []
    for token in sys.argv[2:]:
        name, path = token.split("=", 1)
        specs.append((name, Path(path).resolve()))
    run.mkdir(parents=True, exist_ok=True)
    x, y = prep(run)
    G2.SetPrintLevel("warn")
    gpx = run / "candidate.gpx"
    gpx.unlink(missing_ok=True)
    project = G2.G2Project(newgpx=str(gpx))
    phases = [
        project.add_phase(str(path), phasename=name, fmthint="CIF")
        for name, path in specs
    ]
    hist = project.add_powder_histogram(
        str(run / "pattern.xye"), str(run / "instrument.instprm"),
        phases=phases, fmthint="xye",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"][1] = False
    hist.set_refinements(
        {
            "Limits": [float(x[0]), float(x[-1])],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [float(np.percentile(y, 15))] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    history = [run_cycle(project, run, "scale_background")]

    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    history.append(run_cycle(project, run, "zero"))

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    history.append(run_cycle(project, run, "cells"))

    # Separate the highly correlated constant zero and specimen shift updates.
    hist = project.histograms()[0]
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    history.append(run_cycle(project, run, "shift"))
    hist = project.histograms()[0]
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    history.append(run_cycle(project, run, "zero_again"))

    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    history.append(run_cycle(project, run, "common_profile"))

    for phase in project.phases():
        hap = phase.data["Histograms"][project.histograms()[0].name]
        hap["Size"][1][0] = 1.0
        hap["Mustrain"][1][0] = 800.0
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 1.0, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    history.append(run_cycle(project, run, "phase_profiles", cycles=10))

    # Revisit cells after peak widths and relative scales have stabilized.
    history.append(run_cycle(project, run, "settled", cycles=10))
    project.save(str(gpx))
    for i, phase in enumerate(project.phases()):
        phase.export_CIF(str(run / f"phase_{i}_{phase.name}.cif"))
    hist = project.histograms()[0]
    arrays = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    np.savetxt(
        run / "fit.csv",
        np.column_stack([arrays[0], arrays[1], arrays[3], arrays[1] - arrays[3], arrays[4]]),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference,background",
        comments="",
    )
    residual = gaussian_filter1d(arrays[1] - arrays[3], 1.2)
    peaks, props = find_peaks(residual, prominence=100, distance=5)
    order = np.argsort(props["prominences"])[::-1]
    summary = history[-1]
    summary["residual_peaks"] = [
        {
            "two_theta": float(arrays[0][peaks[i]]),
            "height": float(residual[peaks[i]]),
            "prominence": float(props["prominences"][i]),
        }
        for i in order[:60]
    ]
    (run / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


if __name__ == "__main__":
    main()
