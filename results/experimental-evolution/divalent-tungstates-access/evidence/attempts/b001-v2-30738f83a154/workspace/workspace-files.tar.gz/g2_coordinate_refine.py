"""Sequential bounded coordinate refinement with a basic geometry screen."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat, GSASIIspc as G2spc

from g2_controlled_refine import clear_flags, physical_limits, set_limit, summary


MAX_FRACTIONAL_SHIFT = 0.025


def prepare(project):
    clear_flags(project)
    physical_limits(project)
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    project.set_Frozen()


def run(project, cycles=24):
    project.set_Controls("cycles", cycles)
    project.refine()


def screen(project, phase_name, path):
    phase = project.phase(phase_name)
    phase.export_CIF(str(path))
    data = phase.data
    cx, ct = data["General"]["AtomPtrs"][:2]
    sgdata = data["General"]["SGData"]
    amat = G2lat.cell2AB(data["General"]["Cell"][1:7])[0]
    sites = []
    for atom in data["Atoms"]:
        element = "".join(ch for ch in str(atom[ct]) if ch.isalpha()).capitalize()
        for equivalent in G2spc.GenAtom(atom[cx : cx + 3], sgdata, Move=True):
            position = np.asarray(equivalent[0], float) % 1.0
            if not any(element == old_element and np.allclose(position, old_position, atol=1e-6) for old_element, old_position in sites):
                sites.append((element, position))
    translations = np.asarray(
        [(i, j, k) for i in (-1, 0, 1) for j in (-1, 0, 1) for k in (-1, 0, 1)],
        float,
    )
    pairs = []
    for i, (element_i, position_i) in enumerate(sites):
        for element_j, position_j in sites[i + 1 :]:
            differences = position_j - position_i + translations
            distances = np.linalg.norm(np.inner(amat, differences).T, axis=1)
            pairs.append((element_i, element_j, float(np.min(distances))))
    minimum = min(distance for _, _, distance in pairs)
    oo = [distance for first, second, distance in pairs if first == second == "O"]
    cation_oxygen = [
        distance
        for first, second, distance in pairs
        if (first == "O") != (second == "O")
    ]
    result = {
        "minimum_distance_A": minimum,
        "minimum_O_O_A": float(min(oo)) if oo else None,
        "minimum_cation_O_A": float(min(cation_oxygen)) if cation_oxygen else None,
    }
    result["valid"] = (
        result["minimum_distance_A"] >= 1.2
        and (result["minimum_O_O_A"] is None or result["minimum_O_O_A"] >= 1.65)
        and (result["minimum_cation_O_A"] is None or result["minimum_cation_O_A"] >= 1.3)
    )
    return result


def safe(value):
    return value.replace("/", "_").replace(" ", "_")


def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: g2_coordinate_refine.py BASE.gpx OUTDIR")
    base = Path(sys.argv[1]).resolve()
    out = Path(sys.argv[2]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")

    current = out / "accepted_0.gpx"
    shutil.copy2(base, current)
    initial = G2.G2Project(gpxfile=str(current))
    initial_record = summary(initial, "initial")
    current_rwp = initial_record["rwp_percent"]
    records = [initial_record]
    accepted = []

    fractions = {item["name"]: item["weight_fraction"] for item in initial_record["phases"]}
    order = sorted(fractions, key=fractions.get, reverse=True)
    for step, phase_name in enumerate(order, 1):
        path = out / f"trial_{step}_{safe(phase_name)}.gpx"
        trial = G2.G2Project(gpxfile=str(current))
        trial.save(str(path))
        prepare(trial)
        phase = trial.phase(phase_name)
        pid = int(phase.data["pId"])
        phase.set_refinements({"Atoms": {"all": "X"}})
        for atom_index, atom in enumerate(phase.atoms()):
            for coordinate_index, coordinate in enumerate("xyz"):
                center = float(atom.coordinates[coordinate_index])
                set_limit(
                    trial,
                    f"{pid}::dA{coordinate}:{atom_index}",
                    center - MAX_FRACTIONAL_SHIFT,
                    center + MAX_FRACTIONAL_SHIFT,
                )
        trial.set_Frozen()
        run(trial)
        record = summary(trial, f"coordinates:{phase_name}")
        geometry = screen(trial, phase_name, out / f"screen_{step}_{safe(phase_name)}.cif")
        record.update(phase=phase_name, geometry=geometry)
        records.append(record)
        coordinate_frozen = [name for name in record["frozen"] if "::dA" in name]
        if (
            geometry["valid"]
            and not coordinate_frozen
            and record["rwp_percent"] < current_rwp - 0.005
        ):
            current = out / f"accepted_{step}.gpx"
            shutil.copy2(path, current)
            current_rwp = record["rwp_percent"]
            accepted.append(
                {
                    "phase": phase_name,
                    "rwp_percent": current_rwp,
                    "geometry": geometry,
                    "frozen": record["frozen"],
                }
            )

    shutil.copy2(current, out / "best.gpx")
    result = {"initial": initial_record, "accepted": accepted, "final_rwp_percent": current_rwp, "trials": records}
    (out / "summary.json").write_text(json.dumps(result, indent=2) + "\n")


if __name__ == "__main__":
    main()
