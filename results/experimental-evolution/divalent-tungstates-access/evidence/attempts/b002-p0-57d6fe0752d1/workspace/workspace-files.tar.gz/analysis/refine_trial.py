#!/usr/bin/env python3
"""Create and refine a GSAS-II trial project for a supplied phase list.

This is intentionally conservative: coordinates remain fixed during phase
screening, while scales, cells, a smooth background, common calibration and
isotropic sample broadening are optimized.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]


def write_xye(path: Path) -> None:
    source = ROOT / "inputs" / "pattern.csv"
    with source.open(newline="") as inp, path.open("w") as out:
        rows = csv.DictReader(inp)
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            out.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n")


def write_inst(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def stage(project: G2.G2Project, label: str, cycles: int = 5) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "stage": label,
        "Rwp_percent": hist.get_wR(),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "variables": cov.get("varyList", []),
    }
    print(json.dumps(result, default=str))
    return result


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="+", type=Path)
    parser.add_argument("--names", nargs="*")
    parser.add_argument("--cycles", type=int, default=6)
    args = parser.parse_args()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    xye = args.output.with_suffix(".xye")
    inst = args.output.with_suffix(".instprm")
    write_xye(xye)
    write_inst(inst)

    project = G2.G2Project(newgpx=str(args.output))
    hist = project.add_powder_histogram(
        str(xye), str(inst), fmthint="xye"
    )
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [900.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )

    names = args.names or [p.stem for p in args.phases]
    if len(names) != len(args.phases):
        raise ValueError("--names must match the number of phase files")
    phases = [
        project.add_phase(
            str(path.resolve()), phasename=name, histograms=[hist], fmthint="CIF"
        )
        for name, path in zip(names, args.phases)
    ]
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Extinction"] = [0.0, False]

    # Establish intensity and background before changing peak positions.
    stage(project, "background_scales", args.cycles)

    # Refine a common offset, then lattice metrics for all phases.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stage(project, "zero", args.cycles)
    for phase in phases:
        phase.set_refinements({"Cell": True})
    stage(project, "cells", args.cycles)

    # Optimize a physically positive shared instrumental profile. Values are
    # initialized inside the laboratory ranges; GSAS internal limits constrain
    # the profile during least squares.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    stage(project, "instrument", args.cycles)
    # Instrument X and sample-size Lorentzian broadening are exactly
    # confounded for one histogram. Preserve the common X estimate while
    # fitting phase-specific sizes.
    hist.clear_refinements({"Instrument Parameters": ["X"]})

    # Allow each phase its own crystallite size and microstrain as in the
    # synthetic specimen protocol.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    stage(project, "sample_broadening", args.cycles)

    # A specimen displacement has a different angular dependence from Zero.
    # Fix Zero here because the two offsets are nearly collinear over one scan.
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    stage(project, "shift", args.cycles)
    stage(project, "settle", args.cycles)

    project.save()
    data = hist.data["data"][1]
    summary = {
        "project": str(args.output),
        "histogram": hist.name,
        "Rwp_percent": hist.get_wR(),
        "phases": {},
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.data["Sample Parameters"],
        "background": hist.data["Background"][0],
        "profile": {
            "x": [float(data[0][0]), float(data[0][-1])],
            "observed_sum": float(np.sum(data[1])),
            "calculated_sum": float(np.sum(data[3])),
        },
    }
    masses = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        mass_scale = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(mass_scale)
        summary["phases"][phase.name] = {
            "mass_scale": mass_scale,
            "scale": hap["Scale"],
            "cell": phase.data["General"]["Cell"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    total = sum(max(0.0, value) for value in masses)
    if total:
        for phase, value in zip(phases, masses):
            summary["phases"][phase.name]["weight_fraction"] = max(0.0, value) / total
    args.output.with_suffix(".json").write_text(
        json.dumps(summary, indent=2, default=lambda x: x.tolist() if hasattr(x, "tolist") else str(x))
        + "\n"
    )


if __name__ == "__main__":
    main()
