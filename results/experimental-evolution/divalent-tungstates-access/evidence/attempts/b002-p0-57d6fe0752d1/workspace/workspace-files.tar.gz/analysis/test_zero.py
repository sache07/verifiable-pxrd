#!/usr/bin/env python3
"""Test equivalent calibration/cell decompositions within the lab zero range."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    for zero in (-0.25, 0.0, 0.20, 0.25):
        tag = str(zero).replace("-", "m").replace(".", "p")
        output = args.outdir / f"zero_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(args.input), newgpx=str(output))
        hist = project.histograms()[0]
        hist.data["Instrument Parameters"][0]["Zero"] = [0.0, zero, False]
        project.set_Controls("cycles", 15)
        project.refine()
        project.save()
        print(
            json.dumps(
                {
                    "zero": zero,
                    "Rwp_percent": hist.get_wR(),
                    "shift_um": hist.data["Sample Parameters"]["Shift"][0],
                    "cells": {phase.name: phase.get_cell() for phase in project.phases()},
                    "project": str(output),
                }
            )
        )


if __name__ == "__main__":
    main()
