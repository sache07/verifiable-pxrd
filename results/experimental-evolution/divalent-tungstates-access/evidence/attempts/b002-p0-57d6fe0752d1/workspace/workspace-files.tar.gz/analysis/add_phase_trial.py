#!/usr/bin/env python3
"""Add one candidate phase to an existing GSAS-II model and refine it."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run(project: G2.G2Project, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    print(json.dumps({"stage": label, "Rwp_percent": project.histograms()[0].get_wR()}))


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("name")
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histograms()[0]
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.3
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    run(project, "scale")
    phase.set_refinements({"Cell": True})
    run(project, "cell")
    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        },
        [hist],
    )
    run(project, "profile")
    run(project, "settle")
    project.save()

    masses = []
    for ph in project.phases():
        ph_hap = ph.data["Histograms"][hist.name]
        masses.append(ph.data["General"]["Mass"] * ph_hap["Scale"][0])
    total = sum(masses)
    print(
        json.dumps(
            {
                "Rwp_percent": hist.get_wR(),
                "weight_fractions": {
                    ph.name: float(value / total)
                    for ph, value in zip(project.phases(), masses)
                },
            }
        )
    )


if __name__ == "__main__":
    main()
