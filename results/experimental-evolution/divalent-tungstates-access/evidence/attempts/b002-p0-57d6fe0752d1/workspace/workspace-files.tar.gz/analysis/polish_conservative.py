#!/usr/bin/env python3
"""Conservative final polishing with weak WO3 oxygen positions fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ACTIVE = ("ZnWO4_hubnerite_parent", "WO3_2311041", "ZnO")


def report(project: G2.G2Project, stage: str) -> None:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp_percent": hist.get_wR(),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
                "U": hist.data["Instrument Parameters"][0]["U"][1],
                "phases": {
                    name: {
                        "scale": project.phase(name).data["Histograms"][hist.name]["Scale"][0],
                        "size": project.phase(name).data["Histograms"][hist.name]["Size"][1][0],
                        "strain": project.phase(name).data["Histograms"][hist.name]["Mustrain"][1][0],
                        "texture": project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][:4],
                        "uiso": project.phase(name).atoms()[0].uiso,
                    }
                    for name in ACTIVE
                },
            },
            default=str,
        )
    )


def refine(project: G2.G2Project, stage: str, cycles: int = 20) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, stage)


def coordinate_bounds(
    project: G2.G2Project,
    phase: G2.G2Phase,
    atom_index: int,
    coordinates: tuple[float, float, float],
    axes: str,
    limit: float,
) -> None:
    values = dict(zip("xyz", coordinates))
    for axis in axes:
        variable = f"{phase.data['pId']}::dA{axis}:{atom_index}"
        project.set_Controls("parmMin", values[axis] - limit, variable=variable)
        project.set_Controls("parmMax", values[axis] + limit, variable=variable)


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    project.index_ids()
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.data["Constraints"]["data"]["Phase"] = []
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    inst["U"] = [inst["U"][0], 0.0, False]

    main = project.phase("ZnWO4_hubnerite_parent")
    main_hap = main.data["Histograms"][hist.name]
    main_hap["Pref.Ori."][1] = 0.7
    main_hap["Pref.Ori."][2] = False
    for atom in main.atoms():
        atom.uiso = 0.0095
        atom.refinement_flags = "X"

    wo3 = project.phase("WO3_2311041")
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Size"][0] = "isotropic"
    wo3_hap["Size"][2] = [True, False, False]
    wo3_hap["Mustrain"][1][0] = 0.0
    wo3_hap["Mustrain"][2] = [False, False, False]
    project.set_Controls("parmMin", 0.04, variable=f"{wo3.data['pId']}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{wo3.data['pId']}:0:Size;i")
    project.set_Controls("parmMin", 0.7, variable=f"{wo3.data['pId']}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{wo3.data['pId']}:0:MD")
    for index, atom in enumerate(wo3.atoms()):
        atom.uiso = 0.010
        atom.refinement_flags = "X" if atom.element == "W" else ""
        if atom.element == "W":
            coordinate_bounds(project, wo3, index, atom.coordinates, "xyz", 0.015)

    zno = project.phase("ZnO")
    zno_hap = zno.data["Histograms"][hist.name]
    zno_hap["Mustrain"][1][0] = 0.0
    zno_hap["Mustrain"][2] = [False, False, False]
    for atom in zno.atoms():
        atom.uiso = 0.008
        atom.refinement_flags = ""

    refine(project, "sizes_and_W_coordinates")
    refine(project, "W_coordinate_settle")
    for atom in wo3.atoms():
        atom.refinement_flags = ""

    # Refine the sole wurtzite internal coordinate. This displacement gives a
    # regular tetrahedral Zn environment and remains within the mismatch cap.
    for index, atom in enumerate(zno.atoms()):
        if atom.element == "O":
            coordinate_bounds(project, zno, index, atom.coordinates, "z", 0.025)
            atom.refinement_flags = "X"
    refine(project, "ZnO_internal_coordinate")
    for atom in zno.atoms():
        atom.refinement_flags = ""

    # Stop positional refinement before fitting thermal/profile intensity
    # terms, then impose one bounded Uiso value per active phase.
    for atom in main.atoms():
        atom.refinement_flags = ""
    project.index_ids()
    for name in ACTIVE:
        phase = project.phase(name)
        start = phase.atoms()[0].uiso
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = start
            atom.refinement_flags = "U"
            variable = f"{phase.data['pId']}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    refine(project, "phase_common_Uiso")

    inst["U"] = [inst["U"][0], 5.0, True]
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    refine(project, "instrument_U")

    # Test ZnO strain, which is identifiable only weakly because this phase is
    # ~5 wt%. Retain it only if it stays in the active laboratory range.
    zno_hap["Mustrain"][0] = "isotropic"
    zno_hap["Mustrain"][1][0] = 500.0
    zno_hap["Mustrain"][2] = [True, False, False]
    project.set_Controls("parmMin", 0.0, variable=f"{zno.data['pId']}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{zno.data['pId']}:0:Mustrain;i")
    refine(project, "ZnO_strain_test")
    if zno_hap["Mustrain"][1][0] < 300.0:
        zno_hap["Mustrain"][1][0] = 0.0
        zno_hap["Mustrain"][2] = [False, False, False]
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        refine(project, "ZnO_strain_rejected")

    refine(project, "final_settle")
    project.save()


if __name__ == "__main__":
    main()
