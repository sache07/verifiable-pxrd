#!/usr/bin/env python3
"""Polish the selected wolframite + monoclinic WO3 + wurtzite model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


ACTIVE = ("ZnWO4_hubnerite_parent", "WO3_2311041", "ZnO")


def report(project: G2.G2Project, stage: str) -> None:
    hist = project.histograms()[0]
    rows = {}
    for name in ACTIVE:
        phase = project.phase(name)
        hap = phase.data["Histograms"][hist.name]
        rows[name] = {
            "scale": hap["Scale"][0],
            "size": hap["Size"][1][0],
            "strain": hap["Mustrain"][1][:2],
            "texture": hap["Pref.Ori."][:4],
            "uiso": phase.atoms()[0].uiso,
            "cell": phase.get_cell(),
        }
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp_percent": hist.get_wR(),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
                "instrument_U": hist.data["Instrument Parameters"][0]["U"][1],
                "phases": rows,
            },
            default=str,
        )
    )


def refine(project: G2.G2Project, stage: str, cycles: int = 20) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, stage)


def bound_coordinate(
    project: G2.G2Project,
    pid: int,
    atom_index: int,
    coordinates: tuple[float, float, float],
    limit: float,
) -> None:
    for axis, value in zip("xyz", coordinates):
        variable = f"{pid}::dA{axis}:{atom_index}"
        project.set_Controls("parmMin", value - limit, variable=variable)
        project.set_Controls("parmMax", value + limit, variable=variable)


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    project.index_ids()
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    hist = project.histograms()[0]

    # Keep the physically allowed boundary solution for the dominant [111]
    # texture fixed while polishing weak-phase variables.
    main_hap = project.phase("ZnWO4_hubnerite_parent").data["Histograms"][hist.name]
    main_hap["Pref.Ori."][1] = 0.7
    main_hap["Pref.Ori."][2] = False

    wo3 = project.phase("WO3_2311041")
    wo3_hap = wo3.data["Histograms"][hist.name]
    wo3_hap["Size"][0] = "isotropic"
    wo3_hap["Size"][2] = [True, False, False]
    project.set_Controls("parmMin", 0.04, variable=f"{wo3.data['pId']}:0:Size;i")
    project.set_Controls("parmMax", 1.5, variable=f"{wo3.data['pId']}:0:Size;i")
    project.set_Controls("parmMin", 0.7, variable=f"{wo3.data['pId']}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{wo3.data['pId']}:0:MD")
    refine(project, "WO3_size")

    # The heavy W coordinates carry most of the identifiable structural
    # information for the 12 wt% phase. Bounds exceed the generator's maximum
    # site perturbation while preventing a weak-phase runaway.
    for index, atom in enumerate(wo3.atoms()):
        if atom.element == "W":
            bound_coordinate(project, wo3.data["pId"], index, atom.coordinates, 0.015)
            atom.refinement_flags = "X"
        else:
            atom.refinement_flags = ""
    refine(project, "WO3_W_coordinates")

    # Oxygen coordinates are refined in a separate stage with slightly wider
    # fractional bounds; the source model remains the center of each interval.
    for index, atom in enumerate(wo3.atoms()):
        if atom.element == "O":
            bound_coordinate(project, wo3.data["pId"], index, atom.coordinates, 0.020)
            atom.refinement_flags = "X"
    refine(project, "WO3_all_coordinates")
    refine(project, "WO3_coordinate_settle")
    for atom in wo3.atoms():
        atom.refinement_flags = ""

    # Wurtzite has one independent internal coordinate. Permit the full
    # symmetry-preserving oxygen displacement range implied by the mismatch.
    zno = project.phase("ZnO")
    for index, atom in enumerate(zno.atoms()):
        if atom.element == "O":
            z = atom.coordinates[2]
            project.set_Controls("parmMin", z - 0.025, variable=f"{zno.data['pId']}::dAz:{index}")
            project.set_Controls("parmMax", z + 0.025, variable=f"{zno.data['pId']}::dAz:{index}")
            atom.refinement_flags = "X"
        else:
            atom.refinement_flags = ""
    refine(project, "ZnO_internal_coordinate")
    for atom in zno.atoms():
        atom.refinement_flags = ""

    # Rebuild only the active phase-common Uiso constraints. All generated
    # phases use one isotropic displacement value in [0.003, 0.020] A^2.
    project.data["Constraints"]["data"]["Phase"] = []
    project.index_ids()
    for name in ACTIVE:
        phase = project.phase(name)
        start = min(0.018, max(0.005, phase.atoms()[0].uiso))
        variables = []
        for index, atom in enumerate(phase.atoms()):
            atom.uiso = start
            atom.refinement_flags = "U"
            variable = f"{phase.data['pId']}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    refine(project, "phase_common_Uiso")

    # Test the positive instrumental Gaussian term independently of phase
    # broadening. The selected model already carries a physical main-phase
    # microstrain; the weak phases remain strain-free for this stage.
    inst = hist.data["Instrument Parameters"][0]
    inst["U"] = [inst["U"][0], 10.0, True]
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    refine(project, "instrument_U")

    # A possible WO3 strain is tested last. A fitted value below the stated
    # 300 ppm active range is discarded as an unidentifiable zero surrogate.
    wo3_hap["Mustrain"][0] = "isotropic"
    wo3_hap["Mustrain"][1][0] = 300.0
    wo3_hap["Mustrain"][2] = [True, False, False]
    project.set_Controls("parmMin", 0.0, variable=f"{wo3.data['pId']}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{wo3.data['pId']}:0:Mustrain;i")
    refine(project, "WO3_strain_test")
    if wo3_hap["Mustrain"][1][0] < 300.0:
        wo3_hap["Mustrain"][1][0] = 0.0
        wo3_hap["Mustrain"][2] = [False, False, False]
        project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
        refine(project, "WO3_strain_rejected")

    refine(project, "final_settle")
    project.save()


if __name__ == "__main__":
    main()
