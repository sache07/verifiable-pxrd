#!/usr/bin/env python3
"""Replace the dominant wolframite parent and refine its identifiable variables."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, stage: str) -> None:
    hist = project.histograms()[0]
    phase = project.phase("ZnWO4_hubnerite_parent")
    hap = phase.data["Histograms"][hist.name]
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp_percent": hist.get_wR(),
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "texture": hap["Pref.Ori."][:4],
                "atoms": [atom.data for atom in phase.atoms()],
            },
            default=str,
        )
    )


def refine(project: G2.G2Project, stage: str, cycles: int = 20) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, stage)


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("cif", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    project = G2.G2Project(gpxfile=str(args.model), newgpx=str(args.output))
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.index_ids()
    hist = project.histograms()[0]
    old = project.phase("ZnWO4")
    old_hap = old.data["Histograms"][hist.name]
    old_cell = copy.deepcopy(old.data["General"]["Cell"])
    old_hap["Use"] = False
    old_hap["Scale"] = [0.0, False]

    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename="ZnWO4_hubnerite_parent",
        histograms=[hist],
        fmthint="CIF",
    )
    project.index_ids()
    phase.data["General"]["Cell"] = old_cell
    hap = phase.data["Histograms"][hist.name]
    for key in ["Scale", "Size", "Mustrain", "Pref.Ori.", "Extinction", "Babinet"]:
        if key in old_hap and key in hap:
            hap[key] = copy.deepcopy(old_hap[key])
    hap["Use"] = True
    hap["Scale"][0] = 87.0
    hap["Scale"][1] = True
    hap["Pref.Ori."][2] = True
    for atom in phase.atoms():
        atom.uiso = 0.0095
        atom.refinement_flags = ""
    phase.set_refinements({"Cell": True})

    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
    refine(project, "fixed_parent_coordinates")
    refine(project, "fixed_parent_settle")

    # The dominant phase provides enough independent reflections for its two
    # special-position y coordinates and two general oxygen sites.
    for atom in phase.atoms():
        atom.refinement_flags = "X"
    refine(project, "refined_parent_coordinates")
    refine(project, "refined_parent_settle")
    project.save()


if __name__ == "__main__":
    main()
