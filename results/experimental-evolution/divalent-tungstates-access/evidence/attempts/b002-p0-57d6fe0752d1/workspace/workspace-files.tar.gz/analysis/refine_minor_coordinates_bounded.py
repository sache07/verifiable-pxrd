#!/usr/bin/env python3
"""Refine minor-phase coordinates only within reference-mismatch bounds."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def set_coordinate_bounds(
    project: G2.G2Project,
    pidx: int,
    aidx: int,
    axes: str,
    coordinates: tuple[float, float, float],
    limit: float,
) -> None:
    lookup = dict(zip("xyz", coordinates))
    for axis in axes:
        variable = f"{pidx}::dA{axis}:{aidx}"
        project.set_Controls("parmMin", lookup[axis] - limit, variable=variable)
        project.set_Controls("parmMax", lookup[axis] + limit, variable=variable)


def refine(project: G2.G2Project, label: str) -> None:
    project.set_Controls("cycles", 20)
    project.refine()
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "stage": label,
                "Rwp_percent": project.histograms()[0].get_wR(),
                "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
            },
            default=str,
        )
    )


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    project.index_ids()

    wo3 = project.phase("WO3")
    for aidx, atom in enumerate(wo3.atoms()):
        atom.refinement_flags = "XU"
        limit = 0.006 if atom.element == "W" else 0.008
        set_coordinate_bounds(project, 1, aidx, "xyz", atom.coordinates, limit)
    refine(project, "bounded_WO3_coordinates")
    for atom in wo3.atoms():
        atom.refinement_flags = "U"

    zno = project.phase("ZnO")
    for aidx, atom in enumerate(zno.atoms()):
        atom.refinement_flags = "XU" if atom.element == "O" else "U"
        if atom.element == "O":
            # Site symmetry leaves only z independent in P63mc.
            set_coordinate_bounds(project, 2, aidx, "z", atom.coordinates, 0.010)
    refine(project, "bounded_ZnO_coordinate")
    for atom in zno.atoms():
        atom.refinement_flags = "U"

    refine(project, "settle_after_minor_coordinates")
    project.save()


if __name__ == "__main__":
    main()
