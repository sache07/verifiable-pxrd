#!/usr/bin/env python3
"""Physically constrained staged refinement of the selected three-phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, label: str) -> None:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "stage": label,
                "Rwp_percent": hist.get_wR(),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
            },
            default=str,
        )
    )


def refine(project: G2.G2Project, label: str, cycles: int = 12) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    report(project, label)


def bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)

    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    project.index_ids()
    hist = project.histograms()[0]
    phases = project.phases()

    # Remove non-identifiable/invalid decomposition from exploratory fitting.
    hist.clear_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L", "Zero", "Polariz."]}
    )
    hist.clear_refinements(
        {"Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]}
    )
    inst = hist.data["Instrument Parameters"][0]
    # Retain the already fitted common angular offset. Resetting it while all
    # cells are free creates an avoidable cell/offset singularity.
    inst["U"][1] = 0.0
    inst["W"][1] = 5.0
    inst["X"][1] = 0.1
    inst["SH/L"][1] = 0.03
    hist.data["Sample Parameters"]["Shift"][1] = True
    hist.set_refinements({"Instrument Parameters": ["W", "SH/L"]})
    bound(project, ":0:W", 2.0, 40.0)
    bound(project, ":0:SH/L", 0.005, 0.10)
    bound(project, ":0:Shift", -800.0, 800.0)

    for i, phase in enumerate(phases):
        hap = phase.data["Histograms"][hist.name]
        phase.set_refinements({"Cell": False})
        hap["Scale"][1] = True
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Size"][2] = [True, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [True, False, False]
        bound(project, f"{i}:0:Size;i", 0.04, 1.5)
        bound(project, f"{i}:0:Mustrain;i", 0.0, 8000.0)
    znwo4_hap = project.phase("ZnWO4").data["Histograms"][hist.name]
    znwo4_hap["Pref.Ori."][0] = "MD"
    znwo4_hap["Pref.Ori."][2] = True
    znwo4_hap["Pref.Ori."][3] = [1, 1, 1]
    bound(project, "0:0:MD", 0.65, 1.5)
    refine(project, "physical_profile")
    refine(project, "physical_profile_settle")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    refine(project, "cells_after_profile")

    # Fit whole-pattern intensity effects that are exact members of the
    # generating laboratory model.
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.30, True]
    sample["SurfRoughB"] = [0.10, True]
    bound(project, ":0:SurfRoughA", 0.0, 1.0)
    bound(project, ":0:SurfRoughB", 0.0, 0.5)
    refine(project, "surface_roughness")

    inst["Polariz."][1] = 0.8
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    bound(project, ":0:Polariz.", 0.5, 1.0)
    refine(project, "polarization")

    # Symmetry-reduced coordinate refinement. The principal phase has only
    # eight independent positional parameters. For weak WO3, refine the two W
    # sites (dominant X-ray scatterers) and leave oxygen at the published model.
    znwo4 = project.phase("ZnWO4")
    for atom in znwo4.atoms():
        atom.refinement_flags = "X"
    refine(project, "ZnWO4_coordinates")

    zno = project.phase("ZnO")
    for atom in zno.atoms():
        atom.refinement_flags = "X" if atom.element == "O" else ""
    refine(project, "ZnO_coordinate")

    wo3 = project.phase("WO3")
    for atom in wo3.atoms():
        atom.refinement_flags = "X" if atom.element == "W" else ""
    refine(project, "WO3_W_coordinates")

    # The synthetic specimen uses one isotropic Uiso per phase. Constrain all
    # sites in each phase to a common value while refining it.
    project.index_ids()
    for pidx, phase in enumerate(project.phases()):
        variables = []
        for aidx, atom in enumerate(phase.atoms()):
            atom.uiso = 0.01
            atom.refinement_flags = (atom.refinement_flags or "") + "U"
            var = f"{pidx}::AUiso:{aidx}"
            variables.append(var)
            bound(project, var, 0.001, 0.03)
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=False)
    refine(project, "phase_common_Uiso")
    refine(project, "final_settle")
    project.save()

    # Compact machine-readable diagnostic beside the project.
    masses = []
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        value = float(phase.data["General"]["Mass"] * hap["Scale"][0])
        masses.append(value)
        phase_rows.append(
            {
                "name": phase.name,
                "mass_scale": value,
                "cell": phase.get_cell(),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [atom.data for atom in phase.atoms()],
            }
        )
    total = sum(masses)
    for row, value in zip(phase_rows, masses):
        row["weight_fraction"] = value / total
    arrays = hist.data["data"][1]
    diagnostic = {
        "Rwp_percent": hist.get_wR(),
        "phases": phase_rows,
        "instrument": inst,
        "sample": sample,
        "background": hist.data["Background"],
        "min_calculated": float(np.min(arrays[3])),
        "min_background": float(np.min(arrays[4][np.asarray(arrays[0]) >= 10.0])),
    }
    args.output.with_suffix(".json").write_text(
        json.dumps(diagnostic, indent=2, default=lambda value: value.tolist() if hasattr(value, "tolist") else str(value))
        + "\n"
    )


if __name__ == "__main__":
    main()
