#!/usr/bin/env python3
"""Export the final GSAS-II project, CIFs, fit curve and reports."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_META = {
    "ZnWO4": {
        "formula": "ZnWO4",
        "name": "zinc tungstate (wolframite)",
        "space_group": "P 1 2/c 1",
        "space_group_number": 13,
        "cif_path": "ZnWO4.cif",
    },
    "WO3": {
        "formula": "WO3",
        "name": "tungsten trioxide (monoclinic gamma-WO3)",
        "space_group": "P 1 21/c 1",
        "space_group_number": 14,
        "cif_path": "WO3.cif",
    },
    "ZnO": {
        "formula": "ZnO",
        "name": "zinc oxide (wurtzite)",
        "space_group": "P 63 m c",
        "space_group_number": 186,
        "cif_path": "ZnO.cif",
    },
}


def fraction_covariance(project: G2.G2Project, names: list[str], hist_name: str):
    cov = project.data.get("Covariance", {}).get("data", {})
    vary = [str(item) for item in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    phases = [project.phase(name) for name in names]
    masses = np.asarray([phase.data["General"]["Mass"] for phase in phases])
    scales = np.asarray(
        [phase.data["Histograms"][hist_name]["Scale"][0] for phase in phases]
    )
    numerators = masses * scales
    total = numerators.sum()
    fractions = numerators / total
    try:
        indices = [vary.index(f"{phase.data['pId']}:0:Scale") for phase in phases]
        scale_cov = matrix[np.ix_(indices, indices)]
        jacobian = np.empty((len(names), len(names)))
        for i in range(len(names)):
            for j in range(len(names)):
                jacobian[i, j] = masses[j] * (
                    (total if i == j else 0.0) - numerators[i]
                ) / total**2
        sigmas = np.sqrt(np.maximum(0.0, np.diag(jacobian @ scale_cov @ jacobian.T)))
    except (ValueError, IndexError):
        sigmas = np.full(len(names), np.nan)
    return fractions, sigmas


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=True)

    final_path = out / "final.gpx"
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(final_path))
    project.save()
    # Reload the exact serialized final project before all downstream exports.
    project = G2.G2Project(gpxfile=str(final_path))
    hist = project.histograms()[0]
    names = ["ZnWO4", "WO3", "ZnO"]
    if [phase.name for phase in project.phases()] != names:
        raise ValueError("Final project does not contain exactly the selected phase order")

    fractions, fraction_esd = fraction_covariance(project, names, hist.name)
    phase_rows = []
    for name, fraction, esd in zip(names, fractions, fraction_esd):
        phase = project.phase(name)
        meta = PHASE_META[name]
        phase.export_CIF(str(out / meta["cif_path"]))
        cell = phase.get_cell()
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append(
            {
                **meta,
                "weight_fraction": float(fraction),
                "weight_fraction_formal_esd": None if not np.isfinite(esd) else float(esd),
                "weight_percent": float(100.0 * fraction),
                "cell": {key: float(value) for key, value in cell.items()},
                "crystallite_size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "march_dollase": {
                    "axis": [int(v) for v in hap["Pref.Ori."][3]],
                    "ratio": float(hap["Pref.Ori."][1]),
                },
            }
        )

    arrays = hist.data["data"][1]
    x = np.asarray(arrays[0], dtype=float)
    observed = np.asarray(arrays[1], dtype=float)
    calculated = np.asarray(arrays[3], dtype=float)
    background = np.asarray(arrays[4], dtype=float)
    difference = observed - calculated
    original = np.loadtxt(out / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, original[:, 0]) or not np.array_equal(observed, original[:, 1]):
        raise ValueError("Final project grid or observations differ from pattern.csv")
    if np.any(~np.isfinite(calculated)) or np.any(calculated < 0):
        raise ValueError("Invalid calculated profile")
    np.savetxt(
        out / "fit.csv",
        np.column_stack([x, observed, calculated, difference, background]),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt=["%.8f", "%.8f", "%.10f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    poisson_rms = float(np.sqrt(np.mean(weights * difference**2)))
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvalues = covariance.get("Rvals", {})
    gof = float(rvalues.get("GOF", np.nan))
    fit_stats = {
        "rwp_percent": rwp,
        "rp_percent": rp,
        "goodness_of_fit": gof,
        "weighted_chi_square": chi_square,
        "poisson_standardized_residual_rms": poisson_rms,
        "n_points": int(len(x)),
        "n_refined_variables": int(len(covariance.get("varyList", []))),
        "weighting": "1/max(observed_counts,1)",
        "fit_range_two_theta_deg": [float(x[0]), float(x[-1])],
    }
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    result = {
        "phases": phase_rows,
        "fit_statistics": fit_stats,
        "refinement_histogram": hist.name,
        "calibration": {
            "zero_deg": float(inst["Zero"][1]),
            "specimen_displacement_um": float(sample["Shift"][0]),
            "zero_fixed_for_final_cycles": not bool(inst["Zero"][2]),
        },
        "fraction_basis": "normalized over the modeled crystalline phases; no amorphous fraction determined",
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
    }
    (out / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )

    lines = [
        "# Powder XRD phase analysis",
        "",
        "The pattern is explained by three crystalline phases. Weight fractions are normalized over those phases; without an internal standard, this analysis does not determine an amorphous fraction.",
        "",
        "| Phase | Structural model | Refined cell (Å, °) | Weight fraction |",
        "|---|---|---|---:|",
    ]
    for row in phase_rows:
        c = row["cell"]
        cell_text = (
            f"a={c['length_a']:.5f}, b={c['length_b']:.5f}, c={c['length_c']:.5f}; "
            f"α={c['angle_alpha']:.3f}, β={c['angle_beta']:.3f}, γ={c['angle_gamma']:.3f}"
        )
        esd = row["weight_fraction_formal_esd"]
        fraction_text = f"{row['weight_percent']:.2f} wt%"
        if esd is not None:
            fraction_text += f" (formal 1σ {100*esd:.2f} wt%)"
        lines.append(
            f"| {row['formula']} | {row['space_group']} (No. {row['space_group_number']}) | {cell_text} | {fraction_text} |"
        )
    lines.extend(
        [
            "",
            "## Evidence",
            "",
            "The dominant peak set indexes as wolframite ZnWO4. A W-bearing wolframite parent (COD 9008131, with the divalent site changed to Zn) gave the correct intensity topology; refining its eight symmetry-independent coordinates removed the large residual near 41.6° 2θ. The remaining peaks require monoclinic WO3 and wurtzite ZnO. For WO3, the P21/c COD 2311041 model gave a better whole-pattern fit than the older monoclinic and triclinic alternatives, while retaining a metric within the expected reference mismatch. ZnO accounts for the characteristic wurtzite residuals near 31.8, 34.5, and 36.3°.",
            "",
            f"The final full-grid atomic replay gives Rwp={rwp:.3f}%, Rp={rp:.3f}%, GOF={gof:.3f}, and a Poisson-standardized residual RMS of {poisson_rms:.3f}. No coherent unmodeled peak remains; the largest point residual is about {float(np.max(np.abs(difference)/np.sqrt(np.maximum(observed,1)))):.1f} counting-statistics standard deviations.",
            "",
            "## Remaining uncertainty",
            "",
            "The formal scale-covariance errors in the table are smaller than model uncertainty. Comparisons among acceptable structural/profile branches suggest a practical abundance uncertainty of roughly ±0.5 wt% per phase. The WO3 oxygen coordinates could not be refined reliably: unconstrained/broadly bounded refinement drove several sites to bounds and produced an implausibly short W-O contact, so the submitted WO3 model refines the X-ray-sensitive W positions but retains the published oxygen framework. The ~5 wt% ZnO microstrain is also weakly determined, though its phase identity and scale are stable.",
            "",
            "Because no calibrated profile was supplied, zero, specimen displacement, and lattice parameters are strongly correlated. The final cycles fix an in-range zero at {:.5f}° and refine the displacement ({:.1f} µm); this choice stabilizes the cells without changing the phase inventory or fractions. Preferred orientation is required for ZnWO4 [111], WO3 [110], and ZnO [001].".format(float(inst["Zero"][1]), float(sample["Shift"][0])),
            "",
            "The submitted CIFs, fractions, and fit.csv were exported from final.gpx.",
        ]
    )
    (out / "report.md").write_text("\n".join(lines) + "\n")

    print(json.dumps({"fit_statistics": fit_stats, "phases": phase_rows}, indent=2))


if __name__ == "__main__":
    main()
