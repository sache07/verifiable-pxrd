#!/usr/bin/env python3
"""Test identifiable positive Gaussian profile components."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def refine(project: G2.G2Project, label: str, cycles: int = 20) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    hist = project.histograms()[0]
    print(
        json.dumps(
            {
                "stage": label,
                "Rwp_percent": hist.get_wR(),
                "U": hist.data["Instrument Parameters"][0]["U"][1],
                "strains": {
                    phase.name: phase.data["Histograms"][hist.name]["Mustrain"][1][:2]
                    for phase in project.phases()
                },
            }
        )
    )


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histograms()[0]
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}

    inst = hist.data["Instrument Parameters"][0]
    inst["U"] = [inst["U"][0], 10.0, True]
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 0.0
        hap["Mustrain"][2] = [False, False, False]
    refine(project, "common_U")

    for pidx, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2][0] = True
        project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pidx}:0:Mustrain;i")
        refine(project, f"strain_{phase.name}")
        # Keep a positive fitted component; otherwise return it to inactive.
        if hap["Mustrain"][1][0] <= 1e-6:
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2][0] = False
    refine(project, "settle")
    project.save()


if __name__ == "__main__":
    main()
