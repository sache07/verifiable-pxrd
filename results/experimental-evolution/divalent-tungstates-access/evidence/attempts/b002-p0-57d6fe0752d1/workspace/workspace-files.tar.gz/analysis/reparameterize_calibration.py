#!/usr/bin/env python3
"""Move the correlated zero/displacement pair into the laboratory range."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, stage: str) -> None:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "stage": stage,
                "Rwp_percent": hist.get_wR(),
                "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
                "zero_deg": hist.data["Instrument Parameters"][0]["Zero"][1],
                "shift_um": hist.data["Sample Parameters"]["Shift"][0],
            }
        )
    )


def refine(project: G2.G2Project, stage: str) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)
    project.refine()
    report(project, stage)


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--zero", type=float, default=0.2)
    parser.add_argument("--free-zero", action="store_true")
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]

    old_zero = float(inst["Zero"][1])
    old_shift = float(sample["Shift"][0])
    # GSAS Bragg-Brentano displacement coefficient at a representative
    # theta=25 degrees; this preserves the fitted peak positions closely enough
    # for a stable least-squares handoff.
    coefficient = 0.09 * 4.0 / (math.pi * float(sample["Gonio. radius"]))
    delta_shift = -(old_zero - args.zero) / (coefficient * math.cos(math.radians(25.0)))
    inst["Zero"] = [inst["Zero"][0], args.zero, False]
    sample["Shift"] = [old_shift + delta_shift, True]
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")

    # First optimize the alternative displacement coordinate at fixed cells,
    # then release lattice metrics. This avoids asking the cell tensors to
    # absorb the abrupt parameterization change in the first cycle.
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
    refine(project, "fixed_cells")
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if hap and hap.get("Use", True) and hap["Scale"][0] != 0:
            phase.set_refinements({"Cell": True})
    refine(project, "released_cells")
    refine(project, "fixed_zero_settle")

    if args.free_zero:
        inst["Zero"][2] = True
        project.set_Controls("parmMin", -0.25, variable=":0:Zero")
        project.set_Controls("parmMax", 0.25, variable=":0:Zero")
        refine(project, "bounded_zero")
        refine(project, "bounded_zero_settle")
    project.save()


if __name__ == "__main__":
    main()
