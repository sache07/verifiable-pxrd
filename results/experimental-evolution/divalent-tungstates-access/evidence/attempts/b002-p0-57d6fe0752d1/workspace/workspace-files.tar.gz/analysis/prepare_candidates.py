#!/usr/bin/env python3
"""Prepare local structural candidates from the supplied filtered COD copy."""

from pathlib import Path

from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parents[1]
COD = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c01/cif"
)
OUT = ROOT / "analysis" / "candidates"


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_structure(structure: Structure, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # GSAS-II supplies a sensible default Uiso if the CIF has none. Keeping the
    # source symmetry here avoids spurious splitting from a P1 export.
    CifWriter(structure, symprec=1e-4, significant_figures=10).write_file(path)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    # COD 7205001 is P2/c CoMoO4 in the wolframite framework. Zn and W are
    # isovalent substitutions on the corresponding octahedral sites. Its cell
    # is already within about 1% of ambient ZnWO4 and is refined against data.
    wolframite = Structure.from_file(cod_path("7205001"), primitive=False)
    wolframite.replace_species({"Co": "Zn", "Mo": "W"})
    write_structure(wolframite, OUT / "ZnWO4_wolframite_analogue.cif")

    # A second, chemically closer wolframite parent: the 4.2 K hubnerite
    # refinement (COD 9008131) already contains W on the octahedral B site.
    # Collapsing its minor Fe/Mn disorder to Zn leaves only one cation
    # substitution and provides an independent starting coordinate set.
    hubnerite = Structure.from_file(cod_path("9008131"), primitive=False)
    hubnerite.replace_species({"Mn": "Zn", "Fe": "Zn"})
    write_structure(hubnerite, OUT / "ZnWO4_from_hubnerite_9008131.cif")

    ids = {
        "ZnO_wurtzite_9004178.cif": "9004178",
        "WO3_P21m_1010618.cif": "1010618",
        "WO3_P21c_1528915.cif": "1528915",
        "WO3_P21c_alt_1563541.cif": "1563541",
        "WO3_P21c_2311041.cif": "2311041",
        "WO3_Pminus1_2106293.cif": "2106293",
        "WO3_Pnma_2107312.cif": "2107312",
        "WO3_P42nmc_1521532.cif": "1521532",
        "WO3_P4nmm_1521533.cif": "1521533",
        "W18O49_P2m_1528166.cif": "1528166",
        "W10O29_P2m_1538317.cif": "1538317",
    }
    for name, cod_id in ids.items():
        structure = Structure.from_file(cod_path(cod_id), primitive=False)
        write_structure(structure, OUT / name)


if __name__ == "__main__":
    main()
