#!/usr/bin/env python3
"""Replace one phase in a fitted project and screen texture for the candidate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def refine(project: G2.G2Project, cycles: int = 15) -> float:
    project.set_Controls("cycles", cycles)
    project.refine()
    return float(project.histograms()[0].get_wR())


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("old_name")
    parser.add_argument("cif", type=Path)
    parser.add_argument("new_name")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    candidate_base = args.outdir / "candidate_base.gpx"
    project = G2.G2Project(gpxfile=str(args.model), newgpx=str(candidate_base))
    hist = project.histograms()[0]
    old_hap = project.phase(args.old_name).data["Histograms"][hist.name]
    old_hap["Use"] = False
    old_hap["Scale"] = [0.0, False]

    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.new_name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [4.5, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.08
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    for atom in phase.atoms():
        atom.uiso = 0.01
        atom.refinement_flags = ""
    phase.set_refinements({"Cell": True})
    base_rwp = refine(project)
    base_rwp = refine(project)
    project.save()
    print(json.dumps({"model": "base", "Rwp_percent": base_rwp}))

    axes = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]
    results = []
    for axis in axes:
        tag = "".join(str(value) for value in axis)
        output = args.outdir / f"texture_{tag}.gpx"
        trial = G2.G2Project(gpxfile=str(candidate_base), newgpx=str(output))
        trial_hist = trial.histograms()[0]
        po = trial.phase(args.new_name).data["Histograms"][trial_hist.name]["Pref.Ori."]
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
        rwp = refine(trial)
        trial.save()
        row = {"axis": list(axis), "ratio": float(po[1]), "Rwp_percent": rwp, "project": str(output)}
        print(json.dumps(row))
        results.append(row)
    (args.outdir / "results.json").write_text(
        json.dumps({"base_Rwp_percent": base_rwp, "trials": results}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
