#!/usr/bin/env python3
"""Repeat a saved GSAS-II refinement until its staged model settles."""

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("error")
parser = argparse.ArgumentParser()
parser.add_argument("input", type=Path)
parser.add_argument("output", type=Path)
parser.add_argument("--cycles", type=int, default=20)
parser.add_argument("--steps", type=int, default=3)
args = parser.parse_args()

project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
project.set_Controls("cycles", args.cycles)
for step in range(args.steps):
    project.refine()
    cov = project.data.get("Covariance", {}).get("data", {})
    print(
        json.dumps(
            {
                "step": step + 1,
                "Rwp_percent": project.histograms()[0].get_wR(),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
            },
            default=str,
        )
    )
project.save()
