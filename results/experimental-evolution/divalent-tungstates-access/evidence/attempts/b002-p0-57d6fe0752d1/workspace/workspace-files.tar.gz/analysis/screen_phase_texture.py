#!/usr/bin/env python3
"""Reset minor-phase coordinates to references and screen texture axes."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def refine(project: G2.G2Project, cycles: int = 12) -> float:
    project.set_Controls("cycles", cycles)
    project.refine()
    return float(project.histograms()[0].get_wR())


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("model", type=Path)
    parser.add_argument("reference", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("target")
    parser.add_argument("--reset", nargs="+", default=["WO3", "ZnO"])
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    base_path = args.outdir / "base.gpx"
    project = G2.G2Project(gpxfile=str(args.model), newgpx=str(base_path))
    reference = G2.G2Project(gpxfile=str(args.reference))
    hist = project.histograms()[0]

    for name in args.reset:
        phase = project.phase(name)
        source = reference.phase(name)
        if len(phase.atoms()) != len(source.atoms()):
            raise ValueError(f"Atom count mismatch for {name}")
        for atom, src in zip(phase.atoms(), source.atoms()):
            atom.coordinates = src.coordinates
            atom.refinement_flags = "U"

    # Boundary values from a no-effect roughness fit are represented exactly
    # by the generator's inactive convention in the screening base.
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.0, False]
    sample["SurfRoughB"] = [0.0, False]
    hist.data["Instrument Parameters"][0]["Polariz."][2] = False

    base_rwp = refine(project)
    project.save()
    print(json.dumps({"model": "base", "Rwp_percent": base_rwp}))

    axes = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]
    results = []
    for axis in axes:
        tag = "".join(str(value) for value in axis)
        output = args.outdir / f"{args.target}_texture_{tag}.gpx"
        trial = G2.G2Project(gpxfile=str(base_path), newgpx=str(output))
        trial_hist = trial.histograms()[0]
        phase = trial.phase(args.target)
        po = phase.data["Histograms"][trial_hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
        rwp = refine(trial)
        trial.save()
        row = {
            "axis": list(axis),
            "ratio": float(po[1]),
            "Rwp_percent": rwp,
            "project": str(output),
        }
        print(json.dumps(row))
        results.append(row)
    (args.outdir / "results.json").write_text(
        json.dumps({"base_Rwp_percent": base_rwp, "trials": results}, indent=2) + "\n"
    )


if __name__ == "__main__":
    main()
