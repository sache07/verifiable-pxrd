#!/usr/bin/env python3
"""Screen March-Dollase axes from identical refined starting projects."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--phase", default="ZnWO4")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    axes = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]
    results = []
    for axis in axes:
        tag = "".join(str(v) for v in axis)
        output = args.outdir / f"texture_{tag}.gpx"
        project = G2.G2Project(gpxfile=str(args.input), newgpx=str(output))
        phase = project.phase(args.phase)
        hist = project.histograms()[0]
        po = phase.data["Histograms"][hist.name]["Pref.Ori."]
        po[0] = "MD"
        po[1] = 1.0
        po[2] = True
        po[3] = list(axis)
        project.set_Controls("cycles", 10)
        project.refine()
        project.save()
        value = phase.data["Histograms"][hist.name]["Pref.Ori."][1]
        row = {
            "axis": list(axis),
            "ratio": float(value),
            "Rwp_percent": float(hist.get_wR()),
            "project": str(output),
        }
        print(json.dumps(row))
        results.append(row)
    (args.outdir / "texture_results.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
