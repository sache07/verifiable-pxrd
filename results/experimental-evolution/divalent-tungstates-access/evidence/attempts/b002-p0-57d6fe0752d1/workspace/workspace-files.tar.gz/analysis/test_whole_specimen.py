#!/usr/bin/env python3
"""Diagnostic tests for polarization and surface roughness."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def run(project: G2.G2Project, label: str) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 20)
    project.refine()
    hist = project.histograms()[0]
    print(
        json.dumps(
            {
                "label": label,
                "Rwp_percent": hist.get_wR(),
                "polarization": hist.data["Instrument Parameters"][0]["Polariz."],
                "roughness_A": hist.data["Sample Parameters"]["SurfRoughA"],
                "roughness_B": hist.data["Sample Parameters"]["SurfRoughB"],
            }
        )
    )
    project.save()


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("mode", choices=["polarization", "roughness"])
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histograms()[0]
    if args.mode == "polarization":
        hist.data["Instrument Parameters"][0]["Polariz."] = [0.8, 0.8, True]
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    else:
        sample = hist.data["Sample Parameters"]
        sample["SurfRoughA"] = [0.3, True]
        sample["SurfRoughB"] = [0.1, True]
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 1.0, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.0, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.5, variable=":0:SurfRoughB")
    run(project, args.mode)


if __name__ == "__main__":
    main()
