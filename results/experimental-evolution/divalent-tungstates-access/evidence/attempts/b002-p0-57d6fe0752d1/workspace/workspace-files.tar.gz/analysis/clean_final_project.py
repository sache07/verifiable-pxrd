#!/usr/bin/env python3
"""Remove exploratory phases and settle the final project on the full grid."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def report(project: G2.G2Project, step: int) -> None:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    masses = []
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        rows.append(
            {
                "name": phase.name,
                "mass_scale": mass_scale,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = mass / total
    print(
        json.dumps(
            {
                "step": step,
                "Rwp_percent": hist.get_wR(),
                "GOF": cov.get("Rvals", {}).get("GOF"),
                "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
                "zero": hist.data["Instrument Parameters"][0]["Zero"],
                "shift": hist.data["Sample Parameters"]["Shift"],
                "limits": hist.data["Limits"],
                "phases": rows,
            },
            default=str,
        )
    )


def main() -> None:
    G2.SetPrintLevel("error")
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--steps", type=int, default=5)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histograms()[0]

    # Retain only the three selected atomic phases, with concise final names.
    source = project.data["Phases"]
    header = source["data"]
    zno = source["ZnO"]
    znwo4 = source["ZnWO4_hubnerite_parent"]
    wo3 = source["WO3_2311041"]
    znwo4["General"]["Name"] = "ZnWO4"
    wo3["General"]["Name"] = "WO3"
    znwo4["pId"], wo3["pId"], zno["pId"] = 0, 1, 2
    project.data["Phases"] = {
        "data": header,
        "ZnWO4": znwo4,
        "WO3": wo3,
        "ZnO": zno,
    }
    for branch in project.names:
        if branch and branch[0] == "Phases":
            branch[:] = ["Phases", "ZnWO4", "WO3", "ZnO"]
    hist.data["Reflection Lists"] = {}
    project.index_ids()

    # The zero/height/cell ridge is not uniquely separable from one scan. Fix
    # the in-range zero reached by the bounded refinement and retain the fitted
    # specimen displacement. This stabilizes the lattice and fraction model.
    inst = hist.data["Instrument Parameters"][0]
    inst["Zero"][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    # Remove bounds belonging to discarded exploratory phases, then reinstall
    # only the physical bounds relevant to active variables.
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    for variable, low, high in [
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
        (":0:Shift", -800.0, 800.0),
    ]:
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            project.set_Controls("parmMin", 0.003, variable=f"{pid}::AUiso:{index}")
            project.set_Controls("parmMax", 0.020, variable=f"{pid}::AUiso:{index}")

    # Refit the empirical background on exactly the complete submitted grid so
    # the native saved profile and independent full-grid replay share a domain.
    arrays = hist.data["data"][1]
    x = arrays[0]
    hist.data["Limits"][1] = [float(x[0]), float(x[-1])]

    project.set_Controls("cycles", 20)
    for step in range(1, args.steps + 1):
        project.refine()
        report(project, step)
    project.save()


if __name__ == "__main__":
    main()
