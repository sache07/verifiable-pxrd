#!/usr/bin/env python3
"""Print concise GSAS-II project state and atomic coordinates for diagnostics."""

from __future__ import annotations

import json
import sys

from GSASII import GSASIIscriptable as G2


def main() -> None:
    for filename in sys.argv[1:]:
        project = G2.G2Project(gpxfile=filename)
        hist = project.histograms()[0]
        rows = []
        masses = []
        for phase in project.phases():
            hap = phase.data["Histograms"].get(hist.name)
            if not hap:
                continue
            mass = phase.data["General"]["Mass"] * hap["Scale"][0]
            masses.append(mass)
            rows.append(
                {
                    "name": phase.name,
                    "id": phase.id,
                    "use": hap.get("Use", True),
                    "mass_scale": mass,
                    "cell": phase.data["General"]["Cell"][1:7],
                    "space_group": phase.data["General"]["SGData"]["SpGrp"],
                    "scale": hap["Scale"],
                    "size": hap["Size"],
                    "strain": hap["Mustrain"],
                    "texture": hap["Pref.Ori."],
                    "atoms": [
                        {
                            "label": atom.label,
                            "element": atom.element,
                            "xyz": list(map(float, atom.coordinates)),
                            "uiso": float(atom.uiso),
                            "flag": atom.refinement_flags,
                        }
                        for atom in phase.atoms()
                    ],
                }
            )
        total = sum(masses)
        for row in rows:
            row["fraction"] = row["mass_scale"] / total if total else None
        print(
            json.dumps(
                {
                    "filename": filename,
                    "Rwp": hist.get_wR(),
                    "histogram": hist.name,
                    "instrument": hist.InstrumentParameters,
                    "sample": hist.SampleParameters,
                    "background": hist.data["Background"],
                    "phases": rows,
                    "frozen": project.data.get("Controls", {}).get("data", {}).get("parmFrozen", {}),
                },
                indent=2,
                default=str,
            )
        )


if __name__ == "__main__":
    main()
