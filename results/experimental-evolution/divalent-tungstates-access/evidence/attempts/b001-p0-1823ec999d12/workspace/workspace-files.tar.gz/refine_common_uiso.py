#!/usr/bin/env python3
"""Refine one physically common isotropic ADP per phase."""

import json

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_framework_coordinates import reliable_rwp
from refine_intensity_effects import clear_flags


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "roughness" / "model.gpx"
    outdir = ROOT / ".tmp" / "uiso"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    project.data["Constraints"]["data"]["Phase"] = []
    project.save(str(outdir / "model.gpx"))
    rows = [{"stage": "base", "Rwp": reliable_rwp(project)}]
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "U"
        project.add_EquivConstr(
            tuple(f"{phase.id}::AUiso:{index}" for index, _ in enumerate(phase.atoms()))
        )
        set_bound(project, f"{phase.id}::AUiso:0", 0.003, 0.020)
        project.set_Frozen()
        project.set_Controls("cycles", 20)
        project.refine()
        values = [float(atom.uiso) for atom in phase.atoms()]
        if max(values) - min(values) > 1e-8 or not 0.003-1e-8 <= values[0] <= 0.020+1e-8:
            raise RuntimeError(f"invalid common Uiso for {phase.name}: {values}")
        for atom in phase.atoms():
            atom.refinement_flags = " "
        project.save()
        rows.append(
            {
                "stage": phase.name,
                "Uiso_A2": values[0],
                "Rwp": reliable_rwp(project),
            }
        )
    project.save(str(outdir / "model.gpx"))
    export_profile(project)
    (outdir / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows), flush=True)


if __name__ == "__main__":
    main()
