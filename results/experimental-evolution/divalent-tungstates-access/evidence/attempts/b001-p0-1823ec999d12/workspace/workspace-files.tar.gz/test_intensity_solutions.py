#!/usr/bin/env python3
"""Replay structure-factor-derived Mn2WO5 models in the full Rietveld fit."""

import json

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_framework_coordinates import reliable_rwp
from refine_intensity_effects import clear_flags


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "major_coordinates" / "model.gpx"
    outdir = ROOT / ".tmp" / "intensity_solutions"
    outdir.mkdir(parents=True, exist_ok=True)
    rows = json.loads((ROOT / ".tmp" / "p2_intensity_solutions.json").read_text())
    exact = [row for row in rows if row["parent"] == "Mn2WO5_from_Mn2AsO5"]
    common = next(row for row in exact if row["start"] == 0)
    best = min(exact, key=lambda row: row["cost"])
    outputs = []
    for label, solution in (("common", common), ("best", best)):
        project = G2.G2Project(gpxfile=str(source))
        clear_flags(project)
        phase = project.phases()[2]
        for atom, xyz in zip(phase.atoms(), solution["coordinates"]):
            atom.coordinates = xyz
            atom.refinement_flags = " "
            atom.data[atom.cia] = "I"
            atom.uiso = 0.003
        project.data["Covariance"]["data"] = {}
        path = outdir / f"{label}.gpx"
        project.save(str(path))
        project.set_Frozen()
        project.set_Controls("cycles", 22)
        project.refine()
        phase.set_HAP_refinements({"Pref.Ori.": True})
        set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
        project.set_Frozen()
        project.set_Controls("cycles", 20)
        project.refine()
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        project.save()
        value = reliable_rwp(project)
        phase.export_CIF(str(outdir / f"{label}.cif"))
        outputs.append(
            {
                "label": label,
                "extracted_cost": solution["cost"],
                "Rwp": value,
                "texture_ratio": float(phase.data["Histograms"][project.histograms()[0].name]["Pref.Ori."][1]),
                "path": str(path),
            }
        )
        print(json.dumps(outputs[-1]), flush=True)
    outputs.sort(key=lambda row: row["Rwp"])
    winner = G2.G2Project(gpxfile=outputs[0]["path"])
    clear_flags(winner)
    winner.save(str(outdir / "model.gpx"))
    reliable_rwp(winner)
    export_profile(winner)
    (outdir / "results.json").write_text(json.dumps(outputs, indent=2) + "\n")


if __name__ == "__main__":
    main()
