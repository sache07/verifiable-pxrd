#!/usr/bin/env python3
"""Diagnostic broader relaxation of the analogue-derived minor framework."""

import json

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_framework_coordinates import reliable_rwp
from refine_intensity_effects import clear_flags


def run_group(project, phase, labels, name, outdir):
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.label in labels else " "
    project.set_Frozen()
    project.set_Controls("cycles", 30)
    project.refine()
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save(str(outdir / f"{name}.gpx"))
    return reliable_rwp(project)


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "roughness" / "model.gpx"
    outdir = ROOT / ".tmp" / "minor_relax"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    phase = project.phases()[2]
    lengths = phase.data["General"]["Cell"][1:4]
    for index, atom in enumerate(phase.atoms()):
        cap_A = 0.35 if atom.element == "O" else 0.20
        for direction, value, length in zip("xyz", atom.coordinates, lengths):
            delta = cap_A / float(length)
            set_bound(project, f"{phase.id}::dA{direction}:{index}", value-delta, value+delta)
    project.save(str(outdir / "base.gpx"))
    rows = [{"stage": "base", "Rwp": reliable_rwp(project)}]
    oxygen = [a.label for a in phase.atoms() if a.element == "O"]
    cations = [a.label for a in phase.atoms() if a.element != "O"]
    rows.append({"stage": "oxygen", "Rwp": run_group(project, phase, oxygen, "oxygen", outdir)})
    rows.append({"stage": "cations", "Rwp": run_group(project, phase, cations, "cations", outdir)})
    rows.append({"stage": "all", "Rwp": run_group(project, phase, [a.label for a in phase.atoms()], "all", outdir)})
    phase.set_HAP_refinements({"Pref.Ori.": True})
    set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    project.refine()
    phase.clear_HAP_refinements({"Pref.Ori.": True})
    project.save(str(outdir / "model.gpx"))
    rows.append({"stage": "texture", "Rwp": reliable_rwp(project)})
    export_profile(project)
    (outdir / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows), flush=True)


if __name__ == "__main__":
    main()
