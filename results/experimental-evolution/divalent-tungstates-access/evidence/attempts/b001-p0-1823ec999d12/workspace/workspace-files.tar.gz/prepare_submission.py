#!/usr/bin/env python3
"""Create the clean final GSAS project, CIFs, profile, and machine-readable result."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "wo3_231_final" / "model.gpx"


def main() -> None:
    G2.SetPrintLevel("none")
    project = G2.G2Project(gpxfile=str(SOURCE))
    hist = project.histograms()[0]

    # Remove the zero-scale WO3 trial retained during parent screening, then
    # rename the selected active WO3 phase. This leaves exactly the three
    # modeled crystalline phases in the submitted project.
    phases = project.data["Phases"]
    del phases["WO3"]
    phases["WO3"] = phases.pop("WO3_2311041")
    phases["WO3"]["General"]["Name"] = "WO3"
    phase_names = project.names[-1]
    phase_names.remove("WO3")
    phase_names[phase_names.index("WO3_2311041")] = "WO3"
    reflections = hist.data["Reflection Lists"]
    reflections.pop("WO3", None)
    reflections["WO3"] = reflections.pop("WO3_2311041")
    project.data["Covariance"]["data"] = {}
    project.save(str(ROOT / "final.gpx"))

    # Regenerate the numerical profile from the clean project with no
    # parameter optimization.
    project.set_Controls("cycles", 0)
    project.refine()
    project.data["Covariance"]["data"] = {}
    project.save(str(ROOT / "final.gpx"))
    hist = project.histograms()[0]

    export_names = {"MnWO4": "MnWO4.cif", "WO3": "WO3.cif", "Mn2WO5": "Mn2WO5.cif"}
    for phase in project.phases():
        phase.export_CIF(str(ROOT / export_names[phase.name]))

    data = hist.data["data"][1]
    x, observed, calculated = map(np.asarray, (data[0], data[1], data[3]))
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )

    active = project.phases()
    masses = [
        phase.data["General"]["Mass"]
        * phase.data["Histograms"][hist.name]["Scale"][0]
        for phase in active
    ]
    total = float(sum(masses))
    fractions = {phase.name: float(mass / total) for phase, mass in zip(active, masses)}
    weights = 1.0 / np.maximum(observed, 1.0)
    chi_squared = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    rwp = float(100.0 * np.sqrt(chi_squared / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(observed))
    nvars = 27
    dof = int(len(observed) - nvars)
    gof = float(np.sqrt(chi_squared / dof))
    rows = []
    details = {
        "MnWO4": ("MnWO4", "P2/c"),
        "WO3": ("WO3", "P21/c"),
        "Mn2WO5": ("Mn2WO5", "Pnnm"),
    }
    for name in ("MnWO4", "WO3", "Mn2WO5"):
        formula, space_group = details[name]
        rows.append(
            {
                "name": name,
                "formula": formula,
                "space_group": space_group,
                "cif_path": export_names[name],
                "weight_fraction": fractions[name],
            }
        )
    result = {
        "phases": rows,
        "fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": rwp,
            "Rp_percent": rp,
            "chi_squared": chi_squared,
            "goodness_of_fit": gof,
            "data_points": int(len(observed)),
            "refined_variables_last_cycle": nvars,
            "weighting": "1/max(observed_counts, 1)",
        },
        "refinement_histogram": hist.name,
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
