#!/usr/bin/env python3
"""One bounded Pnnm coordinate-refinement start for parallel screening."""

from __future__ import annotations

import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, set_bound
from refine_framework_coordinates import reliable_rwp
from refine_intensity_effects import clear_flags


FREE = np.array(
    [
        [False, False, True],
        [True, True, False],
        [True, True, False],
        [True, True, True],
        [True, True, False],
        [True, True, False],
        [True, True, False],
    ],
    dtype=bool,
)


def disable_old(project) -> None:
    hist = project.histograms()[0]
    hap = project.phases()[1].data["Histograms"][hist.name]
    hap["Scale"] = [0.0, False]
    hap["Use"] = False


def main() -> None:
    start_index = int(sys.argv[1])
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "wo3_231_final" / "model.gpx"
    parent_source = ROOT / ".tmp" / "pnnm_screen" / "Mn2WO5_from_Zn2AsO5.gpx"
    outdir = ROOT / ".tmp" / "p2_multistart"
    outdir.mkdir(parents=True, exist_ok=True)

    parent_project = G2.G2Project(gpxfile=str(parent_source))
    parent = np.asarray([atom.coordinates for atom in parent_project.phases()[2].atoms()], dtype=float)
    # Work only on a byte-for-byte private copy. Some GSAS-II bookkeeping
    # operations may save to the current filename before an explicit save-as.
    path = outdir / f"start_{start_index}.gpx"
    shutil.copy2(source, path)
    project = G2.G2Project(gpxfile=str(path))
    clear_flags(project)
    disable_old(project)
    phase = project.phases()[2]
    lengths = np.asarray(phase.data["General"]["Cell"][1:4], dtype=float)
    current = np.asarray([atom.coordinates for atom in phase.atoms()], dtype=float)

    if start_index == 0:
        coordinates = current
    elif start_index == 1:
        coordinates = parent
    else:
        rng = np.random.default_rng(5000 + start_index)
        sigma_A = np.asarray([0.035 if atom.element != "O" else 0.045 for atom in phase.atoms()])
        displacement = rng.normal(size=parent.shape) * (sigma_A[:, None] / lengths[None, :])
        coordinates = parent + displacement * FREE

    for atom_index, (atom, point) in enumerate(zip(phase.atoms(), coordinates)):
        cap_A = 0.100 if atom.element != "O" else 0.125
        clipped = parent[atom_index] + np.clip(point - parent[atom_index], -cap_A / lengths, cap_A / lengths)
        atom.coordinates = clipped.tolist()
        atom.refinement_flags = "X"
        for direction, center, length in zip("xyz", parent[atom_index], lengths):
            set_bound(project, f"{phase.id}::dA{direction}:{atom_index}",
                      float(center - cap_A / length), float(center + cap_A / length))

    project.data["Covariance"]["data"] = {}
    project.save()
    project.set_Frozen()
    project.set_Controls("cycles", 40)
    project.refine()
    for atom in phase.atoms():
        atom.refinement_flags = " "
    clear_flags(project)
    disable_old(project)
    project.save()
    value = reliable_rwp(project)
    cif = outdir / f"start_{start_index}.cif"
    phase.export_CIF(str(cif))
    record = {"start": start_index, "Rwp": value, "gpx": str(path), "cif": str(cif),
              "coordinates": [list(map(float, atom.coordinates)) for atom in phase.atoms()]}
    (outdir / f"start_{start_index}.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps(record), flush=True)


if __name__ == "__main__":
    main()
