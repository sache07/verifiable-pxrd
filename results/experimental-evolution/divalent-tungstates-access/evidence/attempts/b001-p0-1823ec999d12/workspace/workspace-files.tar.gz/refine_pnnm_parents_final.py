#!/usr/bin/env python3
"""Robust bounded coordinate comparison for the best Pnnm Mn2WO5 parents."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, set_bound
from refine_framework_coordinates import reliable_rwp, set_coordinate_bounds
from refine_intensity_effects import clear_flags


PARENTS = (
    "Mn2WO5_from_Mn2AsO5",
    "Mn2WO5_from_Cu2PO5_9016468",
    "Mn2WO5_from_Zn2AsO5",
    "Mn2WO5_from_Co2AsO5",
)


def refine_atoms(project, phase, labels, cycles=28) -> float:
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.label in labels else " "
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine()
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save()
    return reliable_rwp(project)


def main() -> None:
    G2.SetPrintLevel("warn")
    outdir = ROOT / ".tmp" / "pnnm_final_screen"
    outdir.mkdir(parents=True, exist_ok=True)
    records = []
    for parent in PARENTS:
        source = ROOT / ".tmp" / "pnnm_screen" / f"{parent}.gpx"
        seed = G2.G2Project(gpxfile=str(source))
        clear_flags(seed)
        base_path = outdir / f"{parent}_base.gpx"
        seed.save(str(base_path))
        phase = seed.phases()[2]
        set_coordinate_bounds(seed, phase)
        seed.save()
        baseline = reliable_rwp(seed)
        trials = []
        for sequence_name, groups in (
            ("all", ("all",)),
            ("cations_all", ("cations", "all")),
            ("oxygen_all", ("oxygen", "all")),
            ("W_all", ("W", "all")),
        ):
            project = G2.G2Project(gpxfile=str(base_path))
            clear_flags(project)
            phase = project.phases()[2]
            stages = []
            for group in groups:
                if group == "all":
                    labels = [atom.label for atom in phase.atoms()]
                elif group == "cations":
                    labels = [atom.label for atom in phase.atoms() if atom.element != "O"]
                elif group == "oxygen":
                    labels = [atom.label for atom in phase.atoms() if atom.element == "O"]
                else:
                    labels = [atom.label for atom in phase.atoms() if atom.element == "W"]
                stages.append({"group": group, "Rwp": refine_atoms(project, phase, labels)})
            # Re-optimize the already-supported [001] March-Dollase term after
            # changing structure factors.
            phase.set_HAP_refinements({"Pref.Ori.": True})
            set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
            project.set_Frozen()
            project.set_Controls("cycles", 20)
            project.refine()
            phase.clear_HAP_refinements({"Pref.Ori.": True})
            path = outdir / f"{parent}_{sequence_name}.gpx"
            project.save(str(path))
            final = reliable_rwp(project)
            phase.export_CIF(str(outdir / f"{parent}_{sequence_name}.cif"))
            trial = {
                "sequence": sequence_name,
                "stages": stages,
                "Rwp": final,
                "texture": float(phase.data["Histograms"][project.histograms()[0].name]["Pref.Ori."][1]),
                "path": str(path),
                "cif": str(outdir / f"{parent}_{sequence_name}.cif"),
            }
            trials.append(trial)
            print(parent, json.dumps(trial), flush=True)
        best = min(trials, key=lambda row: row["Rwp"])
        record = {"parent": parent, "baseline_Rwp": baseline, "trials": trials, "best": best}
        records.append(record)

    records.sort(key=lambda row: row["best"]["Rwp"])
    winner = G2.G2Project(gpxfile=records[0]["best"]["path"])
    clear_flags(winner)
    winner.save(str(outdir / "model.gpx"))
    reliable_rwp(winner)
    (outdir / "results.json").write_text(json.dumps(records, indent=2) + "\n")
    print("winner", json.dumps(records[0]), flush=True)


if __name__ == "__main__":
    main()
