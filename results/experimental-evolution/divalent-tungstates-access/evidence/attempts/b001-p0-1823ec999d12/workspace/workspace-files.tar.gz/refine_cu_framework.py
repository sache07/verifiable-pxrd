#!/usr/bin/env python3
"""Bounded coordinate test for the best additional Pnnm parent."""

import json

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_framework_coordinates import (
    refine_stage,
    reliable_rwp,
    set_coordinate_bounds,
)
from refine_intensity_effects import clear_flags


def main() -> None:
    G2.SetPrintLevel("warn")
    source = (
        ROOT
        / ".tmp"
        / "pnnm_screen"
        / "Mn2WO5_from_Cu2PO5_9016468.gpx"
    )
    outdir = ROOT / ".tmp" / "cu_framework"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    phase = project.phases()[2]
    set_coordinate_bounds(project, phase)
    project.save(str(outdir / "base.gpx"))
    rows = [{"stage": "base", "Rwp": reliable_rwp(project)}]
    groups = [
        ("W", [a.label for a in phase.atoms() if a.element == "W"]),
        ("cations", [a.label for a in phase.atoms() if a.element != "O"]),
        ("all", [a.label for a in phase.atoms()]),
    ]
    for name, labels in groups:
        value = refine_stage(project, phase, labels, cycles=24)
        project.save(str(outdir / f"{name}.gpx"))
        rows.append({"stage": name, "Rwp": value})
    phase.set_HAP_refinements({"Pref.Ori.": True})
    set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    project.refine()
    phase.clear_HAP_refinements({"Pref.Ori.": True})
    project.save(str(outdir / "model.gpx"))
    rows.append({"stage": "texture", "Rwp": reliable_rwp(project)})
    export_profile(project)
    (outdir / "stages.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps(rows), flush=True)


if __name__ == "__main__":
    main()
