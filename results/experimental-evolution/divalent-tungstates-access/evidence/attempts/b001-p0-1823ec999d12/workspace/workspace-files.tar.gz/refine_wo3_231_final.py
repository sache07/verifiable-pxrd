#!/usr/bin/env python3
"""Test the physically valid monoclinic WO3 parent in the final Mn-W-O model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from refine_controlled import ROOT, cod_path, set_bound
from refine_framework_coordinates import reliable_rwp
from refine_intensity_effects import AXES, clear_flags


def disable_old(project) -> None:
    hist = project.histograms()[0]
    hap = project.phases()[1].data["Histograms"][hist.name]
    hap["Scale"] = [0.0, False]
    hap["Use"] = False


def clean(project) -> None:
    clear_flags(project)
    disable_old(project)


def refine(project, cycles=22) -> float:
    disable_old(project)
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine()
    clean(project)
    project.save()
    return reliable_rwp(project)


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "final_optimization" / "model.gpx"
    outdir = ROOT / ".tmp" / "wo3_231_final"
    outdir.mkdir(parents=True, exist_ok=True)

    # Save a private working copy before add_phase, because GSAS-II may
    # auto-save phase additions into the project's current filename.
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(outdir / "working.gpx"))
    hist = project.histograms()[0]
    old = project.phases()[1]
    old_hap = old.data["Histograms"][hist.name]
    mass_scale = old.data["General"]["Mass"] * old_hap["Scale"][0]
    disable_old(project)
    phase = project.add_phase(
        str(cod_path("2311041")), phasename="WO3_2311041", histograms=[hist], fmthint="CIF"
    )
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.uiso = 0.010
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [mass_scale / phase.data["General"]["Mass"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.10
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 5500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    set_bound(project, f"{phase.id}:0:Scale", 0.0, 2000.0)
    set_bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
    set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
    for index, value in enumerate(G2lat.cell2A(phase.data["General"]["Cell"][1:7])):
        low, high = (sorted((0.988 * value, 1.012 * value)) if abs(value) >= 0.005
                     else (value - 0.0004, value + 0.0004))
        set_bound(project, f"{phase.id}::A{index}", low, high)
    clean(project)
    hap["Scale"][1] = True
    base = outdir / "base.gpx"
    project.save(str(base))
    rows = [{"stage": "initial", "Rwp": reliable_rwp(project)}]

    # Scale/background, lattice, and isotropic width equilibration.
    rows.append({"stage": "scale", "Rwp": refine(project, 18)})
    phase.set_refinements({"Cell": True})
    rows.append({"stage": "cell", "Rwp": refine(project, 26)})
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    rows.append({"stage": "strain", "Rwp": refine(project, 22)})
    phase.clear_HAP_refinements({"Mustrain": True})
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": hap["Size"][1][0], "refine": True}})
    rows.append({"stage": "size", "Rwp": refine(project, 22)})
    phase.clear_HAP_refinements({"Size": True})
    equilibrated = outdir / "equilibrated.gpx"
    project.save(str(equilibrated))

    # Screen allowed texture axes without contaminating the common source.
    texture_trials = []
    for index, axis in enumerate(AXES):
        trial = G2.G2Project(gpxfile=str(equilibrated))
        clean(trial)
        candidate = trial.phases()[3]
        candidate_hap = candidate.data["Histograms"][trial.histograms()[0].name]
        candidate_hap["Pref.Ori."][:4] = ["MD", 1.0, False, list(axis)]
        candidate.set_HAP_refinements({"Pref.Ori.": True})
        set_bound(trial, f"{candidate.id}:0:MD", 0.7, 1.4)
        path = outdir / f"texture_{index}.gpx"
        trial.save(str(path))
        value = refine(trial, 22)
        texture_trials.append({"axis": list(axis), "ratio": float(candidate_hap["Pref.Ori."][1]),
                               "Rwp": value, "path": str(path)})
        print("texture", json.dumps(texture_trials[-1]), flush=True)
    best_texture = min(texture_trials, key=lambda row: row["Rwp"])
    current = Path(best_texture["path"]) if rows[-1]["Rwp"] - best_texture["Rwp"] > 0.01 else equilibrated

    # Bounded direct coordinate adjustment from the published parent.
    project = G2.G2Project(gpxfile=str(current))
    clean(project)
    phase = project.phases()[3]
    lengths = phase.data["General"]["Cell"][1:4]
    for atom_index, atom in enumerate(phase.atoms()):
        cap = 0.125 if atom.element == "O" else 0.100
        for direction, value, length in zip("xyz", atom.coordinates, lengths):
            set_bound(project, f"{phase.id}::dA{direction}:{atom_index}",
                      float(value) - cap / float(length), float(value) + cap / float(length))
        atom.refinement_flags = "X"
    coordinate_path = outdir / "coordinates.gpx"
    project.save(str(coordinate_path))
    coordinate_rwp = refine(project, 30)
    for atom in phase.atoms():
        atom.refinement_flags = " "

    # Common Uiso grid, with scales and smooth background re-equilibrated.
    uiso_trials = []
    current = coordinate_path
    for value in (0.003, 0.0045, 0.0065, 0.0095, 0.014, 0.020):
        trial = G2.G2Project(gpxfile=str(current))
        clean(trial)
        candidate = trial.phases()[3]
        for atom in candidate.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = value
            atom.refinement_flags = " "
        path = outdir / f"uiso_{value:.4f}.gpx"
        trial.save(str(path))
        score = refine(trial, 16)
        uiso_trials.append({"uiso_A2": value, "Rwp": score, "path": str(path)})
    best_uiso = min(uiso_trials, key=lambda row: row["Rwp"])
    current = Path(best_uiso["path"])

    project = G2.G2Project(gpxfile=str(current))
    clean(project)
    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.save(str(outdir / "model.gpx"))
    final_rwp = refine(project, 24)
    project.save(str(outdir / "model.gpx"))
    for index, item in enumerate(project.phases()):
        if item.data["Histograms"][hist.name].get("Use", True) and item.data["Histograms"][hist.name]["Scale"][0] > 0:
            item.export_CIF(str(outdir / f"phase_{index}.cif"))
    result = {"stages": rows, "texture_trials": texture_trials, "coordinate_Rwp": coordinate_rwp,
              "uiso_trials": uiso_trials, "final_Rwp": final_rwp}
    (outdir / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print("final", json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
