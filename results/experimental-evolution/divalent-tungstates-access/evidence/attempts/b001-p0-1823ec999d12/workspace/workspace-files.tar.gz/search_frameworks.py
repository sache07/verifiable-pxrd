#!/usr/bin/env python3
"""Search ternary-oxide prototypes after explicit Mn/W site substitution.

The supplied library may omit the exact Mn-W-O composition.  A powder search
on the parent chemistry is then misleading because replacing a light cation
with W changes the intensities drastically.  This script maps each two-cation
oxide prototype onto charge-balanced Mn(II)-W(VI)-O formulae, recalculates its
Cu K-alpha powder pattern, and scores the peak positions against the residual
from the independently identified MnWO4 + WO3 model.
"""

from __future__ import annotations

import gzip
import json
import math
import warnings
from collections import defaultdict
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure
from scipy.ndimage import gaussian_filter1d, maximum_filter1d


ROOT = Path(__file__).resolve().parent
INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c06/index.json.gz"
)
CIFS = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c06/cif"
)


def cod_path(cod_id: str) -> Path:
    return CIFS / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def integral_counts(formula: str) -> dict[str, int] | None:
    try:
        values = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return None
    if len(values) != 3 or "O" not in values:
        return None
    if any(abs(value - round(value)) > 1e-6 for value in values.values()):
        return None
    return {key: int(round(value)) for key, value in values.items()}


def mapped_structure(
    structure: Structure, first: str, second: str, first_target: str
) -> Structure:
    result = structure.copy()
    result.remove_oxidation_states()
    second_target = "W" if first_target == "Mn" else "Mn"
    # Simultaneous dictionary substitution prevents cascading Mn -> W -> Mn.
    result.replace_species({first: first_target, second: second_target})
    return result


def calibration(two_theta: np.ndarray) -> np.ndarray:
    # Stable values from the two known phases. Shift is in micrometres and the
    # Bragg-Brentano radius is 200 mm.  The sign follows GSAS-II's convention.
    zero_deg = -0.08128
    shift_mm = -0.800
    return zero_deg - math.degrees(2.0 * shift_mm / 200.0) * np.cos(
        np.deg2rad(two_theta / 2.0)
    )


def transform(positions: np.ndarray, lattice_scale: np.ndarray) -> np.ndarray:
    sine = np.sin(np.deg2rad(positions[None, :] / 2.0)) / lattice_scale[:, None]
    valid = (sine > 0.0) & (sine < 1.0)
    angles = np.full_like(sine, np.nan)
    angles[valid] = 2.0 * np.rad2deg(np.arcsin(sine[valid]))
    angles += calibration(angles)
    return angles


def main() -> None:
    profile = np.loadtxt(
        ROOT / ".tmp" / "three_orth_bounded" / "profile.csv",
        delimiter=",",
        skiprows=1,
    )
    x, observed, _, _, residual = profile.T
    step = float(np.median(np.diff(x)))
    evidence = residual / np.sqrt(np.maximum(observed, 1.0))
    evidence = gaussian_filter1d(evidence, 5.0)
    # Tolerate small anisotropic analogue-cell differences without allowing a
    # calculated line to jump to an unrelated neighbouring peak.
    evidence = maximum_filter1d(evidence, size=max(3, round(0.08 / step)))
    evidence -= np.median(evidence[(x > 12.0) & (x < 98.0)])

    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)

    # parent_id, formula, space group, R, element mapped to Mn, target formula
    work: list[tuple[str, str, int, float | None, str, str, str]] = []
    for system, rows in index.items():
        elements = system.split("-")
        if len(elements) != 3 or "O" not in elements:
            continue
        for formula, cod_id, space_group, rfactor in rows:
            counts = integral_counts(formula)
            if counts is None or set(counts) != set(elements):
                continue
            cations = [element for element in counts if element != "O"]
            a, b = cations
            for first_target in ("Mn", "W"):
                n_mn = counts[a] if first_target == "Mn" else counts[b]
                n_w = counts[b] if first_target == "Mn" else counts[a]
                n_o = counts["O"]
                # Charge balance for Mn(II), W(VI), O(-II). This covers the
                # chemically natural binary-cation products of this reaction.
                if n_o != n_mn + 3 * n_w:
                    continue
                if n_mn + n_w + n_o > 24:
                    continue
                target = Composition({"Mn": n_mn, "W": n_w, "O": n_o}).reduced_formula
                work.append(
                    (str(cod_id), formula, int(space_group), rfactor, a, b, first_target, target)
                )

    scales = np.linspace(0.72, 1.30, 465)
    calculator = XRDCalculator(wavelength=1.540598)
    results: list[dict] = []
    warnings.filterwarnings("ignore")
    for number, item in enumerate(work, 1):
        cod_id, formula, space_group, rfactor, first, second, first_target, target = item
        try:
            source = Structure.from_file(cod_path(cod_id), primitive=False)
            if len(source) > 160:
                continue
            structure = mapped_structure(source, first, second, first_target)
            pattern = calculator.get_pattern(
                structure, two_theta_range=(6.0, 115.0), scaled=True
            )
            positions = np.asarray(pattern.x, dtype=float)
            intensities = np.asarray(pattern.y, dtype=float) / 100.0
            keep = intensities >= 0.0075
            positions, intensities = positions[keep], intensities[keep]
            if len(positions) < 3:
                continue
        except Exception:
            continue

        transformed = transform(positions, scales)
        inside = (transformed >= x[0]) & (transformed <= x[-1])
        values = np.interp(
            np.nan_to_num(transformed, nan=x[0] - 1.0).ravel(),
            x,
            evidence,
            left=-2.0,
            right=-2.0,
        ).reshape(transformed.shape)
        weights = intensities[None, :] * inside
        # Normalize by calculated intensity length so candidates do not win by
        # having either very few or very many lines. Negative residual evidence
        # explicitly penalizes strong calculated peaks that are absent.
        numerator = np.sum(weights * values, axis=1)
        denominator = np.sqrt(np.sum(weights**2, axis=1)) + 1e-12
        scores = numerator / denominator
        best = int(np.nanargmax(scores))
        result = {
            "target_formula": target,
            "parent_formula": formula,
            "cod_id": cod_id,
            "space_group": space_group,
            "rfactor": rfactor,
            "site_mapping": {first: first_target, second: "W" if first_target == "Mn" else "Mn"},
            "score": float(scores[best]),
            "lattice_scale": float(scales[best]),
            "sites": len(source),
            "source_cell": list(source.lattice.parameters),
        }
        results.append(result)
        if number % 250 == 0:
            print(f"searched {number} / {len(work)}", flush=True)

    results.sort(key=lambda row: row["score"], reverse=True)
    out = ROOT / ".tmp" / "framework_ranking.json"
    out.write_text(json.dumps(results, indent=2) + "\n")
    grouped: dict[str, list[dict]] = defaultdict(list)
    for row in results:
        if len(grouped[row["target_formula"]]) < 15:
            grouped[row["target_formula"]].append(row)
    print(json.dumps(dict(grouped), indent=2))


if __name__ == "__main__":
    main()
