#!/usr/bin/env python3
"""Working GSAS-II refinements for the supplied powder pattern.

This is intentionally kept as a reproducible analysis driver.  It builds a
project from the public observation file and a chosen phase CIF, applies
staged refinements, and prints enough state to diagnose subsequent models.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs" / "pattern.csv"
COD_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c06/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_instrument(path: Path) -> None:
    path.write_text(
        "# Cu Kalpha laboratory instrument; GSAS-II starting values\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.36;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phase_rows.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"],
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": atom.coordinates,
                        "flags": atom.refinement_flags,
                        "adp": atom.ADP,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    result = {
        "label": label,
        "wR": hist.get_wR(),
        "residuals": hist.residuals,
        "instrument": hist.InstrumentParameters,
        "sample": hist.SampleParameters,
        "background": hist.Background,
        "phases": phase_rows,
        "varyList": project.data.get("Covariance", {}).get("data", {}).get("varyList", []),
        "variables": project.data.get("Covariance", {}).get("data", {}).get("variables", []),
        "sig": project.data.get("Covariance", {}).get("data", {}).get("sig", []),
    }
    print(json.dumps(result, indent=2, default=lambda x: np.asarray(x).tolist()))
    return result


def run_refinement(project: G2.G2Project, label: str, cycles: int = 8) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    state(project, label)


def build_single(output: Path, cif: Path) -> None:
    work = output.parent
    work.mkdir(parents=True, exist_ok=True)
    inst = work / "working.instprm"
    write_instrument(inst)
    if output.exists():
        output.unlink()

    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phase = project.add_phase(str(cif), phasename="MnWO4", fmthint="CIF")
    # The synthetic source convention uses one isotropic displacement value.
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.uiso = 0.005
        atom.refinement_flags = " "
    hist = project.add_powder_histogram(
        str(INPUT), str(inst), phases=[phase], fmthint="comma"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1600.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [10.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.0
    hap["Mustrain"][2] = [False, False, False]
    project.save()

    run_refinement(project, "background and scale", 8)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_refinement(project, "cell and zero", 10)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_refinement(project, "instrument profile", 12)

    phase.set_HAP_refinements(
        {
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }
    )
    run_refinement(project, "isotropic sample broadening", 12)

    # Coordinates are allowed to move within the crystallographic symmetry.
    phase.set_refinements({"Atoms": {"all": "X"}})
    run_refinement(project, "atomic coordinates", 15)

    # Use one shared isotropic Uiso, matching the generation convention.
    phase.set_refinements({"Atoms": {"all": "XU"}})
    project.add_EquivConstr(
        tuple(f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms()))
    )
    run_refinement(project, "coordinates and shared Uiso", 15)
    project.save()

    data = project.histograms()[0].data["data"][1]
    np.savetxt(
        work / "single_profile.csv",
        np.column_stack((data[0], data[1], data[3], data[4], data[5])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / ".tmp" / "single" / "single.gpx")
    parser.add_argument("--cif", type=Path, default=cod_path("1520200"))
    args = parser.parse_args()
    build_single(args.output.resolve(), args.cif.resolve())


if __name__ == "__main__":
    main()
