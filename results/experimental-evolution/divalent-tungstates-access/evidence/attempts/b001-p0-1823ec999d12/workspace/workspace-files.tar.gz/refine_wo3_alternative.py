#!/usr/bin/env python3
"""Refine texture, strain anisotropy and coordinates for WO3 COD 2311041."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_framework_coordinates import reliable_rwp
from refine_intensity_effects import AXES, clear_flags


def disable_old(project) -> None:
    hist = project.histograms()[0]
    hap = project.phases()[1].data["Histograms"][hist.name]
    hap["Scale"] = [0.0, False]
    hap["Use"] = False


def clean(project) -> None:
    clear_flags(project)
    disable_old(project)


def refine(project, cycles=20) -> float:
    disable_old(project)
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine()
    disable_old(project)
    project.save()
    return reliable_rwp(project)


def set_coordinate_bounds(project, phase) -> None:
    lengths = phase.data["General"]["Cell"][1:4]
    for index, atom in enumerate(phase.atoms()):
        cap = 0.125 if atom.element == "O" else 0.100
        for direction, value, length in zip("xyz", atom.coordinates, lengths):
            delta = cap / float(length)
            set_bound(
                project,
                f"{phase.id}::dA{direction}:{index}",
                float(value) - delta,
                float(value) + delta,
            )


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "wo3_screen" / "WO3_2311041.gpx"
    outdir = ROOT / ".tmp" / "wo3_alternative"
    outdir.mkdir(parents=True, exist_ok=True)
    base = G2.G2Project(gpxfile=str(source))
    clean(base)
    base.save(str(outdir / "base.gpx"))
    baseline = reliable_rwp(base)

    texture_trials = []
    for index, axis in enumerate(AXES):
        project = G2.G2Project(gpxfile=str(outdir / "base.gpx"))
        clean(project)
        phase = project.phases()[3]
        hap = phase.data["Histograms"][project.histograms()[0].name]
        hap["Pref.Ori."][:4] = ["MD", 1.0, False, list(axis)]
        phase.set_HAP_refinements({"Pref.Ori.": True})
        set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
        path = outdir / f"texture_{index}.gpx"
        project.save(str(path))
        value = refine(project, 20)
        texture_trials.append(
            {"axis": list(axis), "ratio": float(hap["Pref.Ori."][1]), "Rwp": value, "path": str(path)}
        )
        print("texture", json.dumps(texture_trials[-1]), flush=True)
    best_texture = min(texture_trials, key=lambda row: row["Rwp"])
    current = Path(best_texture["path"]) if baseline - best_texture["Rwp"] > 0.015 else outdir / "base.gpx"

    strain_trials = []
    for index, axis in enumerate(AXES[:3]):
        project = G2.G2Project(gpxfile=str(current))
        clean(project)
        phase = project.phases()[3]
        hap = phase.data["Histograms"][project.histograms()[0].name]
        equatorial = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][:2] = [equatorial, equatorial]
        hap["Mustrain"][3] = list(axis)
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
        )
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
        set_bound(project, f"{phase.id}:0:Mustrain;a", 0.0, 32000.0)
        path = outdir / f"strain_{index}.gpx"
        project.save(str(path))
        value = refine(project, 20)
        eq, axial = map(float, hap["Mustrain"][1][:2])
        strain_trials.append(
            {"axis": list(axis), "equatorial": eq, "axial": axial, "ratio": axial / eq, "Rwp": value, "path": str(path)}
        )
        print("strain", json.dumps(strain_trials[-1]), flush=True)
    physical = [row for row in strain_trials if 300 <= row["equatorial"] <= 8000 and 0.25 <= row["ratio"] <= 4]
    current_rwp = min(baseline, best_texture["Rwp"])
    best_strain = min(physical, key=lambda row: row["Rwp"], default=None)
    if best_strain and current_rwp - best_strain["Rwp"] > 0.015:
        current = Path(best_strain["path"])

    project = G2.G2Project(gpxfile=str(current))
    clean(project)
    phase = project.phases()[3]
    set_coordinate_bounds(project, phase)
    coordinate_stages = []
    for label, labels in (
        ("W", [atom.label for atom in phase.atoms() if atom.element == "W"]),
        ("all", [atom.label for atom in phase.atoms()]),
    ):
        for atom in phase.atoms():
            atom.refinement_flags = "X" if atom.label in labels else " "
        value = refine(project, 28)
        for atom in phase.atoms():
            atom.refinement_flags = " "
        path = outdir / f"coordinates_{label}.gpx"
        project.save(str(path))
        coordinate_stages.append({"stage": label, "Rwp": value, "path": str(path)})
        print("coordinates", json.dumps(coordinate_stages[-1]), flush=True)

    clean(project)
    project.save(str(outdir / "model.gpx"))
    final = reliable_rwp(project)
    export_profile(project)
    result = {
        "baseline_Rwp": baseline,
        "texture_trials": [{k: v for k, v in row.items() if k != "path"} for row in texture_trials],
        "strain_trials": [{k: v for k, v in row.items() if k != "path"} for row in strain_trials],
        "coordinate_stages": [{k: v for k, v in row.items() if k != "path"} for row in coordinate_stages],
        "final_Rwp": final,
    }
    (outdir / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print("final", json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
