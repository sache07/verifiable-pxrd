#!/usr/bin/env python3
"""Rank library phases against the positive residual after MnWO4 subtraction."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.optimize import differential_evolution


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c06"
)
INDEX = RESOURCE / "index.json.gz"
CIFS = RESOURCE / "cif"


def cod_path(cod_id: str) -> Path:
    return CIFS / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def gaussian_template(
    x: np.ndarray,
    positions: np.ndarray,
    intensities: np.ndarray,
    scale: float,
    shift: float,
    sigma0: float,
    strain: float,
) -> np.ndarray:
    # Isotropic direct-cell scale transforms all d spacings by scale.
    sines = np.sin(np.deg2rad(positions / 2.0)) / scale
    keep = (sines > 0) & (sines < 1)
    pos1 = 2.0 * np.rad2deg(np.arcsin(sines[keep])) + shift
    inten = intensities[keep]
    # Add the known Cu Kalpha2 line explicitly.
    sines2 = sines[keep] * (1.544426 / 1.540598)
    keep2 = sines2 < 1
    pos = np.r_[pos1, 2.0 * np.rad2deg(np.arcsin(sines2[keep2])) + shift]
    amp = np.r_[inten, 0.5 * inten[keep2]]
    result = np.zeros_like(x)
    step = x[1] - x[0]
    for p, a in zip(pos, amp):
        if p < x[0] - 2 or p > x[-1] + 2:
            continue
        sig = np.hypot(sigma0, strain * np.tan(np.deg2rad(p / 2.0)))
        radius = 4.5 * sig
        lo = max(0, int((p - radius - x[0]) / step))
        hi = min(len(x), int((p + radius - x[0]) / step) + 2)
        result[lo:hi] += a * np.exp(-0.5 * ((x[lo:hi] - p) / sig) ** 2)
    return result


def rank(systems: list[str]) -> list[dict]:
    profile = np.loadtxt(ROOT / ".tmp" / "single" / "single_profile.csv", delimiter=",", skiprows=1)
    x, observed, calculated = profile[:, 0], profile[:, 1], profile[:, 2]
    residual = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    rows = []
    for system in systems:
        rows.extend((system, *row[:3]) for row in index.get(system, []))
    calculator = XRDCalculator(wavelength=1.540598)
    results = []
    for system, formula, cod_id, space_group in rows:
        path = cod_path(str(cod_id))
        try:
            structure = Structure.from_file(path, primitive=False)
            pattern = calculator.get_pattern(structure, two_theta_range=(8.0, 103.0), scaled=False)
            pos = np.asarray(pattern.x, float)
            intensity = np.asarray(pattern.y, float)
            intensity /= intensity.max()
        except Exception as exc:
            print("skip", cod_id, type(exc).__name__, str(exc)[:100])
            continue

        def objective(parameters: np.ndarray, return_details: bool = False):
            template = gaussian_template(x, pos, intensity, *parameters)
            norm = float(np.sum(weights * template * template))
            amplitude = max(0.0, float(np.sum(weights * residual * template)) / max(norm, 1e-30))
            improvement = 2 * amplitude * float(np.sum(weights * residual * template)) - amplitude * amplitude * norm
            if return_details:
                return improvement, amplitude
            return -improvement

        fit = differential_evolution(
            objective,
            bounds=[(0.96, 1.04), (-0.35, 0.75), (0.045, 0.22), (0.0, 0.55)],
            seed=7,
            popsize=7,
            maxiter=25,
            polish=True,
            workers=1,
            updating="immediate",
        )
        improvement, amplitude = objective(fit.x, True)
        results.append(
            {
                "system": system,
                "formula": formula,
                "cod_id": str(cod_id),
                "space_group": space_group,
                "improvement": improvement,
                "amplitude": amplitude,
                "cell_scale": fit.x[0],
                "shift_deg": fit.x[1],
                "sigma0_deg": fit.x[2],
                "strain_width_deg": fit.x[3],
                "success": bool(fit.success),
            }
        )
        print(json.dumps(results[-1]))
    results.sort(key=lambda row: row["improvement"], reverse=True)
    return results


if __name__ == "__main__":
    selected = ["Mn-O", "O-W"]
    output = rank(selected)
    path = ROOT / ".tmp" / "binary_phase_ranking.json"
    path.write_text(json.dumps(output, indent=2) + "\n")
    print("TOP")
    print(json.dumps(output[:20], indent=2))
