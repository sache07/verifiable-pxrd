#!/usr/bin/env python3
"""Diagnostic screen for W ordering over the three equal-multiplicity sites."""

import json

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT
from refine_intensity_effects import clear_flags


def main() -> None:
    G2.SetPrintLevel("warn")
    outdir = ROOT / ".tmp" / "cation_ordering"
    outdir.mkdir(parents=True, exist_ok=True)
    sources = {
        "Mn2AsO5": ROOT / ".tmp" / "pnnm_screen" / "Mn2WO5_from_Mn2AsO5.gpx",
        "Cu2PO5": ROOT / ".tmp" / "pnnm_screen" / "Mn2WO5_from_Cu2PO5_9016468.gpx",
    }
    rows = []
    for parent, source in sources.items():
        for w_index in range(3):
            project = G2.G2Project(gpxfile=str(source))
            clear_flags(project)
            phase = project.phases()[2]
            cations = phase.atoms()[:3]
            for index, atom in enumerate(cations):
                atom.type = "W" if index == w_index else "Mn"
                atom.label = ("W" if index == w_index else "Mn") + str(index)
            G2.SetupGeneral(phase.data, None)
            if phase.composition != {"Mn": 8.0, "W": 4.0, "O": 20.0}:
                raise RuntimeError(str(phase.composition))
            project.data["Covariance"]["data"] = {}
            path = outdir / f"{parent}_Wsite{w_index}.gpx"
            project.save(str(path))
            project.set_Frozen()
            project.set_Controls("cycles", 20)
            project.refine()
            project.set_Controls("cycles", 0)
            project.refine()
            project.save()
            row = {
                "parent": parent,
                "W_site": w_index,
                "W_xyz": list(cations[w_index].coordinates),
                "Rwp": float(project.histograms()[0].get_wR()),
                "path": str(path),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["Rwp"])
    (outdir / "ranking.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("winner", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
