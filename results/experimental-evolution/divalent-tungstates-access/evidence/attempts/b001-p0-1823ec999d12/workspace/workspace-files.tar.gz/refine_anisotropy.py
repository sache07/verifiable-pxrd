#!/usr/bin/env python3
"""Screen the generator's allowed uniaxial microstrain models phase by phase."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, run, set_bound, state
from refine_intensity_effects import clear_flags


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def physical_intensity_model(project: G2.G2Project) -> None:
    """Retain the supported intensity terms while removing a failed Uiso trial."""
    # The old equality records refer to atom random IDs and are deliberately
    # discarded. The U values below are fixed, common within each phase and
    # inside the laboratory's allowed interval.
    project.data["Constraints"]["data"]["Phase"] = []
    common_uiso = [0.0043332864, 0.0200, 0.0030]
    for phase, value in zip(project.phases(), common_uiso):
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = value
            atom.refinement_flags = " "


def candidate(source, phase_index: int, axis, path):
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    phase = project.phases()[phase_index]
    hist = project.histograms()[0]
    hap = phase.data["Histograms"][hist.name]
    equatorial = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = equatorial
    hap["Mustrain"][1][1] = equatorial
    hap["Mustrain"][3] = list(axis)
    phase.set_HAP_refinements(
        {"Mustrain": {"type": "uniaxial", "direction": axis, "refine": True}}
    )
    set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
    set_bound(project, f"{phase.id}:0:Mustrain;a", 0.0, 32000.0)
    project.set_Frozen()
    project.save(str(path))
    project.set_Controls("cycles", 18)
    project.refine()
    project.save()
    hap = phase.data["Histograms"][hist.name]
    eq, ax = map(float, hap["Mustrain"][1][:2])
    return {
        "axis": list(axis),
        "Rwp": float(hist.get_wR()),
        "equatorial_ppm": eq,
        "axial_ppm": ax,
        "axial_ratio": ax / eq if eq > 0 else None,
        "path": str(path),
    }


def main() -> None:
    source = ROOT / ".tmp" / "intensity" / "model.gpx"
    outdir = ROOT / ".tmp" / "anisotropy"
    outdir.mkdir(parents=True, exist_ok=True)

    base = G2.G2Project(gpxfile=str(source))
    physical_intensity_model(base)
    clear_flags(base)
    base.save(str(outdir / "base.gpx"))
    # Re-equilibrate phase scales and the empirical background after replacing
    # the invalid ADPs. No structural or line-width variable is active here.
    run(base, "physical intensity baseline", 15)
    current = outdir / "base.gpx"

    choices = []
    for phase_index in range(len(base.phases())):
        baseline_project = G2.G2Project(gpxfile=str(current))
        clear_flags(baseline_project)
        baseline_project.set_Controls("cycles", 0)
        baseline_project.refine()
        baseline = float(baseline_project.histograms()[0].get_wR())
        trials = []
        for axis_index, axis in enumerate(AXES):
            trials.append(
                candidate(
                    current,
                    phase_index,
                    axis,
                    outdir / f"p{phase_index}_a{axis_index}.gpx",
                )
            )
        # The realization constrains axial/equatorial to 0.25..4. Reject
        # mathematically improved candidates outside that physical family.
        physical = [
            row
            for row in trials
            if row["equatorial_ppm"] >= 300.0
            and row["equatorial_ppm"] <= 8000.0
            and row["axial_ratio"] is not None
            and 0.25 <= row["axial_ratio"] <= 4.0
        ]
        best = min(physical, key=lambda row: row["Rwp"], default=None)
        selected = None
        if best is not None and baseline - best["Rwp"] > 0.025:
            selected_project = G2.G2Project(gpxfile=best["path"])
            clear_flags(selected_project)
            selected_project.save(str(outdir / f"selected_p{phase_index}.gpx"))
            current = outdir / f"selected_p{phase_index}.gpx"
            selected = {k: v for k, v in best.items() if k != "path"}
        record = {
            "phase": baseline_project.phases()[phase_index].name,
            "baseline_Rwp": baseline,
            "trials": [{k: v for k, v in row.items() if k != "path"} for row in trials],
            "selected": selected,
        }
        choices.append(record)
        print(json.dumps(record), flush=True)

    final = G2.G2Project(gpxfile=str(current))
    clear_flags(final)
    final.save(str(outdir / "model.gpx"))
    final.set_Controls("cycles", 0)
    final.refine()
    final.save()
    state(final, "selected microstrain anisotropy")
    export_profile(final)
    (outdir / "trials.json").write_text(json.dumps(choices, indent=2) + "\n")


if __name__ == "__main__":
    main()
