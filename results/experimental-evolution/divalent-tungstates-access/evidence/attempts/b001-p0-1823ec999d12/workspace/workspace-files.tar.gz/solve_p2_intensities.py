#!/usr/bin/env python3
"""Fit Pnnm Mn2WO5 coordinates to Le Bail-extracted structure factors."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import ATOMIC_SCATTERING_PARAMS
from pymatgen.core import Element, Lattice
from pymatgen.symmetry.groups import SpaceGroup
from scipy.optimize import least_squares


ROOT = Path(__file__).resolve().parent
FREE = np.array(
    [
        [False, False, True],
        [True, True, False],
        [True, True, False],
        [True, True, True],
        [True, True, False],
        [True, True, False],
        [True, True, False],
    ],
    dtype=bool,
)
OPS = SpaceGroup("Pnnm").symmetry_ops


def orbit(xyz):
    result = []
    for operation in OPS:
        point = np.mod(operation.operate(xyz), 1.0)
        if not any(
            np.linalg.norm((point - old) - np.round(point - old)) < 1e-6
            for old in result
        ):
            result.append(point)
    return result


def expanded(atoms, coordinates):
    xyz, elements, uiso = [], [], []
    for atom, point in zip(atoms, coordinates):
        points = orbit(point)
        xyz.extend(points)
        elements.extend([atom["e"]] * len(points))
        uiso.extend([atom["u"]] * len(points))
    return np.asarray(xyz), elements, np.asarray(uiso)


def form_factors(elements, s2):
    z = np.asarray([Element(element).Z for element in elements])
    coefficients = np.asarray([ATOMIC_SCATTERING_PARAMS[element] for element in elements])
    return z[:, None] - 41.78214 * s2[None, :] * np.sum(
        coefficients[:, :, 0, None]
        * np.exp(-coefficients[:, :, 1, None] * s2[None, None, :]),
        axis=1,
    )


def f_squared(atoms, coordinates, hkl, s2):
    xyz, elements, uiso = expanded(atoms, coordinates)
    factors = form_factors(elements, s2)
    dw = np.exp(-8 * np.pi**2 * uiso[:, None] * s2[None, :])
    phase = np.exp(2j * np.pi * (xyz @ hkl.T))
    return np.abs(np.sum(factors * dw * phase, axis=0)) ** 2


def minimum_contacts(atoms, coordinates, cell):
    xyz, elements, _ = expanded(atoms, coordinates)
    lattice = Lattice.from_parameters(*cell)
    distances = lattice.get_all_distances(xyz, xyz)
    np.fill_diagonal(distances, np.inf)
    values = {"all": float(np.min(distances)), "O-O": np.inf, "Mn-O": np.inf, "W-O": np.inf}
    for i, first in enumerate(elements):
        for j in range(i + 1, len(elements)):
            second = elements[j]
            pair = "-".join(sorted((first, second)))
            key = {"O-O": "O-O", "Mn-O": "Mn-O", "O-W": "W-O"}.get(pair)
            if key:
                values[key] = min(values[key], float(distances[i, j]))
    return values


def main() -> None:
    parents = json.loads((ROOT / ".tmp" / "pnnm_parents.json").read_text())
    reflections = np.loadtxt(ROOT / ".tmp" / "p2_lebail_reflections.csv", delimiter=",")
    use = (reflections[:, 5] >= 14.0) & (reflections[:, 5] <= 80.0) & (reflections[:, 11] > 0.04)
    data = reflections[use]
    hkl = data[:, :3]
    s2 = 1.0 / (4.0 * data[:, 4] ** 2)
    target = np.maximum(data[:, 8], 0.0)
    correction = data[:, 11]
    # Area-Poisson-like weighting: compare structure-factor amplitudes, with
    # the profile intensity correction retaining sensitivity to visible lines.
    weight = np.sqrt(correction / np.median(correction))
    rng = np.random.default_rng(20261108)
    results = []

    for name, parent in sorted(parents.items()):
        atoms = parent["atoms"]
        base = np.asarray([atom["xyz"] for atom in atoms], dtype=float)
        x0 = base[FREE]
        lower = np.r_[x0 - 0.075, -0.8]
        upper = np.r_[x0 + 0.075, 0.8]

        def unpack(values):
            coordinates = base.copy()
            coordinates[FREE] = values[:-1]
            return coordinates, np.exp(values[-1])

        def residual(values):
            coordinates, scale = unpack(values)
            predicted = scale * f_squared(atoms, coordinates, hkl, s2)
            return weight * (np.sqrt(predicted + 25.0) - np.sqrt(target + 25.0)) / 25.0

        starts = [np.r_[x0, 0.0]]
        for _ in range(5):
            starts.append(np.r_[x0 + rng.normal(0.0, 0.018, len(x0)), rng.normal(0.0, 0.1)])
        for start_index, start in enumerate(starts):
            start = np.clip(start, lower + 1e-7, upper - 1e-7)
            fit = least_squares(
                residual,
                start,
                bounds=(lower, upper),
                loss="soft_l1",
                f_scale=1.0,
                max_nfev=2500,
            )
            coordinates, scale = unpack(fit.x)
            result = {
                "parent": name,
                "start": start_index,
                "cost": float(2 * fit.cost / len(target)),
                "scale": float(scale),
                "coordinates": coordinates.tolist(),
                "contacts_A": minimum_contacts(atoms, coordinates, parent["cell"]),
                "active_bounds": int(np.sum(np.isclose(fit.x, lower, atol=2e-5) | np.isclose(fit.x, upper, atol=2e-5))),
                "success": bool(fit.success),
            }
            results.append(result)
            print(json.dumps(result), flush=True)

    results.sort(key=lambda row: row["cost"])
    (ROOT / ".tmp" / "p2_intensity_solutions.json").write_text(json.dumps(results, indent=2) + "\n")
    print("best", json.dumps(results[0]), flush=True)


if __name__ == "__main__":
    main()
