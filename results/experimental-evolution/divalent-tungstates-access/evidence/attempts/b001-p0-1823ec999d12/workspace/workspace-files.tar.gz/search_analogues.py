#!/usr/bin/env python3
"""Powder-fingerprint search for an unresolved ABO4-like phase."""

from __future__ import annotations

import gzip
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy.ndimage import gaussian_filter1d, maximum_filter1d
from scipy.optimize import differential_evolution
from scipy.signal import find_peaks

from search_patterns import CIFS, INDEX, cod_path, gaussian_template


ROOT = Path(__file__).resolve().parent


def is_abo4(formula: str) -> bool:
    try:
        amounts = Composition(formula).reduced_composition.get_el_amt_dict()
    except Exception:
        return False
    if len(amounts) != 3 or "O" not in amounts or abs(amounts["O"] - 4) > 1e-5:
        return False
    return sorted(round(v, 5) for e, v in amounts.items() if e != "O") == [1.0, 1.0]


def prepared_residual() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    profile = np.loadtxt(ROOT / ".tmp" / "single" / "single_profile.csv", delimiter=",", skiprows=1)
    x, observed, calculated = profile[:, 0], profile[:, 1], profile[:, 2]
    residual = observed - calculated

    # Remove the best powder-fingerprint fit for the independently identified
    # monoclinic WO3 component. Parameters are from binary_phase_ranking.json.
    ranking = json.loads((ROOT / ".tmp" / "binary_phase_ranking.json").read_text())
    row = next(item for item in ranking if item["cod_id"] == "1528915")
    structure = Structure.from_file(cod_path("1528915"), primitive=False)
    pattern = XRDCalculator(wavelength=1.540598).get_pattern(
        structure, two_theta_range=(8.0, 103.0), scaled=False
    )
    intensity = np.asarray(pattern.y, float)
    intensity /= intensity.max()
    template = gaussian_template(
        x,
        np.asarray(pattern.x),
        intensity,
        row["cell_scale"],
        row["shift_deg"],
        row["sigma0_deg"],
        row["strain_width_deg"],
    )
    residual -= row["amplitude"] * template

    # Smooth at about half a narrow FWHM and express evidence in counting-noise
    # units. A local maximum filter tolerates analogue cell anisotropy.
    step = x[1] - x[0]
    evidence = gaussian_filter1d(residual / np.sqrt(np.maximum(observed, 1)), 2.0)
    evidence = maximum_filter1d(evidence, size=max(3, int(0.22 / step)))
    evidence -= np.median(evidence[(x > 12) & (x < 98)])
    return x, observed, evidence


def main() -> None:
    x, observed, evidence = prepared_residual()
    pk, props = find_peaks(evidence, prominence=1.0, distance=8)
    order = np.argsort(props["prominences"])[::-1]
    print("Residual evidence peaks")
    print(" ".join(f"{x[pk[j]]:.3f}({props['prominences'][j]:.1f})" for j in order[:40]))

    with gzip.open(INDEX, "rt") as stream:
        index = json.load(stream)
    rows = []
    for system, records in index.items():
        if "O" not in system.split("-") or len(system.split("-")) != 3:
            continue
        for formula, cod_id, space_group, rfactor in records:
            if is_abo4(formula):
                rows.append((formula, str(cod_id), int(space_group), rfactor))

    calculator = XRDCalculator(wavelength=1.540598)
    results = []
    warnings.filterwarnings("ignore")
    for number, (formula, cod_id, space_group, rfactor) in enumerate(rows, 1):
        try:
            structure = Structure.from_file(cod_path(cod_id), primitive=False)
            if len(structure) > 160:
                continue
            pattern = calculator.get_pattern(structure, two_theta_range=(7.0, 110.0), scaled=True)
            positions = np.asarray(pattern.x, float)
            intensities = np.asarray(pattern.y, float) / 100.0
            keep = intensities >= 0.01
            positions, intensities = positions[keep], intensities[keep]
            weights = np.sqrt(intensities)
        except Exception:
            continue

        def objective(parameters: np.ndarray) -> float:
            scale, shift = parameters
            sine = np.sin(np.deg2rad(positions / 2.0)) / scale
            valid = (sine > 0) & (sine < 1)
            transformed = 2 * np.rad2deg(np.arcsin(sine[valid])) + shift
            inside = (transformed >= x[0]) & (transformed <= x[-1])
            if inside.sum() < 3:
                return 1e6
            values = np.interp(transformed[inside], x, evidence)
            ww = weights[valid][inside]
            # Strong calculated peaks should coincide with positive residual
            # evidence; absent peaks count negatively through the un-clipped
            # evidence curve.
            score = np.sum(ww * values) / np.sum(ww)
            return -float(score)

        fit = differential_evolution(
            objective,
            bounds=[(0.80, 1.20), (-0.5, 0.8)],
            seed=int(cod_id),
            popsize=5,
            maxiter=15,
            polish=True,
            updating="immediate",
        )
        results.append(
            {
                "formula": formula,
                "cod_id": cod_id,
                "space_group": space_group,
                "rfactor": rfactor,
                "score": -float(fit.fun),
                "cell_scale": float(fit.x[0]),
                "shift_deg": float(fit.x[1]),
                "sites": len(structure),
            }
        )
        if number % 50 == 0:
            print("searched", number, "of", len(rows))

    results.sort(key=lambda item: item["score"], reverse=True)
    out = ROOT / ".tmp" / "abo4_analogue_ranking.json"
    out.write_text(json.dumps(results, indent=2) + "\n")
    print(json.dumps(results[:40], indent=2))


if __name__ == "__main__":
    main()
