#!/usr/bin/env python3
"""Build staged multiphase GSAS-II projects for phase identification."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "inputs" / "pattern.csv"
COD_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c06/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def phase_source(identifier: str) -> Path:
    candidate = Path(identifier)
    if candidate.exists():
        return candidate.resolve()
    return cod_path(identifier)


def write_instrument(path: Path) -> None:
    path.write_text(
        "# Cu Kalpha laboratory instrument; GSAS-II starting values\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.08;Polariz.:0.70;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def compact_state(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass_scale = phase.data["General"]["Mass"] * hap["Scale"][0]
        masses.append(mass_scale)
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": hap["Size"][1][:2],
                "mustrain": hap["Mustrain"][1][:2],
                "preferred_orientation": hap["Pref.Ori."][:4],
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "uiso": atom.uiso,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total if total > 0 else None
    state = {
        "label": label,
        "wR": hist.get_wR(),
        "instrument": {key: value[1] for key, value in hist.InstrumentParameters.items()},
        "sample": {
            key: (value[0] if isinstance(value, list) else value)
            for key, value in hist.SampleParameters.items()
            if key in {"Scale", "Type", "Gonio. radius", "Shift", "SurfRoughA", "SurfRoughB"}
        },
        "background": list(hist.Background[0][3:]),
        "phases": phases,
        "varyList": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }
    print(json.dumps(state, indent=2))
    (Path(project.filename).parent / "state.json").write_text(json.dumps(state, indent=2) + "\n")
    return state


def refine(project: G2.G2Project, label: str, cycles: int = 12) -> None:
    project.set_Controls("cycles", cycles)
    project.refine()
    compact_state(project, label)


def set_bound(project: G2.G2Project, variable: str, low: float, high: float) -> None:
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def export_profile(project: G2.G2Project, name: str = "profile.csv") -> None:
    data = project.histograms()[0].data["data"][1]
    np.savetxt(
        Path(project.filename).parent / name,
        np.column_stack((data[0], data[1], data[3], data[4], data[5])),
        delimiter=",",
        header="two_theta_deg,observed,calculated,background,difference",
        comments="",
    )


def build(output: Path, specs: list[tuple[str, str, float]], coarse: bool = False) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()
    inst = output.parent / "working.instprm"
    write_instrument(inst)
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(output))
    phases = []
    for cod_id, name, initial_scale in specs:
        phase = project.add_phase(str(phase_source(cod_id)), phasename=name, fmthint="CIF")
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = 0.005
            atom.refinement_flags = " "
        phases.append((phase, initial_scale))
    hist = project.add_powder_histogram(
        str(INPUT), str(inst), phases=[phase for phase, _ in phases], fmthint="comma"
    )
    hist.set_refinements(
        {
            "Limits": [9.90343322, 100.09455322],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1500.0] + [0.0] * 11,
                "refine": True,
            },
        }
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [-500.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    for phase, initial_scale in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [initial_scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.5
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        set_bound(project, f"{phase.id}:0:Scale", 0.0, 2000.0)
        # Reference mismatch in the synthetic lab is at most 0.5% strain.
        # A slightly wider reciprocal-metric box permits calibration
        # correlation without allowing a wrong phase to invent a new cell.
        reciprocal = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
        for index, value in enumerate(reciprocal):
            if abs(value) >= 0.005:
                low, high = sorted((0.97 * value, 1.03 * value))
            else:
                low, high = value - 0.001, value + 0.001
            set_bound(project, f"{phase.id}::A{index}", low, high)
    set_bound(project, ":0:Zero", -0.25, 0.25)
    set_bound(project, ":0:Shift", -800.0, 800.0)
    for key, low, high in [
        ("U", 0.0, 40.0),
        ("W", 2.0, 40.0),
        ("X", 0.1, 6.0),
        ("SH/L", 0.005, 0.10),
        ("Polariz.", 0.5, 1.0),
    ]:
        set_bound(project, f":0:{key}", low, high)
    project.save()

    refine(project, "background and phase scales", 10)

    for phase, _ in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, "cells and angular calibration", 15)

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine(project, "shared instrument profile", 15)

    for phase, _ in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "value": 0.5, "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
        set_bound(project, f"{phase.id}:0:Size;i", 0.04, 2.0)
        set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
    refine(project, "phase-specific isotropic widths", 15)

    if coarse:
        project.save()
        export_profile(project)
        return

    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    refine(project, "polarization", 12)

    for phase, _ in phases:
        phase.set_refinements({"Atoms": {"all": "X"}})
    refine(project, "atomic coordinates", 18)

    for phase, _ in phases:
        phase.set_refinements({"Atoms": {"all": "XU"}})
        project.add_EquivConstr(
            tuple(f"{phase.id}::AUiso:{i}" for i, _ in enumerate(phase.atoms()))
        )
        set_bound(project, f"{phase.id}::AUiso:0", 0.001, 0.03)
    refine(project, "coordinates and shared phase Uiso", 18)
    project.save()
    export_profile(project)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / ".tmp" / "two" / "two.gpx")
    parser.add_argument(
        "--phase",
        action="append",
        nargs=3,
        metavar=("COD_ID", "NAME", "INITIAL_SCALE"),
        help="Repeat for each phase",
    )
    parser.add_argument("--coarse", action="store_true", help="Stop before atomic refinement")
    args = parser.parse_args()
    raw = args.phase or [["1520200", "MnWO4", "230"], ["1528915", "WO3", "80"]]
    specs = [(cod_id, name, float(scale)) for cod_id, name, scale in raw]
    build(args.output.resolve(), specs, coarse=args.coarse)


if __name__ == "__main__":
    main()
