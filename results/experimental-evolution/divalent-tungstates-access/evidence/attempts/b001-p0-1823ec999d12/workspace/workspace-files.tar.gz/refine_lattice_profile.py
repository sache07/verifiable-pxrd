#!/usr/bin/env python3
"""Re-equilibrate lattice and profile terms after selecting Mn2WO5 framework."""

from __future__ import annotations

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, run, state
from refine_intensity_effects import clear_flags


def main() -> None:
    source = ROOT / ".tmp" / "framework_compare" / "model.gpx"
    outdir = ROOT / ".tmp" / "lattice_profile"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    project.save(str(outdir / "model.gpx"))

    # The analogue comparison used a common provisional cell. Recover the
    # independent a,b,c values from its many resolved diagnostic reflections.
    p0, p1, p2 = project.phases()
    p2.set_refinements({"Cell": True})
    project.set_Frozen()
    run(project, "Mn2WO5 cell", 25)
    p2.clear_refinements({"Cell": True})

    # Revisit the two major-phase cells at the now-stable calibration, followed
    # by a common-zero pass. Cell and zero are alternated to limit correlation.
    for phase in (p0, p1):
        phase.set_refinements({"Cell": True})
    project.set_Frozen()
    run(project, "major-phase cells", 20)
    for phase in (p0, p1):
        phase.clear_refinements({"Cell": True})

    hist = project.histograms()[0]
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Frozen()
    run(project, "common zero", 18)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})

    for phase in project.phases():
        phase.set_refinements({"Cell": True})
    project.set_Frozen()
    run(project, "all cells after zero", 20)
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})

    # The old common width hit bounds before anisotropic phase broadening was
    # introduced. Refit it, then the selected phase-specific width terms.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    project.set_Frozen()
    run(project, "shared profile", 22)
    hist.clear_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})

    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap["Mustrain"][0] == "uniaxial":
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "uniaxial", "refine": True}}
            )
        else:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
    project.set_Frozen()
    run(project, "phase microstrain", 22)
    for phase in project.phases():
        phase.clear_HAP_refinements({"Mustrain": True})

    for phase in project.phases():
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
    project.set_Frozen()
    run(project, "phase size", 22)
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True})

    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    state(project, "lattice/profile model complete")
    export_profile(project)


if __name__ == "__main__":
    main()
