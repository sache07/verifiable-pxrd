#!/usr/bin/env python3
"""Refine physically bounded Mn2WO5 coordinates for each Pnnm parent."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_intensity_effects import clear_flags


def imported_atoms(cif: Path, scratch: Path):
    project = G2.G2Project(newgpx=str(scratch))
    phase = project.add_phase(str(cif), phasename="candidate", fmthint="CIF")
    return copy.deepcopy(phase.data["Atoms"])


def reliable_rwp(project: G2.G2Project) -> float:
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    return float(project.histograms()[0].get_wR())


def set_coordinate_bounds(project: G2.G2Project, phase) -> None:
    cell = phase.data["General"]["Cell"][1:4]
    for index, atom in enumerate(phase.atoms()):
        # Exact generator cap: max(0.05 A, 2.5*rms), with rms <=0.04 A for
        # cations and <=0.05 A for oxygen.
        distance = 0.125 if atom.element == "O" else 0.100
        for direction, value, length in zip("xyz", atom.coordinates, cell):
            delta = distance / float(length)
            set_bound(
                project,
                f"{phase.id}::dA{direction}:{index}",
                float(value) - delta,
                float(value) + delta,
            )


def set_atom_flags(phase, labels) -> None:
    for atom in phase.atoms():
        atom.refinement_flags = "X" if atom.label in labels else " "


def refine_stage(project: G2.G2Project, phase, labels, cycles=22) -> float:
    set_atom_flags(phase, labels)
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine()
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save()
    return reliable_rwp(project)


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "lattice_profile" / "model.gpx"
    outdir = ROOT / ".tmp" / "framework_coordinates"
    outdir.mkdir(parents=True, exist_ok=True)
    results = []
    for cif in sorted((ROOT / ".tmp" / "candidates").glob("Mn2WO5_from_*.cif")):
        label = cif.stem.removeprefix("Mn2WO5_from_")
        project = G2.G2Project(gpxfile=str(source))
        clear_flags(project)
        phase = project.phases()[2]
        phase.data["Atoms"] = imported_atoms(cif, outdir / "scratch.gpx")
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = 0.003
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][project.histograms()[0].name]
        hap["Pref.Ori."][:4] = ["MD", 1.35, False, [0, 0, 1]]
        project.data["Covariance"]["data"] = {}
        set_coordinate_bounds(project, phase)
        base_path = outdir / f"{label}.gpx"
        project.save(str(base_path))

        # Refit scale/background and the already selected [001] texture for the
        # new structure factors before changing atomic positions.
        phase.set_HAP_refinements({"Pref.Ori.": True})
        set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
        project.set_Frozen()
        project.set_Controls("cycles", 18)
        project.refine()
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        project.save()
        baseline = reliable_rwp(project)

        stages = []
        wlabels = [atom.label for atom in phase.atoms() if atom.element == "W"]
        cations = [atom.label for atom in phase.atoms() if atom.element != "O"]
        all_labels = [atom.label for atom in phase.atoms()]
        for name, labels in (
            ("W", wlabels),
            ("cations", cations),
            ("all", all_labels),
        ):
            value = refine_stage(project, phase, labels)
            stages.append({"stage": name, "Rwp": value})

        # Re-optimize texture after structure-factor changes.
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Frozen()
        project.set_Controls("cycles", 18)
        project.refine()
        phase.clear_HAP_refinements({"Pref.Ori.": True})
        project.save()
        final_rwp = reliable_rwp(project)
        ratio = float(
            phase.data["Histograms"][project.histograms()[0].name]["Pref.Ori."][1]
        )
        project.save(str(outdir / f"{label}_final.gpx"))
        record = {
            "parent": label,
            "baseline_Rwp": baseline,
            "stages": stages,
            "texture_ratio": ratio,
            "final_Rwp": final_rwp,
            "path": str(outdir / f"{label}_final.gpx"),
        }
        results.append(record)
        print(json.dumps(record), flush=True)

    results.sort(key=lambda row: row["final_Rwp"])
    winner = G2.G2Project(gpxfile=results[0]["path"])
    clear_flags(winner)
    winner.save(str(outdir / "model.gpx"))
    reliable_rwp(winner)
    export_profile(winner)
    (outdir / "comparison.json").write_text(json.dumps(results, indent=2) + "\n")
    print("winner", json.dumps(results[0]), flush=True)


if __name__ == "__main__":
    main()
