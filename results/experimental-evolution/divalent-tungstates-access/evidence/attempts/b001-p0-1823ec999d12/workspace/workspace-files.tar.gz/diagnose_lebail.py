#!/usr/bin/env python3
"""Diagnostic only: test whether the selected three lattices span all peaks."""

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIstrMain as G2main

from refine_controlled import ROOT, export_profile
from refine_intensity_effects import clear_flags


def main() -> None:
    source = ROOT / ".tmp" / "lattice_profile" / "model.gpx"
    outdir = ROOT / ".tmp" / "lebail"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    # Keep scales/background fixed for a pure reflection-intensity diagnostic.
    project.histograms()[0].clear_refinements({"Background": {"refine": False}})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Scale": True})
        phase.set_refinements({"LeBail": True})
    project.save(str(outdir / "diagnostic.gpx"))
    G2main.DoLeBail(project.filename, cycles=20)
    project.reload()
    project.save()
    export_profile(project)
    print("Le Bail Rwp", project.histograms()[0].get_wR())


if __name__ == "__main__":
    main()
