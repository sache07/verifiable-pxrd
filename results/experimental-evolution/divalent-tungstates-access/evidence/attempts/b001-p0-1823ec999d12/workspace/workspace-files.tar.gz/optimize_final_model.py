#!/usr/bin/env python3
"""Conservative final alternation for the geometry-screened three-phase model."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, set_bound
from refine_framework_coordinates import reliable_rwp
from refine_intensity_effects import AXES, clear_flags


def run_trial(source: Path, path: Path, setup, cycles=20):
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    setup(project)
    project.save(str(path))
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine()
    clear_flags(project)
    project.save()
    value = reliable_rwp(project)
    return project, value


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "pnnm_final_screen" / "Mn2WO5_from_Zn2AsO5_all.gpx"
    outdir = ROOT / ".tmp" / "final_optimization"
    outdir.mkdir(parents=True, exist_ok=True)
    base = G2.G2Project(gpxfile=str(source))
    clear_flags(base)
    current = outdir / "base.gpx"
    base.save(str(current))
    current_rwp = reliable_rwp(base)
    history = [{"stage": "base", "Rwp": current_rwp, "accepted": True}]

    def consider(label, setup, cycles=20, threshold=0.0005):
        nonlocal current, current_rwp
        path = outdir / f"{len(history):02d}_{label}.gpx"
        _, value = run_trial(current, path, setup, cycles)
        accepted = value < current_rwp - threshold
        history.append({"stage": label, "Rwp": value, "accepted": accepted, "path": str(path)})
        if accepted:
            current, current_rwp = path, value
        print(json.dumps(history[-1]), flush=True)

    # Re-equilibrate lattice and peak-shape parameters after the improved
    # minor-phase structure factors.
    consider("all_cells", lambda p: [q.set_refinements({"Cell": True}) for q in p.phases()], 24)
    consider(
        "shared_profile",
        lambda p: p.histograms()[0].set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]}),
        24,
    )

    def activate_strain(project, index):
        phase = project.phases()[index]
        hap = phase.data["Histograms"][project.histograms()[0].name]
        kind = hap["Mustrain"][0]
        request = {"type": kind, "refine": True}
        if kind == "uniaxial":
            request["direction"] = list(hap["Mustrain"][3])
        phase.set_HAP_refinements({"Mustrain": request})

    def activate_size(project, index):
        phase = project.phases()[index]
        hap = phase.data["Histograms"][project.histograms()[0].name]
        phase.set_HAP_refinements(
            {"Size": {"type": hap["Size"][0], "value": hap["Size"][1][0], "refine": True}}
        )

    for index in range(3):
        consider(
            f"strain_p{index}",
            lambda p, i=index: activate_strain(p, i),
            22,
        )
        consider(
            f"size_p{index}",
            lambda p, i=index: activate_size(p, i),
            22,
        )
    consider("zero", lambda p: p.histograms()[0].set_refinements({"Instrument Parameters": ["Zero"]}), 18)
    consider("polarization", lambda p: p.histograms()[0].set_refinements({"Instrument Parameters": ["Polariz."]}), 18)

    # Rescreen the allowed texture axes after the minor structure-factor update.
    texture_rows = []
    for axis_index, axis in enumerate(AXES):
        def texture_setup(project, chosen=axis):
            phase = project.phases()[2]
            hap = phase.data["Histograms"][project.histograms()[0].name]
            hap["Pref.Ori."][:4] = ["MD", 1.0, False, list(chosen)]
            phase.set_HAP_refinements({"Pref.Ori.": True})
            set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)

        path = outdir / f"texture_axis_{axis_index}.gpx"
        project, value = run_trial(current, path, texture_setup, 22)
        ratio = float(project.phases()[2].data["Histograms"][project.histograms()[0].name]["Pref.Ori."][1])
        texture_rows.append({"axis": list(axis), "ratio": ratio, "Rwp": value, "path": str(path)})
        print("texture", json.dumps(texture_rows[-1]), flush=True)
    best_texture = min(texture_rows, key=lambda row: row["Rwp"])
    accepted = best_texture["Rwp"] < current_rwp - 0.002
    history.append({"stage": "texture_screen", "Rwp": best_texture["Rwp"], "accepted": accepted,
                    "axis": best_texture["axis"], "ratio": best_texture["ratio"], "path": best_texture["path"]})
    if accepted:
        current, current_rwp = Path(best_texture["path"]), best_texture["Rwp"]

    # Coordinate-descent grid for phase-common isotropic displacements avoids
    # the unstable equivalence constraints in GSAS-II.
    uiso_grid = (0.0030, 0.0045, 0.0065, 0.0095, 0.0140, 0.0200)
    uiso_rows = []
    for phase_index in range(3):
        trials = []
        for value in uiso_grid:
            def uiso_setup(project, i=phase_index, chosen=value):
                for atom in project.phases()[i].atoms():
                    atom.data[atom.cia] = "I"
                    atom.uiso = chosen
                    atom.refinement_flags = " "

            path = outdir / f"uiso_p{phase_index}_{value:.4f}.gpx"
            _, score = run_trial(current, path, uiso_setup, 14)
            trials.append({"uiso_A2": value, "Rwp": score, "path": str(path)})
        best = min(trials, key=lambda row: row["Rwp"])
        accepted = best["Rwp"] < current_rwp - 0.0005
        uiso_rows.append({"phase_index": phase_index, "trials": trials, "best": best, "accepted": accepted})
        if accepted:
            current, current_rwp = Path(best["path"]), best["Rwp"]
        print("uiso", json.dumps(uiso_rows[-1]), flush=True)

    # Test a slightly richer smooth background basis; retain it only when the
    # full weighted profile improves.
    background_rows = []
    for terms in (10, 12, 16, 20):
        def background_setup(project, count=terms):
            hist = project.histograms()[0]
            old = list(hist.data["Background"][0][3:])
            coeffs = (old + [0.0] * count)[:count]
            hist.data["Background"][0] = ["chebyschev-1", True, count] + coeffs

        path = outdir / f"background_{terms}.gpx"
        _, score = run_trial(current, path, background_setup, 20)
        background_rows.append({"terms": terms, "Rwp": score, "path": str(path)})
        print("background", json.dumps(background_rows[-1]), flush=True)
    best_background = min(background_rows, key=lambda row: row["Rwp"])
    accepted = best_background["Rwp"] < current_rwp - 0.002
    history.append({"stage": "background_screen", "Rwp": best_background["Rwp"], "accepted": accepted,
                    "terms": best_background["terms"], "path": best_background["path"]})
    if accepted:
        current, current_rwp = Path(best_background["path"]), best_background["Rwp"]

    # One final bounded local update of the Pnnm atoms; geometry is screened
    # separately before this candidate can be accepted for submission.
    def p2_coordinates(project):
        for atom in project.phases()[2].atoms():
            atom.refinement_flags = "X"

    consider("p2_coordinates_final", p2_coordinates, 32, threshold=0.002)
    consider(
        "profile_final",
        lambda p: p.histograms()[0].set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]}),
        22,
    )

    final = G2.G2Project(gpxfile=str(current))
    clear_flags(final)
    final.save(str(outdir / "model.gpx"))
    final_rwp = reliable_rwp(final)
    for index, phase in enumerate(final.phases()):
        phase.export_CIF(str(outdir / f"phase_{index}.cif"))
    result = {
        "final_Rwp": final_rwp,
        "selected_path": str(current),
        "history": history,
        "texture_trials": texture_rows,
        "uiso_trials": uiso_rows,
        "background_trials": background_rows,
    }
    (outdir / "results.json").write_text(json.dumps(result, indent=2) + "\n")
    print("final", json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
