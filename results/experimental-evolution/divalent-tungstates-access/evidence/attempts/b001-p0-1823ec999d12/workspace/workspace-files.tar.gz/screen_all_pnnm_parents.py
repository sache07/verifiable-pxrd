#!/usr/bin/env python3
"""Fast full-pattern screen of every available Pnnm M2XO5 parent."""

from __future__ import annotations

import copy
import json

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT
from refine_intensity_effects import clear_flags


def atoms_from_cif(cif, scratch):
    project = G2.G2Project(newgpx=str(scratch))
    phase = project.add_phase(str(cif), phasename="candidate", fmthint="CIF")
    return copy.deepcopy(phase.data["Atoms"])


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "major_coordinates" / "model.gpx"
    outdir = ROOT / ".tmp" / "pnnm_screen"
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for cif in sorted((ROOT / ".tmp" / "candidates").glob("Mn2WO5_from_*.cif")):
        project = G2.G2Project(gpxfile=str(source))
        clear_flags(project)
        phase = project.phases()[2]
        phase.data["Atoms"] = atoms_from_cif(cif, outdir / "scratch.gpx")
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = 0.003
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][project.histograms()[0].name]
        hap["Pref.Ori."][:4] = ["MD", 1.4, False, [0, 0, 1]]
        project.data["Covariance"]["data"] = {}
        path = outdir / f"{cif.stem}.gpx"
        project.save(str(path))
        project.set_Frozen()
        project.set_Controls("cycles", 20)
        project.refine()
        project.set_Controls("cycles", 0)
        project.refine()
        project.save()
        row = {"parent": cif.stem, "Rwp": float(project.histograms()[0].get_wR()), "path": str(path)}
        rows.append(row)
        print(json.dumps(row), flush=True)
    rows.sort(key=lambda row: row["Rwp"])
    (outdir / "ranking.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("winner", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
