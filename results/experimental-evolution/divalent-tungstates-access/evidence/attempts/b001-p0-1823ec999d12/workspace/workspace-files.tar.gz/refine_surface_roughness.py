#!/usr/bin/env python3
"""Screen the allowed Suortti surface-roughness effect from multiple starts."""

import json

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_intensity_effects import clear_flags


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "cu_framework" / "model.gpx"
    outdir = ROOT / ".tmp" / "roughness"
    outdir.mkdir(parents=True, exist_ok=True)
    baseline_project = G2.G2Project(gpxfile=str(source))
    clear_flags(baseline_project)
    baseline_project.set_Controls("cycles", 0)
    baseline_project.refine()
    baseline_project.save(str(outdir / "none.gpx"))
    baseline = float(baseline_project.histograms()[0].get_wR())
    rows = [{"A": 0.0, "B": 0.0, "Rwp": baseline, "path": str(outdir / "none.gpx")}]
    for ai, a0 in enumerate((0.10, 0.30, 0.50)):
        for bi, b0 in enumerate((0.03, 0.12, 0.35)):
            project = G2.G2Project(gpxfile=str(source))
            clear_flags(project)
            hist = project.histograms()[0]
            hist.SampleParameters["SurfRoughA"] = [a0, True]
            hist.SampleParameters["SurfRoughB"] = [b0, True]
            set_bound(project, ":0:SurfRoughA", 0.05, 0.60)
            set_bound(project, ":0:SurfRoughB", 0.02, 0.50)
            project.set_Frozen()
            path = outdir / f"a{ai}_b{bi}.gpx"
            project.save(str(path))
            project.set_Controls("cycles", 22)
            project.refine()
            hist.clear_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
            project.set_Controls("cycles", 0)
            project.refine()
            project.save()
            rows.append(
                {
                    "A": float(hist.SampleParameters["SurfRoughA"][0]),
                    "B": float(hist.SampleParameters["SurfRoughB"][0]),
                    "Rwp": float(hist.get_wR()),
                    "path": str(path),
                }
            )
    rows.sort(key=lambda row: row["Rwp"])
    best = rows[0]
    # Require a material reduction because this pair is highly correlated near
    # the no-effect limit.
    selected = best if baseline - best["Rwp"] > 0.025 else next(r for r in rows if r["A"] == 0.0)
    final = G2.G2Project(gpxfile=selected["path"])
    clear_flags(final)
    final.save(str(outdir / "model.gpx"))
    final.set_Controls("cycles", 0)
    final.refine()
    final.save()
    export_profile(final)
    (outdir / "trials.json").write_text(json.dumps(rows, indent=2) + "\n")
    print(json.dumps({"baseline_Rwp": baseline, "selected": {k:v for k,v in selected.items() if k != "path"}}), flush=True)


if __name__ == "__main__":
    main()
