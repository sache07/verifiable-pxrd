#!/usr/bin/env python3
"""Refine major-phase coordinates inside the generator's displacement caps."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_intensity_effects import clear_flags


def set_bounds(project, phase):
    lengths = phase.data["General"]["Cell"][1:4]
    for index, atom in enumerate(phase.atoms()):
        cap = 0.125 if atom.element == "O" else 0.100
        for direction, value, length in zip("xyz", atom.coordinates, lengths):
            delta = cap / float(length)
            set_bound(
                project,
                f"{phase.id}::dA{direction}:{index}",
                float(value) - delta,
                float(value) + delta,
            )


def calc(project):
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    return float(project.histograms()[0].get_wR())


def stage(project, phase_index, labels, path):
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = " "
    phase = project.phases()[phase_index]
    for atom in phase.atoms():
        if atom.label in labels:
            atom.refinement_flags = "X"
    project.set_Frozen()
    project.set_Controls("cycles", 24)
    project.refine()
    for atom in phase.atoms():
        atom.refinement_flags = " "
    project.save(str(path))
    return calc(project)


def texture(project, phase_index, path):
    phase = project.phases()[phase_index]
    phase.set_HAP_refinements({"Pref.Ori.": True})
    set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
    project.set_Frozen()
    project.set_Controls("cycles", 20)
    project.refine()
    phase.clear_HAP_refinements({"Pref.Ori.": True})
    project.save(str(path))
    return calc(project)


def accept_best(paths):
    scored = []
    for path in paths:
        project = G2.G2Project(gpxfile=str(path))
        scored.append((float(project.histograms()[0].get_wR()), path))
    return min(scored)[1]


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "framework_coordinates" / "model.gpx"
    outdir = ROOT / ".tmp" / "major_coordinates"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    for phase in project.phases()[:2]:
        set_bounds(project, phase)
    base = outdir / "base.gpx"
    project.save(str(base))
    calc(project)
    records = []

    p0 = project.phases()[0]
    p0_cations = [a.label for a in p0.atoms() if a.element != "O"]
    p0_all = [a.label for a in p0.atoms()]
    p0_paths = [base]
    for label, atoms in (("cations", p0_cations), ("all", p0_all)):
        path = outdir / f"MnWO4_{label}.gpx"
        value = stage(project, 0, atoms, path)
        p0_paths.append(path)
        records.append({"phase": "MnWO4", "stage": label, "Rwp": value})
    selected = accept_best(p0_paths)
    project = G2.G2Project(gpxfile=str(selected))
    clear_flags(project)
    value = texture(project, 0, outdir / "MnWO4_selected.gpx")
    records.append({"phase": "MnWO4", "stage": "texture", "Rwp": value})

    p1 = project.phases()[1]
    p1_w = [a.label for a in p1.atoms() if a.element == "W"]
    p1_all = [a.label for a in p1.atoms()]
    p1_start = outdir / "MnWO4_selected.gpx"
    p1_paths = [p1_start]
    for label, atoms in (("W", p1_w), ("all", p1_all)):
        path = outdir / f"WO3_{label}.gpx"
        value = stage(project, 1, atoms, path)
        p1_paths.append(path)
        records.append({"phase": "WO3", "stage": label, "Rwp": value})
    selected = accept_best(p1_paths)
    project = G2.G2Project(gpxfile=str(selected))
    clear_flags(project)
    value = texture(project, 1, outdir / "WO3_selected.gpx")
    records.append({"phase": "WO3", "stage": "texture", "Rwp": value})

    clear_flags(project)
    project.save(str(outdir / "model.gpx"))
    final = calc(project)
    export_profile(project)
    (outdir / "stages.json").write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps({"final_Rwp": final, "stages": records}), flush=True)


if __name__ == "__main__":
    main()
