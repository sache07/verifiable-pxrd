#!/usr/bin/env python3
"""Build documented analogue-derived starting models for refinement."""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(__file__).resolve().parent
COD_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/"
    "divalent-tungstates-access/resources/b001-c06/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    # All four parents share the Pnnm Mn2AsO5 framework and reproduce the
    # unresolved phase's line positions after cell scaling. Build each mapped
    # model so their structure factors can be compared by Rietveld refinement.
    # The common cell is the position-only refinement result; using it here
    # isolates atomic arrangement from trivial lattice differences.
    lattice = Lattice.orthorhombic(8.6952683, 8.8641332, 6.3617736)
    parents = [
        ("9000178", {"As": "W"}, "Mn2AsO5"),
        ("9015147", {"Zn": "Mn", "As": "W"}, "Zn2AsO5"),
        ("2101671", {"Al": "Mn", "Si": "W"}, "Al2SiO5"),
        ("1524664", {"Co": "Mn", "As": "W"}, "Co2AsO5"),
        ("9015082", {"Cu": "Mn", "As": "W"}, "Cu2AsO5"),
        ("9016468", {"Cu": "Mn", "P": "W"}, "Cu2PO5_9016468"),
        ("1528172", {"Cu": "Mn", "P": "W"}, "Cu2PO5_1528172"),
    ]
    for cod_id, mapping, label in parents:
        source = Structure.from_file(cod_path(cod_id), primitive=False)
        source.remove_oxidation_states()
        source.replace_species(mapping)
        model = Structure(
            lattice,
            [site.species for site in source],
            source.frac_coords,
            site_properties=source.site_properties,
        )
        destination = ROOT / ".tmp" / "candidates" / f"Mn2WO5_from_{label}.cif"
        destination.parent.mkdir(parents=True, exist_ok=True)
        CifWriter(model, symprec=0.001, significant_figures=10).write_file(destination)
        print(destination)
        print(model.composition.reduced_formula, model.get_space_group_info(symprec=0.001))
        print(model.lattice)

    # Position-search controls for a competing Mn3WO6 assignment. These two
    # analogues need essentially no lattice rescaling and therefore satisfy the
    # same modest-reference-adjustment standard as the Mn2WO5 parents.
    alternatives = [
        ("2211529", {"Zn": "Mn", "Te": "W"}, "Mn3WO6_from_Zn3TeO6", 1.0025),
        ("2211528", {"Te": "W"}, "Mn3WO6_from_Mn3TeO6", 0.99625),
    ]
    for cod_id, mapping, label, scale in alternatives:
        source = Structure.from_file(cod_path(cod_id), primitive=False)
        source.remove_oxidation_states()
        source.replace_species(mapping)
        a, b, c = (value * scale for value in source.lattice.abc)
        alpha, beta, gamma = source.lattice.angles
        model = Structure(
            Lattice.from_parameters(a, b, c, alpha, beta, gamma),
            [site.species for site in source],
            source.frac_coords,
            site_properties=source.site_properties,
        )
        destination = ROOT / ".tmp" / "candidates" / f"{label}.cif"
        CifWriter(model, symprec=0.001, significant_figures=10).write_file(destination)
        print(destination)
        print(model.composition.reduced_formula, model.get_space_group_info(symprec=0.001))
        print(model.lattice)


if __name__ == "__main__":
    main()
