#!/usr/bin/env python3
"""Bounded coordinate refinement from the selected three-phase model."""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, run, set_bound, state
from refine_intensity_effects import clear_flags


def set_coordinate_bounds(project: G2.G2Project) -> None:
    for phase in project.phases():
        for index, atom in enumerate(phase.atoms()):
            # Despite the historical dA* variable name, GSAS-II's control
            # bounds apply to the absolute fractional coordinate. A +/-0.02
            # box is wider than the generated 0.05 A perturbation but prevents
            # powder-only intensity fitting from creating another framework.
            for direction, value in zip("xyz", atom.coordinates):
                set_bound(
                    project,
                    f"{phase.id}::dA{direction}:{index}",
                    float(value) - 0.020,
                    float(value) + 0.020,
                )


def atom_flags(phase, labels: list[str]) -> None:
    phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
    for label in labels:
        phase.set_refinements({"Atoms": {label: "X"}})


def main() -> None:
    source = ROOT / ".tmp" / "intensity" / "model.gpx"
    outdir = ROOT / ".tmp" / "coordinates"
    outdir.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(source))
    project.save(str(outdir / "model.gpx"))
    clear_flags(project)

    # Replace the failed equivalence-constraint trial with physical common
    # phase values. The boundary choices preserve the direction supported by
    # that trial without retaining its invalid dependent atom values.
    common_uiso = [0.0043332864, 0.0200, 0.0030]
    for phase, value in zip(project.phases(), common_uiso):
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.uiso = value
            atom.refinement_flags = " "
    project.save()
    project.set_Controls("cycles", 0)
    project.refine()
    state(project, "physical common Uiso reset")
    set_coordinate_bounds(project)

    p0, p1, p2 = project.phases()
    stages = [
        (p2, ["W2"], "Mn2WO5 W coordinate"),
        (p2, ["Mn0", "Mn1", "W2"], "Mn2WO5 cation coordinates"),
        (p2, [a.label for a in p2.atoms()], "Mn2WO5 all coordinates"),
        (p0, ["Mn1", "W1"], "MnWO4 cation coordinates"),
        (p0, [a.label for a in p0.atoms()], "MnWO4 all coordinates"),
        (p1, [a.label for a in p1.atoms() if a.element == "W"], "WO3 W coordinates"),
        (p1, [a.label for a in p1.atoms()], "WO3 all coordinates"),
    ]
    for phase, labels, label in stages:
        for other in project.phases():
            other.clear_refinements({"Atoms": [a.label for a in other.atoms()]})
        atom_flags(phase, labels)
        project.set_Frozen()
        run(project, label, 20)

    for phase in project.phases():
        phase.clear_refinements({"Atoms": [a.label for a in phase.atoms()]})

    # Re-optimize the large, physically allowed target texture after its
    # structure factors have changed. Other weak texture terms remain fixed.
    hap = p2.data["Histograms"][project.histograms()[0].name]
    hap["Pref.Ori."][2] = True
    set_bound(project, f"{p2.id}:0:MD", 0.7, 1.4)
    project.set_Frozen()
    run(project, "Mn2WO5 texture after coordinates", 15)
    hap["Pref.Ori."][2] = False

    project.save()
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    state(project, "coordinate model complete")
    export_profile(project)


if __name__ == "__main__":
    main()
