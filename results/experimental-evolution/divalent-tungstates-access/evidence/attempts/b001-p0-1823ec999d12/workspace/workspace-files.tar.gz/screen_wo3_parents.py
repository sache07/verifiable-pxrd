#!/usr/bin/env python3
"""Screen plausible WO3 polymorphs in the refined three-phase pattern model."""

from __future__ import annotations

import json

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

from refine_controlled import ROOT, cod_path, set_bound
from refine_framework_coordinates import reliable_rwp
from refine_intensity_effects import clear_flags


COD_IDS = (
    "2311041",
    "1528915",
    "2107312",
    "2106293",
    "1010618",
    "1521532",
    "1521533",
    "1563541",
)


def disable_old(project, old, hist) -> None:
    hap = old.data["Histograms"][hist.name]
    hap["Scale"] = [0.0, False]
    hap["Use"] = False


def calculate(project) -> float:
    project.set_Controls("cycles", 0)
    project.refine()
    project.save()
    return float(project.histograms()[0].get_wR())


def refine(project, cycles=18) -> float:
    project.set_Frozen()
    project.set_Controls("cycles", cycles)
    project.refine()
    project.save()
    return calculate(project)


def configure(project, phase, hist, mass_scale) -> None:
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.uiso = 0.020
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [mass_scale / phase.data["General"]["Mass"], True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 0.11
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 6500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][:4] = ["MD", 1.0, False, [0, 0, 1]]
    set_bound(project, f"{phase.id}:0:Scale", 0.0, 2000.0)
    set_bound(project, f"{phase.id}:0:Size;i", 0.04, 1.5)
    set_bound(project, f"{phase.id}:0:Mustrain;i", 0.0, 8000.0)
    reciprocal = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
    for index, value in enumerate(reciprocal):
        if abs(value) >= 0.005:
            low, high = sorted((0.988 * value, 1.012 * value))
        else:
            low, high = value - 0.0004, value + 0.0004
        set_bound(project, f"{phase.id}::A{index}", low, high)


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "roughness" / "model.gpx"
    outdir = ROOT / ".tmp" / "wo3_screen"
    outdir.mkdir(parents=True, exist_ok=True)
    results = []
    for cod_id in COD_IDS:
        project = G2.G2Project(gpxfile=str(source))
        clear_flags(project)
        hist = project.histograms()[0]
        old = project.phases()[1]
        old_hap = old.data["Histograms"][hist.name]
        mass_scale = old.data["General"]["Mass"] * old_hap["Scale"][0]
        disable_old(project, old, hist)
        phase = project.add_phase(
            str(cod_path(cod_id)),
            phasename=f"WO3_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        configure(project, phase, hist, mass_scale)
        disable_old(project, old, hist)
        path = outdir / f"WO3_{cod_id}.gpx"
        project.save(str(path))
        stages = {"initial": calculate(project)}

        # Scale/background first, then lattice and line widths. The shared
        # instrument terms are allowed one final update because the old WO3
        # model influenced their previous optimum.
        stages["scale"] = refine(project, 16)
        phase.set_refinements({"Cell": True})
        stages["cell"] = refine(project, 22)
        phase.clear_refinements({"Cell": True})
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
        stages["strain"] = refine(project, 18)
        phase.clear_HAP_refinements({"Mustrain": True})
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}
        )
        stages["size"] = refine(project, 18)
        phase.clear_HAP_refinements({"Size": True})
        hist.set_refinements(
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
        )
        stages["profile"] = refine(project, 20)
        hist.clear_refinements(
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
        )
        disable_old(project, old, hist)
        clear_flags(project)
        disable_old(project, old, hist)
        project.save()
        final = calculate(project)
        hap = phase.data["Histograms"][hist.name]
        result = {
            "cod_id": cod_id,
            "Rwp": final,
            "stages": stages,
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "scale": float(hap["Scale"][0]),
            "size_um": float(hap["Size"][1][0]),
            "strain_ppm": float(hap["Mustrain"][1][0]),
            "path": str(path),
        }
        results.append(result)
        print(json.dumps(result), flush=True)

    results.sort(key=lambda row: row["Rwp"])
    (outdir / "ranking.json").write_text(json.dumps(results, indent=2) + "\n")
    print("winner", json.dumps(results[0]), flush=True)


if __name__ == "__main__":
    main()
