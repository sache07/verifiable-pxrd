#!/usr/bin/env python3
"""Compare Pnnm Mn2WO5 analogue parents by full-pattern structure factors."""

from __future__ import annotations

import copy
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from refine_controlled import ROOT, export_profile, set_bound
from refine_intensity_effects import AXES, clear_flags


def read_atoms(cif: Path, scratch: Path):
    project = G2.G2Project(newgpx=str(scratch))
    phase = project.add_phase(str(cif), phasename="candidate", fmthint="CIF")
    return copy.deepcopy(phase.data["Atoms"])


def prepare(source: Path, cif: Path, output: Path, scratch: Path):
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    phase = project.phases()[2]
    phase.data["Atoms"] = read_atoms(cif, scratch)
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.uiso = 0.003
        atom.refinement_flags = " "
    hap = phase.data["Histograms"][project.histograms()[0].name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    project.data["Covariance"]["data"] = {}
    project.set_Frozen()
    project.save(str(output))
    project.set_Controls("cycles", 18)
    project.refine()
    project.save()
    return project


def texture_trial(source: Path, axis, output: Path):
    project = G2.G2Project(gpxfile=str(source))
    clear_flags(project)
    phase = project.phases()[2]
    hap = phase.data["Histograms"][project.histograms()[0].name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][3] = list(axis)
    phase.set_HAP_refinements({"Pref.Ori.": True})
    set_bound(project, f"{phase.id}:0:MD", 0.7, 1.4)
    project.set_Frozen()
    project.save(str(output))
    project.set_Controls("cycles", 18)
    project.refine()
    project.save()
    return project


def main() -> None:
    G2.SetPrintLevel("warn")
    source = ROOT / ".tmp" / "anisotropy" / "model.gpx"
    outdir = ROOT / ".tmp" / "framework_compare"
    outdir.mkdir(parents=True, exist_ok=True)
    rows = []
    for cif in sorted((ROOT / ".tmp" / "candidates").glob("Mn2WO5_from_*.cif")):
        label = cif.stem.removeprefix("Mn2WO5_from_")
        base_path = outdir / f"{label}_base.gpx"
        base = prepare(source, cif, base_path, outdir / "scratch.gpx")
        baseline = float(base.histograms()[0].get_wR())
        trials = []
        for index, axis in enumerate(AXES):
            path = outdir / f"{label}_texture_{index}.gpx"
            trial = texture_trial(base_path, axis, path)
            hap = trial.phases()[2].data["Histograms"][trial.histograms()[0].name]
            trials.append(
                {
                    "axis": list(axis),
                    "ratio": float(hap["Pref.Ori."][1]),
                    "Rwp": float(trial.histograms()[0].get_wR()),
                    "path": str(path),
                }
            )
        best = min(trials, key=lambda row: row["Rwp"])
        selected = base_path
        if baseline - best["Rwp"] > 0.015:
            selected = Path(best["path"])
        selected_project = G2.G2Project(gpxfile=str(selected))
        clear_flags(selected_project)
        selected_project.save(str(outdir / f"{label}_selected.gpx"))
        record = {
            "parent": label,
            "baseline_Rwp": baseline,
            "texture_trials": [
                {k: v for k, v in row.items() if k != "path"} for row in trials
            ],
            "selected": (
                {k: v for k, v in best.items() if k != "path"}
                if selected != base_path
                else None
            ),
            "selected_Rwp": float(selected_project.histograms()[0].get_wR()),
            "selected_path": str(outdir / f"{label}_selected.gpx"),
        }
        rows.append(record)
        print(json.dumps(record), flush=True)

    rows.sort(key=lambda row: row["selected_Rwp"])
    winner = G2.G2Project(gpxfile=rows[0]["selected_path"])
    winner.save(str(outdir / "model.gpx"))
    winner.set_Controls("cycles", 0)
    winner.refine()
    winner.save()
    export_profile(winner)
    (outdir / "comparison.json").write_text(json.dumps(rows, indent=2) + "\n")
    print("winner", json.dumps(rows[0]), flush=True)


if __name__ == "__main__":
    main()
