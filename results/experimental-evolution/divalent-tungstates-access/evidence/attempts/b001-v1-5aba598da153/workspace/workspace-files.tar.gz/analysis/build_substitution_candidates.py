#!/usr/bin/env python3
"""Construct target-composition ZnWO4 candidates from oxide prototypes."""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c05/cif")
CANDIDATES = {
    "1567215": {"substitution": {"Fe": "Zn"}, "name": "FeWO4 wolframite parent"},
    "1528282": {"substitution": {"Mo": "W"}, "name": "ZnMoO4 triclinic parent"},
    "1549132": {"substitution": {"Cd": "Zn"}, "name": "CdWO4 scheelite parent"},
}


def source_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    destination = Path("analysis/candidates/znwo4_substitutions")
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for cod_id, specification in CANDIDATES.items():
        source = source_path(cod_id)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(source, primitive=False)
        structure.remove_oxidation_states()
        structure.replace_species(specification["substitution"])
        if structure.composition.reduced_formula != "ZnWO4":
            raise RuntimeError(f"Unexpected substituted formula for {cod_id}: {structure.composition}")
        for index, site in enumerate(structure):
            site.label = f"{site.species_string}{index}"
        writer = CifWriter(structure, symprec=0.001, significant_figures=10)
        for block in writer.cif_file.data.values():
            tag = "_atom_site_U_iso_or_equiv"
            block.data[tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
            loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
            if tag not in loop:
                loop.append(tag)
        output = destination / f"znwo4_from_{cod_id}.cif"
        output.write_text(str(writer) + "\n")
        distances = structure.distance_matrix
        minimum = float(np.min(distances[distances > 1.0e-8]))
        record = {
            "cod_id": cod_id,
            "prototype": specification["name"],
            "source": str(source),
            "output": str(output),
            "substitution": specification["substitution"],
            "composition": structure.composition.formula,
            "space_group": structure.get_space_group_info(symprec=0.01),
            "sites": len(structure),
            "minimum_contact_A_before_fit": minimum,
            "hard_contact_failure": minimum < 0.8,
        }
        records.append(record)
        print(json.dumps(record))
    (destination / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
