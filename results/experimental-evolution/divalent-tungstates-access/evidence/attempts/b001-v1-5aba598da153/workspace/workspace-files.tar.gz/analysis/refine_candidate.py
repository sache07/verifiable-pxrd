#!/usr/bin/env python3
"""Stage a reproducible single-candidate GSAS-II screening refinement."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def instrument_text() -> str:
    return (
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.70;Azimuth:0.0\n"
        "U:15.0;V:0.0;W:15.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def prepare_observation(csv_path: Path, target: Path) -> None:
    arr = np.loadtxt(csv_path, delimiter=",", skiprows=1)
    sigma = np.sqrt(np.maximum(arr[:, 1], 1.0))
    np.savetxt(target, np.column_stack((arr, sigma)), fmt="%.8f %.8f %.8f")


def current(value):
    if isinstance(value, (list, tuple)) and len(value) > 1:
        return value[1]
    return value


def finite_cell(phase) -> bool:
    c = phase.data["General"]["Cell"][1:8]
    return all(math.isfinite(float(v)) for v in c) and min(c[:3]) > 1.0 and float(c[6]) > 1.0


def collect(project, phase_name: str, hist_name: str) -> dict:
    phase = project.phase(phase_name)
    hist = project.histogram(hist_name)
    hap = phase.data["Histograms"][hist_name]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    return {
        "rwp_percent_recomputed": float(100 * np.sqrt(loss / denom)),
        "rwp_percent_gsas": hist.get_wR(),
        "weighted_residual_sum": loss,
        "cell": {k: float(v) for k, v in phase.get_cell().items()},
        "scale": float(hap["Scale"][0]),
        "cell_mass": float(phase.data["General"]["Mass"]),
        "instrument": {k: float(current(inst[k])) for k in ("Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz.")},
        "sample": {
            k: float(current(sample[k]))
            for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")
        },
        "size": hap["Size"],
        "mustrain": hap["Mustrain"],
        "background": hist.data["Background"][0],
        "calc_min": float(np.min(calc)),
        "background_min": float(np.min(bkg)),
        "n_vary": len(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def active_check(project, phase_name: str, hist_name: str) -> None:
    phases = project.phases()
    if [p.name for p in phases] != [phase_name]:
        raise RuntimeError(f"Expected only {phase_name!r} active, found {[p.name for p in phases]!r}")
    phase = project.phase(phase_name)
    hap = phase.data["Histograms"].get(hist_name)
    if not hap or not hap.get("Use", True):
        raise RuntimeError("Intended candidate is not active on the observed histogram")
    if not math.isfinite(float(hap["Scale"][0])) or float(hap["Scale"][0]) <= 0:
        raise RuntimeError("Intended candidate does not have a positive initialized scale")


def run_stage(project, phase_name: str, hist_name: str, out: Path, stage: str, records: list[dict]) -> None:
    active_check(project, phase_name, hist_name)
    rollback = out.with_name(out.stem + ".rollback.gpx")
    project.save()
    shutil.copy2(out, rollback)
    try:
        project.refine()
        phase = project.phase(phase_name)
        if not finite_cell(phase):
            raise RuntimeError("Refinement produced a nonphysical cell")
        rec = {"stage": stage, "status": "tested", **collect(project, phase_name, hist_name)}
        if rec["scale"] <= 0 or not math.isfinite(rec["rwp_percent_recomputed"]):
            raise RuntimeError("Refinement produced an invalid scale or objective")
        snap = out.with_name(out.stem + f".{stage}.gpx")
        project.save()
        shutil.copy2(out, snap)
        rec["project"] = str(snap)
        records.append(rec)
    except Exception as exc:
        shutil.copy2(rollback, out)
        project.reload()
        records.append({"stage": stage, "status": "unknown", "error": repr(exc)})
        raise
    finally:
        rollback.unlink(missing_ok=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("cif", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--observed", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--phase-name", default="ZnWO4_wolframite")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    out = args.output.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    datafile = out.with_suffix(".xye")
    instfile = out.with_suffix(".instprm")
    prepare_observation(args.observed.resolve(), datafile)
    instfile.write_text(instrument_text())

    project = G2.G2Project(newgpx=str(out))
    hist = project.add_powder_histogram(str(datafile), str(instfile), fmthint="xye")
    phase = project.add_phase(
        str(args.cif.resolve()),
        phasename=args.phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    hist_name = hist.name
    phase_name = phase.name

    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    # Keep the histogram normalization fixed. Only the identity-addressed HAP
    # scale is refined, avoiding the exactly redundant global/HAP scale pair.
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.set_refinements({"Limits": [float(np.loadtxt(args.observed, delimiter=",", skiprows=1)[0, 0]), 100.09455322]})
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [1250.0] + [0.0] * 7,
                "refine": True,
            }
        }
    )
    hap = phase.data["Histograms"][hist_name]
    hap["Scale"] = [10.0, False]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    phase.set_HAP_refinements({"Scale": True}, histograms=[hist_name])
    project.set_Controls("cycles", 8)
    project.save()

    records: list[dict] = []
    run_stage(project, phase_name, hist_name, out, "scale_background", records)

    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_stage(project, phase_name, hist_name, out, "cell_zero", records)

    # Test specimen displacement with angular zero held at the preceding value.
    # These are strongly correlated in a single Bragg-Brentano scan.
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_stage(project, phase_name, hist_name, out, "cell_shift_fixed_zero", records)

    project.index_ids()
    for key, lo, hi in (
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
    ):
        project.set_Controls("parmMin", lo, variable=key)
        project.set_Controls("parmMax", hi, variable=key)
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_stage(project, phase_name, hist_name, out, "isotropic_instrument", records)

    summary = {
        "candidate": str(args.cif.resolve()),
        "phase_name": phase_name,
        "histogram": hist_name,
        "status": records[-1]["status"],
        "stages": records,
    }
    out.with_suffix(".json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(json.dumps(summary, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
