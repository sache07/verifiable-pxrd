#!/usr/bin/env python3
"""Fit relative phase broadening with one fixed size reference."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def report(project, hist_name):
    hist = project.histogram(hist_name)
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    masses, rows = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        rows.append(
            {
                "name": phase.name,
                "phase_id": int(phase.data["pId"]),
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "size": float(hap["Size"][1][0]),
                "size_refine": bool(hap["Size"][2][0]),
                "mustrain": float(hap["Mustrain"][1][0]),
                "mustrain_refine": bool(hap["Mustrain"][2][0]),
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = float(mass / total)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "rwp_percent": float(100 * np.sqrt(loss / denom)),
        "loss": loss,
        "background_min": float(np.min(bkg)),
        "calc_min": float(np.min(calc)),
        "instrument": {k: float(inst[k][1]) for k in ("U", "W", "X", "SH/L")},
        "phases": rows,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def refine(project, out, hist_name, name, records, keep_only_if_better=True):
    rollback = out.with_name(out.stem + ".rollback.gpx")
    project.save()
    shutil.copy2(out, rollback)
    previous = records[-1]["rwp_percent"]
    project.refine()
    row = {"stage": name, "status": "tested", **report(project, hist_name)}
    valid = (
        math.isfinite(row["rwp_percent"])
        and row["background_min"] >= 0
        and row["calc_min"] >= 0
        and all(p["scale"] > 0 for p in row["phases"])
    )
    if not valid or (keep_only_if_better and row["rwp_percent"] > previous + 1e-7):
        shutil.copy2(rollback, out)
        project.reload()
        row["status"] = "rejected" if valid else "unknown"
        row["reason"] = "objective did not improve" if valid else "nonphysical/failed profile stage"
        row["rolled_back_to_rwp_percent"] = previous
    else:
        snap = out.with_name(out.stem + f".{name}.gpx")
        project.save()
        shutil.copy2(out, snap)
        row["project"] = str(snap)
    rollback.unlink(missing_ok=True)
    records.append(row)
    print(json.dumps({"stage": name, "status": row["status"], "rwp_percent": row["rwp_percent"], "profiles": {p["name"]: [p["size"], p["mustrain"]] for p in row.get("phases", [])}}), flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--reference", required=True)
    ap.add_argument("--broadened", nargs="+", required=True)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = args.output.resolve()
    shutil.copy2(args.base.resolve(), out)
    project = G2.G2Project(gpxfile=str(out))
    reference = project.phase(args.reference)
    broadened = [project.phase(n) for n in args.broadened]
    if reference is None or any(p is None for p in broadened) or len(project.phases()) != 1 + len(broadened):
        raise RuntimeError("Reference and broadened names must cover every project phase")
    hist_name = next(iter(reference.data["Histograms"]))
    hist = project.histogram(hist_name)
    hid = int(hist.id)
    project.set_Controls("cycles", 25)

    # Reset to the simple physical model, choose product size as the fixed
    # reference, and let X describe the common Lorentzian width.
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
    hist.clear_refinements({"Instrument Parameters": ["U", "SH/L"]})
    hist.set_refinements({"Instrument Parameters": ["X"]})
    project.index_ids()
    project.set_Controls("parmMin", 0.1, variable=f":{hid}:X")
    project.set_Controls("parmMax", 6.0, variable=f":{hid}:X")
    records = [{"stage": "physical_profile_rollback", "status": "tested", **report(project, hist_name)}]
    refine(project, out, hist_name, "common_x_fixed_reference_size", records)

    for phase in broadened:
        pid = int(phase.data["pId"])
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.3, "refine": True}}, histograms=[hist_name])
        project.index_ids()
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:{hid}:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:{hid}:Size;i")
        refine(project, out, hist_name, f"relative_size_phase_{pid}", records)

    # With instrumental U fixed, isotropic phase strains are identifiable as
    # relative tan(theta) broadening. Test each and automatically roll back a
    # non-improving addition.
    for phase in (reference, *broadened):
        pid = int(phase.data["pId"])
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, histograms=[hist_name])
        project.index_ids()
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;i")
        refine(project, out, hist_name, f"relative_mustrain_phase_{pid}", records)

    out.with_suffix(".json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
