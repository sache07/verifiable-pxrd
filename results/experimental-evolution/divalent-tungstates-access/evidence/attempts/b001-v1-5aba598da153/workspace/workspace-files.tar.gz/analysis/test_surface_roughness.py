#!/usr/bin/env python3
"""Test the two-parameter Suortti surface-roughness correction."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def metrics(project: G2.G2Project) -> dict:
    hist = project.histograms()[0]
    data = hist.data["data"][1]
    y, w, calc, bkg = [np.asarray(data[i], float) for i in (1, 2, 3, 4)]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), float)
    pairs = []
    if matrix.ndim == 2 and matrix.shape == (len(names), len(names)):
        d = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        with np.errstate(divide="ignore", invalid="ignore"):
            corr = matrix / np.outer(d, d)
        for i in range(len(names)):
            for j in range(i):
                if np.isfinite(corr[i, j]) and abs(corr[i, j]) >= 0.9:
                    pairs.append([float(corr[i, j]), names[j], names[i]])
        pairs.sort(key=lambda row: abs(row[0]), reverse=True)
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    total = sum(masses)
    return {
        "rwp_percent": float(100.0 * math.sqrt(loss / denom)),
        "gof": float(rvals.get("GOF", float("nan"))),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", float("nan"))),
        "surface_roughness_A": float(sample["SurfRoughA"][0]),
        "surface_roughness_B": float(sample["SurfRoughB"][0]),
        "roughness_refine_flags": [bool(sample["SurfRoughA"][1]), bool(sample["SurfRoughB"][1])],
        "background_min": float(np.min(bkg)),
        "calculated_min": float(np.min(calc)),
        "fractions": [float(value / total) for value in masses],
        "high_correlations": pairs,
        "message": str(rvals.get("msg", "")),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output = args.output.resolve()
    shutil.copy2(args.base.resolve(), output)
    project = G2.G2Project(gpxfile=str(output))
    hist = project.histograms()[0]
    baseline = metrics(project)
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [0.25, True]
    sample["SurfRoughB"] = [0.10, True]
    project.index_ids()
    hid = int(hist.id)
    project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughA")
    project.set_Controls("parmMax", 0.6, variable=f":{hid}:SurfRoughA")
    project.set_Controls("parmMin", 0.0, variable=f":{hid}:SurfRoughB")
    project.set_Controls("parmMax", 0.5, variable=f":{hid}:SurfRoughB")
    project.set_Controls("cycles", 50)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    project.save()
    project.refine()
    project.refine()
    project.save()
    tested = metrics(project)
    status = "tested"
    if (
        tested["background_min"] < 0
        or tested["calculated_min"] < 0
        or not (0.0 < tested["surface_roughness_A"] < 0.6)
        or not (0.0 < tested["surface_roughness_B"] < 0.5)
    ):
        status = "unknown"
    result = {"baseline": baseline, "roughness_trial": tested, "status": status}
    output.with_suffix(".json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": status, **tested}), flush=True)


if __name__ == "__main__":
    main()
