#!/usr/bin/env python3
"""Build the physically conservative three-phase branch from a saved rollback."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def summarize(project, hist_name):
    hist = project.histogram(hist_name)
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        atoms = [
            {
                "label": str(a[ct - 1]),
                "element": str(a[ct]),
                "xyz": [float(v) for v in a[cx : cx + 3]],
                "uiso": float(a[cia + 1]),
                "flags": str(a[ct + 1]),
            }
            for a in phase.data["Atoms"]
        ]
        phases.append(
            {
                "name": phase.name,
                "phase_id": int(phase.data["pId"]),
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
                "volume": float(phase.data["General"]["Cell"][7]),
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "atoms": atoms,
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = float(mass / total)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "rwp_percent": float(100 * np.sqrt(loss / denom)),
        "loss": loss,
        "background_min": float(np.min(bkg)),
        "calc_min": float(np.min(calc)),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: float(sample[k][0]) for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "phases": phases,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def stage(project, out, hist_name, name, records):
    rollback = out.with_name(out.stem + ".rollback.gpx")
    project.save()
    shutil.copy2(out, rollback)
    try:
        project.refine()
        row = {"stage": name, "status": "tested", **summarize(project, hist_name)}
        if (
            not math.isfinite(row["rwp_percent"])
            or row["background_min"] < 0
            or row["calc_min"] < 0
            or any(p["scale"] <= 0 for p in row["phases"])
        ):
            raise RuntimeError("nonphysical staged result")
        snap = out.with_name(out.stem + f".{name}.gpx")
        project.save()
        shutil.copy2(out, snap)
        row["project"] = str(snap)
        records.append(row)
        print(json.dumps({"stage": name, "rwp_percent": row["rwp_percent"], "fractions": {p["name"]: p["weight_fraction"] for p in row["phases"]}}), flush=True)
    except Exception as exc:
        shutil.copy2(rollback, out)
        project.reload()
        records.append({"stage": name, "status": "unknown", "error": repr(exc)})
        raise
    finally:
        rollback.unlink(missing_ok=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--product", required=True)
    ap.add_argument("--wo3", required=True)
    ap.add_argument("--zno", required=True)
    ap.add_argument("--zno-u", type=float, default=0.3821)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = args.output.resolve()
    shutil.copy2(args.base.resolve(), out)
    project = G2.G2Project(gpxfile=str(out))
    phases = [project.phase(n) for n in (args.product, args.wo3, args.zno)]
    if any(p is None for p in phases) or len(project.phases()) != 3:
        raise RuntimeError("Expected the named closed three-phase inventory")
    hist_name = next(iter(phases[0].data["Histograms"]))
    project.set_Controls("cycles", 20)

    # The ZnO coordinate-only branch moved u by ~0.03 (about 0.16 A) for a
    # negligible objective gain. Restore the published internal coordinate and
    # keep it fixed; the principal/WO3 heavy and principal oxygen coordinates
    # from the supplied rollback remain active.
    zno = phases[2]
    cx, ct, cs, cia = zno.data["General"]["AtomPtrs"]
    oxygen = [a for a in zno.data["Atoms"] if str(a[ct]) == "O"]
    if len(oxygen) != 1:
        raise RuntimeError("Expected one independent O site in wurtzite ZnO")
    oxygen[0][cx + 2] = float(args.zno_u)
    oxygen[0][ct + 1] = " "
    records = [{"stage": "selected_coordinate_rollback", "status": "tested", **summarize(project, hist_name)}]
    stage(project, out, hist_name, "settled_physical_coordinates", records)

    hist = project.histogram(hist_name)
    hid = int(hist.id)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.index_ids()
    project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
    stage(project, out, hist_name, "polarization", records)

    for phase in phases:
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        pid = int(phase.data["pId"])
        variables = []
        for i, atom in enumerate(phase.data["Atoms"]):
            atom[cia + 1] = 0.008
            flags = str(atom[ct + 1])
            atom[ct + 1] = "XU" if "X" in flags else "U"
            variables.append(f"{pid}::AUiso:{i}")
        if len(variables) > 1:
            project.save()
            project.add_EquivConstr(tuple(variables))
        project.set_Controls("parmMin", 0.001, variable=variables[0])
        project.set_Controls("parmMax", 0.030, variable=variables[0])
    stage(project, out, hist_name, "phase_common_uiso", records)
    out.with_suffix(".json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
