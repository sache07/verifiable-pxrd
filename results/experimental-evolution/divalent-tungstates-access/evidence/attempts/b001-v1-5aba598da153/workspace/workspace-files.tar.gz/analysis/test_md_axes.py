#!/usr/bin/env python3
"""Test March-Dollase axes from one stable GSAS-II rollback project."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1))


def metrics(project, phase_name, hist_name):
    phase = project.phase(phase_name)
    hist = project.histogram(hist_name)
    hap = phase.data["Histograms"][hist_name]
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    return {
        "rwp_percent": float(100 * np.sqrt(loss / denom)),
        "loss": loss,
        "scale": float(hap["Scale"][0]),
        "md_ratio": float(hap["Pref.Ori."][1]),
        "md_axis": list(hap["Pref.Ori."][3]),
        "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
        "background_min": float(np.min(bkg)),
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("output_dir", type=Path)
    ap.add_argument("--phase", required=True)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for axis in AXES:
        tag = "".join(map(str, axis))
        out = (args.output_dir / f"md_{tag}.gpx").resolve()
        shutil.copy2(args.base.resolve(), out)
        project = G2.G2Project(gpxfile=str(out))
        phase = project.phase(args.phase)
        if phase is None:
            raise RuntimeError(f"Phase {args.phase!r} not found")
        hist_names = list(phase.data["Histograms"])
        if len(hist_names) != 1:
            raise RuntimeError("Axis test requires one linked histogram for the selected phase")
        hist_name = hist_names[0]
        hap = phase.data["Histograms"][hist_name]
        if float(hap["Scale"][0]) <= 0 or not hap.get("Use", True):
            raise RuntimeError("Candidate is inactive or has nonpositive scale")
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        project.set_Controls("cycles", 12)
        project.save()
        try:
            project.refine()
            row = {"axis": list(axis), "status": "tested", "project": str(out), **metrics(project, args.phase, hist_name)}
            if row["scale"] <= 0 or not 0.3 < row["md_ratio"] < 3.0 or row["background_min"] < 0:
                row["status"] = "unknown"
                row["reason"] = "boundary/nonphysical trial"
        except Exception as exc:
            row = {"axis": list(axis), "status": "unknown", "project": str(out), "error": repr(exc)}
        rows.append(row)
        print(json.dumps(row, allow_nan=False), flush=True)
    (args.output_dir / "md_axes.json").write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
