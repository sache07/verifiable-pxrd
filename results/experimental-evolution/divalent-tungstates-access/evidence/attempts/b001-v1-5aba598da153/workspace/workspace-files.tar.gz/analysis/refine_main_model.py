#!/usr/bin/env python3
"""Continue the selected wolframite model with staged structural parameters."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def summarize(project, phase_name, hist_name):
    phase = project.phase(phase_name)
    hist = project.histogram(hist_name)
    hap = phase.data["Histograms"][hist_name]
    arrays = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    x, y, w, calc, bkg, diff = arrays
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    atoms = []
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    for i, atom in enumerate(phase.data["Atoms"]):
        atoms.append(
            {
                "index": i,
                "label": atom[ct - 1],
                "element": atom[ct],
                "xyz": [float(v) for v in atom[cx : cx + 3]],
                "occupancy": float(atom[cx + 3]),
                "flags": atom[ct + 1],
                "uiso": float(atom[cia + 1]),
            }
        )
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "rwp_percent": float(100 * np.sqrt(loss / denom)),
        "loss": loss,
        "scale": float(hap["Scale"][0]),
        "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
        "md_ratio": float(hap["Pref.Ori."][1]),
        "md_axis": list(hap["Pref.Ori."][3]),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "U", "W", "X", "SH/L", "Polariz.")},
        "sample": {k: float(sample[k][0]) for k in ("Shift", "SurfRoughA", "SurfRoughB")},
        "background_min": float(np.min(bkg)),
        "calc_min": float(np.min(calc)),
        "atoms": atoms,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def refine_stage(project, out, phase_name, hist_name, stage, records):
    rollback = out.with_name(out.stem + ".rollback.gpx")
    project.save()
    shutil.copy2(out, rollback)
    try:
        project.refine()
        row = {"stage": stage, "status": "tested", **summarize(project, phase_name, hist_name)}
        if (
            not math.isfinite(row["rwp_percent"])
            or row["scale"] <= 0
            or min(row["cell"][:3]) <= 1
            or row["background_min"] < 0
        ):
            raise RuntimeError("nonphysical refinement result")
        snap = out.with_name(out.stem + f".{stage}.gpx")
        project.save()
        shutil.copy2(out, snap)
        row["project"] = str(snap)
        records.append(row)
        print(json.dumps({k: row[k] for k in ("stage", "status", "rwp_percent", "scale", "cell", "md_ratio")}), flush=True)
    except Exception as exc:
        shutil.copy2(rollback, out)
        project.reload()
        row = {"stage": stage, "status": "unknown", "error": repr(exc)}
        records.append(row)
        print(json.dumps(row), flush=True)
        raise
    finally:
        rollback.unlink(missing_ok=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--phase", required=True)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = args.output.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.base.resolve(), out)
    project = G2.G2Project(gpxfile=str(out))
    phase = project.phase(args.phase)
    if phase is None or len(project.phases()) != 1:
        raise RuntimeError("The selected phase must be the only candidate in the project")
    hist_names = list(phase.data["Histograms"])
    if len(hist_names) != 1:
        raise RuntimeError("Expected one linked observed histogram")
    hist_name = hist_names[0]
    hap = phase.data["Histograms"][hist_name]
    if not hap.get("Use", True) or float(hap["Scale"][0]) <= 0:
        raise RuntimeError("Selected phase is inactive or has nonpositive scale")
    project.set_Controls("cycles", 15)
    records = [{"stage": "selected_texture_rollback", "status": "tested", **summarize(project, args.phase, hist_name)}]

    phase.set_refinements({"Atoms": {"O1": "X", "O2": "X"}})
    refine_stage(project, out, args.phase, hist_name, "oxygen_coordinates", records)

    phase.set_refinements({"Atoms": {"Zn1": "X", "W1": "X"}})
    refine_stage(project, out, args.phase, hist_name, "all_coordinates", records)

    hist = project.histogram(hist_name)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.index_ids()
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    refine_stage(project, out, args.phase, hist_name, "polarization", records)

    # The generator uses one isotropic U per phase. Enforce that physically
    # economical model rather than refining four independent displacement terms.
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    for atom in phase.data["Atoms"]:
        atom[cia + 1] = 0.008
        atom[ct + 1] = "XU"
    project.save()
    project.add_EquivConstr(tuple(f"0::AUiso:{i}" for i in range(len(phase.data["Atoms"]))))
    project.set_Controls("parmMin", 0.001, variable="0::AUiso:0")
    project.set_Controls("parmMax", 0.030, variable="0::AUiso:0")
    refine_stage(project, out, args.phase, hist_name, "common_uiso", records)

    out.with_suffix(".json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
