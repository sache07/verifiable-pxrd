#!/usr/bin/env python3
"""Screen identity-addressed secondary phases from one stable GSAS project."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def objective(project, hist_name):
    hist = project.histogram(hist_name)
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    return float(100 * np.sqrt(loss / denom)), loss, float(np.min(bkg))


def phase_record(phase, hist_name):
    hap = phase.data["Histograms"][hist_name]
    return {
        "name": phase.name,
        "phase_id": int(phase.data["pId"]),
        "scale": float(hap["Scale"][0]),
        "cell_mass": float(phase.data["General"]["Mass"]),
        "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
        "volume": float(phase.data["General"]["Cell"][7]),
        "space_group": phase.data["General"]["SGData"]["SpGrp"],
        "use": bool(hap.get("Use", True)),
    }


def fractions(project, hist_name):
    rows = [phase_record(p, hist_name) for p in project.phases()]
    masses = np.asarray([r["scale"] * r["cell_mass"] for r in rows])
    if np.any(masses < 0) or masses.sum() <= 0:
        return rows
    for row, value in zip(rows, masses / masses.sum()):
        row["weight_fraction"] = float(value)
    return rows


def run_one(base, cif, cod_id, output_dir, principal_name):
    out = (output_dir / f"trial_{cod_id}.gpx").resolve()
    shutil.copy2(base.resolve(), out)
    project = G2.G2Project(gpxfile=str(out))
    principal = project.phase(principal_name)
    if principal is None:
        raise RuntimeError("Base project does not contain the named principal phase")
    hist_names = list(principal.data["Histograms"])
    if len(hist_names) != 1:
        raise RuntimeError("Base principal must link to one histogram")
    hist_name = hist_names[0]
    hist = project.histogram(hist_name)
    trial_name = f"trial_WO3_{cod_id}"
    trial = project.add_phase(str(cif.resolve()), phasename=trial_name, histograms=[hist], fmthint="CIF")
    if project.phase(trial_name) is None or trial.name != trial_name:
        raise RuntimeError("Candidate import identity mismatch")
    hap = trial.data["Histograms"][hist_name]
    hap["Scale"] = [5.0, True]
    hap["Use"] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    hap["Mustrain"][1][1] = 1000.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    project.set_Controls("cycles", 12)
    project.index_ids()
    pid = int(trial.data["pId"])
    hid = int(hist.id)
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Scale")
    initial_cell = [float(v) for v in trial.data["General"]["Cell"][1:7]]
    if float(hap["Scale"][0]) <= 0 or not hap["Use"]:
        raise RuntimeError("Candidate did not receive a positive active initialized scale")
    project.save()

    rows = []
    project.refine()
    expected_scale = f"{pid}:{hid}:Scale"
    vary = project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
    if expected_scale not in vary:
        raise RuntimeError("Scale/background trial did not complete for the intended candidate")
    rwp, loss, bmin = objective(project, hist_name)
    trial = project.phase(trial_name)
    rows.append(
        {
            "stage": "scale_background_common_nuisance",
            "rwp_percent": rwp,
            "loss": loss,
            "background_min": bmin,
            "phases": fractions(project, hist_name),
        }
    )

    trial.set_refinements({"Cell": True})
    project.refine()
    vary = project.data.get("Covariance", {}).get("data", {}).get("varyList", [])
    if not any(str(v).startswith(f"{pid}::A") for v in vary):
        raise RuntimeError("Candidate-cell trial did not complete for the intended candidate")
    rwp, loss, bmin = objective(project, hist_name)
    trial = project.phase(trial_name)
    final = phase_record(trial, hist_name)
    length_change = [abs(a - b) / b for a, b in zip(final["cell"][:3], initial_cell[:3])]
    angle_change = [abs(a - b) for a, b in zip(final["cell"][3:], initial_cell[3:])]
    row = {
        "stage": "candidate_cell_common_nuisance",
        "rwp_percent": rwp,
        "loss": loss,
        "background_min": bmin,
        "initial_cell": initial_cell,
        "max_length_change_fraction": max(length_change),
        "max_angle_change_deg": max(angle_change),
        "phases": fractions(project, hist_name),
    }
    trial_row = next(r for r in row["phases"] if r["name"] == trial_name)
    if not math.isfinite(rwp) or bmin < 0 or min(final["cell"][:3]) <= 1:
        status, reason = "unknown", "invalid refinement result"
    elif trial_row.get("weight_fraction", 0.0) < 0.002:
        status, reason = "rejected", "scale collapsed below 0.2 wt%"
    elif max(length_change) > 0.03 or max(angle_change) > 3.0:
        status, reason = "unknown", "fit required a distorted cell"
    else:
        status, reason = "tested", "stable positive contribution"
    row.update(status=status, reason=reason, project=str(out))
    rows.append(row)
    project.save()
    return {
        "cod_id": cod_id,
        "cif": str(cif.resolve()),
        "trial_name": trial_name,
        "status": status,
        "reason": reason,
        "stages": rows,
    }


def cif_path(root, cod_id):
    flat = root / f"{cod_id}.cif"
    if flat.is_file():
        return flat
    return root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("output_dir", type=Path)
    ap.add_argument("--principal", required=True)
    ap.add_argument("--cif-root", type=Path, required=True)
    ap.add_argument("--ids", nargs="+", required=True)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for cod_id in args.ids:
        cif = cif_path(args.cif_root, cod_id)
        try:
            record = run_one(args.base, cif, cod_id, args.output_dir, args.principal)
        except Exception as exc:
            record = {
                "cod_id": cod_id,
                "cif": str(cif.resolve()),
                "status": "unknown",
                "reason": "trial failed or was not imported/refined",
                "error": repr(exc),
            }
        records.append(record)
        brief = {"cod_id": cod_id, "status": record["status"], "reason": record["reason"]}
        if record.get("stages"):
            brief["rwp_percent"] = record["stages"][-1]["rwp_percent"]
            phases = record["stages"][-1]["phases"]
            brief["trial_weight_fraction"] = next(r.get("weight_fraction") for r in phases if r["name"] == record["trial_name"])
        print(json.dumps(brief, allow_nan=False), flush=True)
    (args.output_dir / "screen.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
