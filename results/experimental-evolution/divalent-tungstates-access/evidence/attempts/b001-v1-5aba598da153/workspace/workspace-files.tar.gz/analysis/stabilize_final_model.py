#!/usr/bin/env python3
"""Converge the selected isotropic three-phase model with stable flags."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def state(project: G2.G2Project) -> dict:
    hist = project.histograms()[0]
    name = hist.name
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "size_micrometre": float(hap["Size"][1][0]),
                "size_refine": bool(hap["Size"][2][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
                "microstrain_refine": bool(hap["Mustrain"][2][0]),
            }
        )
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = float(mass / total)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    inst = hist.data["Instrument Parameters"][0]
    return {
        "rwp_percent": float(100.0 * math.sqrt(loss / denom)),
        "weighted_residual_sum": loss,
        "gof": float(rvals.get("GOF", float("nan"))),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", float("nan"))),
        "converged": bool(rvals.get("converged", False)),
        "background_min": float(np.min(bkg)),
        "calculated_min": float(np.min(calc)),
        "instrument": {
            k: {"value": float(inst[k][1]), "refine": bool(inst[k][2])}
            for k in ("Polariz.", "U", "W", "X", "SH/L")
        },
        "phases": phases,
        "vary_list": list(cov.get("varyList", [])),
        "message": str(rvals.get("msg", "")),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--zno", default="trial_WO3_9004178")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    output = args.output.resolve()
    shutil.copy2(args.source.resolve(), output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 50)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5

    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    # U and SH/L previously reached physically allowed limits and were then
    # held fixed. Polarization is fixed at its independently refined value to
    # remove its 0.97 correlation with the product Uiso.
    for key in ("Polariz.", "U", "SH/L"):
        inst[key][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {}

    zno = project.phase(args.zno)
    if zno is None:
        raise RuntimeError(f"ZnO phase not found: {args.zno}")
    hname = hist.name
    zno_hap = zno.data["Histograms"][hname]
    zno_hap["Mustrain"][1][0] = 1000.0
    zno_hap["Mustrain"][2] = [False for _ in zno_hap["Mustrain"][2]]

    project.save()
    records = [{"stage": "input_with_stable_flags", **state(project)}]
    previous = records[-1]["rwp_percent"]
    for iteration in range(1, 5):
        project.refine()
        project.save()
        row = {"stage": f"convergence_pass_{iteration}", **state(project)}
        if not math.isfinite(row["rwp_percent"]):
            raise RuntimeError("non-finite refinement objective")
        if row["background_min"] < 0 or row["calculated_min"] < 0:
            raise RuntimeError("negative background or calculated profile")
        if any(p["scale"] <= 0 for p in row["phases"]):
            raise RuntimeError("non-positive phase scale")
        records.append(row)
        print(
            json.dumps(
                {
                    "stage": row["stage"],
                    "rwp_percent": row["rwp_percent"],
                    "max_shift_over_sigma": row["max_shift_over_sigma"],
                    "fractions": {p["name"]: p["weight_fraction"] for p in row["phases"]},
                }
            ),
            flush=True,
        )
        improvement = previous - row["rwp_percent"]
        previous = row["rwp_percent"]
        if row["converged"] and abs(row["max_shift_over_sigma"]) < 0.25 and improvement < 1.0e-5:
            break

    output.with_suffix(".json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
