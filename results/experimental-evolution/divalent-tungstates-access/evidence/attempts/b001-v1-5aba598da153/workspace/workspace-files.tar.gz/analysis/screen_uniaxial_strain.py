#!/usr/bin/env python3
"""Screen one uniaxial microstrain term at a time from a common project."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def measure(project: G2.G2Project, target_name: str) -> dict:
    hist = project.histograms()[0]
    hname = hist.name
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), float)
    correlations = []
    if matrix.ndim == 2 and matrix.shape == (len(names), len(names)):
        diag = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        with np.errstate(divide="ignore", invalid="ignore"):
            corr = matrix / np.outer(diag, diag)
        for i in range(len(names)):
            for j in range(i):
                if np.isfinite(corr[i, j]) and abs(corr[i, j]) >= 0.9:
                    correlations.append(
                        {
                            "absolute": float(abs(corr[i, j])),
                            "signed": float(corr[i, j]),
                            "parameter_1": names[j],
                            "parameter_2": names[i],
                        }
                    )
        correlations.sort(key=lambda row: row["absolute"], reverse=True)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hname]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "weight_numerator": mass,
                "mustrain_type": str(hap["Mustrain"][0]),
                "equatorial_ppm": float(hap["Mustrain"][1][0]),
                "axial_ppm": float(hap["Mustrain"][1][1]),
                "mustrain_flags": [bool(v) for v in hap["Mustrain"][2]],
                "axis": [int(v) for v in hap["Mustrain"][3]],
            }
        )
    total = sum(masses)
    for row in phases:
        row["weight_fraction"] = float(row.pop("weight_numerator") / total)
    rvals = cov.get("Rvals", {})
    return {
        "target": target_name,
        "rwp_percent": float(100.0 * math.sqrt(loss / denom)),
        "gof": float(rvals.get("GOF", float("nan"))),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", float("nan"))),
        "converged": bool(rvals.get("converged", False)),
        "background_min": float(np.min(bkg)),
        "calculated_min": float(np.min(calc)),
        "phases": phases,
        "high_correlations": correlations,
        "message": str(rvals.get("msg", "")),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output_directory", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    base = args.base.resolve()
    outdir = args.output_directory.resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    records = []
    base_project = G2.G2Project(gpxfile=str(base))
    baseline = measure(base_project, "isotropic_baseline")
    baseline["status"] = "tested"
    records.append(baseline)
    print(json.dumps({"target": "baseline", "rwp_percent": baseline["rwp_percent"]}), flush=True)

    for phase_name in [phase.name for phase in base_project.phases()]:
        for axis in AXES:
            tag = phase_name.replace("/", "_").replace(" ", "_") + "_" + "".join(str(v) for v in axis)
            trial_path = outdir / f"{tag}.gpx"
            shutil.copy2(base, trial_path)
            project = G2.G2Project(gpxfile=str(trial_path))
            project.set_Controls("cycles", 50)
            project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
            phase = project.phase(phase_name)
            hist = project.histograms()[0]
            hname = hist.name
            hap = phase.data["Histograms"][hname]
            starting = float(hap["Mustrain"][1][0]) if hap["Mustrain"][2][0] else 1000.0
            hap["Mustrain"][1][0] = starting
            hap["Mustrain"][1][1] = starting
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "uniaxial", "direction": list(axis), "refine": True}},
                histograms=[hname],
            )
            project.index_ids()
            pid, hid = int(phase.data["pId"]), int(hist.id)
            for suffix in ("i", "a"):
                project.set_Controls("parmMin", 0.0, variable=f"{pid}:{hid}:Mustrain;{suffix}")
                project.set_Controls("parmMax", 8000.0, variable=f"{pid}:{hid}:Mustrain;{suffix}")
            project.save()
            project.refine()
            project.refine()
            project.save()
            row = measure(project, phase_name)
            row.update(axis=list(axis), project=str(trial_path))
            values = next(p for p in row["phases"] if p["name"] == phase_name)
            valid = (
                math.isfinite(row["rwp_percent"])
                and row["background_min"] >= 0
                and row["calculated_min"] >= 0
                and all(p["scale"] > 0 for p in row["phases"])
                and 0.0 < values["equatorial_ppm"] < 8000.0
                and 0.0 < values["axial_ppm"] < 8000.0
            )
            row["status"] = "tested" if valid else "unknown"
            if not valid:
                row["reason"] = "failed, nonphysical, or boundary-hitting refinement"
            records.append(row)
            print(
                json.dumps(
                    {
                        "target": phase_name,
                        "axis": axis,
                        "status": row["status"],
                        "rwp_percent": row["rwp_percent"],
                        "equatorial_ppm": values["equatorial_ppm"],
                        "axial_ppm": values["axial_ppm"],
                        "max_shift_over_sigma": row["max_shift_over_sigma"],
                    }
                ),
                flush=True,
            )
    (outdir / "screen.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
