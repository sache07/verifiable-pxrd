#!/usr/bin/env python3
"""Export the final GSAS-II model, CIFs, profile and machine-readable result."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_EXPORTS = {
    "ZnWO4_wolframite": ("ZnWO4 (wolframite)", "ZnWO4", "phase_znwo4_wolframite.cif"),
    "trial_WO3_2311041": ("WO3 (monoclinic)", "WO3", "phase_wo3_monoclinic.cif"),
    "trial_WO3_9004178": ("ZnO (wurtzite)", "ZnO", "phase_zno_wurtzite.cif"),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("workspace", type=Path)
    args = parser.parse_args()
    G2.SetPrintLevel("warn")

    workspace = args.workspace.resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    final_project = workspace / "final.gpx"
    shutil.copy2(args.source.resolve(), final_project)
    project = G2.G2Project(gpxfile=str(final_project))
    project.save()

    histograms = project.histograms()
    if len(histograms) != 1:
        raise RuntimeError("Final project must contain exactly one histogram")
    hist = histograms[0]
    hname = hist.name
    arrays = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    x, observed, weights, calculated, background, difference = arrays
    if len(x) != 8301 or not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise RuntimeError("Final profile is incomplete, non-finite, or negative")

    fit_path = workspace / "fit.csv"
    with fit_path.open("w", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(["two_theta", "observed", "calculated", "difference"])
        for values in zip(x, observed, calculated, observed - calculated):
            writer.writerow(
                [
                    f"{values[0]:.8f}",
                    f"{values[1]:.12g}",
                    f"{values[2]:.12g}",
                    f"{values[3]:.12g}",
                ]
            )

    phases = project.phases()
    if set(phase.name for phase in phases) != set(PHASE_EXPORTS):
        raise RuntimeError("Unexpected phase inventory in final project")
    mass_terms = []
    for phase in phases:
        hap = phase.data["Histograms"][hname]
        if not hap.get("Use", True) or hap.get("LeBail") or hap["Scale"][0] <= 0:
            raise RuntimeError(f"Inactive, Le Bail, or non-positive phase: {phase.name}")
        mass_terms.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    total_mass_term = sum(mass_terms)

    # Clear the covariance only in this unsaved export view so CIF coordinates
    # are taken directly from the full-precision atom records in final.gpx.
    export_project = G2.G2Project(gpxfile=str(final_project))
    export_project.data["Covariance"]["data"] = {}
    records = []
    for phase, mass_term in zip(phases, mass_terms):
        public_name, formula, filename = PHASE_EXPORTS[phase.name]
        export_phase = export_project.phase(phase.name)
        cif_path = workspace / filename
        export_phase.export_CIF(str(cif_path))
        general = phase.data["General"]
        cell = [float(v) for v in general["Cell"][1:7]]
        records.append(
            {
                "name": public_name,
                "formula": formula,
                "space_group": str(general["SGData"]["SpGrp"]),
                "cif_path": filename,
                "weight_fraction": float(mass_term / total_mass_term),
                "cell_A_degrees": {
                    key: value
                    for key, value in zip(("a", "b", "c", "alpha", "beta", "gamma"), cell)
                },
                "project_phase_name": phase.name,
            }
        )

    loss = float(np.sum(weights * (observed - calculated) ** 2))
    denominator = float(np.sum(weights * observed**2))
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    nvars = int(rvals.get("Nvars", len(covariance.get("varyList", []))))
    nobs = int(rvals.get("Nobs", len(observed)))
    result = {
        "phases": records,
        "refinement_histogram": hname,
        "fit_statistics": {
            "rwp_percent": float(100.0 * math.sqrt(loss / denominator)),
            "rp_percent": float(rvals.get("Rp", float("nan"))),
            "chi_square": loss,
            "reduced_chi_square": float(loss / max(1, nobs - nvars)),
            "goodness_of_fit": float(math.sqrt(loss / max(1, nobs - nvars))),
            "observations": nobs,
            "refined_parameters": nvars,
            "weighting": "1/max(observed_counts,1)",
        },
        "profile_file": "fit.csv",
        "gsas_project": "final.gpx",
        "fraction_basis": "GSAS-II phase scale times unit-cell mass, normalized over modeled crystalline phases",
        "files": {
            "final_gpx_sha256": sha256(final_project),
            "fit_csv_sha256": sha256(fit_path),
        },
    }
    # JSON has no portable NaN representation. Rp is optional if absent.
    if not math.isfinite(result["fit_statistics"]["rp_percent"]):
        result["fit_statistics"].pop("rp_percent")
    (workspace / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
