#!/usr/bin/env python3
"""Verify that WO3 uniaxial strain remains supported after coordinate simplification."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", default="trial_WO3_2311041")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    output = args.output.resolve()
    shutil.copy2(args.base.resolve(), output)
    project = G2.G2Project(gpxfile=str(output))
    project.set_Controls("cycles", 50)
    project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
    hist = project.histograms()[0]
    phase = project.phase(args.phase)
    hap = phase.data["Histograms"][hist.name]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 0.5 * (hap["Mustrain"][1][0] + hap["Mustrain"][1][1])
    hap["Mustrain"][2] = [True, False, False]
    project.save()
    project.refine()
    project.refine()
    project.save()
    x, y, w, calc, bkg = [np.asarray(v, float) for v in hist.data["data"][1][:5]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    row = {
        "rwp_percent": float(100.0 * math.sqrt(loss / denom)),
        "mustrain_type": hap["Mustrain"][0],
        "mustrain_ppm": float(hap["Mustrain"][1][0]),
        "background_min": float(np.min(bkg)),
        "calculated_min": float(np.min(calc)),
        "rvals": project.data["Covariance"]["data"].get("Rvals", {}),
    }
    output.with_suffix(".json").write_text(json.dumps(row, indent=2, allow_nan=False) + "\n")
    print(json.dumps(row, allow_nan=False))


if __name__ == "__main__":
    main()
