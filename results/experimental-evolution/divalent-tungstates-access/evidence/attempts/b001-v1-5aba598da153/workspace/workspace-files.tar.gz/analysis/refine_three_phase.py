#!/usr/bin/env python3
"""Staged structural refinement for the closed ZnWO4/WO3/ZnO inventory."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def atom_rows(phase):
    cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
    rows = []
    for i, atom in enumerate(phase.data["Atoms"]):
        rows.append(
            {
                "index": i,
                "label": str(atom[ct - 1]),
                "element": str(atom[ct]),
                "xyz": [float(v) for v in atom[cx : cx + 3]],
                "occupancy": float(atom[cx + 3]),
                "flags": str(atom[ct + 1]),
                "uiso": float(atom[cia + 1]),
            }
        )
    return rows


def summary(project, hist_name):
    hist = project.histogram(hist_name)
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    masses = []
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        rows.append(
            {
                "name": phase.name,
                "phase_id": int(phase.data["pId"]),
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
                "volume": float(phase.data["General"]["Cell"][7]),
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "size": hap["Size"],
                "mustrain": hap["Mustrain"],
                "preferred_orientation": hap["Pref.Ori."],
                "atoms": atom_rows(phase),
            }
        )
    total = sum(masses)
    for row, mass in zip(rows, masses):
        row["weight_fraction"] = float(mass / total)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    return {
        "rwp_percent": float(100 * np.sqrt(loss / denom)),
        "loss": loss,
        "background_min": float(np.min(bkg)),
        "calc_min": float(np.min(calc)),
        "instrument": {k: float(inst[k][1]) for k in ("Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz.")},
        "sample": {k: float(sample[k][0]) for k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB")},
        "phases": rows,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def refine_stage(project, out, hist_name, stage, records):
    rollback = out.with_name(out.stem + ".rollback.gpx")
    project.save()
    shutil.copy2(out, rollback)
    try:
        project.refine()
        row = {"stage": stage, "status": "tested", **summary(project, hist_name)}
        if (
            not math.isfinite(row["rwp_percent"])
            or row["background_min"] < 0
            or row["calc_min"] < 0
            or any(p["scale"] <= 0 or min(p["cell"][:3]) <= 1 for p in row["phases"])
        ):
            raise RuntimeError("nonphysical staged result")
        snap = out.with_name(out.stem + f".{stage}.gpx")
        project.save()
        shutil.copy2(out, snap)
        row["project"] = str(snap)
        records.append(row)
        print(
            json.dumps(
                {
                    "stage": stage,
                    "rwp_percent": row["rwp_percent"],
                    "fractions": {p["name"]: p["weight_fraction"] for p in row["phases"]},
                },
                allow_nan=False,
            ),
            flush=True,
        )
    except Exception as exc:
        shutil.copy2(rollback, out)
        project.reload()
        row = {"stage": stage, "status": "unknown", "error": repr(exc)}
        records.append(row)
        print(json.dumps(row), flush=True)
        raise
    finally:
        rollback.unlink(missing_ok=True)


def labels_by_element(phase, wanted):
    return [row["label"] for row in atom_rows(phase) if row["element"] in wanted]


def set_coordinate_flags(phase, labels):
    phase.set_refinements({"Atoms": {label: "X" for label in labels}})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--product", required=True)
    ap.add_argument("--wo3", required=True)
    ap.add_argument("--zno", required=True)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = args.output.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.base.resolve(), out)
    project = G2.G2Project(gpxfile=str(out))
    names = [args.product, args.wo3, args.zno]
    if any(project.phase(name) is None for name in names) or len(project.phases()) != 3:
        raise RuntimeError(f"Expected exactly the named three phases, found {[p.name for p in project.phases()]}")
    hist_sets = [set(project.phase(name).data["Histograms"]) for name in names]
    if len(set.union(*hist_sets)) != 1 or any(len(s) != 1 for s in hist_sets):
        raise RuntimeError("All phases must use the same single observed histogram")
    hist_name = next(iter(hist_sets[0]))
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        if not hap.get("Use", True) or float(hap["Scale"][0]) <= 0:
            raise RuntimeError(f"Inactive/nonpositive phase before refinement: {phase.name}")
    project.set_Controls("cycles", 20)
    records = [{"stage": "closed_inventory_rollback", "status": "tested", **summary(project, hist_name)}]

    product = project.phase(args.product)
    wo3 = project.phase(args.wo3)
    zno = project.phase(args.zno)

    set_coordinate_flags(product, labels_by_element(product, {"Zn", "W"}))
    refine_stage(project, out, hist_name, "product_heavy_coordinates", records)

    set_coordinate_flags(wo3, labels_by_element(wo3, {"W"}))
    refine_stage(project, out, hist_name, "wo3_tungsten_coordinates", records)

    set_coordinate_flags(zno, labels_by_element(zno, {"O"}))
    refine_stage(project, out, hist_name, "zno_internal_coordinate", records)

    set_coordinate_flags(product, labels_by_element(product, {"O"}))
    refine_stage(project, out, hist_name, "product_oxygen_coordinates", records)

    set_coordinate_flags(wo3, labels_by_element(wo3, {"O"}))
    refine_stage(project, out, hist_name, "wo3_oxygen_coordinates", records)

    hist = project.histogram(hist_name)
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.index_ids()
    hid = int(hist.id)
    project.set_Controls("parmMin", 0.5, variable=f":{hid}:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=f":{hid}:Polariz.")
    refine_stage(project, out, hist_name, "polarization", records)

    # One common isotropic displacement parameter per phase, matching the
    # specimen model and avoiding independent-atom ADP overfitting.
    for phase in (product, wo3, zno):
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        pid = int(phase.data["pId"])
        variables = []
        for i, atom in enumerate(phase.data["Atoms"]):
            atom[cia + 1] = 0.008
            flags = str(atom[ct + 1])
            atom[ct + 1] = "XU" if "X" in flags else "U"
            variables.append(f"{pid}::AUiso:{i}")
        if len(variables) > 1:
            project.save()
            project.add_EquivConstr(tuple(variables))
        project.set_Controls("parmMin", 0.001, variable=variables[0])
        project.set_Controls("parmMax", 0.030, variable=variables[0])
    refine_stage(project, out, hist_name, "phase_common_uiso", records)

    out.with_suffix(".json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
