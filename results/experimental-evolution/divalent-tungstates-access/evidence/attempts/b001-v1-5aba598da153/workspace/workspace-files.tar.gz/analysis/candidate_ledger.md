# Candidate ledger

All imported branches used the same observed histogram. Phase screens used common
background/profile nuisance settings and identity-addressed phases. A branch is
called rejected only after a stable trial; invalid cells, hard-contact source
models, and interrupted/divergent trials are labeled unknown.

## ZnWO4 product candidates

No exact ZnWO4 entry was present in the supplied case library. Target-composition
CIFs were therefore constructed from same-topology or one-site-substitution
oxide parents while retaining site multiplicities and topology.

| Candidate | Parent / construction | Status | Evidence |
|---|---|---|---|
| Wolframite, P2/c | Zn-for-Cu in mixed (Zn,Cu)WO4, COD 9005254 | tested (selected) | Stable cell/profile fit; one-phase Rwp 28.80%, then 22.29% with supported [100] March-Dollase texture. |
| Wolframite, P2/c | Zn-for-Cd in mixed (Zn,Cd)WO4, COD 1520642 | tested | Independent parent reached Rwp 28.71% and converged toward the same wolframite model. |
| Wolframite, P2/c | Zn-for-Fe in FeWO4, COD 1567215 | rejected | Stable positive scale but poorer common-setting Rwp 32.72%; U reached its lower limit. |
| Triclinic, P-1 | W-for-Mo in ZnMoO4, COD 1528282 | unknown | Scale collapsed and a later cell/profile trial generated an invalid metric; not counted as a rejection. |
| Scheelite, I41/a | Zn-for-Cd in CdWO4, COD 1549132 | unknown | Imported and passed the initial geometry screen, but cell refinement diverged to a nonphysical cell; rolled back. |

## WO3 candidates

All nine exact-WO3 structures in the supplied inventory were normalized and
screened from the same one-phase ZnWO4 project, first with scale/background and
then candidate cell terms.

| COD ID | Symmetry | Status | Common-setting evidence / physical screen |
|---|---|---|---|
| 1004057 | P6/mmm | unknown | Only ~0.34 wt% and required a 3.7% cell change; classified unknown because the cell trial was distorted. |
| 1010618 | P21/m | unknown | Source has a 0.464 A hard contact; useful only as a diagnostic pattern and not a valid atomic model. |
| 1521532 | P4/ncc | rejected | ~0.35 wt%; no objective improvement after cell refinement. |
| 1521533 | P4/nmm | rejected | Rwp 18.93%; required ~2.25% cell change and left the principal WO3 residual family. |
| 1528915 | P21/c | rejected | Screening Rwp 8.89%; fine refinement produced a 0.960 A O-O contact. |
| 1563541 | P21/c | rejected | Rwp 19.38% with an implausibly large cell adjustment. |
| 2106293 | P-1 | rejected | Screening Rwp 8.15%, but fine refinement produced 1.124 A O-O and 1.223 A W-O contacts. |
| 2107312 | Pnma | rejected | Rwp 16.38%; coherent WO3 residuals remained. |
| 2311041 | P21/c | tested (selected) | Screening Rwp 8.21%, stable ~18.5 wt% contribution, and sound final geometry. |

## ZnO candidates

| Candidate | COD ID | Status | Evidence |
|---|---|---|---|
| Wurtzite, P63mc | 9004178 | tested (selected) | Stable positive contribution; lowered Rwp 8.21% to 6.57%. |
| Rocksalt, Fm-3m | 1534836 | rejected | Refined contribution collapsed below 0.2 wt%. |
| Zincblende, F-43m | 1537875 | rejected | Refined contribution collapsed below 0.2 wt%. |

## Final nuisance and closure trials

| Trial | Status | Evidence |
|---|---|---|
| ZnWO4 texture axes [001], [100], [010], [110], [111] | tested; [100] selected | [100] was uniquely best (Rwp 22.29% versus 25.91-28.65%). |
| Isotropic relative size/strain | tested (selected) | Stable finite sizes for WO3 and ZnO; product size held as reference to avoid a boundary solution. |
| One uniaxial strain term, axes [001], [100], [010] for every phase | tested; WO3 [001] selected | Initial screen lowered Rwp 3.736% to 3.664%; in the coordinate-simplified final model, isotropic rollback gave 3.749% versus 3.686% uniaxial. Both components are finite. |
| WO3 W-coordinate simplification | tested (selected) | Fixing one W site at the published position and refining the other removed every >=0.90 covariance correlation; Rwp changed from 3.664% to 3.686% and fractions by <0.1 wt%. |
| Surface roughness A/B | rejected and rolled back | A collapsed to zero, A/B were 99.97% correlated, and scale was strongly correlated with B. |
| Additional Zn-W-O stoichiometries | unknown (not activated) | No coherent positive residual peak family remained after ZnWO4 + WO3 + ZnO closure, so no further atomic phase was asserted. |

The final residual extrema alternate around modeled Bragg peaks; they do not form
a separate consistently positive peak family. Final replay and CIF geometry
checks are recorded in `.tmp/replay/replay.json` and the submission report.
