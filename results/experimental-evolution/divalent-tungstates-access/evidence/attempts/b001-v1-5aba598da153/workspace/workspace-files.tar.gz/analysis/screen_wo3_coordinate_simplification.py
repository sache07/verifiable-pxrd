#!/usr/bin/env python3
"""Compare simpler WO3 W-coordinate parameterizations from one project."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


SOURCE = {
    "W0": (0.028, 0.537, 0.782),
    "W1": (0.466, 0.023, 0.216),
}


def summary(project: G2.G2Project, phase_name: str) -> dict:
    hist = project.histograms()[0]
    data = hist.data["data"][1]
    y, w, calc, bkg = [np.asarray(data[i], float) for i in (1, 2, 3, 4)]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    cov = project.data.get("Covariance", {}).get("data", {})
    names = list(cov.get("varyList", []))
    matrix = np.asarray(cov.get("covMatrix", []), float)
    correlations = []
    if matrix.ndim == 2 and matrix.shape == (len(names), len(names)):
        d = np.sqrt(np.maximum(np.diag(matrix), 0.0))
        with np.errstate(divide="ignore", invalid="ignore"):
            corr = matrix / np.outer(d, d)
        for i in range(len(names)):
            for j in range(i):
                if np.isfinite(corr[i, j]) and abs(corr[i, j]) >= 0.9:
                    correlations.append([float(corr[i, j]), names[j], names[i]])
        correlations.sort(key=lambda row: abs(row[0]), reverse=True)
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(hap["Scale"][0]) * float(phase.data["General"]["Mass"]))
    total = sum(masses)
    phase = project.phase(phase_name)
    atoms = {
        label: {
            "coordinates": list(phase.atom(label).coordinates),
            "flags": phase.atom(label).refinement_flags,
        }
        for label in SOURCE
    }
    rvals = cov.get("Rvals", {})
    return {
        "rwp_percent": float(100.0 * math.sqrt(loss / denom)),
        "gof": float(rvals.get("GOF", float("nan"))),
        "max_shift_over_sigma": float(rvals.get("Max shft/sig", float("nan"))),
        "background_min": float(np.min(bkg)),
        "calculated_min": float(np.min(calc)),
        "fractions": [float(value / total) for value in masses],
        "atoms": atoms,
        "high_correlations": correlations,
        "vary_list": names,
        "message": str(rvals.get("msg", "")),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument("--phase", default="trial_WO3_2311041")
    args = parser.parse_args()
    G2.SetPrintLevel("warn")
    base, outdir = args.base.resolve(), args.output_directory.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    variants = {
        "published_all_fixed": (True, True, None),
        "published_W0_fixed_W1_refined": (True, True, "W1"),
        "published_W1_fixed_W0_refined": (True, True, "W0"),
        "refined_positions_all_fixed": (False, False, None),
    }
    rows = []
    for name, (restore_w0, restore_w1, refined_label) in variants.items():
        output = outdir / f"{name}.gpx"
        shutil.copy2(base, output)
        project = G2.G2Project(gpxfile=str(output))
        project.set_Controls("cycles", 50)
        project.data["Controls"]["data"]["min dM/M"] = 1.0e-5
        phase = project.phase(args.phase)
        for label, restore in (("W0", restore_w0), ("W1", restore_w1)):
            atom = phase.atom(label)
            if restore:
                atom.coordinates = SOURCE[label]
            atom.refinement_flags = "XU" if label == refined_label else "U"
        project.save()
        project.refine()
        project.refine()
        project.save()
        row = {"variant": name, "project": str(output), **summary(project, args.phase)}
        row["status"] = (
            "tested"
            if row["background_min"] >= 0
            and row["calculated_min"] >= 0
            and math.isfinite(row["rwp_percent"])
            else "unknown"
        )
        rows.append(row)
        print(
            json.dumps(
                {
                    "variant": name,
                    "status": row["status"],
                    "rwp_percent": row["rwp_percent"],
                    "max_shift_over_sigma": row["max_shift_over_sigma"],
                    "fractions": row["fractions"],
                    "atoms": row["atoms"],
                    "high_correlations": row["high_correlations"][:4],
                }
            ),
            flush=True,
        )
    (outdir / "screen.json").write_text(json.dumps(rows, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
