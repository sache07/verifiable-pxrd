#!/usr/bin/env python3
"""List coherent positive and negative residual extrema from a GSAS-II project."""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks, peak_widths
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--sigma-bins", type=float, default=2.0)
    parser.add_argument("--prominence-sigma", type=float, default=2.0)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(args.project.resolve()))
    data = project.histograms()[0].data["data"][1]
    x, y, calc = np.asarray(data[0], float), np.asarray(data[1], float), np.asarray(data[3], float)
    residual = y - calc
    smooth = gaussian_filter1d(residual, args.sigma_bins)
    noise = float(1.4826 * np.median(np.abs(smooth - np.median(smooth))))
    prominence = args.prominence_sigma * noise

    rows = []
    for sign, values in (("positive", smooth), ("negative", -smooth)):
        indices, properties = find_peaks(values, prominence=prominence, distance=4)
        widths = peak_widths(values, indices, rel_height=0.5)[0]
        for index, prom, width in zip(indices, properties["prominences"], widths):
            rows.append(
                {
                    "sign": sign,
                    "two_theta_deg": float(x[index]),
                    "smoothed_residual_counts": float(smooth[index]),
                    "raw_residual_counts": float(residual[index]),
                    "prominence_counts": float(prom),
                    "width_deg": float(width * np.median(np.diff(x))),
                    "residual_over_counting_sigma": float(smooth[index] / np.sqrt(max(y[index], 1.0))),
                }
            )
    rows.sort(key=lambda row: row["prominence_counts"], reverse=True)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]) if rows else ["sign", "two_theta_deg"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"smoothed_noise_counts={noise:.4f} threshold={prominence:.4f} extrema={len(rows)}")
    for row in rows[:40]:
        print(
            f"{row['sign']:8s} {row['two_theta_deg']:9.4f} "
            f"d={row['smoothed_residual_counts']:9.2f} "
            f"prom={row['prominence_counts']:9.2f} "
            f"w={row['width_deg']:.4f} sigma={row['residual_over_counting_sigma']:.2f}"
        )


if __name__ == "__main__":
    main()
