#!/usr/bin/env python3
"""Refine only isotropic phase-profile terms from a physical rollback."""

from __future__ import annotations

import argparse
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def summary(project, hist_name):
    hist = project.histogram(hist_name)
    x, y, w, calc, bkg, diff = [np.asarray(v, float) for v in hist.data["data"][1][:6]]
    loss = float(np.sum(w * (y - calc) ** 2))
    denom = float(np.sum(w * y**2))
    masses, phases = [], []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist_name]
        mass = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass)
        phases.append(
            {
                "name": phase.name,
                "phase_id": int(phase.data["pId"]),
                "scale": float(hap["Scale"][0]),
                "cell_mass": float(phase.data["General"]["Mass"]),
                "size_type": hap["Size"][0],
                "size_values": [float(v) for v in hap["Size"][1]],
                "size_flags": list(hap["Size"][2]),
                "mustrain_type": hap["Mustrain"][0],
                "mustrain_values": [float(v) for v in hap["Mustrain"][1]],
                "mustrain_flags": list(hap["Mustrain"][2]),
            }
        )
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = float(mass / total)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "rwp_percent": float(100 * np.sqrt(loss / denom)),
        "loss": loss,
        "background_min": float(np.min(bkg)),
        "calc_min": float(np.min(calc)),
        "instrument": {k: float(inst[k][1]) for k in ("U", "W", "X", "SH/L")},
        "phases": phases,
        "vary_list": list(project.data.get("Covariance", {}).get("data", {}).get("varyList", [])),
    }


def stage(project, out, hist_name, name, records):
    rollback = out.with_name(out.stem + ".rollback.gpx")
    project.save()
    shutil.copy2(out, rollback)
    try:
        project.refine()
        row = {"stage": name, "status": "tested", **summary(project, hist_name)}
        if (
            not math.isfinite(row["rwp_percent"])
            or row["background_min"] < 0
            or row["calc_min"] < 0
            or any(p["scale"] <= 0 for p in row["phases"])
        ):
            raise RuntimeError("nonphysical profile stage")
        snap = out.with_name(out.stem + f".{name}.gpx")
        project.save()
        shutil.copy2(out, snap)
        row["project"] = str(snap)
        records.append(row)
        print(json.dumps({"stage": name, "rwp_percent": row["rwp_percent"], "profiles": {p["name"]: [p["size_values"][0], p["mustrain_values"][0]] for p in row["phases"]}}), flush=True)
    except Exception as exc:
        shutil.copy2(rollback, out)
        project.reload()
        records.append({"stage": name, "status": "unknown", "error": repr(exc)})
        raise
    finally:
        rollback.unlink(missing_ok=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--phases", nargs="+", required=True)
    args = ap.parse_args()
    G2.SetPrintLevel("warn")
    out = args.output.resolve()
    shutil.copy2(args.base.resolve(), out)
    project = G2.G2Project(gpxfile=str(out))
    phases = [project.phase(name) for name in args.phases]
    if any(p is None for p in phases) or len(phases) != len(project.phases()):
        raise RuntimeError("--phases must name every project phase")
    hist_name = next(iter(phases[0].data["Histograms"]))
    hist = project.histogram(hist_name)
    hid = int(hist.id)
    project.set_Controls("cycles", 20)
    # Isolate phase-specific broadening. X and U are exactly or nearly
    # confounded with common size/strain modes in a single scan; retain their
    # settled effective values while fitting only inter-phase differences.
    hist.clear_refinements({"Instrument Parameters": ["X", "U", "SH/L"]})
    records = [{"stage": "physical_structure_rollback", "status": "tested", **summary(project, hist_name)}]

    for phase in phases:
        pid = int(phase.data["pId"])
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": True}}, histograms=[hist_name])
        project.index_ids()
        var = f"{pid}:{hid}:Size;i"
        project.set_Controls("parmMin", 0.04, variable=var)
        project.set_Controls("parmMax", 1.5, variable=var)
        stage(project, out, hist_name, f"size_phase_{pid}", records)

    for phase in phases:
        pid = int(phase.data["pId"])
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}}, histograms=[hist_name])
        project.index_ids()
        var = f"{pid}:{hid}:Mustrain;i"
        project.set_Controls("parmMin", 0.0, variable=var)
        project.set_Controls("parmMax", 8000.0, variable=var)
        stage(project, out, hist_name, f"mustrain_phase_{pid}", records)

    out.with_suffix(".json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
