#!/usr/bin/env python3
"""Normalize database candidates to neutral elements and common Uiso for GSAS-II."""

from __future__ import annotations

import argparse
import json
import warnings
from pathlib import Path

import numpy as np
from pymatgen.core import Structure
from pymatgen.io.cif import CifWriter, CifFile


def normalize(source: Path, destination: Path):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        structure = Structure.from_file(source, primitive=False)
    structure.remove_oxidation_states()
    for i, site in enumerate(structure):
        site.label = f"{site.species_string}{i}"
    writer = CifWriter(structure, symprec=0.001, significant_figures=10)
    tag = "_atom_site_U_iso_or_equiv"
    for block in writer.cif_file.data.values():
        block.data[tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
        loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
        if tag not in loop:
            loop.append(tag)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(str(writer) + "\n")
    distances = structure.distance_matrix
    minimum = float(np.min(distances[distances > 1e-8]))
    return {
        "source": str(source.resolve()),
        "destination": str(destination.resolve()),
        "composition": structure.composition.formula,
        "space_group": structure.get_space_group_info(symprec=0.01),
        "sites": len(structure),
        "minimum_contact_A": minimum,
        "hard_contact_failure": minimum < 0.8,
        "transformation": "neutralized oxidation-state labels; regenerated symmetry at 0.001 A; set all Uiso to 0.005 A^2",
    }


def source_path(root: Path, cod_id: str):
    return root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("source_root", type=Path)
    ap.add_argument("destination", type=Path)
    ap.add_argument("ids", nargs="+")
    args = ap.parse_args()
    records = []
    for cod_id in args.ids:
        source = source_path(args.source_root, cod_id)
        record = normalize(source, args.destination / f"{cod_id}.cif")
        record["cod_id"] = cod_id
        records.append(record)
        print(json.dumps(record, allow_nan=False))
    (args.destination / "provenance.json").write_text(json.dumps(records, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
