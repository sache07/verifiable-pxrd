#!/usr/bin/env python3
"""Remove one explicitly named phase from a copied GSAS-II project.

The input project is never modified.  References in powder reflection lists are
removed with the phase, and the output is reloaded to verify persistence.
"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--phase", required=True)
    args = parser.parse_args()

    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    if source == output:
        raise ValueError("Output must differ from input")
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)

    project = G2.G2Project(gpxfile=str(output))
    phase_names = {phase.name for phase in project.phases()}
    if args.phase not in phase_names:
        raise ValueError(f"Unknown phase identity: {args.phase}")
    del project.data["Phases"][args.phase]
    for tree_item in project.names:
        if tree_item and tree_item[0] == "Phases":
            tree_item.remove(args.phase)
            break
    for histogram in project.histograms():
        histogram.data.get("Reflection Lists", {}).pop(args.phase, None)
    project.save(str(output))

    check = G2.G2Project(gpxfile=str(output))
    remaining = [phase.name for phase in check.phases()]
    if args.phase in remaining:
        raise RuntimeError(f"Phase removal did not persist: {args.phase}")
    print(f"Removed {args.phase}; remaining phases: {remaining}")


if __name__ == "__main__":
    main()
