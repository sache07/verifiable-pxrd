#!/usr/bin/env python3
"""Trial one explicitly named phase addition from a frozen GSAS-II base."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_trial import phase_report, stats


def clear_nuisance_flags(project: G2.G2Project, histogram_name: str) -> None:
    hist = project.histogram(histogram_name)
    hist.data["Background"][0][1] = True
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram_name]
        hap["Use"] = True
        hap["Scale"][1] = True
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--cif", required=True)
    parser.add_argument("--scale", type=float, default=1.0)
    parser.add_argument("--cell", choices=["none", "candidate", "all"], default="none")
    args = parser.parse_args()

    if not np.isfinite(args.scale) or args.scale <= 0:
        raise ValueError("Candidate scale must be finite and positive")
    source = Path(args.base).resolve()
    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if source == output:
        raise ValueError("Screening output must differ from the frozen base")
    # GSAS-II auto-saves when a phase is added, so clone before loading.
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    if len(project.histograms()) != 1:
        raise ValueError("Screening base must contain exactly one histogram")
    hist = project.histograms()[0]
    if any(phase.name == args.name for phase in project.phases()):
        raise ValueError(f"Candidate identity already present: {args.name}")
    candidate = project.add_phase(
        str(Path(args.cif).resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    hap = candidate.data["Histograms"][hist.name]
    hap["Scale"] = [float(args.scale), True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 1000.0
    clear_nuisance_flags(project, hist.name)
    if args.cell == "candidate":
        candidate.data["General"]["Cell"][0] = True
    elif args.cell == "all":
        for phase in project.phases():
            phase.data["General"]["Cell"][0] = True
    # Verify candidate identity, activity and positive initialized scale just
    # before the fit (a positional phase index is never used).
    selected = project.phase(args.name)
    selected_hap = selected.data["Histograms"][hist.name]
    if not selected_hap["Use"] or selected_hap["Scale"][0] <= 0:
        raise RuntimeError("Candidate is inactive or lacks a positive scale")

    project.set_Controls("cycles", 1 if args.cell == "none" else 6)
    project.refine()
    project.save(str(output))
    report = {
        "base": str(source),
        "project": str(output),
        "histogram": hist.name,
        "candidate": args.name,
        "cell_mode": args.cell,
        "stats": stats(project, hist.name),
        "phases": phase_report(project, hist.name),
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    candidate_row = next(row for row in report["phases"] if row["name"] == args.name)
    print(json.dumps({"stats": report["stats"], "candidate": candidate_row}, indent=2))


if __name__ == "__main__":
    main()
