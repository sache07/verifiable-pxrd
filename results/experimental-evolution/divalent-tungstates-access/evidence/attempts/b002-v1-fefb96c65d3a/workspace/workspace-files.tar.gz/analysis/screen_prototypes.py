#!/usr/bin/env python3
"""Rank substituted Mn-W-O prototypes against a positive GSAS residual.

The screen changes only element identity and an isotropic cell scale. Site
multiplicities, fractional coordinates and topology are inherited from each
parent. It is a shortlist generator, not a Rietveld refinement.
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
from collections import Counter
from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure
from scipy.ndimage import gaussian_filter1d


LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cif_path(root: Path, cod_id: str) -> Path:
    return root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def minimum_contacts(structure: Structure) -> dict[str, float | None]:
    best = {"all": math.inf, "O-O": math.inf, "Mn-O": math.inf, "W-O": math.inf}
    for i, site in enumerate(structure):
        for neigh in structure.get_neighbors(site, 4.0):
            j = int(neigh.index)
            if j == i and float(neigh.nn_distance) < 1e-8:
                continue
            dist = float(neigh.nn_distance)
            best["all"] = min(best["all"], dist)
            pair = {site.specie.symbol, neigh.specie.symbol}
            if pair == {"O"}:
                best["O-O"] = min(best["O-O"], dist)
            elif pair == {"Mn", "O"}:
                best["Mn-O"] = min(best["Mn-O"], dist)
            elif pair == {"W", "O"}:
                best["W-O"] = min(best["W-O"], dist)
    return {k: (None if not np.isfinite(v) else float(v)) for k, v in best.items()}


def profile_from_sticks(
    x: np.ndarray,
    d_spacings: np.ndarray,
    intensities: np.ndarray,
    cell_scale: float,
    fwhm_deg: float,
) -> np.ndarray:
    impulse = np.zeros_like(x)
    step = float(np.median(np.diff(x)))
    for wavelength, ratio in ((LAMBDA1, 1.0), (LAMBDA2, 0.5)):
        arg = wavelength / (2.0 * cell_scale * d_spacings)
        valid = arg < 1.0
        positions = np.degrees(2.0 * np.arcsin(arg[valid]))
        values = ratio * intensities[valid]
        bins = np.rint((positions - x[0]) / step).astype(int)
        good = (bins >= 0) & (bins < len(x))
        np.add.at(impulse, bins[good], values[good])
    sigma_bins = fwhm_deg / (2.354820045 * step)
    return gaussian_filter1d(impulse, sigma_bins, mode="constant")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--residual", default=".tmp/three_phase_arrays.npz")
    parser.add_argument(
        "--index",
        default="<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/index.json.gz",
    )
    parser.add_argument(
        "--cif-root",
        default="<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif",
    )
    parser.add_argument("--output", default=".tmp/prototype_screen.json")
    args = parser.parse_args()

    arrays = np.load(args.residual)
    x = np.asarray(arrays["x"], float)
    observed = np.asarray(arrays["observed"], float)
    residual = np.asarray(arrays["difference"], float)
    weight = 1.0 / np.maximum(observed, 1.0)
    base_sse = float(np.sum(weight * residual**2))
    with gzip.open(args.index, "rt") as stream:
        index = json.load(stream)
    root = Path(args.cif_root)

    # (A/W, O/W): target family. Ratios are parent-composition filters.
    families = {
        (1.0, 4.0): "MnWO4",
        (2.0, 6.0): "Mn2WO6",
        (3.0, 6.0): "Mn3WO6",
        (2.0 / 3.0, 4.0): "Mn2W3O12",
        (1.5, 4.5): "Mn3W2O9",
        (1.0, 4.5): "Mn2W2O9",
        (2.0, 4.0): "Mn2WO4",
        (1.0, 3.0): "MnWO3",
    }
    calc = XRDCalculator(wavelength=LAMBDA1, symprec=1e-3)
    results = []
    errors = []
    for key, records in index.items():
        elements = key.split("-")
        if len(elements) != 3 or "W" not in elements or "O" not in elements:
            continue
        parent_element = next(e for e in elements if e not in {"W", "O"})
        for formula, cod_id, listed_sg, r_factor in records:
            try:
                comp = Composition(formula)
                ratios = (float(comp[parent_element] / comp["W"]), float(comp["O"] / comp["W"]))
            except Exception:
                continue
            match = next(
                (pair for pair in families if abs(ratios[0] - pair[0]) < 2e-4 and abs(ratios[1] - pair[1]) < 2e-4),
                None,
            )
            if match is None:
                continue
            path = cif_path(root, cod_id)
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    parent = Structure.from_file(path)
                target = parent.copy()
                # CIFs may carry oxidation-decorated Species (Na+, V3+, ...),
                # which are not matched by a bare element substitution.
                try:
                    target.remove_oxidation_states()
                except Exception:
                    pass
                if parent_element != "Mn":
                    target.replace_species({Element(parent_element): Element("Mn")})
                raw_occ = [float(sum(site.species.values())) for site in target]
                occupancy_ok = bool(raw_occ and min(raw_occ) >= 0 and max(raw_occ) <= 1.0001)
                contacts = minimum_contacts(target)
                pattern = calc.get_pattern(target, two_theta_range=(8.0, 110.0))
                theta = np.radians(np.asarray(pattern.x, float) / 2.0)
                d = LAMBDA1 / (2.0 * np.sin(theta))
                intensities = np.asarray(pattern.y, float)
                best = None
                for cell_scale in np.linspace(0.76, 1.24, 61):
                    for fwhm in (0.16, 0.28, 0.50, 0.80):
                        profile = profile_from_sticks(x, d, intensities, float(cell_scale), fwhm)
                        denom = float(np.sum(weight * profile**2))
                        if denom <= 0:
                            continue
                        amplitude = max(0.0, float(np.sum(weight * profile * residual)) / denom)
                        sse = float(np.sum(weight * (residual - amplitude * profile) ** 2))
                        row = (sse, float(cell_scale), fwhm, amplitude)
                        if best is None or row < best:
                            best = row
                if best is None:
                    raise ValueError("No profile evaluated")
                sg_symbol, sg_number = target.get_space_group_info(symprec=1e-3)
                results.append(
                    {
                        "target_family": families[match],
                        "parent_element": parent_element,
                        "parent_formula": formula,
                        "cod_id": cod_id,
                        "cif": str(path),
                        "listed_space_group_number": listed_sg,
                        "detected_space_group": [sg_symbol, int(sg_number)],
                        "n_sites": len(target),
                        "target_composition": target.composition.formula,
                        "occupancy_ok": occupancy_ok,
                        "contacts_A": contacts,
                        "physical_ok": bool(
                            occupancy_ok and contacts["all"] is not None and contacts["all"] >= 0.8
                        ),
                        "best_cell_scale": best[1],
                        "best_fwhm_deg": best[2],
                        "best_amplitude": best[3],
                        "weighted_sse_improvement": base_sse - best[0],
                        "fraction_of_base_sse_removed": (base_sse - best[0]) / base_sse,
                    }
                )
            except Exception as exc:
                errors.append({"cod_id": cod_id, "formula": formula, "error": f"{type(exc).__name__}: {exc}"})

    results.sort(
        key=lambda row: (row["physical_ok"], row["weighted_sse_improvement"]),
        reverse=True,
    )
    payload = {
        "residual": args.residual,
        "base_weighted_sse": base_sse,
        "family_counts": dict(Counter(row["target_family"] for row in results)),
        "results": results,
        "errors": errors,
    }
    Path(args.output).write_text(json.dumps(payload, indent=2) + "\n")
    print("rank family parent id sg scale fwhm gain_fraction min_contact")
    for rank, row in enumerate(results[:80], 1):
        print(
            f"{rank:3d} {row['target_family']:10s} {row['parent_element']:>2s} {row['cod_id']} "
            f"{row['detected_space_group'][0]:10s} {row['best_cell_scale']:.3f} "
            f"{row['best_fwhm_deg']:.2f} {row['fraction_of_base_sse_removed']:.5f} "
            f"{row['contacts_A']['all']!s}"
        )


if __name__ == "__main__":
    main()
