#!/usr/bin/env python3
"""Search simple oxide prototypes against a frozen positive PXRD residual.

Binary AOx parents are mapped independently to Mn-O and W-O compositions.
Ternary A-B-O parents are mapped in both A/B -> Mn/W assignments. Fractional
occupancies, site multiplicities and fractional coordinates are retained.
The screen uses a fast stick-profile projection followed by full weighted
profile regression for the best candidates. It is a nomination tool only;
shortlisted structures must still be imported, refined and geometry-screened.
"""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import gzip
import json
import math
import os
from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure
from scipy.ndimage import gaussian_filter1d


LAMBDA1 = 1.540598
LAMBDA2 = 1.544426


def cif_path(root: str | Path, cod_id: str) -> Path:
    root = Path(root)
    return root / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def plausible_target(mn: float, tungsten: float, oxygen: float) -> tuple[bool, float | None]:
    """Loose redox filter for Mn(II-IV), W(IV-VI), and mixed Mn-W oxides."""
    if min(mn, tungsten, oxygen) < 0 or oxygen <= 0 or mn + tungsten <= 0:
        return False, None
    if mn > 0 and tungsten > 0:
        mn_valence_at_w6 = (2.0 * oxygen - 6.0 * tungsten) / mn
        ok = (
            1.5 <= mn_valence_at_w6 <= 4.1
            and oxygen / tungsten <= 8.0
            and oxygen / (mn + tungsten) <= 4.5
        )
        return ok, float(mn_valence_at_w6)
    if mn > 0:
        valence = 2.0 * oxygen / mn
        return 1.5 <= valence <= 4.1, float(valence)
    valence = 2.0 * oxygen / tungsten
    return 3.5 <= valence <= 6.5, float(valence)


def enumerate_tasks(index: dict, r_limit: float) -> list[dict]:
    grouped: dict[tuple, dict] = {}
    for key, records in index.items():
        elements = key.split("-")
        if "O" not in elements or len(elements) not in (2, 3):
            continue
        cations = [element for element in elements if element != "O"]
        for formula, cod_id, listed_sg, r_factor in records:
            if r_factor is not None and float(r_factor) > r_limit:
                continue
            try:
                comp = Composition(formula)
                oxygen = float(comp["O"])
                counts = [float(comp[element]) for element in cations]
            except Exception:
                continue
            if not counts or min(counts) <= 0:
                continue
            if len(cations) == 1:
                assignments = [
                    ({cations[0]: "Mn"}, counts[0], 0.0),
                    ({cations[0]: "W"}, 0.0, counts[0]),
                ]
            else:
                assignments = [
                    ({cations[0]: "Mn", cations[1]: "W"}, counts[0], counts[1]),
                    ({cations[0]: "W", cations[1]: "Mn"}, counts[1], counts[0]),
                ]
            for mapping, mn, tungsten in assignments:
                ok, valence = plausible_target(mn, tungsten, oxygen)
                if not ok:
                    continue
                total_cations = mn + tungsten
                target_signature = (
                    round(mn / total_cations, 5),
                    round(tungsten / total_cations, 5),
                    round(oxygen / total_cations, 5),
                )
                group = (key, target_signature, int(listed_sg))
                rank = float(r_factor) if r_factor is not None else 9.0
                task = {
                    "key": key,
                    "parent_formula": formula,
                    "cod_id": str(cod_id),
                    "listed_space_group_number": int(listed_sg),
                    "r_factor": None if r_factor is None else float(r_factor),
                    "mapping": mapping,
                    "target_signature": list(target_signature),
                    "mn_valence_at_w6": valence,
                }
                if group not in grouped or rank < grouped[group][0]:
                    grouped[group] = (rank, task)
    return [value[1] for value in grouped.values()]


def minimum_contacts(structure: Structure) -> dict[str, float | None]:
    best = {"all": math.inf, "O-O": math.inf, "Mn-O": math.inf, "W-O": math.inf}
    for index, site in enumerate(structure):
        symbols = {species.symbol for species in site.species}
        for neighbor in structure.get_neighbors(site, 4.2):
            if int(neighbor.index) == index and float(neighbor.nn_distance) < 1e-8:
                continue
            distance = float(neighbor.nn_distance)
            neighbor_symbols = {species.symbol for species in neighbor.species}
            pair = symbols | neighbor_symbols
            best["all"] = min(best["all"], distance)
            if pair == {"O"}:
                best["O-O"] = min(best["O-O"], distance)
            elif pair == {"Mn", "O"}:
                best["Mn-O"] = min(best["Mn-O"], distance)
            elif pair == {"W", "O"}:
                best["W-O"] = min(best["W-O"], distance)
    return {key: (None if not np.isfinite(value) else float(value)) for key, value in best.items()}


def build_pattern(payload: tuple[dict, str]) -> dict:
    task, root = payload
    path = cif_path(root, task["cod_id"])
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = Structure.from_file(path)
        try:
            structure.remove_oxidation_states()
        except Exception:
            pass
        source_elements = {element.symbol for element in structure.composition.elements}
        expected_elements = set(task["key"].split("-"))
        if not source_elements.issubset(expected_elements):
            raise ValueError(f"CIF elements {sorted(source_elements)} differ from index key")
        substitutions = {
            Element(source): Element(target)
            for source, target in task["mapping"].items()
            if source != target
        }
        if substitutions:
            structure.replace_species(substitutions)
        remaining = {element.symbol for element in structure.composition.elements}
        if not remaining.issubset({"Mn", "W", "O"}):
            raise ValueError(f"Unmapped elements remain: {sorted(remaining)}")
        occupancies = [float(sum(site.species.values())) for site in structure]
        occupancy_ok = bool(occupancies and min(occupancies) > 0 and max(occupancies) <= 1.0001)
        contacts = minimum_contacts(structure)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            pattern = XRDCalculator(wavelength=LAMBDA1, symprec=1e-3).get_pattern(
                structure, two_theta_range=(7.0, 112.0)
            )
            sg_symbol, sg_number = structure.get_space_group_info(symprec=1e-3)
        positions = np.asarray(pattern.x, dtype=float)
        intensities = np.asarray(pattern.y, dtype=float)
        theta = np.radians(positions / 2.0)
        d_spacings = LAMBDA1 / (2.0 * np.sin(theta))
        row = dict(task)
        row.update(
            {
                "cif": str(path),
                "mapping": task["mapping"],
                "target_composition": structure.composition.formula,
                "n_sites": len(structure),
                "occupancy_ok": occupancy_ok,
                "contacts_A_unscaled": contacts,
                "detected_space_group": [sg_symbol, int(sg_number)],
                "d_spacings": d_spacings.tolist(),
                "intensities": intensities.tolist(),
            }
        )
        return row
    except Exception as exc:
        return {"cod_id": task["cod_id"], "error": f"{type(exc).__name__}: {exc}"}


def fast_scale_score(
    x: np.ndarray,
    smoothed_wr: np.ndarray,
    smoothed_w: np.ndarray,
    d: np.ndarray,
    intensities: np.ndarray,
    scales: np.ndarray,
) -> tuple[float, float]:
    best = (-math.inf, 1.0)
    for scale in scales:
        numerator = 0.0
        denominator = 0.0
        for wavelength, ratio in ((LAMBDA1, 1.0), (LAMBDA2, 0.5)):
            arg = wavelength / (2.0 * scale * d)
            valid = (arg > 0) & (arg < 1)
            if not np.any(valid):
                continue
            positions = np.degrees(2.0 * np.arcsin(arg[valid]))
            values = ratio * intensities[valid]
            in_range = (positions >= x[0]) & (positions <= x[-1])
            positions = positions[in_range]
            values = values[in_range]
            numerator += float(np.sum(values * np.interp(positions, x, smoothed_wr)))
            denominator += float(np.sum(values**2 * np.interp(positions, x, smoothed_w)))
        score = numerator / math.sqrt(max(denominator, 1e-30))
        if score > best[0]:
            best = (float(score), float(scale))
    return best


def profile_from_sticks(
    x: np.ndarray,
    d: np.ndarray,
    intensities: np.ndarray,
    scale: float,
    fwhm: float,
) -> np.ndarray:
    impulse = np.zeros_like(x)
    step = float(np.median(np.diff(x)))
    for wavelength, ratio in ((LAMBDA1, 1.0), (LAMBDA2, 0.5)):
        arg = wavelength / (2.0 * scale * d)
        valid = (arg > 0) & (arg < 1)
        positions = np.degrees(2.0 * np.arcsin(arg[valid]))
        values = ratio * intensities[valid]
        bins = np.rint((positions - x[0]) / step).astype(int)
        good = (bins >= 0) & (bins < len(x))
        np.add.at(impulse, bins[good], values[good])
    sigma_bins = fwhm / (2.354820045 * step)
    return gaussian_filter1d(impulse, sigma_bins, mode="constant")


def geometry_at_scale(row: dict, scale: float) -> dict[str, float | None]:
    return {
        key: (None if value is None else float(value) * scale)
        for key, value in row["contacts_A_unscaled"].items()
    }


def geometry_ok(row: dict, scale: float) -> bool:
    contacts = geometry_at_scale(row, scale)
    return bool(
        row["occupancy_ok"]
        and contacts["all"] is not None
        and contacts["all"] >= 1.15
        and (contacts["O-O"] is None or contacts["O-O"] >= 1.8)
        and (contacts["Mn-O"] is None or contacts["Mn-O"] >= 1.65)
        and (contacts["W-O"] is None or contacts["W-O"] >= 1.45)
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--residual", required=True)
    parser.add_argument(
        "--index",
        default="<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/index.json.gz",
    )
    parser.add_argument(
        "--cif-root",
        default="<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b002-c02/cif",
    )
    parser.add_argument("--output", required=True)
    parser.add_argument("--r-limit", type=float, default=0.20)
    parser.add_argument("--workers", type=int, default=max(1, min(8, os.cpu_count() or 1)))
    parser.add_argument("--full-shortlist", type=int, default=300)
    args = parser.parse_args()

    arrays = np.load(args.residual)
    x = np.asarray(arrays["x"], float)
    observed = np.asarray(arrays["observed"], float)
    residual = np.asarray(arrays["difference"], float)
    weight = 1.0 / np.maximum(observed, 1.0)
    base_sse = float(np.sum(weight * residual**2))
    step = float(np.median(np.diff(x)))
    sigma = 0.30 / (2.354820045 * step)
    smoothed_wr = gaussian_filter1d(weight * residual, sigma, mode="constant")
    smoothed_w = gaussian_filter1d(weight, sigma, mode="constant")

    with gzip.open(args.index, "rt") as stream:
        index = json.load(stream)
    tasks = enumerate_tasks(index, args.r_limit)
    print(f"metadata candidates: {len(tasks)}", flush=True)

    patterns = []
    errors = []
    payloads = ((task, args.cif_root) for task in tasks)
    with ProcessPoolExecutor(max_workers=args.workers) as executor:
        for count, row in enumerate(executor.map(build_pattern, payloads, chunksize=8), 1):
            if "error" in row:
                errors.append(row)
            else:
                patterns.append(row)
            if count % 100 == 0 or count == len(tasks):
                print(f"patterns {count}/{len(tasks)} usable={len(patterns)} errors={len(errors)}", flush=True)

    scales = np.linspace(0.78, 1.22, 89)
    fast_rows = []
    for row in patterns:
        d = np.asarray(row.pop("d_spacings"), float)
        intensities = np.asarray(row.pop("intensities"), float)
        score, scale = fast_scale_score(x, smoothed_wr, smoothed_w, d, intensities, scales)
        row["fast_projection_score"] = score
        row["fast_cell_scale"] = scale
        row["_d"] = d
        row["_intensities"] = intensities
        fast_rows.append(row)
    fast_rows.sort(key=lambda row: row["fast_projection_score"], reverse=True)

    refined = []
    for count, row in enumerate(fast_rows[: args.full_shortlist], 1):
        d = row["_d"]
        intensities = row["_intensities"]
        center = row["fast_cell_scale"]
        local_scales = np.unique(
            np.clip(np.r_[center, np.arange(center - 0.035, center + 0.0351, 0.0025)], 0.76, 1.24)
        )
        best = None
        for scale in local_scales:
            for fwhm in (0.16, 0.28, 0.50, 0.80):
                profile = profile_from_sticks(x, d, intensities, float(scale), float(fwhm))
                denominator = float(np.sum(weight * profile**2))
                if denominator <= 0:
                    continue
                amplitude = max(0.0, float(np.sum(weight * profile * residual)) / denominator)
                sse = float(np.sum(weight * (residual - amplitude * profile) ** 2))
                trial = (sse, float(scale), float(fwhm), float(amplitude))
                if best is None or trial < best:
                    best = trial
        if best is None:
            continue
        clean = {key: value for key, value in row.items() if not key.startswith("_")}
        clean.update(
            {
                "best_cell_scale": best[1],
                "best_fwhm_deg": best[2],
                "best_amplitude": best[3],
                "weighted_sse_improvement": base_sse - best[0],
                "fraction_of_base_sse_removed": (base_sse - best[0]) / base_sse,
                "contacts_A_at_best_scale": geometry_at_scale(row, best[1]),
                "screen_geometry_ok": geometry_ok(row, best[1]),
            }
        )
        refined.append(clean)
        if count % 50 == 0:
            print(f"full profiles {count}/{min(args.full_shortlist, len(fast_rows))}", flush=True)

    refined.sort(
        key=lambda row: (row["screen_geometry_ok"], row["weighted_sse_improvement"]),
        reverse=True,
    )
    payload = {
        "residual": str(Path(args.residual).resolve()),
        "base_weighted_sse": base_sse,
        "metadata_candidate_count": len(tasks),
        "usable_pattern_count": len(patterns),
        "full_profile_count": len(refined),
        "method_note": "Isotropic scale/stick nomination only; all candidates require GSAS-II import and physical validation.",
        "results": refined,
        "errors": errors,
    }
    Path(args.output).write_text(json.dumps(payload, indent=2) + "\n")
    print("rank target parent id map sg scale fwhm gain physical min_contact", flush=True)
    for rank, row in enumerate(refined[:100], 1):
        print(
            f"{rank:3d} {row['target_composition'][:18]:18s} {row['parent_formula'][:18]:18s} "
            f"{row['cod_id']} {json.dumps(row['mapping'], sort_keys=True):20s} "
            f"{row['detected_space_group'][0]:10s} {row['best_cell_scale']:.4f} "
            f"{row['best_fwhm_deg']:.2f} {row['fraction_of_base_sse_removed']:.6f} "
            f"{str(row['screen_geometry_ok']):5s} {row['contacts_A_at_best_scale']['all']!s}",
            flush=True,
        )


if __name__ == "__main__":
    main()
