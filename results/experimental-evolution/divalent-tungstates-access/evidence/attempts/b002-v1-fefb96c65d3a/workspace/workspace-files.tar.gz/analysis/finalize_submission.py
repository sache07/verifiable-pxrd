#!/usr/bin/env python3
"""Freeze a GSAS-II refinement and export the required submission artifacts."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


PHASE_METADATA = {
    "MnWO4_wolframite": ("MnWO4", "wolframite MnWO4"),
    "WO3_monoclinic": ("WO3", "monoclinic WO3"),
    "Mn2WO5_Cu9011171": ("Mn2WO5", "monoclinic Mn2WO5 analogue"),
    "Mn2WO5_Pnnm_Co1524664": ("Mn2WO5", "orthorhombic Mn2WO5 analogue"),
    "MnWO4_rutile_1528738": ("MnWO4", "rutile-like disordered MnWO4"),
    "Mn2O3_P3m1_1539160": ("Mn2O3", "trigonal Mn2O3 analogue"),
    "MnO2_Pna21_Sb9012783": ("MnO2", "orthorhombic MnO2 analogue"),
    "MnWO4_P42mnm_VSb1535996": ("MnWO4", "minor rutile-family MnWO4 analogue"),
    "Mn2O3_Fd3m_1011218": ("Mn2O3", "cubic Mn2O3 analogue"),
}


def clear_refinement_flags(project: G2.G2Project, histogram_name: str) -> None:
    histogram = project.histogram(histogram_name)
    histogram.data["Background"][0][1] = False
    for value in histogram.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in histogram.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram_name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False


def recomputed_statistics(histogram) -> dict:
    x, observed, weight, calculated, background, _ = [
        np.asarray(values, dtype=float) for values in histogram.data["data"][1]
    ]
    lower, upper = map(float, histogram.data["Limits"][1])
    use = (
        (x >= lower)
        & (x <= upper)
        & np.isfinite(observed)
        & np.isfinite(calculated)
        & np.isfinite(weight)
        & (weight > 0)
    )
    residual = observed[use] - calculated[use]
    chi_square = float(np.sum(weight[use] * residual**2))
    rwp = 100.0 * np.sqrt(
        chi_square / float(np.sum(weight[use] * observed[use] ** 2))
    )
    rp = 100.0 * float(np.sum(np.abs(residual))) / float(np.sum(observed[use]))
    return {
        "rwp_percent_recomputed": float(rwp),
        "rp_percent_recomputed": float(rp),
        "weighted_chi_square_recomputed": chi_square,
        "n_profile_points": int(np.count_nonzero(use)),
        "fit_limits_two_theta_deg": [lower, upper],
        "minimum_background_counts_in_fit": float(np.min(background[use])),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", required=True)
    parser.add_argument("--workspace", default=".")
    args = parser.parse_args()

    root = Path(args.workspace).resolve()
    source = Path(args.source).resolve()
    final_project = root / "final.gpx"
    if source == final_project:
        raise ValueError("Source refinement must differ from final.gpx")
    shutil.copy2(source, final_project)

    project = G2.G2Project(gpxfile=str(final_project))
    if len(project.histograms()) != 1:
        raise ValueError("Expected exactly one powder histogram")
    histogram = project.histograms()[0]
    clear_refinement_flags(project, histogram.name)
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        if not hap["Use"] or not np.isfinite(hap["Scale"][0]) or hap["Scale"][0] <= 0:
            raise ValueError(f"Inactive or nonpositive submitted phase: {phase.name}")
    project.save(str(final_project))

    # Reload the frozen project. Export without covariance substitutions, which
    # matches the scorer's full-precision saved-atom export convention.
    export_project = G2.G2Project(gpxfile=str(final_project))
    export_histogram = export_project.histograms()[0]
    covariance = dict(export_project.data.get("Covariance", {}).get("data", {}))
    export_project.data["Covariance"]["data"] = {}

    phase_dir = root / "phases"
    phase_dir.mkdir(parents=True, exist_ok=True)
    phase_rows = []
    masses = []
    phases = list(export_project.phases())
    unknown = [phase.name for phase in phases if phase.name not in PHASE_METADATA]
    if unknown:
        raise ValueError(f"Missing final phase metadata: {unknown}")
    for index, phase in enumerate(phases, 1):
        formula, label = PHASE_METADATA[phase.name]
        filename = f"phase_{index:02d}_{phase.name}.cif"
        relative = Path("phases") / filename
        phase.export_CIF(str(root / relative))
        hap = phase.data["Histograms"][export_histogram.name]
        mass_term = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(mass_term)
        sg = phase.data["General"]["SGData"]["SpGrp"].strip()
        phase_rows.append(
            {
                "name": label,
                "project_phase_name": phase.name,
                "formula": formula,
                "space_group": sg,
                "cif_path": relative.as_posix(),
                "weight_fraction": None,
            }
        )
    total_mass = float(sum(masses))
    if total_mass <= 0:
        raise ValueError("No positive crystalline phase mass")
    dep_sig = covariance.get("depSigDict", {})
    for phase, row, mass_term in zip(phases, phase_rows, masses):
        row["weight_fraction"] = float(mass_term / total_mass)
        key = f"{phase.data['pId']}:{export_histogram.data['data'][0]['hId']}:WgtFrac"
        if key in dep_sig and len(dep_sig[key]) >= 2:
            row["weight_fraction_formal_esd"] = float(dep_sig[key][1])

    statistics = recomputed_statistics(export_histogram)
    r_values = covariance.get("Rvals", {})
    if r_values:
        statistics.update(
            {
                "rwp_percent_gsas": float(r_values.get("Rwp")),
                "goodness_of_fit_gsas": float(r_values.get("GOF")),
                "weighted_chi_square_gsas": float(r_values.get("chisq")),
                "n_observations_gsas": int(r_values.get("Nobs")),
                "n_variables_last_scale_background_cycle": int(r_values.get("Nvars")),
            }
        )

    x, observed, _, calculated, _, _ = [
        np.asarray(values, dtype=float) for values in export_histogram.data["data"][1]
    ]
    profile = np.column_stack([x, observed, calculated, observed - calculated])
    np.savetxt(
        root / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )

    result = {
        "schema_version": 1,
        "refinement_histogram": export_histogram.name,
        "project_path": "final.gpx",
        "profile_path": "fit.csv",
        "weight_fraction_basis": "normalized over the modeled crystalline phases",
        "phases": phase_rows,
        "fit_statistics": statistics,
    }
    (root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
