# Candidate ledger

All branches were run from a saved rollback project, with candidate identity specified by name. Fixed-cell scale/background screening preceded candidate-cell refinement. No branch remains pending or unknown; the two initially unreadable exact MnO2 CIFs were converted to conventional/P1 serializations and then tested.

The exact-formula inventory in the supplied structure index contained 1 MnWO4, 9 WO3, 3 MnO, 13 MnO2, 3 Mn2O3, 3 Mn3O4, and no Mn2WO5 entries. Every entry in those exact-formula sets was inspected and scale-screened; chemically plausible analogue families were then added from the full oxide-parent search.

| Composition/family | Candidates or parent structures | Final status | Falsifying/selection evidence |
|---|---|---|---|
| MnWO4, wolframite | Exact COD 1520200 | Tested—accepted | Dominant positive scale and unique peak coverage; stable cell and physical contacts. |
| WO3 | All 9 exact entries: COD 1004057, 1010618, 1521532, 1521533, 1528915, 1563541, 2311041, 2106293, 2107312 | Tested—COD 2311041 accepted; others rejected | Monoclinic P21/c entry gave the best common scale/cell fit. Other polymorphs left coherent residuals or lost scale. |
| MnO | Exact COD 1514108, 1514231, 4117966 | Tested—rejected from final inventory | Hexagonal COD 4117966 was initially positive, but fell to about 0.5 wt% after P-3m1 Mn2O3 was added; removing it changed Rwp by only 0.016 percentage points. Cubic entries were weaker. |
| MnO2 | All 13 exact entries in the index | Tested—rejected as final models | Exact polymorph screens were inferior to the Pna21 analogue. The final two bookkeeping trials gave only about 0.18–0.29 wt%; COD 9011409 required a >20% volume change on cell refinement and was rejected as distorted. |
| Mn2O3 | Exact COD 1010586, 1514103, 1514230 | Tested—rejected | Exact bixbyite/orthorhombic scales collapsed or were inferior under the common nuisance model. |
| Mn3O4 | Exact COD 1541183, 9001302, 9001963 | Tested—rejected | Scales collapsed in closure trials. |
| Mn2WO5, monoclinic | Cu2AsO5 COD 9011171 -> Mn/W | Tested—accepted | Best chemically economical P21/c branch; stable positive scale and acceptable Mn-O/W-O/O-O contacts. |
| Mn2WO5, orthorhombic | Pnnm parents COD 1524664, 2101671, 9015147, 9000178, 9015082, 9016468 | Tested—COD 1524664 accepted; alternatives rejected | Common refinements gave Rwp 10.7647% (Co parent), 10.7694% (Al), 10.8063% (Zn), and 10.8639% (Mn); Cu-derived alternatives had poorer fits/short W-O contacts. |
| Other Mn-W oxide topologies | R-3 Mn3WO6, R-3c Mn4WO6, Ccce MnWO5, P212121/Pna21/P321/P-31m Mn2WO6 and related parents | Tested—rejected | All were compared with common nuisance settings; none matched the two accepted Mn2WO5 contributions without poorer profile agreement or uneconomic chemistry. |
| Rutile-like MnWO4, larger cell | CrReO4 COD 1528738 and independent rutile parents | Tested—accepted | P42/mnm lowered Rwp from about 10.13% to 9.65% in its nomination stage; independent parents converged to the same cell. Isotropic strain was stable; uniaxial trials required 46,000–62,000 ppm and were rejected. |
| Mn2O3, trigonal | Pu2O3 COD 1539160 -> Mn | Tested—accepted | Fixed-cell and cell-refined contributions remained positive; final isotropic strain is 5663 ppm. Removing overlapping hexagonal MnO did not worsen the fit materially. |
| MnO2, orthorhombic | SbO2 COD 9012783 -> Mn | Tested—accepted | Symmetry-diverse closure shortlist winner: about 4.5 wt% at nomination and Rwp 8.21% -> 7.80%. Neutral profile values retained; size/strain and coordinate embellishments were unsupported or unphysical. |
| Minor rutile-family Mn-W oxide | VSbO4 COD 1535996 -> Mn/W | Tested—provisionally accepted | Stable positive contribution and Rwp 7.80% -> 7.67%; competing WO2, I41md MnWO4 and R3m Mn3WO7 branches collapsed below 0.06 wt% once included. Final 0.28 wt% abundance and cation assignment are not reliable. |
| Mn2O3, cubic | Sb2O3 COD 1011218 -> Mn | Tested—accepted | Stable ~1 wt% scale after the other closure phases, physical contacts, and Rwp 7.67% -> 7.55%. Size refinement diverged and strain exceeded the 8000 ppm laboratory range, so neutral profile values were retained. |
| Fluorite MnO2 / cubic MnO controls | PuO2 COD 9009036 -> Mn and exact cubic MnO | Tested—rejected | Positive in early residual projection but clearly inferior to P-3m1/Pna21/Fd-3m oxide branches in full GSAS-II refinement. |

Coordinate/profile branches that diverged, hit a boundary, became strongly correlated, or produced short contacts were rolled back. In particular, several WO3 oxygen-coordinate trials generated W-O distances of 1.36–1.47 A; Pna21 oxygen trials generated Mn-O down to 1.62 A or an O-O contact near 1.95 A. These variants were not used.
