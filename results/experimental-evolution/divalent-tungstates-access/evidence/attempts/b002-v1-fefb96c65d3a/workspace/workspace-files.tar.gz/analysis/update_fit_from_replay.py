#!/usr/bin/env python3
"""Replace fit.csv with the frozen project's full-grid native replay."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prediction", required=True)
    parser.add_argument("--workspace", default=".")
    args = parser.parse_args()

    root = Path(args.workspace).resolve()
    replay = np.load(args.prediction)
    x = np.asarray(replay["x"], float)
    observed = np.asarray(replay["observed"], float)
    calculated = np.asarray(replay["predicted"], float)
    public = np.loadtxt(root / "inputs/pattern.csv", delimiter=",", skiprows=1)
    if public.shape != (len(x), 2):
        raise ValueError("Replay does not cover the complete measured grid")
    if not np.allclose(public[:, 0], x, rtol=0, atol=1e-7):
        raise ValueError("Replay grid differs from the public scan")
    if not np.allclose(public[:, 1], observed, rtol=0, atol=1e-5):
        raise ValueError("Replay observations differ from the public scan")
    if not np.all(np.isfinite(calculated)) or np.any(calculated < 0):
        raise ValueError("Replay contains invalid calculated intensities")

    profile = np.column_stack([x, observed, calculated, observed - calculated])
    np.savetxt(
        root / "fit.csv",
        profile,
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt="%.10g",
    )
    weight = 1.0 / np.maximum(observed, 1.0)
    residual = observed - calculated
    rwp = 100.0 * np.sqrt(
        np.sum(weight * residual**2) / np.sum(weight * observed**2)
    )
    rp = 100.0 * np.sum(np.abs(residual)) / np.sum(observed)
    result_path = root / "result.json"
    result = json.loads(result_path.read_text())
    result["fit_statistics"].update(
        {
            "rwp_percent_full_grid_native_replay": float(rwp),
            "rp_percent_full_grid_native_replay": float(rp),
            "full_grid_points": int(len(x)),
            "fit_csv_calculated_profile": "native no-refinement replay of final.gpx over the complete measured grid",
        }
    )
    result_path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result["fit_statistics"], indent=2))


if __name__ == "__main__":
    main()
