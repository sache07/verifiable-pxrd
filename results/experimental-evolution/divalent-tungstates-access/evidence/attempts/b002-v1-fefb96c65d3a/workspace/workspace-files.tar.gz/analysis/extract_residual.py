#!/usr/bin/env python3
"""Export the fitted powder arrays and a reproducible residual-peak list."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from scipy.signal import find_peaks, peak_widths


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--peak-output")
    parser.add_argument("--prominence", type=float, default=120.0)
    parser.add_argument("--distance-deg", type=float, default=0.10)
    args = parser.parse_args()

    project = G2.G2Project(gpxfile=str(Path(args.project).resolve()))
    if len(project.histograms()) != 1:
        raise ValueError("Expected exactly one powder histogram")
    hist = project.histograms()[0]
    x, observed, weight, calculated, background, stored_difference = [
        np.asarray(values, dtype=float) for values in hist.data["data"][1]
    ]
    difference = observed - calculated
    lo, hi = map(float, hist.data["Limits"][1])
    use = (x >= lo) & (x <= hi) & np.isfinite(observed) & np.isfinite(calculated)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        output,
        x=x[use],
        observed=observed[use],
        weight=weight[use],
        calculated=calculated[use],
        background=background[use],
        difference=difference[use],
        stored_difference=stored_difference[use],
    )

    xu = x[use]
    du = difference[use]
    step = float(np.median(np.diff(xu)))
    peak_indices, properties = find_peaks(
        du,
        prominence=float(args.prominence),
        distance=max(1, int(round(args.distance_deg / step))),
    )
    widths = peak_widths(du, peak_indices, rel_height=0.5)[0] * step
    peaks = []
    for rank, index in enumerate(peak_indices, 1):
        theta = np.radians(float(xu[index]) / 2.0)
        peaks.append(
            {
                "two_theta_deg": float(xu[index]),
                "d_A_CuKa1": float(1.540598 / (2.0 * np.sin(theta))),
                "positive_residual_counts": float(du[index]),
                "prominence_counts": float(properties["prominences"][rank - 1]),
                "fwhm_deg_approx": float(widths[rank - 1]),
            }
        )
    peaks.sort(key=lambda row: row["positive_residual_counts"], reverse=True)
    payload = {
        "project": str(Path(args.project).resolve()),
        "histogram": hist.name,
        "fit_limits_deg": [lo, hi],
        "prominence_threshold_counts": float(args.prominence),
        "peaks": peaks,
    }
    peak_output = Path(args.peak_output) if args.peak_output else output.with_suffix(".peaks.json")
    peak_output.write_text(json.dumps(payload, indent=2) + "\n")
    print(json.dumps({"arrays": str(output), "peak_output": str(peak_output), "top_peaks": peaks[:30]}, indent=2))


if __name__ == "__main__":
    main()
