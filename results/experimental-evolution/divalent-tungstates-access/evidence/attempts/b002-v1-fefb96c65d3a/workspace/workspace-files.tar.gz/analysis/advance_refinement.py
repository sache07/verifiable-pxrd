#!/usr/bin/env python3
"""Advance one GSAS-II project through one explicitly scoped refinement stage."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from refine_trial import phase_report, stats


def names(value: str | None) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in value.split(",") if item.strip()]


def select_phases(project: G2.G2Project, value: str | None) -> list:
    requested = names(value)
    if not requested:
        return []
    if requested == ["all"]:
        return list(project.phases())
    available = {phase.name: phase for phase in project.phases()}
    missing = sorted(set(requested) - set(available))
    if missing:
        raise ValueError(f"Unknown phase identities: {missing}")
    return [available[name] for name in requested]


def clear_flags(project: G2.G2Project, histogram_name: str) -> None:
    hist = project.histogram(histogram_name)
    hist.data["Background"][0][1] = False
    for value in hist.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) >= 2 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][histogram_name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False
        hap["Extinction"][1] = False


def normalize_uiso(project: G2.G2Project, value: float) -> None:
    for phase in project.phases():
        for atom in phase.atoms():
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = float(value)
            atom.data[atom.cia + 2 : atom.cia + 8] = [0.0] * 6


def correlations(project: G2.G2Project) -> list[dict]:
    data = project.data.get("Covariance", {}).get("data", {})
    covariance = np.asarray(data.get("covMatrix", []), float)
    sig = np.asarray(data.get("sig", []), float)
    variables = [str(v) for v in data.get("varyList", [])]
    if covariance.ndim != 2 or len(sig) != len(variables) or not len(sig):
        return []
    denom = np.outer(sig, sig)
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = np.where(denom > 0, covariance / denom, 0.0)
    rows = []
    for i in range(len(variables)):
        for j in range(i + 1, len(variables)):
            value = float(corr[i, j])
            if abs(value) >= 0.75:
                rows.append({"a": variables[i], "b": variables[j], "correlation": value})
    return sorted(rows, key=lambda row: abs(row["correlation"]), reverse=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--cycles", type=int, default=6)
    parser.add_argument("--background", action="store_true")
    parser.add_argument("--scales", action="store_true")
    parser.add_argument("--instrument", help="comma-separated parameter names")
    parser.add_argument("--sample", help="comma-separated sample parameter names")
    parser.add_argument("--cells", help="all or comma-separated phase identities")
    parser.add_argument("--size", help="all or comma-separated phase identities")
    parser.add_argument("--mustrain", help="all or comma-separated phase identities")
    parser.add_argument("--coordinates", help="all or comma-separated phase identities")
    parser.add_argument(
        "--coordinate-elements",
        action="append",
        default=[],
        metavar="PHASE:ELEMENT[,ELEMENT...]",
        help="refine coordinates only for the listed element types in one phase",
    )
    parser.add_argument(
        "--coordinate-labels",
        action="append",
        default=[],
        metavar="PHASE:LABEL[,LABEL...]",
        help="refine coordinates only for explicitly named independent sites",
    )
    parser.add_argument("--uiso", help="all or comma-separated phase identities")
    parser.add_argument("--normalize-uiso", type=float)
    parser.add_argument(
        "--set-instrument",
        action="append",
        default=[],
        metavar="NAME=VALUE",
    )
    parser.add_argument(
        "--set-profile",
        action="append",
        default=[],
        metavar="PHASE:SIZE_UM,MUSTRAIN_PPM",
    )
    parser.add_argument(
        "--set-sample",
        action="append",
        default=[],
        metavar="NAME=VALUE",
    )
    parser.add_argument("--tie-phase-uiso", action="store_true")
    parser.add_argument(
        "--uniaxial-mustrain",
        action="append",
        default=[],
        metavar="PHASE:H,K,L",
    )
    parser.add_argument(
        "--orientation",
        action="append",
        default=[],
        metavar="PHASE:H,K,L",
    )
    parser.add_argument(
        "--set-orientation",
        action="append",
        default=[],
        metavar="PHASE:H,K,L,RATIO",
        help="set (without refining) one March-Dollase direction and ratio",
    )
    args = parser.parse_args()

    source = Path(args.input).resolve()
    output = Path(args.output).resolve()
    if source == output:
        raise ValueError("Output must differ from input so rollback remains available")
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, output)
    project = G2.G2Project(gpxfile=str(output))
    if len(project.histograms()) != 1:
        raise ValueError("Expected exactly one refinement histogram")
    hist = project.histograms()[0]
    clear_flags(project, hist.name)

    if args.normalize_uiso is not None:
        normalize_uiso(project, args.normalize_uiso)
    for assignment in args.set_instrument:
        parameter, value_text = assignment.split("=", 1)
        instrument = hist.data["Instrument Parameters"][0]
        if parameter not in instrument:
            raise ValueError(f"Unknown instrument parameter: {parameter}")
        instrument[parameter][1] = float(value_text)
    for assignment in args.set_profile:
        phase_name, values_text = assignment.split(":", 1)
        size_text, strain_text = values_text.split(",", 1)
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = float(size_text)
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = float(strain_text)
        hap["Mustrain"][1][1] = float(strain_text)
    for assignment in args.set_sample:
        parameter, value_text = assignment.split("=", 1)
        if parameter not in hist.SampleParameters:
            raise ValueError(f"Unknown sample parameter: {parameter}")
        current = hist.SampleParameters[parameter]
        if not isinstance(current, list) or not current:
            raise ValueError(f"Sample parameter is not numeric/refinable: {parameter}")
        current[0] = float(value_text)
    if args.background:
        hist.data["Background"][0][1] = True
    if args.scales:
        for phase in project.phases():
            hap = phase.data["Histograms"][hist.name]
            if not hap["Use"] or not np.isfinite(hap["Scale"][0]) or hap["Scale"][0] <= 0:
                raise ValueError(f"Inactive or nonpositive phase scale: {phase.name}")
            hap["Scale"][1] = True
    if args.instrument:
        hist.set_refinements({"Instrument Parameters": names(args.instrument)})
    if args.sample:
        hist.set_refinements({"Sample Parameters": names(args.sample)})
    for phase in select_phases(project, args.cells):
        phase.data["General"]["Cell"][0] = True
    for phase in select_phases(project, args.size):
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, histograms=[hist]
        )
    for phase in select_phases(project, args.mustrain):
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, histograms=[hist]
        )
    for specification in args.uniaxial_mustrain:
        phase_name, direction_text = specification.split(":", 1)
        direction = [int(v) for v in direction_text.split(",")]
        phase = project.phase(phase_name)
        phase.set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": direction,
                    "refine": True,
                }
            },
            histograms=[hist],
        )
    for specification in args.orientation:
        phase_name, direction_text = specification.split(":", 1)
        direction = [int(v) for v in direction_text.split(",")]
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][3] = direction
        hap["Pref.Ori."][2] = True
    for specification in args.set_orientation:
        phase_name, values_text = specification.split(":", 1)
        values = values_text.split(",")
        if len(values) != 4:
            raise ValueError("Orientation setting requires H,K,L,RATIO")
        direction = [int(value) for value in values[:3]]
        ratio = float(values[3])
        if not np.isfinite(ratio) or ratio <= 0:
            raise ValueError("March-Dollase ratio must be finite and positive")
        phase = project.phase(phase_name)
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = ratio
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = direction
    for phase in select_phases(project, args.coordinates):
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    for specification in args.coordinate_elements:
        phase_name, elements_text = specification.split(":", 1)
        elements = {item.strip() for item in elements_text.split(",") if item.strip()}
        if not elements:
            raise ValueError(f"No coordinate elements supplied for {phase_name}")
        phase = project.phase(phase_name)
        matched = 0
        for atom in phase.atoms():
            if atom.element in elements:
                atom.refinement_flags = "X"
                matched += 1
        if not matched:
            raise ValueError(
                f"No atoms of elements {sorted(elements)} found in phase {phase_name}"
            )
    for specification in args.coordinate_labels:
        phase_name, labels_text = specification.split(":", 1)
        labels = {item.strip() for item in labels_text.split(",") if item.strip()}
        if not labels:
            raise ValueError(f"No coordinate labels supplied for {phase_name}")
        phase = project.phase(phase_name)
        available = {atom.label: atom for atom in phase.atoms()}
        missing = sorted(labels - set(available))
        if missing:
            raise ValueError(f"Unknown atom labels in {phase_name}: {missing}")
        for label in labels:
            available[label].refinement_flags = "X"
    uiso_phases = select_phases(project, args.uiso)
    for phase in uiso_phases:
        for atom in phase.atoms():
            if atom.adp_flag != "I":
                raise ValueError(f"Uiso refinement requested for anisotropic atom {phase.name}:{atom.label}")
            atom.refinement_flags = "U"

    if args.tie_phase_uiso:
        # Replace phase-scope equivalences from any earlier trial, then tie all
        # AUiso variables within each phase selected for Uiso refinement.
        project.get_Constraints("Phase")[:] = []
        first = True
        for phase in uiso_phases:
            atom_count = len(phase.atoms())
            if atom_count < 2:
                continue
            variables = [f"{phase.data['pId']}::AUiso:{i}" for i in range(atom_count)]
            project.add_EquivConstr(variables, reloadIdx=first, override=True)
            first = False

    project.set_Controls("cycles", args.cycles)
    project.refine()
    project.save(str(output))
    report = {
        "input": str(source),
        "project": str(output),
        "histogram": hist.name,
        "stage": {
            key: value
            for key, value in vars(args).items()
            if key not in {"input", "output"} and value not in (None, False, [], "")
        },
        "stats": stats(project, hist.name),
        "phases": phase_report(project, hist.name),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.SampleParameters,
        "high_correlations": correlations(project)[:50],
        "rvals": project.data.get("Covariance", {}).get("data", {}).get("Rvals", {}),
    }
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps({"stats": report["stats"], "high_correlations": report["high_correlations"][:10]}, indent=2))


if __name__ == "__main__":
    main()
