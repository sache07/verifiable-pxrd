#!/usr/bin/env python3
"""Create a symmetry-preserving, substituted oxide-prototype candidate CIF."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from pymatgen.core import Element, Structure
from pymatgen.io.cif import CifWriter
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


def contacts(structure: Structure) -> dict[str, float | None]:
    result = {"all": np.inf, "O-O": np.inf, "Mn-O": np.inf, "W-O": np.inf}
    for i, site in enumerate(structure):
        site_elements = {species.symbol for species in site.species}
        for neighbor in structure.get_neighbors(site, 4.0):
            if neighbor.index == i and neighbor.nn_distance < 1e-8:
                continue
            distance = float(neighbor.nn_distance)
            result["all"] = min(result["all"], distance)
            neighbor_elements = {species.symbol for species in neighbor.species}
            pair = site_elements | neighbor_elements
            if pair == {"O"}:
                result["O-O"] = min(result["O-O"], distance)
            elif pair == {"Mn", "O"}:
                result["Mn-O"] = min(result["Mn-O"], distance)
            elif pair == {"W", "O"}:
                result["W-O"] = min(result["W-O"], distance)
    return {key: (None if not np.isfinite(value) else float(value)) for key, value in result.items()}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("parent")
    parser.add_argument("output")
    parser.add_argument("--from-element")
    parser.add_argument("--to-element", default="Mn")
    parser.add_argument(
        "--identity",
        action="store_true",
        help="allow setting/scale conversion without an element substitution",
    )
    parser.add_argument(
        "--substitute",
        action="append",
        default=[],
        metavar="FROM=TO",
        help="repeatable substitution; supersedes --from-element/--to-element",
    )
    parser.add_argument("--cell-scale", type=float, default=1.0)
    parser.add_argument(
        "--standardize",
        action="store_true",
        help="serialize in the conventional international setting",
    )
    parser.add_argument(
        "--p1",
        action="store_true",
        help="serialize the expanded structure in P1 for reader compatibility",
    )
    parser.add_argument("--parent-id", required=True)
    parser.add_argument("--target-family", required=True)
    args = parser.parse_args()

    parent = Structure.from_file(args.parent)
    target = parent.copy()
    try:
        target.remove_oxidation_states()
    except Exception:
        pass
    substitutions = {}
    for assignment in args.substitute:
        source, destination = assignment.split("=", 1)
        substitutions[Element(source)] = Element(destination)
    if args.from_element:
        substitutions[Element(args.from_element)] = Element(args.to_element)
    if not substitutions and not args.identity:
        raise ValueError("At least one substitution is required")
    if substitutions:
        target.replace_species(substitutions)
    if args.standardize:
        target = SpacegroupAnalyzer(target, symprec=1e-3).get_conventional_standard_structure(
            international_monoclinic=True
        )
    if args.cell_scale <= 0 or not np.isfinite(args.cell_scale):
        raise ValueError("Cell scale must be finite and positive")
    target.scale_lattice(target.volume * args.cell_scale**3)
    occupancies = [float(sum(site.species.values())) for site in target]
    screen = {
        "occupancy_min": min(occupancies),
        "occupancy_max": max(occupancies),
        "contacts_A": contacts(target),
    }
    if screen["occupancy_min"] < 0 or screen["occupancy_max"] > 1.0001:
        raise ValueError(f"Invalid occupancy screen: {screen}")
    if screen["contacts_A"]["all"] is None or screen["contacts_A"]["all"] < 0.8:
        raise ValueError(f"Hard-contact screen failed: {screen}")

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    writer_symprec = None if args.p1 else 1e-3
    CifWriter(
        target,
        symprec=writer_symprec,
        refine_struct=False,
        write_site_properties=False,
    ).write_file(output)
    imported = Structure.from_file(output)
    imported_occupancies = [float(sum(site.species.values())) for site in imported]
    imported_screen = {
        "occupancy_min": min(imported_occupancies),
        "occupancy_max": max(imported_occupancies),
        "contacts_A": contacts(imported),
    }
    if imported_screen["occupancy_min"] < 0 or imported_screen["occupancy_max"] > 1.0001:
        raise ValueError(f"Serialized CIF occupancy screen failed: {imported_screen}")
    if imported_screen["contacts_A"]["all"] is None or imported_screen["contacts_A"]["all"] < 0.8:
        raise ValueError(f"Serialized CIF hard-contact screen failed: {imported_screen}")
    provenance = {
        "model_basis": "analogue_derived",
        "target_family": args.target_family,
        "parent_id": args.parent_id,
        "parent_cif": str(Path(args.parent).resolve()),
        "transformation": {
            "substitution": {
                source.symbol: destination.symbol for source, destination in substitutions.items()
            },
            "isotropic_cell_scale": args.cell_scale,
            "fractional_coordinates": "unchanged before CIF symmetry serialization",
            "conventional_setting_standardized": bool(args.standardize),
            "expanded_P1_serialization": bool(args.p1),
        },
        "composition": imported.composition.formula,
        "reduced_formula": imported.composition.reduced_formula,
        "n_sites": len(imported),
        "space_group": imported.get_space_group_info(symprec=1e-3),
        "cell": imported.lattice.parameters,
        "physical_screen_before_serialization": screen,
        "physical_screen_after_serialization": imported_screen,
    }
    output.with_suffix(".provenance.json").write_text(json.dumps(provenance, indent=2) + "\n")
    print(json.dumps(provenance, indent=2))


if __name__ == "__main__":
    main()
