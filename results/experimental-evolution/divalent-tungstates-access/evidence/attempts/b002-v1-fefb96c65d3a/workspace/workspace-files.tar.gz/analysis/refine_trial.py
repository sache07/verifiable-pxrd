#!/usr/bin/env python3
"""Build a staged GSAS-II trial project from explicitly named phase CIFs.

This is an analysis helper. Candidate identity is always passed by name/path;
no phase is selected through a positional index.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def stats(project: G2.G2Project, histogram_name: str) -> dict:
    hist = project.histogram(histogram_name)
    x, y, w, yc, yb, yd = [np.asarray(a, dtype=float) for a in hist.data["data"][1]]
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi) & np.isfinite(y) & np.isfinite(yc) & (y > 0)
    resid = y[use] - yc[use]
    rwp = 100.0 * np.sqrt(np.sum(w[use] * resid**2) / np.sum(w[use] * y[use] ** 2))
    rp = 100.0 * np.sum(np.abs(resid)) / np.sum(y[use])
    return {
        "Rwp_percent_recomputed": float(rwp),
        "Rp_percent_recomputed": float(rp),
        "n_points": int(np.count_nonzero(use)),
        "fit_limits_deg": [float(lo), float(hi)],
        "max_calc": float(np.max(yc[use])),
        "min_background": float(np.min(yb[use])),
    }


def phase_report(project: G2.G2Project, histogram_name: str) -> list[dict]:
    rows = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram_name]
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        masses.append(max(0.0, scale * mass))
        rows.append(
            {
                "name": phase.name,
                "scale": scale,
                "cell_mass": mass,
                "cell": [float(v) for v in phase.data["General"]["Cell"][1:]],
                "size": phase.data["Histograms"][histogram_name]["Size"],
                "mustrain": phase.data["Histograms"][histogram_name]["Mustrain"],
            }
        )
    total = sum(masses)
    for row, value in zip(rows, masses):
        row["weight_fraction"] = float(value / total) if total else None
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", required=True)
    parser.add_argument("--pattern", default="inputs/pattern.csv")
    parser.add_argument("--instrument", default="analysis/instrument.instprm")
    parser.add_argument(
        "--phase",
        nargs=3,
        action="append",
        metavar=("NAME", "CIF", "SCALE"),
        required=True,
    )
    parser.add_argument("--stage", choices=["scale", "cell", "profile"], default="scale")
    parser.add_argument(
        "--calibration",
        choices=["none", "zero", "shift", "both"],
        default="shift",
        help="Calibration term(s) enabled with cell refinement",
    )
    args = parser.parse_args()

    output = Path(args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(output))
    hist = project.add_powder_histogram(
        str(Path(args.pattern).resolve()),
        str(Path(args.instrument).resolve()),
        fmthint="comma",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [1300.0] + [0.0] * 9,
                "refine": True,
            },
        }
    )

    names = set()
    for name, cif, scale_text in args.phase:
        if name in names:
            raise ValueError(f"Duplicate phase identity: {name}")
        names.add(name)
        phase = project.add_phase(
            str(Path(cif).resolve()),
            phasename=name,
            histograms=[hist],
            fmthint="CIF",
        )
        hap = phase.data["Histograms"][hist.name]
        scale = float(scale_text)
        if not np.isfinite(scale) or scale <= 0:
            raise ValueError(f"Phase {name} requires a positive initial scale")
        hap["Scale"] = [scale, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False

    # Stage 1: only scales and background. Candidate trials share this nuisance model.
    project.set_Controls("cycles", 8)
    project.refine()

    if args.stage in {"cell", "profile"}:
        # Common shift/zero plus all symmetry-independent cell terms.
        if args.calibration in {"zero", "both"}:
            hist.set_refinements({"Instrument Parameters": ["Zero"]})
        if args.calibration in {"shift", "both"}:
            hist.set_refinements({"Sample Parameters": ["Shift"]})
        for phase in project.phases():
            phase.set_refinements({"Cell": True})
        project.refine()

    if args.stage == "profile":
        # Isotropic instrument/profile complexity only at this stage.
        hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X", "SH/L"]})
        for phase in project.phases():
            phase.set_HAP_refinements(
                {
                    "Size": {"type": "isotropic", "value": 1.0, "refine": True},
                    "Mustrain": {"type": "isotropic", "refine": True},
                },
                histograms=[hist],
            )
        project.refine()

    project.save(str(output))
    report = {
        "project": str(output),
        "histogram": hist.name,
        "stage": args.stage,
        "stats": stats(project, hist.name),
        "phases": phase_report(project, hist.name),
        "instrument": hist.data["Instrument Parameters"][0],
        "sample": hist.SampleParameters,
        "covariance": project.data.get("Covariance", {}).get("data", {}),
    }
    output.with_suffix(".json").write_text(json.dumps(report, indent=2, default=str) + "\n")
    print(json.dumps({"stats": report["stats"], "phases": report["phases"]}, indent=2))


if __name__ == "__main__":
    main()
