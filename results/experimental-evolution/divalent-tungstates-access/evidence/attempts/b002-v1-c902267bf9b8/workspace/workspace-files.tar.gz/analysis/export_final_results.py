#!/usr/bin/env python3
"""Export the accepted GSAS-II model and machine-readable deliverables."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "analysis" / "finalization" / "accepted.gpx"
REPLAY = ROOT / "analysis" / "replay_export"
HISTOGRAM = "PWDR pattern.xye"

PHASE_EXPORTS = {
    "MnWO4_wolframite": (
        REPLAY / "phase_0.cif",
        ROOT / "phase_MnWO4_wolframite.cif",
        "MnWO4 (wolframite)",
        "high",
    ),
    "WO3_2311041": (
        REPLAY / "phase_1.cif",
        ROOT / "phase_WO3_monoclinic.cif",
        "WO3 (monoclinic)",
        "high",
    ),
    "Mn3WO62_4030285": (
        REPLAY / "phase_2.cif",
        ROOT / "phase_Mn3W2O12_tentative.cif",
        "Mn3W2O12 (analogue-derived monoclinic model)",
        "tentative",
    ),
}


def main() -> None:
    # Preserve the exact, already-refined project. The replay worker verified
    # that this file is unchanged by full-grid atomic-profile regeneration.
    shutil.copy2(PROJECT, ROOT / "final.gpx")

    project = G2sc.G2Project(str(PROJECT))
    histogram = project.histogram(HISTOGRAM)
    fractions = histogram.ComputeMassFracs()
    phase_names = [phase.name for phase in project.phases()]
    if phase_names != list(PHASE_EXPORTS):
        raise RuntimeError(f"Unexpected project phase inventory: {phase_names}")

    for source, destination, _, _ in PHASE_EXPORTS.values():
        shutil.copy2(source, destination)

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as replay:
        x = np.asarray(replay["x"], dtype=float)
        observed = np.asarray(replay["observed"], dtype=float)
        calculated = np.asarray(replay["predicted"], dtype=float)
        background = np.asarray(replay["background"], dtype=float)
        signal = np.asarray(replay["signal"], dtype=float)

    public = np.loadtxt(
        ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1, ndmin=2
    )
    if not np.allclose(x, public[:, 0], rtol=0, atol=1e-10):
        raise RuntimeError("Replay grid does not match pattern.csv")
    if not np.allclose(observed, public[:, 1], rtol=0, atol=1e-10):
        raise RuntimeError("Replay observations do not match pattern.csv")
    if np.any(calculated < 0) or not np.isfinite(calculated).all():
        raise RuntimeError("Invalid replayed calculated profile")

    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background, signal)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background,bragg_signal",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f", "%.8f", "%.8f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    replay_chi_square = float(np.sum(weights * difference**2))
    replay_rwp = float(
        100.0
        * np.sqrt(replay_chi_square / np.sum(weights * np.square(observed)))
    )
    covariance = project.data["Covariance"]["data"]
    rvals = covariance["Rvals"]
    histogram_stats = histogram.data["data"][0]

    phases = []
    for internal_name, (_, destination, display_name, confidence) in PHASE_EXPORTS.items():
        fraction, sigma = fractions[internal_name]
        phase = project.phase(internal_name)
        cell = phase.get_cell()
        phases.append(
            {
                "name": display_name,
                "project_phase_name": internal_name,
                "formula": {
                    "MnWO4_wolframite": "MnWO4",
                    "WO3_2311041": "WO3",
                    "Mn3WO62_4030285": "Mn3W2O12",
                }[internal_name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": destination.name,
                "weight_fraction": float(fraction),
                "weight_fraction_esd": float(sigma),
                "identification_confidence": confidence,
                "cell": {
                    "a_angstrom": float(cell["length_a"]),
                    "b_angstrom": float(cell["length_b"]),
                    "c_angstrom": float(cell["length_c"]),
                    "alpha_deg": float(cell["angle_alpha"]),
                    "beta_deg": float(cell["angle_beta"]),
                    "gamma_deg": float(cell["angle_gamma"]),
                    "volume_angstrom3": float(cell["volume"]),
                },
            }
        )

    result = {
        "schema_version": 1,
        "refinement_method": "GSAS-II multiphase Rietveld refinement",
        "refinement_histogram": HISTOGRAM,
        "normalization": "Weight fractions sum to one over the modeled crystalline phases.",
        "phases": phases,
        "fit_statistics": {
            "refined_range_two_theta_deg": [10.0, 99.9],
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(histogram_stats["R"]),
            "GOF": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "Nobs": int(rvals["Nobs"]),
            "Nvars": int(rvals["Nvars"]),
            "wRmin_percent": float(histogram_stats["wRmin"]),
            "max_shift_over_esd": float(rvals["Max shft/sig"]),
            "full_grid_replay_Rwp_percent": replay_rwp,
            "full_grid_replay_chi_square": replay_chi_square,
            "full_grid_bins": int(len(x)),
        },
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
        "notes": [
            "The Mn3W2O12 assignment is an analogue-derived P21/c topology and is structurally tentative.",
            "Formal fraction e.s.d.s reflect the fixed three-phase model and do not include phase-model uncertainty.",
        ],
    }
    if not np.isclose(sum(row["weight_fraction"] for row in phases), 1.0, atol=1e-12):
        raise RuntimeError("Mass fractions are not normalized")
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )


if __name__ == "__main__":
    G2sc.SetPrintLevel("warn")
    main()
