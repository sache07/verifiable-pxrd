#!/usr/bin/env python3
"""Test whether candidate isotropic microstrain remains supported after cell/W refinement."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "selected_structure_trials" / "02_candidate_W.gpx"
OUT = ROOT / "analysis" / "candidate_microstrain_trial.gpx"
CANDIDATE = "Mn3WO62_4030285"


def main() -> None:
    G2sc.SetPrintLevel("warn")
    project = G2sc.G2Project(str(BASE), newgpx=str(OUT))
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for name in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(name).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    project.phase("WO3_2311041").data["Histograms"][hist.name]["Pref.Ori."][2] = True
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": size, "refine": True}}
    )
    candidate.set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    project.set_Controls("cycles", 20)
    project.do_refinements([{}], outputnames=[str(OUT)])
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    hap = candidate.data["Histograms"][hist.name]
    result = {
        "output": str(OUT),
        "converged": rvals.get("converged", False),
        "rwp_percent": hist.get_wR(),
        "gof": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "candidate_size_um": float(hap["Size"][1][0]),
        "candidate_microstrain_ppm": float(hap["Mustrain"][1][0]),
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }
    valid = bool(
        rvals.get("converged", False)
        and 0.02 <= result["candidate_size_um"] <= 5.0
        and 0 <= result["candidate_microstrain_ppm"] <= 8000
    )
    result["status"] = "tested" if valid else "unknown"
    if not valid:
        result["reason"] = "nonconvergent or profile term outside generator range"
    else:
        project.save(str(OUT))
    (ROOT / "analysis" / "candidate_microstrain_trial.json").write_text(
        json.dumps(result, indent=2) + "\n"
    )
    print(json.dumps(result, sort_keys=True))


if __name__ == "__main__":
    main()
