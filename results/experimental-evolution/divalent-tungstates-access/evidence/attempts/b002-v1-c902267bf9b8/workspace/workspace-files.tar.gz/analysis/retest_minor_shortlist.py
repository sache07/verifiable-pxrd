#!/usr/bin/env python3
"""Retest a topology-diverse minor-phase shortlist after nuisance refinement."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "specimen_trials" / "17_cells_shift.gpx"
OUT = ROOT / "analysis" / "minor_shortlist"
NORMALIZED = ROOT / "analysis" / "normalized_candidates"
CANDIDATES = {
    "4117966": "MnO_hexagonal",
    "1514108": "MnO_rocksalt",
    "1514110": "MnO2_rutile_a",
    "1514232": "MnO2_rutile_b",
    "2101050": "W3O8_orthorhombic",
    "9001302": "Mn3O4_orthorhombic",
    "9001963": "Mn3O4_hausmannite",
    "1541183": "Mn3O4_orthorhombic_alt",
}


def success(project, expected):
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project):
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    project.phase("WO3_2311041").data["Histograms"][hist.name]["Pref.Ori."][2] = True


def stage(project, output):
    project.set_Controls("cycles", 12)
    project.do_refinements([{}], outputnames=[str(output)])
    return success(project, output)


def run_one(cod_id, label):
    branch = OUT / cod_id
    branch.mkdir(parents=True, exist_ok=True)
    project = G2sc.G2Project(str(BASE), newgpx=str(branch / "trial.gpx"))
    prepare(project)
    hist = project.histogram(0)
    candidate = project.add_phase(
        str(NORMALIZED / f"{cod_id}.cif"),
        phasename=label,
        histograms=[hist],
        fmthint="CIF",
    )
    initial_cell = candidate.get_cell()
    candidate.data["Histograms"][hist.name]["Scale"] = [0.1, True]
    candidate.set_HAP_refinements({"Scale": True, "Use": True})
    candidate.set_refinements({"Cell": False})
    intended = ["MnWO4_wolframite", "WO3_2311041", label]
    active = [p.name for p in project.phases() if p.data["Histograms"][hist.name]["Use"]]
    result = {"cod_id": cod_id, "phase": label, "initial_cell": initial_cell}
    if active != intended or candidate.HAPvalue("Scale", targethistlist=[hist]) <= 0:
        result.update(status="unknown", reason=f"invalid initialized inventory {active}")
        return result

    output = branch / "scale_background.gpx"
    if not stage(project, output):
        result.update(status="unknown", reason="scale/background fit failed")
        return result
    result["rwp_scale_background_percent"] = hist.get_wR()
    result["scale_after_scale_background"] = candidate.HAPvalue("Scale", targethistlist=[hist])
    if result["scale_after_scale_background"] <= 0:
        result.update(status="rejected", reason="scale collapsed non-positive")
        return result

    candidate.set_refinements({"Cell": True})
    output = branch / "cell.gpx"
    if not stage(project, output):
        result.update(status="unknown", reason="cell fit failed")
        return result
    result["rwp_cell_percent"] = hist.get_wR()
    result["refined_cell"] = candidate.get_cell()
    result["volume_ratio"] = candidate.get_cell()["volume"] / initial_cell["volume"]

    candidate.set_refinements({"Cell": False})
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
    )
    output = branch / "size.gpx"
    if not stage(project, output):
        result.update(status="unknown", reason="size fit failed")
        return result
    result["rwp_size_percent"] = hist.get_wR()
    result["size_um"] = candidate.data["Histograms"][hist.name]["Size"][1][0]
    result["mass_fractions"] = {
        name: {"value": value, "sigma": sigma}
        for name, (value, sigma) in hist.ComputeMassFracs().items()
    }
    if not 0.8 < result["volume_ratio"] < 1.2:
        result.update(status="rejected", reason="requires >20% cell-volume change")
    elif not 0.02 < result["size_um"] <= 10.0:
        result.update(status="unknown", reason="size is boundary-hitting or invalid")
    else:
        result["status"] = "tested"
    project.save(str(branch / "trial.gpx"))
    return result


def main():
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for cod_id, label in CANDIDATES.items():
        result = run_one(cod_id, label)
        results.append(result)
        print(
            cod_id,
            result["status"],
            result.get("rwp_scale_background_percent"),
            result.get("rwp_cell_percent"),
            result.get("rwp_size_percent"),
            result.get("reason", ""),
            flush=True,
        )
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
