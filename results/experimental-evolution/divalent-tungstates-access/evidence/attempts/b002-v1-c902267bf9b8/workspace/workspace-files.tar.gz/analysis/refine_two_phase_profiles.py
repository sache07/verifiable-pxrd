#!/usr/bin/env python3
"""Stage physically screened isotropic profile refinements for two phases."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "wo3_trials_v2" / "2311041" / "cell.gpx"
OUT = ROOT / "analysis" / "profile_trials"


def refinement_succeeded(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def physical(project: G2sc.G2Project) -> tuple[bool, str]:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    vals = {key: float(inst[key][1]) for key in ("U", "V", "W", "X", "Y", "SH/L")}
    theta = np.radians(np.linspace(5.0, 50.0, 1000))
    gaussian = vals["U"] * np.tan(theta) ** 2 + vals["V"] * np.tan(theta) + vals["W"]
    lorentzian = vals["X"] / np.cos(theta) + vals["Y"] * np.tan(theta)
    if np.any(~np.isfinite(gaussian)) or np.min(gaussian) <= 0:
        return False, f"non-positive Gaussian width (minimum {np.min(gaussian)})"
    if np.any(~np.isfinite(lorentzian)) or np.min(lorentzian) < 0:
        return False, f"negative Lorentzian width (minimum {np.min(lorentzian)})"
    if not 0.0005 <= vals["SH/L"] <= 0.2:
        return False, f"SH/L outside physical screening interval: {vals['SH/L']}"
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        size = float(hap["Size"][1][0])
        mustrain = float(hap["Mustrain"][1][0])
        if not np.isfinite(size) or size <= 0.01 or size > 20:
            return False, f"invalid size for {phase.name}: {size} um"
        if not np.isfinite(mustrain) or mustrain < 0 or mustrain > 50000:
            return False, f"invalid microstrain for {phase.name}: {mustrain} ppm"
    return True, ""


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Sample Parameters"]["Shift"][1] = False
    hist.set_refinements({"Background": {"refine": True}})
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    return {
        "rwp_percent": hist.get_wR(),
        "instrument": {key: float(inst[key][1]) for key in ("U", "V", "W", "X", "Y", "SH/L")},
        "phases": {
            phase.name: {
                "scale": phase.HAPvalue("Scale", targethistlist=[hist]),
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "microstrain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
            }
            for phase in project.phases()
        },
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }


def run_stage(input_path: Path, label: str, configure) -> tuple[Path | None, dict]:
    output = OUT / f"{label}.gpx"
    project = G2sc.G2Project(str(input_path), newgpx=str(output))
    prepare(project)
    configure(project)
    project.set_Controls("cycles", 12)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"stage": label, "input": str(input_path), "output": str(output)}
    if not refinement_succeeded(project, output):
        result.update(status="unknown", reason="refinement did not complete cleanly")
        return None, result
    valid, reason = physical(project)
    result.update(summarize(project))
    if not valid:
        result.update(status="unknown", reason=reason)
        return None, result
    result["status"] = "tested"
    project.save(str(output))
    return output, result


def instrument(*keys):
    def configure(project):
        project.histogram(0).set_refinements({"Instrument Parameters": list(keys)})
    return configure


def phase_size(names):
    def configure(project):
        for name in names:
            project.phase(name).set_HAP_refinements(
                {"Size": {"type": "isotropic", "value": 1.0, "refine": True}}
            )
    return configure


def phase_mustrain(names):
    def configure(project):
        hist = project.histogram(0)
        for name in names:
            phase = project.phase(name)
            phase.data["Histograms"][hist.name]["Mustrain"][1][0] = 1000.0
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}
            )
    return configure


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    current = BASE
    for label, configure in [
        ("01_W", instrument("W")),
        ("02_WU", instrument("W", "U")),
        ("03_WUX", instrument("W", "U", "X")),
        ("04_size_main", phase_size(["MnWO4_wolframite"])),
        ("05_size_both", phase_size(["MnWO4_wolframite", "WO3_2311041"])),
        ("06_mustrain_main", phase_mustrain(["MnWO4_wolframite"])),
        ("07_mustrain_both", phase_mustrain(["MnWO4_wolframite", "WO3_2311041"])),
    ]:
        output, result = run_stage(current, label, configure)
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
        if output is not None:
            current = output
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
