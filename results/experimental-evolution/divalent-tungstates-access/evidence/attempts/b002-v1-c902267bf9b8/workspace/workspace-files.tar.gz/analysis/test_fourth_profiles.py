#!/usr/bin/env python3
"""Require physically stable size broadening for the two surviving fourth-phase branches."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "fourth_profile_trials"
THIRD = "Mn3WO62_4030285"
BRANCHES = {
    "MnO_hexagonal": ROOT / "analysis" / "closure_trials" / "MnO_hexagonal" / "cell.gpx",
    "Mn3WO6_2242674_fourth": ROOT
    / "analysis"
    / "closure_trials"
    / "Mn3WO6_2242674_fourth"
    / "cell.gpx",
}


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def run(name: str, source: Path) -> dict:
    output = OUT / f"{name}_size.gpx"
    project = G2sc.G2Project(str(source), newgpx=str(output))
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for parent in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(parent).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    for textured in ("WO3_2311041", THIRD):
        project.phase(textured).data["Histograms"][hist.name]["Pref.Ori."][2] = True
    third = project.phase(THIRD)
    third_size = float(third.data["Histograms"][hist.name]["Size"][1][0])
    third.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": third_size, "refine": True}}
    )
    fourth = project.phase(name)
    initial = float(fourth.data["Histograms"][hist.name]["Size"][1][0])
    fourth.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": initial, "refine": True}}
    )
    project.set_Controls("cycles", 20)
    project.do_refinements([{}], outputnames=[str(output)])
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    size = float(fourth.data["Histograms"][hist.name]["Size"][1][0])
    result = {
        "phase": name,
        "input": str(source),
        "output": str(output),
        "rwp_percent": hist.get_wR(),
        "converged": rvals.get("converged", False),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "size_um": size,
        "mass_fractions": {
            phase_name: {"value": value, "sigma": sigma}
            for phase_name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }
    if not success(project, output):
        result.update(status="unknown", reason="refinement failed or did not converge")
    elif not 0.04 <= size <= 1.5:
        result.update(status="unknown", reason="size outside generator range")
    else:
        result["status"] = "tested"
        project.save(str(output))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for name, source in BRANCHES.items():
        result = run(name, source)
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
