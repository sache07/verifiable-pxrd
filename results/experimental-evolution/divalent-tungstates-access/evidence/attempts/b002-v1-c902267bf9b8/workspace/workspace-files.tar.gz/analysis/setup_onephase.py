#!/usr/bin/env python3
"""Create and stage a one-phase GSAS-II refinement for residual analysis."""

from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
PATTERN = ROOT / "inputs" / "pattern.csv"
WORK = ROOT / "analysis" / "onephase"
MNWO4 = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/1/52/02/1520200.cif"
)


def write_inputs() -> tuple[Path, Path]:
    WORK.mkdir(parents=True, exist_ok=True)
    arr = np.loadtxt(PATTERN, delimiter=",", skiprows=1)
    xye = WORK / "pattern.xye"
    np.savetxt(
        xye,
        np.column_stack((arr[:, 0], arr[:, 1], np.sqrt(np.maximum(arr[:, 1], 1.0)))),
        fmt=("%.8f", "%.8f", "%.8f"),
    )
    inst = WORK / "CuKa.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file for Cu Kalpha Bragg-Brentano data\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;Zero:0.0;Polariz.:0.7;"
        "Azimuth:0.0;I(L2)/I(L1):0.5\n"
        "U:20.0;V:0.0;W:20.0;X:2.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def summarize(project: G2sc.G2Project, label: str) -> None:
    hist = project.histogram(0)
    phase = project.phase("MnWO4_wolframite")
    hap = phase.data["Histograms"][hist.name]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    print(
        label,
        "wR", hist.get_wR(),
        "cell", phase.get_cell(),
        "phase_scale", hap["Scale"],
        "shift", sample.get("Shift"),
        "profile", {k: inst[k] for k in ("U", "V", "W", "X", "Y", "SH/L")},
    )


def main() -> None:
    G2sc.SetPrintLevel("warn")
    xye, inst = write_inputs()
    project = G2sc.G2Project(newgpx=str(WORK / "onephase.gpx"))
    hist = project.add_powder_histogram(str(xye), str(inst), fmthint="xye")
    phase = project.add_phase(
        str(MNWO4),
        phasename="MnWO4_wolframite",
        histograms=[hist],
        fmthint="CIF",
    )
    project.set_Controls("cycles", 8)
    hist.data["Background"][0][0] = "chebyschev-1"
    hist.data["Background"][0][2] = 10
    hist.data["Background"][0][3:] = [1400.0] + [0.0] * 9
    hist.data["Limits"][1] = [10.0, 99.9]
    # Explicit positive starting scale; the phase is addressed by name above.
    phase.data["Histograms"][hist.name]["Scale"][0] = 1.0
    phase.set_HAP_refinements({"Scale": True})
    hist.set_refinements({"Background": {"refine": True}})
    project.do_refinements([{}], outputnames=[str(WORK / "stage1_scale_bg.gpx")])
    summarize(project, "stage1")

    # Common angular displacement and symmetry-independent monoclinic cell terms.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    phase.set_refinements({"Cell": True})
    project.do_refinements([{}], outputnames=[str(WORK / "stage2_shift_cell.gpx")])
    summarize(project, "stage2")

    # Refine only the isotropic instrumental profile terms at this stage.
    hist.set_refinements({"Instrument Parameters": ["U", "V", "W", "X"]})
    project.do_refinements([{}], outputnames=[str(WORK / "stage3_profile.gpx")])
    summarize(project, "stage3")
    project.save(str(WORK / "onephase.gpx"))


if __name__ == "__main__":
    main()
