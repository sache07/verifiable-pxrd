#!/usr/bin/env python3
"""Construct Mn-W-O candidates from one- and two-substitution oxide parents."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "analogue_candidates"
CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


SPECS = [
    # Mn2WO6: one-substitution parents with the same A2WO6 stoichiometry.
    ("mn2wo6_y_1541070", "1541070", {"Y": "Mn"}),
    ("mn2wo6_y_2106838", "2106838", {"Y": "Mn"}),
    ("mn2wo6_y_1563285", "1563285", {"Y": "Mn"}),
    ("mn2wo6_fe_2310464", "2310464", {"Fe": "Mn"}),
    ("mn2wo6_cr_1530909", "1530909", {"Cr": "Mn"}),
    ("mn2wo6_v_1008912", "1008912", {"V": "Mn"}),
    ("mn2wo6_lu_7712111", "7712111", {"Lu": "Mn"}),
    # Multiplicity-preserving two-substitution parents.
    ("mn2wo6_mnnb_8103682", "8103682", {"Mn": "W", "Nb": "Mn"}),
    ("mn2wo6_mnta_8103683", "8103683", {"Mn": "W", "Ta": "Mn"}),
    ("mn2wo6_mnta_1531374", "1531374", {"Mn": "W", "Ta": "Mn"}),
    ("mn2wo6_ymo_1533443", "1533443", {"Y": "Mn", "Mo": "W"}),
    ("mn2wo6_lamo_1539106", "1539106", {"La": "Mn", "Mo": "W"}),
    ("mn2wo6_lamo_2000420", "2000420", {"La": "Mn", "Mo": "W"}),
    # Mn3WO6: charge-balanced mixed-valence manganese tungstate candidates.
    ("mn3wo6_cu_1527404", "1527404", {"Cu": "Mn"}),
    ("mn3wo6_ca_1563081", "1563081", {"Ca": "Mn"}),
    ("mn3wo6_ba_1534803", "1534803", {"Ba": "Mn"}),
    ("mn3wo6_camno_4001598", "4001598", {"Ca": "W"}),
    ("mn3wo6_dymno_4345717", "4345717", {"Dy": "W"}),
    # MnW2O7 and MnW2O8 families.
    ("mnw2o7_mnv_4030807", "4030807", {"V": "W"}),
    ("mnw2o7_mgmo_2106441", "2106441", {"Mg": "Mn", "Mo": "W"}),
    ("mnw2o7_temo_1007001", "1007001", {"Te": "W", "Mo": "Mn"}),
    ("mnw2o8_mnv_4030806", "4030806", {"V": "W"}),
    ("mnw2o8_zrw_2004120", "2004120", {"Zr": "Mn"}),
    ("mnw2o8_zrmo_1540280", "1540280", {"Zr": "Mn", "Mo": "W"}),
    ("mnw2o8_zrmo_2103577", "2103577", {"Zr": "Mn", "Mo": "W"}),
    ("mnw2o8_zrmo_2102219", "2102219", {"Zr": "Mn", "Mo": "W"}),
    ("mnw2o8_zrmo_2103585", "2103585", {"Zr": "Mn", "Mo": "W"}),
    ("mnw2o8_zrmo_4002577", "4002577", {"Zr": "Mn", "Mo": "W"}),
    # Mn3WO8 parents with preserved 3:1 cation multiplicities.
    ("mn3wo8_mnas_9000156", "9000156", {"As": "W"}),
    ("mn3wo8_mnse_1527675", "1527675", {"Mn": "W", "Se": "Mn"}),
]


def source_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_model(model_id: str, cod_id: str, substitutions: dict[str, str]) -> dict:
    source = source_path(cod_id)
    structure = CifParser(source, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
    parent_formula = structure.composition.reduced_formula
    structure.remove_oxidation_states()
    structure.replace_species(substitutions)
    for index, site in enumerate(structure):
        site.label = f"{site.species_string}{index}"
    writer = CifWriter(structure, symprec=0.001, significant_figures=10)
    tag = "_atom_site_U_iso_or_equiv"
    for block in writer.cif_file.data.values():
        block.data[tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
        loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
        if tag not in loop:
            loop.append(tag)
    destination = OUT / f"{model_id}.cif"
    destination.write_text(str(writer) + "\n")
    distances = structure.distance_matrix.copy()
    np.fill_diagonal(distances, np.inf)
    return {
        "model_id": model_id,
        "parent_cod_id": cod_id,
        "parent_formula": parent_formula,
        "source": str(source),
        "cif": str(destination),
        "substitutions": substitutions,
        "target_formula": structure.composition.reduced_formula,
        "space_group": structure.get_space_group_info(symprec=0.001),
        "cell": {
            "a": structure.lattice.a,
            "b": structure.lattice.b,
            "c": structure.lattice.c,
            "alpha": structure.lattice.alpha,
            "beta": structure.lattice.beta,
            "gamma": structure.lattice.gamma,
            "volume": structure.volume,
        },
        "sites": len(structure),
        "density_g_cm3": structure.density,
        "minimum_separation_A": float(distances.min()),
        "model_basis": "analogue_derived",
        "transformation": "species substitutions only; site multiplicities/topology preserved; neutral elements; Uiso=0.005 A^2",
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    records = []
    for model_id, cod_id, substitutions in SPECS:
        try:
            records.append(write_model(model_id, cod_id, substitutions))
        except Exception as exc:
            records.append(
                {
                    "model_id": model_id,
                    "parent_cod_id": cod_id,
                    "substitutions": substitutions,
                    "status": "unknown",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
    (OUT / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")
    for record in records:
        print(
            record["model_id"],
            record.get("target_formula"),
            record.get("space_group"),
            record.get("minimum_separation_A"),
            record.get("error", ""),
        )


if __name__ == "__main__":
    main()
