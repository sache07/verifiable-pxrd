#!/usr/bin/env python3
"""Test plausible residual Mn and W oxides as a third crystalline phase."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "wo3_trials_v2" / "2311041" / "cell.gpx"
OUT = ROOT / "analysis" / "third_phase_trials"
NORMALIZED = ROOT / "analysis" / "normalized_candidates"
INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/index.json.gz"
)


def candidates() -> list[dict]:
    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    rows = []
    for formula, cod_id, space_group, _ in index["O-W"]:
        if formula != "WO3":
            rows.append({"formula": formula, "cod_id": cod_id, "space_group": int(space_group)})
    plausible_manganese_oxides = {"MnO", "Mn2O3", "Mn3O4", "MnO2"}
    for formula, cod_id, space_group, _ in index["Mn-O"]:
        if formula in plausible_manganese_oxides:
            rows.append({"formula": formula, "cod_id": cod_id, "space_group": int(space_group)})
    return list({row["cod_id"]: row for row in rows}.values())


def source_records() -> dict[str, dict]:
    records = json.loads((NORMALIZED / "provenance.json").read_text())
    return {record["cod_id"]: record for record in records}


def refinement_succeeded(project: G2sc.G2Project, expected_title: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    title = covariance.get("title")
    return bool(
        title
        and Path(title).resolve() == expected_title.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare_common(project: G2sc.G2Project):
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Sample Parameters"]["Shift"][1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    existing = [project.phase("MnWO4_wolframite"), project.phase("WO3_2311041")]
    for phase in existing:
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
    hist.set_refinements({"Background": {"refine": True}})
    return hist, existing


def run_one(row: dict, provenance: dict) -> dict:
    cod_id = row["cod_id"]
    branch = OUT / cod_id
    branch.mkdir(parents=True, exist_ok=True)
    result = {**row, "status": "pending", "source_geometry": provenance}
    if "error" in provenance:
        result.update(status="unknown", reason="source could not be normalized")
        return result
    if provenance["minimum_separation_A"] < 0.8:
        result.update(status="rejected", reason="source has an interatomic contact below 0.8 A")
        return result
    source = NORMALIZED / f"{cod_id}.cif"
    result["source_cif"] = str(source)
    try:
        project = G2sc.G2Project(str(BASE), newgpx=str(branch / "trial.gpx"))
        hist, existing = prepare_common(project)
        name = f"{row['formula']}_{cod_id}"
        candidate = project.add_phase(
            str(source), phasename=name, histograms=[hist], fmthint="CIF"
        )
        initial_cell = candidate.get_cell()
        result["initial_cell"] = initial_cell
        candidate.data["Histograms"][hist.name]["Scale"] = [1.0, True]
        candidate.set_HAP_refinements({"Scale": True, "Use": True})
        candidate.set_refinements({"Cell": False})
        active = [p.name for p in project.phases() if p.data["Histograms"][hist.name]["Use"]]
        intended = [p.name for p in existing] + [candidate.name]
        if active != intended:
            raise RuntimeError(f"unexpected active inventory: {active}")
        if any(p.HAPvalue("Scale", targethistlist=[hist]) <= 0 for p in project.phases()):
            raise RuntimeError("non-positive initialized scale")

        project.set_Controls("cycles", 8)
        scale_output = branch / "scale_background.gpx"
        project.do_refinements([{}], outputnames=[str(scale_output)])
        if not refinement_succeeded(project, scale_output):
            result.update(status="unknown", reason="scale/background fit did not complete cleanly")
            return result
        result["rwp_scale_background_percent"] = hist.get_wR()
        result["candidate_scale_after_scale_background"] = candidate.HAPvalue(
            "Scale", targethistlist=[hist]
        )
        if result["candidate_scale_after_scale_background"] <= 0:
            result.update(status="rejected", reason="candidate scale collapsed non-positive")
            return result

        candidate.set_refinements({"Cell": True})
        cell_output = branch / "cell.gpx"
        project.do_refinements([{}], outputnames=[str(cell_output)])
        if not refinement_succeeded(project, cell_output):
            result.update(status="unknown", reason="cell fit did not complete cleanly")
            return result
        refined_cell = candidate.get_cell()
        result["refined_cell"] = refined_cell
        result["volume_ratio"] = refined_cell["volume"] / initial_cell["volume"]
        result["rwp_cell_percent"] = hist.get_wR()
        result["candidate_scale"] = candidate.HAPvalue("Scale", targethistlist=[hist])
        result["mass_fractions"] = {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        }
        if result["candidate_scale"] <= 0:
            result.update(status="unknown", reason="candidate scale became non-positive")
        elif not 0.8 < result["volume_ratio"] < 1.2:
            result.update(status="rejected", reason="fit requires a cell-volume change above 20%")
        else:
            result["status"] = "tested"
        project.save(str(branch / "trial.gpx"))
    except Exception as exc:
        result.update(status="unknown", reason=f"{type(exc).__name__}: {exc}")
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    provenance = source_records()
    results = []
    for row in candidates():
        result = run_one(row, provenance.get(row["cod_id"], {"error": "missing"}))
        results.append(result)
        print(
            result["cod_id"],
            result["formula"],
            result["status"],
            result.get("rwp_scale_background_percent"),
            result.get("rwp_cell_percent"),
            result.get("reason", ""),
            flush=True,
        )
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
