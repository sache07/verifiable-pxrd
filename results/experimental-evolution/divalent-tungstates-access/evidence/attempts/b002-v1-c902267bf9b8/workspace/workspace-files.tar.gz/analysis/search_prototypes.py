#!/usr/bin/env python3
"""Broad oxide-prototype search against the coherent two-phase residual.

The search enumerates binary/ternary oxides that can be converted to Mn-W-O
with one or two element substitutions, preserves every site/multiplicity, and
ranks their calculated Cu Kalpha1 peak families before any Rietveld fitting.
"""

from __future__ import annotations

import gzip
import json
import math
import os
import warnings
from concurrent.futures import ProcessPoolExecutor
from itertools import product
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d


ROOT = Path(__file__).resolve().parents[1]
INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/index.json.gz"
)
CIF_ROOT = INDEX.parent / "cif"
RESIDUAL = ROOT / "analysis" / "prototype_search" / "base_residual.npz"
OUT = ROOT / "analysis" / "prototype_search"
WAVELENGTH = 1.540598
FACTORS = np.linspace(0.94, 1.06, 25)


def source_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def enumerate_jobs() -> list[dict]:
    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    jobs = []
    seen = set()
    for element_key, rows in index.items():
        elements = element_key.split("-")
        if "O" not in elements or not 2 <= len(elements) <= 3 or "H" in elements:
            continue
        cations = [element for element in elements if element != "O"]
        if len(cations) != 2:
            continue
        for formula, cod_id, space_group, disorder in rows:
            try:
                composition = Composition(formula)
                if set(composition.get_el_amt_dict()) != set(elements):
                    continue
                reduced = composition.reduced_composition.get_el_amt_dict()
                counts = [reduced[element] for element in cations]
                oxygen = reduced["O"]
                if any(
                    abs(value - round(value)) > 1e-5
                    for value in [oxygen, *counts]
                ):
                    continue
                if sum(reduced.values()) > 40 or oxygen > 24:
                    continue
            except Exception:
                continue
            for targets in product(("Mn", "W"), repeat=2):
                if set(targets) != {"Mn", "W"}:
                    continue
                manganese = sum(
                    counts[i] for i, target in enumerate(targets) if target == "Mn"
                )
                tungsten = sum(
                    counts[i] for i, target in enumerate(targets) if target == "W"
                )
                mn_oxidation = (2 * oxygen - 6 * tungsten) / manganese
                if not 1.5 <= mn_oxidation <= 4.5:
                    continue
                substitutions = dict(zip(cations, targets))
                key = (cod_id, tuple(sorted(substitutions.items())))
                if key in seen:
                    continue
                seen.add(key)
                jobs.append(
                    {
                        "cod_id": cod_id,
                        "parent_formula": formula,
                        "space_group_number": int(space_group),
                        "disorder_metric": disorder,
                        "substitutions": substitutions,
                        "nominal_target_counts": {
                            "Mn": manganese,
                            "W": tungsten,
                            "O": oxygen,
                        },
                        "nominal_mn_oxidation": mn_oxidation,
                    }
                )
    return jobs


_SEARCH_DATA = None


def init_worker() -> None:
    global _SEARCH_DATA
    data = np.load(RESIDUAL)
    x = np.asarray(data["two_theta"], float)
    observed = np.asarray(data["observed"], float)
    residual = np.asarray(data["residual"], float)
    standardized = residual / np.sqrt(np.maximum(observed, 1.0))
    _SEARCH_DATA = {
        "x": x,
        "observed": observed,
        "smooth": {
            sigma: gaussian_filter1d(standardized, sigma=sigma, mode="nearest")
            for sigma in (3.0, 7.0, 14.0)
        },
    }
    warnings.filterwarnings("ignore")


def rank_pattern(two_theta: np.ndarray, intensity: np.ndarray) -> dict:
    x = _SEARCH_DATA["x"]
    observed = _SEARCH_DATA["observed"]
    keep = (
        np.isfinite(two_theta)
        & np.isfinite(intensity)
        & (two_theta >= 10.0)
        & (two_theta <= 99.9)
        & (intensity >= 0.5)
    )
    two_theta = two_theta[keep]
    intensity = intensity[keep]
    if not len(two_theta):
        raise ValueError("no usable reflections")
    best = None
    source_sine = np.sin(np.deg2rad(two_theta / 2.0))
    for factor in FACTORS:
        valid = source_sine / factor < 1.0
        shifted = np.rad2deg(2.0 * np.arcsin(source_sine[valid] / factor))
        values = intensity[valid]
        in_range = (shifted >= 10.0) & (shifted <= 99.9)
        shifted = shifted[in_range]
        values = values[in_range]
        if not len(shifted):
            continue
        local_noise = np.sqrt(np.interp(shifted, x, np.maximum(observed, 1.0)))
        denominator = math.sqrt(float(np.sum((values / local_noise) ** 2)))
        if denominator <= 0:
            continue
        for sigma, smoothed in _SEARCH_DATA["smooth"].items():
            sampled = np.interp(shifted, x, smoothed)
            score = float(np.sum(values * sampled / local_noise) / denominator)
            trial = {
                "coarse_score": score,
                "uniform_cell_factor": float(factor),
                "residual_smoothing_points": sigma,
                "reflection_count": int(len(shifted)),
            }
            if best is None or score > best["coarse_score"]:
                best = trial
    return best


def evaluate(job: dict) -> dict:
    result = dict(job)
    source = source_path(job["cod_id"])
    result["source"] = str(source)
    try:
        structure = CifParser(source, occupancy_tolerance=1.0).parse_structures(
            primitive=False
        )[0]
        structure.remove_oxidation_states()
        structure.replace_species(job["substitutions"])
        if len(structure) > 240:
            raise ValueError("expanded cell exceeds 240 sites")
        distances = np.asarray(structure.distance_matrix, float)
        np.fill_diagonal(distances, np.inf)
        minimum = float(np.min(distances))
        result["minimum_separation_A"] = minimum
        result["expanded_sites"] = len(structure)
        result["target_formula"] = structure.composition.reduced_formula
        result["source_cell"] = {
            "a": structure.lattice.a,
            "b": structure.lattice.b,
            "c": structure.lattice.c,
            "alpha": structure.lattice.alpha,
            "beta": structure.lattice.beta,
            "gamma": structure.lattice.gamma,
            "volume": structure.volume,
        }
        if minimum < 0.8:
            result.update(status="rejected_geometry")
            return result
        pattern = XRDCalculator(wavelength=WAVELENGTH, symprec=0).get_pattern(
            structure, two_theta_range=(9.5, 101.0), scaled=True
        )
        result.update(
            status="ranked",
            **rank_pattern(np.asarray(pattern.x, float), np.asarray(pattern.y, float)),
        )
    except Exception as exc:
        result.update(status="unknown", error=f"{type(exc).__name__}: {exc}")
    return result


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    jobs = enumerate_jobs()
    print(f"enumerated {len(jobs)} substitution branches", flush=True)
    workers = min(8, os.cpu_count() or 1)
    results = []
    with ProcessPoolExecutor(max_workers=workers, initializer=init_worker) as executor:
        for index, result in enumerate(executor.map(evaluate, jobs, chunksize=4), 1):
            results.append(result)
            if index % 100 == 0 or index == len(jobs):
                ranked = [row for row in results if row.get("status") == "ranked"]
                leader = max(ranked, key=lambda row: row["coarse_score"]) if ranked else {}
                print(
                    f"{index}/{len(jobs)} leader={leader.get('cod_id')} "
                    f"{leader.get('target_formula')} score={leader.get('coarse_score')}",
                    flush=True,
                )
    ranked = sorted(
        (row for row in results if row.get("status") == "ranked"),
        key=lambda row: row["coarse_score"],
        reverse=True,
    )
    payload = {
        "method": (
            "Cu Kalpha1 patterns of all binary/ternary oxide parents transformable "
            "to Mn-W-O by one or two whole-element substitutions; signed residual "
            "score sampled after 3, 7, or 14-point smoothing and 0.94-1.06 "
            "uniform cell scaling"
        ),
        "jobs": len(jobs),
        "ranked": len(ranked),
        "unknown": sum(row.get("status") == "unknown" for row in results),
        "rejected_geometry": sum(
            row.get("status") == "rejected_geometry" for row in results
        ),
        "results": results,
    }
    (OUT / "coarse_ledger.json").write_text(json.dumps(payload, indent=2) + "\n")
    (OUT / "top_candidates.json").write_text(json.dumps(ranked[:200], indent=2) + "\n")
    for row in ranked[:50]:
        print(
            f"{row['coarse_score']:9.3f} {row['cod_id']} "
            f"{row['parent_formula']} -> {row['target_formula']} "
            f"{row['substitutions']} factor={row['uniform_cell_factor']:.4f}",
            flush=True,
        )


if __name__ == "__main__":
    main()
