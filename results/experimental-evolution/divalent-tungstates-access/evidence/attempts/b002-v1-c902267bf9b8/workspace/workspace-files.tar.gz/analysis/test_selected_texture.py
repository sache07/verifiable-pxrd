#!/usr/bin/env python3
"""Test one candidate March-Dollase axis at a time on the physical W-coordinate model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "selected_structure_trials" / "02_candidate_W.gpx"
OUT = ROOT / "analysis" / "selected_texture_trials"
CANDIDATE = "Mn3WO62_4030285"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for name in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(name).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    project.phase("WO3_2311041").data["Histograms"][hist.name]["Pref.Ori."][2] = True
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": size, "refine": True}}
    )


def run(axis: tuple[int, int, int]) -> dict:
    label = "".join(map(str, axis))
    output = OUT / f"candidate_{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    prepare(project)
    hist = project.histogram(0)
    phase = project.phase(CANDIDATE)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    project.set_Controls("cycles", 16)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"axis": list(axis), "output": str(output)}
    if not success(project, output):
        result.update(status="unknown", reason="refinement failed or did not converge")
        return result
    ratio = float(pref[1])
    size = float(phase.data["Histograms"][hist.name]["Size"][1][0])
    rvals = project.data["Covariance"]["data"]["Rvals"]
    result.update(
        rwp_percent=hist.get_wR(),
        gof=rvals.get("GOF"),
        max_shift_over_sigma=rvals.get("Max shft/sig"),
        march_dollase_ratio=ratio,
        candidate_size_um=size,
        mass_fractions={
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    )
    if not 0.7 <= ratio <= 1.4:
        result.update(status="rejected", reason="texture ratio outside generator range")
    elif not 0.02 <= size <= 5.0:
        result.update(status="unknown", reason="candidate size became invalid")
    else:
        result["status"] = "tested"
        project.save(str(output))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for axis in AXES:
        result = run(axis)
        results.append(result)
        print(
            result["axis"],
            result["status"],
            result.get("rwp_percent"),
            result.get("march_dollase_ratio"),
            result.get("candidate_size_um"),
            flush=True,
        )
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
