#!/usr/bin/env python3
"""Rietveld-screen the broad-search prototype shortlist identically."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "specimen_trials" / "17_cells_shift.gpx"
SOURCE = ROOT / "analysis" / "prototype_shortlist"
OUT = ROOT / "analysis" / "prototype_trials"
PARENTS = ["MnWO4_wolframite", "WO3_2311041"]


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project):
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for name in PARENTS:
        phase = project.phase(name)
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    project.phase("WO3_2311041").data["Histograms"][hist.name]["Pref.Ori."][2] = True
    return hist


def stage(project: G2sc.G2Project, output: Path) -> bool:
    project.set_Controls("cycles", 12)
    project.do_refinements([{}], outputnames=[str(output)])
    return success(project, output)


def run_one(record: dict) -> dict:
    result = {**record, "status": "pending"}
    if "cif" not in record or "error" in record:
        result.update(status="unknown", reason="candidate CIF unavailable")
        return result
    name = record["model_id"]
    branch = OUT / name
    branch.mkdir(parents=True, exist_ok=True)
    try:
        project = G2sc.G2Project(str(BASE), newgpx=str(branch / "trial.gpx"))
        hist = prepare(project)
        candidate = project.add_phase(
            record["cif"], phasename=name, histograms=[hist], fmthint="CIF"
        )
        initial_cell = candidate.get_cell()
        result["gsas_initial_cell"] = initial_cell
        candidate.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        candidate.set_HAP_refinements({"Scale": True, "Use": True})
        candidate.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        candidate.data["Histograms"][hist.name]["Scale"] = [0.1, True]
        active = [
            phase.name
            for phase in project.phases()
            if phase.data["Histograms"][hist.name]["Use"]
        ]
        scales = {
            phase.name: phase.HAPvalue("Scale", targethistlist=[hist])
            for phase in project.phases()
        }
        result["active_inventory"] = active
        result["initialized_scales"] = scales
        if active != PARENTS + [name] or any(scales[key] <= 0 for key in active):
            result.update(status="unknown", reason="invalid initialized inventory")
            return result

        output = branch / "scale_background.gpx"
        if not stage(project, output):
            result.update(status="unknown", reason="scale/background fit failed")
            return result
        result["rwp_scale_background_percent"] = hist.get_wR()
        result["scale_after_scale_background"] = candidate.HAPvalue(
            "Scale", targethistlist=[hist]
        )
        if result["scale_after_scale_background"] <= 0:
            result.update(status="rejected", reason="scale collapsed non-positive")
            return result

        candidate.set_refinements({"Cell": True})
        output = branch / "cell.gpx"
        if not stage(project, output):
            result.update(status="unknown", reason="cell fit failed")
            return result
        result["rwp_cell_percent"] = hist.get_wR()
        result["refined_cell"] = candidate.get_cell()
        result["volume_ratio_from_initialized"] = (
            result["refined_cell"]["volume"] / initial_cell["volume"]
        )
        result["volume_ratio_from_parent"] = (
            result["refined_cell"]["volume"]
            / record["original_parent_cell"]["volume"]
        )
        result["candidate_scale"] = candidate.HAPvalue(
            "Scale", targethistlist=[hist]
        )
        result["mass_fractions"] = {
            phase_name: {"value": value, "sigma": sigma}
            for phase_name, (value, sigma) in hist.ComputeMassFracs().items()
        }
        if result["candidate_scale"] <= 0:
            result.update(status="unknown", reason="scale became non-positive")
        elif not 0.8 < result["volume_ratio_from_initialized"] < 1.2:
            result.update(
                status="rejected", reason="requires >20% volume change from initialized cell"
            )
        else:
            result["status"] = "tested"
        candidate.set_refinements({"Cell": False})
        project.save(str(branch / "trial.gpx"))
    except Exception as exc:
        result.update(status="unknown", reason=f"{type(exc).__name__}: {exc}")
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    records = json.loads((SOURCE / "provenance.json").read_text())
    results = []
    for record in records:
        result = run_one(record)
        results.append(result)
        print(
            result.get("model_id", result["cod_id"]),
            result["status"],
            result.get("rwp_scale_background_percent"),
            result.get("rwp_cell_percent"),
            result.get("volume_ratio_from_initialized"),
            result.get("reason", ""),
            flush=True,
        )
        (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
