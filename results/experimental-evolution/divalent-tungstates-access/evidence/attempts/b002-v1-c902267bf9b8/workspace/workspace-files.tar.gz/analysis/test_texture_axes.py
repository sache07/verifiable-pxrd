#!/usr/bin/env python3
"""Screen one March-Dollase term at a time on the stable two-phase model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "coordinate_trials" / "11_wo3_tungsten.gpx"
OUT = ROOT / "analysis" / "texture_trials"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def refinement_succeeded(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Sample Parameters"]["Shift"][1] = False
    hist.set_refinements({"Background": {"refine": True}})
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})


def run_one(phase_name: str, axis: list[int]) -> dict:
    label = phase_name.replace("_", "-") + "_" + "".join(map(str, axis))
    output = OUT / f"{label}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    prepare(project)
    hist = project.histogram(0)
    phase = project.phase(phase_name)
    pref = phase.data["Histograms"][hist.name]["Pref.Ori."]
    pref[0] = "MD"
    pref[1] = 1.0
    pref[2] = True
    pref[3] = list(axis)
    project.set_Controls("cycles", 12)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"phase": phase_name, "axis": axis, "output": str(output)}
    if not refinement_succeeded(project, output):
        result.update(status="unknown", reason="refinement did not complete cleanly")
        return result
    ratio = float(phase.data["Histograms"][hist.name]["Pref.Ori."][1])
    result.update(
        rwp_percent=hist.get_wR(),
        march_dollase_ratio=ratio,
        mass_fractions={
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    )
    if not 0.5 < ratio < 2.0:
        result.update(status="rejected", reason="texture ratio is outside broad physical limits")
    else:
        result["status"] = "tested"
    project.save(str(output))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for phase_name in ("MnWO4_wolframite", "WO3_2311041"):
        for axis in AXES:
            result = run_one(phase_name, list(axis))
            results.append(result)
            print(
                phase_name,
                axis,
                result["status"],
                result.get("rwp_percent"),
                result.get("march_dollase_ratio"),
                flush=True,
            )
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
