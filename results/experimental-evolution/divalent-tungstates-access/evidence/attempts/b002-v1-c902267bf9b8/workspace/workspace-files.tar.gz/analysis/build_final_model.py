#!/usr/bin/env python3
"""Conservatively replay the accepted three-phase model into a final project."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "final_coordinate_trials" / "05_wo3_O6.gpx"
OUT = ROOT / "analysis" / "finalization"
CANDIDATE = "Mn3WO62_4030285"


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project) -> None:
    # Uiso equivalences were used to obtain phase-wide values. All ADPs are
    # fixed for the final replay, so remove now-unused constraint records.
    constraints = project.data.get("Constraints", {}).get("data", {})
    constraints["Phase"] = []
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    # Roll back the later scale-correlated drift (A=0.724) to the stable
    # one-parameter roughness branch. Keep both values fixed thereafter.
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.4819252703655758, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.13136986289408417, False]
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    # Main-phase size had run to 10 um and its microstrain became negative
    # when U/W were revisited. Use the simpler physical rollback: size at the
    # generator upper bound and zero (inactive) microstrain.
    main = project.phase("MnWO4_wolframite")
    main_hap = main.data["Histograms"][hist.name]
    main_hap["Size"][1][0] = 1.5
    main_hap["Mustrain"][1][0] = 0.0
    project.phase("WO3_2311041").set_HAP_refinements(
        {"Mustrain": {"type": "isotropic", "refine": True}}
    )
    for name in ("WO3_2311041", CANDIDATE):
        project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][2] = True
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": size, "refine": True}}
    )


def cells_shift(project: G2sc.G2Project) -> None:
    project.histogram(0).data["Sample Parameters"]["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})


def instrument(*keys):
    def configure(project: G2sc.G2Project) -> None:
        project.histogram(0).set_refinements({"Instrument Parameters": list(keys)})

    return configure


def no_extra(project: G2sc.G2Project) -> None:
    return None


def physical(project: G2sc.G2Project) -> tuple[bool, str]:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    values = {key: float(inst[key][1]) for key in ("U", "V", "W", "X", "Y")}
    theta = np.radians(np.linspace(5.0, 50.0, 1000))
    gaussian = values["U"] * np.tan(theta) ** 2 + values["V"] * np.tan(theta) + values["W"]
    lorentzian = values["X"] / np.cos(theta) + values["Y"] * np.tan(theta)
    if np.min(gaussian) <= 0 or np.min(lorentzian) < 0:
        return False, "non-positive instrumental peak width"
    ranges = {
        "U": (0.0, 40.0),
        "W": (2.0, 40.0),
        "X": (0.1, 6.0),
        "SH/L": (0.005, 0.1),
        "Polariz.": (0.5, 1.0),
    }
    for key, (lower, upper) in ranges.items():
        value = float(inst[key][1])
        if not lower <= value <= upper:
            return False, f"{key}={value} outside generator range"
    sample = hist.data["Sample Parameters"]
    if not 0.05 <= float(sample["SurfRoughA"][0]) <= 0.6:
        return False, "surface roughness A outside generator range"
    if not 0.02 <= float(sample["SurfRoughB"][0]) <= 0.5:
        return False, "surface roughness B outside generator range"
    for phase in project.phases():
        if phase.HAPvalue("Scale", targethistlist=[hist]) <= 0:
            return False, f"non-positive phase scale for {phase.name}"
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    if not 0.04 <= size <= 1.5:
        return False, f"candidate size outside generator range: {size}"
    for name in ("MnWO4_wolframite", "WO3_2311041", CANDIDATE):
        hap = project.phase(name).data["Histograms"][hist.name]
        strain = float(hap["Mustrain"][1][0])
        if not 0 <= strain <= 8000:
            return False, f"microstrain outside generator range for {name}"
        size_value = float(hap["Size"][1][0])
        if not 0.04 <= size_value <= 1.5:
            return False, f"size outside generator range for {name}"
    for name in ("WO3_2311041", CANDIDATE):
        ratio = float(project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][1])
        if not 0.7 <= ratio <= 1.4:
            return False, f"texture outside generator range for {name}"
    arrays = np.asarray(hist.data["data"][1], float)
    limits = hist.data["Limits"][1]
    selected = (arrays[0] >= limits[0]) & (arrays[0] <= limits[1])
    if np.min(arrays[4, selected]) < 0:
        return False, "negative fitted background"
    return True, ""


def max_correlation(project: G2sc.G2Project) -> dict | None:
    data = project.data.get("Covariance", {}).get("data", {})
    names = data.get("varyList", [])
    cov = np.asarray(data.get("covMatrix", []), float)
    if cov.ndim != 2 or len(names) != len(cov) or len(names) < 2:
        return None
    sig = np.sqrt(np.maximum(np.diag(cov), 0))
    denom = np.outer(sig, sig)
    corr = np.divide(cov, denom, out=np.zeros_like(cov), where=denom > 0)
    np.fill_diagonal(corr, 0)
    index = np.unravel_index(np.argmax(np.abs(corr)), corr.shape)
    return {
        "variables": [names[index[0]], names[index[1]]],
        "correlation": float(corr[index]),
    }


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "rwp_percent": hist.get_wR(),
        "gof": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "max_parameter_correlation": max_correlation(project),
        "instrument": {
            key: float(inst[key][1])
            for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "sample": {
            key: float(sample[key][0])
            for key in ("Shift", "SurfRoughA", "SurfRoughB")
        },
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "microstrain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "march_ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "march_axis": list(phase.data["Histograms"][hist.name]["Pref.Ori."][3]),
            }
            for phase in project.phases()
        },
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }


def run(input_path: Path, label: str, configure, previous_rwp: float) -> tuple[Path | None, dict]:
    output = OUT / f"{label}.gpx"
    project = G2sc.G2Project(str(input_path), newgpx=str(output))
    prepare(project)
    configure(project)
    project.set_Controls("cycles", 30)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"stage": label, "input": str(input_path), "output": str(output)}
    if not success(project, output):
        result.update(status="unknown", reason="refinement failed or did not converge")
        return None, result
    result.update(summarize(project))
    valid, reason = physical(project)
    if not valid:
        result.update(status="unknown", reason=reason)
        return None, result
    if result["rwp_percent"] > previous_rwp + 0.002:
        result.update(status="rejected", reason="Rwp worsened relative to rollback model")
        return None, result
    result["status"] = "tested"
    project.save(str(output))
    return output, result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    current = BASE
    # The first replay deliberately replaces two nonphysical profile values,
    # so it is accepted on physical validity even if Rwp rises modestly.
    previous_rwp = 999.0
    results = []
    stages = (
        ("01_replay", no_extra),
        ("02_cells_shift", cells_shift),
        ("03_UW", instrument("U", "W")),
        ("04_X", instrument("X")),
        ("05_SHL", instrument("SH/L")),
        ("06_polarization", instrument("Polariz.")),
        ("07_replay", no_extra),
    )
    for label, configure in stages:
        output, result = run(current, label, configure, previous_rwp)
        results.append(result)
        print(
            label,
            result["status"],
            result.get("rwp_percent"),
            result.get("instrument"),
            result.get("reason", ""),
            flush=True,
        )
        if output is not None:
            current = output
            previous_rwp = result["rwp_percent"]
    final = G2sc.G2Project(str(current), newgpx=str(OUT / "accepted.gpx"))
    prepare(final)
    final.save(str(OUT / "accepted.gpx"))
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")
    (OUT / "accepted_source.txt").write_text(str(current) + "\n")


if __name__ == "__main__":
    main()
