#!/usr/bin/env python3
"""Refine one phase-wide isotropic ADP per phase with exact equivalence constraints."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "complete_nuisance_trials" / "05_cells_shift.gpx"
OUT = ROOT / "analysis" / "tied_uiso_trials"
CANDIDATE = "Mn3WO62_4030285"


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for name in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(name).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    for name in ("WO3_2311041", CANDIDATE):
        project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][2] = True
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": size, "refine": True}}
    )


def configure_tied_uiso(project: G2sc.G2Project, phase_name: str, output: Path) -> None:
    phases = project.phases()
    phase_index = next(i for i, phase in enumerate(phases) if phase.name == phase_name)
    phase = project.phase(phase_name)
    atoms = phase.atoms()
    # The source MnWO4 CIF carries anisotropic literature ADPs, while the
    # synthetic measurement model applies one isotropic specimen Uiso per
    # phase. Convert any source tensors explicitly before tying the values.
    isotropic_values = []
    for atom in atoms:
        if atom.adp_flag == "I":
            isotropic_values.append(float(atom.uiso))
        else:
            tensor = np.asarray(atom.ADP, float)
            isotropic_values.append(float(np.mean(tensor[:3])))
            atom.data[atom.cia] = "I"
    average = float(np.mean(isotropic_values))
    for atom in atoms:
        atom.uiso = average
        atom.refinement_flags = "U"
    project.save(str(output))
    variables = [f"{phase_index}::AUiso:{index}" for index in range(len(atoms))]
    if len(variables) > 1:
        project.add_EquivConstr(variables, reloadIdx=True)


def summarize(project: G2sc.G2Project, phase_name: str) -> dict:
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "rwp_percent": hist.get_wR(),
        "gof": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "phase_uiso_A2": {
            phase.name: [float(atom.uiso) for atom in phase.atoms()]
            for phase in project.phases()
        },
        "refined_phase_uiso_A2": float(project.phase(phase_name).atoms()[0].uiso),
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }


def run(input_path: Path, phase_name: str, index: int) -> tuple[Path | None, dict]:
    output = OUT / f"{index:02d}_{phase_name}.gpx"
    project = G2sc.G2Project(str(input_path), newgpx=str(output))
    prepare(project)
    configure_tied_uiso(project, phase_name, output)
    project.set_Controls("cycles", 20)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"phase": phase_name, "input": str(input_path), "output": str(output)}
    if not success(project, output):
        result.update(status="unknown", reason="refinement failed or did not converge")
        return None, result
    result.update(summarize(project, phase_name))
    value = result["refined_phase_uiso_A2"]
    if not 0.002 <= value <= 0.03:
        result.update(status="unknown", reason="phase-wide Uiso outside physical range")
        return None, result
    result["status"] = "tested"
    project.save(str(output))
    return output, result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    current = BASE
    results = []
    for index, phase_name in enumerate(
        ("MnWO4_wolframite", "WO3_2311041", CANDIDATE), 1
    ):
        output, result = run(current, phase_name, index)
        results.append(result)
        print(
            phase_name,
            result["status"],
            result.get("rwp_percent"),
            result.get("refined_phase_uiso_A2"),
            result.get("reason", ""),
            flush=True,
        )
        if output is not None:
            current = output
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
