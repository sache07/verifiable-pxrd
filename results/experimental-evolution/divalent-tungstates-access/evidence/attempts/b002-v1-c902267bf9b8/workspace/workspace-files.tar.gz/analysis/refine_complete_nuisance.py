#!/usr/bin/env python3
"""Revisit instrument/specimen nuisance terms after the phase inventory closes."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "roughness_trials" / "A_only.gpx"
OUT = ROOT / "analysis" / "complete_nuisance_trials"
CANDIDATE = "Mn3WO62_4030285"


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    hist.data["Sample Parameters"]["SurfRoughA"][1] = True
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for name in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(name).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    for name in ("WO3_2311041", CANDIDATE):
        project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][2] = True
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": size, "refine": True}}
    )


def instrument(*keys):
    def configure(project: G2sc.G2Project) -> None:
        project.histogram(0).set_refinements({"Instrument Parameters": list(keys)})

    return configure


def cells_shift(project: G2sc.G2Project) -> None:
    project.histogram(0).data["Sample Parameters"]["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})


def all_supported(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "X", "Polariz.", "SH/L"]}
    )
    hist.data["Sample Parameters"]["Shift"][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})


def physical(project: G2sc.G2Project) -> tuple[bool, str]:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    values = {key: float(inst[key][1]) for key in ("U", "V", "W", "X", "Y")}
    theta = np.radians(np.linspace(5.0, 50.0, 1000))
    gaussian = values["U"] * np.tan(theta) ** 2 + values["V"] * np.tan(theta) + values["W"]
    lorentzian = values["X"] / np.cos(theta) + values["Y"] * np.tan(theta)
    if np.min(gaussian) <= 0 or np.min(lorentzian) < 0:
        return False, "non-positive total instrumental peak width"
    if not 0 <= values["U"] <= 60 or not 0 < values["W"] <= 60 or not 0 < values["X"] <= 10:
        return False, "instrument profile outside broad physical bounds"
    if not 0.5 <= float(inst["Polariz."][1]) <= 1.0:
        return False, "polarization outside generator range"
    if not 0.005 <= float(inst["SH/L"][1]) <= 0.1:
        return False, "SH/L outside generator range"
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    if not 0.02 <= size <= 1.5:
        return False, "candidate size outside physical bounds"
    for name in ("WO3_2311041", CANDIDATE):
        ratio = float(project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][1])
        if not 0.7 <= ratio <= 1.4:
            return False, f"texture ratio outside generator range for {name}"
    return True, ""


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    inst = hist.data["Instrument Parameters"][0]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "rwp_percent": hist.get_wR(),
        "gof": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "instrument": {
            key: float(inst[key][1])
            for key in ("U", "V", "W", "X", "Y", "SH/L", "Polariz.")
        },
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "roughness_A": float(hist.data["Sample Parameters"]["SurfRoughA"][0]),
        "roughness_B": float(hist.data["Sample Parameters"]["SurfRoughB"][0]),
        "cells": {phase.name: phase.get_cell() for phase in project.phases()},
        "profiles": {
            phase.name: {
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "microstrain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "march_ratio": float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]),
                "march_axis": list(phase.data["Histograms"][hist.name]["Pref.Ori."][3]),
            }
            for phase in project.phases()
        },
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }


def run(input_path: Path, label: str, configure) -> tuple[Path | None, dict]:
    output = OUT / f"{label}.gpx"
    project = G2sc.G2Project(str(input_path), newgpx=str(output))
    prepare(project)
    configure(project)
    project.set_Controls("cycles", 20)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"stage": label, "input": str(input_path), "output": str(output)}
    if not success(project, output):
        result.update(status="unknown", reason="refinement failed or did not converge")
        return None, result
    result.update(summarize(project))
    valid, reason = physical(project)
    if not valid:
        result.update(status="unknown", reason=reason)
        return None, result
    result["status"] = "tested"
    project.save(str(output))
    return output, result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    current = BASE
    results = []
    stages = (
        ("01_UW", instrument("U", "W")),
        ("02_X", instrument("X")),
        ("03_polarization", instrument("Polariz.")),
        ("04_SHL", instrument("SH/L")),
        ("05_cells_shift", cells_shift),
        ("06_all_supported", all_supported),
    )
    for label, configure in stages:
        output, result = run(current, label, configure)
        results.append(result)
        print(
            label,
            result["status"],
            result.get("rwp_percent"),
            result.get("instrument"),
            result.get("reason", ""),
            flush=True,
        )
        if output is not None:
            current = output
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
