#!/usr/bin/env python3
"""Stage supported specimen/instrument terms after the stable structural model."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "texture_trials" / "WO3-2311041_111.gpx"
OUT = ROOT / "analysis" / "specimen_trials"


def success(project, expected):
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project):
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for key, value in hist.data["Sample Parameters"].items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    wo3_pref = project.phase("WO3_2311041").data["Histograms"][hist.name]["Pref.Ori."]
    wo3_pref[2] = True


def roughness(project):
    sample = project.histogram(0).data["Sample Parameters"]
    if sample["SurfRoughA"][0] == 0:
        sample["SurfRoughA"][0] = 0.2
    if sample["SurfRoughB"][0] == 0:
        sample["SurfRoughB"][0] = 0.1
    project.histogram(0).set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})


def polarization(project):
    project.histogram(0).set_refinements({"Instrument Parameters": ["Polariz."]})


def shl(project):
    project.histogram(0).set_refinements({"Instrument Parameters": ["SH/L"]})


def cell_shift(project):
    project.histogram(0).set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})


def summary(project):
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    inst = hist.data["Instrument Parameters"][0]
    return {
        "rwp_percent": hist.get_wR(),
        "shift_um": sample["Shift"][0],
        "surface_roughness_A": sample["SurfRoughA"][0],
        "surface_roughness_B": sample["SurfRoughB"][0],
        "polarization": inst["Polariz."][1],
        "SH_L": inst["SH/L"][1],
        "wo3_texture_ratio": project.phase("WO3_2311041").data["Histograms"][hist.name]["Pref.Ori."][1],
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }


def run_stage(input_path, label, configure):
    output = OUT / f"{label}.gpx"
    project = G2sc.G2Project(str(input_path), newgpx=str(output))
    prepare(project)
    configure(project)
    project.set_Controls("cycles", 15)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"stage": label, "output": str(output)}
    if not success(project, output):
        result.update(status="unknown", reason="refinement did not complete cleanly")
        return None, result
    result.update(summary(project))
    if not 0.0 <= result["surface_roughness_A"] <= 1.0 or not 0.0 <= result["surface_roughness_B"] <= 1.0:
        result.update(status="unknown", reason="surface roughness outside broad physical bounds")
        return None, result
    if not 0.5 <= result["polarization"] <= 1.0:
        result.update(status="unknown", reason="polarization outside stated laboratory range")
        return None, result
    if not 0.002 <= result["SH_L"] <= 0.2:
        result.update(status="unknown", reason="SH/L outside broad physical bounds")
        return None, result
    result["status"] = "tested"
    project.save(str(output))
    return output, result


def main():
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    current = BASE
    results = []
    for label, configure in [
        ("14_roughness", roughness),
        ("15_polarization", polarization),
        ("16_SHL", shl),
        ("17_cells_shift", cell_shift),
    ]:
        output, result = run_stage(current, label, configure)
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
        if output is not None:
            current = output
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
