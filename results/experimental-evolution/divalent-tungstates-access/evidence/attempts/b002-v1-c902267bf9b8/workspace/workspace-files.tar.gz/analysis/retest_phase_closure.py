#!/usr/bin/env python3
"""Test plausible fourth phases after closure of the substituted third phase."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "final_coordinate_trials" / "05_wo3_O6.gpx"
OUT = ROOT / "analysis" / "closure_trials"
CANDIDATE = "Mn3WO62_4030285"
EXISTING = ["MnWO4_wolframite", "WO3_2311041", CANDIDATE]
NORMALIZED = ROOT / "analysis" / "normalized_candidates"
PROTOTYPES = ROOT / "analysis" / "prototype_shortlist"

CANDIDATES = [
    ("MnO_hexagonal", NORMALIZED / "4117966.cif"),
    ("MnO_rocksalt", NORMALIZED / "1514108.cif"),
    ("MnO2_rutile", NORMALIZED / "1514110.cif"),
    ("Mn3O4_hausmannite", NORMALIZED / "9001963.cif"),
    ("Mn3O4_orthorhombic", NORMALIZED / "9001302.cif"),
    ("Mn2WO5_9000178_fourth", PROTOTYPES / "Mn2WO5_9000178.cif"),
    ("Mn2WO5_9011171_fourth", PROTOTYPES / "Mn2WO5_9011171.cif"),
    ("Mn3WO6_2242674_fourth", PROTOTYPES / "Mn3WO6_2242674.cif"),
    ("WO3_1528915_second", NORMALIZED / "1528915.cif"),
    ("WO3_1521532_tetragonal", NORMALIZED / "1521532.cif"),
]


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project):
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for name in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(name).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    for name in ("WO3_2311041", CANDIDATE):
        project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][2] = True
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": size, "refine": True}}
    )
    return hist


def stage(project: G2sc.G2Project, output: Path) -> bool:
    project.set_Controls("cycles", 20)
    project.do_refinements([{}], outputnames=[str(output)])
    return success(project, output)


def run(name: str, cif: Path) -> dict:
    branch = OUT / name
    branch.mkdir(parents=True, exist_ok=True)
    result = {"phase": name, "source_cif": str(cif)}
    try:
        project = G2sc.G2Project(str(BASE), newgpx=str(branch / "trial.gpx"))
        hist = prepare(project)
        phase = project.add_phase(
            str(cif), phasename=name, histograms=[hist], fmthint="CIF"
        )
        initial_cell = phase.get_cell()
        result["initial_cell"] = initial_cell
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
        phase.data["Histograms"][hist.name]["Scale"] = [0.1, True]
        active = [
            item.name
            for item in project.phases()
            if item.data["Histograms"][hist.name]["Use"]
        ]
        scales = {
            item.name: item.HAPvalue("Scale", targethistlist=[hist])
            for item in project.phases()
        }
        result["active_inventory"] = active
        result["initialized_scales"] = scales
        if active != EXISTING + [name] or any(scales[item] <= 0 for item in active):
            result.update(status="unknown", reason="invalid initialized inventory")
            return result

        output = branch / "scale_background.gpx"
        if not stage(project, output):
            result.update(status="unknown", reason="scale/background refinement failed")
            return result
        result["rwp_scale_background_percent"] = hist.get_wR()
        result["scale_after_scale_background"] = phase.HAPvalue(
            "Scale", targethistlist=[hist]
        )
        result["mass_fractions_scale_background"] = {
            phase_name: {"value": value, "sigma": sigma}
            for phase_name, (value, sigma) in hist.ComputeMassFracs().items()
        }
        if result["scale_after_scale_background"] <= 0:
            result.update(status="rejected", reason="scale collapsed non-positive")
            return result

        phase.set_refinements({"Cell": True})
        output = branch / "cell.gpx"
        if not stage(project, output):
            result.update(status="unknown", reason="cell refinement failed")
            return result
        result["rwp_cell_percent"] = hist.get_wR()
        result["refined_cell"] = phase.get_cell()
        result["volume_ratio"] = (
            result["refined_cell"]["volume"] / initial_cell["volume"]
        )
        result["mass_fractions"] = {
            phase_name: {"value": value, "sigma": sigma}
            for phase_name, (value, sigma) in hist.ComputeMassFracs().items()
        }
        fraction = result["mass_fractions"][name]["value"]
        if fraction < 0.003:
            result.update(status="rejected", reason="mass fraction collapsed below 0.3 wt%")
        elif not 0.8 <= result["volume_ratio"] <= 1.2:
            result.update(status="rejected", reason="requires >20% cell-volume change")
        else:
            result["status"] = "tested"
        phase.set_refinements({"Cell": False})
        project.save(str(branch / "trial.gpx"))
    except Exception as exc:
        result.update(status="unknown", reason=f"{type(exc).__name__}: {exc}")
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for name, cif in CANDIDATES:
        result = run(name, cif)
        results.append(result)
        print(
            name,
            result["status"],
            result.get("rwp_scale_background_percent"),
            result.get("rwp_cell_percent"),
            result.get("reason", ""),
            flush=True,
        )
        (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
