#!/usr/bin/env python3
"""Materialize a topology-diverse shortlist from the broad residual search."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parents[1]
SEARCH = ROOT / "analysis" / "prototype_search" / "coarse_ledger.json"
OUT = ROOT / "analysis" / "prototype_shortlist"

# Same-composition variants plus topology- and stoichiometry-diverse leaders.
SELECTION = [
    ("9015147", "Mn2WO5"),
    ("9000178", "Mn2WO5"),
    ("9011171", "Mn2WO5"),
    ("1524664", "Mn2WO5"),
    ("9015082", "Mn2WO5"),
    ("9016468", "Mn2WO5"),
    ("1528172", "Mn2WO5"),
    ("1531540", "Mn2WO5"),
    ("2242674", "Mn3WO6"),
    ("2211529", "Mn3WO6"),
    ("2015468", "Mn3WO6"),
    ("4345717", "Mn3WO6"),
    ("2211031", "Mn3WO6"),
    ("1563081", "Mn3WO6"),
    ("9008249", "Mn3(WO6)2"),
    ("4030285", "Mn3(WO6)2"),
    ("4124525", "Mn3(WO6)2"),
    ("1001855", "Mn3(WO6)2"),
    # Chemically economical reverse site assignments for the same frameworks:
    # W on tetrahedral phosphate/sulfate sites and Mn on the parent cation sites.
    ("4030285", "Mn2(WO4)3"),
    ("9008249", "Mn2(WO4)3"),
    ("4124525", "Mn2(WO4)3"),
    ("1001855", "Mn2(WO4)3"),
    ("2012343", "Mn4WO6"),
    ("2006774", "Mn4WO6"),
    ("2002344", "Mn4W2O9"),
    ("1008924", "Mn4W2O9"),
    ("2002359", "Mn4W2O9"),
]


def model_id(row: dict) -> str:
    safe_formula = (
        row["target_formula"]
        .replace("(", "")
        .replace(")", "")
        .replace("[", "")
        .replace("]", "")
    )
    return f"{safe_formula}_{row['cod_id']}"


def write_model(row: dict) -> dict:
    structure = CifParser(row["source"], occupancy_tolerance=1.0).parse_structures(
        primitive=False
    )[0]
    structure.remove_oxidation_states()
    structure.replace_species(row["substitutions"])
    original_cell = {
        "a": structure.lattice.a,
        "b": structure.lattice.b,
        "c": structure.lattice.c,
        "alpha": structure.lattice.alpha,
        "beta": structure.lattice.beta,
        "gamma": structure.lattice.gamma,
        "volume": structure.volume,
    }
    factor = row["uniform_cell_factor"]
    structure.scale_lattice(structure.volume * factor**3)
    writer = CifWriter(structure, symprec=0.001, significant_figures=10)
    uiso_tag = "_atom_site_U_iso_or_equiv"
    for block in writer.cif_file.data.values():
        block.data[uiso_tag] = ["0.0050000000"] * len(
            block.data["_atom_site_label"]
        )
        loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
        if uiso_tag not in loop:
            loop.append(uiso_tag)
    name = model_id(row)
    destination = OUT / f"{name}.cif"
    destination.write_text(str(writer) + "\n")
    distances = np.asarray(structure.distance_matrix, float)
    np.fill_diagonal(distances, np.inf)
    return {
        **row,
        "model_id": name,
        "cif": str(destination),
        "original_parent_cell": original_cell,
        "initialized_cell": {
            "a": structure.lattice.a,
            "b": structure.lattice.b,
            "c": structure.lattice.c,
            "alpha": structure.lattice.alpha,
            "beta": structure.lattice.beta,
            "gamma": structure.lattice.gamma,
            "volume": structure.volume,
        },
        "minimum_separation_after_scaling_A": float(np.min(distances)),
        "transformation": (
            "whole-element substitutions with all site multiplicities/topology "
            "preserved; isotropic cell initialization from coarse residual match; "
            "neutral elements; Uiso=0.005 A^2"
        ),
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    rows = json.loads(SEARCH.read_text())["results"]
    selected = []
    for cod_id, target in SELECTION:
        matches = [
            row
            for row in rows
            if row.get("cod_id") == cod_id
            and row.get("target_formula") == target
            and row.get("status") == "ranked"
        ]
        if len(matches) != 1:
            selected.append(
                {
                    "cod_id": cod_id,
                    "target_formula": target,
                    "status": "unknown",
                    "error": f"expected one coarse-search record, found {len(matches)}",
                }
            )
            continue
        try:
            selected.append(write_model(matches[0]))
        except Exception as exc:
            selected.append(
                {
                    **matches[0],
                    "status": "unknown",
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
    (OUT / "provenance.json").write_text(json.dumps(selected, indent=2) + "\n")
    for row in selected:
        print(
            row.get("model_id", row["cod_id"]),
            row.get("target_formula"),
            row.get("minimum_separation_after_scaling_A"),
            row.get("error", ""),
        )


if __name__ == "__main__":
    main()
