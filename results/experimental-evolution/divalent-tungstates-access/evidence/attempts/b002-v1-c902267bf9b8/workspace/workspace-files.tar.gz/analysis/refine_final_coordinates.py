#!/usr/bin/env python3
"""Replay limited coordinate groups after inventory and phase-wide Uiso closure."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "tied_uiso_trials" / "02_WO3_2311041.gpx"
OUT = ROOT / "analysis" / "final_coordinate_trials"
CANDIDATE = "Mn3WO62_4030285"


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for name in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(name).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    for name in ("WO3_2311041", CANDIDATE):
        project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][2] = True
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": size, "refine": True}}
    )


def group(phase_name: str, elements: set[str]):
    def configure(project: G2sc.G2Project) -> None:
        phase = project.phase(phase_name)
        refs = {
            atom.label: "X" for atom in phase.atoms() if atom.element in elements
        }
        phase.set_refinements({"Atoms": refs})

    return configure


def one_atom(phase_name: str, label: str):
    def configure(project: G2sc.G2Project) -> None:
        project.phase(phase_name).set_refinements({"Atoms": {label: "X"}})

    return configure


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "rwp_percent": hist.get_wR(),
        "gof": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
        "atoms": {
            phase.name: {
                atom.label: {
                    "element": atom.element,
                    "coordinates": list(atom.coordinates),
                }
                for atom in phase.atoms()
            }
            for phase in project.phases()
        },
    }


def run(input_path: Path, label: str, configure) -> tuple[Path | None, dict]:
    output = OUT / f"{label}.gpx"
    project = G2sc.G2Project(str(input_path), newgpx=str(output))
    prepare(project)
    configure(project)
    project.set_Controls("cycles", 20)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"stage": label, "input": str(input_path), "output": str(output)}
    if not success(project, output):
        result.update(status="unknown", reason="refinement failed or did not converge")
        return None, result
    result.update(summarize(project))
    result["status"] = "tested"
    project.save(str(output))
    for phase in project.phases():
        phase.export_CIF(str(OUT / f"{label}_{phase.name}.cif"))
    return output, result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    current = BASE
    sequential = (
        ("01_main_cations", group("MnWO4_wolframite", {"Mn", "W"})),
        ("02_main_oxygen", group("MnWO4_wolframite", {"O"})),
        ("03_wo3_W", group("WO3_2311041", {"W"})),
        ("04_candidate_W", group(CANDIDATE, {"W"})),
    )
    for label, configure in sequential:
        output, result = run(current, label, configure)
        results.append(result)
        print(label, result["status"], result.get("rwp_percent"), flush=True)
        if output is not None:
            current = output

    heavy_model = current
    oxygen_labels = [
        atom.label
        for atom in G2sc.G2Project(str(heavy_model)).phase("WO3_2311041").atoms()
        if atom.element == "O"
    ]
    for label in oxygen_labels:
        branch_label = f"05_wo3_{label}"
        _, result = run(heavy_model, branch_label, one_atom("WO3_2311041", label))
        results.append(result)
        print(branch_label, result["status"], result.get("rwp_percent"), flush=True)
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
