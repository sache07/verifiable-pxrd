#!/usr/bin/env python3
"""Compare supported isotropic profile terms for the selected third phase."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "prototype_trials" / "Mn3WO62_4030285" / "cell.gpx"
OUT = ROOT / "analysis" / "candidate_profile_trials"
CANDIDATE = "Mn3WO62_4030285"


def success(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for name in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(name).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    project.phase("WO3_2311041").data["Histograms"][hist.name]["Pref.Ori."][2] = True


def configure(project: G2sc.G2Project, mode: str) -> None:
    phase = project.phase(CANDIDATE)
    hist = project.histogram(0)
    if mode in ("size", "both"):
        value = float(phase.data["Histograms"][hist.name]["Size"][1][0])
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "value": value, "refine": True}}
        )
    if mode in ("mustrain", "both"):
        value = float(phase.data["Histograms"][hist.name]["Mustrain"][1][0])
        phase.data["Histograms"][hist.name]["Mustrain"][1][0] = value
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )


def summarize(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    phase = project.phase(CANDIDATE)
    hap = phase.data["Histograms"][hist.name]
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "rwp_percent": hist.get_wR(),
        "gof": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "size_um": float(hap["Size"][1][0]),
        "microstrain_ppm": float(hap["Mustrain"][1][0]),
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }


def run(mode: str) -> dict:
    output = OUT / f"{mode}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    prepare(project)
    configure(project, mode)
    project.set_Controls("cycles", 16)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"mode": mode, "input": str(BASE), "output": str(output)}
    if not success(project, output):
        result.update(status="unknown", reason="refinement failed or did not converge")
        return result
    result.update(summarize(project))
    if not 0.02 <= result["size_um"] <= 5.0:
        result.update(status="unknown", reason="candidate size is boundary-hitting")
    elif not 0 <= result["microstrain_ppm"] <= 20000:
        result.update(status="unknown", reason="candidate microstrain is invalid")
    else:
        result["status"] = "tested"
        project.save(str(output))
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for mode in ("size", "mustrain", "both"):
        result = run(mode)
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
