#!/usr/bin/env python3
"""Test the chemically conventional reverse assignments on identical topologies."""

from __future__ import annotations

import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "analysis"))

from test_prototype_shortlist import G2sc, run_one  # noqa: E402


def main() -> None:
    G2sc.SetPrintLevel("warn")
    source = ROOT / "analysis" / "prototype_shortlist" / "provenance.json"
    records = [
        row
        for row in json.loads(source.read_text())
        if row.get("target_formula") == "Mn2(WO4)3"
    ]
    results = []
    for record in records:
        result = run_one(record)
        results.append(result)
        print(
            result["model_id"],
            result["status"],
            result.get("rwp_scale_background_percent"),
            result.get("rwp_cell_percent"),
            result.get("reason", ""),
            flush=True,
        )
    destination = ROOT / "analysis" / "prototype_trials" / "reverse_ledger.json"
    destination.write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
