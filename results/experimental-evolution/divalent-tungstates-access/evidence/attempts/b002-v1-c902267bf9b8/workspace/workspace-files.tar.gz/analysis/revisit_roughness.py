#!/usr/bin/env python3
"""Compare zero-, one-, and two-parameter roughness models after phase closure."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "selected_texture_trials" / "candidate_001.gpx"
OUT = ROOT / "analysis" / "roughness_trials"
CANDIDATE = "Mn3WO62_4030285"


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for value in hist.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements(
            {"Size": True, "Mustrain": True, "Pref.Ori.": True}
        )
    for name in ("MnWO4_wolframite", "WO3_2311041"):
        project.phase(name).set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )
    for name in ("WO3_2311041", CANDIDATE):
        project.phase(name).data["Histograms"][hist.name]["Pref.Ori."][2] = True
    candidate = project.phase(CANDIDATE)
    size = float(candidate.data["Histograms"][hist.name]["Size"][1][0])
    candidate.set_HAP_refinements(
        {"Size": {"type": "isotropic", "value": size, "refine": True}}
    )


def correlation(project: G2sc.G2Project, first: str, second: str):
    data = project.data.get("Covariance", {}).get("data", {})
    names = data.get("varyList", [])
    if first not in names or second not in names:
        return None
    cov = np.asarray(data["covMatrix"], float)
    i, j = names.index(first), names.index(second)
    return float(cov[i, j] / np.sqrt(cov[i, i] * cov[j, j]))


def run(mode: str) -> dict:
    output = OUT / f"{mode}.gpx"
    project = G2sc.G2Project(str(BASE), newgpx=str(output))
    prepare(project)
    hist = project.histogram(0)
    sample = hist.data["Sample Parameters"]
    if mode == "none":
        sample["SurfRoughA"] = [1.0, False]
        sample["SurfRoughB"] = [0.0, False]
    elif mode == "A_only":
        sample["SurfRoughA"][1] = True
    elif mode == "B_only":
        sample["SurfRoughB"][1] = True
    elif mode == "both":
        sample["SurfRoughA"][1] = True
        sample["SurfRoughB"][1] = True
    else:
        raise ValueError(mode)
    project.set_Controls("cycles", 20)
    project.do_refinements([{}], outputnames=[str(output)])
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    result = {
        "mode": mode,
        "output": str(output),
        "converged": rvals.get("converged", False),
        "rwp_percent": hist.get_wR(),
        "gof": rvals.get("GOF"),
        "max_shift_over_sigma": rvals.get("Max shft/sig"),
        "roughness_A": float(sample["SurfRoughA"][0]),
        "roughness_B": float(sample["SurfRoughB"][0]),
        "A_B_correlation": correlation(
            project, ":0:SurfRoughA", ":0:SurfRoughB"
        ),
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
    }
    valid = bool(
        rvals.get("converged", False)
        and 0 <= result["roughness_A"] <= 1
        and 0 <= result["roughness_B"] <= 1
    )
    result["status"] = "tested" if valid else "unknown"
    if valid:
        project.save(str(output))
    else:
        result["reason"] = "nonconvergent or roughness outside physical range"
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    results = []
    for mode in ("none", "A_only", "B_only", "both"):
        result = run(mode)
        results.append(result)
        print(json.dumps(result, sort_keys=True), flush=True)
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
