#!/usr/bin/env python3
"""Screen all available WO3 structures from one stable GSAS-II project."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "onephase" / "stage2_shift_cell.gpx"
OUT = ROOT / "analysis" / "wo3_trials_v2"
NORMALIZED = ROOT / "analysis" / "normalized_candidates"
INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/index.json.gz"
)
CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cif_path(cod_id: str) -> Path:
    return NORMALIZED / f"{cod_id}.cif"


def candidate_rows() -> list[tuple[str, int]]:
    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    return [(cod_id, int(space_group)) for formula, cod_id, space_group, _ in index["O-W"] if formula == "WO3"]


def provenance() -> dict[str, dict]:
    records = json.loads((NORMALIZED / "provenance.json").read_text())
    return {record["cod_id"]: record for record in records}


def refinement_succeeded(project: G2sc.G2Project, expected_title: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    title = covariance.get("title")
    return bool(
        title
        and Path(title).resolve() == expected_title.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def valid_cell(cell: dict[str, float]) -> bool:
    lengths = np.array([cell["length_a"], cell["length_b"], cell["length_c"]])
    angles = np.array([cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"]])
    return bool(
        np.all(np.isfinite(lengths))
        and np.all((lengths > 1.5) & (lengths < 40.0))
        and np.all(np.isfinite(angles))
        and np.all((angles > 20.0) & (angles < 160.0))
        and np.isfinite(cell["volume"])
        and cell["volume"] > 10.0
    )


def prepare_common(project: G2sc.G2Project) -> tuple[G2sc.G2PwdrData, G2sc.G2Phase]:
    hist = project.histogram(0)
    main = project.phase("MnWO4_wolframite")
    # Remove the redundant histogram scale/phase scale product from the original
    # branch while preserving its calculated intensity.
    old_hist_scale = float(hist.data["Sample Parameters"]["Scale"][0])
    old_phase_scale = float(main.data["Histograms"][hist.name]["Scale"][0])
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    main.data["Histograms"][hist.name]["Scale"] = [old_hist_scale * old_phase_scale, True]
    hist.data["Sample Parameters"]["Shift"][1] = False
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    main.set_refinements({"Cell": False})
    main.set_HAP_refinements({"Scale": True, "Use": True})
    hist.set_refinements({"Background": {"refine": True}})
    return hist, main


def run_one(cod_id: str, space_group: int, source_record: dict) -> dict:
    branch = OUT / cod_id
    branch.mkdir(parents=True, exist_ok=True)
    result: dict = {
        "composition": "WO3",
        "cod_id": cod_id,
        "space_group_number_index": space_group,
        "status": "pending",
        "source_cif": str(cif_path(cod_id)),
        "source_geometry": source_record,
    }
    if source_record["minimum_separation_A"] < 0.8:
        result["status"] = "rejected"
        result["reason"] = "normalized source has an interatomic contact below 0.8 A"
        return result
    try:
        project = G2sc.G2Project(str(BASE), newgpx=str(branch / "trial.gpx"))
        hist, main = prepare_common(project)
        candidate = project.add_phase(
            str(cif_path(cod_id)),
            phasename=f"WO3_{cod_id}",
            histograms=[hist],
            fmthint="CIF",
        )
        candidate.data["Histograms"][hist.name]["Scale"] = [10.0, True]
        candidate.set_HAP_refinements({"Scale": True, "Use": True})
        candidate.set_refinements({"Cell": False})
        # Verify the intended two-phase inventory before each fit.
        active = [p.name for p in project.phases() if p.data["Histograms"][hist.name]["Use"]]
        if active != [main.name, candidate.name]:
            raise RuntimeError(f"unexpected active inventory: {active}")
        if any(p.HAPvalue("Scale", targethistlist=[hist]) <= 0 for p in (main, candidate)):
            raise RuntimeError("non-positive initialized scale")

        project.set_Controls("cycles", 8)
        scale_output = branch / "scale_background.gpx"
        project.do_refinements([{}], outputnames=[str(scale_output)])
        if not refinement_succeeded(project, scale_output):
            result["status"] = "unknown"
            result["reason"] = "scale/background refinement did not complete cleanly"
            return result
        result["rwp_scale_background_percent"] = hist.get_wR()
        result["scale_after_scale_background"] = candidate.HAPvalue("Scale", targethistlist=[hist])
        if result["scale_after_scale_background"] <= 0:
            result["status"] = "rejected"
            result["reason"] = "candidate scale collapsed to a non-positive value"
            project.save(str(branch / "trial.gpx"))
            return result

        candidate.set_refinements({"Cell": True})
        cell_output = branch / "cell.gpx"
        project.do_refinements([{}], outputnames=[str(cell_output)])
        if not refinement_succeeded(project, cell_output):
            result["status"] = "unknown"
            result["reason"] = "cell refinement did not complete cleanly"
            return result
        cell = candidate.get_cell()
        result["rwp_cell_percent"] = hist.get_wR()
        result["candidate_cell"] = cell
        result["main_cell"] = main.get_cell()
        result["candidate_scale"] = candidate.HAPvalue("Scale", targethistlist=[hist])
        result["mass_fractions"] = {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        }
        if not valid_cell(cell) or result["candidate_scale"] <= 0:
            result["status"] = "unknown"
            result["reason"] = "cell refinement diverged or scale became non-positive"
        else:
            result["status"] = "tested"
        project.save(str(branch / "trial.gpx"))
    except Exception as exc:
        result["status"] = "unknown"
        result["reason"] = f"trial failed: {type(exc).__name__}: {exc}"
    return result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    source_records = provenance()
    results = []
    for cod_id, space_group in candidate_rows():
        row = run_one(cod_id, space_group, source_records[cod_id])
        results.append(row)
        print(json.dumps(row, sort_keys=True))
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
