#!/usr/bin/env python3
"""Normalize selected COD structures for comparable GSAS-II screening."""

from __future__ import annotations

import gzip
import json
from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "analysis" / "normalized_candidates"
INDEX = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/index.json.gz"
)
CIF_ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def source_path(cod_id: str) -> Path:
    return CIF_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_normalized(cod_id: str) -> dict:
    source = source_path(cod_id)
    structure = CifParser(source, occupancy_tolerance=1.0).parse_structures(primitive=False)[0]
    structure.remove_oxidation_states()
    for index, site in enumerate(structure):
        site.label = f"{site.species_string}{index}"
    writer = CifWriter(structure, symprec=0.001, significant_figures=10)
    uiso_tag = "_atom_site_U_iso_or_equiv"
    for block in writer.cif_file.data.values():
        block.data[uiso_tag] = ["0.0050000000"] * len(block.data["_atom_site_label"])
        loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
        if uiso_tag not in loop:
            loop.append(uiso_tag)
    destination = OUT / f"{cod_id}.cif"
    destination.write_text(str(writer) + "\n")
    distances = structure.distance_matrix.copy()
    distances[distances == 0] = float("inf")
    return {
        "cod_id": cod_id,
        "source": str(source),
        "normalized": str(destination),
        "formula": structure.composition.reduced_formula,
        "space_group": structure.get_space_group_info(symprec=0.001),
        "sites_conventional": len(structure),
        "density_g_cm3": structure.density,
        "minimum_separation_A": float(distances.min()),
        "transformation": "neutral elements; symmetry regenerated at 0.001 A; all Uiso set to 0.005 A^2",
    }


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    with gzip.open(INDEX, "rt") as handle:
        index = json.load(handle)
    ids = ["1520200"]
    ids.extend(cod_id for formula, cod_id, _, _ in index["O-W"])
    plausible_manganese_oxides = {"MnO", "Mn2O3", "Mn3O4", "MnO2"}
    ids.extend(
        cod_id
        for formula, cod_id, _, _ in index["Mn-O"]
        if formula in plausible_manganese_oxides
    )
    records = []
    for cod_id in dict.fromkeys(ids):
        try:
            records.append(write_normalized(cod_id))
        except Exception as exc:
            records.append(
                {
                    "cod_id": cod_id,
                    "source": str(source_path(cod_id)),
                    "error": f"{type(exc).__name__}: {exc}",
                }
            )
    (OUT / "provenance.json").write_text(json.dumps(records, indent=2) + "\n")
    print(json.dumps(records, indent=2))


if __name__ == "__main__":
    main()
