#!/usr/bin/env python3
"""Refine cells, common displacement and limited coordinate groups in stages."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2sc


ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "analysis" / "profile_trials" / "07_mustrain_both.gpx"
OUT = ROOT / "analysis" / "coordinate_trials"


def refinement_succeeded(project: G2sc.G2Project, expected: Path) -> bool:
    covariance = project.data.get("Covariance", {}).get("data", {})
    rvals = covariance.get("Rvals", {})
    return bool(
        covariance.get("title")
        and Path(covariance["title"]).resolve() == expected.resolve()
        and rvals.get("converged", False)
        and np.isfinite(rvals.get("Rwp", np.nan))
        and "error" not in str(rvals.get("msg", "")).lower()
    )


def prepare(project: G2sc.G2Project) -> None:
    hist = project.histogram(0)
    hist.data["Sample Parameters"]["Scale"][1] = False
    hist.data["Sample Parameters"]["Shift"][1] = False
    hist.set_refinements({"Background": {"refine": True}})
    for key in ("U", "V", "W", "X", "Y", "Z", "SH/L"):
        if key in hist.data["Instrument Parameters"][0]:
            hist.data["Instrument Parameters"][0][key][2] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        phase.set_HAP_refinements({"Scale": True, "Use": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}
        )


def summary(project: G2sc.G2Project) -> dict:
    hist = project.histogram(0)
    return {
        "rwp_percent": hist.get_wR(),
        "shift_um": float(hist.data["Sample Parameters"]["Shift"][0]),
        "mass_fractions": {
            name: {"value": value, "sigma": sigma}
            for name, (value, sigma) in hist.ComputeMassFracs().items()
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "atoms": {
                    atom.label: {
                        "element": atom.element,
                        "coordinates": list(atom.coordinates),
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                },
                "microstrain_ppm": phase.data["Histograms"][hist.name]["Mustrain"][1][0],
            }
            for phase in project.phases()
        },
    }


def cells_shift(project: G2sc.G2Project) -> None:
    project.histogram(0).set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_refinements({"Cell": True})


def atoms(phase_name: str, elements: set[str]):
    def configure(project: G2sc.G2Project) -> None:
        phase = project.phase(phase_name)
        refs = {atom.label: "X" for atom in phase.atoms() if atom.element in elements}
        phase.set_refinements({"Atoms": refs})
    return configure


def run_stage(input_path: Path, label: str, configure) -> tuple[Path | None, dict]:
    output = OUT / f"{label}.gpx"
    project = G2sc.G2Project(str(input_path), newgpx=str(output))
    prepare(project)
    configure(project)
    project.set_Controls("cycles", 12)
    project.do_refinements([{}], outputnames=[str(output)])
    result = {"stage": label, "input": str(input_path), "output": str(output)}
    if not refinement_succeeded(project, output):
        result.update(status="unknown", reason="refinement did not complete cleanly")
        return None, result
    result.update(summary(project))
    result["status"] = "tested"
    project.save(str(output))
    return output, result


def main() -> None:
    G2sc.SetPrintLevel("warn")
    OUT.mkdir(parents=True, exist_ok=True)
    current = BASE
    results = []
    stages = [
        ("08_cells_shift", cells_shift),
        ("09_main_cations", atoms("MnWO4_wolframite", {"Mn", "W"})),
        ("10_main_oxygen", atoms("MnWO4_wolframite", {"O"})),
        ("11_wo3_tungsten", atoms("WO3_2311041", {"W"})),
        ("12_wo3_oxygen", atoms("WO3_2311041", {"O"})),
        ("13_cells_shift_replay", cells_shift),
    ]
    for label, configure in stages:
        output, result = run_stage(current, label, configure)
        results.append(result)
        print(
            label,
            result["status"],
            result.get("rwp_percent"),
            result.get("shift_um"),
            result.get("reason", ""),
            flush=True,
        )
        if output is not None:
            current = output
    (OUT / "ledger.json").write_text(json.dumps(results, indent=2) + "\n")


if __name__ == "__main__":
    main()
