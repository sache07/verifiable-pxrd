#!/usr/bin/env python3
"""Create charge-balanced MnWO4 analogues from A(I)B(III)(WO4)2 parents."""

from __future__ import annotations

from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / ".tmp" / "double_tungstate_models"

# Scale estimates are only starting values from residual-profile matching.
MODELS = {
    "1524299": ("kin", 1.075),
    "2014857": ("rbgd", 0.970),
    "2002400": ("smtl", 0.965),
    "2300442": ("kgd", 0.980),
    "1528708": ("keu", 0.975),
    "2300099": ("kyb", 0.985),
    "4505086": ("klu", 0.990),
    "1527647": ("nain", 1.025),
}


def source(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for cod_id, (tag, scale) in MODELS.items():
        structure = CifParser(source(cod_id), occupancy_tolerance=10).parse_structures(
            primitive=False
        )[0]
        substitutions = {el: "Mn" for el in structure.composition.elements
                         if el.symbol not in {"W", "O"}}
        structure.replace_species(substitutions)
        structure.scale_lattice(structure.volume * scale ** 3)
        destination = OUT / f"mnwo4_double_{tag}_{cod_id}.cif"
        CifWriter(structure, symprec=0.01, significant_figures=10).write_file(destination)
        print(destination)


if __name__ == "__main__":
    main()
