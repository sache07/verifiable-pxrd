#!/usr/bin/env python3
"""Controlled, bounded GSAS-II refinements for candidate phase models."""

from __future__ import annotations

import argparse
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cif_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def inputs(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    xye = work / "pattern.xye"
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as fp, xye.open("w") as out:
        out.write("# two_theta intensity sigma\n")
        for row in csv.DictReader(fp):
            x, y = float(row["two_theta_deg"]), float(row["intensity"])
            out.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1)):.8f}\n")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:5.0;V:0.0;W:30.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def direct_rwp(project: G2.G2Project) -> float:
    hist = project.histogram(0)
    x, y, w, yc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return float(100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) /
                               np.sum(w[use] * y[use] ** 2)))


def checkpoint(project: G2.G2Project, work: Path, label: str, refine: bool = True) -> dict:
    if refine:
        project.refine(printFile=str(work / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, work / f"{label}.gpx")
    hist = project.histogram(0)
    info = {"label": label, "rwp": direct_rwp(project),
            "residuals": hist.residuals,
            "zero": hist.InstrumentParameters["Zero"],
            "instrument": {k: hist.InstrumentParameters[k] for k in
                           ["Polariz.", "U", "V", "W", "X", "Y", "SH/L"]},
            "sample": {k: hist.SampleParameters.get(k) for k in
                       ["Shift", "SurfRoughA", "SurfRoughB"]},
            "phases": []}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        info["phases"].append({"name": phase.name, "cell": phase.get_cell(),
                               "scale": hap["Scale"], "size": hap["Size"],
                               "mustrain": hap["Mustrain"], "po": hap["Pref.Ori."]})
    print(f"{label:24s} Rwp={info['rwp']:.5f}")
    return info


def set_limits(project: G2.G2Project, nphases: int) -> None:
    bounds = {
        ":0:Zero": (-0.30, 0.30), ":0:U": (0.0, 60.0), ":0:W": (0.1, 60.0),
        ":0:X": (0.01, 10.0), ":0:SH/L": (0.002, 0.20),
        ":0:Polariz.": (0.50, 1.0), ":0:Shift": (-800.0, 800.0),
        ":0:SurfRoughA": (0.001, 0.90), ":0:SurfRoughB": (0.001, 1.0),
    }
    for i in range(nphases):
        bounds[f"{i}:0:Scale"] = (1e-8, 1000.0)
        bounds[f"{i}:0:Size;i"] = (0.03, 3.0)
        bounds[f"{i}:0:Mustrain;i"] = (0.0, 20000.0)
        bounds[f"{i}:0:Mustrain;a"] = (0.0, 20000.0)
        bounds[f"{i}:0:MD"] = (0.5, 1.5)
    for variable, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--wo3", default="1528915")
    ap.add_argument("--wo-axis", default="001", choices=["001", "100", "010"])
    ap.add_argument("--tag", required=True)
    args = ap.parse_args()
    axis = [int(c) for c in args.wo_axis]
    work = ROOT / ".tmp" / "bounded" / args.tag
    xye, inst = inputs(work)
    project = G2.G2Project(newgpx=str(work / "model.gpx"))
    mnw = project.add_phase(str(cif_path("1520200")), phasename="MnWO4", fmthint="CIF")
    wo = project.add_phase(str(cif_path(args.wo3)), phasename="WO3", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(inst), phases=[mnw, wo], fmthint="xye")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 12,
                                          "coeffs": [1500.0] + [0.0] * 11,
                                          "refine": True}})
    mnw_hap = mnw.data["Histograms"][hist.name]
    wo_hap = wo.data["Histograms"][hist.name]
    mnw_hap["Scale"] = [110.0, True]
    wo_hap["Scale"] = [14.0, True]
    mnw.setSampleProfile(hist, "size", "isotropic", 1.0)
    mnw.setSampleProfile(hist, "microstrain", "isotropic", 300.0)
    wo.setSampleProfile(hist, "size", "isotropic", 0.12)
    wo.setSampleProfile(hist, "microstrain", "uniaxial", 3500.0, 7000.0, axis)
    project.set_Controls("cycles", 8)
    project.save()
    set_limits(project, 2)

    history = [checkpoint(project, work, "00_initial", refine=False)]
    history.append(checkpoint(project, work, "01_scale_bg"))
    history.append(checkpoint(project, work, "02_scale_bg"))
    for phase in [mnw, wo]:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    history.append(checkpoint(project, work, "03_cell_zero"))
    history.append(checkpoint(project, work, "04_cell_zero"))

    hist.set_refinements({"Instrument Parameters": ["W"]})
    history.append(checkpoint(project, work, "05_common_W"))
    hist.set_refinements({"Instrument Parameters": ["U", "X"]})
    history.append(checkpoint(project, work, "06_common_profile"))

    wo.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    history.append(checkpoint(project, work, "07_wo_size"))
    wo.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True,
                                          "direction": axis}})
    history.append(checkpoint(project, work, "08_wo_strain"))
    history.append(checkpoint(project, work, "09_wo_strain"))

    (work / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    data = hist.data["data"][1]
    np.savez_compressed(work / "profile.npz", **{k: np.asarray(v, float) for k, v in
                         zip(["x", "y", "w", "yc", "yb", "yd"], data[:6])})
    print(json.dumps(history[-1], indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
