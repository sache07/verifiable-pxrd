#!/usr/bin/env python3
"""Test one March-Dollase preferred-orientation axis in an existing project."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def rwp(project: G2.G2Project) -> float:
    hist = project.histogram(0)
    x, y, w, yc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return float(100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) /
                               np.sum(w[use] * y[use] ** 2)))


def checkpoint(project: G2.G2Project, work: Path, label: str) -> dict:
    project.refine(printFile=str(work / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, work / f"{label}.gpx")
    hist = project.histogram(0)
    row = {"label": label, "rwp": rwp(project), "phases": []}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"].append({"name": phase.name, "scale": hap["Scale"],
                              "po": hap["Pref.Ori."]})
    print(label, row["rwp"], [(p["name"], p["scale"][0], p["po"][:4])
                               for p in row["phases"]])
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("tag")
    ap.add_argument("phase_index", type=int)
    ap.add_argument("axis", choices=["100", "010", "001", "110", "111"])
    args = ap.parse_args()
    axis = [int(v) for v in args.axis]
    work = ROOT / ".tmp" / "po_tests" / f"{args.tag}_p{args.phase_index}_{args.axis}"
    work.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.base, work / "model.gpx")
    project = G2.G2Project(gpxfile=str(work / "model.gpx"))
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
                            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    phase = project.phase(args.phase_index)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    project.set_Controls("cycles", 12)
    project.set_Controls("parmMin", 0.7, variable=f"{args.phase_index}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{args.phase_index}:0:MD")
    history = [checkpoint(project, work, "01_po"), checkpoint(project, work, "02_po")]
    (work / "history.json").write_text(json.dumps(history, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
