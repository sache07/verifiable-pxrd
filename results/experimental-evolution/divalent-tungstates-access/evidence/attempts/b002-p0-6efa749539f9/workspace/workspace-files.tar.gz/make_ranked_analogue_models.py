#!/usr/bin/env python3
"""Create selected Mn-W-O analogue models from the transformed-library ranking."""

from __future__ import annotations

from pathlib import Path

from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / ".tmp" / "ranked_analogue_models"
MODELS = {
    "9016339": ("mn232w026o4_pmmm", 1.140),
    "1001055": ("mn232w026o5_pmmm", 1.140),
    "1533878": ("mn3w2o9_r167", 0.875),
    "1541070": ("mn2wo6_p212121", 0.965),
    "2310464": ("mn2wo6_pbnm", 0.890),
    "1530909": ("mn2wo6_p42mnm", 0.970),
    "5910088": ("mnwo4_sg88", 0.905),
    "1001175": ("mn5wo9_p63mmc", 0.890),
    "1551090": ("mnwo5_p21c", 0.975),
    "1535960": ("mnwo4_p3m1", 1.060),
    "1563543": ("mn3wo6_pnma", 0.965),
    "1541623": ("mn3wo6_fm3m", 0.910),
    "2311977": ("mn3w2o9_c2c", 0.915),
}


def source(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for cod_id, (tag, scale) in MODELS.items():
        structure = CifParser(source(cod_id), occupancy_tolerance=10).parse_structures(
            primitive=False
        )[0]
        structure.replace_species({el: "Mn" for el in structure.composition.elements
                                   if el.symbol not in {"W", "O"}})
        structure.scale_lattice(structure.volume * scale ** 3)
        destination = OUT / f"{tag}_{cod_id}.cif"
        CifWriter(structure, symprec=0.01, significant_figures=10).write_file(destination)
        print(destination)


if __name__ == "__main__":
    main()
