#!/usr/bin/env python3
"""Run staged, bounded refinement experiments for the selected four-phase model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
DEFAULT_BASE = ROOT / ".tmp" / "fourth_tests" / "mn2po010_mno" / "05_strain.gpx"
MNWO4_COORDS = [
    (0.5, 0.6886184941383179, 0.25),
    (0.0, 0.17766391784299873, 0.25),
    (0.22429677480964016, 0.1070488766634665, 0.934835910704347),
    (0.2562625088814075, 0.37967434510397485, 0.3899002518387485),
]


def metrics(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    x, y, w, yc, yb = (np.asarray(v, float) for v in hist.data["data"][1][:5])
    use = (x >= hist.data["Limits"][1][0]) & (x <= hist.data["Limits"][1][1])
    return {
        "rwp_native": float(100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) /
                                          np.sum(w[use] * y[use] ** 2))),
        "rwp_score_saved": float(100 * np.sqrt(np.sum((y - yc) ** 2 / np.maximum(y, 1.0)) /
                                               np.sum(y ** 2 / np.maximum(y, 1.0)))),
        "min_calc": float(np.min(yc)),
        "min_background": float(np.min(yb)),
    }


def set_isotropic_adp(phase: G2.G2Phase, value: float) -> None:
    for atom in phase.atoms():
        atom.data[atom.cia] = "I"
        atom.data[atom.cia + 1] = float(value)
        atom.data[atom.cia + 2:atom.cia + 8] = [0.0] * 6


def clear_all(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})


def bounds(project: G2.G2Project) -> None:
    ranges = {
        ":0:Zero": (-0.25, 0.25), ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0), ":0:SH/L": (0.005, 0.1), ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0), ":0:SurfRoughA": (0.0, 0.6),
        ":0:SurfRoughB": (0.0, 0.5),
    }
    for phase in project.phases():
        pid = phase.data["pId"]
        ranges[f"{pid}:0:Scale"] = (1e-8, 1000.0)
        ranges[f"{pid}:0:Size;i"] = (0.04, 1.5)
        ranges[f"{pid}:0:Size;a"] = (0.04, 1.5)
        ranges[f"{pid}:0:Mustrain;i"] = (0.0, 8000.0)
        ranges[f"{pid}:0:Mustrain;a"] = (0.0, 32000.0)
        ranges[f"{pid}:0:MD"] = (0.7, 1.4)
        for index, _ in enumerate(phase.atoms()):
            ranges[f"{pid}::AUiso:{index}"] = (0.003, 0.02)
    for variable, (lo, hi) in ranges.items():
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)


def checkpoint(project: G2.G2Project, folder: Path, label: str) -> dict:
    project.refine(printFile=str(folder / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, folder / f"{label}.gpx")
    row = {"label": label, **metrics(project), "residuals": project.histogram(0).residuals,
           "fractions": project.histogram(0).ComputeMassFracs()}
    print(label, row["rwp_native"], row["rwp_score_saved"], flush=True)
    return row


def initialize(base: Path, folder: Path, mn_coords: bool, u_values: list[float] | None) -> G2.G2Project:
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / "model.gpx"
    shutil.copy2(base, target)
    project = G2.G2Project(gpxfile=str(target))
    clear_all(project)
    bounds(project)
    project.set_Controls("cycles", 12)
    hist = project.histogram(0)
    hist.set_refinements({"Limits": hist.data["Limits"][0]})
    if mn_coords:
        for atom, xyz in zip(project.phase(0).atoms(), MNWO4_COORDS):
            atom.coordinates = xyz
    if u_values is not None:
        for phase, value in zip(project.phases(), u_values):
            set_isotropic_adp(phase, value)
    # Restore the audited lower profile bound inherited as 0.01 in the exploratory fit.
    hist.data["Instrument Parameters"][0]["X"][1] = max(
        0.1, hist.data["Instrument Parameters"][0]["X"][1])
    project.set_Frozen()
    project.save()
    return project


def run_initial(args: argparse.Namespace) -> None:
    root = ROOT / ".tmp" / "final_experiments" / args.tag
    cases = {
        "source_adp_source_xyz": (False, None),
        "source_adp_refined_xyz": (True, None),
        "u008_source_xyz": (False, [0.008] * 4),
        "u008_refined_xyz": (True, [0.008] * 4),
    }
    summary = []
    for name, (coords, uvals) in cases.items():
        if args.case and name != args.case:
            continue
        folder = root / name
        project = initialize(args.base, folder, coords, uvals)
        rows = [checkpoint(project, folder, "01_scale"), checkpoint(project, folder, "02_scale")]
        (folder / "history.json").write_text(json.dumps(rows, indent=2) + "\n")
        summary.append({"case": name, **rows[-1]})
    (root / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")


def run_coordinates(args: argparse.Namespace) -> None:
    root = ROOT / ".tmp" / "final_experiments" / args.tag
    for start_refined in (False, True):
        name = "coords_from_refined" if start_refined else "coords_from_source"
        if args.case and name != args.case:
            continue
        folder = root / name
        project = initialize(args.base, folder, start_refined, None)
        phase = project.phase(0)
        phase.set_refinements({"Atoms": {"all": "X"}})
        rows = [checkpoint(project, folder, "01_coordinates"),
                checkpoint(project, folder, "02_coordinates")]
        phase.clear_refinements({"Atoms": [atom.label for atom in phase.atoms()]})
        rows.append(checkpoint(project, folder, "03_fixed"))
        (folder / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_phase_atoms(args: argparse.Namespace) -> None:
    choices = {
        "wo3_w": (1, ["W1", "W2"]),
        "wo3_o": (1, ["O1", "O2", "O3", "O4", "O5", "O6"]),
        "wo3_all": (1, None),
        "mn2wo6_w": (2, ["W2"]),
        "mn2wo6_heavy": (2, ["Mn0", "Mn1", "W2"]),
        "mn2wo6_all": (2, None),
    }
    selected = [args.case] if args.case else list(choices)
    root = ROOT / ".tmp" / "final_experiments" / args.tag
    for name in selected:
        phase_index, labels = choices[name]
        folder = root / name
        project = initialize(args.base, folder, False, None)
        phase = project.phase(phase_index)
        labels = labels or [atom.label for atom in phase.atoms()]
        phase.set_refinements({"Atoms": {label: "X" for label in labels}})
        rows = [checkpoint(project, folder, "01_coordinates"),
                checkpoint(project, folder, "02_coordinates")]
        phase.clear_refinements({"Atoms": labels})
        rows.append(checkpoint(project, folder, "03_fixed"))
        (folder / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


def clamp_profiles(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][1][0] = float(np.clip(hap["Size"][1][0], 0.04, 1.5))
        hap["Size"][1][1] = float(np.clip(hap["Size"][1][1], 0.04, 1.5))
        hap["Mustrain"][1][0] = float(np.clip(hap["Mustrain"][1][0], 0.0, 8000.0))
        hap["Mustrain"][1][1] = float(np.clip(hap["Mustrain"][1][1], 0.0, 32000.0))
    project.set_Frozen()


def run_profile(args: argparse.Namespace) -> None:
    cases = args.case.split(",") if args.case else ["instrument", "phases", "joint"]
    root = ROOT / ".tmp" / "final_experiments" / args.tag
    for name in cases:
        folder = root / name
        project = initialize(args.base, folder, False, None)
        clamp_profiles(project)
        hist = project.histogram(0)
        selected = []
        if name in {"instrument", "joint"}:
            hist.set_refinements({"Instrument Parameters": ["U", "W", "X"]})
        if name in {"phases", "joint"}:
            selected = list(range(len(project.phases())))
        elif name.startswith("p") and name[1:].isdigit():
            selected = [int(name[1:])]
        for index in selected:
            phase = project.phase(index)
            hap = phase.data["Histograms"][hist.name]
            phase.set_HAP_refinements({
                "Size": {"type": hap["Size"][0], "refine": True},
                "Mustrain": {"type": hap["Mustrain"][0], "refine": True},
            })
        project.save()
        rows = [checkpoint(project, folder, f"0{i}_profile") for i in range(1, 4)]
        hist.clear_refinements({"Instrument Parameters": ["U", "W", "X"]})
        for phase in project.phases():
            phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        project.set_Frozen()
        rows.append(checkpoint(project, folder, "04_fixed"))
        (folder / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_one_parameter(args: argparse.Namespace) -> None:
    if not args.case:
        raise ValueError("--case is required for one-parameter mode")
    name = args.case
    folder = ROOT / ".tmp" / "final_experiments" / args.tag / name
    project = initialize(args.base, folder, False, None)
    hist = project.histogram(0)
    if len(name) > 1 and name[0] == "p" and name[1].isdigit():
        phase_index = int(name[1])
        quantity = name.split("_", 1)[1]
        phase = project.phase(phase_index)
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        if quantity == "size":
            project.set_Controls("parmMin", 0.02, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMax", 10.0, variable=f"{pid}:0:Size;i")
            project.set_Controls("parmMin", 0.02, variable=f"{pid}:0:Size;a")
            project.set_Controls("parmMax", 10.0, variable=f"{pid}:0:Size;a")
            phase.set_HAP_refinements({"Size": {"type": hap["Size"][0], "refine": True}})
        elif quantity == "strain":
            project.set_Controls("parmMax", 50000.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 50000.0, variable=f"{pid}:0:Mustrain;a")
            phase.set_HAP_refinements({"Mustrain": {"type": hap["Mustrain"][0], "refine": True}})
        elif quantity in {"strain_eq", "strain_ax"}:
            project.set_Controls("parmMax", 50000.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 50000.0, variable=f"{pid}:0:Mustrain;a")
            part = "equatorial" if quantity.endswith("eq") else "axial"
            phase.set_HAP_refinements({"Mustrain": {"type": hap["Mustrain"][0], "refine": part}})
        else:
            raise ValueError(name)
    elif name in {"w", "u", "x", "shl", "polar", "zero", "shift", "zero_shift", "roughness"}:
        mapping = {"w": "W", "u": "U", "x": "X", "shl": "SH/L", "polar": "Polariz.",
                   "zero": "Zero"}
        if name in mapping:
            hist.set_refinements({"Instrument Parameters": [mapping[name]]})
        elif name == "shift":
            hist.set_refinements({"Sample Parameters": ["Shift"]})
        elif name == "zero_shift":
            hist.set_refinements({"Instrument Parameters": ["Zero"],
                                  "Sample Parameters": ["Shift"]})
        else:
            sample = hist.data["Sample Parameters"]
            sample["SurfRoughA"][0] = 0.1
            sample["SurfRoughB"][0] = 0.1
            hist.set_refinements({"Sample Parameters": ["SurfRoughA", "SurfRoughB"]})
        if name == "x":
            project.set_Controls("parmMin", 0.01, variable=":0:X")
    else:
        raise ValueError(name)
    project.set_Frozen()
    project.save()
    rows = [checkpoint(project, folder, "01_refine"), checkpoint(project, folder, "02_refine")]
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "W", "X", "SH/L", "Polariz."],
                            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
    project.set_Frozen()
    rows.append(checkpoint(project, folder, "03_fixed"))
    (folder / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_po(args: argparse.Namespace) -> None:
    if not args.case:
        raise ValueError("--case pN_HKL is required for PO mode")
    phase_text, axis_text = args.case.split("_", 1)
    phase_index = int(phase_text[1:])
    axis = [int(ch) for ch in axis_text]
    folder = ROOT / ".tmp" / "final_experiments" / args.tag / args.case
    project = initialize(args.base, folder, False, None)
    hist = project.histogram(0)
    phase = project.phase(phase_index)
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    project.set_Controls("parmMin", 0.7, variable=f"{phase_index}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{phase_index}:0:MD")
    project.set_Frozen()
    project.save()
    rows = [checkpoint(project, folder, "01_po"), checkpoint(project, folder, "02_po")]
    phase.clear_HAP_refinements({"Pref.Ori.": True})
    project.set_Frozen()
    rows.append(checkpoint(project, folder, "03_fixed"))
    (folder / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


def run_adp(args: argparse.Namespace) -> None:
    if not args.case:
        raise ValueError("--case pN_VALUE is required for ADP mode")
    phase_text, value_text = args.case.split("_", 1)
    phase_index, value = int(phase_text[1:]), float(value_text)
    folder = ROOT / ".tmp" / "final_experiments" / args.tag / args.case
    project = initialize(args.base, folder, False, None)
    set_isotropic_adp(project.phase(phase_index), value)
    project.save()
    rows = [checkpoint(project, folder, "01_scale"), checkpoint(project, folder, "02_scale")]
    (folder / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("tag")
    parser.add_argument("--base", type=Path, default=DEFAULT_BASE)
    parser.add_argument("--mode", choices=["initial", "coordinates", "phase-atoms", "profile", "one", "po", "adp"], default="initial")
    parser.add_argument("--case")
    args = parser.parse_args()
    if args.mode == "initial":
        run_initial(args)
    elif args.mode == "coordinates":
        run_coordinates(args)
    elif args.mode == "phase-atoms":
        run_phase_atoms(args)
    elif args.mode == "profile":
        run_profile(args)
    elif args.mode == "one":
        run_one_parameter(args)
    elif args.mode == "po":
        run_po(args)
    else:
        run_adp(args)


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
