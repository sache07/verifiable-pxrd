#!/usr/bin/env python3
"""Print compact diagnostics for a GSAS-II project used in this analysis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(gpxfile=str(args.project))
    hist = project.histogram(0)
    x, y, w, yc, yb, yd = (np.asarray(v, float) for v in hist.data["data"][1][:6])
    use = (x >= 10.0) & (x <= 100.0)
    mass = hist.ComputeMassFracs()
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    cov = project.data.get("Covariance", {}).get("data", {})
    report = {
        "project": str(args.project),
        "histogram": hist.name,
        "residuals": hist.residuals,
        "direct_rwp": 100.0 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) /
                                      np.sum(w[use] * y[use] ** 2)),
        "score_rwp": 100.0 * np.sqrt(np.sum((y - yc) ** 2 / np.maximum(y, 1.0)) /
                                     np.sum(y ** 2 / np.maximum(y, 1.0))),
        "min_calculated": float(np.min(yc)),
        "min_background": float(np.min(yb)),
        "instrument": {key: value for key, value in inst.items()
                       if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "U", "V", "W",
                                  "X", "Y", "SH/L", "Polariz."}},
        "sample": sample,
        "background": hist.data["Background"],
        "limits": hist.data["Limits"],
        "mass_fractions": mass,
        "vary_list": cov.get("varyList", []),
        "variables": cov.get("variables", []),
        "sig": cov.get("sig", []),
        "phases": [],
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        report["phases"].append({
            "name": phase.name,
            "pId": phase.data["pId"],
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "formula": phase.data["General"].get("F000X"),
            "mass": phase.data["General"]["Mass"],
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "po": hap["Pref.Ori."],
            "atoms": [{
                "label": atom.label,
                "element": atom.element,
                "xyz": list(atom.coordinates),
                "occupancy": atom.occupancy,
                "adp_flag": atom.adp_flag,
                "adp": atom.ADP,
                "flags": atom.refinement_flags,
            } for atom in phase.atoms()],
        })
    print(json.dumps(plain(report), indent=2, allow_nan=False))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
