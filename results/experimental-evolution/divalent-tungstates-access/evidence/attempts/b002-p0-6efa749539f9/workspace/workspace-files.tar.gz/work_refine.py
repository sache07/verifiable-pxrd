#!/usr/bin/env python3
"""Build and iteratively refine a GSAS-II model for the supplied PXRD pattern.

This is a working analysis script. Final artifacts are exported separately after
the refinement strategy has been selected.
"""

from __future__ import annotations

import csv
import json
import math
import os
import sys
from pathlib import Path

import numpy as np

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"
SOURCE_CIF = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/1/52/02/1520200.cif"
)
WORK = ROOT / ".tmp" / "rietveld"
GPX = WORK / "working.gpx"


def prepare_inputs() -> tuple[Path, Path]:
    WORK.mkdir(parents=True, exist_ok=True)
    xye = WORK / "pattern.xye"
    rows = []
    with PATTERN.open(newline="") as fp:
        for row in csv.DictReader(fp):
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            rows.append((x, y, math.sqrt(max(y, 1.0))))
    with xye.open("w") as fp:
        fp.write("# two_theta intensity sigma\n")
        for x, y, sig in rows:
            fp.write(f"{x:.8f} {y:.8f} {sig:.8f}\n")

    inst = WORK / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def summarize(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    phase = project.phase(0)
    hap = phase.data["Histograms"][hist.name]
    inst = hist.InstrumentParameters
    samp = hist.SampleParameters
    data = hist.data["data"][1]
    x, y, w, yc, yb = (np.asarray(a, float) for a in data[:5])
    lo, hi = hist.data["Limits"][1]
    use = (x >= lo) & (x <= hi)
    rwp = 100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))
    print(f"\n[{label}] residuals={hist.residuals} direct_Rwp={rwp:.6f}")
    print("cell", phase.get_cell())
    print("inst", {k: v for k, v in inst.items() if k in ["Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L"]})
    print("sample", {k: samp.get(k) for k in ["Scale", "Type", "Gonio. radius", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    print("HAP", {k: hap.get(k) for k in ["Scale", "Size", "Mustrain", "Pref.Ori.", "HStrain"]})
    print("background", hist.Background)
    print("atoms")
    for atom in phase.atoms():
        try:
            adp = atom.uiso
        except Exception:
            adp = "anisotropic"
        print(atom.label, atom.element, atom.coordinates, atom.occupancy, adp, atom.refinement_flags)


def build() -> G2.G2Project:
    xye, inst = prepare_inputs()
    project = G2.G2Project(newgpx=str(GPX))
    phase = project.add_phase(str(SOURCE_CIF), phasename="MnWO4", fmthint="CIF")
    hist = project.add_powder_histogram(str(xye), str(inst), phases=[phase], fmthint="xye")
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.set_refinements(
        {
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 8,
                "coeffs": [1500.0] + [0.0] * 7,
                "refine": True,
            }
        }
    )
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [1.0, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = 1.0
    hap["Size"][1][1] = 1.0
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = 500.0
    hap["Mustrain"][1][1] = 500.0
    hap["Mustrain"][2] = [False, False, False]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]
    project.set_Controls("cycles", 12)
    project.save()
    return project


def refine_step(project: G2.G2Project, label: str) -> None:
    project.refine(printFile=str(WORK / f"{label}.lst"), makeBack=False)
    project.save()
    summarize(project, label)


def run() -> None:
    G2.SetPrintLevel("warn")
    project = build()
    summarize(project, "built")
    refine_step(project, "scale_background")
    refine_step(project, "scale_background_2")

    hist = project.histogram(0)
    phase = project.phase(0)
    phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_step(project, "cell_zero")
    refine_step(project, "cell_zero_2")

    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    refine_step(project, "profile")
    refine_step(project, "profile_2")

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_step(project, "shift")
    refine_step(project, "shift_2")


if __name__ == "__main__":
    run()
