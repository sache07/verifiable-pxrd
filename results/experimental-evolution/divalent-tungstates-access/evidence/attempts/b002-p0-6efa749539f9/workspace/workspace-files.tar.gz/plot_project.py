#!/usr/bin/env python3
"""Plot an observed/calculated GSAS-II powder profile and weighted residual."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path, help="GPX project or profile NPZ")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    if args.project.suffix.lower() == ".npz":
        with np.load(args.project) as data:
            x, y, yc, yb = (np.asarray(data[key], float) for key in ("x", "y", "yc", "yb"))
    else:
        from GSASII import GSASIIscriptable as G2
        project = G2.G2Project(gpxfile=str(args.project))
        hist = project.histogram(0)
        x, y, _, yc, yb = (np.asarray(v, float) for v in hist.data["data"][1][:5])
    import matplotlib.pyplot as plt
    residual = (y - yc) / np.sqrt(np.maximum(y, 1.0))
    fig, axes = plt.subplots(3, 1, figsize=(16, 10), sharex=True,
                             gridspec_kw={"height_ratios": [2.0, 2.0, 1.2]})
    axes[0].plot(x, y, color="black", lw=0.45, label="observed")
    axes[0].plot(x, yc, color="tab:red", lw=0.65, label="calculated")
    axes[0].plot(x, yb, color="tab:blue", lw=0.5, label="background")
    axes[0].set_ylim(0, np.percentile(y, 99.8) * 1.08)
    axes[0].legend(loc="upper right", ncol=3)
    axes[0].set_ylabel("counts")
    axes[1].plot(x, y, color="black", lw=0.45)
    axes[1].plot(x, yc, color="tab:red", lw=0.65)
    axes[1].set_yscale("symlog", linthresh=100)
    axes[1].set_ylabel("counts (symlog)")
    axes[2].plot(x, residual, color="tab:purple", lw=0.5)
    axes[2].axhline(0, color="black", lw=0.5)
    axes[2].set_ylim(-25, 25)
    axes[2].set_ylabel(r"$(I_o-I_c)/\sqrt{I_o}$")
    axes[2].set_xlabel(r"$2\theta$ (degrees)")
    axes[2].set_xlim(float(x[0]), float(x[-1]))
    fig.tight_layout()
    fig.savefig(args.output, dpi=160)


if __name__ == "__main__":
    main()
