#!/usr/bin/env python3
"""Screen W-oxide/tungstate analogues against the broad positive residual."""

from __future__ import annotations

import gzip
import json
import math
import warnings
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser


ROOT = Path(__file__).resolve().parent
BASE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02"
)


def cif_path(cod_id: str) -> Path:
    return BASE / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    with gzip.open(BASE / "index.json.gz", "rt") as fp:
        index = json.load(fp)
    data = np.load(ROOT / ".tmp" / "bounded" / "w2311041_a100" / "profile.npz")
    x = data["x"]
    y = data["y"]
    residual = y - data["yc"]
    dx = float(np.median(np.diff(x)))
    # Emphasize broad positive features; sharp mismatch lobes are suppressed.
    smooth = gaussian_filter1d(residual, 0.16 / dx)
    smooth = np.maximum(smooth, 0.0) / np.sqrt(np.maximum(y, 1.0))
    calc = XRDCalculator(wavelength="CuKa1")
    records = []
    seen = set()
    keys = [k for k in index if "O" in k.split("-") and "W" in k.split("-")
            and len(k.split("-")) <= 4]
    keys += ["Mn-O"]
    for key in keys:
        for formula, cod_id, sg, quality in index.get(key, []):
            if cod_id in seen:
                continue
            seen.add(cod_id)
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = CifParser(cif_path(cod_id), occupancy_tolerance=10).parse_structures(primitive=False)[0]
                pattern = calc.get_pattern(structure, two_theta_range=(9.5, 100.5), scaled=True)
                pos = np.asarray(pattern.x, float)
                inten = np.sqrt(np.maximum(np.asarray(pattern.y, float), 0.0))
                keep = inten >= math.sqrt(0.5)
                pos, inten = pos[keep], inten[keep]
                if not len(pos):
                    continue
                best = (-np.inf, 1.0)
                for scale in np.linspace(0.82, 1.18, 145):
                    arg = np.sin(np.deg2rad(pos / 2.0)) / scale
                    valid = (arg > 0) & (arg < 1)
                    shifted = 2 * np.rad2deg(np.arcsin(arg[valid]))
                    vals = np.interp(shifted, x, smooth, left=0.0, right=0.0)
                    score = float(np.dot(inten[valid], vals) / np.sqrt(np.dot(inten[valid], inten[valid])))
                    if score > best[0]:
                        best = (score, float(scale))
                records.append({"score": best[0], "scale": best[1], "key": key,
                                "formula": formula, "cod_id": cod_id, "space_group": sg,
                                "n_peaks": int(len(pos))})
            except Exception:
                continue
    records.sort(key=lambda z: z["score"], reverse=True)
    out = ROOT / ".tmp" / "analogue_screen.json"
    out.write_text(json.dumps(records, indent=2) + "\n")
    for row in records[:100]:
        print(f"{row['score']:9.3f} scale={row['scale']:.4f} {row['cod_id']} "
              f"{row['formula']:<24s} SG={row['space_group']:<3} key={row['key']}")


if __name__ == "__main__":
    main()
