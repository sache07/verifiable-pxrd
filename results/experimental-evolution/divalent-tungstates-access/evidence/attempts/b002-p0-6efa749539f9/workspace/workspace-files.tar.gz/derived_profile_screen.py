#!/usr/bin/env python3
"""Screen physically valid Mn-substituted W-oxide analogues against the residual."""

from __future__ import annotations

import gzip
import json
import math
import warnings
from pathlib import Path

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Element
from pymatgen.io.cif import CifParser
from scipy.ndimage import gaussian_filter1d


ROOT = Path(__file__).resolve().parent
BASE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02"
)


def cif_path(cod_id: str) -> Path:
    return BASE / "cif" / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    with gzip.open(BASE / "index.json.gz", "rt") as fp:
        index = json.load(fp)
    data = np.load(ROOT / ".tmp" / "bounded" / "w2311041_a100" / "profile.npz")
    x, y = data["x"], data["y"]
    residual = y - data["yc"]
    weight = 1.0 / np.maximum(y, 1.0)
    use = (x >= 10) & (x <= 100)
    base_loss = float(np.sum(weight[use] * residual[use] ** 2))
    dx = float(np.median(np.diff(x)))
    calculators = [(XRDCalculator(wavelength=1.540598), 1.0),
                   (XRDCalculator(wavelength=1.544426), 0.5)]
    records = []
    seen = set()
    keys = [k for k in index if {"O", "W"} <= set(k.split("-"))
            and len(k.split("-")) <= 4]
    for key in keys:
        for formula, cod_id, sg, quality in index[key]:
            if cod_id in seen:
                continue
            seen.add(cod_id)
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = CifParser(cif_path(cod_id), occupancy_tolerance=10).parse_structures(
                        primitive=False
                    )[0]
                other = [el for el in structure.composition.elements
                         if el.symbol not in {"W", "O"}]
                if not other or any(not Element(el.symbol).is_metal for el in other):
                    continue
                structure.replace_species({el: "Mn" for el in other})
                comp = structure.composition
                mn, tungsten, oxygen = (float(comp.get_atomic_fraction(e) * comp.num_atoms)
                                        for e in ["Mn", "W", "O"])
                if min(mn, tungsten, oxygen) <= 0:
                    continue
                mn_valence = (2 * oxygen - 6 * tungsten) / mn
                if not 1.5 <= mn_valence <= 4.2:
                    continue
                distances = structure.distance_matrix.copy()
                np.fill_diagonal(distances, np.inf)
                if len(structure) > 1 and float(np.min(distances)) < 0.8:
                    continue
                sticks = []
                for calculator, multiplier in calculators:
                    pattern = calculator.get_pattern(structure, two_theta_range=(8, 105),
                                                     scaled=False)
                    sticks.extend((float(a), float(b) * multiplier)
                                  for a, b in zip(pattern.x, pattern.y) if b > 0)
                best = (-np.inf, None, None, None)
                for scale in np.linspace(0.85, 1.15, 61):
                    delta = np.zeros_like(x)
                    for position, intensity in sticks:
                        arg = np.sin(np.deg2rad(position / 2)) / scale
                        if not 0 < arg < 1:
                            continue
                        shifted = 2 * np.rad2deg(np.arcsin(arg))
                        index_at = int(round((shifted - x[0]) / dx))
                        if 0 <= index_at < len(delta):
                            delta[index_at] += intensity
                    for sigma_deg in (0.08, 0.15, 0.25, 0.40, 0.65):
                        profile = gaussian_filter1d(delta, sigma_deg / dx)
                        denom = float(np.sum(weight[use] * profile[use] ** 2))
                        numer = float(np.sum(weight[use] * profile[use] * residual[use]))
                        amplitude = max(0.0, numer / denom) if denom else 0.0
                        loss = float(np.sum(weight[use] *
                                            (residual[use] - amplitude * profile[use]) ** 2))
                        reduction = base_loss - loss
                        if reduction > best[0]:
                            best = (reduction, float(scale), float(sigma_deg), amplitude)
                reduced = comp.reduced_composition
                records.append({
                    "relative_reduction": best[0] / base_loss,
                    "loss_reduction": best[0],
                    "profile_scale": best[1],
                    "sigma_deg": best[2],
                    "amplitude": best[3],
                    "cod_id": cod_id,
                    "parent_formula": formula,
                    "derived_formula": reduced.alphabetical_formula,
                    "mn_formal_valence": mn_valence,
                    "space_group": sg,
                    "key": key,
                    "substitutions": [el.symbol for el in other],
                })
            except Exception:
                continue
    records.sort(key=lambda row: row["loss_reduction"], reverse=True)
    (ROOT / ".tmp" / "derived_profile_screen.json").write_text(
        json.dumps(records, indent=2) + "\n"
    )
    for row in records[:100]:
        print(f"{row['relative_reduction']:8.5f} s={row['profile_scale']:.3f} "
              f"sig={row['sigma_deg']:.2f} {row['cod_id']} {row['parent_formula']:<24s} "
              f"-> {row['derived_formula']:<18s} Mn{row['mn_formal_valence']:.2f} "
              f"SG={row['space_group']}")


if __name__ == "__main__":
    main()
