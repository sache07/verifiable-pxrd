#!/usr/bin/env python3
"""Test an analogue-derived replacement for phase 2 in the selected model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def metric(project: G2.G2Project) -> float:
    x, y, _, yc = (np.asarray(v, float) for v in project.histogram(0).data["data"][1][:4])
    return float(100 * np.sqrt(np.sum((y - yc) ** 2 / np.maximum(y, 1.0)) /
                               np.sum(y ** 2 / np.maximum(y, 1.0))))


def clear(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True,
                                     "Pref.Ori.": True})


def checkpoint(project: G2.G2Project, folder: Path, label: str) -> dict:
    project.set_Frozen()
    project.refine(printFile=str(folder / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, folder / f"{label}.gpx")
    hist = project.histogram(0)
    row = {"label": label, "rwp": metric(project), "fractions": hist.ComputeMassFracs()}
    print(label, row["rwp"], row["fractions"], flush=True)
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("model", type=Path)
    parser.add_argument("tag")
    parser.add_argument("--size", type=float, default=0.08)
    parser.add_argument("--strain", type=float, default=8000.0)
    args = parser.parse_args()
    folder = ROOT / ".tmp" / "replacement_tests" / args.tag
    folder.mkdir(parents=True, exist_ok=True)
    target = folder / "model.gpx"
    shutil.copy2(args.base, target)
    project = G2.G2Project(gpxfile=str(target))
    hist = project.histogram(0)
    clear(project)
    # Retain the old phase only as a zero-scale control during comparison.
    old = project.phase(2)
    old.data["Histograms"][hist.name]["Scale"] = [1e-8, False]
    new = project.add_phase(str(args.model), phasename=args.tag, histograms=[hist], fmthint="CIF")
    pid = new.data["pId"]
    new.data["Histograms"][hist.name]["Scale"] = [10.0, True]
    new.setSampleProfile(hist, "size", "isotropic", args.size)
    new.setSampleProfile(hist, "microstrain", "isotropic", args.strain)
    project.set_Controls("cycles", 12)
    for variable, lo, hi in [(f"{pid}:0:Scale", 1e-8, 1000.0),
                             (f"{pid}:0:Size;i", 0.02, 2.0),
                             (f"{pid}:0:Mustrain;i", 0.0, 50000.0),
                             (f"{pid}:0:MD", 0.7, 1.4)]:
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)
    project.save()
    rows = [checkpoint(project, folder, "01_scale"), checkpoint(project, folder, "02_scale")]
    new.set_refinements({"Cell": True})
    rows += [checkpoint(project, folder, "03_cell"), checkpoint(project, folder, "04_cell")]
    new.clear_refinements({"Cell": True})
    new.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    rows += [checkpoint(project, folder, "05_strain"), checkpoint(project, folder, "06_strain")]
    new.clear_HAP_refinements({"Mustrain": True})
    new.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    rows += [checkpoint(project, folder, "07_size"), checkpoint(project, folder, "08_size")]
    new.clear_HAP_refinements({"Size": True})
    rows.append(checkpoint(project, folder, "09_fixed"))
    (folder / "history.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
