#!/usr/bin/env python3
"""Test chemically restrained coordinate refinement for the Mn2WO6 phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    return value


def metrics(project: G2.G2Project) -> dict:
    hist = project.histogram(0)
    x, y, w, yc, yb = (np.asarray(v, float) for v in hist.data["data"][1][:5])
    return {
        "rwp": float(100 * np.sqrt(np.sum(w * (y - yc) ** 2) / np.sum(w * y ** 2))),
        "min_calculated": float(np.min(yc)),
        "min_background": float(np.min(yb)),
        "fractions": hist.ComputeMassFracs(),
        "residuals": hist.residuals,
    }


def clear_refinements(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"],
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})


def checkpoint(project: G2.G2Project, folder: Path, label: str) -> dict:
    project.refine(printFile=str(folder / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, folder / f"{label}.gpx")
    row = {"label": label, **metrics(project)}
    print(label, row["rwp"], flush=True)
    return row


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("base", type=Path)
    parser.add_argument("folder", type=Path)
    parser.add_argument("--weight", type=float, required=True)
    parser.add_argument("--w-esd", type=float, default=0.05)
    parser.add_argument("--mn-esd", type=float, default=0.07)
    parser.add_argument("--coord-bound", type=float)
    parser.add_argument("--steps", type=int, default=2)
    args = parser.parse_args()

    args.folder.mkdir(parents=True, exist_ok=True)
    target = args.folder / "model.gpx"
    shutil.copy2(args.base, target)
    project = G2.G2Project(gpxfile=str(target))
    clear_refinements(project)
    project.set_Controls("cycles", 12)
    project.set_Frozen()

    phase = project.phase(2)
    restraint_data = project.data.setdefault("Restraints", {}).setdefault("data", {})
    restraint_data.setdefault(phase.name, {})["Bond"] = {
        "wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True,
    }
    phase.clearDistRestraint()
    atoms = phase.atoms()
    oxygen = [a for a in atoms if a.element == "O"]
    tungsten = [a for a in atoms if a.element == "W"]
    manganese = [a for a in atoms if a.element == "Mn"]
    counts = {
        "W-O": phase.addDistRestraint(tungsten, oxygen, 1.87, factor=1.18, ESD=args.w_esd),
        "Mn-O": phase.addDistRestraint(manganese, oxygen, 2.25, factor=1.14, ESD=args.mn_esd),
    }
    phase.setDistRestraintWeight(args.weight)
    phase.set_refinements({"Atoms": {a.label: "X" for a in atoms}})
    if args.coord_bound is not None:
        pid = phase.data["pId"]
        for index, _ in enumerate(atoms):
            for axis in "xyz":
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", -args.coord_bound, variable=variable)
                project.set_Controls("parmMax", args.coord_bound, variable=variable)
    project.save()

    rows = [checkpoint(project, args.folder, f"{i:02d}_coordinates")
            for i in range(1, args.steps + 1)]
    phase.clear_refinements({"Atoms": [a.label for a in atoms]})
    project.set_Frozen()
    rows.append(checkpoint(project, args.folder, f"{args.steps + 1:02d}_fixed"))
    output = {
        "restraint_weight": args.weight,
        "w_esd": args.w_esd,
        "mn_esd": args.mn_esd,
        "coord_bound": args.coord_bound,
        "restraint_counts": counts,
        "restraints": project.data["Restraints"]["data"][phase.name]["Bond"],
        "history": rows,
    }
    (args.folder / "history.json").write_text(json.dumps(plain(output), indent=2) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
