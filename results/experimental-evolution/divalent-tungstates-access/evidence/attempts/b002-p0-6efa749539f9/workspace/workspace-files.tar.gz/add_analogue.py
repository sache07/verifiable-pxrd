#!/usr/bin/env python3
"""Refine an analogue-derived MnWO4 model as a third phase."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "bounded" / "w2311041_a100" / "09_wo_strain.gpx"


def rwp(project: G2.G2Project) -> float:
    hist = project.histogram(0)
    x, y, w, yc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return float(100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) /
                               np.sum(w[use] * y[use] ** 2)))


def step(project: G2.G2Project, work: Path, label: str) -> dict:
    project.refine(printFile=str(work / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, work / f"{label}.gpx")
    hist = project.histogram(0)
    row = {"label": label, "rwp": rwp(project), "phases": []}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"].append({"name": phase.name, "cell": phase.get_cell(),
                              "scale": hap["Scale"], "size": hap["Size"],
                              "mustrain": hap["Mustrain"], "po": hap["Pref.Ori."]})
    print(label, row["rwp"], [(p["name"], p["scale"][0]) for p in row["phases"]])
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("model", type=Path)
    ap.add_argument("tag")
    args = ap.parse_args()
    work = ROOT / ".tmp" / "analogue_tests" / args.tag
    work.mkdir(parents=True, exist_ok=True)
    shutil.copy2(BASE, work / "model.gpx")
    project = G2.G2Project(gpxfile=str(work / "model.gpx"))
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
                            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for old in project.phases():
        old.clear_refinements({"Cell": True})
        old.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        old.set_HAP_refinements({"Scale": True})
    phase = project.add_phase(str(args.model), phasename=f"MnWO4_{args.tag}",
                              histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [8.0, True]
    phase.setSampleProfile(hist, "size", "isotropic", 0.20)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 5000.0)
    project.set_Controls("cycles", 10)
    project.save()
    for variable, lo, hi in [("2:0:Scale", 1e-8, 1000.0),
                             ("2:0:Size;i", 0.04, 1.5),
                             ("2:0:Mustrain;i", 0.0, 16000.0),
                             ("2:0:MD", 0.5, 1.5)]:
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)
    history = [step(project, work, "01_scale"), step(project, work, "02_scale")]
    phase.set_refinements({"Cell": True})
    history += [step(project, work, "03_cell"), step(project, work, "04_cell")]
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    history.append(step(project, work, "05_strain"))
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    history += [step(project, work, "06_profile"), step(project, work, "07_profile")]
    (work / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    data = hist.data["data"][1]
    np.savez_compressed(work / "profile.npz", **{k: np.asarray(v, float) for k, v in
                         zip(["x", "y", "w", "yc", "yb", "yd"], data[:6])})


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
