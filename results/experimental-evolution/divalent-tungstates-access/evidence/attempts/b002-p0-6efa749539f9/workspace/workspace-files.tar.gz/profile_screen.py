#!/usr/bin/env python3
"""Full-profile matched-filter refinement of the analogue shortlist."""

from __future__ import annotations

import json
import warnings
from pathlib import Path

import numpy as np
from scipy.ndimage import gaussian_filter1d
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.io.cif import CifParser


ROOT = Path(__file__).resolve().parent
BASE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cif_path(cod_id: str) -> Path:
    return BASE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    prelim = json.loads((ROOT / ".tmp" / "analogue_screen.json").read_text())
    selected = prelim[:250]
    # Always retain the chemically direct systems even when the preliminary rank is low.
    direct = [r for r in prelim if r["key"] in {"O-W", "Mn-O", "Mn-O-W"}]
    by_id = {r["cod_id"]: r for r in selected + direct}
    data = np.load(ROOT / ".tmp" / "bounded" / "w2311041_a100" / "profile.npz")
    x, y = data["x"], data["y"]
    residual = y - data["yc"]
    weight = 1.0 / np.maximum(y, 1.0)
    use = (x >= 10) & (x <= 100)
    base_loss = float(np.sum(weight[use] * residual[use] ** 2))
    dx = float(np.median(np.diff(x)))
    calcs = [(XRDCalculator(wavelength=1.540598), 1.0),
             (XRDCalculator(wavelength=1.544426), 0.5)]
    result = []
    for rec in by_id.values():
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = CifParser(cif_path(rec["cod_id"]), occupancy_tolerance=10).parse_structures(primitive=False)[0]
            sticks = []
            for calc, mult in calcs:
                pat = calc.get_pattern(structure, two_theta_range=(8.0, 105.0), scaled=False)
                sticks += [(float(a), float(b) * mult) for a, b in zip(pat.x, pat.y) if b > 0]
            best = (-np.inf, None, None, None)
            for scale in np.linspace(0.90, 1.10, 41):
                delta = np.zeros_like(x)
                for pos, intensity in sticks:
                    arg = np.sin(np.deg2rad(pos / 2.0)) / scale
                    if not 0 < arg < 1:
                        continue
                    shifted = 2 * np.rad2deg(np.arcsin(arg))
                    ind = int(round((shifted - x[0]) / dx))
                    if 0 <= ind < len(delta):
                        delta[ind] += intensity
                for sigma_deg in (0.08, 0.15, 0.25, 0.40, 0.65):
                    profile = gaussian_filter1d(delta, sigma_deg / dx)
                    denom = float(np.sum(weight[use] * profile[use] ** 2))
                    numer = float(np.sum(weight[use] * profile[use] * residual[use]))
                    amplitude = max(0.0, numer / denom) if denom else 0.0
                    loss = float(np.sum(weight[use] * (residual[use] - amplitude * profile[use]) ** 2))
                    reduction = base_loss - loss
                    if reduction > best[0]:
                        best = (reduction, float(scale), float(sigma_deg), amplitude)
            row = dict(rec)
            row.update(loss_reduction=best[0], relative_reduction=best[0] / base_loss,
                       profile_scale=best[1], sigma_deg=best[2], amplitude=best[3])
            result.append(row)
        except Exception:
            continue
    result.sort(key=lambda r: r["loss_reduction"], reverse=True)
    (ROOT / ".tmp" / "profile_screen.json").write_text(json.dumps(result, indent=2) + "\n")
    for r in result[:100]:
        print(f"{r['relative_reduction']:8.5f} s={r['profile_scale']:.3f} sig={r['sigma_deg']:.2f} "
              f"{r['cod_id']} {r['formula']:<25s} SG={r['space_group']:<3} {r['key']}")


if __name__ == "__main__":
    main()
