#!/usr/bin/env python3
"""Quick GSAS-II screens of plausible WO3 and Mn-oxide secondary phases."""

from __future__ import annotations

import argparse
import csv
import json
import math
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)


def cif_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def make_inputs(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    xye = work / "pattern.xye"
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as fp, xye.open("w") as out:
        out.write("# two_theta intensity sigma\n")
        for row in csv.DictReader(fp):
            x, y = float(row["two_theta_deg"]), float(row["intensity"])
            out.write(f"{x:.8f} {y:.8f} {math.sqrt(max(y, 1)):.8f}\n")
    inst = work / "instrument.instprm"
    inst.write_text(
        "#GSAS-II instrument parameter file; Cu Kalpha Bragg-Brentano\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.02\n"
    )
    return xye, inst


def refine(project: G2.G2Project, work: Path, label: str) -> None:
    project.refine(printFile=str(work / f"{label}.lst"), makeBack=False)
    project.save()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("wo3")
    ap.add_argument("mnoxide", nargs="?", default="none")
    args = ap.parse_args()
    tag = f"w{args.wo3}_m{args.mnoxide}"
    work = ROOT / ".tmp" / "screens" / tag
    xye, inst = make_inputs(work)
    project = G2.G2Project(newgpx=str(work / "screen.gpx"))
    specs = [
        ("MnWO4", "1520200", 80.0, 0.8, 400.0),
        ("WO3", args.wo3, 25.0, 0.08, 2500.0),
    ]
    if args.mnoxide != "none":
        specs.append(("Mn3O4", args.mnoxide, 8.0, 0.15, 1200.0))
    phases = []
    for name, cod_id, _, _, _ in specs:
        phases.append(project.add_phase(str(cif_path(cod_id)), phasename=name, fmthint="CIF"))
    hist = project.add_powder_histogram(str(xye), str(inst), phases=phases, fmthint="xye")
    hist.Limits("lower", 10.0)
    hist.Limits("upper", 100.0)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": 10,
                        "coeffs": [1500.0] + [0.0] * 9, "refine": True}}
    )
    for phase, (_, _, scale, size, strain) in zip(phases, specs):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [scale, True]
        phase.setSampleProfile(hist, "size", "isotropic", size)
        phase.setSampleProfile(hist, "microstrain", "isotropic", strain)
    project.set_Controls("cycles", 10)
    project.save()
    refine(project, work, "scale_bg")
    refine(project, work, "scale_bg_2")

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, work, "cell_zero")
    refine(project, work, "cell_zero_2")

    for phase in phases:
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True},
             "Mustrain": {"type": "isotropic", "refine": True}}
        )
    refine(project, work, "phase_profile")
    refine(project, work, "phase_profile_2")

    data = hist.data["data"][1]
    x, y, w, yc, yb, yd = (np.asarray(v, float) for v in data[:6])
    use = (x >= 10) & (x <= 100)
    rwp = 100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) / np.sum(w[use] * y[use] ** 2))
    summary = {
        "tag": tag,
        "rwp_percent": float(rwp),
        "residuals": hist.residuals,
        "zero": hist.InstrumentParameters["Zero"],
        "phases": [],
    }
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        summary["phases"].append(
            {"name": phase.name, "cell": phase.get_cell(), "scale": hap["Scale"],
             "size": hap["Size"], "mustrain": hap["Mustrain"]}
        )
    (work / "summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    np.savez_compressed(work / "profile.npz", x=x, y=y, w=w, yc=yc, yb=yb, yd=yd)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
