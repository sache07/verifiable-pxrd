#!/usr/bin/env python3
"""Freeze the selected GSAS-II project and export its saved phase models."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def output_name(phase_name: str) -> str:
    key = phase_name.lower()
    if key == "mnwo4":
        return "mnwo4_wolframite.cif"
    if key == "wo3":
        return "wo3_monoclinic.cif"
    if "mn2wo6" in key:
        return "mn2wo6_orthorhombic.cif"
    if key == "mno":
        return "mno_rocksalt.cif"
    raise ValueError(f"Unexpected phase in selected project: {phase_name}")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("--outdir", type=Path, default=Path.cwd())
    args = parser.parse_args()

    source = args.source.resolve()
    outdir = args.outdir.resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    final_project = outdir / "final.gpx"
    shutil.copyfile(source, final_project)

    project = G2.G2Project(gpxfile=str(final_project))
    # The scorer exports the persisted atom tables with covariance removed.
    # Mirror that convention so the submitted CIFs are digit-for-digit models
    # of the project, rather than values substituted from a stale covariance.
    project.data.setdefault("Covariance", {})["data"] = {}

    exports = []
    seen = set()
    for phase in project.phases():
        filename = output_name(phase.name)
        if filename in seen:
            raise ValueError(f"Duplicate phase export target: {filename}")
        seen.add(filename)
        path = outdir / filename
        phase.export_CIF(str(path))
        exports.append({"project_phase": phase.name, "cif_path": filename})

    expected = {
        "mnwo4_wolframite.cif",
        "wo3_monoclinic.cif",
        "mn2wo6_orthorhombic.cif",
        "mno_rocksalt.cif",
    }
    if seen != expected:
        raise ValueError(f"Unexpected exported inventory: {sorted(seen)}")
    print(json.dumps({"project": str(final_project), "exports": exports}, indent=2))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
