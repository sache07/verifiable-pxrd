#!/usr/bin/env python3
"""Build Mn-W-O test models from the cubic CsLiWO4 stuffed-cristobalite parent."""

from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif/2/10/64/2106410.cif"
)
OUT = ROOT / ".tmp" / "cubic_models"


def make(tag: str, cs_occupancy: float, li_occupancy: float) -> None:
    text = SOURCE.read_text()
    text = text.replace("data_2106410", f"data_MnWO4_cubic_{tag}")
    text = text.replace("_chemical_formula_sum            'Cs Li O4 W'",
                        "_chemical_formula_sum            'Mn O4 W'")
    text = text.replace("_chemical_name_systematic        'Cs Li W O4'",
                        "_chemical_name_systematic        'manganese tungsten oxide; cubic analogue-derived model'")
    text = text.replace("_cell_formula_units_Z            4", "_cell_formula_units_Z            4")
    text = text.replace("_cell_length_a                   8.35", "_cell_length_a                   8.850")
    text = text.replace("_cell_length_b                   8.35", "_cell_length_b                   8.850")
    text = text.replace("_cell_length_c                   8.35", "_cell_length_c                   8.850")
    text = text.replace("_cell_volume                     582.183", "_cell_volume                     693.155")
    text = text.replace("_cod_database_code               2106410", "# Parent COD record: 2106410")
    text = text.replace("Cs1 Cs+1 0.5 0.5 0.5 1 0.0",
                        f"Mn_cavity Mn+2 0.5 0.5 0.5 {cs_occupancy:.6f} 0.005")
    text = text.replace("Li1 Li+1 0.25 0.25 0.25 1 0.0",
                        f"Mn_tetra Mn+2 0.25 0.25 0.25 {li_occupancy:.6f} 0.005")
    text = text.replace("W1 W+6 0.5 0.5 0 1 0.0", "W1 W+6 0.5 0.5 0 1 0.005")
    text = text.replace("O1 O-2 0.39 0.39 0.147 0.333 0.0",
                        "O1 O-2 0.39 0.39 0.147 0.333333 0.005")
    destination = OUT / f"mnwo4_cubic_{tag}.cif"
    destination.write_text(text)
    print(destination)


def make_swapped() -> None:
    """Put Mn and W on the two compact tetrahedral sublattices; leave the cavity vacant."""
    text = SOURCE.read_text()
    text = text.replace("data_2106410", "data_MnWO4_cubic_swapped")
    text = text.replace("_chemical_formula_sum            'Cs Li O4 W'",
                        "_chemical_formula_sum            'Mn O4 W'")
    text = text.replace("_chemical_name_systematic        'Cs Li W O4'",
                        "_chemical_name_systematic        'manganese tungsten oxide; cubic analogue-derived swapped model'")
    text = text.replace("_cell_length_a                   8.35", "_cell_length_a                   8.850")
    text = text.replace("_cell_length_b                   8.35", "_cell_length_b                   8.850")
    text = text.replace("_cell_length_c                   8.35", "_cell_length_c                   8.850")
    text = text.replace("_cell_volume                     582.183", "_cell_volume                     693.155")
    text = text.replace("_cod_database_code               2106410", "# Parent COD record: 2106410")
    text = text.replace("Cs1 Cs+1 0.5 0.5 0.5 1 0.0", "Mn_cavity Mn+2 0.5 0.5 0.5 0.000000 0.005")
    text = text.replace("W1 W+6 0.5 0.5 0 1 0.0", "Mn1 Mn+2 0.5 0.5 0 1 0.005")
    text = text.replace("Li1 Li+1 0.25 0.25 0.25 1 0.0", "W1 W+6 0.25 0.25 0.25 1 0.005")
    text = text.replace("O1 O-2 0.39 0.39 0.147 0.333 0.0",
                        "O1 O-2 0.39 0.39 0.147 0.333333 0.005")
    destination = OUT / "mnwo4_cubic_swapped.cif"
    destination.write_text(text)
    print(destination)


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    # Tetrahedral Mn gives MnWO4 and chemically reasonable Mn-O distances.
    make("tetra", 0.0, 1.0)
    # Alternative placements are diagnostics for diffraction/site sensitivity.
    make("cavity", 1.0, 0.0)
    make("split", 0.5, 0.5)
    make("both", 1.0, 1.0)
    make_swapped()


if __name__ == "__main__":
    main()
