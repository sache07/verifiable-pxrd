#!/usr/bin/env python3
"""Add a candidate fourth phase to the MnWO4/WO3/trigonal-MnWO4 model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
DEFAULT_BASE = ROOT / ".tmp" / "analogue_tests" / "kin" / "05_strain.gpx"


def cif_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def rwp(project: G2.G2Project) -> float:
    hist = project.histogram(0)
    x, y, w, yc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return float(100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) /
                               np.sum(w[use] * y[use] ** 2)))


def step(project: G2.G2Project, work: Path, label: str) -> dict:
    project.refine(printFile=str(work / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, work / f"{label}.gpx")
    hist = project.histogram(0)
    row = {"label": label, "rwp": rwp(project), "phases": []}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        row["phases"].append({"name": phase.name, "cell": phase.get_cell(),
                              "scale": hap["Scale"], "size": hap["Size"],
                              "mustrain": hap["Mustrain"], "po": hap["Pref.Ori."]})
    print(label, row["rwp"], [(p["name"], p["scale"][0]) for p in row["phases"]])
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cod_id")
    ap.add_argument("name")
    ap.add_argument("--base", type=Path, default=DEFAULT_BASE)
    ap.add_argument("--tag")
    args = ap.parse_args()
    work = ROOT / ".tmp" / "fourth_tests" / (args.tag or args.cod_id)
    work.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.base, work / "model.gpx")
    project = G2.G2Project(gpxfile=str(work / "model.gpx"))
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
                            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for old in project.phases():
        old.clear_refinements({"Cell": True})
        old.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        old.set_HAP_refinements({"Scale": True})
    phase = project.add_phase(str(cif_path(args.cod_id)), phasename=args.name,
                              histograms=[hist], fmthint="CIF")
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [5.0, True]
    phase.setSampleProfile(hist, "size", "isotropic", 0.10)
    phase.setSampleProfile(hist, "microstrain", "isotropic", 5000.0)
    project.set_Controls("cycles", 10)
    project.save()
    for variable, lo, hi in [("3:0:Scale", 1e-8, 1000.0),
                             ("3:0:Size;i", 0.04, 1.5),
                             ("3:0:Mustrain;i", 0.0, 16000.0),
                             ("3:0:MD", 0.5, 1.5)]:
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)
    history = [step(project, work, "01_scale"), step(project, work, "02_scale")]
    phase.set_refinements({"Cell": True})
    history += [step(project, work, "03_cell"), step(project, work, "04_cell")]
    phase.clear_refinements({"Cell": True})
    phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    history.append(step(project, work, "05_strain"))
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    history += [step(project, work, "06_profile"), step(project, work, "07_profile")]
    (work / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    data = hist.data["data"][1]
    np.savez_compressed(work / "profile.npz", **{k: np.asarray(v, float) for k, v in
                         zip(["x", "y", "w", "yc", "yb", "yd"], data[:6])})


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
