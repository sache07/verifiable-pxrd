#!/usr/bin/env python3
"""Calculate and save per-phase powder-profile contributions from a GPX file."""

from __future__ import annotations

import argparse
import pickle
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    work = args.output.with_suffix(".gpx")
    partials = args.output.with_suffix(".partials")
    shutil.copy2(args.project, work)
    project = G2.G2Project(gpxfile=str(work))
    hist = project.histogram(0)
    hist.clear_refinements({
        "Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
        "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB", "Transparency"],
        "Background": False,
    })
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [atom.label for atom in phase.atoms()]})
        phase.clear_HAP_refinements({"Scale": True, "Size": True, "Mustrain": True,
                                     "Pref.Ori.": True})
    controls = project.data["Controls"]["data"]
    controls["max cyc"] = 0
    controls["PhasePartials"] = str(partials.resolve())
    partials.unlink(missing_ok=True)
    project.save()
    project.refine(printFile=str(args.output.with_suffix(".lst")), makeBack=False)
    project.save()
    with partials.open("rb") as handle:
        assert pickle.load(handle) is None
        hid = pickle.load(handle)
        x = pickle.load(handle)
        background = pickle.load(handle)
        profiles = {}
        while True:
            try:
                name = pickle.load(handle)
            except EOFError:
                break
            if name is None:
                break
            profiles[name] = pickle.load(handle)
    data = hist.data["data"][1]
    np.savez_compressed(args.output, x=np.asarray(x), observed=np.asarray(data[1]),
                        calculated=np.asarray(data[3]), background=np.asarray(background),
                        histogram_id=hid, names=np.asarray(list(profiles)),
                        profiles=np.asarray(list(profiles.values())))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
