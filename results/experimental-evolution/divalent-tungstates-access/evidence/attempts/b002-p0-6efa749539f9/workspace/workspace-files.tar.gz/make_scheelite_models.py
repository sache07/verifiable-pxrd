#!/usr/bin/env python3
"""Create MnWO4 scheelite-type analogue models from valid AWO4 parents."""

from __future__ import annotations

from pathlib import Path
import warnings

from pymatgen.io.cif import CifParser, CifWriter


ROOT = Path(__file__).resolve().parent
RESOURCE = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b002-c02/cif"
)
OUT = ROOT / ".tmp" / "scheelite_models"
PARENTS = {
    "ca_7219229": ("7219229", "Ca"),
    "sr_1546036": ("1546036", "Sr"),
    "cd_1549132": ("1549132", "Cd"),
    "pb_1527935": ("1527935", "Pb"),
    "ba_1527204": ("1527204", "Ba"),
}


def cif_path(cod_id: str) -> Path:
    return RESOURCE / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    for tag, (cod_id, element) in PARENTS.items():
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            structure = CifParser(cif_path(cod_id), occupancy_tolerance=10).parse_structures(primitive=False)[0]
        structure.replace_species({element: "Mn"})
        path = OUT / f"mnwo4_scheelite_{tag}.cif"
        path.write_text(str(CifWriter(structure, symprec=1e-4, significant_figures=9)) + "\n")
        distances = structure.distance_matrix
        positive = distances[distances > 1e-8]
        print(tag, structure.composition.reduced_formula, structure.get_space_group_info(),
              structure.lattice, "minimum_distance", positive.min(), "->", path)


if __name__ == "__main__":
    main()
