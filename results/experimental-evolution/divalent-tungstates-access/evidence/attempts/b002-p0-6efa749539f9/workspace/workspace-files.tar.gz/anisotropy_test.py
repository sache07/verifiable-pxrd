#!/usr/bin/env python3
"""Test uniaxial microstrain directions for the third phase in a GSAS-II model."""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent


def rwp(project: G2.G2Project) -> float:
    hist = project.histogram(0)
    x, y, w, yc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return float(100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) /
                               np.sum(w[use] * y[use] ** 2)))


def checkpoint(project: G2.G2Project, work: Path, label: str) -> dict:
    project.refine(printFile=str(work / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, work / f"{label}.gpx")
    hist = project.histogram(0)
    phase = project.phase(2)
    hap = phase.data["Histograms"][hist.name]
    row = {"label": label, "rwp": rwp(project), "cell": phase.get_cell(),
           "scale": hap["Scale"], "size": hap["Size"], "mustrain": hap["Mustrain"]}
    print(label, row["rwp"], row["scale"][0], row["size"][1], row["mustrain"][1])
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("base", type=Path)
    ap.add_argument("tag")
    ap.add_argument("axis", choices=["100", "010", "001"])
    args = ap.parse_args()
    axis = [int(v) for v in args.axis]
    work = ROOT / ".tmp" / "anisotropy_tests" / f"{args.tag}_{args.axis}"
    work.mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.base, work / "model.gpx")
    project = G2.G2Project(gpxfile=str(work / "model.gpx"))
    hist = project.histogram(0)
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
                            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    phase = project.phase(2)
    phase.setSampleProfile(hist, "size", "isotropic", 0.15)
    phase.setSampleProfile(hist, "microstrain", "uniaxial", 7000.0, 18000.0, axis)
    phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "refine": True,
                                             "direction": axis}})
    project.set_Controls("cycles", 12)
    for variable, lo, hi in [("2:0:Scale", 1e-8, 1000.0),
                             ("2:0:Size;i", 0.04, 1.5),
                             ("2:0:Mustrain;i", 0.0, 8000.0),
                             ("2:0:Mustrain;a", 0.0, 32000.0)]:
        project.set_Controls("parmMin", lo, variable=variable)
        project.set_Controls("parmMax", hi, variable=variable)
    history = [checkpoint(project, work, "01_strain"),
               checkpoint(project, work, "02_strain")]
    phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    history += [checkpoint(project, work, "03_size"),
                checkpoint(project, work, "04_size")]
    (work / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    data = hist.data["data"][1]
    np.savez_compressed(work / "profile.npz", **{k: np.asarray(v, float) for k, v in
                         zip(["x", "y", "w", "yc", "yb", "yd"], data[:6])})


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
