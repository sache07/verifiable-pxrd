#!/usr/bin/env python3
"""Refine atomic and intensity parameters from the selected two-phase model."""

from __future__ import annotations

import json
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
BASE = ROOT / ".tmp" / "bounded" / "w2311041_a100" / "09_wo_strain.gpx"
WORK = ROOT / ".tmp" / "enhanced"


def rwp(project: G2.G2Project) -> float:
    hist = project.histogram(0)
    x, y, w, yc = (np.asarray(v, float) for v in hist.data["data"][1][:4])
    use = (x >= 10) & (x <= 100)
    return float(100 * np.sqrt(np.sum(w[use] * (y[use] - yc[use]) ** 2) /
                               np.sum(w[use] * y[use] ** 2)))


def step(project: G2.G2Project, label: str) -> dict:
    project.refine(printFile=str(WORK / f"{label}.lst"), makeBack=False)
    project.save()
    shutil.copy2(project.filename, WORK / f"{label}.gpx")
    hist = project.histogram(0)
    out = {"label": label, "rwp": rwp(project), "residuals": hist.residuals,
           "phases": []}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        out["phases"].append({"name": phase.name, "cell": phase.get_cell(),
                              "scale": hap["Scale"], "po": hap["Pref.Ori."],
                              "atoms": [{"label": a.label, "element": a.element,
                                         "xyz": list(a.coordinates), "flags": a.refinement_flags}
                                        for a in phase.atoms()]})
    print(label, out["rwp"])
    return out


def main() -> None:
    WORK.mkdir(parents=True, exist_ok=True)
    shutil.copy2(BASE, WORK / "enhanced.gpx")
    project = G2.G2Project(gpxfile=str(WORK / "enhanced.gpx"))
    hist = project.histogram(0)
    # Keep profile/position calibration fixed while refining structure factors.
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "SH/L", "Polariz."],
                            "Sample Parameters": ["Shift", "SurfRoughA", "SurfRoughB"]})
    for phase in project.phases():
        phase.clear_refinements({"Cell": True, "Atoms": [a.label for a in phase.atoms()]})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    project.set_Controls("cycles", 12)
    project.save()
    history = []

    mnw, wo = project.phases()
    mnw.set_refinements({"Atoms": {"all": "X"}})
    history.append(step(project, "01_mnwo4_xyz"))
    history.append(step(project, "02_mnwo4_xyz"))
    mnw.clear_refinements({"Atoms": [a.label for a in mnw.atoms()]})

    wo.set_refinements({"Atoms": {"all": "X"}})
    history.append(step(project, "03_wo3_xyz"))
    history.append(step(project, "04_wo3_xyz"))
    wo.clear_refinements({"Atoms": [a.label for a in wo.atoms()]})

    (WORK / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    data = hist.data["data"][1]
    np.savez_compressed(WORK / "profile.npz", **{k: np.asarray(v, float) for k, v in
                         zip(["x", "y", "w", "yc", "yb", "yd"], data[:6])})


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
