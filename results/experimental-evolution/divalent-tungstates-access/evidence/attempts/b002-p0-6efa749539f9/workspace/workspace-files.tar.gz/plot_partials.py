#!/usr/bin/env python3
"""Plot observed profile, total fit and individual phase contributions."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("profile", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--xmin", type=float, default=10.0)
    parser.add_argument("--xmax", type=float, default=60.0)
    args = parser.parse_args()
    with np.load(args.profile) as data:
        x = data["x"]
        observed = data["observed"]
        calculated = data["calculated"]
        background = data["background"]
        names = data["names"]
        profiles = data["profiles"]
    use = (x >= args.xmin) & (x <= args.xmax)
    fig, axes = plt.subplots(2, 1, figsize=(16, 8), sharex=True,
                             gridspec_kw={"height_ratios": [2.2, 1.2]})
    axes[0].plot(x[use], observed[use], color="black", lw=0.7, label="observed")
    axes[0].plot(x[use], calculated[use], color="tab:red", lw=0.8, label="total calculated")
    axes[0].plot(x[use], background[use], color="grey", lw=0.6, label="background")
    for name, profile in zip(names, profiles):
        axes[0].plot(x[use], background[use] + profile[use], lw=0.65, alpha=0.85,
                     label=str(name))
    axes[0].legend(ncol=4, fontsize=8)
    axes[0].set_ylabel("counts")
    residual = (observed - calculated) / np.sqrt(np.maximum(observed, 1.0))
    axes[1].plot(x[use], residual[use], color="tab:purple", lw=0.6)
    axes[1].axhline(0, color="black", lw=0.5)
    axes[1].set_ylabel(r"$(I_o-I_c)/\sqrt{I_o}$")
    axes[1].set_xlabel(r"$2\theta$ (degrees)")
    axes[1].set_xlim(args.xmin, args.xmax)
    fig.tight_layout()
    fig.savefig(args.output, dpi=170)


if __name__ == "__main__":
    main()
