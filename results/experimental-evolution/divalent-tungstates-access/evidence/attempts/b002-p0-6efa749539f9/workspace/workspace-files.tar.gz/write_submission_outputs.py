#!/usr/bin/env python3
"""Write fit.csv and result.json from the independent final-project replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
REPLAY = ROOT / ".tmp" / "final_replay"


def main() -> None:
    replay = json.loads((REPLAY / "replay.json").read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"Final project did not replay: {replay}")
    if replay.get("profile_review_flags"):
        raise RuntimeError(f"Final project has replay flags: {replay['profile_review_flags']}")

    with np.load(REPLAY / "prediction.npz", allow_pickle=False) as data:
        x = np.asarray(data["x"], float)
        observed = np.asarray(data["observed"], float)
        calculated = np.asarray(data["predicted"], float)
    difference = observed - calculated
    if not (np.isfinite(x).all() and np.isfinite(observed).all()
            and np.isfinite(calculated).all() and np.all(calculated >= 0)):
        raise ValueError("Replayed profile contains invalid values")

    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack([x, observed, calculated, difference]),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.1f", "%.10f", "%.10f"],
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    chi_square = float(np.sum(weights * difference ** 2))
    denominator = float(np.sum(weights * observed ** 2))
    rwp = float(100.0 * np.sqrt(chi_square / denominator))
    rp = float(100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed)))
    expected_rwp = 1.9937201963814055

    descriptions = {
        "MnWO4": {
            "name": "MnWO4 (wolframite)", "formula": "MnWO4",
            "space_group": "P 2/c", "cif_path": "mnwo4_wolframite.cif",
            "model_basis": "published COD 1520200, Rietveld-refined",
        },
        "WO3": {
            "name": "WO3 (monoclinic)", "formula": "WO3",
            "space_group": "P 21/c", "cif_path": "wo3_monoclinic.cif",
            "model_basis": "published COD 2311041, Rietveld-refined",
        },
        "MnWO4_mn2wo6_p212121": {
            "name": "Mn2WO6 (orthorhombic)", "formula": "Mn2WO6",
            "space_group": "P 21 21 21", "cif_path": "mn2wo6_orthorhombic.cif",
            "model_basis": "analogue-derived from Y2WO6 COD 1541070",
        },
        "MnO": {
            "name": "MnO (rocksalt)", "formula": "MnO",
            "space_group": "F m -3 m", "cif_path": "mno_rocksalt.cif",
            "model_basis": "published COD 1514108, Rietveld-refined",
        },
    }
    phases = []
    for phase in replay["phases"]:
        row = dict(descriptions[phase["name"]])
        row["weight_fraction"] = float(phase["weight_fraction"])
        phases.append(row)
    total = sum(row["weight_fraction"] for row in phases)
    if abs(total - 1.0) > 1e-12:
        raise ValueError(f"Phase fractions do not sum to one: {total}")

    result = {
        "phases": phases,
        "fraction_basis": "normalized over the four modeled crystalline phases; amorphous content not determined",
        "fit_statistics": {
            "rwp_percent": rwp,
            "rp_percent": rp,
            "expected_rwp_percent": expected_rwp,
            "goodness_of_fit": rwp / expected_rwp,
            "chi_square": chi_square,
            "n_points": int(len(x)),
            "weighting": "1/max(observed_counts, 1)",
            "profile_source": "fresh native GSAS-II forward replay of final.gpx",
        },
        "calibration": {
            "zero_shift_deg": float(replay["instrument"]["Zero"][1]),
            "wavelength_Kalpha1_angstrom": float(replay["instrument"]["Lam1"][1]),
            "wavelength_Kalpha2_angstrom": float(replay["instrument"]["Lam2"][1]),
            "Kalpha2_to_Kalpha1_ratio": float(replay["instrument"]["I(L2)/I(L1)"][1]),
        },
        "refinement_histogram": replay["histogram"],
        "project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
