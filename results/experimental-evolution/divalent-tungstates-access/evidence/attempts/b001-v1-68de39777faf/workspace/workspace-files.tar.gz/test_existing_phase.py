"""Reactivate one existing phase by name and test its scale, then its cell."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def summarize(project, histogram, stage):
    rows = []
    products = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        product = max(float(hap["Scale"][0]), 0.0) * float(phase.data["General"]["Mass"])
        products.append(product)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_product": product,
                "cell": [float(value) for value in phase.data["General"]["Cell"][1:7]],
            }
        )
    total = sum(products)
    for row, product in zip(rows, products):
        row["weight_fraction"] = product / total if total else None
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "stage": stage,
        "rwp": float(rvals["Rwp"]),
        "gof": float(rvals["GOF"]),
        "converged": bool(rvals.get("converged", False)),
        "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        "phases": rows,
    }


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("candidate")
parser.add_argument("--inactive", default="", help="comma-separated phases kept at zero scale")
parser.add_argument("--initial-weight", type=float, default=0.01)
parser.add_argument("--reset-texture", action="store_true", help="set every March-Dollase ratio to one")
parser.add_argument("--copy-profile-from", help="copy fixed isotropic size and strain from this phase to the candidate")
parser.add_argument("--cycles", type=int, default=40)
parser.add_argument("--repeats", type=int, default=2)
args = parser.parse_args()

if not 0.0 < args.initial_weight < 1.0:
    raise ValueError("--initial-weight must lie strictly between zero and one")

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
candidate = project.phase(args.candidate)
inactive = {name for name in args.inactive.split(",") if name}
inactive.discard(candidate.name)

histogram.data["Background"][0][1] = True
for value in histogram.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = False
histogram.data["Sample Parameters"]["Shift"][1] = False

other_product = 0.0
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    if phase.name in inactive:
        hap["Scale"] = [0.0, False]
    else:
        hap["Scale"][1] = True
        if phase.name != candidate.name:
            other_product += max(float(hap["Scale"][0]), 0.0) * float(phase.data["General"]["Mass"])
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    if args.reset_texture:
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6

candidate_hap = candidate.data["Histograms"][histogram.name]
if args.copy_profile_from:
    source_hap = project.phase(args.copy_profile_from).data["Histograms"][histogram.name]
    candidate_hap["Size"][0] = "isotropic"
    candidate_hap["Size"][1][0] = float(source_hap["Size"][1][0])
    candidate_hap["Size"][2] = [False, False, False]
    candidate_hap["Mustrain"][0] = "isotropic"
    candidate_hap["Mustrain"][1][0] = float(source_hap["Mustrain"][1][0])
    candidate_hap["Mustrain"][2] = [False, False, False]
candidate_hap["Scale"] = [
    args.initial_weight / (1.0 - args.initial_weight) * other_product / float(candidate.data["General"]["Mass"]),
    True,
]

project.set_Controls("cycles", args.cycles)
project.save(str(Path(args.output).resolve()))
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    history.append(summarize(project, histogram, f"scale_background_{iteration + 1}"))

candidate_row = next(row for row in history[-1]["phases"] if row["name"] == candidate.name)
status = "rejected_scale_collapse"
if candidate_row["scale"] > 0.0 and candidate_row["weight_fraction"] is not None and candidate_row["weight_fraction"] >= 1e-5:
    before = candidate_row["cell"]
    candidate.data["General"]["Cell"][0] = True
    for iteration in range(args.repeats):
        project.refine()
        project.save()
        history.append(summarize(project, histogram, f"candidate_cell_{iteration + 1}"))
    after = next(row for row in history[-1]["phases"] if row["name"] == candidate.name)["cell"]
    valid = all(math.isfinite(value) and value > 0.0 for value in after[:3])
    status = "tested" if valid else "unknown_invalid_cell"

print(json.dumps({"project": str(Path(args.output).resolve()), "candidate": candidate.name, "status": status, "history": history}))
