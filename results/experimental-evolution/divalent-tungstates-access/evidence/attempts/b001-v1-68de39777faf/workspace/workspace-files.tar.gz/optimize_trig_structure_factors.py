"""Fit the two free oxygen coordinates of a P-31m Mn2WO6 model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from pymatgen.analysis.diffraction.xrd import ATOMIC_SCATTERING_PARAMS
from pymatgen.core import Element, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.symmetry.groups import SpaceGroup
from scipy.optimize import least_squares


parser = argparse.ArgumentParser()
parser.add_argument("input_cif")
parser.add_argument("reflections_npz")
parser.add_argument("output_cif")
parser.add_argument("--max-shift-A", type=float, default=0.05)
parser.add_argument("--regularization", type=float, default=0.1)
parser.add_argument("--fobs-min", type=float, default=100.0)
args = parser.parse_args()

parent = Structure.from_file(args.input_cif, primitive=False)
analyzer = SpacegroupAnalyzer(parent, symprec=1e-3)
if analyzer.get_space_group_number() != 162:
    raise ValueError("input structure is not P-31m (#162)")
symmetrized = analyzer.get_symmetrized_structure()
groups = [list(group) for group in symmetrized.equivalent_indices]
representatives = [group[0] for group in groups]
species = [parent[index].specie.symbol for index in representatives]
coordinates = np.asarray([parent[index].frac_coords for index in representatives], float)
oxygen_index = species.index("O")
if len(species) != 3 or species.count("O") != 1:
    raise ValueError(f"expected independent Mn, W and O sites, got {species}")
initial_oxygen = coordinates[oxygen_index].copy()
if abs(initial_oxygen[0]) > 1e-5:
    raise ValueError(f"expected the O site on x=0 mirror, got {initial_oxygen}")

with np.load(args.reflections_npz) as arrays:
    hkl = np.asarray(arrays["hkl"], int)
    d = np.asarray(arrays["d"], float)
    position = np.asarray(arrays["position"], float)
    fobs2 = np.asarray(arrays["fobs2"], float)
    fcalc2 = np.asarray(arrays["fcalc2"], float)
mask = (
    np.isfinite(fobs2)
    & np.isfinite(fcalc2)
    & (fobs2 >= args.fobs_min)
    & (fcalc2 > 1e-3)
    & (position <= 90.0)
)
hkl, d, fobs2, fcalc2 = hkl[mask], d[mask], fobs2[mask], fcalc2[mask]

operations = SpaceGroup("P-31m").symmetry_ops
s2 = (0.5 / d) ** 2
scattering = {}
for symbol in set(species):
    element = Element(symbol)
    coefficients = np.asarray(ATOMIC_SCATTERING_PARAMS[symbol], float)
    scattering[symbol] = element.Z - 41.78214 * s2 * np.sum(
        coefficients[:, 0][None, :] * np.exp(-coefficients[:, 1][None, :] * s2[:, None]),
        axis=1,
    )


def unique_symmetry_coordinates(point):
    rows = []
    for operation in operations:
        value = operation.operate(point) % 1.0
        if not any(np.linalg.norm((value - old) - np.round(value - old)) < 1e-6 for old in rows):
            rows.append(value)
    return rows


def direct_intensity(oxygen_yz):
    trial = coordinates.copy()
    trial[oxygen_index, 1:] = oxygen_yz
    amplitude = np.zeros(len(hkl), complex)
    for symbol, point in zip(species, trial):
        for equivalent in unique_symmetry_coordinates(point):
            amplitude += scattering[symbol] * np.exp(2j * np.pi * (hkl @ equivalent))
    return np.maximum((amplitude * amplitude.conjugate()).real, 1e-12)


initial_yz = initial_oxygen[1:].copy()
initial_direct = direct_intensity(initial_yz)
fractional_limits = np.asarray(
    [args.max_shift_A / parent.lattice.b, args.max_shift_A / parent.lattice.c], float
)


def profile(yz):
    return np.maximum(fcalc2 * direct_intensity(yz) / initial_direct, 1e-9)


def residual(yz):
    predicted = profile(yz)
    strength = np.sqrt(np.clip(fobs2 / np.percentile(fobs2, 75), 0.05, 2.0))
    data = strength * (np.log(predicted + 100.0) - np.log(fobs2 + 100.0))
    displacement = (yz - initial_yz) / fractional_limits
    return np.concatenate([data, args.regularization * displacement])


fit = least_squares(
    residual,
    initial_yz,
    bounds=(initial_yz - fractional_limits, initial_yz + fractional_limits),
    x_scale="jac",
    loss="soft_l1",
    max_nfev=1000,
    ftol=1e-12,
    xtol=1e-12,
    gtol=1e-12,
)
optimized = coordinates.copy()
optimized[oxygen_index, 1:] = fit.x
trial = Structure.from_spacegroup(162, parent.lattice, species, optimized)
trial.remove_oxidation_states()
sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model  # noqa: E402

write_synthetic_model(trial, args.output_cif)
delta = np.array([0.0, *(fit.x - initial_yz)])
shift = float(np.linalg.norm(delta @ parent.lattice.matrix))
print(
    json.dumps(
        {
            "success": bool(fit.success),
            "message": fit.message,
            "reflections": int(len(hkl)),
            "initial_oxygen": initial_oxygen.tolist(),
            "optimized_oxygen": optimized[oxygen_index].tolist(),
            "cartesian_shift_A": shift,
            "at_boundary": bool(np.any(np.abs(fit.x - initial_yz) >= 0.98 * fractional_limits)),
            "cost": float(fit.cost),
            "output": str(Path(args.output_cif)),
        }
    )
)
