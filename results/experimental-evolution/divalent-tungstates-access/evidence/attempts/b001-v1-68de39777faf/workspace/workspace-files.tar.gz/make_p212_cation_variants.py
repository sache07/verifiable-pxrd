"""Enumerate Mn/W orderings on the three cation orbits of a P212121 model."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output_dir")
args = parser.parse_args()

structure = Structure.from_file(args.input, primitive=False)
symmetrized = SpacegroupAnalyzer(structure, symprec=1e-3).get_symmetrized_structure()
cation_groups = [
    list(group)
    for group in symmetrized.equivalent_indices
    if structure[group[0]].specie.symbol != "O"
]
if len(cation_groups) != 3:
    raise ValueError(f"expected three cation orbits, found {len(cation_groups)}")

output = Path(args.output_dir)
output.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model  # noqa: E402

for w_site in range(3):
    trial = structure.copy()
    for orbit, indices in enumerate(cation_groups):
        for index in indices:
            trial.replace(index, "W" if orbit == w_site else "Mn")
    path = output / f"Mn2WO6_Wsite{w_site}.cif"
    write_synthetic_model(trial, path)
    print(path, trial.composition.reduced_formula)

for mn_site in range(3):
    trial = structure.copy()
    for orbit, indices in enumerate(cation_groups):
        for index in indices:
            trial.replace(index, "Mn" if orbit == mn_site else "W")
    path = output / f"MnW2O6_Mnsite{mn_site}.cif"
    write_synthetic_model(trial, path)
    print(path, trial.composition.reduced_formula)
