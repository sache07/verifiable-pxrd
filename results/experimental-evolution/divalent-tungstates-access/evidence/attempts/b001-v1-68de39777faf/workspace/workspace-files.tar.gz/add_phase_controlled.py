"""Add one phase and refine only inventory scales/background under fixed nuisance terms."""

from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


def rows(project, histogram):
    result = []
    products = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        product = max(float(hap["Scale"][0]), 0.0) * float(phase.data["General"]["Mass"])
        products.append(product)
        result.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "mass_product": product,
                "cell": [float(value) for value in phase.data["General"]["Cell"][1:7]],
            }
        )
    total = sum(products)
    for row, product in zip(result, products):
        row["weight_fraction"] = product / total if total else None
    return result


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("cif")
parser.add_argument("name")
parser.add_argument("--inactive", default="")
parser.add_argument("--profile-source", default="MnWO4_wolframite")
parser.add_argument("--copy-texture", action="store_true", help="copy the profile source's fixed MD axis and ratio")
parser.add_argument("--initial-weight", type=float, default=0.02)
parser.add_argument("--cycles", type=int, default=45)
parser.add_argument("--repeats", type=int, default=3)
args = parser.parse_args()

if not 0.0 < args.initial_weight < 1.0:
    raise ValueError("--initial-weight must lie strictly between zero and one")

G2.SetPrintLevel("warn")
input_path = Path(args.input).resolve()
output_path = Path(args.output).resolve()
if input_path != output_path:
    shutil.copy2(input_path, output_path)
project = G2.G2Project(gpxfile=str(output_path))
histogram = project.histograms()[0]
inactive = {name for name in args.inactive.split(",") if name}
trial = project.add_phase(str(Path(args.cif).resolve()), phasename=args.name, histograms=[histogram], fmthint="CIF")

histogram.data["Background"][0][1] = True
for value in histogram.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = False
histogram.data["Sample Parameters"]["Shift"][1] = False

other_product = 0.0
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    if phase.name in inactive:
        hap["Scale"] = [0.0, False]
    else:
        hap["Scale"][1] = True
        if phase.name != trial.name:
            other_product += max(float(hap["Scale"][0]), 0.0) * float(phase.data["General"]["Mass"])
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6

source_hap = project.phase(args.profile_source).data["Histograms"][histogram.name]
trial_hap = trial.data["Histograms"][histogram.name]
trial_hap["Size"][0] = "isotropic"
trial_hap["Size"][1][0] = float(source_hap["Size"][1][0])
trial_hap["Size"][2] = [False, False, False]
trial_hap["Mustrain"][0] = "isotropic"
trial_hap["Mustrain"][1][0] = float(source_hap["Mustrain"][1][0])
trial_hap["Mustrain"][2] = [False, False, False]
trial_hap["Mustrain"][5] = [False] * len(trial_hap["Mustrain"][5])
if args.copy_texture:
    trial_hap["Pref.Ori."] = copy.deepcopy(source_hap["Pref.Ori."])
    trial_hap["Pref.Ori."][2] = False
else:
    trial_hap["Pref.Ori."][0] = "MD"
    trial_hap["Pref.Ori."][1] = 1.0
    trial_hap["Pref.Ori."][2] = False
trial_hap["Scale"] = [
    args.initial_weight / (1.0 - args.initial_weight) * other_product / float(trial.data["General"]["Mass"]),
    True,
]

project.set_Controls("cycles", args.cycles)
project.save(str(output_path))
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": iteration + 1,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        }
    )

print(json.dumps({"project": str(output_path), "history": history, "phases": rows(project, histogram)}))
