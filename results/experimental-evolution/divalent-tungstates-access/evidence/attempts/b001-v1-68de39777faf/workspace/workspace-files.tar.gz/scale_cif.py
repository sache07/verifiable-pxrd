"""Apply an isotropic lattice-length scale to a CIF without changing fractional sites."""

from __future__ import annotations

import argparse
from pathlib import Path

from pymatgen.core import Structure


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("scale", type=float, help="multiplicative scale for a, b, and c")
args = parser.parse_args()

if not 0.5 < args.scale < 1.5:
    raise ValueError("scale is outside the guarded range 0.5--1.5")

structure = Structure.from_file(args.input, primitive=False)
structure.scale_lattice(structure.volume * args.scale**3)
structure.to(filename=str(Path(args.output)), fmt="cif", symprec=1e-5)
print(Path(args.output), structure.composition.reduced_formula, structure.lattice, structure.density)
