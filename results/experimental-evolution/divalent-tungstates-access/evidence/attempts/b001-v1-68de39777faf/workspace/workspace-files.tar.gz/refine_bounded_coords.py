"""One bounded coordinate-refinement stage for a named phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("phase")
parser.add_argument("--inactive", default="", help="comma-separated phases held at zero scale")
group = parser.add_mutually_exclusive_group(required=True)
group.add_argument("--elements")
group.add_argument("--labels")
parser.add_argument("--max-shift-A", type=float, required=True)
parser.add_argument("--cycles", type=int, default=50)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
histogram.data["Background"][0][1] = True
for value in histogram.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = False
histogram.data["Sample Parameters"]["Shift"][1] = False
target = project.phase(args.phase)
selected = set((args.elements or args.labels).split(","))
inactive = {name for name in args.inactive.split(",") if name}
controls = project.data["Controls"]["data"]
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}
controls["parmFrozen"] = {"FrozenList": []}

cell = target.data["General"]["Cell"][1:7]
a, b, c, alpha, beta, gamma = cell
alpha, beta, gamma = np.deg2rad([alpha, beta, gamma])
lattice = np.array(
    [
        [a, 0.0, 0.0],
        [b * np.cos(gamma), b * np.sin(gamma), 0.0],
        [
            c * np.cos(beta),
            c * (np.cos(alpha) - np.cos(beta) * np.cos(gamma)) / np.sin(gamma),
            0.0,
        ],
    ]
)
lattice[2, 2] = np.sqrt(max(0.0, c * c - lattice[2, 0] ** 2 - lattice[2, 1] ** 2))
axis_lengths = np.linalg.norm(lattice, axis=1)
initial = {}
selected_indices = []
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    if phase.name in inactive:
        hap["Scale"] = [0.0, False]
    else:
        hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    for index, atom in enumerate(phase.data["Atoms"]):
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6
        if phase.name != target.name:
            continue
        initial[atom[0]] = np.asarray(atom[3:6], float)
        key = atom[1] if args.elements else atom[0]
        if key in selected:
            atom[2] = "X"
            selected_indices.append(index)
            for axis, axis_name in enumerate("xyz"):
                variable = f"{target.data['pId']}::dA{axis_name}:{index}"
                limit = args.max_shift_A / axis_lengths[axis]
                project.set_Controls("parmMin", float(initial[atom[0]][axis] - limit), variable=variable)
                project.set_Controls("parmMax", float(initial[atom[0]][axis] + limit), variable=variable)

project.set_Controls("cycles", args.cycles)
project.save(str(Path(args.output).resolve()))
project.refine()
project.save()
rvals = project.data["Covariance"]["data"]["Rvals"]
rows = []
for index in selected_indices:
    atom = target.data["Atoms"][index]
    delta = np.asarray(atom[3:6], float) - initial[atom[0]]
    delta -= np.round(delta)
    rows.append(
        {
            "label": atom[0],
            "initial_fractional": initial[atom[0]].tolist(),
            "refined_fractional": [float(value) for value in atom[3:6]],
            "cartesian_shift_A": float(np.linalg.norm(delta @ lattice)),
        }
    )
print(
    json.dumps(
        {
            "project": str(Path(args.output).resolve()),
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
            "frozen": project.get_Frozen(),
            "atoms": rows,
        }
    )
)
