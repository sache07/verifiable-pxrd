"""Constrained P212121 coordinate fit to GSAS-II extracted structure factors.

This is a shortlist diagnostic. The resulting CIF still has to improve the
full-profile GSAS-II fit and pass geometry/boundary checks before use.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import numpy as np
from pymatgen.analysis.diffraction.xrd import ATOMIC_SCATTERING_PARAMS
from pymatgen.core import Element, Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.symmetry.groups import SpaceGroup
from scipy.optimize import least_squares


parser = argparse.ArgumentParser()
parser.add_argument("input_cif")
parser.add_argument("reflections_npz")
parser.add_argument("output_cif")
parser.add_argument("--max-heavy-A", type=float, default=0.06)
parser.add_argument("--max-oxygen-A", type=float, default=0.08)
parser.add_argument("--regularization", type=float, default=0.25)
parser.add_argument("--fobs-min", type=float, default=100.0)
parser.add_argument("--max-nfev", type=int, default=1200)
args = parser.parse_args()

parent = Structure.from_file(args.input_cif, primitive=False)
analyzer = SpacegroupAnalyzer(parent, symprec=1e-3)
if analyzer.get_space_group_number() != 19:
    raise ValueError("input structure is not P212121 (#19)")
symmetrized = analyzer.get_symmetrized_structure()
groups = [list(group) for group in symmetrized.equivalent_indices]
representatives = [group[0] for group in groups]
species = [parent[index].specie.symbol for index in representatives]
initial = np.asarray([parent[index].frac_coords for index in representatives], float)
if len(initial) != 9 or species.count("O") != 6:
    raise ValueError(f"expected 9 independent sites including 6 O, got {species}")

with np.load(args.reflections_npz) as arrays:
    hkl = np.asarray(arrays["hkl"], int)
    d = np.asarray(arrays["d"], float)
    position = np.asarray(arrays["position"], float)
    fobs2 = np.asarray(arrays["fobs2"], float)
    fcalc2 = np.asarray(arrays["fcalc2"], float)
mask = (
    np.isfinite(fobs2)
    & np.isfinite(fcalc2)
    & (fobs2 >= args.fobs_min)
    & (fcalc2 > 1e-3)
    & (position <= 90.0)
)
hkl, d, fobs2, fcalc2 = hkl[mask], d[mask], fobs2[mask], fcalc2[mask]

operations = SpaceGroup("P2_12_12_1").symmetry_ops
lattice = parent.lattice
inverse_lattice = np.linalg.inv(lattice.matrix)
s2 = (0.5 / d) ** 2
site_scattering = np.empty((len(s2), len(species)), float)
for site_index, symbol in enumerate(species):
    element = Element(symbol)
    coefficients = np.asarray(ATOMIC_SCATTERING_PARAMS[symbol], float)
    site_scattering[:, site_index] = element.Z - 41.78214 * s2 * np.sum(
        coefficients[:, 0][None, :] * np.exp(-coefficients[:, 1][None, :] * s2[:, None]),
        axis=1,
    )


def full_coordinates(representative_coordinates):
    rows = []
    owners = []
    for site_index, coordinate in enumerate(representative_coordinates):
        for operation in operations:
            rows.append(operation.operate(coordinate) % 1.0)
            owners.append(site_index)
    return np.asarray(rows, float), np.asarray(owners, int)


def direct_intensity(representative_coordinates):
    coordinates, owners = full_coordinates(representative_coordinates)
    phase = np.exp(2j * np.pi * (hkl @ coordinates.T))
    amplitudes = np.sum(site_scattering[:, owners] * phase, axis=1)
    return np.maximum((amplitudes * amplitudes.conjugate()).real, 1e-12)


initial_direct = direct_intensity(initial)
heavy = np.asarray([symbol != "O" for symbol in species])
limits = np.where(heavy, args.max_heavy_A, args.max_oxygen_A)
lower = np.repeat(-limits, 3)
upper = np.repeat(limits, 3)


def coordinates_from_cartesian(values):
    cartesian = np.asarray(values, float).reshape((-1, 3))
    return (initial + cartesian @ inverse_lattice) % 1.0


def profile(values):
    trial = direct_intensity(coordinates_from_cartesian(values))
    return np.maximum(fcalc2 * trial / initial_direct, 1e-9)


def residual(values):
    predicted = profile(values)
    # Log residuals prevent the few largest extracted reflections from
    # overwhelming all independent structure-factor information.
    strength = np.sqrt(np.clip(fobs2 / np.percentile(fobs2, 75), 0.05, 2.0))
    data = strength * (np.log(predicted + 100.0) - np.log(fobs2 + 100.0))
    scales = np.repeat(np.where(heavy, 0.04, 0.05), 3)
    restraint = args.regularization * np.asarray(values, float) / scales
    return np.concatenate([data, restraint])


fit = least_squares(
    residual,
    np.zeros(3 * len(initial)),
    bounds=(lower, upper),
    max_nfev=args.max_nfev,
    x_scale="jac",
    loss="soft_l1",
    ftol=1e-11,
    xtol=1e-11,
    gtol=1e-11,
)
cartesian = fit.x.reshape((-1, 3))
optimized = coordinates_from_cartesian(fit.x)
trial = Structure.from_spacegroup(19, lattice, species, optimized)
trial.remove_oxidation_states()
sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model  # noqa: E402

write_synthetic_model(trial, args.output_cif)
predicted_before = profile(np.zeros_like(fit.x))
predicted_after = profile(fit.x)


def factor_rwp(predicted):
    weights = 1.0 / np.maximum(fobs2, 1.0)
    return float(100.0 * np.sqrt(np.sum(weights * (fobs2 - predicted) ** 2) / np.sum(weights * fobs2**2)))


boundary = np.abs(fit.x) >= 0.98 * upper
report = {
    "success": bool(fit.success),
    "message": fit.message,
    "reflections": int(len(hkl)),
    "factor_rwp_before_percent": factor_rwp(predicted_before),
    "factor_rwp_after_percent": factor_rwp(predicted_after),
    "cost": float(fit.cost),
    "nfev": int(fit.nfev),
    "boundary_components": int(np.count_nonzero(boundary)),
    "sites": [
        {
            "species": symbol,
            "cartesian_shift_A": [float(value) for value in vector],
            "shift_norm_A": float(np.linalg.norm(vector)),
            "at_boundary": [bool(value) for value in row],
        }
        for symbol, vector, row in zip(species, cartesian, boundary.reshape((-1, 3)))
    ],
    "output": str(Path(args.output_cif)),
}
print(json.dumps(report))
