"""Fast residual screen of every accessible Mn-O structure."""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Structure
from scipy.optimize import minimize_scalar


parser = argparse.ArgumentParser()
parser.add_argument("--arrays", default=".tmp/three_cal_arrays.npz")
parser.add_argument("--output", default=".tmp/mn_oxide_screen.json")
parser.add_argument("--shift-um", type=float, default=-721.4841695073925)
args = parser.parse_args()

ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06")
with gzip.open(ROOT / "index.json.gz", "rt") as stream:
    index = json.load(stream)
with np.load(args.arrays) as arrays:
    x = arrays["x"]
    observed = arrays["observed"]
    calculated = arrays["predicted"] if "predicted" in arrays.files else arrays["calculated"]

residual = observed - calculated
weight = 1.0 / np.maximum(observed, 1.0)
denominator = float(np.sum(weight * observed**2))
base_loss = float(np.sum(weight * residual**2))
calculator = XRDCalculator(wavelength=1.540598)
lam1 = 1.540598
lam2 = 1.544426
zero = 0.0
shift_um = args.shift_um
radius_mm = 200.0


def source_path(record_id: str) -> Path:
    return ROOT / "cif" / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def displaced(center):
    theta = np.deg2rad(center / 2.0)
    return center + zero - 0.09 / (np.pi * radius_mm) * 4.0 * shift_um * np.cos(theta)


def profile(angles, intensities, lattice_scale):
    sine1 = np.sin(np.deg2rad(angles / 2.0)) / lattice_scale
    valid = (sine1 > 0.0) & (sine1 < 1.0)
    sine1 = sine1[valid]
    values = intensities[valid]
    centers1 = displaced(np.rad2deg(2.0 * np.arcsin(sine1)))
    sine2 = sine1 * lam2 / lam1
    valid2 = sine2 < 1.0
    centers = np.concatenate([centers1, displaced(np.rad2deg(2.0 * np.arcsin(sine2[valid2])))])
    values = np.concatenate([values, 0.5 * values[valid2]])
    result = np.zeros_like(x)
    for center, intensity in zip(centers, values):
        sigma = 0.10 + 0.0028 * center
        lo = int(np.searchsorted(x, center - 4.5 * sigma))
        hi = int(np.searchsorted(x, center + 4.5 * sigma))
        if hi > lo:
            z = (x[lo:hi] - center) / sigma
            result[lo:hi] += intensity * np.exp(-0.5 * z * z)
    maximum = float(result.max(initial=0.0))
    return result / maximum if maximum > 0.0 else result


def score(angles, intensities, scale):
    candidate = profile(angles, intensities, scale)
    norm = float(np.sum(weight * candidate**2))
    amplitude = max(0.0, float(np.sum(weight * candidate * residual)) / norm) if norm else 0.0
    loss = float(np.sum(weight * (residual - amplitude * candidate) ** 2))
    return loss, amplitude


rows = []
seen = set()
for key, records in index.items():
    if set(key.split("-")) not in ({"Mn", "O"}, {"Mn"}):
        continue
    for formula, record_id, space_group, source_r in records:
        if record_id in seen:
            continue
        seen.add(record_id)
        row = {"record_id": record_id, "formula": formula, "space_group": space_group, "source_r": source_r}
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = Structure.from_file(source_path(record_id), primitive=False)
                pattern = calculator.get_pattern(structure, two_theta_range=(8.0, 105.0), scaled=False)
            angles = np.asarray(pattern.x, float)
            intensities = np.asarray(pattern.y, float)
            optimum = minimize_scalar(
                lambda value: score(angles, intensities, float(value))[0],
                method="bounded",
                bounds=(0.88, 1.12),
                options={"xatol": 1e-5, "maxiter": 80},
            )
            loss, amplitude = score(angles, intensities, float(optimum.x))
            row.update(
                status="screened",
                lattice_scale=float(optimum.x),
                amplitude_counts=float(amplitude),
                approximate_rwp=100.0 * math.sqrt(loss / denominator),
                improvement=base_loss - loss,
            )
        except Exception as exc:
            row.update(status="unknown", error=repr(exc))
        rows.append(row)

rows.sort(key=lambda value: value.get("approximate_rwp", float("inf")))
Path(args.output).write_text(json.dumps(rows, indent=2) + "\n")
print("baseline", 100.0 * math.sqrt(base_loss / denominator))
for row in rows[:30]:
    print(json.dumps(row))
