"""Run the frozen scorer's read-only GSAS-II replay for a local project."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys


parser = argparse.ArgumentParser()
parser.add_argument("project")
parser.add_argument("output_dir")
parser.add_argument("--observed", default="inputs/pattern.csv")
parser.add_argument("--histogram", default="PWDR pattern.csv")
args = parser.parse_args()

root = Path(__file__).resolve().parent
runtime = root / "learned/divalent-tungstates/scorer/runtime"
sys.path.insert(0, str(runtime))
from replay_worker import replay  # noqa: E402

project = Path(args.project).resolve()
observed = Path(args.observed).resolve()
output = Path(args.output_dir).resolve()
output.mkdir(parents=True, exist_ok=True)
os.chdir(output)
result = replay({"project": str(project), "observed": str(observed), "histogram": args.histogram})
Path("replay.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
print(json.dumps({"status": result["status"], "phases": len(result["phases"]), "output": str(output)}))
