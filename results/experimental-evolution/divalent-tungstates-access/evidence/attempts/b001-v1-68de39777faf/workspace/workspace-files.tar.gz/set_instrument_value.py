"""Set and freeze one GSAS-II instrument parameter without refinement."""

from __future__ import annotations

import argparse
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("key")
parser.add_argument("value", type=float)
args = parser.parse_args()

project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
instrument = project.histograms()[0].data["Instrument Parameters"][0]
if args.key not in instrument or not isinstance(instrument[args.key], list):
    raise KeyError(args.key)
instrument[args.key][1] = args.value
instrument[args.key][2] = False
project.save(str(Path(args.output).resolve()))
print(args.output, args.key, instrument[args.key])
