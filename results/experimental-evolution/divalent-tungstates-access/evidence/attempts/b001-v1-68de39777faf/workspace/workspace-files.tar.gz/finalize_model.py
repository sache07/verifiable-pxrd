"""Freeze the accepted GSAS-II model and export its active crystal structures.

This script deliberately changes no fitted numerical parameter.  It sets
discarded trial-phase scales to exact zero, clears refinement flags and stale
trial constraints, saves ``final.gpx``, and exports the 13 active phases.
"""

from __future__ import annotations

from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/X185_converged.gpx")
OUTPUT = Path("final.gpx")

INACTIVE = {
    "trial_mn2wo6_y",
    "trial_9001963",
    "trial_trig4342220",
    "Mn2WO6_trirutile",
}

EXPORTS = [
    ("MnWO4_wolframite", "phase_01_MnWO4_wolframite.cif"),
    ("trial_2311041", "phase_02_WO3_monoclinic.cif"),
    ("trial_hmno", "phase_03_MnO_hexagonal.cif"),
    ("Mn2WO6_P61", "phase_04_Mn2WO6_P61.cif"),
    ("MnWO4_scheelite", "phase_05_MnWO4_scheelite.cif"),
    ("MnW2O6_trirutile", "phase_06_MnW2O6_trirutile.cif"),
    ("MnW2O6_P4mmm", "phase_07_MnW2O6_Pmmm.cif"),
    ("Mn2WO6_trig_CoIO", "phase_08_Mn2WO6_P-31m.cif"),
    ("MnWO4_Pbcn", "phase_09_MnWO4_Pbcn.cif"),
    ("MnWO4_Cmmm", "phase_10_MnWO4_Cmmm.cif"),
    ("Mn2WO6_trirutile_TaCo", "phase_11_Mn2WO6_trirutile.cif"),
    ("P212_sf_free", "phase_12_Mn2WO6_P212121.cif"),
    ("test_Mn2WO6_Aea2", "phase_13_Mn2WO6_Aea2.cif"),
]


def set_false_flags(value):
    """Recursively clear booleans without touching numerical values."""
    if isinstance(value, list):
        for index, item in enumerate(value):
            if isinstance(item, bool):
                value[index] = False
            elif isinstance(item, (list, dict)):
                set_false_flags(item)
    elif isinstance(value, dict):
        for key, item in value.items():
            if isinstance(item, bool):
                # 'Use' and 'LeBail' have semantic meaning rather than being
                # refinement flags and are handled explicitly below.
                if key not in {"Use", "LeBail"}:
                    value[key] = False
            elif isinstance(item, (list, dict)):
                set_false_flags(item)


project = G2sc.G2Project(gpxfile=str(SOURCE))
histograms = project.histograms()
if len(histograms) != 1 or histograms[0].name != "PWDR pattern.csv":
    raise RuntimeError("Expected the single original powder histogram")
histogram = histograms[0]

# Freeze histogram-level refinables.
histogram.data["Background"][0][1] = False
for value in histogram.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and value and isinstance(value[-1], bool):
        value[-1] = False
for value in histogram.data["Sample Parameters"].values():
    if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
        value[1] = False

phase_names = {phase.name for phase in project.phases()}
expected = INACTIVE | {name for name, _ in EXPORTS}
if phase_names != expected:
    raise RuntimeError(f"Unexpected project phase inventory: {sorted(phase_names ^ expected)}")

for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""  # coordinate/occupancy/ADP refinement code
    hap = phase.data["Histograms"][histogram.name]
    if phase.name in INACTIVE:
        hap["Scale"] = [0.0, False]
    elif not (hap["Scale"][0] > 0):
        raise RuntimeError(f"Active phase has non-positive scale: {phase.name}")
    hap["Use"] = True
    hap["LeBail"] = False
    set_false_flags(hap)

# Trial branches left obsolete variable objects in these collections. They do
# not affect forward replay, but removing them makes the submitted project a
# clean, stable endpoint for inspection.
constraints = project.data["Constraints"]["data"]
for key in ("Hist", "HAP", "Phase", "Global"):
    constraints[key] = []
controls = project.data["Controls"]["data"]
controls["parmFrozen"] = {"FrozenList": []}
controls["parmMinDict"] = {}
controls["parmMaxDict"] = {}

project.save(str(OUTPUT))

# Export from the saved phase records with covariance removed, matching the
# scorer's read-only replay convention exactly.
export_project = G2sc.G2Project(gpxfile=str(OUTPUT))
export_project.data["Covariance"]["data"] = {}
for phase_name, filename in EXPORTS:
    export_project.phase(phase_name).export_CIF(filename)

print(f"saved {OUTPUT} and {len(EXPORTS)} active-phase CIFs")
