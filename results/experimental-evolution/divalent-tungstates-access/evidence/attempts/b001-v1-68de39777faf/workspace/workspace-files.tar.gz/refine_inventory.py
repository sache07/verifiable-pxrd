"""Run a controlled GSAS-II inventory refinement stage.

This helper intentionally exposes only the nuisance terms used while testing
the phase inventory.  Atomic coordinates, displacement parameters, texture,
and profile terms are held fixed unless a later dedicated stage enables them.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def fraction_rows(project, histogram):
    products = []
    rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        product = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        products.append(product)
        rows.append(
            {
                "name": phase.name,
                "scale": float(hap["Scale"][0]),
                "cell": [float(value) for value in phase.data["General"]["Cell"][1:7]],
                "mass_product": product,
                "size_um": float(hap["Size"][1][0]),
                "microstrain_ppm": float(hap["Mustrain"][1][0]),
            }
        )
    total = sum(max(value, 0.0) for value in products)
    for row, product in zip(rows, products):
        row["weight_fraction"] = max(product, 0.0) / total if total else float("nan")
    return rows


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--cells", default="", help="comma-separated phase names or 'all'")
parser.add_argument("--inactive", default="", help="comma-separated phases held at zero scale")
parser.add_argument("--zero", action="store_true")
parser.add_argument("--shift", action="store_true")
parser.add_argument("--map-zero-to-shift", action="store_true")
parser.add_argument("--cycles", type=int, default=30)
parser.add_argument("--repeats", type=int, default=1)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
selected_cells = {value for value in args.cells.split(",") if value}
inactive = {value for value in args.inactive.split(",") if value}
if selected_cells == {"all"}:
    selected_cells = {phase.name for phase in project.phases() if phase.name not in inactive}

instrument = histogram.data["Instrument Parameters"][0]
sample = histogram.data["Sample Parameters"]
if args.map_zero_to_shift:
    # At low angle, GSAS-II's Bragg-Brentano shift is approximately
    # -0.000573 deg/um for the 200 mm goniometer used here.
    radius = float(sample["Gonio. radius"])
    coefficient = -0.09 / (math.pi * radius) * 4.0
    sample["Shift"][0] += float(instrument["Zero"][1]) / coefficient
    instrument["Zero"][1] = 0.0

instrument["Zero"][2] = bool(args.zero)
sample["Shift"][1] = bool(args.shift)
for phase in project.phases():
    active = phase.name not in inactive
    phase.data["General"]["Cell"][0] = active and phase.name in selected_cells
    hap = phase.data["Histograms"][histogram.name]
    if active:
        hap["Scale"][1] = True
    else:
        hap["Scale"] = [0.0, False]
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6

histogram.data["Background"][0][1] = True
project.set_Controls("cycles", args.cycles)
project.save(str(Path(args.output).resolve()))
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": iteration + 1,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        }
    )

print(
    json.dumps(
        {
            "project": str(Path(args.output).resolve()),
            "history": history,
            "zero_deg": float(instrument["Zero"][1]),
            "shift_um": float(sample["Shift"][0]),
            "phases": fraction_rows(project, histogram),
        }
    )
)
