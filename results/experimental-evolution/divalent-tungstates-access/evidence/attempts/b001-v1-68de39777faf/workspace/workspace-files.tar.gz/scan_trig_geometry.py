"""Common-setting scale/background tests for physical P-31m oxygen positions."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2sc


SOURCE = Path(".tmp/X185_converged.gpx")
PHASE = "Mn2WO6_trig_CoIO"
INACTIVE = {
    "trial_mn2wo6_y",
    "trial_9001963",
    "trial_trig4342220",
    "Mn2WO6_trirutile",
}

# The first point is the accepted profile baseline.  All subsequent points
# clear the scorer's 1.8 A O--O review threshold and span the nearest physical
# boundary plus a modestly more separated interior.
POINTS = [
    (0.215, 0.354),
    (0.216, 0.338),
    (0.222, 0.340),
    (0.220, 0.338),
    (0.216, 0.336),
    (0.224, 0.338),
    (0.230, 0.344),
    (0.220, 0.330),
    (0.240, 0.340),
    (0.250, 0.340),
    (0.280, 0.320),
    (0.320, 0.290),
    (0.3565, 0.2677),
]


def freeze_profiles(project, histogram):
    histogram.data["Background"][0][1] = True
    for value in histogram.data["Instrument Parameters"][0].values():
        if isinstance(value, list) and value and isinstance(value[-1], bool):
            value[-1] = False
    for value in histogram.data["Sample Parameters"].values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        hap = phase.data["Histograms"][histogram.name]
        hap["Scale"] = [0.0, False] if phase.name in INACTIVE else [float(hap["Scale"][0]), True]
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])
        hap["Extinction"][1] = False
        for value in hap["Babinet"].values():
            value[1] = False
        for atom in phase.data["Atoms"]:
            atom[2] = ""
    constraints = project.data["Constraints"]["data"]
    for key in ("Hist", "HAP", "Phase", "Global"):
        constraints[key] = []
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}


G2sc.SetPrintLevel("warn")
results = []
for y, z in POINTS:
    project = G2sc.G2Project(gpxfile=str(SOURCE))
    histogram = project.histograms()[0]
    freeze_profiles(project, histogram)
    phase = project.phase(PHASE)
    oxygens = [atom for atom in phase.data["Atoms"] if atom[1] == "O"]
    if len(oxygens) != 1:
        raise RuntimeError("Expected one independent oxygen site")
    oxygens[0][3:6] = [0.0, y, z]
    output = Path(f".tmp/trig_geometry_y{y:.4f}_z{z:.4f}.gpx")
    project.set_Controls("cycles", 40)
    project.save(str(output))
    for _ in range(2):
        project.refine()
        project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    products = []
    for item in project.phases():
        hap = item.data["Histograms"][histogram.name]
        products.append(max(0.0, float(hap["Scale"][0])) * float(item.data["General"]["Mass"]))
    target_index = [item.name for item in project.phases()].index(PHASE)
    results.append(
        {
            "oxygen_y": y,
            "oxygen_z": z,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
            "phase_weight_fraction": products[target_index] / sum(products),
            "project": str(output),
        }
    )

print(json.dumps(results, indent=2, allow_nan=False))
