from pathlib import Path
import argparse
import gzip
import json
import math
import sys
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Element, Structure
from scipy.optimize import minimize_scalar


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06")
INDEX = ROOT / "index.json.gz"
CIF_ROOT = ROOT / "cif"
parser = argparse.ArgumentParser()
parser.add_argument("--arrays", default=".tmp/three_arrays.npz")
parser.add_argument("--output", default=".tmp/prototype_screen.json")
parser.add_argument("--out-dir", default=".tmp/prototypes")
args = parser.parse_args()

OUT = Path(args.out_dir)
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model  # noqa: E402


TARGETS = {"MnWO4", "Mn2WO6", "Mn3WO6", "Mn3W2O9", "Mn2(WO4)3"}
with gzip.open(INDEX, "rt") as stream:
    index = json.load(stream)
with np.load(args.arrays) as arrays:
    x = arrays["x"].copy()
    observed = arrays["observed"].copy() if "observed" in arrays.files else arrays["y"].copy()
    if "predicted" in arrays.files:
        calculated = arrays["predicted"].copy()
    elif "calculated" in arrays.files:
        calculated = arrays["calculated"].copy()
    else:
        calculated = arrays["calc"].copy()
residual = observed - calculated
weight = 1.0 / np.maximum(observed, 1.0)
denominator = float(np.sum(weight * observed**2))
baseline_loss = float(np.sum(weight * residual**2))
baseline_rwp = 100.0 * math.sqrt(baseline_loss / denominator)
calculator = XRDCalculator(wavelength=1.540598)


def cif_path(record_id):
    return CIF_ROOT / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def mapped_formula(formula, other):
    values = Composition(formula).element_composition.get_el_amt_dict()
    amount = values.pop(other, 0.0)
    if amount <= 0 or set(values) - {"W", "O"}:
        return None
    return Composition({"Mn": amount, **values}).reduced_formula


def candidate_profile(angles, intensities, lattice_scale):
    sine = np.sin(np.deg2rad(angles / 2.0)) / lattice_scale
    valid = (sine > 0) & (sine < 1)
    centers = np.rad2deg(2.0 * np.arcsin(sine[valid]))
    intensities = intensities[valid]
    profile = np.zeros_like(x)
    # The observed phase peaks broaden strongly with angle. This approximation
    # is only a shortlist screen; accepted candidates are tested in GSAS-II.
    for center, intensity in zip(centers, intensities):
        sigma = 0.045 + 0.0042 * center
        lo = np.searchsorted(x, center - 4.5 * sigma)
        hi = np.searchsorted(x, center + 4.5 * sigma)
        if hi > lo:
            z = (x[lo:hi] - center) / sigma
            profile[lo:hi] += intensity * np.exp(-0.5 * z * z)
    maximum = float(profile.max(initial=0.0))
    return profile / maximum if maximum > 0 else profile


def fit_profile(angles, intensities, lattice_scale):
    profile = candidate_profile(angles, intensities, lattice_scale)
    norm = float(np.sum(weight * profile * profile))
    amplitude = max(0.0, float(np.sum(weight * profile * residual)) / norm) if norm else 0.0
    trial_residual = residual - amplitude * profile
    loss = float(np.sum(weight * trial_residual**2))
    return loss, amplitude, profile


records = []
seen = set()
for key, rows in index.items():
    elements = key.split("-")
    if "W" not in elements or "O" not in elements or len(elements) != 3:
        continue
    other = next(element for element in elements if element not in {"W", "O"})
    # Restrict the analogue operation to a chemically meaningful cation site.
    try:
        if other in {"H", "C", "N", "P", "S", "F", "Cl", "Br", "I"}:
            continue
        Element(other)
    except Exception:
        continue
    for formula, record_id, space_group, source_r in rows:
        try:
            target = mapped_formula(formula, other)
        except Exception:
            continue
        if target not in TARGETS or (target, record_id) in seen:
            continue
        seen.add((target, record_id))
        source = cif_path(record_id)
        row = {
            "record_id": record_id,
            "source_formula": formula,
            "target_formula": target,
            "substitution": f"{other}->Mn",
            "space_group_number_index": space_group,
            "source_r": source_r,
            "status": "pending",
        }
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                structure = Structure.from_file(source, primitive=False)
            # Replace oxidation-state-bearing and mixed sites explicitly; a
            # mapping keyed only by neutral Element does not match Species Y3+.
            for site_index, site in enumerate(list(structure)):
                species = {}
                changed = False
                for specie, occupancy in site.species.items():
                    symbol = specie.element.symbol if hasattr(specie, "element") else specie.symbol
                    target_symbol = "Mn" if symbol == other else symbol
                    changed |= symbol == other
                    species[target_symbol] = species.get(target_symbol, 0.0) + float(occupancy)
                if changed:
                    structure.replace(site_index, species, coords=site.frac_coords,
                                      properties=site.properties)
            if other in structure.symbol_set or "Mn" not in structure.symbol_set:
                raise ValueError(f"substitution {other}->Mn did not produce the target species")
            structure.remove_oxidation_states()
            target_path = OUT / f"{target.replace('(', '').replace(')', '')}_{record_id}.cif"
            write_synthetic_model(structure, target_path)
            centers, neighbors, _, distances = structure.get_neighbor_list(3.0)
            positive = distances[distances > 1e-8]
            minimum_contact = float(positive.min()) if len(positive) else None
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                pattern = calculator.get_pattern(structure, two_theta_range=(8.0, 110.0), scaled=False)
            angles = np.asarray(pattern.x, float)
            intensities = np.asarray(pattern.y, float)
            optimum = minimize_scalar(
                lambda scale: fit_profile(angles, intensities, float(scale))[0],
                method="bounded",
                bounds=(0.78, 1.22),
                options={"xatol": 2e-5, "maxiter": 80},
            )
            loss, amplitude, profile = fit_profile(angles, intensities, float(optimum.x))
            improvement = baseline_loss - loss
            predicted_rwp = 100.0 * math.sqrt(max(loss, 0.0) / denominator)
            strongest = np.argsort(intensities)[::-1][:12]
            transformed = np.rad2deg(
                2.0 * np.arcsin(np.clip(np.sin(np.deg2rad(angles[strongest] / 2.0)) / optimum.x, 0, 1))
            )
            row.update(
                status="screened",
                cif_path=str(target_path),
                atom_count=len(structure),
                density_g_cm3=float(structure.density),
                minimum_contact_A=minimum_contact,
                lattice_scale=float(optimum.x),
                maximum_length_change_fraction=abs(float(optimum.x) - 1.0),
                fitted_profile_amplitude_counts=amplitude,
                approximate_rwp_percent=predicted_rwp,
                approximate_chi_square_improvement=improvement,
                strongest_transformed_peaks_deg=[float(value) for value in transformed],
            )
        except Exception as exc:
            row.update(status="unknown", error=repr(exc))
        records.append(row)

records.sort(key=lambda row: row.get("approximate_rwp_percent", float("inf")))
report = {
    "baseline_rwp_percent": baseline_rwp,
    "scope": "Analogue-substitution shortlist screen; candidates require GSAS-II testing and physical review.",
    "records": records,
}
Path(args.output).write_text(json.dumps(report, indent=2) + "\n")
for row in records[:30]:
    print(json.dumps(row))
