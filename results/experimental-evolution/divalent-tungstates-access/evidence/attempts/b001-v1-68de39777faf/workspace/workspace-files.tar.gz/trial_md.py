from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project_path = Path(sys.argv[1]).resolve()
axis = [int(v) for v in sys.argv[2:5]]
project = G2.G2Project(gpxfile=str(project_path))
phase = project.phase("MnWO4_wolframite")
histogram = project.histograms()[0]
hap = phase.data["Histograms"][histogram.name]
hap["Pref.Ori."][0] = "MD"
hap["Pref.Ori."][1] = 1.0
hap["Pref.Ori."][2] = True
hap["Pref.Ori."][3] = axis
project.set_Controls("cycles", 30)
project.refine()
project.save()
print(json.dumps({
    "project": str(project_path),
    "axis": axis,
    "ratio": hap["Pref.Ori."][1],
    "rwp": project.data["Covariance"]["data"]["Rvals"]["Rwp"],
    "converged": project.data["Covariance"]["data"]["Rvals"].get("converged"),
}))
