"""Replace CIF lattice lengths while preserving angles and fractional coordinates."""

from __future__ import annotations

import argparse

from pymatgen.core import Lattice, Structure


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("a", type=float)
parser.add_argument("b", type=float)
parser.add_argument("c", type=float)
args = parser.parse_args()

structure = Structure.from_file(args.input, primitive=False)
alpha, beta, gamma = structure.lattice.angles
lattice = Lattice.from_parameters(args.a, args.b, args.c, alpha, beta, gamma)
updated = Structure(
    lattice,
    [site.species for site in structure],
    [site.frac_coords for site in structure],
    site_properties=structure.site_properties,
)
updated.to(filename=args.output, fmt="cif", symprec=1e-5)
print(args.output, updated.composition.reduced_formula, updated.lattice, updated.density)
