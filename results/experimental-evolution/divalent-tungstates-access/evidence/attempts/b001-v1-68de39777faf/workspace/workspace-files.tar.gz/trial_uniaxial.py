"""Test one symmetry-supported uniaxial microstrain axis."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("phase")
parser.add_argument("axis", help="comma-separated h,k,l")
parser.add_argument("--inactive", default="", help="comma-separated phases held at zero scale")
parser.add_argument("--equatorial", type=float, default=6000.0)
parser.add_argument("--axial", type=float, default=12000.0)
parser.add_argument("--fixed", action="store_true", help="hold the two strain values fixed while refitting scales/background")
parser.add_argument("--cycles", type=int, default=45)
parser.add_argument("--repeats", type=int, default=2)
args = parser.parse_args()

axis = [int(value) for value in args.axis.split(",")]
if len(axis) != 3:
    raise ValueError("axis must have three indices")

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
inactive = {name for name in args.inactive.split(",") if name}
histogram.data["Background"][0][1] = True
for value in histogram.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = False
histogram.data["Sample Parameters"]["Shift"][1] = False

for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    if phase.name in inactive:
        hap["Scale"] = [0.0, False]
    else:
        hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    if phase.name == args.phase:
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][0] = args.equatorial
        hap["Mustrain"][1][1] = args.axial
        hap["Mustrain"][2] = [not args.fixed, not args.fixed, False]
        hap["Mustrain"][3] = axis
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6

project.set_Controls("cycles", args.cycles)
project.save(str(Path(args.output).resolve()))
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": iteration + 1,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        }
    )

phase = project.phase(args.phase)
hap = phase.data["Histograms"][histogram.name]
print(
    json.dumps(
        {
            "project": str(Path(args.output).resolve()),
            "history": history,
            "axis": hap["Mustrain"][3],
            "equatorial_ppm": float(hap["Mustrain"][1][0]),
            "axial_ppm": float(hap["Mustrain"][1][1]),
            "axial_ratio": float(hap["Mustrain"][1][1] / hap["Mustrain"][1][0]),
        }
    )
)
