"""Test one March-Dollase texture axis for a named phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("phase")
parser.add_argument("axis")
parser.add_argument("--inactive", default="", help="comma-separated phases held at zero scale")
parser.add_argument("--continue-existing", action="store_true", help="retain the candidate's current ratio and axis")
parser.add_argument("--fixed-ratio", type=float, help="set and hold a specified MD ratio")
parser.add_argument("--cycles", type=int, default=40)
parser.add_argument("--repeats", type=int, default=2)
args = parser.parse_args()
axis = [int(value) for value in args.axis.split(",")]

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
histogram.data["Background"][0][1] = True
for value in histogram.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = False
histogram.data["Sample Parameters"]["Shift"][1] = False
inactive = {name for name in args.inactive.split(",") if name}
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    if phase.name in inactive:
        hap["Scale"] = [0.0, False]
    else:
        hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    if phase.name == args.phase:
        hap["Pref.Ori."][0] = "MD"
        if args.fixed_ratio is not None:
            hap["Pref.Ori."][1] = float(args.fixed_ratio)
        elif not args.continue_existing:
            hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = args.fixed_ratio is None
        if not args.continue_existing:
            hap["Pref.Ori."][3] = axis
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6

project.set_Controls("cycles", args.cycles)
project.save(str(Path(args.output).resolve()))
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": iteration + 1,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        }
    )

hap = project.phase(args.phase).data["Histograms"][histogram.name]
print(json.dumps({"project": str(Path(args.output).resolve()), "history": history, "axis": axis, "ratio": float(hap["Pref.Ori."][1])}))
