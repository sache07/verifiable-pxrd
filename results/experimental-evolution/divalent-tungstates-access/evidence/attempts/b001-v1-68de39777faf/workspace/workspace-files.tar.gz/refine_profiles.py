"""Refine selected phase profile terms with structural terms held fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--phases", required=True, help="comma-separated names or 'all'")
parser.add_argument("--inactive", default="", help="comma-separated phases held at zero scale")
parser.add_argument("--size", action="store_true")
parser.add_argument("--strain", action="store_true")
parser.add_argument("--cycles", type=int, default=40)
parser.add_argument("--repeats", type=int, default=2)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
selected = {name for name in args.phases.split(",") if name}
inactive = {name for name in args.inactive.split(",") if name}
if selected == {"all"}:
    selected = {phase.name for phase in project.phases() if phase.name not in inactive}

histogram.data["Background"][0][1] = True
histogram.data["Instrument Parameters"][0]["Zero"][2] = False
histogram.data["Sample Parameters"]["Shift"][1] = False
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    if phase.name in inactive:
        hap["Scale"] = [0.0, False]
    else:
        hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][2] = [bool(args.size and phase.name in selected), False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][2] = [bool(args.strain and phase.name in selected), False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6

project.set_Controls("cycles", args.cycles)
project.save(str(Path(args.output).resolve()))
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": iteration + 1,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        }
    )

rows = []
products = []
for phase in project.phases():
    hap = phase.data["Histograms"][histogram.name]
    product = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
    products.append(product)
    rows.append(
        {
            "name": phase.name,
            "size_um": float(hap["Size"][1][0]),
            "microstrain_ppm": float(hap["Mustrain"][1][0]),
            "mass_product": product,
        }
    )
total = sum(max(value, 0.0) for value in products)
for row, value in zip(rows, products):
    row["weight_fraction"] = max(value, 0.0) / total

print(json.dumps({"project": str(Path(args.output).resolve()), "history": history, "phases": rows}))
