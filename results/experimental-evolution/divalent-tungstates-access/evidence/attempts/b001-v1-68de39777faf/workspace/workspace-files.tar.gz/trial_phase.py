from pathlib import Path
import json
import math
import sys

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project_path = Path(sys.argv[1]).resolve()
cif_path = Path(sys.argv[2]).resolve()
record_id = sys.argv[3]

project = G2.G2Project(gpxfile=str(project_path))
histogram = project.histograms()[0]
main = project.phase("MnWO4_wolframite")
trial_name = f"trial_{record_id}"
trial = project.add_phase(
    str(cif_path), phasename=trial_name, histograms=[histogram], fmthint="CIF"
)

# Screen all candidates with the same fixed isotropic profile and scalar ADP.
main_hap = main.data["Histograms"][histogram.name]
trial_hap = trial.data["Histograms"][histogram.name]
trial_hap["Size"][0] = "isotropic"
trial_hap["Size"][1][0] = main_hap["Size"][1][0]
trial_hap["Size"][2] = [False] * len(trial_hap["Size"][2])
trial_hap["Mustrain"][0] = "isotropic"
trial_hap["Mustrain"][1][0] = main_hap["Mustrain"][1][0]
trial_hap["Mustrain"][2] = [False] * len(trial_hap["Mustrain"][2])
trial_hap["Mustrain"][5] = [False] * len(trial_hap["Mustrain"][5])
trial_hap["Pref.Ori."][2] = False
trial.data["General"]["Cell"][0] = False
for atom in trial.data["Atoms"]:
    atom[2] = ""
    atom[9] = "I"
    atom[10] = 0.005
    atom[11:17] = [0.0] * 6

main_mass = float(main.data["General"]["Mass"])
trial_mass = float(trial.data["General"]["Mass"])
main_scale = float(main_hap["Scale"][0])
trial_hap["Scale"] = [main_scale * (0.02 / 0.98) * main_mass / trial_mass, True]

def summary(stage):
    phases = []
    masses = []
    for phase in project.phases():
        hap = phase.data["Histograms"][histogram.name]
        mass_product = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
        masses.append(mass_product)
        phases.append({
            "name": phase.name,
            "scale": float(hap["Scale"][0]),
            "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
            "mass_product": mass_product,
        })
    total = sum(masses)
    for row, value in zip(phases, masses):
        row["weight_fraction"] = value / total if total > 0 else None
    rvals = project.data["Covariance"]["data"]["Rvals"]
    return {
        "stage": stage,
        "rwp": float(rvals["Rwp"]),
        "converged": bool(rvals.get("converged", False)),
        "phases": phases,
    }

project.set_Controls("cycles", 20)
project.refine()
stage1 = summary("scale_background")
trial_row = next(row for row in stage1["phases"] if row["name"] == trial_name)

result = {"record_id": record_id, "project": str(project_path), "stage1": stage1}
if trial_row["scale"] <= 0 or trial_row["weight_fraction"] is None or trial_row["weight_fraction"] < 1e-5:
    result["status"] = "rejected_scale_collapse"
else:
    before = trial_row["cell"]
    trial.data["General"]["Cell"][0] = True
    try:
        project.set_Controls("cycles", 25)
        project.refine()
        stage2 = summary("candidate_cell")
        result["stage2"] = stage2
        after = next(row for row in stage2["phases"] if row["name"] == trial_name)["cell"]
        distortion = max(abs(a / b - 1.0) for a, b in zip(after[:3], before[:3]))
        result["maximum_length_change_fraction"] = distortion
        result["status"] = "tested" if all(math.isfinite(v) and v > 0 for v in after[:3]) else "unknown_invalid_cell"
    except Exception as exc:
        result["status"] = "unknown_refinement_failure"
        result["error"] = repr(exc)

project.save()
print(json.dumps(result))
