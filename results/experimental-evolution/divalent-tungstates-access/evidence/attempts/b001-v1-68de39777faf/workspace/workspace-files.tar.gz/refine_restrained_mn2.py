"""Coordinate refinement of the Mn2WO6 analogue with bond restraints."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


W_O = {
    "O3": [1.865322],
    "O4": [1.751979],
    "O5": [1.792736],
    "O6": [1.832267],
    "O7": [1.870103],
    "O8": [1.941061],
}
MN_O = {
    "Mn0": {
        "O3": [2.087656, 2.202394],
        "O4": [2.225246],
        "O5": [2.296082],
        "O6": [2.198219],
        "O7": [2.460554],
        "O8": [2.189128],
    },
    "Mn1": {
        "O4": [2.210032],
        "O5": [2.252326],
        "O6": [2.245342],
        "O7": [2.176473, 2.313087],
        "O8": [2.216574, 2.303712],
    },
}

parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--mode", choices=["W", "WO", "all"], required=True)
parser.add_argument("--weight", type=float, default=1000.0)
parser.add_argument("--esd", type=float, default=0.03)
parser.add_argument("--cycles", type=int, default=50)
parser.add_argument("--repeats", type=int, default=2)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
histogram.data["Background"][0][1] = True
for value in histogram.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = False
histogram.data["Sample Parameters"]["Shift"][1] = False

target_phase = project.phase("trial_mn2wo6_y")
project.data.setdefault("Restraints", {"data": {}}).setdefault("data", {}).setdefault(
    target_phase.name,
    {"Bond": {"wtFactor": 1.0, "Range": 1.1, "Bonds": [], "Use": True}},
)
target_phase.clearDistRestraint()
count = 0
for oxygen, distances in W_O.items():
    for distance in distances:
        count += target_phase.addDistRestraint(
            ["W2"], [oxygen], distance, factor=1.012, ESD=args.esd
        )
if args.mode == "all":
    for manganese, oxygen_rows in MN_O.items():
        for oxygen, distances in oxygen_rows.items():
            for distance in distances:
                count += target_phase.addDistRestraint(
                    [manganese], [oxygen], distance, factor=1.008, ESD=args.esd
                )
target_phase.setDistRestraintWeight(args.weight)

selected = {"W"}
if args.mode in {"WO", "all"}:
    selected.add("O")
if args.mode == "all":
    selected.add("Mn")
initial = {}
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6
        if phase.name == target_phase.name:
            initial[atom[0]] = [float(value) for value in atom[3:6]]
            if atom[1] in selected:
                atom[2] = "X"

project.set_Controls("cycles", args.cycles)
project.save(str(Path(args.output).resolve()))
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": iteration + 1,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
            "restraint_sum": float(rvals.get("RestraintSum", 0.0)),
        }
    )

atoms = []
for atom in target_phase.data["Atoms"]:
    if atom[2]:
        atoms.append(
            {
                "label": atom[0],
                "initial_fractional": initial[atom[0]],
                "refined_fractional": [float(value) for value in atom[3:6]],
            }
        )
print(json.dumps({"project": str(Path(args.output).resolve()), "restraint_count": count, "history": history, "atoms": atoms}))
