"""Copy a GSAS-II project and set one named phase scale without refining."""

from __future__ import annotations

import argparse
from pathlib import Path
import shutil

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("phase")
parser.add_argument("scale", type=float)
args = parser.parse_args()

if args.scale < 0:
    raise ValueError("phase scale must be nonnegative")
source = Path(args.input).resolve()
target = Path(args.output).resolve()
if source != target:
    shutil.copy2(source, target)
project = G2.G2Project(gpxfile=str(target))
histogram = project.histograms()[0]
hap = project.phase(args.phase).data["Histograms"][histogram.name]
hap["Scale"] = [float(args.scale), False]
project.save(str(target))
print(target, args.phase, hap["Scale"])
