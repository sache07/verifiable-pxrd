from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


G2.SetPrintLevel("warn")
project_path = Path(sys.argv[1]).resolve()
trial_name = sys.argv[2]
project = G2.G2Project(gpxfile=str(project_path))
histogram = project.histograms()[0]
main = project.phase("MnWO4_wolframite")
trial = project.phase(trial_name)

for phase in (main, trial):
    phase.data["General"]["Cell"][0] = True
    for atom in phase.data["Atoms"]:
        atom[2] = "U"
        atom[9] = "I"
        atom[11:17] = [0.0] * 6
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][1] = True
    hap["Size"][0] = "isotropic"
    hap["Size"][2] = [True, False, False]
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][2] = [True, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False

# The registered generator models use one scalar Uiso for every site in a phase.
project.save()
if len(trial.data["Atoms"]) > 1:
    project.add_EquivConstr(
        [f"1::AUiso:{i}" for i in range(len(trial.data["Atoms"]))]
    )

project.set_Controls("cycles", 40)
project.refine()
project.save()

mass_products = []
rows = []
for phase in (main, trial):
    hap = phase.data["Histograms"][histogram.name]
    mass_product = float(hap["Scale"][0]) * float(phase.data["General"]["Mass"])
    mass_products.append(mass_product)
    rows.append({
        "name": phase.name,
        "scale": float(hap["Scale"][0]),
        "cell": [float(v) for v in phase.data["General"]["Cell"][1:7]],
        "size_um": float(hap["Size"][1][0]),
        "microstrain_ppm": float(hap["Mustrain"][1][0]),
        "uiso_A2": float(phase.data["Atoms"][0][10]),
    })
total = sum(mass_products)
for row, value in zip(rows, mass_products):
    row["weight_fraction"] = value / total
rvals = project.data["Covariance"]["data"]["Rvals"]
print(json.dumps({
    "project": str(project_path),
    "rwp": float(rvals["Rwp"]),
    "converged": bool(rvals.get("converged", False)),
    "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
    "phases": rows,
}))
