"""Residual screen of one- and two-substitution ABO4 frameworks for MnWO4."""

from __future__ import annotations

import argparse
import gzip
import json
import math
from pathlib import Path
import sys
import warnings

import numpy as np
from pymatgen.analysis.diffraction.xrd import XRDCalculator
from pymatgen.core import Composition, Structure
from scipy.optimize import minimize_scalar


ROOT = Path("<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/resources/b001-c06")
parser = argparse.ArgumentParser()
parser.add_argument("--arrays", required=True)
parser.add_argument("--output", required=True)
parser.add_argument("--out-dir", required=True)
parser.add_argument("--shift-um", type=float, default=-717.3)
args = parser.parse_args()
out_dir = Path(args.out_dir)
out_dir.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(Path("learned/divalent-tungstates/runtime").resolve()))
from models import write_synthetic_model  # noqa: E402

with gzip.open(ROOT / "index.json.gz", "rt") as stream:
    catalog = json.load(stream)
with np.load(args.arrays) as arrays:
    x = np.asarray(arrays["x"], float)
    observed = np.asarray(arrays["observed"], float)
    calculated = np.asarray(arrays["predicted"] if "predicted" in arrays.files else arrays["calculated"], float)

residual = observed - calculated
weight = 1.0 / np.maximum(observed, 1.0)
denominator = float(np.sum(weight * observed**2))
base_loss = float(np.sum(weight * residual**2))
calculator = XRDCalculator(wavelength=1.540598)
lam1, lam2 = 1.540598, 1.544426
radius_mm = 200.0


def source_path(record_id):
    return ROOT / "cif" / record_id[0] / record_id[1:3] / record_id[3:5] / f"{record_id}.cif"


def possible_mappings(formula):
    values = Composition(formula).element_composition.get_el_amt_dict()
    oxygen = values.pop("O", 0.0)
    if len(values) != 2:
        return []
    items = sorted(values.items())
    if min(value for _, value in items) <= 0:
        return []
    scale = 1.0 / items[0][1]
    if abs(items[1][1] * scale - 1.0) > 1e-5 or abs(oxygen * scale - 4.0) > 1e-5:
        return []
    (a, _), (b, _) = items
    return [{a: "Mn", b: "W"}, {a: "W", b: "Mn"}]


def displaced(center):
    theta = np.deg2rad(center / 2.0)
    return center - 0.09 / (np.pi * radius_mm) * 4.0 * args.shift_um * np.cos(theta)


def profile(angles, intensities, lattice_scale):
    sine1 = np.sin(np.deg2rad(angles / 2.0)) / lattice_scale
    valid = (sine1 > 0.0) & (sine1 < 1.0)
    sine1 = sine1[valid]
    values = intensities[valid]
    centers1 = displaced(np.rad2deg(2.0 * np.arcsin(sine1)))
    sine2 = sine1 * lam2 / lam1
    valid2 = sine2 < 1.0
    centers = np.concatenate([centers1, displaced(np.rad2deg(2.0 * np.arcsin(sine2[valid2])))])
    values = np.concatenate([values, 0.5 * values[valid2]])
    result = np.zeros_like(x)
    for center, intensity in zip(centers, values):
        sigma = 0.065 + 0.0022 * center
        lo = int(np.searchsorted(x, center - 4.5 * sigma))
        hi = int(np.searchsorted(x, center + 4.5 * sigma))
        if hi > lo:
            z = (x[lo:hi] - center) / sigma
            result[lo:hi] += intensity * np.exp(-0.5 * z * z)
    maximum = float(result.max(initial=0.0))
    return result / maximum if maximum > 0.0 else result


def score(angles, intensities, lattice_scale):
    candidate = profile(angles, intensities, lattice_scale)
    norm = float(np.sum(weight * candidate**2))
    amplitude = max(0.0, float(np.sum(weight * candidate * residual)) / norm) if norm else 0.0
    loss = float(np.sum(weight * (residual - amplitude * candidate) ** 2))
    return loss, amplitude


rows = []
seen = set()
for records in catalog.values():
    for formula, record_id, space_group, source_r in records:
        for mapping in possible_mappings(formula):
            key = (record_id, tuple(sorted(mapping.items())))
            if key in seen:
                continue
            seen.add(key)
            tag = "_".join(f"{source}-{target}" for source, target in sorted(mapping.items()))
            row = {
                "record_id": record_id,
                "source_formula": formula,
                "space_group": space_group,
                "mapping": mapping,
                "source_r": source_r,
                "status": "pending",
            }
            try:
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    structure = Structure.from_file(source_path(record_id), primitive=False)
                for site_index, site in enumerate(list(structure)):
                    species = {}
                    for specie, occupancy in site.species.items():
                        symbol = specie.element.symbol if hasattr(specie, "element") else specie.symbol
                        target = mapping.get(symbol, symbol)
                        species[target] = species.get(target, 0.0) + float(occupancy)
                    structure.replace(site_index, species, coords=site.frac_coords, properties=site.properties)
                structure.remove_oxidation_states()
                if structure.composition.reduced_formula != "MnWO4":
                    raise ValueError(f"mapped composition is {structure.composition.reduced_formula}")
                cif = out_dir / f"MnWO4_{record_id}_{tag}.cif"
                write_synthetic_model(structure, cif)
                with warnings.catch_warnings():
                    warnings.simplefilter("ignore")
                    pattern = calculator.get_pattern(structure, two_theta_range=(8.0, 105.0), scaled=False)
                angles = np.asarray(pattern.x, float)
                intensities = np.asarray(pattern.y, float)
                optimum = minimize_scalar(
                    lambda value: score(angles, intensities, float(value))[0],
                    method="bounded",
                    bounds=(0.72, 1.28),
                    options={"xatol": 1e-5, "maxiter": 90},
                )
                loss, amplitude = score(angles, intensities, float(optimum.x))
                screened = structure.copy()
                screened.scale_lattice(screened.volume * float(optimum.x) ** 3)
                shells = {}
                for element in ("Mn", "W"):
                    distances = []
                    for site in screened:
                        if site.specie.symbol != element:
                            continue
                        oxygen = sorted(
                            float(neighbor.nn_distance)
                            for neighbor in screened.get_neighbors(site, 3.2)
                            if neighbor.specie.symbol == "O"
                        )
                        distances.extend(oxygen[:8])
                    shells[element] = {
                        "minimum_A": min(distances) if distances else None,
                        "maximum_first8_A": max(distances) if distances else None,
                    }
                _, _, _, contacts = screened.get_neighbor_list(1.8)
                row.update(
                    status="screened",
                    cif_path=str(cif),
                    lattice_scale=float(optimum.x),
                    amplitude_counts=float(amplitude),
                    approximate_rwp=100.0 * math.sqrt(loss / denominator),
                    improvement=base_loss - loss,
                    atom_count=len(screened),
                    density_g_cm3=float(screened.density),
                    cation_oxygen=shells,
                    contacts_below_1p8_A=int(len(contacts)),
                    minimum_contact_A=float(contacts.min()) if len(contacts) else None,
                )
            except Exception as exc:
                row.update(status="unknown", error=repr(exc))
            rows.append(row)

rows.sort(key=lambda row: row.get("approximate_rwp", float("inf")))
Path(args.output).write_text(json.dumps(rows, indent=2) + "\n")
print("baseline", 100.0 * math.sqrt(base_loss / denominator), "candidates", len(rows))
for row in rows[:60]:
    print(json.dumps(row))
