"""Refine one scalar isotropic displacement parameter for a selected phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("phase")
parser.add_argument("--inactive", default="", help="comma-separated phases held at zero scale")
parser.add_argument("--minimum", type=float, default=0.003)
parser.add_argument("--maximum", type=float, default=0.020)
parser.add_argument("--cycles", type=int, default=40)
parser.add_argument("--repeats", type=int, default=2)
args = parser.parse_args()
if not 0.0 <= args.minimum < args.maximum:
    raise ValueError("Uiso bounds must satisfy 0 <= minimum < maximum")

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
histogram.data["Background"][0][1] = True
for value in histogram.data["Instrument Parameters"][0].values():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = False
histogram.data["Sample Parameters"]["Shift"][1] = False

selected = project.phase(args.phase)
inactive = {name for name in args.inactive.split(",") if name}
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    if phase.name in inactive:
        hap["Scale"] = [0.0, False]
    else:
        hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6
        if phase.name == selected.name:
            atom[2] = "U"

for index in range(len(selected.data["Atoms"])):
    variable = f"{selected.data['pId']}::AUiso:{index}"
    project.set_Controls("parmMin", args.minimum, variable=variable)
    project.set_Controls("parmMax", args.maximum, variable=variable)

project.save(str(Path(args.output).resolve()))
if len(selected.data["Atoms"]) > 1:
    project.add_EquivConstr(
        [f"{selected.data['pId']}::AUiso:{index}" for index in range(len(selected.data["Atoms"]))]
    )
project.set_Controls("cycles", args.cycles)
project.save()
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": iteration + 1,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        }
    )

print(
    json.dumps(
        {
            "project": str(Path(args.output).resolve()),
            "history": history,
            "uiso_A2": float(selected.data["Atoms"][0][10]),
            "frozen": project.get_Frozen(),
        }
    )
)
