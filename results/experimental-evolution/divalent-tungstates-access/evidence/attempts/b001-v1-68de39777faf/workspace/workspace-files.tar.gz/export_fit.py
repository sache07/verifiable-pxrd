"""Export the complete observed/calculated/difference profile from replay."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np


replay_dir = Path(".tmp/replay_final")
with np.load(replay_dir / "prediction.npz", allow_pickle=False) as data:
    x = data["x"]
    observed = data["observed"]
    calculated = data["predicted"]

public = np.loadtxt("inputs/pattern.csv", delimiter=",", skiprows=1, ndmin=2)
if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
    raise RuntimeError("Replay profile does not use the complete public data grid")

difference = observed - calculated
np.savetxt(
    "fit.csv",
    np.column_stack((x, observed, calculated, difference)),
    delimiter=",",
    header="two_theta_deg,observed,calculated,difference_observed_minus_calculated",
    comments="",
    fmt="%.15g",
)

weights = 1.0 / np.maximum(observed, 1.0)
loss = float(np.sum(weights * difference**2))
denominator = float(np.sum(weights * observed**2))
statistics = {
    "Rwp_percent": 100.0 * (loss / denominator) ** 0.5,
    "Rp_percent": 100.0 * float(np.sum(np.abs(difference)) / np.sum(observed)),
    "weighted_chi_square": loss,
    "n_observations": int(len(x)),
}
(replay_dir / "fit_statistics.json").write_text(
    json.dumps(statistics, indent=2, allow_nan=False) + "\n"
)
print(json.dumps(statistics, sort_keys=True))
