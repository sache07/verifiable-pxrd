"""Refine selected shared instrument terms with phase terms held fixed."""

from __future__ import annotations

import argparse
import json
import numbers
from pathlib import Path

from GSASII import GSASIIscriptable as G2


parser = argparse.ArgumentParser()
parser.add_argument("input")
parser.add_argument("output")
parser.add_argument("--terms", required=True, help="comma-separated instrument keys")
parser.add_argument("--cycles", type=int, default=40)
parser.add_argument("--repeats", type=int, default=2)
args = parser.parse_args()

G2.SetPrintLevel("warn")
project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
histogram = project.histograms()[0]
selected = set(args.terms.split(","))
instrument = histogram.data["Instrument Parameters"][0]
for key, value in instrument.items():
    if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool):
        value[2] = key in selected
histogram.data["Sample Parameters"]["Shift"][1] = False
histogram.data["Background"][0][1] = True
for phase in project.phases():
    phase.data["General"]["Cell"][0] = False
    hap = phase.data["Histograms"][histogram.name]
    hap["Scale"][1] = True
    hap["Size"][2] = [False, False, False]
    hap["Mustrain"][2] = [False, False, False]
    hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
    hap["Pref.Ori."][2] = False
    for atom in phase.data["Atoms"]:
        atom[2] = ""
        atom[9] = "I"
        atom[11:17] = [0.0] * 6

project.set_Controls("cycles", args.cycles)
project.save(str(Path(args.output).resolve()))
history = []
for iteration in range(args.repeats):
    project.refine()
    project.save()
    rvals = project.data["Covariance"]["data"]["Rvals"]
    history.append(
        {
            "iteration": iteration + 1,
            "rwp": float(rvals["Rwp"]),
            "gof": float(rvals["GOF"]),
            "converged": bool(rvals.get("converged", False)),
            "max_shift_esd": float(rvals.get("Max shft/sig", float("nan"))),
        }
    )

print(
    json.dumps(
        {
            "project": str(Path(args.output).resolve()),
            "history": history,
            "instrument": {
                key: float(value[1])
                for key, value in instrument.items()
                if isinstance(value, list) and len(value) >= 3 and isinstance(value[2], bool)
                and isinstance(value[1], numbers.Real)
            },
        }
    )
)
