"""Build composition-preserving antisite variants of the P-31m Mn2WO6 model."""

from __future__ import annotations

import argparse
from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


parser = argparse.ArgumentParser()
parser.add_argument("output_dir")
parser.add_argument("--q", default="0.975,0.95,0.90")
args = parser.parse_args()

out = Path(args.output_dir)
out.mkdir(parents=True, exist_ok=True)
lattice = Lattice.hexagonal(4.99863515, 4.44521239)
for q in (float(value) for value in args.q.split(",")):
    if not 0.5 <= q <= 1.0:
        raise ValueError("q must lie between 0.5 and 1")
    p = 2.0 * q - 1.0
    structure = Structure.from_spacegroup(
        "P-31m",
        lattice,
        [
            {"Mn": q, "W": 1.0 - q},
            {"W": p, "Mn": 1.0 - p},
            "O",
        ],
        [
            [1.0 / 3.0, 2.0 / 3.0, 0.5],
            [0.0, 0.0, 0.0],
            [0.0, 0.215, 0.354],
        ],
    )
    path = out / f"Mn2WO6_Pm31m_q{q:.3f}.cif"
    CifWriter(structure, symprec=1e-5, refine_struct=False).write_file(path)
    print(path, structure.composition)
