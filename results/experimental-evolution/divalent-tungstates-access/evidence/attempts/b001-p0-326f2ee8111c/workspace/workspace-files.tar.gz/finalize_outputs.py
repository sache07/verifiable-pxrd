#!/usr/bin/env python3
"""Clean the selected refinement and export all required deliverables."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "analysis" / "extensions" / "uiso_pol.gpx"
FINAL = ROOT / "final.gpx"


def remove_flag(flags: str, flag: str) -> str:
    return "".join(value for value in flags if value != flag)


def main() -> None:
    G2.SetPrintLevel("warn")
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(FINAL))
    project.set_Controls("cycles", 10)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6
    hist = project.histogram(0)

    # Remove three numerically redundant degrees of freedom while retaining
    # their already-refined physical values in the forward model.
    wo3_hap = project.phase("WO3").getHAPvalues(hist)
    wo3_hap["Mustrain"][1][0] = 0.0
    wo3_hap["Mustrain"][2] = [False for _ in wo3_hap["Mustrain"][2]]
    hist.InstrumentParameters["X"][2] = False
    zno = project.phase("ZnO")
    zno.atoms()[0].refinement_flags = remove_flag(
        zno.atoms()[0].refinement_flags, "X"
    )
    project.data["Controls"]["data"]["parmFrozen"] = {}

    project.refine()
    project.save()

    phase_files = {"WO3": "phase_wo3.cif", "ZnO": "phase_zno.cif"}
    for phase in project.phases():
        phase.export_CIF(str(ROOT / phase_files[phase.name]))

    arrays = [np.asarray(item, dtype=float) for item in hist.data["data"][1]]
    x, observed, weights, calculated = arrays[:4]
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta,observed,calculated,difference",
        comments="",
        fmt=["%.8f", "%.8f", "%.8f", "%.8f"],
    )

    fractions = hist.ComputeMassFracs()
    residuals = hist.residuals
    chi_square = float(np.sum(weights * difference**2))
    denominator = float(np.sum(weights * observed**2))
    vary_count = len(project.data["Covariance"]["data"].get("varyList", []))
    fit_statistics = {
        "Rwp_percent": float(residuals["wR"]),
        "Rp_percent": float(residuals["R"]),
        "Rexp_percent": float(residuals["wRmin"]),
        "goodness_of_fit": float(residuals["wR"] / residuals["wRmin"]),
        "chi_square": chi_square,
        "weighted_profile_denominator": denominator,
        "data_points": int(len(x)),
        "refined_parameters": int(vary_count),
        "weighting": "1/max(observed_counts,1)",
    }
    phases = []
    provenance = {
        "WO3": {
            "formula": "WO3",
            "structure_type": "monoclinic tungsten trioxide",
            "starting_model": "COD 2311041, generator-normalized",
        },
        "ZnO": {
            "formula": "ZnO",
            "structure_type": "wurtzite zinc oxide",
            "starting_model": "COD 9004178, generator-normalized",
        },
    }
    for phase in project.phases():
        value, sigma = fractions[phase.name]
        phases.append(
            {
                "name": phase.name,
                **provenance[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": phase_files[phase.name],
                "weight_fraction": float(value),
                "weight_fraction_esd": float(sigma),
                "unit_cell": phase.get_cell(),
            }
        )
    result = {
        "phases": phases,
        "fit_statistics": fit_statistics,
        "refinement_histogram": hist.name,
        "fraction_basis": "normalized over the two modeled crystalline phases",
        "unresolved_components": [],
    }
    (ROOT / "result.json").write_text(
        json.dumps(result, indent=2, sort_keys=True, allow_nan=False) + "\n"
    )
    print(json.dumps(result, indent=2, sort_keys=True), flush=True)


if __name__ == "__main__":
    main()
