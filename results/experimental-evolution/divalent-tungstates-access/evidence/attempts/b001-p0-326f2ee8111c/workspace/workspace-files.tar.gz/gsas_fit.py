#!/usr/bin/env python3
"""Build and refine a diagnostic GSAS-II model for the supplied PXRD scan.

Run with the GSAS-II Python interpreter. This intentionally keeps each
refinement stage small so that failures and parameter correlations are visible.
"""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
NORMALIZED_ROOT = Path(__file__).resolve().parent / "analysis" / "normalized_models"
PHASES = {
    "wo3_2311041": ("WO3", "2311041"),
    "wo3_1528915": ("WO3", "1528915"),
    "wo3_1010618": ("WO3", "1010618"),
    "zno_9004178": ("ZnO", "9004178"),
    "znwo4_1520641": ("ZnWO4", "1520641"),
    "znwo4_2101679": ("ZnWO4_tri1", "2101679"),
    "znwo4_2101690": ("ZnWO4_tri2", "2101690"),
}


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_inputs(pattern: Path, work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    xye = work / "pattern.xye"
    with pattern.open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    with xye.open("w") as stream:
        stream.write("# two_theta intensity sigma\n")
        for row in rows:
            x = float(row["two_theta_deg"])
            y = float(row["intensity"])
            stream.write(f"{x:.8f} {y:.1f} {np.sqrt(max(y, 1.0)):.10f}\n")

    inst = work / "instrument.instprm"
    inst.write_text(
        "# Cu Kalpha laboratory instrument; GSAS-II convention\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {
            key: value[:3] if isinstance(value, list) else value
            for key, value in hist.InstrumentParameters.items()
        },
        "sample": hist.SampleParameters,
        "background": hist.Background[0],
        "phases": {},
    }
    try:
        result["mass_fractions"] = hist.ComputeMassFracs()
    except Exception as exc:
        result["mass_fraction_error"] = str(exc)
    for phase in project.phases():
        hap = phase.getHAPvalues(hist)
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "composition": phase.composition,
            "scale": hap["Scale"],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "preferred_orientation": hap["Pref.Ori."],
        }
    return result


def run_stage(
    project: G2.G2Project, label: str, reports: list[dict], verbose: bool = False
) -> None:
    project.refine()
    report = snapshot(project, label)
    reports.append(report)
    if verbose:
        print(json.dumps(report, indent=2, default=float), flush=True)
    else:
        print(
            json.dumps(
                {
                    "stage": label,
                    "Rwp": report["residuals"].get("wR"),
                    "fractions": report.get("mass_fractions"),
                },
                default=float,
            ),
            flush=True,
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--pattern", type=Path, default=Path("inputs/pattern.csv"))
    parser.add_argument("--work", type=Path, required=True)
    parser.add_argument(
        "--phases",
        nargs="+",
        choices=sorted(PHASES),
        default=["wo3_2311041", "zno_9004178"],
    )
    parser.add_argument("--background-terms", type=int, default=18)
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--verbose", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.work.mkdir(parents=True, exist_ok=True)
    xye, inst = write_inputs(args.pattern, args.work)
    gpx = args.work / "model.gpx"
    project = G2.G2Project(newgpx=str(gpx))
    phases = []
    for key in args.phases:
        name, cod_id = PHASES[key]
        source = NORMALIZED_ROOT / f"{cod_id}.cif"
        if not source.is_file():
            source = cod_path(cod_id)
        phases.append(
            project.add_phase(
                str(source), phasename=name, fmthint="CIF"
            )
        )
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    measured = np.loadtxt(xye, comments="#")[:, 0]
    hist.set_refinements(
        {
            "Limits": [float(measured.min()), float(measured.max())],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": args.background_terms,
                "coeffs": [700.0] + [0.0] * (args.background_terms - 1),
                "refine": True,
            },
        }
    )

    # Stable, physically plausible starts for specimen terms.
    for index, phase in enumerate(phases):
        hap = phase.getHAPvalues(hist)
        hap["Scale"] = [1.0 if index == 0 else 0.4, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 300.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
        # Generator models use one isotropic displacement parameter per phase.
        for atom in phase.atoms():
            if atom.adp_flag == "I":
                atom.uiso = 0.008

    project.set_Controls("cycles", 6)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    # Keep sampled physical parameters within the frozen laboratory ranges.
    bounded = {
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.1),
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
    }
    for phase in phases:
        bounded[f"{phase.id}:0:Scale"] = (0.0, None)
        bounded[f"{phase.id}:0:Size;i"] = (0.04, 1.5)
        bounded[f"{phase.id}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (lower, upper) in bounded.items():
        if lower is not None:
            project.set_Controls("parmMin", lower, variable=variable)
        if upper is not None:
            project.set_Controls("parmMax", upper, variable=variable)
    reports: list[dict] = []

    # Linear terms first.
    run_stage(project, "background_and_scales", reports, args.verbose)

    # A constant angular zero is identifiable before cells are allowed to move.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_stage(project, "zero", reports, args.verbose)

    for phase in phases:
        phase.set_refinements({"Cell": True})
    run_stage(project, "cells", reports, args.verbose)

    # Separate the common cos(theta) specimen displacement from the constant zero.
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_stage(project, "zero_cells_shift", reports, args.verbose)

    # The generator uses V=Y=Z=0, so only its sampled profile family is varied.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_stage(project, "instrument_profile", reports, args.verbose)

    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            },
            [hist],
        )
    run_stage(project, "phase_profiles", reports, args.verbose)

    if args.coordinates:
        for phase in phases:
            phase.set_refinements({"Atoms": {"all": "X"}})
        run_stage(project, "coordinates", reports, args.verbose)

    project.save()
    (args.work / "stages.json").write_text(
        json.dumps(reports, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
