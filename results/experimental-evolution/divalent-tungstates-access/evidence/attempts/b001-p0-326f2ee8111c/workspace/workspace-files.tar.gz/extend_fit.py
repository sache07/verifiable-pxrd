#!/usr/bin/env python3
"""Apply controlled post-refinement extensions to an existing GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def add_flag(flags: str, new: str) -> str:
    order = "FXU"
    return "".join(key for key in order if key in flags or key in new)


def summary(project: G2.G2Project, label: str) -> None:
    hist = project.histogram(0)
    print(
        json.dumps(
            {
                "stage": label,
                "Rwp": hist.residuals.get("wR"),
                "fractions": hist.ComputeMassFracs(),
                "instrument": {
                    key: value[1]
                    for key, value in hist.InstrumentParameters.items()
                    if isinstance(value, list) and len(value) >= 3
                },
            },
            default=float,
        ),
        flush=True,
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--uiso", action="store_true")
    parser.add_argument("--polarization", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()

    G2.SetPrintLevel("warn")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(gpxfile=str(args.input), newgpx=str(args.output))
    hist = project.histogram(0)
    project.set_Controls("cycles", args.cycles)
    project.data["Controls"]["data"]["min dM/M"] = 1e-6

    if args.uiso:
        # The frozen generator assigns one isotropic Uiso to every atom in a phase.
        # Reproduce that model with an exact within-phase equivalence constraint.
        for phase in project.phases():
            variables = []
            for index, atom in enumerate(phase.atoms()):
                if atom.adp_flag != "I":
                    raise ValueError(f"Non-isotropic atom in normalized phase {phase.name}")
                atom.refinement_flags = add_flag(atom.refinement_flags, "U")
                variable = f"{phase.id}::AUiso:{index}"
                variables.append(variable)
                project.set_Controls("parmMin", 0.003, variable=variable)
                project.set_Controls("parmMax", 0.020, variable=variable)
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)

    if args.polarization:
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")

    if args.roughness:
        # Start away from the (0,0) no-effect special case so numerical
        # derivatives are defined. Both parameters are bounded to lab settings.
        hist.SampleParameters["SurfRoughA"] = [0.30, True]
        hist.SampleParameters["SurfRoughB"] = [0.08, True]
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")

    project.refine()
    summary(project, "extended")
    project.save()


if __name__ == "__main__":
    main()
