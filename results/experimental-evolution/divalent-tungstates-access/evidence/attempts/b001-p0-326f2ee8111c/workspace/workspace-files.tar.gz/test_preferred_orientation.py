#!/usr/bin/env python3
"""Grid-test the finite March-Dollase axes used by the frozen generator."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")
    results = []
    for phase_index in range(2):
        for axis in AXES:
            token = "".join(map(str, axis))
            output = args.outdir / f"phase{phase_index}_{token}.gpx"
            project = G2.G2Project(gpxfile=str(args.input), newgpx=str(output))
            project.set_Controls("cycles", 8)
            phase = project.phase(phase_index)
            hist = project.histogram(0)
            po = phase.getHAPvalues(hist)["Pref.Ori."]
            po[0] = "MD"
            po[1] = 1.0
            po[2] = True
            po[3] = list(axis)
            project.set_Controls(
                "parmMin", 0.7, variable=f"{phase_index}:0:MD"
            )
            project.set_Controls(
                "parmMax", 1.4, variable=f"{phase_index}:0:MD"
            )
            project.refine()
            row = {
                "phase": phase.name,
                "phase_index": phase_index,
                "axis": axis,
                "ratio": phase.getHAPvalues(hist)["Pref.Ori."][1],
                "Rwp": hist.residuals.get("wR"),
                "fractions": hist.ComputeMassFracs(),
                "output": str(output),
            }
            results.append(row)
            print(json.dumps(row, default=float), flush=True)
            project.save()
    (args.outdir / "results.json").write_text(
        json.dumps(results, indent=2, default=float) + "\n"
    )


if __name__ == "__main__":
    main()
