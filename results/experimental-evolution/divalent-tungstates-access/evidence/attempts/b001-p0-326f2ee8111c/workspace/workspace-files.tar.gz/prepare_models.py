#!/usr/bin/env python3
"""Normalize selected COD models exactly as the frozen generator does."""

from __future__ import annotations

import sys
import warnings
from pathlib import Path

from pymatgen.io.cif import CifParser


ROOT = Path(__file__).resolve().parent
RUNTIME = ROOT / "learned" / "divalent-tungstates" / "runtime"
sys.path.insert(0, str(RUNTIME))
from models import write_synthetic_model  # noqa: E402


COD_ROOT = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
IDS = [
    "2311041",
    "1528915",
    "1010618",
    "9004178",
    "1520641",
    "2101679",
    "2101690",
]


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main() -> None:
    target = ROOT / "analysis" / "normalized_models"
    target.mkdir(parents=True, exist_ok=True)
    for cod_id in IDS:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            parser = CifParser(
                cod_path(cod_id),
                occupancy_tolerance=1.0,
                site_tolerance=1e-5,
                frac_tolerance=0,
            )
            structures = parser.parse_structures(primitive=False, on_error="raise")
        if len(structures) != 1:
            raise ValueError(f"Expected one structure for COD {cod_id}")
        structure = structures[0]
        structure.remove_oxidation_states()
        output = target / f"{cod_id}.cif"
        write_synthetic_model(structure, output)
        print(output)


if __name__ == "__main__":
    main()
