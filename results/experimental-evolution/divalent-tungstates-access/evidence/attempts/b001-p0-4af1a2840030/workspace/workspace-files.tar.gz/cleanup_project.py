#!/usr/bin/env python3
"""Remove redundant origin/profile parameters from the selected GSAS-II fit."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2


src, dst = map(Path, sys.argv[1:3])
G2.SetPrintLevel("error")
project = G2.G2Project(gpxfile=str(src.resolve()))
project.save(str(dst.resolve()))
hist = project.histogram(0)

# P63mc has an arbitrary origin along c. Place Zn at z=0 and retain the
# refined Zn--O separation, then hold the redundant origin coordinate.
zno = project.phases()[1]
zn, oxygen = zno.atoms()
origin_shift = -zn.coordinates[2]
zn.coordinates = (zn.coordinates[0], zn.coordinates[1], 0.0)
oxygen.coordinates = (oxygen.coordinates[0], oxygen.coordinates[1],
                      (oxygen.coordinates[2] + origin_shift) % 1.0)
zn.refinement_flags = "U"
oxygen.refinement_flags = "XU"

# X and the large-crystallite size limit are effectively collinear here.
# Keep the fitted instrumental X and hold the ZnO size at its limiting value.
hist.InstrumentParameters["X"][2] = False
zno.data["Histograms"][hist.name]["Size"][2][0] = False
project.set_Frozen()

project.set_Controls("cycles", 10)
project.refine()
project.save(str(dst.resolve()))
print(hist.residuals)
print(project.data["Covariance"]["data"].get("Rvals"))
print(hist.ComputeMassFracs())
