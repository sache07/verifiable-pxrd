#!/usr/bin/env python3
"""Export phase CIFs and the fitted profile from final.gpx."""

import csv
from pathlib import Path

from GSASII import GSASIIscriptable as G2


root = Path(__file__).resolve().parent
G2.SetPrintLevel("error")
project = G2.G2Project(gpxfile=str(root / "final.gpx"))
hist = project.histogram(0)
phases = project.phases()
if len(phases) != 2:
    raise RuntimeError("Expected the final two-phase model")

phases[0].export_CIF(str(root / "phase_WO3.cif"))
phases[1].export_CIF(str(root / "phase_ZnO.cif"))

x, observed, weights, calculated, background, difference = hist.data["data"][1]
with (root / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(["two_theta", "observed", "calculated", "difference", "background"])
    writer.writerows(zip(x, observed, calculated, observed - calculated, background))

print(hist.name)
print(hist.residuals)
print(hist.ComputeMassFracs())
print(project.data["Covariance"]["data"].get("Rvals"))
