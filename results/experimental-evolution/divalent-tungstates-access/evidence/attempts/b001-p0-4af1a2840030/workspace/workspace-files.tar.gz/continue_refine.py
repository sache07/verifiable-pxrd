#!/usr/bin/env python3
"""Apply targeted continuation refinements to an existing GSAS-II project."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def state(project, label):
    hist = project.histogram(0)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
        phases.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element, "xyz": a.coordinates,
                       "uiso": a.ADP, "flags": a.refinement_flags}
                      for a in phase.atoms()],
        })
    total = sum(masses)
    for row, mass in zip(phases, masses):
        row["weight_fraction"] = mass / total
    return clean({
        "label": label,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1},
        "sample": {k: (v[0] if isinstance(v, list) else v)
                   for k, v in hist.SampleParameters.items()},
        "phases": phases,
        "vary": project.get_VaryList(),
        "frozen": project.get_Frozen(),
    })


def refine(project, label, records, cycles):
    project.set_Controls("cycles", cycles)
    project.refine()
    record = state(project, label)
    records.append(record)
    print(json.dumps(record), flush=True)


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    parser.add_argument("--neutral-roughness", action="store_true")
    parser.add_argument("--instrument-profile", action="store_true")
    parser.add_argument("--x-profile", type=float)
    parser.add_argument("--orientation-phase", type=int)
    parser.add_argument("--orientation-axis", nargs=3, type=int)
    parser.add_argument("--uniaxial-phase", type=int)
    parser.add_argument("--uniaxial-axis", nargs=3, type=int)
    parser.add_argument("--cycles", type=int, default=10)
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
    output = Path(args.output).resolve()
    project.save(str(output))
    hist = project.histogram(0)
    phases = project.phases()
    records = []

    # Preserve physical common-Uiso constraints; never vary polarization in the
    # same fit because it is nearly singular with overall thermal attenuation.
    hist.InstrumentParameters["Polariz."][2] = False

    if args.neutral_roughness:
        hist.SampleParameters["SurfRoughA"] = [0.0, False]
        hist.SampleParameters["SurfRoughB"] = [0.0, False]
        project.set_Frozen()
        refine(project, "neutral_surface_roughness", records, args.cycles)

    if args.instrument_profile:
        hist.InstrumentParameters["U"][2] = True
        bound(project, ":0:U", 0.0, 40.0)
        project.set_Frozen()
        refine(project, "instrument_U", records, args.cycles)
        hist.InstrumentParameters["X"][2] = True
        bound(project, ":0:X", 0.1, 6.0)
        project.set_Frozen()
        refine(project, "instrument_X", records, args.cycles)

    if args.x_profile is not None:
        hist.InstrumentParameters["X"][1] = args.x_profile
        hist.InstrumentParameters["X"][2] = False
        for pidx, phase in enumerate(phases):
            phase.data["Histograms"][hist.name]["Size"][1][0] = 0.7
            phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
            bound(project, f"{pidx}:0:Size;i", 0.04, 1.5)
        project.set_Frozen()
        refine(project, f"fixed_X_{args.x_profile:g}", records, args.cycles)

    if args.coordinates:
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = "XU" if atom.element != "O" else "U"
        project.set_Frozen()
        refine(project, "heavy_atom_coordinates", records, args.cycles)
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = "XU"
        project.set_Frozen()
        refine(project, "all_atomic_coordinates", records, args.cycles)

    if args.shift:
        hist.SampleParameters["Shift"] = [0.0, True]
        bound(project, ":0:Shift", -800.0, 800.0)
        project.set_Frozen()
        refine(project, "sample_displacement", records, args.cycles)

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.25, True]
        hist.SampleParameters["SurfRoughB"] = [0.08, True]
        bound(project, ":0:SurfRoughA", 0.0, 0.8)
        bound(project, ":0:SurfRoughB", 0.001, 0.8)
        project.set_Frozen()
        refine(project, "surface_roughness", records, args.cycles)

    if args.orientation_phase is not None:
        phase = phases[args.orientation_phase]
        hap = phase.data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = list(args.orientation_axis)
        phase.set_HAP_refinements({"Pref.Ori.": True})
        bound(project, f"{args.orientation_phase}:0:MD", 0.7, 1.4)
        project.set_Frozen()
        refine(project, f"orientation_p{args.orientation_phase}_{args.orientation_axis}", records, args.cycles)

    if args.uniaxial_phase is not None:
        phase = phases[args.uniaxial_phase]
        phase.set_HAP_refinements({"Mustrain": {"type": "uniaxial", "direction": list(args.uniaxial_axis),
                                                  "refine": True}})
        bound(project, f"{args.uniaxial_phase}:0:Mustrain;i", 0.0, 8000.0)
        bound(project, f"{args.uniaxial_phase}:0:Mustrain;a", 0.0, 32000.0)
        project.set_Frozen()
        refine(project, f"uniaxial_p{args.uniaxial_phase}_{args.uniaxial_axis}", records, args.cycles)

    project.save(str(output))
    output.with_suffix(".json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
