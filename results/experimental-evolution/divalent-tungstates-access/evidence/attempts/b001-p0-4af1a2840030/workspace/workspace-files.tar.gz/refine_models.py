#!/usr/bin/env python3
"""Build and refine exploratory two-phase GSAS-II models for the supplied scan."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(ident: str) -> Path:
    return COD / ident[0] / ident[1:3] / ident[3:5] / f"{ident}.cif"


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = project.phases()
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if isinstance(v, list) and len(v) > 1},
        "sample": {k: (v[0] if isinstance(v, list) else v) for k, v in hist.SampleParameters.items()},
        "background": hist.Background[0],
        "phases": [],
    }
    masses = []
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        masses.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
        result["phases"].append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "adp": [a.ADP for a in phase.atoms()],
        })
    total = sum(masses)
    for row, mass in zip(result["phases"], masses):
        row["weight_fraction"] = mass / total
    print(json.dumps(result, default=lambda x: x.tolist() if isinstance(x, np.ndarray) else str(x)))
    return result


def refine(project: G2.G2Project, label: str, cycles: int = 8) -> dict:
    project.set_Controls("cycles", cycles)
    project.refine()
    return snapshot(project, label)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--zno", default="9004178")
    parser.add_argument("--out", required=True)
    parser.add_argument("--full", action="store_true")
    args = parser.parse_args()

    G2.SetPrintLevel("error")
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(newgpx=str(out))
    wo3 = project.add_phase(str(cod_path(args.wo3)), phasename=f"WO3_{args.wo3}", fmthint="CIF")
    zno = project.add_phase(str(cod_path(args.zno)), phasename=f"ZnO_{args.zno}", fmthint="CIF")
    hist = project.add_powder_histogram(
        str(Path("inputs/pattern.csv").resolve()),
        str(Path("instrument.instprm").resolve()),
        phases=[wo3, zno],
        fmthint="comma",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.1, False]
    # A flexible smooth background approximates the sampled exponential/power-law continuum.
    hist.set_refinements({"Background": {"type": "chebyschev-1", "no. coeffs": 16, "refine": True,
                                                "coeffs": [650.0] + [0.0] * 15}})
    # Stable, physically plausible initial phase parameters.
    for phase, fraction in [(wo3, 0.74), (zno, 0.26)]:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][0] = 10000.0 * fraction / phase.data["General"]["Mass"]
        phase.set_HAP_refinements({"Scale": True})
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 1.0, "refine": False}})
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": False}})

    stages = []
    stages.append(refine(project, "background_scales", 8))

    # Peak positions: common zero first, followed by symmetry-constrained phase cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stages.append(refine(project, "zero", 8))
    wo3.set_refinements({"Cell": True})
    zno.set_refinements({"Cell": True})
    stages.append(refine(project, "cells", 10))

    # Common instrumental broadening, then phase-specific size and microstrain.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    stages.append(refine(project, "instrument_profile", 10))
    for phase in (wo3, zno):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": 0.5, "refine": True}})
    stages.append(refine(project, "phase_size", 10))
    for phase in (wo3, zno):
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    stages.append(refine(project, "phase_strain", 10))

    if args.full:
        # Separate zero from Bragg-Brentano height error using the high-angle range.
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        stages.append(refine(project, "sample_shift", 12))

    project.save(str(out))
    out.with_suffix(".json").write_text(json.dumps(stages, indent=2, default=lambda x: x.tolist() if isinstance(x, np.ndarray) else str(x)) + "\n")


if __name__ == "__main__":
    main()
