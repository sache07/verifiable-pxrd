#!/usr/bin/env python3
"""Continue the best phase-identification model with physically bounded refinements."""

from __future__ import annotations

import argparse
import faulthandler
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def plain(value):
    if isinstance(value, dict):
        return {str(k): plain(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, np.generic):
        return value.item()
    return value


def summary(project, label):
    hist = project.histogram(0)
    masses = []
    phases = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        masses.append(mass)
        phases.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
            "pref_ori": hap["Pref.Ori."],
            "atoms": [{"label": a.label, "element": a.element, "xyz": a.coordinates,
                       "adp_flag": a.adp_flag, "adp": a.ADP, "flags": a.refinement_flags}
                      for a in phase.atoms()],
        })
    total = sum(masses)
    for phase, mass in zip(phases, masses):
        phase["weight_fraction"] = mass / total
    result = {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items()
                       if isinstance(v, list) and len(v) > 1},
        "sample": {k: (v[0] if isinstance(v, list) else v)
                   for k, v in hist.SampleParameters.items()},
        "background": hist.Background[0],
        "phases": phases,
        "vary": project.get_VaryList(),
        "frozen": project.get_Frozen(),
    }
    print(json.dumps(plain(result)))
    return result


def run(project, label, cycles=12):
    project.set_Controls("cycles", cycles)
    project.refine()
    return summary(project, label)


def bound(project, variable, low, high):
    project.set_Controls("parmMin", low, variable=variable)
    project.set_Controls("parmMax", high, variable=variable)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input")
    parser.add_argument("output")
    parser.add_argument("--coordinates", action="store_true")
    parser.add_argument("--shift", action="store_true")
    parser.add_argument("--roughness", action="store_true")
    args = parser.parse_args()

    faulthandler.dump_traceback_later(45, repeat=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(gpxfile=str(Path(args.input).resolve()))
    output = Path(args.output).resolve()
    project.save(str(output))
    hist = project.histogram(0)
    phases = project.phases()

    # Remove the unphysical profile minimum reached in the unconstrained screening fit.
    print("loaded", flush=True)
    for item in hist.InstrumentParameters.values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    hist.InstrumentParameters["U"][1] = 10.0
    hist.InstrumentParameters["W"][1] = 10.0
    hist.InstrumentParameters["X"][1] = 1.0
    hist.InstrumentParameters["SH/L"][1] = 0.03
    hist.InstrumentParameters["Polariz."][1] = 0.75
    # Avoid the exact global-scale degeneracy between histogram and all HAP scales.
    hist.SampleParameters["Scale"][1] = False
    bound(project, ":0:W", 2.0, 40.0)
    bound(project, ":0:SH/L", 0.005, 0.10)
    bound(project, ":0:Polariz.", 0.5, 1.0)
    bound(project, ":0:Zero", -0.25, 0.25)

    # The synthetic reference normalization assigns one isotropic Uiso to every
    # site in a phase. Restore that model and refine one constrained value/phase.
    print("instrument configured", flush=True)
    for pidx, phase in enumerate(phases):
        atoms = phase.atoms()
        for atom in atoms:
            atom.data[atom.cia] = "I"
            atom.data[atom.cia + 1] = 0.007
            atom.refinement_flags = "U"
        if len(atoms) > 1:
            project.add_EquivConstr(tuple(f"{pidx}::AUiso:{i}" for i in range(len(atoms))))
        bound(project, f"{pidx}::AUiso:*", 0.001, 0.04)
        phase.set_refinements({"Cell": False})
        phase.set_HAP_refinements({"Scale": True})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True})
        bound(project, f"{pidx}:0:Size;i", 0.04, 1.5)
        bound(project, f"{pidx}:0:Mustrain;i", 0.0, 8000.0)

    hist.set_refinements({"Background": True})
    print("atoms and constraints configured", flush=True)
    project.set_Frozen()
    print("starting bounded refinement", flush=True)
    stages = [run(project, "scales_background_uiso", 8)]

    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    stages.append(run(project, "cells_zero", 8))

    hist.set_refinements({"Instrument Parameters": ["W"]})
    stages.append(run(project, "common_gaussian_width", 8))
    for phase in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    stages.append(run(project, "phase_sizes", 8))
    for phase in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    stages.append(run(project, "phase_microstrain", 8))
    hist.set_refinements({"Instrument Parameters": ["SH/L"]})
    stages.append(run(project, "axial_divergence", 8))
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    stages.append(run(project, "polarization", 8))

    if args.coordinates:
        for phase in phases:
            for atom in phase.atoms():
                atom.refinement_flags = "XU"
        project.set_Frozen()
        stages.append(run(project, "atomic_coordinates", 20))

    if args.shift:
        hist.SampleParameters["Shift"] = [0.0, True]
        bound(project, ":0:Shift", -800.0, 800.0)
        project.set_Frozen()
        stages.append(run(project, "specimen_shift", 20))

    if args.roughness:
        hist.SampleParameters["SurfRoughA"] = [0.25, True]
        hist.SampleParameters["SurfRoughB"] = [0.08, True]
        bound(project, ":0:SurfRoughA", 0.0, 0.8)
        bound(project, ":0:SurfRoughB", 0.001, 0.8)
        project.set_Frozen()
        stages.append(run(project, "surface_roughness", 20))

    project.save(str(output))
    output.with_suffix(".json").write_text(json.dumps(plain(stages), indent=2) + "\n")


if __name__ == "__main__":
    main()
