"""Test roughness, texture and uniaxial strain with clean profile replay."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2

from optimize_raw import clear_flags, configure, valid, wr


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "physical-p21c" / "best.gpx"
OUTDIR = ROOT / ".tmp" / "nuisance"
PROJECT = OUTDIR / "best.gpx"
PO_AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
STRAIN_AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def chi(project):
    x, y, w, calc, bkg, diff = project.histogram(0).data["data"][1]
    return float(np.sum(w * (y - calc) ** 2))


def fractions(project):
    hist = project.histogram(0)
    mass = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return (mass / mass.sum()).tolist()


def recalculate(project, path):
    """Force cached arrays to match the saved atomic/profile parameters."""
    clear_flags(project)
    project.set_Frozen(None)
    project.save(path)
    project.refine()
    clear_flags(project)
    project.set_Frozen(None)
    project.save(path)
    return project


def record(project, label, accepted, reason, candidates=None):
    hist = project.histogram(0)
    return {
        "label": label,
        "accepted": accepted,
        "reason": reason,
        "wR": wr(project),
        "chi_square": chi(project),
        "fractions": fractions(project),
        "candidates": candidates,
        "roughness": [
            float(hist.SampleParameters["SurfRoughA"][0]),
            float(hist.SampleParameters["SurfRoughB"][0]),
        ],
        "phases": [
            {
                "name": p.name,
                "preferred_orientation": p.data["Histograms"][hist.name]["Pref.Ori."],
                "microstrain": p.data["Histograms"][hist.name]["Mustrain"],
            }
            for p in project.phases()
        ],
    }


def choose_roughness(project):
    base_chi = chi(project)
    candidates = []
    best = None
    for index, (a0, b0) in enumerate(((0.15, 0.05), (0.30, 0.10), (0.50, 0.25))):
        path = OUTDIR / f"roughness-{index}.gpx"
        shutil.copy2(PROJECT, path)
        trial = G2.G2Project(gpxfile=str(path))
        clear_flags(trial)
        sample = trial.histogram(0).SampleParameters
        sample["SurfRoughA"] = [a0, True]
        sample["SurfRoughB"] = [b0, True]
        trial.set_Controls("parmMin", 0.05, ":0:SurfRoughA")
        trial.set_Controls("parmMax", 0.60, ":0:SurfRoughA")
        trial.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
        trial.set_Controls("parmMax", 0.50, ":0:SurfRoughB")
        trial.set_Frozen(None)
        trial.refine()
        a = float(sample["SurfRoughA"][0])
        b = float(sample["SurfRoughB"][0])
        physical = 0.05 <= a <= 0.60 and 0.02 <= b <= 0.50
        trial = recalculate(trial, path)
        row = {"start": [a0, b0], "A": a, "B": b, "physical": bool(physical),
               "wR": wr(trial), "chi_square": chi(trial)}
        candidates.append(row)
        if physical and (best is None or row["chi_square"] < best[0]):
            best = (row["chi_square"], path, row)
    penalty = float(2 * np.log(8301) + 2 * np.log(len(candidates)))
    accepted = best is not None and best[0] < base_chi - penalty
    if accepted:
        shutil.copy2(best[1], PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
        reason = f"A={best[2]['A']:.6f}, B={best[2]['B']:.6f}; chi {base_chi:.2f}->{best[0]:.2f}"
    else:
        reason = f"no stable candidate exceeded penalized improvement {penalty:.2f}"
    return project, record(project, "surface_roughness", accepted, reason, candidates)


def choose_po(project, phase_id):
    base_chi = chi(project)
    candidates = []
    best = None
    for axis in PO_AXES:
        path = OUTDIR / f"po-p{phase_id}-{'-'.join(map(str, axis))}.gpx"
        shutil.copy2(PROJECT, path)
        trial = G2.G2Project(gpxfile=str(path))
        clear_flags(trial)
        hist = trial.histogram(0)
        po = trial.phases()[phase_id].data["Histograms"][hist.name]["Pref.Ori."]
        po[0], po[1], po[2], po[3] = "MD", 1.0, True, list(axis)
        trial.set_Controls("parmMin", 0.70, f"{phase_id}:0:MD")
        trial.set_Controls("parmMax", 1.40, f"{phase_id}:0:MD")
        trial.set_Frozen(None)
        trial.refine()
        ratio = float(po[1])
        physical = 0.70 <= ratio <= 1.40
        trial = recalculate(trial, path)
        row = {"axis": list(axis), "ratio": ratio, "physical": bool(physical),
               "wR": wr(trial), "chi_square": chi(trial)}
        candidates.append(row)
        if physical and (best is None or row["chi_square"] < best[0]):
            best = (row["chi_square"], path, row)
    penalty = float(np.log(8301) + 2 * np.log(len(PO_AXES)))
    accepted = best is not None and best[0] < base_chi - penalty
    if accepted:
        shutil.copy2(best[1], PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
        reason = f"axis={best[2]['axis']}, ratio={best[2]['ratio']:.6f}; chi {base_chi:.2f}->{best[0]:.2f}"
    else:
        reason = f"no axis exceeded penalized improvement {penalty:.2f}"
    return project, record(project, f"preferred_orientation_p{phase_id}", accepted, reason, candidates)


def choose_strain(project, phase_id):
    base_chi = chi(project)
    candidates = []
    best = None
    for axis in STRAIN_AXES:
        path = OUTDIR / f"strain-p{phase_id}-{'-'.join(map(str, axis))}.gpx"
        shutil.copy2(PROJECT, path)
        trial = G2.G2Project(gpxfile=str(path))
        clear_flags(trial)
        hist = trial.histogram(0)
        ms = trial.phases()[phase_id].data["Histograms"][hist.name]["Mustrain"]
        equatorial = float(ms[1][0])
        ms[0] = "uniaxial"
        ms[1][1] = equatorial
        ms[2][0] = True
        ms[2][1] = True
        ms[3] = list(axis)
        trial.set_Controls("parmMin", 0.0, f"{phase_id}:0:Mustrain;e")
        trial.set_Controls("parmMax", 8000.0, f"{phase_id}:0:Mustrain;e")
        trial.set_Controls("parmMin", 0.0, f"{phase_id}:0:Mustrain;a")
        trial.set_Controls("parmMax", 32000.0, f"{phase_id}:0:Mustrain;a")
        trial.set_Frozen(None)
        trial.refine()
        eq, axial = map(float, ms[1][:2])
        ratio = axial / eq if eq > 0 else np.inf
        physical = 0 <= eq <= 8000 and 0 <= axial <= 32000 and 0.25 <= ratio <= 4.0
        trial = recalculate(trial, path)
        row = {"axis": list(axis), "equatorial_ppm": eq, "axial_ppm": axial,
               "ratio": ratio, "physical": bool(physical), "wR": wr(trial), "chi_square": chi(trial)}
        candidates.append(row)
        if physical and (best is None or row["chi_square"] < best[0]):
            best = (row["chi_square"], path, row)
    penalty = float(np.log(8301) + 2 * np.log(len(STRAIN_AXES)))
    accepted = best is not None and best[0] < base_chi - penalty
    if accepted:
        shutil.copy2(best[1], PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
        reason = f"axis={best[2]['axis']}, ratio={best[2]['ratio']:.6f}; chi {base_chi:.2f}->{best[0]:.2f}"
    else:
        reason = f"no axis exceeded penalized improvement {penalty:.2f}"
    return project, record(project, f"uniaxial_strain_p{phase_id}", accepted, reason, candidates)


def base_stage(project):
    base = chi(project)
    path = OUTDIR / "base-final-trial.gpx"
    shutil.copy2(PROJECT, path)
    trial = G2.G2Project(gpxfile=str(path))
    configure(trial, "base")
    trial.set_Frozen(None)
    trial.refine()
    trial = recalculate(trial, path)
    ok, why = valid(trial)
    accepted = ok and chi(trial) <= base + 1e-7
    if accepted:
        shutil.copy2(path, PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
        reason = f"chi {base:.2f}->{chi(project):.2f}"
    else:
        reason = why if not ok else "recalculated fit worsened"
    return project, record(project, "base_final", accepted, reason)


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, PROJECT)
    project = G2.G2Project(gpxfile=str(PROJECT))
    project = recalculate(project, PROJECT)
    history = [record(project, "start", True, "fresh no-variable recalculation")]

    project, row = choose_roughness(project)
    history.append(row)
    for phase_id in range(len(project.phases())):
        project, row = choose_po(project, phase_id)
        history.append(row)
    for phase_id in range(len(project.phases())):
        project, row = choose_strain(project, phase_id)
        history.append(row)
    project, row = base_stage(project)
    history.append(row)
    project = recalculate(project, PROJECT)
    history.append(record(project, "final", True, "flags and frozen list cleared; profile recalculated"))
    (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("FINAL", wr(project), chi(project), fractions(project))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
