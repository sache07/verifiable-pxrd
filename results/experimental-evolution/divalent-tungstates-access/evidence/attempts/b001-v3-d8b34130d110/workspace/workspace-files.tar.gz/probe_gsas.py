from pathlib import Path
import sys

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def main():
    wo3_id = sys.argv[1] if len(sys.argv) > 1 else "1528915"
    out = ROOT / ".tmp" / f"probe-{wo3_id}.gpx"
    out.parent.mkdir(exist_ok=True)
    project = G2.G2Project(newgpx=str(out))
    ids = ["4000806", "1527404", wo3_id]
    names = ["CuWO4", "Cu3WO6", "WO3"]
    phases = [
        project.add_phase(str(cod_cif(i)), phasename=n, fmthint="CIF")
        for i, n in zip(ids, names)
    ]
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        phases=phases,
        fmthint="comma",
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    x, y = hist.data["data"][1][:2]
    baseline = percentile_filter(y, percentile=20, size=401, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, 10).tolist()
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": len(coeffs), "coeffs": coeffs, "refine": False}}
    )
    for p, wf in zip(phases, [0.6, 0.2, 0.2]):
        hap = p.data["Histograms"][hist.name]
        hap["Scale"] = [1.0e6 * wf / p.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.3
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
    project.set_Controls("cycles", 0)
    project.refine()
    hist = project.histogram(0)
    arr = hist.data["data"][1]
    print("histogram", hist.name)
    print("residuals", hist.residuals)
    print("obs range", float(np.min(arr[1])), float(np.max(arr[1])))
    print("calc range", float(np.min(arr[3])), float(np.max(arr[3])))
    print("bkg range", float(np.min(arr[4])), float(np.max(arr[4])))
    for p in project.phases():
        h = p.data["Histograms"][hist.name]
        print(p.name, p.data["General"]["Mass"], h["Scale"], p.get_cell())
    project.save()


if __name__ == "__main__":
    main()
