"""Finish a four-phase refinement with parent-centered coordinate bounds.

Usage: physical_finish.py CHECKPOINT PARENT OUTDIR
"""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from optimize_raw import clear_flags, configure, set_bounds, valid, wr


SOURCE = Path(sys.argv[1]).resolve()
PARENT_FILE = Path(sys.argv[2]).resolve()
OUTDIR = Path(sys.argv[3]).resolve()
PROJECT = OUTDIR / "best.gpx"


def fractions(project):
    hist = project.histogram(0)
    mass = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return (mass / mass.sum()).tolist()


def snapshot(project, label, accepted, reason):
    hist = project.histogram(0)
    return {
        "label": label,
        "accepted": accepted,
        "reason": reason,
        "wR": wr(project),
        "fractions": fractions(project),
        "instrument": {
            k: float(hist.InstrumentParameters[k][1])
            for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]
        },
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "size_um": float(p.data["Histograms"][hist.name]["Size"][1][0]),
                "strain_ppm": float(p.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "atoms": [
                    {"label": a.label, "element": a.element, "xyz": list(a.coordinates)}
                    for a in p.atoms()
                ],
            }
            for p in project.phases()
        ],
    }


def parent_coordinate(parent, phase_id, atom_index):
    return np.asarray(parent.phases()[phase_id].atoms()[atom_index].coordinates, float)


def coordinate_setup(project, parent, phase_id, labels):
    """Refine selected coordinates while keeping each component near its parent."""
    phase = project.phases()[phase_id]
    lengths = np.array([
        phase.get_cell()["length_a"],
        phase.get_cell()["length_b"],
        phase.get_cell()["length_c"],
    ])
    selected = set(labels)
    for atom_index, atom in enumerate(phase.atoms()):
        if atom.label not in selected:
            continue
        parent_xyz = parent_coordinate(parent, phase_id, atom_index)
        current_xyz = np.asarray(atom.coordinates, float)
        center = parent_xyz - current_xyz
        center -= np.rint(center)
        # The generator perturbs site positions by 0.01--0.05 A RMS. These
        # per-component envelopes permit up to about 0.14 A total displacement
        # for oxygen and 0.11 A for the heavier cations without allowing the
        # unconstrained bond-collapse solutions seen in exploratory fits.
        component_A = 0.080 if atom.element == "O" else 0.065
        half_width = component_A / lengths
        for axis, delta, width in zip("xyz", center, half_width):
            variable = f"{phase_id}::dA{axis}:{atom_index}"
            project.set_Controls("parmMin", float(delta - width), variable)
            project.set_Controls("parmMax", float(delta + width), variable)
    configure(project, "coordinates", phase_id, tuple(labels))


def coordinate_envelope_ok(project, parent):
    for phase_id, phase in enumerate(project.phases()):
        lengths = np.array([
            phase.get_cell()["length_a"],
            phase.get_cell()["length_b"],
            phase.get_cell()["length_c"],
        ])
        for atom_index, atom in enumerate(phase.atoms()):
            parent_xyz = parent_coordinate(parent, phase_id, atom_index)
            delta = np.asarray(atom.coordinates, float) - parent_xyz
            delta -= np.rint(delta)
            component_A = 0.080 if atom.element == "O" else 0.065
            if np.any(np.abs(delta * lengths) > component_A + 2e-5):
                return False, f"{phase.name} {atom.label} left coordinate envelope"
    return True, "ok"


def project_into_coordinate_envelope(project, parent):
    """Project an unconstrained LS coordinate step onto the physical envelope."""
    changed = False
    for phase_id, phase in enumerate(project.phases()):
        lengths = np.array([
            phase.get_cell()["length_a"],
            phase.get_cell()["length_b"],
            phase.get_cell()["length_c"],
        ])
        for atom_index, atom in enumerate(phase.atoms()):
            parent_xyz = parent_coordinate(parent, phase_id, atom_index)
            current_xyz = np.asarray(atom.coordinates, float)
            delta = current_xyz - parent_xyz
            delta -= np.rint(delta)
            component_A = 0.080 if atom.element == "O" else 0.065
            limit = component_A / lengths
            clipped = np.clip(delta, -limit, limit)
            if not np.allclose(delta, clipped, rtol=0, atol=1e-12):
                atom.coordinates = tuple(parent_xyz + clipped)
                changed = True
    return changed


def cell_envelope_ok(project, parent):
    for phase_id, phase in enumerate(project.phases()):
        now = phase.get_cell()
        old = parent.phases()[phase_id].get_cell()
        for key in ["length_a", "length_b", "length_c"]:
            if abs(now[key] / old[key] - 1) > 0.012:
                return False, f"{phase.name} {key} outside 1.2% parent envelope"
        for key in ["angle_alpha", "angle_beta", "angle_gamma"]:
            if abs(now[key] - old[key]) > 1.2:
                return False, f"{phase.name} {key} outside 1.2 degree parent envelope"
    return True, "ok"


def stage(project, parent, label, setup, repeats=2):
    clear_flags(project)
    project.save(PROJECT)
    backup = OUTDIR / "accepted.gpx"
    shutil.copy2(PROJECT, backup)
    before = wr(project)
    values = []
    for _ in range(repeats):
        project.data["Controls"]["data"]["shift factor"] = 1.0
        setup(project)
        project.set_Frozen(None)
        project.refine()
        if project_into_coordinate_envelope(project, parent):
            # The saved profile must correspond to the projected coordinates,
            # not to GSAS's transient out-of-envelope least-squares step.
            clear_flags(project)
            project.set_Frozen(None)
            project.save(PROJECT)
            project.refine()
        values.append(wr(project))
        if len(values) > 1 and abs(values[-1] - values[-2]) < 0.0005:
            break
    ok, why = valid(project)
    if ok:
        ok, why = coordinate_envelope_ok(project, parent)
    if ok:
        ok, why = cell_envelope_ok(project, parent)
    after = wr(project)
    accepted = ok and after <= before + 1e-7
    if accepted:
        reason = f"wR {before:.6f} -> {after:.6f}; {values}"
        clear_flags(project)
        project.save(PROJECT)
        shutil.copy2(PROJECT, OUTDIR / f"{label}.gpx")
    else:
        reason = why if not ok else f"wR worsened {before:.6f} -> {after:.6f}"
        shutil.copy2(backup, PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
    print(label, "accepted" if accepted else "rejected", reason)
    return project, snapshot(project, label, accepted, reason)


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, PROJECT)
    project = G2.G2Project(gpxfile=str(PROJECT))
    parent = G2.G2Project(gpxfile=str(PARENT_FILE))
    clear_flags(project)
    set_bounds(project)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.set_Controls("cycles", 8)
    project.save(PROJECT)
    history = [snapshot(project, "start", True, "physical parent-centered checkpoint")]

    # The checkpoint is immediately before phase 2 coordinate adaptation.
    phase_id = 2
    phase = project.phases()[phase_id]
    heavy = [a.label for a in phase.atoms() if a.element != "O"]
    oxygen = [a.label for a in phase.atoms() if a.element == "O"]
    for atom_label in heavy + oxygen:
        project, row = stage(
            project, parent, f"bounded_p2_{atom_label}",
            lambda p, a=(atom_label,): coordinate_setup(p, parent, phase_id, a),
            2,
        )
        history.append(row)
    for group, labels in [("heavy", heavy), ("oxygen", oxygen)]:
        project, row = stage(
            project, parent, f"bounded_p2_all_{group}",
            lambda p, a=tuple(labels): coordinate_setup(p, parent, phase_id, a),
            2,
        )
        history.append(row)
    project, row = stage(project, parent, "base_after_p2", lambda p: configure(p, "base"), 2)
    history.append(row)

    # CuO has only one symmetry-variable oxygen coordinate.
    p3_labels = tuple(a.label for a in project.phases()[3].atoms())
    project, row = stage(
        project, parent, "bounded_p3_coords",
        lambda p: coordinate_setup(p, parent, 3, p3_labels), 2,
    )
    history.append(row)
    project, row = stage(project, parent, "base_after_p3", lambda p: configure(p, "base"), 2)
    history.append(row)

    for phase_id in range(len(project.phases())):
        for kind in ("size", "strain"):
            project, row = stage(
                project, parent, f"profile1_{kind}_p{phase_id}",
                lambda p, k=kind, i=phase_id: configure(p, k, i), 2,
            )
            history.append(row)
    project, row = stage(project, parent, "polarization1", lambda p: configure(p, "Polariz."), 2)
    history.append(row)
    project, row = stage(project, parent, "base1", lambda p: configure(p, "base"), 3)
    history.append(row)

    # Cell and calibration pass, followed by one bounded coupled-coordinate
    # pass for every phase so all candidate symmetries receive equal treatment.
    for phase_id in range(len(project.phases())):
        project, row = stage(
            project, parent, f"cell_p{phase_id}",
            lambda p, i=phase_id: configure(p, "cell", i), 2,
        )
        history.append(row)
    project, row = stage(project, parent, "base_after_cells", lambda p: configure(p, "base"), 2)
    history.append(row)
    for key in ("Zero", "Shift"):
        project, row = stage(
            project, parent, f"calibration_{key}",
            lambda p, k=key: configure(p, k), 2,
        )
        history.append(row)

    for phase_id, phase in enumerate(project.phases()):
        for group, labels in (
            ("heavy", [a.label for a in phase.atoms() if a.element != "O"]),
            ("oxygen", [a.label for a in phase.atoms() if a.element == "O"]),
        ):
            if not labels:
                continue
            project, row = stage(
                project, parent, f"bounded2_p{phase_id}_{group}",
                lambda p, i=phase_id, a=tuple(labels): coordinate_setup(p, parent, i, a),
                2,
            )
            history.append(row)
        project, row = stage(
            project, parent, f"base_after_coords_p{phase_id}",
            lambda p: configure(p, "base"), 2,
        )
        history.append(row)

    for phase_id in range(len(project.phases())):
        for kind in ("size", "strain"):
            project, row = stage(
                project, parent, f"profile2_{kind}_p{phase_id}",
                lambda p, k=kind, i=phase_id: configure(p, k, i), 2,
            )
            history.append(row)
    for key in ("U", "W", "X", "Polariz."):
        project, row = stage(
            project, parent, f"instrument2_{key.replace('/', '_')}",
            lambda p, k=key: configure(p, k), 2,
        )
        history.append(row)
    project, row = stage(project, parent, "base_final", lambda p: configure(p, "base"), 3)
    history.append(row)

    clear_flags(project)
    project.set_Frozen(None)
    project.save(PROJECT)
    history.append(snapshot(project, "final", True, "refinement flags and frozen list cleared"))
    (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("FINAL", wr(project), fractions(project))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
