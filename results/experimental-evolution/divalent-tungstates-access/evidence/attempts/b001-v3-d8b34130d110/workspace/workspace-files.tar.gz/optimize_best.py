"""Physically bounded, staged refinement of the selected four-phase model."""

from pathlib import Path
import json
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "trials" / "trial-2311041-1011194-instrument_profile.gpx"
OUTDIR = ROOT / ".tmp" / "opt"
PROJECT = OUTDIR / "best.gpx"


def clear_flags(project):
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def configure(project, *, inst=(), sample=(), cells=(), broad=(), atoms=None, uiso=()):
    clear_flags(project)
    hist = project.histogram(0)
    hist.data["Background"][0][1] = True
    for key in inst:
        hist.InstrumentParameters[key][2] = True
    for key in sample:
        hist.SampleParameters[key][1] = True
    for phase in project.phases():
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    for phase_id in cells:
        project.phases()[phase_id].data["General"]["Cell"][0] = True
    for phase_id in broad:
        hap = project.phases()[phase_id].data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][2][0] = True
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][2][0] = True
    for phase_id in uiso:
        for atom in project.phases()[phase_id].atoms():
            atom.refinement_flags = "U"
    for phase_id, labels in (atoms or {}).items():
        selected = set(labels)
        for atom in project.phases()[phase_id].atoms():
            if atom.label in selected:
                atom.refinement_flags = "X"


def wr(project):
    return float(project.histogram(0).residuals["wR"])


def physical(project):
    hist = project.histogram(0)
    x, y, w, calc, bkg, diff = hist.data["data"][1]
    if not np.all(np.isfinite(calc)) or np.min(bkg) < -1e-5:
        return False, "nonfinite profile or negative background"
    inst = hist.InstrumentParameters
    bounds = {
        "Zero": (-0.25, 0.25), "U": (0.0, 40.0), "W": (2.0, 40.0),
        "X": (0.1, 6.0), "SH/L": (0.005, 0.10), "Polariz.": (0.5, 1.0),
    }
    for key, (lo, hi) in bounds.items():
        if not lo - 1e-8 <= float(inst[key][1]) <= hi + 1e-8:
            return False, f"instrument {key} outside physical range"
    shift = float(hist.SampleParameters["Shift"][0])
    if not -800.0 - 1e-8 <= shift <= 800.0 + 1e-8:
        return False, "sample shift outside physical range"
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap["Scale"][0] <= 0:
            return False, "nonpositive phase scale"
        size = float(hap["Size"][1][0])
        strain = float(hap["Mustrain"][1][0])
        if not 0.04 - 1e-8 <= size <= 1.5 + 1e-8:
            return False, f"{phase.name} size outside physical range"
        if not 0.0 - 1e-8 <= strain <= 8000.0 + 1e-8:
            return False, f"{phase.name} strain outside physical range"
        for atom in phase.atoms():
            if not 0.003 - 1e-8 <= atom.uiso <= 0.020 + 1e-8:
                return False, f"{phase.name} Uiso outside physical range"
    return True, "ok"


def summary(project, label, accepted, reason):
    hist = project.histogram(0)
    masses = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    fractions = masses / masses.sum()
    return {
        "label": label,
        "accepted": accepted,
        "reason": reason,
        "wR": wr(project),
        "weight_fractions": fractions.tolist(),
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
        "sample_shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "size_um": float(p.data["Histograms"][hist.name]["Size"][1][0]),
                "strain_ppm": float(p.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "uiso": [float(a.uiso) for a in p.atoms()],
            }
            for p in project.phases()
        ],
        "frozen": project.get_Frozen(),
    }


def set_bounds(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    controls["min dM/M"] = 1e-5
    project.set_Controls("cycles", 12)
    limits = {
        ":0:Zero": (-0.25, 0.25), ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0), ":0:SH/L": (0.005, 0.10), ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0), ":0:SurfRoughA": (0.05, 0.6), ":0:SurfRoughB": (0.02, 0.5),
    }
    for phase_id in range(len(project.phases())):
        limits[f"{phase_id}:0:Scale"] = (0.0, 1.0e6)
        limits[f"{phase_id}:0:Size;i"] = (0.04, 1.5)
        limits[f"{phase_id}:0:Mustrain;i"] = (0.0, 8000.0)
        limits[f"{phase_id}:0:Mustrain;a"] = (0.0, 32000.0)
        for atom_id in range(len(project.phases()[phase_id].atoms())):
            limits[f"{phase_id}::AUiso:{atom_id}"] = (0.003, 0.020)
    for variable, (lo, hi) in limits.items():
        project.set_Controls("parmMin", lo, variable)
        project.set_Controls("parmMax", hi, variable)


def initialize(project):
    hist = project.histogram(0)
    hist.InstrumentParameters["Zero"][1] = -0.24
    hist.InstrumentParameters["SH/L"][1] = 0.01
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    project.data["Constraints"]["data"] = {
        "Hist": [], "HAP": [], "Phase": [], "Global": [], "_seqmode": "auto-wildcard", "_seqhist": 0,
    }
    for phase_id, phase in enumerate(project.phases()):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Pref.Ori."][1] = 1.0
        for atom in phase.atoms():
            atom.uiso = 0.008
        variables = [f"{phase_id}::AUiso:{i}" for i in range(len(phase.atoms()))]
        if len(variables) > 1:
            project.add_EquivConstr(variables, reloadIdx=(phase_id == 0))
    set_bounds(project)
    clear_flags(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.set_Controls("cycles", 12)
    project.save()


def refine_stage(project, label, setup, repeats=2, tolerance=0.002):
    backup = OUTDIR / "accepted.gpx"
    project.save(PROJECT)
    shutil.copy2(PROJECT, backup)
    before = wr(project)
    setup(project)
    values = []
    for _ in range(repeats):
        project.set_Frozen(None)
        project.refine()
        values.append(wr(project))
        if len(values) > 1 and abs(values[-1] - values[-2]) < 0.001:
            break
    ok, reason = physical(project)
    after = wr(project)
    accepted = ok and after <= before + tolerance
    if not accepted:
        reason = reason if not ok else f"wR worsened from {before:.5f} to {after:.5f}"
        shutil.copy2(backup, PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
    else:
        reason = f"wR {before:.5f} -> {after:.5f}; cycles {values}"
        project.save(PROJECT)
        shutil.copy2(PROJECT, OUTDIR / f"{label}.gpx")
    print(label, "accepted" if accepted else "rejected", reason)
    return project, summary(project, label, accepted, reason)


def main():
    OUTDIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, PROJECT)
    project = G2.G2Project(gpxfile=str(PROJECT))
    initialize(project)
    history = [summary(project, "initialized", True, "normalized Uiso and physical bounds")]

    stages = [
        ("base", lambda p: configure(p), 3),
        ("calibration0", lambda p: configure(p, inst=("Zero",), sample=("Shift",)), 3),
        ("cell0_p0", lambda p: configure(p, cells=(0,)), 2),
        ("cell0_p1", lambda p: configure(p, cells=(1,)), 2),
        ("cell0_p2", lambda p: configure(p, cells=(2,)), 2),
        ("cell0_p3", lambda p: configure(p, cells=(3,)), 2),
        ("uiso_p0", lambda p: configure(p, uiso=(0,)), 2),
        ("uiso_p1", lambda p: configure(p, uiso=(1,)), 2),
        ("uiso_p2", lambda p: configure(p, uiso=(2,)), 2),
        ("uiso_p3", lambda p: configure(p, uiso=(3,)), 2),
        ("broad_p0", lambda p: configure(p, broad=(0,)), 3),
        ("broad_p1", lambda p: configure(p, broad=(1,)), 3),
        ("broad_p2", lambda p: configure(p, broad=(2,)), 3),
        ("broad_p3", lambda p: configure(p, broad=(3,)), 3),
        ("instrument", lambda p: configure(p, inst=("U", "W", "X", "SH/L")), 3),
        ("broad2_p0", lambda p: configure(p, broad=(0,)), 2),
        ("broad2_p1", lambda p: configure(p, broad=(1,)), 2),
        ("broad2_p2", lambda p: configure(p, broad=(2,)), 2),
        ("broad2_p3", lambda p: configure(p, broad=(3,)), 2),
        ("calibration", lambda p: configure(p, inst=("Zero",), sample=("Shift",)), 3),
        ("cell_p0", lambda p: configure(p, cells=(0,)), 2),
        ("cell_p1", lambda p: configure(p, cells=(1,)), 2),
        ("cell_p2", lambda p: configure(p, cells=(2,)), 2),
        ("cell_p3", lambda p: configure(p, cells=(3,)), 2),
    ]
    for label, setup, repeats in stages:
        project, row = refine_stage(project, label, setup, repeats)
        history.append(row)
        (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")

    # Symmetry-allowed atomic coordinates, one phase and substructure at a time.
    for phase_id, phase in enumerate(project.phases()):
        heavy = [a.label for a in phase.atoms() if a.element != "O"]
        oxygen = [a.label for a in phase.atoms() if a.element == "O"]
        if heavy:
            label = f"coords_p{phase_id}_heavy"
            project, row = refine_stage(project, label, lambda p, i=phase_id, a=heavy: configure(p, atoms={i: a}), 3)
            history.append(row)
        for j, atom_label in enumerate(oxygen):
            label = f"coords_p{phase_id}_O{j+1}"
            project, row = refine_stage(project, label, lambda p, i=phase_id, a=(atom_label,): configure(p, atoms={i: a}), 2)
            history.append(row)
        (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")

    final_stages = [
        ("uiso_all", lambda p: configure(p, uiso=tuple(range(len(p.phases())))), 3),
        ("profile_final", lambda p: configure(p, inst=("U", "W", "X", "SH/L")), 3),
        ("calibration_final", lambda p: configure(p, inst=("Zero",), sample=("Shift",)), 3),
    ]
    for label, setup, repeats in final_stages:
        project, row = refine_stage(project, label, setup, repeats)
        history.append(row)
    clear_flags(project)
    project.save(PROJECT)
    history.append(summary(project, "final", True, "all refinement flags cleared"))
    (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("FINAL", wr(project))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
