"""Replay-consistent staged refinement from the selected raw atomic project."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "trials" / "trial-2311041-1011194-instrument_profile.gpx"
OUTDIR = ROOT / ".tmp" / "rawopt"
PROJECT = OUTDIR / "best.gpx"


def clear_flags(project):
    hist = project.histogram(0)
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def configure(project, kind, phase_id=None, atom_labels=()):
    clear_flags(project)
    hist = project.histogram(0)
    if kind == "base":
        hist.data["Background"][0][1] = True
        for phase in project.phases():
            phase.data["Histograms"][hist.name]["Scale"][1] = True
    elif kind == "size":
        project.phases()[phase_id].data["Histograms"][hist.name]["Size"][2][0] = True
    elif kind == "strain":
        project.phases()[phase_id].data["Histograms"][hist.name]["Mustrain"][2][0] = True
    elif kind == "cell":
        project.phases()[phase_id].data["General"]["Cell"][0] = True
    elif kind == "coordinates":
        selected = set(atom_labels)
        for atom in project.phases()[phase_id].atoms():
            if atom.label in selected:
                atom.refinement_flags = "X"
    elif kind in hist.InstrumentParameters:
        hist.InstrumentParameters[kind][2] = True
    elif kind in hist.SampleParameters:
        hist.SampleParameters[kind][1] = True
    else:
        raise ValueError(kind)


def wr(project):
    return float(project.histogram(0).residuals["wR"])


def valid(project):
    hist = project.histogram(0)
    x, y, w, calc, bkg, diff = hist.data["data"][1]
    if not np.all(np.isfinite(calc)) or np.min(bkg) < -1e-6:
        return False, "invalid profile/background"
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if hap["Scale"][0] <= 0:
            return False, "nonpositive phase scale"
        if not 0.04 - 1e-8 <= hap["Size"][1][0] <= 1.5 + 1e-8:
            return False, f"{phase.name} size outside range"
        if not 0.0 - 1e-8 <= hap["Mustrain"][1][0] <= 8000.0 + 1e-8:
            return False, f"{phase.name} strain outside range"
    return True, "ok"


def snapshot(project, label, accepted, reason):
    hist = project.histogram(0)
    mass = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return {
        "label": label, "accepted": accepted, "reason": reason, "wR": wr(project),
        "fractions": (mass / mass.sum()).tolist(),
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
        "shift_um": float(hist.SampleParameters["Shift"][0]),
        "phases": [
            {
                "name": p.name, "cell": p.get_cell(),
                "size_um": float(p.data["Histograms"][hist.name]["Size"][1][0]),
                "strain_ppm": float(p.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "atoms": [{"label": a.label, "xyz": list(a.coordinates), "uiso": float(a.uiso)} for a in p.atoms()],
            }
            for p in project.phases()
        ],
        "frozen": project.get_Frozen(),
    }


def set_bounds(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    controls["min dM/M"] = 1e-5
    controls["shift factor"] = 1.0
    project.set_Controls("cycles", 8)
    limits = {
        ":0:U": (0.0, 40.0), ":0:W": (2.0, 40.0), ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10), ":0:Polariz.": (0.5, 1.0),
    }
    for i in range(len(project.phases())):
        limits[f"{i}:0:Scale"] = (0.0, 1.0e6)
        limits[f"{i}:0:Size;i"] = (0.04, 1.5)
        limits[f"{i}:0:Mustrain;i"] = (0.0, 8000.0)
    for variable, (lo, hi) in limits.items():
        project.set_Controls("parmMin", lo, variable)
        project.set_Controls("parmMax", hi, variable)


def stage(project, label, setup, repeats=1):
    project.save(PROJECT)
    backup = OUTDIR / "accepted.gpx"
    shutil.copy2(PROJECT, backup)
    before = wr(project)
    setup(project)
    values = []
    for _ in range(repeats):
        project.set_Frozen(None)
        project.refine()
        values.append(wr(project))
        if len(values) > 1 and abs(values[-1] - values[-2]) < 0.0005:
            break
    ok, why = valid(project)
    after = wr(project)
    accepted = ok and after <= before + 1e-7
    if accepted:
        reason = f"wR {before:.6f} -> {after:.6f}; {values}"
        clear_flags(project)
        project.save(PROJECT)
        shutil.copy2(PROJECT, OUTDIR / f"{label}.gpx")
    else:
        reason = why if not ok else f"wR worsened {before:.6f} -> {after:.6f}"
        shutil.copy2(backup, PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
    print(label, "accepted" if accepted else "rejected", reason)
    return project, snapshot(project, label, accepted, reason)


def main():
    global SOURCE, OUTDIR, PROJECT
    if len(sys.argv) >= 3:
        SOURCE = Path(sys.argv[1]).resolve()
        OUTDIR = Path(sys.argv[2]).resolve()
        PROJECT = OUTDIR / "best.gpx"
    OUTDIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, PROJECT)
    project = G2.G2Project(gpxfile=str(PROJECT))
    project.data["Constraints"]["data"] = {
        "Hist": [], "HAP": [], "Phase": [], "Global": [], "_seqmode": "auto-wildcard", "_seqhist": 0,
    }
    clear_flags(project)
    set_bounds(project)
    project.save(PROJECT)
    history = [snapshot(project, "start", True, "replay-consistent source")]

    # Refine physically bounded isotropic broadening one parameter at a time.
    for phase_id in range(len(project.phases())):
        for kind in ("size", "strain"):
            label = f"{kind}_p{phase_id}"
            project, row = stage(project, label, lambda p, k=kind, i=phase_id: configure(p, k, i), 2)
            history.append(row)
    project, row = stage(project, "base_after_broadening", lambda p: configure(p, "base"), 2)
    history.append(row)

    # Instrument terms are also separated to avoid profile correlations.
    for key in ("U", "W", "X"):
        project, row = stage(project, f"instrument_{key.replace('/', '_')}", lambda p, k=key: configure(p, k), 2)
        history.append(row)
    def setup_shl(p):
        p.histogram(0).InstrumentParameters["SH/L"][1] = 0.005
        configure(p, "SH/L")
    project, row = stage(project, "instrument_SH_L", setup_shl, 2)
    history.append(row)

    # Symmetry-allowed coordinates: heavy sites first, then one oxygen site at a time.
    for phase_id in range(len(project.phases())):
        phase = project.phases()[phase_id]
        heavy = [a.label for a in phase.atoms() if a.element != "O"]
        oxygens = [a.label for a in phase.atoms() if a.element == "O"]
        for atom_label in heavy + oxygens:
            safe = atom_label.replace("/", "_")
            label = f"coords_p{phase_id}_{safe}"
            project, row = stage(
                project, label,
                lambda p, i=phase_id, a=(atom_label,): configure(p, "coordinates", i, a),
                2,
            )
            history.append(row)
        # Reconcile scale and background after each phase's intensity adaptation.
        project, row = stage(project, f"base_after_coords_p{phase_id}", lambda p: configure(p, "base"), 2)
        history.append(row)
        (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")

    # Revisit broadening after coordinates, then polarization and a final linear fit.
    for phase_id in range(len(project.phases())):
        for kind in ("size", "strain"):
            label = f"final_{kind}_p{phase_id}"
            project, row = stage(project, label, lambda p, k=kind, i=phase_id: configure(p, k, i), 2)
            history.append(row)
    project, row = stage(project, "polarization", lambda p: configure(p, "Polariz."), 2)
    history.append(row)
    project, row = stage(project, "base_final", lambda p: configure(p, "base"), 3)
    history.append(row)
    clear_flags(project)
    project.save(PROJECT)
    history.append(snapshot(project, "final", True, "flags cleared"))
    (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("FINAL", wr(project))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
