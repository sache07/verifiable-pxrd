"""Staged GSAS-II comparison of three-phase Cu-W-O candidate models."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from scipy.ndimage import percentile_filter
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_cif(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def clear_flags(project, hist):
    hist.data["Background"][0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for key, value in hist.SampleParameters.items():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], (bool, np.bool_)):
            value[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Size"][2] = [False for _ in hap["Size"][2]]
        hap["Size"][5] = [False for _ in hap["Size"][5]]
        hap["Mustrain"][2] = [False for _ in hap["Mustrain"][2]]
        hap["Mustrain"][5] = [False for _ in hap["Mustrain"][5]]
        hap["Pref.Ori."][2] = False


def set_flags(project, hist, flags):
    clear_flags(project, hist)
    if "background" in flags:
        hist.data["Background"][0][1] = True
    for key in flags & {"Zero", "U", "W", "X", "SH/L", "Polariz."}:
        hist.InstrumentParameters[key][2] = True
    if "Shift" in flags:
        hist.SampleParameters["Shift"][1] = True
    if "roughness" in flags:
        hist.SampleParameters["SurfRoughA"][1] = True
        hist.SampleParameters["SurfRoughB"][1] = True
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        if "scales" in flags:
            hap["Scale"][1] = True
        if "cells" in flags:
            phase.data["General"]["Cell"][0] = True
        if "size" in flags:
            hap["Size"][0] = "isotropic"
            hap["Size"][2][0] = True
        if "strain" in flags:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][2][0] = True


def mass_fractions(project, hist):
    masses = np.array(
        [p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0] for p in project.phases()],
        dtype=float,
    )
    return masses / masses.sum()


def state(project, hist, stage):
    cov = project.data.get("Covariance", {}).get("data", {})
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    residuals = {}
    for key, value in hist.residuals.items():
        if isinstance(value, (int, float, np.integer, np.floating)):
            residuals[key] = float(value)
    return {
        "stage": stage,
        "residuals": residuals,
        "gof": float(cov.get("Rvals", {}).get("GOF", np.nan)),
        "n_parameters": len(cov.get("varyList", [])),
        "weight_fractions": mass_fractions(project, hist).tolist(),
        "instrument": {k: float(inst[k][1]) for k in ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]},
        "sample": {
            "Shift": float(sample["Shift"][0]),
            "SurfRoughA": float(sample["SurfRoughA"][0]),
            "SurfRoughB": float(sample["SurfRoughB"][0]),
        },
        "phases": [
            {
                "name": p.name,
                "cell": p.get_cell(),
                "scale": float(p.data["Histograms"][hist.name]["Scale"][0]),
                "size": float(p.data["Histograms"][hist.name]["Size"][1][0]),
                "strain": float(p.data["Histograms"][hist.name]["Mustrain"][1][0]),
            }
            for p in project.phases()
        ],
        "vary_list": [str(v) for v in cov.get("varyList", [])],
    }


def set_limits(project, nphases):
    limits = {
        ":0:Zero": (-1.0, 1.0),
        ":0:U": (0.0, 100.0),
        ":0:W": (0.01, 100.0),
        ":0:X": (0.001, 20.0),
        ":0:SH/L": (0.001, 0.2),
        ":0:Polariz.": (0.0, 1.0),
        ":0:Shift": (-1200.0, 1200.0),
        ":0:SurfRoughA": (0.001, 1.0),
        ":0:SurfRoughB": (0.001, 1.0),
    }
    for p in range(nphases):
        limits[f"{p}:0:Scale"] = (0.0, 1.0e6)
        limits[f"{p}:0:Size;i"] = (0.02, 5.0)
        limits[f"{p}:0:Mustrain;i"] = (0.0, 20000.0)
    for var, (lo, hi) in limits.items():
        project.set_Controls("parmMin", lo, var)
        project.set_Controls("parmMax", hi, var)


def build_project(wo3_id, cuo_id, out):
    project = G2.G2Project(newgpx=str(out))
    ids = ["4000806", "1527404", wo3_id, cuo_id]
    names = ["CuWO4_P-1", "Cu3WO6_Pa-3", f"WO3_{wo3_id}", f"CuO_{cuo_id}"]
    phases = [project.add_phase(str(cod_cif(i)), phasename=n, fmthint="CIF") for i, n in zip(ids, names)]
    hist = project.add_powder_histogram(
        str(ROOT / "inputs" / "pattern.csv"),
        str(ROOT / "instrument.instprm"),
        phases=phases,
        fmthint="comma",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [0.0, False]
    x, y = hist.data["data"][1][:2]
    baseline = percentile_filter(y, percentile=20, size=401, mode="nearest")
    t = 2 * (x - x[0]) / (x[-1] - x[0]) - 1
    coeffs = np.polynomial.chebyshev.chebfit(t, baseline, 10).tolist()
    hist.set_refinements(
        {"Background": {"type": "chebyschev-1", "no. coeffs": len(coeffs), "coeffs": coeffs, "refine": False}}
    )
    for phase, wf in zip(phases, [0.65, 0.14, 0.18, 0.03]):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [2.0e5 * wf / phase.data["General"]["Mass"], False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.30
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Extinction"] = [0.0, False]
    set_limits(project, len(phases))
    project.set_Controls("cycles", 8)
    return project, hist


def main():
    if len(sys.argv) < 2:
        raise SystemExit("usage: refine_trial.py WO3_COD_ID [CuO_COD_ID]")
    wo3_id = sys.argv[1]
    cuo_id = sys.argv[2] if len(sys.argv) > 2 else "1011194"
    tag = f"{wo3_id}-{cuo_id}"
    outdir = ROOT / ".tmp" / "trials"
    outdir.mkdir(parents=True, exist_ok=True)
    out = outdir / f"trial-{tag}.gpx"
    for old in outdir.glob(f"trial-{tag}*"):
        if old.is_file():
            old.unlink()
    project, hist = build_project(wo3_id, cuo_id, out)
    stages = [
        ("scale_background", {"scales", "background"}),
        ("position", {"scales", "background", "Zero", "Shift"}),
        ("cells", {"scales", "background", "Zero", "Shift", "cells"}),
        ("instrument_profile", {"scales", "background", "Zero", "Shift", "cells", "U", "W", "X", "SH/L"}),
        ("sizes", {"scales", "background", "Zero", "Shift", "cells", "U", "W", "X", "SH/L", "size"}),
        ("strains", {"scales", "background", "Zero", "Shift", "cells", "U", "W", "X", "SH/L", "size", "strain"}),
    ]
    history = []
    for stage, flags in stages:
        set_flags(project, hist, flags)
        project.refine()
        hist = project.histogram(0)
        row = state(project, hist, stage)
        history.append(row)
        print(stage, "wR", row["residuals"].get("wR"), "wf", row["weight_fractions"])
        shutil.copy2(out, outdir / f"trial-{tag}-{stage}.gpx")
    project.save()
    summary = {"wo3_id": wo3_id, "cuo_id": cuo_id, "project": str(out), "history": history, "final": history[-1]}
    (outdir / f"trial-{tag}-summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
