"""Post-refinement: cells, coupled coordinates, texture and anisotropic strain."""

from pathlib import Path
import json
import shutil
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

from optimize_raw import clear_flags, configure, wr, valid


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "rawopt" / "best.gpx"
OUTDIR = ROOT / ".tmp" / "postopt"
PROJECT = OUTDIR / "best.gpx"
AXES_PO = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])
AXES_STRAIN = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def chi(project):
    x, y, w, calc, bkg, diff = project.histogram(0).data["data"][1]
    return float(np.sum(w * (y - calc) ** 2))


def fractions(project):
    hist = project.histogram(0)
    mass = np.array([
        p.data["General"]["Mass"] * p.data["Histograms"][hist.name]["Scale"][0]
        for p in project.phases()
    ])
    return (mass / mass.sum()).tolist()


def record(project, label, accepted, reason, candidates=None):
    hist = project.histogram(0)
    return {
        "label": label, "accepted": accepted, "reason": reason,
        "wR": wr(project), "chi_square": chi(project), "fractions": fractions(project),
        "instrument": {k: float(hist.InstrumentParameters[k][1]) for k in ["Zero", "U", "W", "X", "SH/L", "Polariz."]},
        "sample": {k: (float(v[0]) if isinstance(v, list) else v) for k, v in hist.SampleParameters.items() if k in ["Shift", "SurfRoughA", "SurfRoughB"]},
        "phases": [
            {
                "name": p.name, "cell": p.get_cell(),
                "size_um": float(p.data["Histograms"][hist.name]["Size"][1][0]),
                "strain": p.data["Histograms"][hist.name]["Mustrain"],
                "preferred_orientation": p.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for p in project.phases()
        ],
        "candidates": candidates,
    }


def stage(project, label, setup, repeats=2):
    clear_flags(project)
    project.save(PROJECT)
    backup = OUTDIR / "accepted.gpx"
    shutil.copy2(PROJECT, backup)
    before = wr(project)
    setup(project)
    values = []
    for _ in range(repeats):
        project.set_Frozen(None)
        project.refine()
        values.append(wr(project))
        if len(values) > 1 and abs(values[-1] - values[-2]) < 0.0005:
            break
    ok, why = valid(project)
    after = wr(project)
    accepted = ok and after <= before + 1e-7
    if accepted:
        reason = f"wR {before:.6f} -> {after:.6f}; {values}"
        clear_flags(project)
        project.save(PROJECT)
        shutil.copy2(PROJECT, OUTDIR / f"{label}.gpx")
    else:
        reason = why if not ok else f"wR worsened {before:.6f} -> {after:.6f}"
        shutil.copy2(backup, PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
    print(label, "accepted" if accepted else "rejected", reason)
    return project, record(project, label, accepted, reason)


def choose_preferred_orientation(project, phase_id):
    clear_flags(project)
    project.save(PROJECT)
    base_chi, base_wr = chi(project), wr(project)
    candidates = []
    best = None
    for axis in AXES_PO:
        path = OUTDIR / f"po-p{phase_id}-{'-'.join(map(str, axis))}.gpx"
        shutil.copy2(PROJECT, path)
        trial = G2.G2Project(gpxfile=str(path))
        clear_flags(trial)
        hist = trial.histogram(0)
        hap = trial.phases()[phase_id].data["Histograms"][hist.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = True
        hap["Pref.Ori."][3] = list(axis)
        trial.set_Frozen(None)
        trial.refine()
        ratio = float(trial.phases()[phase_id].data["Histograms"][hist.name]["Pref.Ori."][1])
        ok = 0.7 <= ratio <= 1.4
        row = {"axis": list(axis), "ratio": ratio, "wR": wr(trial), "chi_square": chi(trial), "physical": ok}
        candidates.append(row)
        if ok and (best is None or row["chi_square"] < best[0]):
            clear_flags(trial)
            trial.save(path)
            best = (row["chi_square"], path, row)
    penalty = float(np.log(8301) + 2 * np.log(len(AXES_PO)))
    accepted = best is not None and best[0] < base_chi - penalty
    if accepted:
        shutil.copy2(best[1], PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
        reason = f"axis {best[2]['axis']}, ratio {best[2]['ratio']:.6f}; chi {base_chi:.2f} -> {best[0]:.2f}"
    else:
        reason = f"no axis passed penalized chi-square improvement > {penalty:.2f}"
    print(f"preferred_orientation_p{phase_id}", "accepted" if accepted else "rejected", reason)
    return project, record(project, f"preferred_orientation_p{phase_id}", accepted, reason, candidates)


def choose_uniaxial_strain(project, phase_id):
    clear_flags(project)
    project.save(PROJECT)
    base_chi = chi(project)
    candidates = []
    best = None
    for axis in AXES_STRAIN:
        path = OUTDIR / f"strain-p{phase_id}-{'-'.join(map(str, axis))}.gpx"
        shutil.copy2(PROJECT, path)
        trial = G2.G2Project(gpxfile=str(path))
        clear_flags(trial)
        hist = trial.histogram(0)
        hap = trial.phases()[phase_id].data["Histograms"][hist.name]
        equatorial = float(hap["Mustrain"][1][0])
        hap["Mustrain"][0] = "uniaxial"
        hap["Mustrain"][1][1] = equatorial
        hap["Mustrain"][2][0] = True
        hap["Mustrain"][2][1] = True
        hap["Mustrain"][3] = list(axis)
        trial.set_Frozen(None)
        trial.refine()
        values = trial.phases()[phase_id].data["Histograms"][hist.name]["Mustrain"][1]
        eq, axial = float(values[0]), float(values[1])
        ratio = axial / eq if eq > 0 else np.inf
        ok = 0 <= eq <= 8000 and 0 <= axial <= 32000 and 0.25 <= ratio <= 4.0
        row = {"axis": list(axis), "equatorial_ppm": eq, "axial_ppm": axial, "ratio": ratio,
               "wR": wr(trial), "chi_square": chi(trial), "physical": bool(ok)}
        candidates.append(row)
        if ok and (best is None or row["chi_square"] < best[0]):
            clear_flags(trial)
            trial.save(path)
            best = (row["chi_square"], path, row)
    penalty = float(np.log(8301) + 2 * np.log(len(AXES_STRAIN)))
    accepted = best is not None and best[0] < base_chi - penalty
    if accepted:
        shutil.copy2(best[1], PROJECT)
        project = G2.G2Project(gpxfile=str(PROJECT))
        reason = f"axis {best[2]['axis']}, ratio {best[2]['ratio']:.6f}; chi {base_chi:.2f} -> {best[0]:.2f}"
    else:
        reason = f"no axis passed penalized chi-square improvement > {penalty:.2f}"
    print(f"uniaxial_strain_p{phase_id}", "accepted" if accepted else "rejected", reason)
    return project, record(project, f"uniaxial_strain_p{phase_id}", accepted, reason, candidates)


def main():
    global SOURCE, OUTDIR, PROJECT
    if len(sys.argv) >= 3:
        SOURCE = Path(sys.argv[1]).resolve()
        OUTDIR = Path(sys.argv[2]).resolve()
        PROJECT = OUTDIR / "best.gpx"
    stop_pre_roughness = "--pre-rough" in sys.argv[3:]
    OUTDIR.mkdir(parents=True, exist_ok=True)
    shutil.copy2(SOURCE, PROJECT)
    project = G2.G2Project(gpxfile=str(PROJECT))
    clear_flags(project)
    project.data["Controls"]["data"]["min dM/M"] = 1e-5
    project.set_Controls("cycles", 8)
    project.save(PROJECT)
    history = [record(project, "start", True, "replay-consistent rawopt project")]

    for phase_id in range(len(project.phases())):
        project, row = stage(project, f"cell_p{phase_id}", lambda p, i=phase_id: configure(p, "cell", i), 2)
        history.append(row)
    project, row = stage(project, "base_after_cells", lambda p: configure(p, "base"), 2)
    history.append(row)

    for key in ("Zero", "Shift"):
        project, row = stage(project, f"calibration_{key}", lambda p, k=key: configure(p, k), 2)
        history.append(row)

    # Comparable coupled-coordinate relaxation from the already adapted starts.
    for phase_id, phase in enumerate(project.phases()):
        for group, labels in (
            ("heavy", [a.label for a in phase.atoms() if a.element != "O"]),
            ("oxygen", [a.label for a in phase.atoms() if a.element == "O"]),
        ):
            if not labels:
                continue
            project, row = stage(
                project, f"coords_p{phase_id}_{group}",
                lambda p, i=phase_id, a=tuple(labels): configure(p, "coordinates", i, a), 2,
            )
            history.append(row)
        project, row = stage(project, f"base_after_coords_p{phase_id}", lambda p: configure(p, "base"), 2)
        history.append(row)

    for phase_id in range(len(project.phases())):
        for kind in ("size", "strain"):
            project, row = stage(project, f"profile_{kind}_p{phase_id}", lambda p, k=kind, i=phase_id: configure(p, k, i), 2)
            history.append(row)
    for key in ("U", "W", "X", "Polariz."):
        project, row = stage(project, f"profile_{key.replace('/', '_')}", lambda p, k=key: configure(p, k), 2)
        history.append(row)

    if stop_pre_roughness:
        clear_flags(project)
        project.save(PROJECT)
        history.append(record(project, "final_pre_roughness", True, "refinement flags cleared"))
        (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")
        print("FINAL PRE-ROUGHNESS", wr(project), chi(project), fractions(project))
        return

    # Whole-specimen surface roughness trial within the generating range.
    def roughness(p):
        configure(p, "SurfRoughA")
        h = p.histogram(0)
        h.SampleParameters["SurfRoughA"] = [0.30, True]
        h.SampleParameters["SurfRoughB"] = [0.10, True]
        p.set_Controls("parmMin", 0.05, ":0:SurfRoughA")
        p.set_Controls("parmMax", 0.60, ":0:SurfRoughA")
        p.set_Controls("parmMin", 0.02, ":0:SurfRoughB")
        p.set_Controls("parmMax", 0.50, ":0:SurfRoughB")
    project, row = stage(project, "surface_roughness", roughness, 2)
    history.append(row)
    project, row = stage(project, "base_after_roughness", lambda p: configure(p, "base"), 2)
    history.append(row)

    for phase_id in range(len(project.phases())):
        project, row = choose_preferred_orientation(project, phase_id)
        history.append(row)
    for phase_id in range(len(project.phases())):
        project, row = choose_uniaxial_strain(project, phase_id)
        history.append(row)

    project, row = stage(project, "base_final", lambda p: configure(p, "base"), 3)
    history.append(row)
    clear_flags(project)
    project.save(PROJECT)
    history.append(record(project, "final", True, "refinement flags cleared"))
    (OUTDIR / "history.json").write_text(json.dumps(history, indent=2) + "\n")
    print("FINAL", wr(project), chi(project), fractions(project))


if __name__ == "__main__":
    G2.SetPrintLevel("warn")
    main()
