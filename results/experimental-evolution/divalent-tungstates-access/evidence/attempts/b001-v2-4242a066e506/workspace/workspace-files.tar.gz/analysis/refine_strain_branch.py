#!/usr/bin/env python3
"""Common-state uniaxial microstrain branch test for one phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, rwp, set_bounds


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--axis", required=True)
    parser.add_argument("--axial-ratio", type=float, default=1.0)
    parser.add_argument("--rounds", type=int, default=2)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3 or not any(axis):
        raise ValueError("axis must be a nonzero h,k,l triple")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.unlink(missing_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.save(str(args.output.resolve()))
    freeze_all(project)
    set_bounds(project)
    hist = project.histograms()[0]
    phases = project.phases()
    if len(phases) > 2:
        phases[2].data["Histograms"][hist.name]["Scale"] = [0.0, False]
    for retained in phases[:2]:
        retained.data["Histograms"][hist.name]["Scale"][1] = True
    phases[0].data["Histograms"][hist.name]["Pref.Ori."][2] = True

    phase = phases[args.phase]
    hap = phase.data["Histograms"][hist.name]
    eq = float(hap["Mustrain"][1][0])
    hap["Mustrain"][0] = "uniaxial"
    hap["Mustrain"][1][0] = eq
    hap["Mustrain"][1][1] = max(0.0, eq * args.axial_ratio)
    hap["Mustrain"][2] = [True, True, False]
    hap["Mustrain"][3] = axis
    h_id = hist.data["data"][0]["hId"]
    for suffix, high in [("Mustrain;i", 8000.0), ("Mustrain;a", 32000.0)]:
        variable = f"{phase.id}:{h_id}:{suffix}"
        project.set_Controls("parmMin", 0.0, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    project.set_Controls("cycles", 10)
    for i in range(args.rounds):
        project.refine()
        print("round", i + 1, "stored_Rwp", rwp(hist), "strain", hap["Mustrain"], flush=True)
    project.set_Controls("cycles", 0)
    project.refine()
    fresh = rwp(hist)
    project.save(str(args.output.resolve()))
    result = {
        "phase": phase.name,
        "axis": axis,
        "initial_axial_ratio": args.axial_ratio,
        "fresh_Rwp_percent": fresh,
        "mustrain": hap["Mustrain"],
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print("fresh_Rwp", fresh, result, flush=True)


if __name__ == "__main__":
    main()
