#!/usr/bin/env python3
"""Common-state preferred-orientation tests for retained zincite."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, set_bounds


def full_rwp(hist) -> float:
    data = hist.data["data"][1]
    yo, w, yc = (np.asarray(data[i], dtype=float) for i in [1, 2, 3])
    return float(100 * np.sqrt(np.sum(w * (yo - yc) ** 2) / np.sum(w * yo**2)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")

    axes = [[0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1]]
    records = []
    for axis in axes:
        tag = "_".join(map(str, axis))
        output = args.outdir / f"axis_{tag}.gpx"
        output.unlink(missing_ok=True)
        try:
            project = G2.G2Project(
                str(args.input.resolve()), newgpx=str(output.resolve())
            )
            project.save(str(output.resolve()))
            freeze_all(project)
            set_bounds(project)
            hist = project.histograms()[0]
            for phase in project.phases():
                phase.data["Histograms"][hist.name]["Scale"][1] = True
            phase = project.phase("ZnO_zincite")
            hap = phase.data["Histograms"][hist.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 0.9
            hap["Pref.Ori."][2] = True
            hap["Pref.Ori."][3] = axis
            project.set_Controls("cycles", 10)
            project.refine()
            project.refine()
            project.set_Controls("cycles", 0)
            project.refine()
            project.save(str(output.resolve()))
            raw = [
                float(p.data["Histograms"][hist.name]["Scale"][0])
                * float(p.data["General"]["Mass"])
                for p in project.phases()
            ]
            row = {
                "axis": axis,
                "MD_ratio": float(hap["Pref.Ori."][1]),
                "fresh_full_grid_Rwp_percent": full_rwp(hist),
                "weight_fractions": {
                    p.name: float(v / sum(raw))
                    for p, v in zip(project.phases(), raw)
                },
                "project": str(output),
                "status": "completed",
            }
        except Exception as exc:
            row = {
                "axis": axis,
                "status": "unknown_after_failure",
                "error": str(exc),
            }
        records.append(row)
        print(json.dumps(row), flush=True)
    (args.outdir / "grid.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
