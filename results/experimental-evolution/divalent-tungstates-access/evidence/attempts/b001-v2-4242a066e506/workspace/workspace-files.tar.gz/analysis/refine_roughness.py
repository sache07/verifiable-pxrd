#!/usr/bin/env python3
"""Common-state Suortti surface-roughness branch test."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, rwp, set_bounds


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--A", type=float, required=True)
    parser.add_argument("--B", type=float, required=True)
    parser.add_argument("--rounds", type=int, default=2)
    parser.add_argument("--present-bounds", action="store_true")
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.unlink(missing_ok=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.save(str(args.output.resolve()))
    freeze_all(project)
    set_bounds(project)
    hist = project.histograms()[0]
    phases = project.phases()
    if len(phases) > 2:
        phases[2].data["Histograms"][hist.name]["Scale"] = [0.0, False]
    for phase in phases[:2]:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        # Retain any accepted phase texture refinements.
        if abs(float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]) - 1.0) > 1e-8:
            phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    sample = hist.data["Sample Parameters"]
    sample["SurfRoughA"] = [args.A, True]
    sample["SurfRoughB"] = [args.B, True]
    h_id = hist.data["data"][0]["hId"]
    limits = {"SurfRoughA": (0.05, 0.6), "SurfRoughB": (0.02, 0.5)} if args.present_bounds else {
        "SurfRoughA": (0.0, 0.8), "SurfRoughB": (0.0, 0.6)
    }
    for name, (low, high) in limits.items():
        variable = f":{h_id}:{name}"
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", 10)
    for i in range(args.rounds):
        project.refine()
        print("round", i + 1, "stored_Rwp", rwp(hist), "A/B", sample["SurfRoughA"], sample["SurfRoughB"], flush=True)
    project.set_Controls("cycles", 0)
    project.refine()
    fresh = rwp(hist)
    project.save(str(args.output.resolve()))
    result = {"fresh_Rwp_percent": fresh, "SurfRoughA": sample["SurfRoughA"], "SurfRoughB": sample["SurfRoughB"]}
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print("fresh_Rwp", fresh, result, flush=True)


if __name__ == "__main__":
    main()
