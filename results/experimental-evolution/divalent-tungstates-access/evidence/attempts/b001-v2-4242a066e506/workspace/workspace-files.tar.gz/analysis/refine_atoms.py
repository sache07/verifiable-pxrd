#!/usr/bin/env python3
"""Refine selected atomic coordinates from a freshly replayed GSAS-II state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, rwp, set_bounds


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--elements", default="all", help="comma-separated symbols or all")
    parser.add_argument("--flags", default="X", help="GSAS-II atom refinement flags")
    parser.add_argument("--rounds", type=int, default=3)
    args = parser.parse_args()
    selected = None if args.elements == "all" else set(args.elements.split(","))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.unlink(missing_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    freeze_all(project)
    set_bounds(project)
    hist = project.histograms()[0]
    phases = project.phases()
    if len(phases) > 2:
        phases[2].data["Histograms"][hist.name]["Scale"] = [0.0, False]
    for phase in phases[:2]:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    # Keep the established target texture coupled to the intensity refinement.
    phases[0].data["Histograms"][hist.name]["Pref.Ori."][2] = True

    phase = phases[args.phase]
    refined = []
    before = {}
    for atom in phase.atoms():
        before[atom.label] = {
            "element": atom.element,
            "coordinates": list(map(float, atom.coordinates)),
            "uiso": float(atom.uiso),
        }
        if selected is None or atom.element in selected:
            atom.refinement_flags = args.flags
            refined.append(atom.label)
    if not refined:
        raise ValueError("no atoms selected")

    project.set_Controls("cycles", 10)
    for i in range(args.rounds):
        project.refine()
        print("round", i + 1, "stored_Rwp", rwp(hist), flush=True)
    project.set_Controls("cycles", 0)
    project.refine()
    fresh = rwp(hist)
    project.save(str(args.output.resolve()))
    after = {
        atom.label: {
            "element": atom.element,
            "coordinates": list(map(float, atom.coordinates)),
            "uiso": float(atom.uiso),
            "flags": atom.refinement_flags,
        }
        for atom in phase.atoms()
    }
    result = {
        "phase": phase.name,
        "selected_atoms": refined,
        "flags": args.flags,
        "fresh_Rwp_percent": fresh,
        "before": before,
        "after": after,
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print("fresh_Rwp", fresh, "phase", phase.name, "atoms", refined, flush=True)


if __name__ == "__main__":
    main()
