#!/usr/bin/env python3
"""Export all required submission artifacts from one fresh GSAS-II state."""

from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("pattern", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    submitted_gpx = args.outdir / "final.gpx"
    submitted_gpx.unlink(missing_ok=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(
        str(args.project.resolve()), newgpx=str(submitted_gpx.resolve())
    )
    if len(project.histograms()) != 1 or len(project.phases()) != 3:
        raise ValueError("submission must contain one histogram and three phases")

    # Freeze the accepted model, replay it over every measured point and save
    # exactly that state as the submission project.
    hist = project.histograms()[0]
    public = np.loadtxt(args.pattern, delimiter=",", skiprows=1, ndmin=2)
    hist.data["Limits"][1] = [float(public[0, 0]), float(public[-1, 0])]
    freeze_all(project)
    project.set_Controls("cycles", 0)
    project.refine()
    project.save(str(submitted_gpx.resolve()))

    arrays = hist.data["data"][1]
    x, observed, gsas_weights, calculated, background = (
        np.asarray(arrays[i], dtype=float) for i in range(5)
    )
    if x.shape != public[:, 0].shape:
        raise ValueError("GSAS histogram does not span the supplied pattern")
    if not np.allclose(x, public[:, 0], rtol=0, atol=1e-7):
        raise ValueError("GSAS and supplied angle grids differ")
    if not np.allclose(observed, public[:, 1], rtol=0, atol=1e-5):
        raise ValueError("GSAS and supplied observed intensities differ")
    if not all(np.all(np.isfinite(v)) for v in [calculated, background]):
        raise ValueError("nonfinite calculated profile")
    if np.min(calculated) < -1e-6:
        raise ValueError("negative calculated total profile")

    difference = observed - calculated
    weights = 1.0 / np.maximum(observed, 1.0)
    denominator = float(np.sum(weights * observed**2))
    wrss = float(np.sum(weights * difference**2))
    stats = {
        "Rwp_percent": float(100.0 * np.sqrt(wrss / denominator)),
        "Rp_percent": float(
            100.0 * np.sum(np.abs(difference)) / np.sum(np.abs(observed))
        ),
        "weighted_residual_sum_squares": wrss,
        "mean_weighted_squared_residual": float(wrss / len(x)),
        "n_points": int(len(x)),
        "weighting": "1/max(observed_counts,1)",
        "minimum_calculated_counts": float(np.min(calculated)),
        "minimum_background_counts": float(np.min(background)),
    }

    raw_masses = []
    for phase in project.phases():
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        if scale <= 0 or mass <= 0:
            raise ValueError(f"nonpositive crystalline scale for {phase.name}")
        raw_masses.append(scale * mass)
    total = float(sum(raw_masses))

    filename_by_phase = {
        "ZnWO4_wolframite": "ZnWO4_wolframite.cif",
        "WO3": "WO3_monoclinic.cif",
        "ZnO_zincite": "ZnO_zincite.cif",
    }
    pretty_by_phase = {
        "ZnWO4_wolframite": "ZnWO4 (wolframite)",
        "WO3": "WO3 (monoclinic)",
        "ZnO_zincite": "ZnO (zincite)",
    }
    formula_by_phase = {
        "ZnWO4_wolframite": "ZnWO4",
        "WO3": "WO3",
        "ZnO_zincite": "ZnO",
    }
    records = []
    for phase, raw_mass in zip(project.phases(), raw_masses):
        if phase.name not in filename_by_phase:
            raise ValueError(f"unexpected retained phase {phase.name}")
        filename = filename_by_phase[phase.name]
        phase.export_CIF(str((args.outdir / filename).resolve()))
        records.append(
            {
                "name": pretty_by_phase[phase.name],
                "formula": formula_by_phase[phase.name],
                "space_group": phase.data["General"]["SGData"]["SpGrp"],
                "cif_path": filename,
                "weight_fraction": float(raw_mass / total),
            }
        )

    with (args.outdir / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(
            ["two_theta", "observed", "calculated", "difference", "background"]
        )
        writer.writerows(
            zip(x, observed, calculated, difference, background, strict=True)
        )

    result = {
        "phases": records,
        "phase_fraction_basis": "normalized over modeled crystalline phases",
        "fit_statistics": stats,
        "refinement_histogram": hist.name,
        "calibration": {
            "zero_shift_deg": float(
                hist.data["Instrument Parameters"][0]["Zero"][1]
            ),
            "sample_displacement_micrometers": float(
                hist.data["Sample Parameters"]["Shift"][0]
            ),
        },
    }
    (args.outdir / "result.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n"
    )
    print(json.dumps(result, indent=2))
    print("GSAS_weight_Rwp_percent", 100 * np.sqrt(np.sum(gsas_weights * difference**2) / np.sum(gsas_weights * observed**2)))


if __name__ == "__main__":
    main()
