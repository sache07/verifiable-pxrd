#!/usr/bin/env python3
"""Build normalized starting CIFs for the Zn-W-O refinement.

The unavailable ZnWO4 reference is transferred from the isostructural
wolframite FeWO4 COD entry 1567215 by Fe -> Zn substitution.  Other CIFs are
normalized copies of ordinary references from the case-specific COD library.
"""

from pathlib import Path

from pymatgen.core import Lattice, Structure
from pymatgen.io.cif import CifWriter


ROOT = Path(
    "<EVOLUTION_SOURCE>/runs/divalent-tungstates-access/"
    "resources/b001-c05/cif"
)
OUT = Path(__file__).resolve().parents[1] / "analysis" / "models"


def cod_path(cod_id: str) -> Path:
    return ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def write_with_uiso(structure: Structure, path: Path, uiso: float = 0.008) -> None:
    structure = structure.copy()
    structure.remove_oxidation_states()
    for i, site in enumerate(structure):
        site.label = f"{site.species_string}{i + 1}"
    writer = CifWriter(structure, symprec=0.001, significant_figures=10)
    tag = "_atom_site_U_iso_or_equiv"
    for block in writer.cif_file.data.values():
        labels = block.data["_atom_site_label"]
        block.data[tag] = [f"{uiso:.10f}"] * len(labels)
        loop = next(loop for loop in block.loops if "_atom_site_label" in loop)
        if tag not in loop:
            loop.append(tag)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(writer) + "\n")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)

    # Wolframite FeWO4 parent; starting ZnWO4 cell from the characteristic
    # ambient wolframite metric, close enough for stable cell refinement.
    parent = Structure.from_file(cod_path("1567215"))
    parent.replace_species({"Fe": "Zn"})
    znwo4 = Structure(
        Lattice.monoclinic(4.6920, 5.7210, 4.9280, 90.64),
        parent.species,
        parent.frac_coords,
        site_properties=parent.site_properties,
    )
    write_with_uiso(znwo4, OUT / "znwo4_from_fe1567215.cif")

    # Distinct same-stoichiometry frameworks retained for the required
    # prototype-transfer screen. CuWO4 supplies the triclinic wolframite
    # distortion; scheelite CdWO4 supplies tetragonal I41/a.
    cu_parent = Structure.from_file(cod_path("4000806"))
    cu_parent.replace_species({"Cu": "Zn"})
    write_with_uiso(cu_parent, OUT / "znwo4_from_cu4000806_triclinic.cif")
    cd_parent = Structure.from_file(cod_path("1549132"))
    cd_parent.replace_species({"Cd": "Zn"})
    write_with_uiso(cd_parent, OUT / "znwo4_from_cd1549132_scheelite.cif")

    references = {
        "wo3_1010618": "1010618",
        "wo3_1528915": "1528915",
        "wo3_1563541": "1563541",
        "wo3_2311041": "2311041",
        "wo3_2106293": "2106293",
        "wo3_2107312": "2107312",
        "zno_9004178": "9004178",
    }
    for name, cod_id in references.items():
        structure = Structure.from_file(cod_path(cod_id))
        write_with_uiso(structure, OUT / f"{name}.cif")


if __name__ == "__main__":
    main()
