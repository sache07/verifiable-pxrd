#!/usr/bin/env python3
"""Run a reproducible common-state three-phase GSAS-II trial.

Invoke with the GSAS-II Python interpreter. The only trial-dependent choice is
the WO3 reference; all other phases and nuisance/refinement steps are fixed.
"""

from __future__ import annotations

import argparse
import copy
import csv
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
MODELS = ROOT / "analysis" / "models"


def write_observation(path: Path) -> None:
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as stream:
        rows = list(csv.DictReader(stream))
    x = np.array([float(row["two_theta_deg"]) for row in rows])
    y = np.array([float(row["intensity"]) for row in rows])
    sigma = np.sqrt(np.maximum(y, 1.0))
    np.savetxt(path, np.column_stack([x, y, sigma]), fmt="%.8f %.8f %.8f")


def write_instrument(path: Path) -> None:
    path.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:12.0;V:0.0;W:12.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def values(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    yobs = np.asarray(hist.data["data"][1][1], float)
    weight = np.asarray(hist.data["data"][1][2], float)
    ycalc = np.asarray(hist.data["data"][1][3], float)
    rwp_direct = 100.0 * np.sqrt(np.sum(weight * (yobs - ycalc) ** 2) / np.sum(weight * yobs ** 2))
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    phases = {}
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        phases[phase.name] = {
            "cell": phase.get_cell(),
            "scale": float(hap["Scale"][0]),
            "size": copy.deepcopy(hap["Size"]),
            "mustrain": copy.deepcopy(hap["Mustrain"]),
            "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
        }
    try:
        mass = {k: [float(v[0]), float(v[1])] for k, v in hist.ComputeMassFracs().items()}
    except Exception as exc:
        mass = {"error": str(exc)}
    return {
        "stage": stage,
        "Rwp_percent": hist.get_wR(),
        "Rwp_direct_percent": float(rwp_direct),
        "residuals": hist.residuals,
        "instrument": {k: copy.deepcopy(v) for k, v in inst.items() if k in {"Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."}},
        "sample": {k: copy.deepcopy(sample[k]) for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius") if k in sample},
        "mass_fractions": mass,
        "phases": phases,
    }


def refine(project: G2.G2Project, log: list[dict], stage: str) -> None:
    project.refine()
    record = values(project, stage)
    log.append(record)
    print(stage, "Rwp", record["Rwp_percent"], "direct", record["Rwp_direct_percent"], "mass", record["mass_fractions"], flush=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("wo3", choices=[
        "wo3_1010618", "wo3_1528915", "wo3_1563541",
        "wo3_2311041", "wo3_2106293", "wo3_2107312",
    ])
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    out = (args.out or ROOT / "analysis" / "trials" / args.wo3).resolve()
    out.mkdir(parents=True, exist_ok=True)

    obs = out / "observed.xye"
    inst = out / "instrument.instprm"
    gpx = out / "trial.gpx"
    # This script always creates a fresh screening project; never inherit flags
    # or parameters from an earlier failed trial in the same directory.
    gpx.unlink(missing_ok=True)
    write_observation(obs)
    write_instrument(inst)

    G2.SetPrintLevel("error")
    project = G2.G2Project(newgpx=str(gpx))
    hist = project.add_powder_histogram(str(obs), str(inst), fmthint="xye")
    hist.data["Sample Parameters"]["Type"] = "Bragg-Brentano"
    hist.data["Sample Parameters"]["Gonio. radius"] = 200.0
    hist.data["Sample Parameters"]["Scale"] = [1.0, False]
    hist.data["Sample Parameters"]["Shift"] = [0.0, False]
    hist.data["Sample Parameters"]["Transparency"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughA"] = [0.0, False]
    hist.data["Sample Parameters"]["SurfRoughB"] = [0.0, False]
    hist.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1200.0] + [0.0] * 11,
            "refine": True,
        },
    })

    phase_files = [
        ("ZnWO4_wolframite", MODELS / "znwo4_from_fe1567215.cif"),
        ("WO3", MODELS / f"{args.wo3}.cif"),
        ("ZnO_zincite", MODELS / "zno_9004178.cif"),
    ]
    phases = [
        project.add_phase(str(path), phasename=name, histograms=[hist], fmthint="CIF")
        for name, path in phase_files
    ]
    for phase, initial_size, initial_strain in zip(phases, [0.30, 0.80, 0.80], [1800.0, 300.0, 300.0]):
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [1.0, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = initial_size
        hap["Size"][1][1] = initial_size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = initial_strain
        hap["Mustrain"][1][1] = initial_strain
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]

    # The synthetic-lab bounds are also physical bounds for these nuisance
    # terms. Explicit limits prevent scale collapse or correlated zero/shift
    # steps from entering nonphysical regions during nonlinear refinement.
    h_id = hist.data["data"][0]["hId"]
    bounded = {
        f":{h_id}:Zero": (-0.25, 0.25),
        f":{h_id}:Shift": (-800.0, 800.0),
        f":{h_id}:U": (0.0, 40.0),
        f":{h_id}:W": (2.0, 40.0),
        f":{h_id}:X": (0.1, 6.0),
        f":{h_id}:SH/L": (0.005, 0.10),
        f":{h_id}:Polariz.": (0.5, 1.0),
    }
    for phase in phases:
        bounded[f"{phase.id}:{h_id}:Scale"] = (0.0, 1.0e4)
        bounded[f"{phase.id}:{h_id}:Size;i"] = (0.04, 1.5)
        bounded[f"{phase.id}:{h_id}:Mustrain;i"] = (0.0, 8000.0)
    for variable, (low, high) in bounded.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    project.set_Controls("cycles", 8)
    log: list[dict] = []
    refine(project, log, "background_scales")
    refine(project, log, "background_scales_converged")

    # A common angular zero, then individual cells, then the specimen shift.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine(project, log, "zero")
    # Keep the very weak ZnO metric fixed during screening: an effectively
    # zero scale provides no cell information and otherwise makes the normal
    # matrix singular. Its scale remains active in every common-state trial.
    for phase in phases[:2]:
        phase.set_refinements({"Cell": True})
    refine(project, log, "cells")
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine(project, log, "zero_shift_cells")

    # Instrument shape is common; phase broadening is refined only afterward.
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L", "Polariz."]})
    refine(project, log, "instrument")
    for phase in phases[:2]:
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "value": phase.data["Histograms"][hist.name]["Size"][1][0], "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        }, [hist])
    refine(project, log, "isotropic_phase_profiles")
    refine(project, log, "converged_isotropic")

    project.save(str(gpx))
    (out / "trial_log.json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
