#!/usr/bin/env python3
"""Ordinary final refinement of the physically screened three-phase model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, set_bounds


def full_rwp(hist) -> float:
    data = hist.data["data"][1]
    yo, w, yc = (np.asarray(data[i], dtype=float) for i in [1, 2, 3])
    return float(100 * np.sqrt(np.sum(w * (yo - yc) ** 2) / np.sum(w * yo**2)))


def fresh(project) -> float:
    project.set_Controls("cycles", 0)
    project.refine()
    return full_rwp(project.histograms()[0])


def configure(project, mode: str) -> None:
    freeze_all(project)
    set_bounds(project)
    hist = project.histograms()[0]
    phases = project.phases()
    h_id = hist.data["data"][0]["hId"]

    # Common intensity block. Keep the very weak ZnO texture at random until
    # it is tested independently after the base model has converged.
    hist.data["Background"][0][1] = True
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    for phase in phases[:2]:
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    for key, low, high in [
        ("SurfRoughA", 0.05, 0.6),
        ("SurfRoughB", 0.02, 0.5),
    ]:
        hist.data["Sample Parameters"][key][1] = True
        project.set_Controls("parmMin", low, variable=f":{h_id}:{key}")
        project.set_Controls("parmMax", high, variable=f":{h_id}:{key}")

    nuisance_all = mode in {"nuisance_all", "target_nuisance"}
    if mode == "cells" or nuisance_all:
        for phase in phases:
            phase.data["General"]["Cell"][0] = True
    if mode == "zero" or nuisance_all:
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
    if mode == "shift" or nuisance_all:
        hist.data["Sample Parameters"]["Shift"][1] = True
    if mode == "profiles" or nuisance_all:
        for phase in phases:
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][2][0] = True
            hap["Mustrain"][2][0] = True
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][1] = True
                variable = f"{phase.id}:{h_id}:Mustrain;a"
                project.set_Controls("parmMin", 0.0, variable=variable)
                project.set_Controls("parmMax", 32000.0, variable=variable)
    if mode == "instrument" or nuisance_all:
        inst = hist.data["Instrument Parameters"][0]
        for key in ["U", "W", "X", "SH/L", "Polariz."]:
            inst[key][2] = True
    if mode in {"target_atoms", "target_nuisance"}:
        for atom in phases[0].atoms():
            atom.refinement_flags = "X"


def fractions(project) -> dict[str, float]:
    hist = project.histograms()[0]
    raw = [
        float(p.data["Histograms"][hist.name]["Scale"][0])
        * float(p.data["General"]["Mass"])
        for p in project.phases()
    ]
    return {p.name: float(v / sum(raw)) for p, v in zip(project.phases(), raw)}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")

    clean = args.outdir / "00_fresh.gpx"
    clean.unlink(missing_ok=True)
    project = G2.G2Project(
        str(args.input.resolve()), newgpx=str(clean.resolve())
    )
    expected = ["ZnWO4_wolframite", "WO3", "ZnO_zincite"]
    if [p.name for p in project.phases()] != expected:
        raise ValueError("unexpected three-phase inventory")
    freeze_all(project)
    best = fresh(project)
    project.save(str(clean.resolve()))
    best_file = clean
    log = [
        {
            "stage": "fresh_start",
            "Rwp_percent": best,
            "weight_fractions": fractions(project),
            "accepted": True,
        }
    ]
    print("fresh_start", best, fractions(project), flush=True)

    stages = [
        ("intensity", 2),
        ("cells", 3),
        ("zero", 1),
        ("shift", 1),
        ("profiles", 3),
        ("instrument", 2),
        ("nuisance_all", 4),
        ("target_atoms", 1),
        ("target_nuisance", 2),
    ]
    for index, (mode, rounds) in enumerate(stages, start=1):
        candidate = args.outdir / f"{index:02d}_{mode}.gpx"
        candidate.unlink(missing_ok=True)
        project = G2.G2Project(
            str(best_file.resolve()), newgpx=str(candidate.resolve())
        )
        configure(project, mode)
        project.set_Controls("cycles", 10)
        for _ in range(rounds):
            project.refine()
        value = fresh(project)
        project.save(str(candidate.resolve()))
        accepted = value <= best + 1e-7
        row = {
            "stage": mode,
            "Rwp_percent": value,
            "weight_fractions": fractions(project),
            "accepted": accepted,
        }
        log.append(row)
        print(mode, value, row["weight_fractions"], "accepted", accepted, flush=True)
        if accepted:
            best, best_file = value, candidate

    final = args.outdir / "final_three_phase.gpx"
    final.unlink(missing_ok=True)
    project = G2.G2Project(
        str(best_file.resolve()), newgpx=str(final.resolve())
    )
    freeze_all(project)
    value = fresh(project)
    project.save(str(final.resolve()))
    log.append(
        {
            "stage": "final_fresh_replay",
            "Rwp_percent": value,
            "weight_fractions": fractions(project),
            "accepted": True,
            "source": str(best_file),
        }
    )
    (args.outdir / "final_refine_log.json").write_text(
        json.dumps(log, indent=2) + "\n"
    )
    print("FINAL", value, fractions(project), final, "from", best_file, flush=True)


if __name__ == "__main__":
    main()
