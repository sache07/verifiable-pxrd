#!/usr/bin/env python3
"""Final two-phase ordinary refinement with accept/reject fresh replays."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, rwp, set_bounds


def remove_phase(project, name: str) -> None:
    if name not in project.data["Phases"]:
        return
    del project.data["Phases"][name]
    for item in project.names:
        if item[0] == "Phases" and name in item:
            item.remove(name)
    for hist in project.histograms():
        hist.data["Reflection Lists"].pop(name, None)
    project.update_ids()


def fresh(project) -> float:
    project.set_Controls("cycles", 0)
    project.refine()
    return rwp(project.histograms()[0])


def enable_base(project) -> None:
    hist = project.histograms()[0]
    phases = project.phases()
    hist.data["Background"][0][1] = True
    for phase in phases:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    hist.data["Sample Parameters"]["SurfRoughA"][1] = True
    hist.data["Sample Parameters"]["SurfRoughB"][1] = True


def configure(project, mode: str) -> None:
    freeze_all(project)
    set_bounds(project)
    hist = project.histograms()[0]
    phases = project.phases()
    enable_base(project)
    h_id = hist.data["data"][0]["hId"]
    # Physical present-roughness bounds from the frozen lab protocol.
    for name, low, high in [("SurfRoughA", 0.05, 0.6), ("SurfRoughB", 0.02, 0.5)]:
        variable = f":{h_id}:{name}"
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)

    if mode in {"cells", "all"}:
        for phase in phases:
            phase.data["General"]["Cell"][0] = True
    if mode in {"zero", "all"}:
        hist.data["Instrument Parameters"][0]["Zero"][2] = True
    if mode in {"shift", "all"}:
        hist.data["Sample Parameters"]["Shift"][1] = True
    if mode in {"profiles", "all"}:
        for phase in phases:
            hap = phase.data["Histograms"][hist.name]
            hap["Size"][2][0] = True
            hap["Mustrain"][2][0] = True
            if hap["Mustrain"][0] == "uniaxial":
                hap["Mustrain"][2][1] = True
                variable = f"{phase.id}:{h_id}:Mustrain;a"
                project.set_Controls("parmMin", 0.0, variable=variable)
                project.set_Controls("parmMax", 32000.0, variable=variable)
    if mode in {"instrument", "all"}:
        inst = hist.data["Instrument Parameters"][0]
        for key in ["U", "W", "X", "SH/L", "Polariz."]:
            inst[key][2] = True
    if mode in {"target_atoms", "all_atoms", "all"}:
        for atom in phases[0].atoms():
            atom.refinement_flags = "X"
    if mode in {"wo3_atoms", "all_atoms", "all"}:
        for atom in phases[1].atoms():
            atom.refinement_flags = "X"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    clean = args.outdir / "00_clean.gpx"
    clean.unlink(missing_ok=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(clean.resolve()))
    remove_phase(project, "ZnO_zincite")
    if len(project.phases()) != 2:
        raise ValueError("final inventory must contain exactly two phases")
    freeze_all(project)
    project.save(str(clean.resolve()))
    baseline = fresh(project)
    project.save(str(clean.resolve()))
    log = [{"stage": "clean_fresh", "Rwp_percent": baseline, "accepted": True}]
    best_file = clean
    best = baseline
    print("clean_fresh", best, flush=True)

    stages = [
        ("intensity", 2),
        ("cells", 1),
        ("zero", 1),
        ("shift", 1),
        ("profiles", 2),
        ("instrument", 2),
        ("target_atoms", 1),
        ("wo3_atoms", 1),
        ("all_atoms", 1),
        ("all", 1),
    ]
    for index, (mode, rounds) in enumerate(stages, start=1):
        candidate = args.outdir / f"{index:02d}_{mode}.gpx"
        candidate.unlink(missing_ok=True)
        project = G2.G2Project(str(best_file.resolve()), newgpx=str(candidate.resolve()))
        project.save(str(candidate.resolve()))
        configure(project, mode)
        project.set_Controls("cycles", 8)
        for _ in range(rounds):
            project.refine()
        value = fresh(project)
        project.save(str(candidate.resolve()))
        accepted = value <= best + 1e-7
        log.append({"stage": mode, "Rwp_percent": value, "accepted": accepted})
        print(mode, value, "accepted", accepted, flush=True)
        if accepted:
            best = value
            best_file = candidate

    final = args.outdir / "final_two_phase.gpx"
    final.unlink(missing_ok=True)
    project = G2.G2Project(str(best_file.resolve()), newgpx=str(final.resolve()))
    freeze_all(project)
    value = fresh(project)
    project.save(str(final.resolve()))
    log.append({"stage": "final_fresh_replay", "Rwp_percent": value, "accepted": True, "source": str(best_file)})
    (args.outdir / "final_refine_log.json").write_text(json.dumps(log, indent=2) + "\n")
    print("FINAL", value, final, "from", best_file, flush=True)


if __name__ == "__main__":
    main()
