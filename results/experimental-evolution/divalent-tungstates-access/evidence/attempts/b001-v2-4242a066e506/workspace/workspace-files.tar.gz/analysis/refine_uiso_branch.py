#!/usr/bin/env python3
"""Grid-test a physically common phase Uiso with other nuisance terms fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, rwp, set_bounds


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, required=True)
    parser.add_argument("--uiso", type=float, required=True)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.unlink(missing_ok=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.save(str(args.output.resolve()))
    freeze_all(project)
    set_bounds(project)
    hist = project.histograms()[0]
    phases = project.phases()
    if len(phases) > 2:
        phases[2].data["Histograms"][hist.name]["Scale"] = [0.0, False]
    for phase in phases[:2]:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
        if abs(float(phase.data["Histograms"][hist.name]["Pref.Ori."][1]) - 1.0) > 1e-8:
            phase.data["Histograms"][hist.name]["Pref.Ori."][2] = True
    phase = phases[args.phase]
    for atom in phase.atoms():
        atom.uiso = args.uiso
        atom.refinement_flags = " "
    project.set_Controls("cycles", 8)
    project.refine()
    project.set_Controls("cycles", 0)
    project.refine()
    fresh = rwp(hist)
    project.save(str(args.output.resolve()))
    result = {"phase": phase.name, "Uiso_A2": args.uiso, "fresh_Rwp_percent": fresh}
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(result, flush=True)


if __name__ == "__main__":
    main()
