#!/usr/bin/env python3
"""Branch a saved GSAS-II project for a preferred-orientation axis trial."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def direct_rwp(hist) -> float:
    data = hist.data["data"][1]
    x, yobs, weight, ycalc = (np.asarray(data[i], float) for i in range(4))
    mask = (x >= 10.0) & (x <= 100.0)
    return float(100.0 * np.sqrt(
        np.sum(weight[mask] * (yobs[mask] - ycalc[mask]) ** 2)
        / np.sum(weight[mask] * yobs[mask] ** 2)
    ))


def snapshot(project, label: str) -> dict:
    hist = project.histograms()[0]
    raw = []
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        raw.append(max(0.0, float(hap["Scale"][0])) * float(phase.data["General"]["Mass"]))
    total = sum(raw)
    mass_fractions = {
        phase.name: (value / total if total > 0 else 0.0)
        for phase, value in zip(project.phases(), raw)
    }
    result = {
        "label": label,
        "Rwp_direct_percent": direct_rwp(hist),
        "Rwp_GSAS_percent": hist.get_wR(),
        "mass_fractions": mass_fractions,
        "phases": {},
    }
    for phase in project.phases():
        hap = phase.data["Histograms"][hist.name]
        result["phases"][phase.name] = {
            "cell": phase.get_cell(),
            "scale": hap["Scale"],
            "preferred_orientation": hap["Pref.Ori."],
            "size": hap["Size"],
            "mustrain": hap["Mustrain"],
        }
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--phase", type=int, default=0)
    parser.add_argument("--axis", required=True, help="comma-separated h,k,l")
    parser.add_argument("--ratio", type=float, default=0.85)
    parser.add_argument("--rounds", type=int, default=3)
    args = parser.parse_args()
    axis = [int(v) for v in args.axis.split(",")]
    if len(axis) != 3 or not any(axis):
        raise ValueError("axis must be a nonzero h,k,l triple")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.unlink(missing_ok=True)
    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.input.resolve()))
    project.save(str(args.output.resolve()))
    hist = project.histograms()[0]
    phases = project.phases()

    # Hold the accepted common nuisance state fixed for the discrete axis
    # comparison. Only the two retained phase scales and the trial MD ratio
    # are allowed to move; this makes each branch an actual common-state test.
    hist.data["Background"][0][1] = False
    for item in hist.data["Instrument Parameters"][0].values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.data["Sample Parameters"].values():
        if isinstance(item, list) and len(item) == 2 and isinstance(item[1], bool):
            item[1] = False
    for trial_phase in phases:
        trial_phase.data["General"]["Cell"][0] = False
        for atom in trial_phase.atoms():
            atom.refinement_flags = " "
        trial_hap = trial_phase.data["Histograms"][hist.name]
        trial_hap["Scale"][1] = False
        trial_hap["Pref.Ori."][2] = False
        trial_hap["Size"][2] = [False] * len(trial_hap["Size"][2])
        trial_hap["Size"][5] = [False] * len(trial_hap["Size"][5])
        trial_hap["Mustrain"][2] = [False] * len(trial_hap["Mustrain"][2])
        trial_hap["Mustrain"][5] = [False] * len(trial_hap["Mustrain"][5])
        trial_hap["HStrain"][1] = [False] * len(trial_hap["HStrain"][1])
    for retained in phases[:2]:
        retained.data["Histograms"][hist.name]["Scale"][1] = True

    # ZnO collapsed in every common-state WO3 trial. Keep the record in the
    # branch project for auditability but remove its zero-information variable.
    if len(phases) > 2:
        phases[2].data["Histograms"][hist.name]["Scale"] = [0.0, False]

    phase = phases[args.phase]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = float(args.ratio)
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = axis
    h_id = hist.data["data"][0]["hId"]
    variable = f"{phase.id}:{h_id}:MD"
    project.set_Controls("parmMin", 0.7, variable=variable)
    project.set_Controls("parmMax", 1.4, variable=variable)
    project.set_Controls("cycles", 10)

    log = [snapshot(project, "initial")]
    for i in range(args.rounds):
        project.refine()
        row = snapshot(project, f"round_{i + 1}")
        log.append(row)
        print(row["label"], "Rwp", row["Rwp_direct_percent"], "MD", row["phases"][phase.name]["preferred_orientation"], flush=True)
    project.save(str(args.output.resolve()))
    args.output.with_suffix(".json").write_text(json.dumps(log, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
