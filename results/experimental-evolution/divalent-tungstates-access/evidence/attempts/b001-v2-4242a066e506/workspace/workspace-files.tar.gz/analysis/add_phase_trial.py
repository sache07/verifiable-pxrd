#!/usr/bin/env python3
"""Add one candidate to a saved project while holding the accepted state fixed."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, set_bounds


def profile_stats(hist) -> tuple[float, float]:
    data = hist.data["data"][1]
    x, yo, w, yc = (np.asarray(data[i], dtype=float) for i in range(4))
    full = 100 * np.sqrt(np.sum(w * (yo - yc) ** 2) / np.sum(w * yo**2))
    mask = (x >= 10.0) & (x <= 100.0)
    core = 100 * np.sqrt(
        np.sum(w[mask] * (yo[mask] - yc[mask]) ** 2)
        / np.sum(w[mask] * yo[mask] ** 2)
    )
    return float(full), float(core)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("candidate_cif", type=Path)
    parser.add_argument("--name", default="ZnO_zincite")
    parser.add_argument("--size", type=float, required=True)
    parser.add_argument("--strain", type=float, required=True)
    parser.add_argument("--initial-scale", type=float, default=5.0)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.unlink(missing_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(
        str(args.input.resolve()), newgpx=str(args.output.resolve())
    )
    project.save(str(args.output.resolve()))
    hist = project.histograms()[0]
    if args.name in [phase.name for phase in project.phases()]:
        raise ValueError(f"phase already exists: {args.name}")
    phase = project.add_phase(
        str(args.candidate_cif.resolve()),
        phasename=args.name,
        histograms=[hist],
        fmthint="CIF",
    )
    project.update_ids()
    freeze_all(project)
    set_bounds(project)
    hap = phase.data["Histograms"][hist.name]
    hap["Scale"] = [args.initial_scale, True]
    hap["Size"][0] = "isotropic"
    hap["Size"][1][0] = args.size
    hap["Size"][2] = [False] * len(hap["Size"][2])
    hap["Mustrain"][0] = "isotropic"
    hap["Mustrain"][1][0] = args.strain
    hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = False
    hap["Pref.Ori."][3] = [0, 0, 1]

    project.set_Controls("cycles", 8)
    project.refine()
    project.refine()
    project.set_Controls("cycles", 0)
    project.refine()
    full, core = profile_stats(hist)
    project.save(str(args.output.resolve()))

    raw = []
    for candidate in project.phases():
        candidate_hap = candidate.data["Histograms"][hist.name]
        raw.append(
            float(candidate_hap["Scale"][0])
            * float(candidate.data["General"]["Mass"])
        )
    total = sum(raw)
    result = {
        "candidate": str(args.candidate_cif),
        "size_micrometers": args.size,
        "microstrain_ppm": args.strain,
        "fresh_full_grid_Rwp_percent": full,
        "fresh_10_100_Rwp_percent": core,
        "scale": float(hap["Scale"][0]),
        "weight_fraction": float(raw[-1] / total),
        "all_weight_fractions": {
            candidate.name: float(value / total)
            for candidate, value in zip(project.phases(), raw)
        },
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
