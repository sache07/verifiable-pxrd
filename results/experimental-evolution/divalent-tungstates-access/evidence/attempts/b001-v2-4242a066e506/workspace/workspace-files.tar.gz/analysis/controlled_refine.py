#!/usr/bin/env python3
"""Staged, physically bounded GSAS-II refinement with fresh replays.

This starts from the best common-state phase inventory, resets unstable profile
terms to physical values, and performs small refinement blocks. Every reported
Rwp follows a zero-cycle recalculation from the parameters actually stored in
the GPX, so post-boundary stale profiles cannot be mistaken for an improvement.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


def rwp(hist) -> float:
    a = hist.data["data"][1]
    x, yo, w, yc = (np.asarray(a[i], float) for i in range(4))
    m = (x >= 10.0) & (x <= 100.0)
    return float(100 * np.sqrt(np.sum(w[m] * (yo[m] - yc[m]) ** 2) / np.sum(w[m] * yo[m] ** 2)))


def freeze_all(project) -> None:
    hist = project.histograms()[0]
    hist.data["Background"][0][1] = False
    for item in hist.data["Instrument Parameters"][0].values():
        if isinstance(item, list) and len(item) > 2:
            item[2] = False
    for item in hist.data["Sample Parameters"].values():
        if isinstance(item, list) and len(item) == 2 and isinstance(item[1], bool):
            item[1] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])
        hap["HStrain"][1] = [False] * len(hap["HStrain"][1])


def set_bounds(project) -> None:
    hist = project.histograms()[0]
    h_id = hist.data["data"][0]["hId"]
    bounds = {
        f":{h_id}:Zero": (-0.25, 0.25),
        f":{h_id}:Shift": (-800.0, 800.0),
        f":{h_id}:U": (0.0, 40.0),
        f":{h_id}:W": (2.0, 40.0),
        f":{h_id}:X": (0.1, 6.0),
        f":{h_id}:SH/L": (0.005, 0.10),
        f":{h_id}:Polariz.": (0.5, 1.0),
    }
    for phase in project.phases():
        bounds.update({
            f"{phase.id}:{h_id}:Scale": (0.0, 1.0e4),
            f"{phase.id}:{h_id}:Size;i": (0.04, 1.5),
            f"{phase.id}:{h_id}:Mustrain;i": (0.0, 8000.0),
            f"{phase.id}:{h_id}:MD": (0.7, 1.4),
        })
    for variable, (low, high) in bounds.items():
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)


def replay(project, label: str, records: list[dict], outdir: Path) -> float:
    project.set_Controls("cycles", 0)
    project.refine()
    hist = project.histograms()[0]
    value = rwp(hist)
    raw_mass = []
    for phase in project.phases():
        scale = float(phase.data["Histograms"][hist.name]["Scale"][0])
        raw_mass.append(max(0.0, scale) * float(phase.data["General"]["Mass"]))
    total_mass = sum(raw_mass)
    mass_fractions = {
        phase.name: (value / total_mass if total_mass > 0 else 0.0)
        for phase, value in zip(project.phases(), raw_mass)
    }
    row = {
        "stage": label,
        "Rwp_direct_percent": value,
        "Rwp_GSAS_percent": hist.get_wR(),
        "mass_fractions": mass_fractions,
    }
    records.append(row)
    checkpoint = outdir / f"{len(records):02d}_{label}.gpx"
    project.save(str(checkpoint))
    print(label, "fresh_Rwp", value, "mass", row["mass_fractions"], flush=True)
    return value


def refine(project, label: str, records: list[dict], outdir: Path, cycles: int = 8, rounds: int = 1) -> float:
    for _ in range(rounds):
        project.set_Controls("cycles", cycles)
        project.refine()
    return replay(project, label, records, outdir)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    work = args.outdir / "working.gpx"
    work.unlink(missing_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.input.resolve()))
    project.save(str(work.resolve()))
    hist = project.histograms()[0]
    phases = project.phases()
    if len(phases) < 2:
        raise ValueError("two retained phases are required")
    freeze_all(project)
    set_bounds(project)

    # Reinitialize the profile values that had previously been clipped in a
    # nonlinear step. The observed widths are compatible with these interior
    # values and they lie well within the lab's physically allowed ranges.
    inst = hist.data["Instrument Parameters"][0]
    for key, value in {"U": 10.0, "W": 12.0, "X": 1.0, "SH/L": 0.03, "Polariz.": 0.75}.items():
        inst[key][1] = value
    for phase, size, strain in zip(phases[:2], [0.30, 0.50], [1200.0, 500.0]):
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = strain
    target_hap = phases[0].data["Histograms"][hist.name]
    target_hap["Pref.Ori."][0] = "MD"
    target_hap["Pref.Ori."][1] = 0.78
    target_hap["Pref.Ori."][3] = [1, 0, 0]
    # The common-state test collapsed ZnO to zero repeatedly. It remains in
    # intermediate projects only as an inactive audit record.
    if len(phases) > 2:
        phases[2].data["Histograms"][hist.name]["Scale"] = [0.0, False]

    records: list[dict] = []
    replay(project, "reset_profile", records, args.outdir)

    # Linear intensity block: two phase scales and smooth background.
    hist.data["Background"][0][1] = True
    for phase in phases[:2]:
        phase.data["Histograms"][hist.name]["Scale"][1] = True
    target_hap["Pref.Ori."][2] = True
    refine(project, "scales_background_texture", records, args.outdir, rounds=2)

    # Common zero and phase cells are alternated, avoiding a simultaneous
    # zero/shift/cell jump.
    inst["Zero"][2] = True
    refine(project, "zero", records, args.outdir)
    inst["Zero"][2] = False
    for phase in phases[:2]:
        phase.data["General"]["Cell"][0] = True
    refine(project, "cells", records, args.outdir, rounds=2)
    for phase in phases[:2]:
        phase.data["General"]["Cell"][0] = False
    hist.data["Sample Parameters"]["Shift"][1] = True
    refine(project, "shift", records, args.outdir)
    hist.data["Sample Parameters"]["Shift"][1] = False

    # Phase and common profile terms are first optimized separately and then
    # together from their freshly replayed values.
    for phase in phases[:2]:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    refine(project, "phase_profiles", records, args.outdir, rounds=2)
    for phase in phases[:2]:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = False
        hap["Mustrain"][2][0] = False
    for key in ["U", "W", "X", "SH/L", "Polariz."]:
        inst[key][2] = True
    refine(project, "instrument_profile", records, args.outdir, rounds=2)
    for phase in phases[:2]:
        hap = phase.data["Histograms"][hist.name]
        hap["Size"][2][0] = True
        hap["Mustrain"][2][0] = True
    refine(project, "combined_profiles", records, args.outdir, rounds=2)

    project.save(str(work.resolve()))
    (args.outdir / "controlled_log.json").write_text(json.dumps(records, indent=2, default=str) + "\n")


if __name__ == "__main__":
    main()
