#!/usr/bin/env python3
"""Print a compact JSON summary and export phase CIFs from a GSAS-II project."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def serial(value):
    if hasattr(value, "tolist"):
        return value.tolist()
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    if isinstance(value, (str, int, float, bool)) or value is None:
        return value
    return str(value)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)

    G2.SetPrintLevel("error")
    project = G2.G2Project(str(args.project.resolve()))
    hist = project.histograms()[0]
    inst = hist.data["Instrument Parameters"][0]
    sample = hist.data["Sample Parameters"]
    info = {
        "project": str(args.project),
        "histogram": hist.name,
        "instrument": {k: serial(v) for k, v in inst.items()},
        "sample": {k: serial(v) for k, v in sample.items()},
        "background": serial(hist.data["Background"]),
        "phases": [],
    }
    for index, phase in enumerate(project.phases(), start=1):
        safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", phase.name).strip("_")
        cif = args.outdir / f"{index}_{safe}.cif"
        phase.export_CIF(str(cif.resolve()))
        hap = phase.data["Histograms"][hist.name]
        info["phases"].append(
            {
                "name": phase.name,
                "cif": str(cif),
                "space_group": phase.data["General"]["SGData"].get("SpGrp"),
                "cell": serial(phase.data["General"]["Cell"]),
                "mass": serial(phase.data["General"].get("Mass")),
                "hap": serial(hap),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "coordinates": serial(atom.coordinates),
                        "occupancy": atom.occupancy,
                        "uiso": atom.uiso,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    print(json.dumps(info, indent=2))


if __name__ == "__main__":
    main()
