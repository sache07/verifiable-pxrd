#!/usr/bin/env python3
"""Replace one phase in a saved multiphase GPX and refine only the replacement.

The retained phases and all common nuisance settings are held fixed. This is
used for residual-directed, common-state reference/prototype comparisons.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, rwp, set_bounds


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("phase_name")
    parser.add_argument("replacement_cif", type=Path)
    parser.add_argument("--rounds", type=int, default=2)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.unlink(missing_ok=True)

    G2.SetPrintLevel("error")
    # Give each branch its own filename before add_phase is called. GSAS-II's
    # phase loader indexes (and may save) the current project filename, so
    # sharing the source filename across concurrent trials is unsafe.
    project = G2.G2Project(str(args.input.resolve()), newgpx=str(args.output.resolve()))
    project.save(str(args.output.resolve()))
    hist = project.histograms()[0]
    old = project.phase(args.phase_name)
    old_hap = old.data["Histograms"][hist.name]
    old_mass = float(old.data["General"]["Mass"])
    old_scale = float(old_hap["Scale"][0])
    old_size = float(old_hap["Size"][1][0])
    old_strain = float(old_hap["Mustrain"][1][0])
    old_po = list(old_hap["Pref.Ori."])

    # GSASIIscriptable has no public phase-deletion wrapper. Remove the phase
    # and its histogram reflection cache, then let add_phase/update_ids rebuild
    # all identifiers and links in this disposable branch project.
    del project.data["Phases"][args.phase_name]
    for tree_item in project.names:
        if tree_item[0] == "Phases" and args.phase_name in tree_item:
            tree_item.remove(args.phase_name)
    hist.data["Reflection Lists"].pop(args.phase_name, None)
    project.update_ids()
    replacement = project.add_phase(
        str(args.replacement_cif.resolve()),
        phasename=args.phase_name,
        histograms=[hist],
        fmthint="CIF",
    )
    project.update_ids()
    new_hap = replacement.data["Histograms"][hist.name]
    new_mass = float(replacement.data["General"]["Mass"])
    new_hap["Scale"] = [old_scale * old_mass / new_mass, True]
    new_hap["Size"][0] = "isotropic"
    new_hap["Size"][1][0] = min(1.5, max(0.04, old_size))
    new_hap["Mustrain"][0] = "isotropic"
    new_hap["Mustrain"][1][0] = min(8000.0, max(0.0, old_strain))
    new_hap["Pref.Ori."][0] = old_po[0]
    new_hap["Pref.Ori."][1] = float(old_po[1])
    new_hap["Pref.Ori."][3] = list(old_po[3])

    freeze_all(project)
    set_bounds(project)
    # All retained phases and nuisance terms remain fixed; only scale, metric,
    # isotropic size and strain of the replacement are optimized.
    new_hap["Scale"][1] = True
    replacement.data["General"]["Cell"][0] = True
    new_hap["Size"][2][0] = True
    new_hap["Mustrain"][2][0] = True
    new_hap["Pref.Ori."][2] = bool(old_po[2])
    project.set_Controls("cycles", 10)
    for i in range(args.rounds):
        project.refine()
        print("round", i + 1, "stored_Rwp", rwp(hist), flush=True)
    project.set_Controls("cycles", 0)
    project.refine()
    fresh = rwp(hist)
    project.save(str(args.output.resolve()))
    result = {
        "replacement": str(args.replacement_cif),
        "fresh_Rwp_percent": fresh,
        "cell": replacement.get_cell(),
        "scale": new_hap["Scale"],
        "size": new_hap["Size"],
        "mustrain": new_hap["Mustrain"],
    }
    args.output.with_suffix(".json").write_text(json.dumps(result, indent=2, default=str) + "\n")
    print("fresh_Rwp", fresh, "replacement", args.replacement_cif, flush=True)


if __name__ == "__main__":
    main()
