#!/usr/bin/env python3
"""Common-state fixed-profile grid for a weak residual ZnO phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2

from controlled_refine import freeze_all, set_bounds


def full_rwp(hist) -> float:
    data = hist.data["data"][1]
    yo, w, yc = (np.asarray(data[i], dtype=float) for i in [1, 2, 3])
    return float(100 * np.sqrt(np.sum(w * (yo - yc) ** 2) / np.sum(w * yo**2)))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("outdir", type=Path)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("error")

    records = []
    for size in [0.04, 0.06, 0.10, 0.20]:
        for strain in [0.0, 500.0, 2000.0]:
            tag = f"size_{size:.2f}_strain_{strain:.0f}".replace(".", "p")
            output = args.outdir / f"{tag}.gpx"
            output.unlink(missing_ok=True)
            try:
                project = G2.G2Project(
                    str(args.input.resolve()), newgpx=str(output.resolve())
                )
                project.save(str(output.resolve()))
                freeze_all(project)
                set_bounds(project)
                hist = project.histograms()[0]
                phase = project.phase("ZnO_zincite")
                hap = phase.data["Histograms"][hist.name]
                hap["Size"][0] = "isotropic"
                hap["Size"][1][0] = size
                hap["Mustrain"][0] = "isotropic"
                hap["Mustrain"][1][0] = strain
                hap["Scale"][1] = True
                phase.data["General"]["Cell"][0] = True
                project.set_Controls("cycles", 10)
                project.refine()
                project.set_Controls("cycles", 0)
                project.refine()
                project.save(str(output.resolve()))
                raw = [
                    float(p.data["Histograms"][hist.name]["Scale"][0])
                    * float(p.data["General"]["Mass"])
                    for p in project.phases()
                ]
                row = {
                    "tag": tag,
                    "size_micrometers": size,
                    "microstrain_ppm": strain,
                    "fresh_full_grid_Rwp_percent": full_rwp(hist),
                    "scale": float(hap["Scale"][0]),
                    "weight_fraction": float(raw[-1] / sum(raw)),
                    "cell": phase.get_cell(),
                    "project": str(output),
                    "status": "completed",
                }
            except Exception as exc:
                row = {
                    "tag": tag,
                    "size_micrometers": size,
                    "microstrain_ppm": strain,
                    "status": "unknown_after_failure",
                    "error": str(exc),
                }
            records.append(row)
            print(json.dumps(row), flush=True)
    (args.outdir / "grid.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
