#!/usr/bin/env python3
"""Refine the unknown instrument polarization with supported intensity terms."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "texture_joint.gpx"),
        newgpx=str(WORK / "polarization_work.gpx"),
    )
    clear_all(project)
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    h.set_refinements({"Instrument Parameters": ["Polariz."]})
    project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
    project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    run(project, "w01_polarization_intensity_settle", 14)
    clear_all(project)
    project.save(str(WORK / "polarization_developed.gpx"))


if __name__ == "__main__":
    main()
