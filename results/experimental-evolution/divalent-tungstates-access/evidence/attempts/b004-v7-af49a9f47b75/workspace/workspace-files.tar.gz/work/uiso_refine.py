#!/usr/bin/env python3
"""Refine one common isotropic displacement parameter per phase."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def set_phase_u_flags(project, active_indices):
    for pi, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = "U" if pi in active_indices else " "


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "texture_accepted.gpx"),
        newgpx=str(WORK / "uiso_work.gpx"),
    )
    project.index_ids()
    # The synthetic specimen uses a single sampled Uiso for every site in a
    # phase, so enforce that known model structure rather than fitting sites
    # independently.
    for phase in project.phases():
        pid = phase.data["pId"]
        variables = tuple(f"{pid}::AUiso:{i}" for i in range(len(phase.atoms())))
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
    project.save()

    for pi in range(3):
        clear_all(project); common(project); set_phase_u_flags(project, {pi})
        run(project, f"u0{pi + 1}_phase_{pi}_uiso", 7)

    clear_all(project); common(project); set_phase_u_flags(project, {0, 1, 2})
    # Retain and co-refine the already supported dominant texture term.
    project.phases()[0].set_HAP_refinements({"Pref.Ori.": True})
    run(project, "u04_joint_uiso_texture", 10)
    clear_all(project)
    project.save(str(WORK / "uiso_developed.gpx"))


if __name__ == "__main__":
    main()
