#!/usr/bin/env python3
"""Restore the physical per-phase isotropic-U model and converge intensities."""

from pathlib import Path
import statistics
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "winner_structural.gpx"),
        newgpx=str(WORK / "physical_uiso_work.gpx"),
    )
    project.index_ids()

    # The experiment samples one scalar Uiso for every site in a phase.
    # Replace the inherited WO3-only equivalence with one equivalence per phase.
    project.data["Constraints"]["data"]["Phase"] = []
    for phase in project.phases():
        atoms = phase.atoms()
        values = [min(0.020, max(0.003, float(atom.uiso))) for atom in atoms]
        shared = statistics.median(values)
        for atom in atoms:
            atom.uiso = shared
        pid = phase.data["pId"]
        variables = tuple(f"{pid}::AUiso:{i}" for i in range(len(atoms)))
        if len(variables) > 1:
            project.add_EquivConstr(variables)
        for variable in variables:
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)

    clear_all(project)
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True, "Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    run(project, "p00_physical_uiso", 16)

    clear_all(project)
    project.save(str(WORK / "physical_uiso.gpx"))


if __name__ == "__main__":
    main()
