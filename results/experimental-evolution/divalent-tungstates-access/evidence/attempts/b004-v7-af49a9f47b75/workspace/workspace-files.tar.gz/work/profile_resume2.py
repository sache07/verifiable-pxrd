#!/usr/bin/env python3
"""Complete stable profile terms after WO3 strain tested at zero."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, install_bounds, run


def common(project, cells=False):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if cells:
            phase.set_refinements({"Cell": True})


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "q01_strain_0.gpx"),
        newgpx=str(WORK / "profile_stable.gpx"),
    )
    install_bounds(project)
    h = hist(project)
    # The direct one-cycle test drove WO3 microstrain below the physical
    # lower limit, so retain the no-microstrain model.
    wo3_hap = project.phases()[1].data["Histograms"][h.name]
    wo3_hap["Mustrain"][1][0] = 0.0
    wo3_hap["Mustrain"][2] = [False, False, False]

    clear_all(project); common(project)
    project.phases()[2].set_HAP_refinements({
        "Mustrain": {"type": "isotropic", "refine": True}
    })
    run(project, "r01_baco3_strain", 5)

    # Fit common profile terms against all three phases with phase terms fixed.
    clear_all(project); common(project, cells=True)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    run(project, "r02_common_low_angle", 6)

    clear_all(project); common(project, cells=True)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["U"]})
    run(project, "r03_common_U", 6)

    # Revisit only the two demonstrably broadened phases.
    clear_all(project); common(project, cells=True)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for index in (0, 2):
        project.phases()[index].set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    run(project, "r04_profile_settle", 8)
    project.save(str(WORK / "profile_developed.gpx"))


if __name__ == "__main__":
    main()
