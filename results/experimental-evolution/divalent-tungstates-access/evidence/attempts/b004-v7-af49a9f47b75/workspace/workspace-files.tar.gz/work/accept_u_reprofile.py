#!/usr/bin/env python3
"""Accept the interior instrumental-U branch and re-equilibrate phase widths."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def activate_u(project):
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["U"]})
    project.set_Controls("parmMin", 0.0, variable=":0:U")
    project.set_Controls("parmMax", 40.0, variable=":0:U")


def activate_phase_profiles(project):
    h = hist(project)
    for index, phase in enumerate(project.phases()):
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][h.name]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{pid}:0:Size;i")
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
        })
        if index == 0:
            phase.set_HAP_refinements({
                "Mustrain": {"type": "isotropic", "refine": True},
            })
            project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
            project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        else:
            hap["Mustrain"][0] = "isotropic"
            hap["Mustrain"][1][0] = 0.0
            hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "instrument_U.gpx"),
        newgpx=str(WORK / "accept_u_reprofile_work.gpx"),
    )
    project.index_ids()

    clear_all(project); common(project); activate_u(project)
    run(project, "p40_u_settle_1", 12)
    run(project, "p40_u_settle_2", 12)

    clear_all(project); common(project); activate_phase_profiles(project)
    for index in range(1, 4):
        run(project, f"p41_reprofile_{index}", 12)

    clear_all(project); common(project); activate_u(project)
    run(project, "p42_u_recheck_1", 12)
    run(project, "p42_u_recheck_2", 12)

    clear_all(project); common(project); activate_phase_profiles(project)
    run(project, "p43_reprofile_final_1", 12)
    run(project, "p43_reprofile_final_2", 12)

    clear_all(project)
    project.save(str(WORK / "u_profile_accepted.gpx"))


if __name__ == "__main__":
    main()
