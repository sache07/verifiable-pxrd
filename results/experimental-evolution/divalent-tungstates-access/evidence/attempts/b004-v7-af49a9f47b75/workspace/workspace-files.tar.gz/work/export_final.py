#!/usr/bin/env python3
"""Read-only export of structures, profile and summary from final.gpx."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
PROJECT = ROOT / "final.gpx"
REPLAY_DIR = ROOT / "work" / "replay_check"

EXPORTS = [
    ("Ba3W2O9", "phase_Ba3W2O9.cif", "Ba3W2O9", "R-3c", "COD 1533878"),
    ("WO3", "phase_WO3.cif", "WO3", "P21/c", "COD 2311041"),
    ("BaCO3", "phase_BaCO3.cif", "BaCO3", "Pnma", "COD 9010928"),
]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    before = digest(PROJECT)
    replay = json.loads((REPLAY_DIR / "replay.json").read_text())
    if replay.get("status") != "replayed" or replay.get("project_sha256") != before:
        raise RuntimeError("independent replay does not correspond to final.gpx")

    project = G2.G2Project(gpxfile=str(PROJECT))
    hist = project.histograms()[0]
    phases = project.phases()
    if len(phases) != len(EXPORTS):
        raise RuntimeError(f"expected three phases, found {len(phases)}")

    fractions = hist.ComputeMassFracs()
    phase_rows = []
    for phase, (label, filename, formula, space_group, reference) in zip(phases, EXPORTS):
        output = ROOT / filename
        phase.export_CIF(str(output))
        fraction, uncertainty = fractions[phase.name]
        phase_rows.append({
            "name": label,
            "project_phase": phase.name,
            "formula": formula,
            "space_group": space_group,
            "identification": reference,
            "cif_path": filename,
            "weight_fraction": float(fraction),
            "weight_fraction_esd": float(uncertainty),
        })

    with np.load(REPLAY_DIR / "prediction.npz", allow_pickle=False) as data:
        x = np.asarray(data["x"], dtype=float)
        observed = np.asarray(data["observed"], dtype=float)
        calculated = np.asarray(data["predicted"], dtype=float)
    public = np.loadtxt(ROOT / "inputs" / "pattern.csv", delimiter=",", skiprows=1)
    if not np.array_equal(x, public[:, 0]) or not np.array_equal(observed, public[:, 1]):
        raise RuntimeError("replayed profile does not reproduce the public grid and observations")
    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference)),
        delimiter=",",
        header="two_theta_deg,observed,calculated,difference",
        comments="",
        fmt=("%.8f", "%.10g", "%.10g", "%.10g"),
    )

    weights = 1.0 / np.maximum(observed, 1.0)
    full_chisq = float(np.sum(weights * difference**2))
    full_denominator = float(np.sum(weights * observed**2))
    rvals = project.data["Covariance"]["data"]["Rvals"]
    powder_stats = hist.data["data"][0]
    result = {
        "phases": phase_rows,
        "unresolved_components": [],
        "fraction_basis": "normalized over modeled crystalline phases",
        "project_path": "final.gpx",
        "refinement_histogram": hist.name,
        "fit_statistics": {
            "Rwp_percent": float(rvals["Rwp"]),
            "Rp_percent": float(powder_stats["Rb"]),
            "GOF": float(rvals["GOF"]),
            "chi_square": float(rvals["chisq"]),
            "Nobs": int(rvals["Nobs"]),
            "Nvars": int(rvals["Nvars"]),
            "Durbin_Watson": float(powder_stats["Durbin-Watson"]),
            "full_grid_Rwp_percent": float(100.0 * np.sqrt(full_chisq / full_denominator)),
            "full_grid_chi_square": full_chisq,
        },
        "replay": {
            "status": replay["status"],
            "parameters_optimized": replay["parameters_optimized"],
            "project_unchanged": replay["project_unchanged"],
            "profile_review_flags": replay["profile_review_flags"],
            "project_sha256": before,
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    after = digest(PROJECT)
    if after != before:
        raise RuntimeError("final.gpx changed during export")
    print(json.dumps({
        "project_sha256": before,
        "Rwp_percent": result["fit_statistics"]["Rwp_percent"],
        "full_grid_Rwp_percent": result["fit_statistics"]["full_grid_Rwp_percent"],
        "fractions": {row["name"]: row["weight_fraction"] for row in phase_rows},
    }, indent=2))


if __name__ == "__main__":
    main()
