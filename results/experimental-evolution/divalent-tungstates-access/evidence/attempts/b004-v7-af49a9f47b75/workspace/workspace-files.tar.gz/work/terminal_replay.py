#!/usr/bin/env python3
"""Final replay of supported structure, intensity and profile parameters."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run
from intensity_coords_settle import (
    common, install_coordinate_bounds, activate_cations, activate_intensity,
)
from accept_u_reprofile import activate_u, activate_phase_profiles
from profile_final_settle import activate_shl


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "final_profile_after_structure.gpx"),
        newgpx=str(WORK / "terminal_replay_work.gpx"),
    )
    project.index_ids()
    install_coordinate_bounds(project)

    for phase_index in range(3):
        clear_all(project); common(project); activate_cations(project, phase_index)
        run(project, f"p80_phase_{phase_index}_cations_a", 10)
        run(project, f"p80_phase_{phase_index}_cations_b", 10)

    clear_all(project); common(project); activate_intensity(project)
    run(project, "p81_intensity_a", 12)
    run(project, "p81_intensity_b", 12)

    clear_all(project); common(project); activate_phase_profiles(project)
    run(project, "p82_profiles_a", 12)
    run(project, "p82_profiles_b", 12)

    clear_all(project); common(project); activate_u(project)
    run(project, "p83_instrument_u", 12)

    clear_all(project); common(project); activate_shl(project)
    run(project, "p83_instrument_shl", 12)

    clear_all(project); common(project); activate_phase_profiles(project)
    run(project, "p84_profiles_a", 12)
    run(project, "p84_profiles_b", 12)

    clear_all(project); common(project); activate_intensity(project)
    run(project, "p85_intensity_final_a", 12)
    run(project, "p85_intensity_final_b", 12)

    # A flag-free replay of only background and scales establishes the final
    # covariance state and tests numerical stability without changing model form.
    clear_all(project); common(project)
    run(project, "p86_scale_background_replay_a", 12)
    run(project, "p86_scale_background_replay_b", 12)

    clear_all(project)
    project.save(str(WORK / "terminal_prepolish.gpx"))


if __name__ == "__main__":
    main()
