#!/usr/bin/env python3
"""Test each common instrumental profile term from one settled checkpoint."""

import json
from pathlib import Path
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


TERMS = {
    "U": (0.0, 40.0),
    "W": (2.0, 40.0),
    "X": (0.1, 6.0),
    "SH/L": (0.005, 0.10),
}


def strongest_correlation(project, target):
    cov = project.data.get("Covariance", {}).get("data", {})
    names = [str(v) for v in cov.get("varyList", [])]
    matrix = np.asarray(cov.get("covMatrix", []), dtype=float)
    name = f":0:{target}"
    if name not in names or matrix.shape != (len(names), len(names)):
        return None
    i = names.index(name)
    denom = np.sqrt(np.maximum(np.diag(matrix), 0.0))
    with np.errstate(divide="ignore", invalid="ignore"):
        corr = matrix[i] / (denom[i] * denom)
    corr[i] = 0.0
    j = int(np.nanargmax(np.abs(corr)))
    return {"variable": names[j], "correlation_percent": float(100.0 * corr[j])}


def main():
    G2.SetPrintLevel("warn")
    source = Path(sys.argv[1]) if len(sys.argv) > 1 else WORK / "profile_accepted.gpx"
    suffix = sys.argv[2] if len(sys.argv) > 2 else ""
    rows = []
    for term, bounds in TERMS.items():
        tag = term.replace("/", "_")
        path = WORK / f"instrument_{tag}{suffix}.gpx"
        project = G2.G2Project(
            gpxfile=str(source), newgpx=str(path)
        )
        project.index_ids()
        clear_all(project)
        h = hist(project)
        h.Background[0][1] = True
        h.set_refinements({"Instrument Parameters": [term]})
        project.set_Controls("parmMin", bounds[0], variable=f":0:{term}")
        project.set_Controls("parmMax", bounds[1], variable=f":0:{term}")
        for phase in project.phases():
            phase.set_HAP_refinements({"Scale": True})
        result = run(project, f"p30_instrument_{tag}", 12)
        result.update({
            "term": term,
            "value": float(h.InstrumentParameters[term][1]),
            "path": str(path),
            "strongest_correlation": strongest_correlation(project, term),
        })
        rows.append(result)
    (WORK / f"instrument_scan{suffix}.json").write_text(json.dumps(rows, indent=2))
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
