#!/usr/bin/env python3
"""Test zero and specimen displacement separately from the same checkpoint."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def main():
    G2.SetPrintLevel("warn")
    rows = []
    for term in ("Shift", "Zero"):
        path = WORK / f"calibration_{term.lower()}.gpx"
        project = G2.G2Project(
            gpxfile=str(WORK / "profile_terminal_precal.gpx"), newgpx=str(path)
        )
        project.index_ids()
        clear_all(project); common(project)
        h = hist(project)
        if term == "Shift":
            h.set_refinements({"Sample Parameters": ["Shift"]})
            project.set_Controls("parmMin", -800.0, variable=":0:Shift")
            project.set_Controls("parmMax", 800.0, variable=":0:Shift")
        else:
            h.set_refinements({"Instrument Parameters": ["Zero"]})
            project.set_Controls("parmMin", -0.25, variable=":0:Zero")
            project.set_Controls("parmMax", 0.25, variable=":0:Zero")
        result = run(project, f"p50_calibration_{term.lower()}", 12)
        result.update({
            "term": term,
            "value": float(h.SampleParameters[term][0]) if term == "Shift"
                     else float(h.InstrumentParameters[term][1]),
            "path": str(path),
        })
        rows.append(result)
    (WORK / "calibration_scan.json").write_text(json.dumps(rows, indent=2))
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
