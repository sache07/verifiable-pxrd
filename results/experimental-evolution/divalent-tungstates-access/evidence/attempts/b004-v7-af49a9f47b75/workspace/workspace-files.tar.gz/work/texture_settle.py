#!/usr/bin/env python3
"""Converge the accepted Ba3W2O9 [110] texture branch."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "texture_p0_110.gpx"),
        newgpx=str(WORK / "texture_accepted_work.gpx"),
    )
    clear_all(project)
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    phase = project.phases()[0]
    hap = phase.data["Histograms"][h.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][3] = [1, 1, 0]
    phase.set_HAP_refinements({"Pref.Ori.": True})
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    run(project, "t01_ba3w2o9_110_settle", 14)
    clear_all(project)
    # Retain the accepted correction value but freeze it for the next tests.
    project.save(str(WORK / "texture_accepted.gpx"))


if __name__ == "__main__":
    main()
