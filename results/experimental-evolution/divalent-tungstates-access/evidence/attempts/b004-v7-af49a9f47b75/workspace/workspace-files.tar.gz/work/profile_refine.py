#!/usr/bin/env python3
"""Restart from the cell checkpoint and separate phase and instrument profiles."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, install_bounds, run, state


def enable_common(project, cells=True):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if cells:
            phase.set_refinements({"Cell": True})


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "s03_cells.gpx"),
        newgpx=str(WORK / "profile_restart.gpx"),
    )
    h = hist(project)
    clear_all(project)
    h.SampleParameters["Scale"] = [1.0, False]
    # Return the common profile to its interior starting point; retain the
    # already fitted cells and angular correction for this profile separation.
    starts = {"U": 20.0, "W": 20.0, "X": 0.8, "SH/L": 0.025}
    for key, value in starts.items():
        h.InstrumentParameters[key][1] = value
        h.InstrumentParameters[key][2] = False
    for phase, size0 in zip(project.phases(), [0.30, 1.20, 0.25]):
        hap = phase.data["Histograms"][h.name]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 800.0
        hap["Mustrain"][2] = [False, False, False]
    install_bounds(project)
    project.save()

    clear_all(project); enable_common(project)
    run(project, "p01_rescale", 10)

    clear_all(project); enable_common(project)
    for phase in project.phases():
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    run(project, "p02_sizes", 12)

    clear_all(project); enable_common(project)
    for phase in project.phases():
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    run(project, "p03_strains", 12)

    clear_all(project); enable_common(project)
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    run(project, "p04_joint_phase_profiles", 12)

    # Fit low-angle common broadening before angular broadening.
    clear_all(project); enable_common(project)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    run(project, "p05_instrument_low_angle", 12)

    clear_all(project); enable_common(project)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["U"]})
    run(project, "p06_instrument_U", 12)

    clear_all(project); enable_common(project)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
    run(project, "p07_joint_profiles", 16)
    project.save(str(WORK / "profile_developed.gpx"))


if __name__ == "__main__":
    main()
