#!/usr/bin/env python3
"""Compare equally developed uniaxial microstrain branches for Ba3W2O9."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def main():
    G2.SetPrintLevel("warn")
    rows = []
    for axis in AXES:
        tag = "".join(str(v) for v in axis)
        path = WORK / f"strain_ba3_{tag}.gpx"
        project = G2.G2Project(
            gpxfile=str(WORK / "profile_isotropic.gpx"), newgpx=str(path)
        )
        project.index_ids()
        clear_all(project); common(project)
        phase = project.phases()[0]
        hap = phase.data["Histograms"][hist(project).name]
        start = float(hap["Mustrain"][1][0])
        hap["Mustrain"][1][1] = start
        phase.set_HAP_refinements({
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {
                "type": "uniaxial", "direction": axis, "refine": True,
            },
        })
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 300.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMin", 75.0, variable=f"{pid}:0:Mustrain;a")
        project.set_Controls("parmMax", 32000.0, variable=f"{pid}:0:Mustrain;a")
        result = run(project, f"p10_ba3_strain_{tag}", 14)
        hap = phase.data["Histograms"][hist(project).name]
        eq, axial = map(float, hap["Mustrain"][1][:2])
        result.update({
            "axis": list(axis), "equatorial_ppm": eq, "axial_ppm": axial,
            "axial_ratio": axial / eq, "size_um": float(hap["Size"][1][0]),
            "path": str(path),
        })
        rows.append(result)
    (WORK / "strain_scan.json").write_text(json.dumps(rows, indent=2))
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
