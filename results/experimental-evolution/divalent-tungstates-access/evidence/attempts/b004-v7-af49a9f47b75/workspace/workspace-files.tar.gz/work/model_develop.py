#!/usr/bin/env python3
"""Calibrate and refine bounded structural coordinates phase by phase."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, install_bounds, run


COORD_WINDOW_A = 0.10


def common(project, cells=False):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if cells:
            phase.set_refinements({"Cell": True})


def install_coordinate_bounds(project):
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                delta = COORD_WINDOW_A / length
                var = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", value - delta, variable=var)
                project.set_Controls("parmMax", value + delta, variable=var)


def coord_stage(project, phase_index, oxygen, label, cycles=6):
    clear_all(project); common(project)
    phase = project.phases()[phase_index]
    for atom in phase.atoms():
        atom.refinement_flags = "X" if ((atom.element == "O") == oxygen) else " "
    run(project, label, cycles)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "profile_developed.gpx"),
        newgpx=str(WORK / "structural_develop.gpx"),
    )
    h = hist(project)
    install_bounds(project)
    # Roll back the bound-hit W term to the last tested interior checkpoint.
    h.InstrumentParameters["W"][1] = 2.1496571676948255
    h.InstrumentParameters["W"][2] = False
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    # Frozen reference models are normalized to this Uiso before specimen draws.
    for phase in project.phases():
        for atom in phase.atoms():
            atom.uiso = 0.005
            atom.refinement_flags = " "
    project.save()

    clear_all(project); common(project, cells=True)
    run(project, "d01_normalized_reference", 8)

    # Alternate the strongly correlated constant-zero and specimen-height
    # terms, keeping cells fixed during calibration.
    clear_all(project); common(project)
    h = hist(project); h.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "d02_shift", 5)

    clear_all(project); common(project)
    h = hist(project); h.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "d03_zero", 5)

    clear_all(project); common(project)
    h = hist(project); h.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "d04_shift_repeat", 5)

    clear_all(project); common(project, cells=True)
    run(project, "d05_cell_settle", 8)

    install_coordinate_bounds(project)
    coord_stage(project, 0, False, "d06_ba3w2o9_heavy", 6)
    coord_stage(project, 0, True, "d07_ba3w2o9_oxygen", 6)
    coord_stage(project, 1, False, "d08_wo3_heavy", 6)
    coord_stage(project, 1, True, "d09_wo3_oxygen", 6)
    coord_stage(project, 2, False, "d10_baco3_heavy", 6)
    coord_stage(project, 2, True, "d11_baco3_oxygen", 6)

    clear_all(project); common(project)
    for phase in project.phases():
        for atom in phase.atoms():
            atom.refinement_flags = "X"
    run(project, "d12_joint_coordinates", 8)
    clear_all(project)
    project.save(str(WORK / "coordinates_developed.gpx"))


if __name__ == "__main__":
    main()
