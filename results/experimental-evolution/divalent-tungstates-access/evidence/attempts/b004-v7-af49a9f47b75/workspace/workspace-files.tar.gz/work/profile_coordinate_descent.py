#!/usr/bin/env python3
"""Alternate common U with phase widths until their physical split stabilizes."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run
from accept_u_reprofile import common, activate_u, activate_phase_profiles


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "u_profile_accepted.gpx"),
        newgpx=str(WORK / "profile_coordinate_work.gpx"),
    )
    project.index_ids()
    for round_no in range(1, 4):
        clear_all(project); common(project); activate_u(project)
        run(project, f"p44_round_{round_no}_u", 12)

        clear_all(project); common(project); activate_phase_profiles(project)
        run(project, f"p44_round_{round_no}_profile_a", 12)
        run(project, f"p44_round_{round_no}_profile_b", 12)

    clear_all(project)
    project.save(str(WORK / "profile_coordinate_accepted.gpx"))


if __name__ == "__main__":
    main()
