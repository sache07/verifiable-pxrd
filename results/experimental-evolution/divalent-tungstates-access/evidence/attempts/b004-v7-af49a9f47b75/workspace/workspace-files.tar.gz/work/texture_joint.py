#!/usr/bin/env python3
"""Settle the best symmetry-diverse texture model for all phases."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "minor_texture_p1_010.gpx"),
        newgpx=str(WORK / "texture_joint_work.gpx"),
    )
    clear_all(project)
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    axes = ([1, 1, 0], [0, 1, 0], [0, 0, 1])
    starts = (1.305, 0.967, 1.0)
    for phase, axis, ratio in zip(project.phases(), axes, starts):
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][h.name]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = ratio
        hap["Pref.Ori."][3] = list(axis)
        phase.set_HAP_refinements({"Pref.Ori.": True})
        for atom in phase.atoms():
            atom.refinement_flags = "U"
    run(project, "v01_joint_textures_uiso", 12)
    clear_all(project)
    project.save(str(WORK / "texture_joint.gpx"))


if __name__ == "__main__":
    main()
