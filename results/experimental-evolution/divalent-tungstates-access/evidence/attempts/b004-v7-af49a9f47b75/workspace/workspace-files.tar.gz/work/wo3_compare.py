#!/usr/bin/env python3
"""Equally develop exact-composition WO3 references against the common model."""

from __future__ import annotations

import copy
import json
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
CANDIDATES = ["1528915", "2311041", "2106293", "2107312", "1010618"]
AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def cod_path(cod_id):
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def add_bounds(project, phase, source_coordinates):
    project.index_ids()
    controls = project.data["Controls"]["data"]
    controls["parmFrozen"] = {"FrozenList": []}
    pid = phase.data["pId"]
    cell = phase.get_cell()
    lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
    reciprocal = G2lat.cell2A([
        cell["length_a"], cell["length_b"], cell["length_c"],
        cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
    ])
    for index, value in enumerate(reciprocal):
        span = max(0.01 * abs(float(value)), 0.0003)
        project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
        project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
    for index, (atom, coords) in enumerate(zip(phase.atoms(), source_coordinates)):
        for axis, value, length in zip("xyz", coords, lengths):
            half = 0.10 / length
            project.set_Controls("parmMin", value - half, variable=f"{pid}::dA{axis}:{index}")
            project.set_Controls("parmMax", value + half, variable=f"{pid}::dA{axis}:{index}")
        variable = f"{pid}::AUiso:{index}"
        project.set_Controls("parmMin", 0.003, variable=variable)
        project.set_Controls("parmMax", 0.020, variable=variable)
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def run(project, cycles):
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save(); project.refine(makeBack=False); project.save()
    h = hist(project)
    rvals = project.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    return {
        "Rwp_percent": h.get_wR(), "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
    }


def build_project(cod_id, base, ba3_cif, baco3_cif):
    path = WORK / f"wo3_{cod_id}_work.gpx"
    project = G2.G2Project(newgpx=str(path))
    h = project.add_powder_histogram(
        str(WORK / "pattern.xye"), str(WORK / "instrument.instprm"),
        fmthint="xye",
    )
    base_h = hist(base)
    h.data["Instrument Parameters"] = copy.deepcopy(base_h.data["Instrument Parameters"])
    h.data["Sample Parameters"] = copy.deepcopy(base_h.data["Sample Parameters"])
    h.data["Background"] = copy.deepcopy(base_h.data["Background"])
    h.data["Limits"] = copy.deepcopy(base_h.data["Limits"])
    files = [ba3_cif, cod_path(cod_id), baco3_cif]
    names = ["Ba3W2O9_R-3c", f"WO3_{cod_id}", "BaCO3_Pnma"]
    phases = [
        project.add_phase(str(file), phasename=name, histograms=[h], fmthint="CIF")
        for file, name in zip(files, names)
    ]
    # Transfer the accepted specimen model for the common phases.
    for new_index, old_index in ((0, 0), (2, 2)):
        src = base.phases()[old_index].data["Histograms"][base_h.name]
        dst = phases[new_index].data["Histograms"][h.name]
        for key in ("Scale", "Size", "Mustrain", "Pref.Ori."):
            dst[key] = copy.deepcopy(src[key])
            if key == "Scale": dst[key][1] = False
            if key == "Pref.Ori.": dst[key][2] = False
    src = base.phases()[1].data["Histograms"][base_h.name]
    dst = phases[1].data["Histograms"][h.name]
    dst["Scale"] = [src["Scale"][0], False]
    dst["Size"] = copy.deepcopy(src["Size"]); dst["Size"][2] = [False] * len(dst["Size"][2])
    dst["Mustrain"] = copy.deepcopy(src["Mustrain"]); dst["Mustrain"][2] = [False] * len(dst["Mustrain"][2])
    dst["Pref.Ori."][0] = "MD"; dst["Pref.Ori."][1] = 1.0
    dst["Pref.Ori."][2] = False; dst["Pref.Ori."][3] = [0, 0, 1]
    target_u = base.phases()[1].atoms()[0].uiso
    for atom in phases[1].atoms(): atom.uiso = target_u
    project.save(); project.index_ids()
    target = phases[1]
    source_coordinates = [a.coordinates for a in target.atoms()]
    variables = tuple(f"{target.data['pId']}::AUiso:{i}" for i in range(len(target.atoms())))
    if len(variables) > 1: project.add_EquivConstr(variables)
    add_bounds(project, target, source_coordinates)
    project.save()
    return project, source_coordinates


def main():
    G2.SetPrintLevel("warn")
    base = G2.G2Project(str(WORK / "texture_joint.gpx"))
    ba3_cif = WORK / "compare_ba3.cif"
    baco3_cif = WORK / "compare_baco3.cif"
    base.phases()[0].export_CIF(str(ba3_cif))
    base.phases()[2].export_CIF(str(baco3_cif))
    summaries = []
    for cod_id in CANDIDATES:
        project, source_coordinates = build_project(cod_id, base, ba3_cif, baco3_cif)
        target = project.phases()[1]

        clear_all(project); common(project); target.set_refinements({"Cell": True})
        cell_result = run(project, 9)

        clear_all(project); common(project)
        target = project.phases()[1]
        for atom in target.atoms(): atom.refinement_flags = "X" if atom.element == "W" else " "
        coord_result = run(project, 9)

        clear_all(project); common(project)
        target = project.phases()[1]
        for atom in target.atoms(): atom.refinement_flags = "U"
        uiso_result = run(project, 8)
        adapted = WORK / f"wo3_{cod_id}_adapted.gpx"
        shutil.copy2(project.filename, adapted)

        texture_rows = []
        for axis in AXES:
            branch_path = WORK / f"wo3_{cod_id}_tex_{axis[0]}{axis[1]}{axis[2]}.gpx"
            branch = G2.G2Project(gpxfile=str(adapted), newgpx=str(branch_path))
            clear_all(branch); common(branch)
            target = branch.phases()[1]
            hap = target.data["Histograms"][hist(branch).name]
            hap["Pref.Ori."][0] = "MD"; hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(axis)
            target.set_HAP_refinements({"Pref.Ori.": True})
            for atom in target.atoms(): atom.refinement_flags = "U"
            result = run(branch, 7)
            result.update(axis=list(axis), ratio=target.data["Histograms"][hist(branch).name]["Pref.Ori."][1], path=str(branch_path))
            texture_rows.append(result)
        eligible = [row for row in texture_rows if not row["frozen"]]
        best = min(eligible or texture_rows, key=lambda row: row["Rwp_percent"])

        final_path = WORK / f"wo3_{cod_id}_final.gpx"
        final = G2.G2Project(gpxfile=best["path"], newgpx=str(final_path))
        clear_all(final); common(final)
        target = final.phases()[1]
        target.set_refinements({"Cell": True})
        target.set_HAP_refinements({"Pref.Ori.": True})
        for atom in target.atoms():
            atom.refinement_flags = "XU" if atom.element == "W" else "U"
        final_result = run(final, 10)
        h = hist(final); target = final.phases()[1]
        summary = {
            "cod_id": cod_id,
            "cell_adaptation": cell_result,
            "coordinate_adaptation": coord_result,
            "uiso_adaptation": uiso_result,
            "texture_trials": texture_rows,
            "selected_axis": best["axis"],
            "selected_ratio_start_checkpoint": best["ratio"],
            "final": final_result,
            "final_ratio": target.data["Histograms"][h.name]["Pref.Ori."][1],
            "final_uiso": target.atoms()[0].uiso,
            "final_cell": target.get_cell(),
            "mass_fractions": {k: v[0] for k, v in h.ComputeMassFracs().items()},
            "project": str(final_path),
        }
        summaries.append(summary)
        print(json.dumps(summary), flush=True)
    (WORK / "wo3_compare.json").write_text(json.dumps(summaries, indent=2) + "\n")


if __name__ == "__main__":
    main()
