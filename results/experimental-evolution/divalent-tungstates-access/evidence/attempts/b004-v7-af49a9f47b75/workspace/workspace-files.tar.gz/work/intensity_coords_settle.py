#!/usr/bin/env python3
"""Settle supported cation coordinates, phase Uiso and accepted texture terms."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def install_coordinate_bounds(project):
    project.index_ids()
    for phase in project.phases():
        cell = phase.get_cell()
        lengths = [cell["length_a"], cell["length_b"], cell["length_c"]]
        pid = phase.data["pId"]
        for index, atom in enumerate(phase.atoms()):
            for axis, value, length in zip("xyz", atom.coordinates, lengths):
                half_width = 0.10 / max(float(length), 1.0e-6)
                variable = f"{pid}::dA{axis}:{index}"
                project.set_Controls("parmMin", float(value) - half_width, variable=variable)
                project.set_Controls("parmMax", float(value) + half_width, variable=variable)


def activate_cations(project, phase_index):
    for pi, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = (
                "X" if pi == phase_index and atom.element.strip() in {"Ba", "W"} else " "
            )


def activate_intensity(project):
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        phase.set_HAP_refinements({"Pref.Ori.": True})
        project.set_Controls("parmMin", 0.70, variable=f"{pid}:0:MD")
        project.set_Controls("parmMax", 1.40, variable=f"{pid}:0:MD")
        for index, atom in enumerate(phase.atoms()):
            atom.refinement_flags = "U"
            variable = f"{pid}::AUiso:{index}"
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "calibration_cells_accepted.gpx"),
        newgpx=str(WORK / "intensity_coords_work.gpx"),
    )
    project.index_ids()
    install_coordinate_bounds(project)

    for phase_index in range(3):
        clear_all(project); common(project); activate_cations(project, phase_index)
        run(project, f"p60_phase_{phase_index}_cation_coords_a", 10)
        run(project, f"p60_phase_{phase_index}_cation_coords_b", 10)

    clear_all(project); common(project); activate_intensity(project)
    for index in range(1, 4):
        run(project, f"p61_intensity_settle_{index}", 12)

    clear_all(project)
    project.save(str(WORK / "intensity_coords_accepted.gpx"))


if __name__ == "__main__":
    main()
