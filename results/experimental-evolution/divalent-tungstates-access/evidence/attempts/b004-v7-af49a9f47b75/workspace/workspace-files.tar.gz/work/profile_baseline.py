#!/usr/bin/env python3
"""Settle the physical isotropic phase-profile checkpoint."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def activate_profile(project, phase_index):
    phase = project.phases()[phase_index]
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMax", 1.50, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    phase.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "physical_uiso.gpx"),
        newgpx=str(WORK / "profile_baseline_work.gpx"),
    )
    project.index_ids()

    clear_all(project); common(project); activate_profile(project, 0)
    run(project, "p01_ba3_isotropic_profile", 12)

    clear_all(project); common(project); activate_profile(project, 2)
    run(project, "p02_baco3_isotropic_profile", 12)

    clear_all(project); common(project)
    activate_profile(project, 0); activate_profile(project, 2)
    run(project, "p03_isotropic_profile_joint", 12)

    clear_all(project)
    project.save(str(WORK / "profile_isotropic.gpx"))


if __name__ == "__main__":
    main()
