#!/usr/bin/env python3
"""Build and progressively refine the ordinary Ba-W-O phase model."""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "work"
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


PHASES = [
    ("Ba3W2O9_R-3c", "1533878"),
    ("WO3_P21c", "1528915"),
    ("BaCO3_Pnma", "9010928"),
]


def hist(project):
    return project.histograms()[0]


def clear_all(project):
    h = hist(project)
    h.Background[0][1] = False
    for val in h.InstrumentParameters.values():
        if isinstance(val, list) and len(val) > 2:
            val[2] = False
    for val in h.SampleParameters.values():
        if isinstance(val, list) and len(val) > 1 and isinstance(val[1], bool):
            val[1] = False
    for phase in project.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True,
        })
        for atom in phase.atoms():
            atom.refinement_flags = " "
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def install_bounds(project):
    controls = project.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {"FrozenList": []}
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
        ":0:Shift": (-800.0, 800.0),
    }
    for var, (lo, hi) in bounds.items():
        project.set_Controls("parmMin", lo, variable=var)
        project.set_Controls("parmMax", hi, variable=var)
    project.index_ids()
    for phase in project.phases():
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 1.0e6, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")


def state(project, label):
    h = hist(project)
    cov = project.data.get("Covariance", {}).get("data", {})
    rvals = cov.get("Rvals", {})
    inst = {
        key: val[1] if isinstance(val, list) and len(val) > 1 else val
        for key, val in h.InstrumentParameters.items()
        if key in {"Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L"}
    }
    sample = {
        key: (val[0] if isinstance(val, list) else val)
        for key, val in h.SampleParameters.items()
        if key in {"Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Scale", "Gonio. radius"}
    }
    phase_rows = []
    for phase in project.phases():
        hap = phase.data["Histograms"][h.name]
        phase_rows.append({
            "name": phase.name,
            "cell": phase.get_cell(),
            "scale": hap["Scale"][0],
            "size": hap["Size"][:4],
            "mustrain": hap["Mustrain"][:4],
            "pref_ori": hap["Pref.Ori."][:4],
        })
    row = {
        "stage": label,
        "Rwp_percent": h.get_wR(),
        "GOF": rvals.get("GOF"),
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": list(project.get_Frozen()),
        "instrument": inst,
        "sample": sample,
        "phases": phase_rows,
    }
    print(json.dumps(row), flush=True)
    return row


def run(project, label, cycles=8):
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    result = state(project, label)
    shutil.copy2(project.filename, WORK / f"{label}.gpx")
    return result


def build():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(newgpx=str(WORK / "initial.gpx"))
    h = project.add_powder_histogram(
        str(WORK / "pattern.xye"), str(WORK / "instrument.instprm"),
        fmthint="xye",
    )
    h.SampleParameters["Type"] = "Bragg-Brentano"
    h.SampleParameters["Gonio. radius"] = 200.0
    h.SampleParameters["Shift"] = [0.0, False]
    h.SampleParameters["SurfRoughA"] = [0.0, False]
    h.SampleParameters["SurfRoughB"] = [0.0, False]
    h.set_refinements({
        "Limits": [10.0, 100.0],
        "Background": {
            "type": "chebyschev-1", "no. coeffs": 12,
            "coeffs": [1100.0] + [0.0] * 11, "refine": False,
        },
    })
    for name, cod_id in PHASES:
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[h], fmthint="CIF"
        )
        hap = phase.data["Histograms"][h.name]
        hap["Scale"] = [1.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 1.0
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 500.0
        hap["Mustrain"][2] = [False, False, False]
    project.save()
    project.index_ids()
    install_bounds(project)

    # Establish positive phase scales and a smooth background.
    clear_all(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    run(project, "s01_scale_background", 12)

    # Refine the two allowed angular calibration components, then cells.
    clear_all(project)
    h.Background[0][1] = True
    h.set_refinements({"Instrument Parameters": ["Zero"]})
    h.set_refinements({"Sample Parameters": ["Shift"]})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    run(project, "s02_zero_shift", 12)

    clear_all(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    run(project, "s03_cells", 12)

    # Develop the common instrumental profile within laboratory bounds.
    clear_all(project)
    h.Background[0][1] = True
    h.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        phase.set_refinements({"Cell": True})
    run(project, "s04_instrument_profile", 12)

    # Develop phase-dependent broadening after the common profile.
    clear_all(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Scale": True,
            "Size": {"type": "isotropic", "value": 0.5, "refine": True},
        })
        phase.set_refinements({"Cell": True})
    run(project, "s05_sizes", 12)

    clear_all(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Scale": True,
            "Size": {"type": "isotropic", "refine": True},
            "Mustrain": {"type": "isotropic", "refine": True},
        })
        phase.set_refinements({"Cell": True})
    run(project, "s06_phase_profiles", 16)
    project.save(str(WORK / "ordinary.gpx"))


if __name__ == "__main__":
    build()
