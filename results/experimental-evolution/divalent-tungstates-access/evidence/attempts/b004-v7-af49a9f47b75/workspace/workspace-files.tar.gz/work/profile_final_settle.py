#!/usr/bin/env python3
"""Settle accepted U and axial-divergence terms against phase widths."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run
from accept_u_reprofile import common, activate_u, activate_phase_profiles


def activate_shl(project):
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["SH/L"]})
    project.set_Controls("parmMin", 0.005, variable=":0:SH/L")
    project.set_Controls("parmMax", 0.100, variable=":0:SH/L")


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "instrument_SH_L_post.gpx"),
        newgpx=str(WORK / "profile_final_settle_work.gpx"),
    )
    project.index_ids()
    for round_no in range(1, 3):
        clear_all(project); common(project); activate_u(project)
        run(project, f"p45_round_{round_no}_u", 12)

        clear_all(project); common(project); activate_shl(project)
        run(project, f"p45_round_{round_no}_shl", 12)

        clear_all(project); common(project); activate_phase_profiles(project)
        run(project, f"p45_round_{round_no}_profile_a", 12)
        run(project, f"p45_round_{round_no}_profile_b", 12)

    clear_all(project)
    project.save(str(WORK / "profile_terminal_precal.gpx"))


if __name__ == "__main__":
    main()
