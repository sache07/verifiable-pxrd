#!/usr/bin/env python3
"""Converge the accepted isotropic phase-profile model."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "profile_isotropic.gpx"),
        newgpx=str(WORK / "profile_settle_work.gpx"),
    )
    project.index_ids()
    clear_all(project)
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})

    ba3 = project.phases()[0]
    ba3.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
        "Mustrain": {"type": "isotropic", "refine": True},
    })
    carbonate = project.phases()[2]
    chap = carbonate.data["Histograms"][h.name]
    chap["Mustrain"][0] = "isotropic"
    chap["Mustrain"][1][0] = 0.0
    chap["Mustrain"][2] = [False] * len(chap["Mustrain"][2])
    carbonate.set_HAP_refinements({
        "Size": {"type": "isotropic", "refine": True},
    })
    for phase in (ba3, carbonate):
        pid = phase.data["pId"]
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.50, variable=f"{pid}:0:Size;i")
    project.set_Controls("parmMin", 300.0, variable="0:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable="0:0:Mustrain;i")

    for index in range(1, 4):
        run(project, f"p20_profile_settle_{index}", 12)

    clear_all(project)
    project.save(str(WORK / "profile_accepted.gpx"))


if __name__ == "__main__":
    main()
