#!/usr/bin/env python3
"""Converge cells, calibration and supported parameters for the winning WO3 basin."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def common(project, cells=False):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if cells:
            phase.set_refinements({"Cell": True})


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "wo3_2311041_final.gpx"),
        newgpx=str(WORK / "winner_structural_work.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    clear_all(project); common(project, cells=True)
    run(project, "x01_all_cells", 14)

    clear_all(project); common(project)
    h = hist(project); h.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "x02_shift", 6)

    clear_all(project); common(project)
    h = hist(project); h.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "x03_zero", 6)

    clear_all(project); common(project, cells=True)
    run(project, "x04_cell_replay_settle", 10)

    # Only W coordinates in the replacement WO3 phase are supported by the
    # comparison. Other accepted heavy coordinates are already converged.
    clear_all(project); common(project)
    for atom in project.phases()[1].atoms():
        atom.refinement_flags = "X" if atom.element == "W" else " "
    run(project, "x05_wo3_W_settle", 10)

    clear_all(project); common(project)
    for phase in project.phases():
        phase.set_HAP_refinements({"Pref.Ori.": True})
        for atom in phase.atoms(): atom.refinement_flags = "U"
    run(project, "x06_intensity_settle", 12)

    clear_all(project)
    project.save(str(WORK / "winner_structural.gpx"))


if __name__ == "__main__":
    main()
