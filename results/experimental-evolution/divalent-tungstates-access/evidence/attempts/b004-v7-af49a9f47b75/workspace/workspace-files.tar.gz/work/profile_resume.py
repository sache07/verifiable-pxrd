#!/usr/bin/env python3
"""Resume profile development with phasewise strain updates."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, install_bounds, run


def common(project, cells=False):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        if cells:
            phase.set_refinements({"Cell": True})


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "p02_sizes.gpx"),
        newgpx=str(WORK / "profile_phasewise.gpx"),
    )
    install_bounds(project)
    for index, phase in enumerate(project.phases()):
        clear_all(project); common(project)
        phase = project.phases()[index]
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        })
        run(project, f"q0{index + 1}_strain_{index}", 5)

    clear_all(project); common(project, cells=True)
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        })
    run(project, "q04_joint_strains", 8)

    # Common low-angle terms, then angular Gaussian width.
    clear_all(project); common(project, cells=True)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    run(project, "q05_common_low_angle", 8)

    clear_all(project); common(project, cells=True)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["U"]})
    run(project, "q06_common_U", 8)

    clear_all(project); common(project, cells=True)
    h = hist(project)
    h.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    for phase in project.phases():
        phase.set_HAP_refinements({
            "Mustrain": {"type": "isotropic", "refine": True}
        })
    run(project, "q07_profile_settle", 10)
    project.save(str(WORK / "profile_developed.gpx"))


if __name__ == "__main__":
    main()
