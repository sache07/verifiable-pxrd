#!/usr/bin/env python3
"""Compare the laboratory's allowed March-Dollase axes from one checkpoint."""

import json
from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist


AXES = [(0, 0, 1), (1, 0, 0), (0, 1, 0), (1, 1, 0), (1, 1, 1)]


def main():
    G2.SetPrintLevel("warn")
    source = WORK / "coordinates_developed.gpx"
    rows = []
    for phase_index in range(3):
        for axis in AXES:
            tag = f"texture_p{phase_index}_{axis[0]}{axis[1]}{axis[2]}"
            project = G2.G2Project(
                gpxfile=str(source), newgpx=str(WORK / f"{tag}.gpx")
            )
            clear_all(project)
            h = hist(project)
            h.Background[0][1] = True
            h.SampleParameters["Scale"] = [1.0, False]
            for phase in project.phases():
                phase.set_HAP_refinements({"Scale": True})
                hap = phase.data["Histograms"][h.name]
                hap["Pref.Ori."][0] = "MD"
                hap["Pref.Ori."][1] = 1.0
                hap["Pref.Ori."][2] = False
            phase = project.phases()[phase_index]
            hap = phase.data["Histograms"][h.name]
            hap["Pref.Ori."][3] = list(axis)
            hap["Pref.Ori."][2] = True
            pid = phase.data["pId"]
            project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
            project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
            project.set_Controls("cycles", 5)
            project.save()
            project.refine(makeBack=False)
            project.save()
            h = hist(project)
            phase = project.phases()[phase_index]
            cov = project.data.get("Covariance", {}).get("data", {})
            rvals = cov.get("Rvals", {})
            row = {
                "phase_index": phase_index,
                "phase": phase.name,
                "axis": list(axis),
                "ratio": phase.data["Histograms"][h.name]["Pref.Ori."][1],
                "Rwp_percent": h.get_wR(),
                "converged": rvals.get("converged"),
                "max_shift_esd": rvals.get("Max shft/sig"),
                "frozen": list(project.get_Frozen()),
                "project": str(WORK / f"{tag}.gpx"),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
    (WORK / "texture_scan.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
