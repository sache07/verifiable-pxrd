#!/usr/bin/env python3
"""Test the optional Suortti surface-roughness term from an equal checkpoint."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "texture_joint.gpx"),
        newgpx=str(WORK / "roughness_test_work.gpx"),
    )
    clear_all(project)
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    h.SampleParameters["SurfRoughA"] = [0.30, True]
    h.SampleParameters["SurfRoughB"] = [0.10, True]
    project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
    project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
    project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
    project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    run(project, "w02_surface_roughness_test", 10)
    clear_all(project)
    project.save(str(WORK / "roughness_test.gpx"))


if __name__ == "__main__":
    main()
