#!/usr/bin/env python3
"""Coordinate-descent settle of displacement, zero and unit cells."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def activate_shift(project):
    hist(project).set_refinements({"Sample Parameters": ["Shift"]})
    project.set_Controls("parmMin", -800.0, variable=":0:Shift")
    project.set_Controls("parmMax", 800.0, variable=":0:Shift")


def activate_zero(project):
    hist(project).set_refinements({"Instrument Parameters": ["Zero"]})
    project.set_Controls("parmMin", -0.25, variable=":0:Zero")
    project.set_Controls("parmMax", 0.25, variable=":0:Zero")


def install_cell_bounds(project):
    for phase in project.phases():
        cell = phase.get_cell()
        values = [cell[k] for k in (
            "length_a", "length_b", "length_c",
            "angle_alpha", "angle_beta", "angle_gamma",
        )]
        avec = G2lat.cell2A(values)
        pid = phase.data["pId"]
        for index, value in enumerate(avec):
            span = max(abs(float(value)) * 0.005, 0.0003)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")


def activate_cells(project):
    for phase in project.phases():
        phase.set_refinements({"Cell": True})


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "calibration_shift.gpx"),
        newgpx=str(WORK / "calibration_cells_work.gpx"),
    )
    project.index_ids()
    install_cell_bounds(project)

    for round_no in range(1, 3):
        clear_all(project); common(project); activate_shift(project)
        run(project, f"p51_round_{round_no}_shift", 12)

        clear_all(project); common(project); activate_zero(project)
        run(project, f"p51_round_{round_no}_zero", 12)

        clear_all(project); common(project); activate_cells(project)
        run(project, f"p51_round_{round_no}_cells_a", 12)
        run(project, f"p51_round_{round_no}_cells_b", 12)

    clear_all(project)
    project.save(str(WORK / "calibration_cells_accepted.gpx"))


if __name__ == "__main__":
    main()
