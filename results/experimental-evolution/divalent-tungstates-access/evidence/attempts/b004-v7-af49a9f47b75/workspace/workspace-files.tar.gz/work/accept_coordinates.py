#!/usr/bin/env python3
"""Retain only interior heavy-atom coordinate refinements."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, hist, run


def common(project):
    h = hist(project)
    h.Background[0][1] = True
    h.SampleParameters["Scale"] = [1.0, False]
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})


def select(project, phase_index=None, labels=()):
    for pi, phase in enumerate(project.phases()):
        for atom in phase.atoms():
            atom.refinement_flags = (
                "X" if pi == phase_index and atom.label in labels else " "
            )


def main():
    G2.SetPrintLevel("warn")
    # d06 contains the accepted Ba3W2O9 heavy-atom update and untouched
    # reference coordinates for every light atom and the other phases.
    project = G2.G2Project(
        gpxfile=str(WORK / "d06_ba3w2o9_heavy.gpx"),
        newgpx=str(WORK / "accepted_coordinates_work.gpx"),
    )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}

    clear_all(project); common(project); select(project, 0, ("W1", "Ba1"))
    run(project, "e01_ba3w2o9_heavy_settle", 8)

    clear_all(project); common(project); select(project, 1, ("W1", "W2"))
    run(project, "e02_wo3_heavy_clean", 8)

    clear_all(project); common(project); select(project, 2, ("Ba",))
    run(project, "e03_baco3_ba_clean", 6)

    clear_all(project); common(project)
    select(project, 0, ("W1", "Ba1"))
    for atom in project.phases()[1].atoms():
        if atom.label in ("W1", "W2"):
            atom.refinement_flags = "X"
    for atom in project.phases()[2].atoms():
        if atom.label == "Ba":
            atom.refinement_flags = "X"
    run(project, "e04_heavy_coordinate_settle", 8)

    clear_all(project)
    project.save(str(WORK / "coordinates_developed.gpx"))


if __name__ == "__main__":
    main()
