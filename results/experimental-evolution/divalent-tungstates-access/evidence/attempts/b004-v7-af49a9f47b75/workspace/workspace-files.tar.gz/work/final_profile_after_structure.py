#!/usr/bin/env python3
"""Re-equilibrate accepted phase and common widths after coordinate settling."""

from pathlib import Path
import sys

from GSASII import GSASIIscriptable as G2

sys.path.insert(0, str(Path(__file__).resolve().parent))
from refine import WORK, clear_all, run
from accept_u_reprofile import common, activate_u, activate_phase_profiles
from profile_final_settle import activate_shl


def main():
    G2.SetPrintLevel("warn")
    project = G2.G2Project(
        gpxfile=str(WORK / "intensity_coords_accepted.gpx"),
        newgpx=str(WORK / "final_profile_after_structure_work.gpx"),
    )
    project.index_ids()

    clear_all(project); common(project); activate_phase_profiles(project)
    run(project, "p70_reprofile_a", 12)
    run(project, "p70_reprofile_b", 12)

    clear_all(project); common(project); activate_u(project)
    run(project, "p71_instrument_u", 12)

    clear_all(project); common(project); activate_shl(project)
    run(project, "p71_instrument_shl", 12)

    clear_all(project); common(project); activate_phase_profiles(project)
    run(project, "p72_reprofile_a", 12)
    run(project, "p72_reprofile_b", 12)

    clear_all(project)
    project.save(str(WORK / "final_profile_after_structure.gpx"))


if __name__ == "__main__":
    main()
