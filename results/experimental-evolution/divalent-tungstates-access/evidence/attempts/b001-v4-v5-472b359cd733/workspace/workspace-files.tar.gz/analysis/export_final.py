"""Export the selected full-grid physical GSAS-II model and diagnostics."""

from __future__ import annotations

from pathlib import Path
import csv
import json
import math

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "analysis" / "final_trials" / "full_grid_light_cawo4.gpx"
FINAL_GPX = ROOT / "final.gpx"


project = G2.G2Project(str(SOURCE), newgpx=str(FINAL_GPX))
project.save()
hist = project.histogram(0)

cif_names = ["phase_CaWO4_scheelite.cif", "phase_WO3_monoclinic.cif"]
for phase, name in zip(project.phases(), cif_names):
    phase.export_CIF(str(ROOT / name))

x, y_obs, weights, y_calc, background, difference = [
    np.asarray(values, dtype=float) for values in hist.data["data"][1][:6]
]
if not np.allclose(difference, y_obs - y_calc, rtol=0.0, atol=1e-8):
    raise RuntimeError("stored GSAS-II difference profile is inconsistent")
if len(x) != 8301:
    raise RuntimeError(f"expected the full 8301-point grid, found {len(x)}")

with (ROOT / "fit.csv").open("w", newline="") as stream:
    writer = csv.writer(stream)
    writer.writerow(
        [
            "two_theta_deg",
            "observed_intensity",
            "calculated_intensity",
            "difference",
        ]
    )
    writer.writerows(zip(x, y_obs, y_calc, difference))

fractions = hist.ComputeMassFracs()
residuals = hist.residuals
rwp = float(residuals["wR"])
rexp = float(residuals["wRmin"])

phase_values = []
for index, (phase, cif_name) in enumerate(zip(project.phases(), cif_names)):
    hap = phase.getHAPvalues(hist.name)
    value, sigma = fractions[phase.name]
    phase_values.append(
        {
            "project_name": phase.name,
            "cif_path": cif_name,
            "weight_fraction": value,
            "weight_fraction_formal_sigma": sigma,
            "cell": phase.get_cell(),
            "composition_in_cell": phase.composition,
            "density_g_cm3": phase.density,
            "scale": hap["Scale"][0],
            "size_um": hap["Size"][1][0],
            "mustrain_type": hap["Mustrain"][0],
            "mustrain_ppm": hap["Mustrain"][1][:2],
            "mustrain_axis": hap["Mustrain"][3],
            "uiso_A2": phase.atoms()[0].uiso,
        }
    )

values = {
    "histogram": hist.name,
    "point_count": len(x),
    "limits_two_theta_deg": list(hist.data["Limits"][1]),
    "fit_statistics_percent": {
        "Rwp": rwp,
        "Rp": float(residuals["R"]),
        "Rexp": rexp,
        "GOF": rwp / rexp,
        "reduced_chi_squared": (rwp / rexp) ** 2,
    },
    "instrument": {
        key: value[1]
        for key, value in hist.InstrumentParameters.items()
        if key
        in {
            "Lam1",
            "Lam2",
            "I(L2)/I(L1)",
            "Zero",
            "Polariz.",
            "U",
            "V",
            "W",
            "X",
            "Y",
            "SH/L",
        }
    },
    "sample": {
        "shift_um": hist.SampleParameters["Shift"][0],
        "goniometer_radius_mm": hist.SampleParameters["Gonio. radius"],
        "surface_roughness_A": hist.SampleParameters["SurfRoughA"][0],
        "surface_roughness_B": hist.SampleParameters["SurfRoughB"][0],
    },
    "phases": phase_values,
}
(ROOT / "analysis" / "final_values.json").write_text(
    json.dumps(values, indent=2) + "\n"
)

