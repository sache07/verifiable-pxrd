"""Run a comparable staged GSAS-II screen for a two-phase candidate model.

Usage (with the GSAS-II Python interpreter):
    refine_branch.py SECOND_COD_ID OUTPUT_DIRECTORY
"""

from __future__ import annotations

from pathlib import Path
import copy
import json
import math
import shutil
import sys

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parents[1]
COD_ROOT = Path(
    "<HOME>/.local/share/characterizagent/backends/dara/"
    "cod-filtered-2024/cif"
)


def cod_path(cod_id: str) -> Path:
    return COD_ROOT / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def snapshot(project: G2.G2Project, label: str) -> dict:
    hist = project.histogram(0)
    phases = []
    weighted_scales = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        scale = float(hap["Scale"][0])
        mass = float(phase.data["General"]["Mass"])
        weighted_scales.append(max(scale * mass, 0.0))
        phases.append(
            {
                "name": phase.name,
                "composition": phase.composition,
                "cell": phase.get_cell(),
                "mass": mass,
                "scale": scale,
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "occupancy": atom.occupancy,
                        "adp": atom.ADP,
                        "flags": atom.refinement_flags,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(weighted_scales)
    for phase, value in zip(phases, weighted_scales):
        phase["weight_fraction"] = value / total if total else None
    return {
        "stage": label,
        "residuals": hist.residuals,
        "instrument": copy.deepcopy(hist.InstrumentParameters),
        "sample": copy.deepcopy(hist.SampleParameters),
        "background": copy.deepcopy(hist.Background),
        "phases": phases,
        "vary_list": project.get_VaryList(),
    }


def clear_flags(project: G2.G2Project) -> None:
    """Clear all refinement flags used by this screening recipe."""
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for key in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        if isinstance(hist.SampleParameters.get(key), list):
            hist.SampleParameters[key][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def run_stage(
    project: G2.G2Project,
    output_dir: Path,
    label: str,
    log: list,
    passes: int = 2,
) -> None:
    project.set_Controls("cycles", 12)
    for _ in range(passes):
        project.refine()
    state = snapshot(project, label)
    rwp = state["residuals"].get("wR")
    if rwp is None or not math.isfinite(float(rwp)):
        raise RuntimeError(f"non-finite Rwp after {label}")
    project.save()
    shutil.copy2(project.filename, output_dir / f"checkpoint_{label}.gpx")
    log.append(state)
    print(
        label,
        "Rwp=", round(float(rwp), 5),
        "fractions=", [round(p["weight_fraction"], 5) for p in state["phases"]],
        "cells=", [
            [round(p["cell"][key], 5) for key in ("length_a", "length_b", "length_c")]
            for p in state["phases"]
        ],
        flush=True,
    )


def main(second_id: str, output_dir: Path) -> None:
    G2.SetPrintLevel("warn")
    output_dir.mkdir(parents=True, exist_ok=True)
    project_path = output_dir / "branch.gpx"
    project = G2.G2Project(newgpx=str(project_path))
    hist = project.add_powder_histogram(
        str(ROOT / "analysis" / "pattern.xye"),
        str(ROOT / "analysis" / "instrument.instprm"),
        fmthint="xye",
    )
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    # A positive specimen height shifts lines to lower 2theta in GSAS-II.
    hist.SampleParameters["Shift"] = [500.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 12,
                "coeffs": [1000.0] + [0.0] * 11,
                "refine": False,
            },
        }
    )

    phase_specs = [
        ("7219229", "CaWO4_scheelite"),
        (second_id, f"candidate_{second_id}"),
    ]
    phases = []
    for cod_id, name in phase_specs:
        phase = project.add_phase(
            str(cod_path(cod_id)), phasename=name, histograms=[hist], fmthint="CIF"
        )
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"] = [5.0, False]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = 0.2
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        for atom in phase.atoms():
            atom.refinement_flags = " "
            if atom.adp_flag == "I":
                atom.uiso = 0.01
        phases.append(phase)

    # Conservative bounds prevent a screening branch from winning through an
    # unphysical profile or a negative abundance.
    project.save()
    for pidx in range(len(phases)):
        project.set_Controls("parmMin", 1e-8, variable=f"{pidx}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pidx}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pidx}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pidx}:0:Mustrain;i")
        project.set_Controls("parmMax", 12000.0, variable=f"{pidx}:0:Mustrain;i")
    for name, lower, upper in (
        (":0:Shift", -800.0, 800.0),
        (":0:Zero", -0.25, 0.25),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.1),
    ):
        project.set_Controls("parmMin", lower, variable=name)
        project.set_Controls("parmMax", upper, variable=name)

    log = [snapshot(project, "initial")]

    clear_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    run_stage(project, output_dir, "scale_background", log)

    clear_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_stage(project, output_dir, "cells_shift", log)

    clear_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.set_HAP_refinements(
            {"Size": {"type": "isotropic", "refine": True}}, [hist]
        )
    run_stage(project, output_dir, "phase_size", log)

    clear_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    hist.set_refinements(
        {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
    )
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    run_stage(project, output_dir, "instrument_profile", log)

    clear_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
        phase.set_HAP_refinements(
            {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
        )
    run_stage(project, output_dir, "phase_strain", log)

    # Compare structures after allowing heavy-atom shifts, but do not let a
    # topology win merely by unconstrained motion of every oxygen atom.
    clear_flags(project)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True}, [hist])
    for atom in phases[1].atoms():
        if atom.element == "W":
            atom.refinement_flags = "X"
    run_stage(project, output_dir, "heavy_coordinates", log)

    (output_dir / "summary.json").write_text(json.dumps(log, indent=2) + "\n")
    project.save()


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("usage: refine_branch.py SECOND_COD_ID OUTPUT_DIRECTORY")
    main(sys.argv[1], Path(sys.argv[2]).resolve())
