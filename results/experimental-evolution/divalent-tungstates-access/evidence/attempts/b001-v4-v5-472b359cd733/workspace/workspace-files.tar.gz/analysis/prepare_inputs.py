"""Convert the supplied count data to a GSAS-II XYE input file."""

from pathlib import Path
import csv
import math


ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "inputs" / "pattern.csv"
target = ROOT / "analysis" / "pattern.xye"

with source.open(newline="") as stream, target.open("w") as out:
    rows = csv.DictReader(stream)
    for row in rows:
        two_theta = float(row["two_theta_deg"])
        intensity = float(row["intensity"])
        # Counting statistics are the defensible point weights when no
        # pointwise uncertainties are supplied. Guard against zero counts.
        sigma = math.sqrt(max(intensity, 1.0))
        out.write(f"{two_theta:.8f} {intensity:.8f} {sigma:.8f}\n")

