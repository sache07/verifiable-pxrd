"""Apply named, isolated refinement steps to an existing GSAS-II project.

This is intentionally a small experiment driver: each invocation starts from a
specified checkpoint, writes a new project, and records every intermediate
state. It permits direct A/B comparisons without contaminating the best model.
"""

from __future__ import annotations

from pathlib import Path
import copy
import json
import math
import shutil
import sys

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.Background[0][1] = False
    for key in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB"):
        value = hist.SampleParameters.get(key)
        if isinstance(value, list) and len(value) > 1:
            value[1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for phase in project.phases():
        phase.data["General"]["Cell"][0] = False
        for atom in phase.atoms():
            atom.refinement_flags = " "
        hap = phase.getHAPvalues(hist.name)
        hap["Scale"][1] = False
        hap["Pref.Ori."][2] = False
        hap["Size"][2] = [False] * len(hap["Size"][2])
        hap["Size"][5] = [False] * len(hap["Size"][5])
        hap["Mustrain"][2] = [False] * len(hap["Mustrain"][2])
        hap["Mustrain"][5] = [False] * len(hap["Mustrain"][5])


def set_base(project: G2.G2Project) -> None:
    hist = project.histogram(0)
    hist.set_refinements({"Background": {"refine": True}})
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True}, [hist])


def parse_axis(text: str) -> list[int]:
    axis = [int(v) for v in text.split("_")]
    if len(axis) != 3:
        raise ValueError(f"invalid axis {text!r}")
    return axis


def configure(project: G2.G2Project, mode: str) -> None:
    clear_flags(project)
    set_base(project)
    hist = project.histogram(0)
    phases = project.phases()

    if mode == "scale_background":
        return
    if mode == "full_limits":
        x = hist.data["data"][1][0]
        hist.set_refinements({"Limits": [float(x[0]), float(x[-1])]})
        return
    if mode in {"background16", "background20"}:
        count = int(mode.removeprefix("background"))
        hist.set_refinements(
            {"Background": {"no. coeffs": count, "refine": True}}
        )
        return
    if mode == "cells_shift":
        for phase in phases:
            phase.set_refinements({"Cell": True})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        return
    if mode == "zero_cells":
        for phase in phases:
            phase.set_refinements({"Cell": True})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        return
    if mode == "zero_only":
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        return
    if mode == "calibration_joint":
        for phase in phases:
            phase.set_refinements({"Cell": True})
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        hist.set_refinements({"Instrument Parameters": ["Zero"]})
        return
    if mode == "instrument":
        hist.set_refinements(
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
        )
        return
    if mode == "polarization":
        project.set_Controls("parmMin", 0.5, variable=":0:Polariz.")
        project.set_Controls("parmMax", 1.0, variable=":0:Polariz.")
        hist.set_refinements({"Instrument Parameters": ["Polariz."]})
        return
    if mode == "size":
        for phase in phases:
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}, [hist]
            )
        return
    if mode == "strain":
        for phase in phases:
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
        return
    if mode in {"strain_current0", "strain_current1"}:
        pidx = int(mode[-1])
        hap = phases[pidx].getHAPvalues(hist.name)
        if hap["Mustrain"][0] == "uniaxial":
            hap["Mustrain"][2][0] = True
            hap["Mustrain"][2][1] = True
        elif hap["Mustrain"][0] == "isotropic":
            hap["Mustrain"][2][0] = True
        else:
            raise RuntimeError("current-strain mode supports isotropic/uniaxial only")
        return
    if mode == "heavy":
        for phase in phases:
            for atom in phase.atoms():
                if atom.element in {"W", "Ca"}:
                    atom.refinement_flags = "X"
        return
    if mode == "light_cawo4":
        for atom in phases[0].atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
        return
    if mode == "light_wo3":
        for atom in phases[1].atoms():
            if atom.element == "O":
                atom.refinement_flags = "X"
        return
    if mode == "light_wo3_bounded":
        # Powder intensities weakly constrain the many oxygen coordinates in
        # monoclinic WO3. Limit each one-step fractional displacement to a
        # chemically modest range, then screen the resulting octahedra.
        project.save()
        project.index_ids()
        for index, atom in enumerate(phases[1].atoms()):
            if atom.element != "O":
                continue
            atom.refinement_flags = "X"
            for axis, coordinate in zip("xyz", atom.coordinates):
                variable = f"1::dA{axis}:{index}"
                project.set_Controls(
                    "parmMin", float(coordinate) - 0.008, variable=variable
                )
                project.set_Controls(
                    "parmMax", float(coordinate) + 0.008, variable=variable
                )
        return
    if mode == "light_all":
        for phase in phases:
            for atom in phase.atoms():
                if atom.element == "O":
                    atom.refinement_flags = "X"
        return
    if mode == "uiso_common":
        # The specimen model assigns one physical Uiso per phase. Equivalence
        # constraints retain that interpretation while allowing each phase to
        # have a different value.
        project.save()
        project.index_ids()
        existing = project.get_Constraints("Phase")
        if existing:
            raise RuntimeError("uiso_common expects a checkpoint without phase constraints")
        for pidx, phase in enumerate(phases):
            atoms = phase.atoms()
            if not all(atom.adp_flag == "I" for atom in atoms):
                raise RuntimeError(f"anisotropic ADP found in {phase.name}")
            for atom in atoms:
                atom.refinement_flags = "U"
            variables = [f"{pidx}::AUiso:{i}" for i in range(len(atoms))]
            for variable in variables:
                project.set_Controls("parmMin", 0.001, variable=variable)
                project.set_Controls("parmMax", 0.03, variable=variable)
            if len(variables) > 1:
                project.add_EquivConstr(variables, reloadIdx=False)
        return
    if mode == "uiso_existing":
        if not project.get_Constraints("Phase"):
            raise RuntimeError("uiso_existing requires existing phase constraints")
        for phase in phases:
            for atom in phase.atoms():
                if atom.adp_flag != "I":
                    raise RuntimeError(f"anisotropic ADP found in {phase.name}")
                atom.refinement_flags = "U"
        return
    if mode == "surface":
        # Nonzero starts are required because the roughness function can have
        # a flat derivative at exactly zero.
        if hist.SampleParameters["SurfRoughA"][0] <= 0:
            hist.SampleParameters["SurfRoughA"][0] = 0.10
        if hist.SampleParameters["SurfRoughB"][0] <= 0:
            hist.SampleParameters["SurfRoughB"][0] = 0.05
        project.set_Controls("parmMin", 0.05, variable=":0:SurfRoughA")
        project.set_Controls("parmMax", 0.60, variable=":0:SurfRoughA")
        project.set_Controls("parmMin", 0.02, variable=":0:SurfRoughB")
        project.set_Controls("parmMax", 0.50, variable=":0:SurfRoughB")
        hist.set_refinements(
            {"Sample Parameters": ["SurfRoughA", "SurfRoughB"]}
        )
        return
    if mode.startswith("texture"):
        # texture{phase-index}_{h}_{k}_{l}
        prefix, *axis_bits = mode.split("_")
        pidx = int(prefix.removeprefix("texture"))
        axis = [int(v) for v in axis_bits]
        if len(axis) != 3:
            raise ValueError(f"invalid texture mode {mode!r}")
        hap = phases[pidx].getHAPvalues(hist.name)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][3] = axis
        project.set_Controls("parmMin", 0.7, variable=f"{pidx}:0:MD")
        project.set_Controls("parmMax", 1.4, variable=f"{pidx}:0:MD")
        phases[pidx].set_HAP_refinements({"Pref.Ori.": True}, [hist])
        return
    if mode.startswith("strain") and "_axis_" in mode:
        # strain{phase-index}_axis_{h}_{k}_{l}
        left, axis_text = mode.split("_axis_", 1)
        pidx = int(left.removeprefix("strain"))
        axis = parse_axis(axis_text)
        for suffix in ("i", "a"):
            project.set_Controls(
                "parmMin", 0.0, variable=f"{pidx}:0:Mustrain;{suffix}"
            )
            project.set_Controls(
                "parmMax", 12000.0, variable=f"{pidx}:0:Mustrain;{suffix}"
            )
        phases[pidx].set_HAP_refinements(
            {
                "Mustrain": {
                    "type": "uniaxial",
                    "direction": axis,
                    "refine": True,
                }
            },
            [hist],
        )
        return
    if mode == "joint_core":
        for phase in phases:
            phase.set_refinements({"Cell": True})
            phase.set_HAP_refinements(
                {"Size": {"type": "isotropic", "refine": True}}, [hist]
            )
            phase.set_HAP_refinements(
                {"Mustrain": {"type": "isotropic", "refine": True}}, [hist]
            )
        hist.set_refinements({"Sample Parameters": ["Shift"]})
        hist.set_refinements(
            {"Instrument Parameters": ["U", "W", "X", "SH/L"]}
        )
        return
    raise ValueError(f"unknown refinement mode {mode!r}")


def state(project: G2.G2Project, mode: str) -> dict:
    hist = project.histogram(0)
    phases = []
    weighted = []
    for phase in project.phases():
        hap = phase.getHAPvalues(hist.name)
        mass_scale = float(phase.data["General"]["Mass"]) * float(hap["Scale"][0])
        weighted.append(max(0.0, mass_scale))
        phases.append(
            {
                "name": phase.name,
                "cell": phase.get_cell(),
                "scale": hap["Scale"][0],
                "size": copy.deepcopy(hap["Size"]),
                "mustrain": copy.deepcopy(hap["Mustrain"]),
                "preferred_orientation": copy.deepcopy(hap["Pref.Ori."]),
                "atoms": [
                    {
                        "label": atom.label,
                        "element": atom.element,
                        "xyz": list(atom.coordinates),
                        "uiso": atom.ADP,
                    }
                    for atom in phase.atoms()
                ],
            }
        )
    total = sum(weighted)
    for phase, value in zip(phases, weighted):
        phase["weight_fraction"] = value / total
    return {
        "mode": mode,
        "residuals": hist.residuals,
        "sample": copy.deepcopy(hist.SampleParameters),
        "instrument": copy.deepcopy(hist.InstrumentParameters),
        "background": copy.deepcopy(hist.Background),
        "phases": phases,
        "vary_list": project.get_VaryList(),
    }


def main(start: Path, output: Path, modes: list[str]) -> None:
    G2.SetPrintLevel("warn")
    output.parent.mkdir(parents=True, exist_ok=True)
    project = G2.G2Project(str(start.resolve()), newgpx=str(output.resolve()))
    project.save()
    log = [state(project, "start")]
    for mode in modes:
        requested_mode = mode
        single_pass = mode.endswith("_once")
        if single_pass:
            mode = mode.removesuffix("_once")
        configure(project, mode)
        project.set_Controls("cycles", 15)
        passes = 1 if mode.endswith("_bounded") or single_pass else 2
        for _ in range(passes):
            project.refine()
        current = state(project, requested_mode)
        rwp = current["residuals"].get("wR")
        if rwp is None or not math.isfinite(float(rwp)):
            raise RuntimeError(f"non-finite Rwp after {mode}")
        log.append(current)
        project.save()
        checkpoint = output.with_name(
            f"{output.stem}_{requested_mode}{output.suffix}"
        )
        shutil.copy2(output, checkpoint)
        print(
            requested_mode,
            f"Rwp={float(rwp):.6f}",
            "fractions=" + ",".join(
                f"{p['weight_fraction']:.6f}" for p in current["phases"]
            ),
            flush=True,
        )
    output.with_suffix(".json").write_text(json.dumps(log, indent=2) + "\n")


if __name__ == "__main__":
    if len(sys.argv) != 4:
        raise SystemExit(
            "usage: refine_steps.py START.gpx OUTPUT.gpx MODE[,MODE...]"
        )
    main(Path(sys.argv[1]), Path(sys.argv[2]), sys.argv[3].split(","))
