#!/usr/bin/env python3
"""Continue from the last replay-consistent three-phase GSAS-II state."""

from pathlib import Path
import json
import sys

from GSASII import GSASIIscriptable as G2


def clear_limits(gpx):
    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}


def fix_common(gpx):
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        phase.set_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": True})
    return hist


def summary(gpx, label):
    hist = gpx.histogram(0)
    row = {
        "label": label,
        "Rwp": hist.get_wR(),
        "mass_fractions": {k: v[0] for k, v in hist.ComputeMassFracs().items()},
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "sizes": {p.name: p.data["Histograms"][hist.name]["Size"][1][0] for p in gpx.phases()},
        "strain": {p.name: p.data["Histograms"][hist.name]["Mustrain"][1][0] for p in gpx.phases()},
        "scale": {p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in gpx.phases()},
        "instrument": {k: v[1] for k, v in hist.InstrumentParameters.items() if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: (v[0] if isinstance(v, list) else v) for k, v in hist.SampleParameters.items() if k in ("Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius")},
    }
    print(json.dumps(row), flush=True)
    return row


def main():
    source = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(source), newgpx=str(output))
    hist = fix_common(gpx)
    clear_limits(gpx)
    phases = gpx.phases()
    # The minor calcite width is weakly determined; keep it at a physical
    # 0.10 um while refining the two phases with many independent peaks.
    phases[0].data["Histograms"][hist.name]["Size"][1][0] = 0.10
    phases[1].data["Histograms"][hist.name]["Size"][1][0] = 0.30
    phases[2].data["Histograms"][hist.name]["Size"][1][0] = 0.10
    phases[0].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    phases[1].set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
    gpx.set_Controls("cycles", 8)
    gpx.refine(makeBack=False)
    rows = [summary(gpx, "sizes")]
    gpx.save()
    # A fresh zero-cycle replay is mandatory; this catches clamped or stale
    # calculated arrays before the project can be considered for submission.
    gpx.set_Controls("cycles", 0)
    gpx.refine(makeBack=False)
    rows.append(summary(gpx, "sizes_replay"))
    gpx.save()
    output.with_suffix(".summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
