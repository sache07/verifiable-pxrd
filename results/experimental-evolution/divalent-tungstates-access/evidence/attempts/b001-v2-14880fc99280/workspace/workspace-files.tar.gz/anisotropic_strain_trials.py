#!/usr/bin/env python3
"""Test uniaxial microstrain models in an otherwise fixed multiphase state."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ((0, 0, 1), (1, 0, 0), (0, 1, 0))


def clear_flags(gpx: G2.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Instrument Parameters": list(hist.InstrumentParameters),
    })
    hist.clear_refinements({
        "Sample Parameters": [
            k for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and len(v) > 1
        ],
    })
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True,
        })
        cx, ct, cs, cia = phase.data["General"]["AtomPtrs"]
        for atom in phase.data["Atoms"]:
            atom[ct + 1] = " "


def main() -> None:
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for pidx in range(3):
        for axis in AXES:
            tag = f"p{pidx}_{axis[0]}{axis[1]}{axis[2]}"
            output = outdir / f"{tag}.gpx"
            gpx = G2.G2Project(str(source), newgpx=str(output))
            clear_flags(gpx)
            hist = gpx.histogram(0)
            phase = gpx.phase(pidx)
            mustrain = phase.data["Histograms"][hist.name]["Mustrain"]
            iso = float(mustrain[1][0])
            mustrain[1][0] = iso
            mustrain[1][1] = iso
            phase.set_HAP_refinements({
                "Mustrain": {
                    "type": "uniaxial", "direction": axis,
                    "refine": True,
                }
            })
            controls = gpx.data["Controls"]["data"]
            controls["parmMinDict"] = {}
            controls["parmMaxDict"] = {}
            controls["parmFrozen"] = {}
            gpx.set_Controls("parmMin", 300.0, f"{pidx}:0:Mustrain;i")
            gpx.set_Controls("parmMax", 8000.0, f"{pidx}:0:Mustrain;i")
            gpx.set_Controls("parmMin", 300.0, f"{pidx}:0:Mustrain;a")
            gpx.set_Controls("parmMax", 8000.0, f"{pidx}:0:Mustrain;a")
            gpx.set_Controls("cycles", 8)
            gpx.refine(makeBack=False)
            # A zero-cycle replay guards against stale curves after bounds handling.
            phase.clear_HAP_refinements({"Mustrain": True})
            gpx.set_Controls("cycles", 0)
            gpx.refine(makeBack=False)
            vals = phase.data["Histograms"][hist.name]["Mustrain"][1]
            row = {
                "phase_index": pidx,
                "phase": phase.name,
                "axis": list(axis),
                "equatorial": vals[0],
                "axial": vals[1],
                "Rwp_percent": hist.get_wR(),
            }
            rows.append(row)
            print(json.dumps(row), flush=True)
            gpx.save()
    (outdir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
