#!/usr/bin/env python3
"""Refine common and phase profile terms one at a time with replay checkpoints."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2


def clear_all(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        p.set_refinements({"Cell": False})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.set_HAP_refinements({"Scale": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    h.set_refinements({"Background": True})
    c = gpx.data["Controls"]["data"]
    c["parmMinDict"] = {}
    c["parmMaxDict"] = {}
    c["parmFrozen"] = {}
    gpx.set_Controls("cycles", 5)
    return h


def state(gpx, label):
    h = gpx.histogram(0)
    row = {
        "label": label, "Rwp": h.get_wR(),
        "instrument": {k: h.InstrumentParameters[k][1] for k in ("U", "V", "W", "X", "Y", "SH/L")},
        "size": [p.data["Histograms"][h.name]["Size"][1][0] for p in gpx.phases()],
        "strain": [p.data["Histograms"][h.name]["Mustrain"][1][0] for p in gpx.phases()],
    }
    print(json.dumps(row), flush=True)
    return row


def run(gpx, output, label):
    gpx.refine(makeBack=False)
    row = state(gpx, label)
    gpx.save()
    shutil.copy2(output, output.with_suffix(f".{label}.gpx"))
    return row


def main():
    source, output = map(lambda x: Path(x).resolve(), sys.argv[1:3])
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(source), newgpx=str(output))
    h = clear_all(gpx)
    rows = []
    for key in ("SH/L", "W", "X", "U"):
        h.set_refinements({"Instrument Parameters": [key]})
        rows.append(run(gpx, output, "inst_" + key.replace("/", "")))
        h.clear_refinements({"Instrument Parameters": [key]})
    for i, p in enumerate(gpx.phases()):
        p.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        rows.append(run(gpx, output, f"size_{i}"))
        p.clear_HAP_refinements({"Size": True})
    for i, p in enumerate(gpx.phases()):
        p.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        rows.append(run(gpx, output, f"strain_{i}"))
        p.clear_HAP_refinements({"Mustrain": True})
    gpx.set_Controls("cycles", 0)
    rows.append(run(gpx, output, "replay"))
    output.with_suffix(".summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
