#!/usr/bin/env python3
"""Final common-state Uiso sensitivity after coordinate refinement."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "polarization.gpx"
OUT = ROOT / ".tmp" / "uiso_final"
BASE = [0.012, 0.009, 0.020]
GRIDS = [[0.010, 0.011, 0.012, 0.013, 0.014],
         [0.005, 0.008, 0.011, 0.014],
         [0.012, 0.016, 0.020]]


def configure(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        p.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.set_HAP_refinements({"Scale": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    h.set_refinements({"Background": True})
    c = gpx.data["Controls"]["data"]
    c["parmMinDict"] = {}; c["parmMaxDict"] = {}; c["parmFrozen"] = {}
    gpx.set_Controls("cycles", 5)
    return h


def set_uiso(phase, value):
    cia = phase.data["General"]["AtomPtrs"][3]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"; atom[cia + 1] = float(value); atom[cia + 2:cia + 8] = [0.0] * 6


def main():
    G2.SetPrintLevel("error"); OUT.mkdir(parents=True, exist_ok=True)
    tests = [(None, None, BASE.copy())]
    for pidx, grid in enumerate(GRIDS):
        for value in grid:
            vals = BASE.copy(); vals[pidx] = value; tests.append((pidx, value, vals))
    rows = []
    for index, (pidx, value, values) in enumerate(tests):
        dst = OUT / f"final_{index:02d}.gpx"; shutil.copy2(SOURCE, dst)
        gpx = G2.G2Project(str(dst)); h = configure(gpx)
        for p, u in zip(gpx.phases(), values): set_uiso(p, u)
        gpx.refine(makeBack=False); gpx.save()
        row = {"index": index, "phase_index": pidx, "tested_value": value,
               "values": values, "Rwp": h.get_wR()}
        rows.append(row); print(json.dumps(row), flush=True)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__": main()
