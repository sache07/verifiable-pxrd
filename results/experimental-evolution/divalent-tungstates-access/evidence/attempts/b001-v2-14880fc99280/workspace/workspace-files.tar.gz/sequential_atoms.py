#!/usr/bin/env python3
"""Refine symmetry-allowed coordinates in scattering-power order."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2


def configure(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        p.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.set_HAP_refinements({"Scale": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    h.set_refinements({"Background": True})
    c = gpx.data["Controls"]["data"]
    c["parmMinDict"] = {}
    c["parmMaxDict"] = {}
    c["parmFrozen"] = {}
    gpx.set_Controls("cycles", 7)
    return h


def snapshot(gpx, label):
    h = gpx.histogram(0)
    row = {"label": label, "Rwp": h.get_wR(), "coordinates": {
        p.name: {a.label: list(a.coordinates) for a in p.atoms()} for p in gpx.phases()}}
    print(json.dumps(row), flush=True)
    return row


def run(gpx, output, label):
    gpx.refine(makeBack=False)
    row = snapshot(gpx, label)
    gpx.save()
    shutil.copy2(output, output.with_suffix(f".{label}.gpx"))
    return row


def set_elements(phase, elements):
    phase.set_refinements({"Atoms": {a.label: "X" for a in phase.atoms() if a.element in elements}})


def clear_atoms(phase):
    phase.set_refinements({"Atoms": {"all": " "}})


def main():
    source, output = map(lambda x: Path(x).resolve(), sys.argv[1:3])
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(source), newgpx=str(output))
    configure(gpx)
    rows = []
    phases = gpx.phases()
    set_elements(phases[0], {"O"})
    rows.append(run(gpx, output, "cawo4_O"))
    clear_atoms(phases[0])
    set_elements(phases[1], {"W"})
    rows.append(run(gpx, output, "wo3_W"))
    clear_atoms(phases[1])
    set_elements(phases[1], {"O"})
    rows.append(run(gpx, output, "wo3_O"))
    clear_atoms(phases[1])
    set_elements(phases[2], {"O"})
    rows.append(run(gpx, output, "calcite_O"))
    clear_atoms(phases[2])
    gpx.set_Controls("cycles", 0)
    rows.append(run(gpx, output, "replay"))
    output.with_suffix(".summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
