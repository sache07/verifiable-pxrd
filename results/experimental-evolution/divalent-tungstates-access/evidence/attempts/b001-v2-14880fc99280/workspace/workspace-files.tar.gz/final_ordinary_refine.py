#!/usr/bin/env python3
"""Final coordinate-descent refinement from a physical saved checkpoint."""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def configure(gpx: G2.G2Project):
    hist = gpx.histogram(0)
    hist.clear_refinements({"Instrument Parameters": list(hist.InstrumentParameters)})
    hist.clear_refinements({
        "Sample Parameters": [
            k for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and len(v) > 1
        ]
    })
    hist.set_refinements({"Background": True})
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_HAP_refinements({
            "Size": True, "Mustrain": True, "Pref.Ori.": True,
            "HStrain": True,
        })
        phase.set_HAP_refinements({"Scale": True})
    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    gpx.set_Controls("cycles", 7)
    return hist


def snapshot(gpx: G2.G2Project, label: str) -> dict:
    h = gpx.histogram(0)
    return {
        "label": label,
        "Rwp_percent": h.get_wR(),
        "U": h.InstrumentParameters["U"][1],
        "W": h.InstrumentParameters["W"][1],
        "X": h.InstrumentParameters["X"][1],
        "SH/L": h.InstrumentParameters["SH/L"][1],
        "polarization": h.InstrumentParameters["Polariz."][1],
        "shift_um": h.SampleParameters["Shift"][0],
        "sizes_um": [p.data["Histograms"][h.name]["Size"][1][0] for p in gpx.phases()],
        "microstrain": [p.data["Histograms"][h.name]["Mustrain"][1][0] for p in gpx.phases()],
    }


def run(gpx: G2.G2Project, output: Path, label: str, rows: list[dict]) -> None:
    gpx.refine(makeBack=False)
    row = snapshot(gpx, label)
    print(json.dumps(row), flush=True)
    rows.append(row)
    gpx.save()
    shutil.copy2(output, output.with_suffix(f".{label}.gpx"))


def main() -> None:
    source, output = map(lambda p: Path(p).resolve(), sys.argv[1:3])
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(source), newgpx=str(output))
    hist = configure(gpx)
    rows = []
    for i, phase in enumerate(gpx.phases()):
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "refine": True}})
        run(gpx, output, f"size_{i}", rows)
        phase.clear_HAP_refinements({"Size": True})
    for i, phase in enumerate(gpx.phases()):
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
        run(gpx, output, f"strain_{i}", rows)
        phase.clear_HAP_refinements({"Mustrain": True})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(gpx, output, "shift", rows)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    hist.set_refinements({"Instrument Parameters": ["Polariz."]})
    run(gpx, output, "polarization", rows)
    hist.clear_refinements({"Instrument Parameters": ["Polariz."]})
    gpx.set_Controls("cycles", 0)
    run(gpx, output, "replay", rows)
    output.with_suffix(".summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
