#!/usr/bin/env python3
"""Compare physically allowed surface-roughness states from one GSAS-II project."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "physical_sizes.gpx"
OUT = ROOT / ".tmp" / "roughness"


def configure(gpx, a, b):
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        phase.set_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": True})
    hist.SampleParameters["SurfRoughA"] = [a, False]
    hist.SampleParameters["SurfRoughB"] = [b, False]
    gpx.data["Controls"]["data"].get("parmFrozen", {}).clear()
    gpx.set_Controls("cycles", 6)


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    grid = [(0.0, 0.0), (0.10, 0.02), (0.10, 0.08), (0.10, 0.20),
            (0.25, 0.02), (0.25, 0.08), (0.25, 0.20), (0.50, 0.02),
            (0.50, 0.08), (0.50, 0.20), (0.50, 0.40)]
    rows = []
    for i, (a, b) in enumerate(grid):
        dst = OUT / f"rough_{i:02d}.gpx"
        shutil.copy2(SOURCE, dst)
        gpx = G2.G2Project(str(dst))
        configure(gpx, a, b)
        gpx.refine(makeBack=False)
        gpx.save()
        hist = gpx.histogram(0)
        row = {"index": i, "A": a, "B": b, "Rwp": hist.get_wR(),
               "mass_fractions": {k: v[0] for k, v in hist.ComputeMassFracs().items()}}
        rows.append(row)
        print(json.dumps(row), flush=True)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
