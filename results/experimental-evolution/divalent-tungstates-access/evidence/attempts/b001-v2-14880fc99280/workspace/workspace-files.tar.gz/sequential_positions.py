#!/usr/bin/env python3
"""Refine common displacement and phase metrics sequentially to avoid correlations."""

from pathlib import Path
import json
import shutil
import sys

from GSASII import GSASIIscriptable as G2


def clear_all(gpx):
    hist = gpx.histogram(0)
    for phase in gpx.phases():
        phase.set_refinements({"Cell": False})
        phase.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        phase.set_HAP_refinements({"Scale": True})
    hist.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    hist.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    hist.set_refinements({"Background": True})
    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    gpx.set_Controls("cycles", 6)
    return hist


def state(gpx, label):
    h = gpx.histogram(0)
    vals = [p.data["General"]["Cell"][1:7] for p in gpx.phases()]
    row = {"label": label, "Rwp": h.get_wR(), "shift_um": h.SampleParameters["Shift"][0],
           "zero_deg": h.InstrumentParameters["Zero"][1], "cells": vals}
    print(json.dumps(row), flush=True)
    return row


def run_step(gpx, output, label):
    gpx.refine(makeBack=False)
    row = state(gpx, label)
    gpx.save()
    shutil.copy2(output, output.with_suffix(f".{label}.gpx"))
    return row


def main():
    source, output = map(lambda x: Path(x).resolve(), sys.argv[1:3])
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(source), newgpx=str(output))
    hist = clear_all(gpx)
    rows = []
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    rows.append(run_step(gpx, output, "shift"))
    hist.clear_refinements({"Sample Parameters": ["Shift"]})
    for i, phase in enumerate(gpx.phases()):
        phase.set_refinements({"Cell": True})
        rows.append(run_step(gpx, output, f"cell_{i}"))
        phase.set_refinements({"Cell": False})
    gpx.set_Controls("cycles", 0)
    rows.append(run_step(gpx, output, "replay"))
    output.with_suffix(".summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
