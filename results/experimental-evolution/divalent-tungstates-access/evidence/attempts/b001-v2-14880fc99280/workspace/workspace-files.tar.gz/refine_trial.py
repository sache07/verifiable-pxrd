#!/usr/bin/env python3
"""Build and refine joint GSAS-II trial projects for the supplied pattern."""

from __future__ import annotations

import argparse
import copy
import csv
import json
import math
import shutil
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def prepare_data() -> tuple[Path, Path]:
    xye = ROOT / ".tmp" / "pattern.xye"
    inst = ROOT / ".tmp" / "instrument.instprm"
    xye.parent.mkdir(parents=True, exist_ok=True)
    with (ROOT / "inputs" / "pattern.csv").open(newline="") as src, xye.open("w") as dst:
        rows = csv.DictReader(src)
        for row in rows:
            y = float(row["intensity"])
            dst.write(f'{float(row["two_theta_deg"]):.8f} {y:.8f} {math.sqrt(max(y, 1.0)):.8f}\n')
    inst.write_text(
        "# GSAS-II Cu Kalpha Bragg-Brentano starting profile\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.75;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )
    return xye, inst


def snap(gpx: G2.G2Project, label: str) -> dict:
    hist = gpx.histogram(0)
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    out = {
        "label": label,
        "wR_percent": hist.get_wR(),
        "R_percent": hist.residuals.get("R"),
        "cells": {p.name: p.get_cell() for p in gpx.phases()},
        "scales": {p.name: p.data["Histograms"][hist.name]["Scale"][0] for p in gpx.phases()},
        "size": {p.name: p.data["Histograms"][hist.name]["Size"] for p in gpx.phases()},
        "mustrain": {p.name: p.data["Histograms"][hist.name]["Mustrain"] for p in gpx.phases()},
        "pref_ori": {p.name: p.data["Histograms"][hist.name]["Pref.Ori."] for p in gpx.phases()},
        "instrument": {k: v for k, v in inst.items() if k in ("Zero", "Polariz.", "U", "V", "W", "X", "Y", "Z", "SH/L")},
        "sample": {k: sample.get(k) for k in ("Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type")},
        "background": hist.Background,
        "vary_list": gpx.get_VaryList(),
    }
    print(json.dumps(out, default=lambda x: np.asarray(x).tolist()))
    return out


def refine_once(gpx: G2.G2Project, label: str, log: list[dict]) -> None:
    gpx.refine(makeBack=False)
    log.append(copy.deepcopy(snap(gpx, label)))
    primary = Path(gpx.filename)
    checkpoint = primary.with_suffix(f".{label}.gpx")
    gpx.save()
    shutil.copy2(primary, checkpoint)


def build(cawo4_id: str, wo3_id: str, calcite_id: str | None, output: Path) -> None:
    G2.SetPrintLevel("warn")
    xye, instfile = prepare_data()
    gpx = G2.G2Project(newgpx=str(output))
    hist = gpx.add_powder_histogram(str(xye), str(instfile), fmthint="xye")
    ca = gpx.add_phase(str(cod_path(cawo4_id)), phasename=f"CaWO4_{cawo4_id}", histograms=[hist], fmthint="CIF")
    wo = gpx.add_phase(str(cod_path(wo3_id)), phasename=f"WO3_{wo3_id}", histograms=[hist], fmthint="CIF")
    phases = [(ca, 0.03, 0.10, (0, 2)), (wo, 0.01, 0.30, (0, 1, 2, 4))]
    if calcite_id:
        calcite = gpx.add_phase(str(cod_path(calcite_id)), phasename=f"CaCO3_{calcite_id}", histograms=[hist], fmthint="CIF")
        phases.append((calcite, 0.005, 0.30, (0, 2)))
    hist.Limits("lower", 9.90343322)
    hist.Limits("upper", 100.09455322)
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Shift"] = [550.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.25, False]
    hist.SampleParameters["SurfRoughB"] = [0.08, False]
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.set_refinements({
        "Background": {
            "type": "chebyschev-1",
            "no. coeffs": 12,
            "coeffs": [1000.0] + [0.0] * 11,
            "refine": True,
        }
    })
    for phase, value, size, _ in phases:
        hap = phase.data["Histograms"][hist.name]
        hap["Scale"] = [value, True]
        hap["Size"][0] = "isotropic"
        hap["Size"][1][0] = size
        hap["Size"][2] = [False, False, False]
        hap["Mustrain"][0] = "isotropic"
        hap["Mustrain"][1][0] = 1000.0
        hap["Mustrain"][1][1] = 1000.0
        hap["Mustrain"][2] = [False, False, False]
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
    gpx.set_Controls("cycles", 8)
    bounds = {
        ":0:Zero": (-0.25, 0.25),
        ":0:Shift": (-800.0, 800.0),
        ":0:U": (0.0, 40.0),
        ":0:W": (2.0, 40.0),
        ":0:X": (0.1, 6.0),
        ":0:SH/L": (0.005, 0.10),
        ":0:Polariz.": (0.5, 1.0),
    }
    for pidx in range(len(phases)):
        bounds[f"{pidx}:0:Size;i"] = (0.04, 1.5)
        bounds[f"{pidx}:0:Mustrain;i"] = (0.0, 8000.0)
        bounds[f"{pidx}:0:Scale"] = (1e-8, 1e4)
    # Keep metric changes within a generous envelope around the reference.
    for pidx, (phase, _, _, indices) in enumerate(phases):
        avec = G2lat.cell2A(phase.data["General"]["Cell"][1:7])
        for idx in indices:
            lo, hi = sorted((avec[idx] * 0.97, avec[idx] * 1.03))
            bounds[f"{pidx}::A{idx}"] = (lo, hi)
    for variable, (lo, hi) in bounds.items():
        gpx.set_Controls("parmMin", lo, variable)
        gpx.set_Controls("parmMax", hi, variable)
    log: list[dict] = []
    refine_once(gpx, "background_scales", log)

    hist.set_refinements({"Sample Parameters": ["Shift"]})
    refine_once(gpx, "common_shift", log)

    for phase, _, _, _ in phases:
        phase.set_refinements({"Cell": True})
    refine_once(gpx, "cells", log)

    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    refine_once(gpx, "zero", log)

    for phase, _, size, _ in phases:
        phase.set_HAP_refinements({"Size": {"type": "isotropic", "value": size, "refine": True}})
    refine_once(gpx, "sizes", log)

    hist.set_refinements({"Instrument Parameters": ["W", "X", "SH/L"]})
    refine_once(gpx, "instrument_W_X_SHL", log)

    # Re-optimize phase broadening after establishing the common profile.
    gpx.data["Controls"]["data"].get("parmFrozen", {}).clear()
    refine_once(gpx, "sizes_released", log)

    for phase, _, _, _ in phases:
        phase.set_HAP_refinements({"Mustrain": {"type": "isotropic", "refine": True}})
    refine_once(gpx, "isotropic_strain", log)

    hist.set_refinements({"Instrument Parameters": ["U", "Polariz."]})
    refine_once(gpx, "U_polarization", log)
    gpx.save()
    output.with_suffix(".log.json").write_text(json.dumps(log, indent=2, default=lambda x: np.asarray(x).tolist()) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cawo4", default="7219229")
    parser.add_argument("--wo3", default="2311041")
    parser.add_argument("--calcite")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    build(args.cawo4, args.wo3, args.calcite, args.output.resolve())


if __name__ == "__main__":
    main()
