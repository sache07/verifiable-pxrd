#!/usr/bin/env python3
"""Replay the selected physical state and create the requested deliverables."""

from __future__ import annotations

import csv
import json
import math
import sys
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PHASE_OUTPUTS = (
    ("scheelite calcium tungstate", "CaWO4", "phase_1_CaWO4.cif"),
    ("monoclinic tungsten trioxide", "WO3", "phase_2_WO3.cif"),
    ("calcite", "CaCO3", "phase_3_CaCO3.cif"),
)


def clear_all_flags(gpx: G2.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({
        "Instrument Parameters": [
            "Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."
        ]
    })
    hist.clear_refinements({
        "Sample Parameters": [
            "Scale", "Absorption", "DisplaceX", "DisplaceY", "Shift",
            "Transparency", "SurfRoughA", "SurfRoughB",
        ]
    })
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True})
        phase.set_refinements({"Atoms": {"all": " "}})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True,
            "Babinet": ["BabA", "BabU"],
            "Extinction": True,
        })
    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}


def main() -> None:
    source = Path(sys.argv[1]).resolve()
    final_gpx = ROOT / "final.gpx"
    G2.SetPrintLevel("warn")
    gpx = G2.G2Project(str(source), newgpx=str(final_gpx))
    clear_all_flags(gpx)
    hist = gpx.histogram(0)

    with (ROOT / "inputs" / "pattern.csv").open(newline="") as stream:
        input_rows = list(csv.DictReader(stream))
    input_x = np.array([float(r["two_theta_deg"]) for r in input_rows])
    input_y = np.array([float(r["intensity"]) for r in input_rows])
    hist.Limits("lower", float(input_x[0]))
    hist.Limits("upper", float(input_x[-1]))
    gpx.set_Controls("cycles", 0)
    gpx.refine(makeBack=False)
    gpx.save()

    arrays = hist.data["data"][1]
    x, yobs, weights, ycalc, yback, ydiff = [np.asarray(v, dtype=float) for v in arrays[:6]]
    if len(x) != len(input_x) or not np.allclose(x, input_x, rtol=0, atol=1e-8):
        raise RuntimeError("Final project does not replay the complete supplied grid")
    if not np.allclose(yobs, input_y, rtol=0, atol=1e-8):
        raise RuntimeError("Final project observed intensities differ from the supplied data")
    if not np.allclose(ydiff, yobs - ycalc, rtol=0, atol=1e-8):
        raise RuntimeError("Stored difference profile is inconsistent")
    if np.min(ycalc) <= 0 or np.min(yback) <= 0:
        raise RuntimeError("Final calculated profile or background is non-positive")

    masses_scales = []
    for phase in gpx.phases():
        hap = phase.data["Histograms"][hist.name]
        masses_scales.append(float(phase.data["General"]["Mass"]) * float(hap["Scale"][0]))
    fractions = np.asarray(masses_scales) / np.sum(masses_scales)

    phase_rows = []
    for idx, (phase, spec, fraction) in enumerate(zip(gpx.phases(), PHASE_OUTPUTS, fractions)):
        common_name, formula, cif_name = spec
        phase.export_CIF(str(ROOT / cif_name))
        cell = phase.get_cell()
        phase_rows.append({
            "name": common_name,
            "formula": formula,
            "space_group": phase.data["General"]["SGData"]["SpGrp"],
            "cif_path": cif_name,
            "weight_fraction": float(fraction),
            "weight_percent": float(100.0 * fraction),
            "unit_cell": {k: float(v) for k, v in cell.items()},
        })

    with (ROOT / "fit.csv").open("w", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow([
            "two_theta", "observed", "calculated", "difference",
        ])
        writer.writerows(zip(x, yobs, ycalc, ydiff))

    residuals = hist.residuals
    weighted_ss = float(np.sum(weights * ydiff * ydiff))
    poisson_floor = float(residuals["wRmin"])
    rwp = float(hist.get_wR())
    stats = {
        "Rwp_percent": rwp,
        "Rp_percent": float(residuals["R"]),
        "background_Rwp_percent": float(residuals["wRb"]),
        "poisson_Rwp_floor_percent": poisson_floor,
        "Rwp_over_poisson_floor": rwp / poisson_floor,
        "chi_square_per_point": weighted_ss / len(x),
        "weighted_residual_sum_squares": weighted_ss,
        "number_of_points": int(len(x)),
        "two_theta_range_deg": [float(x[0]), float(x[-1])],
    }
    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": stats,
        "profile_path": "fit.csv",
        "gsasii_project_path": "final.gpx",
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
