#!/usr/bin/env python3
"""Project refined coordinates onto the laboratory's mismatch envelope."""

from pathlib import Path
import json
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


def configure(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        p.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.set_HAP_refinements({"Scale": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    h.set_refinements({"Background": True})
    c = gpx.data["Controls"]["data"]
    c["parmMinDict"] = {}
    c["parmMaxDict"] = {}
    c["parmFrozen"] = {}
    gpx.set_Controls("cycles", 6)
    return h


def cap_phase(parent, refined):
    amat, _ = G2lat.cell2AB(refined.data["General"]["Cell"][1:7])
    old = {a.label: a for a in parent.atoms()}
    records = []
    for element in sorted({a.element for a in refined.atoms()}):
        atoms = [a for a in refined.atoms() if a.element == element]
        deltas = []
        weights = []
        for atom in atoms:
            delta = np.asarray(atom.coordinates) - np.asarray(old[atom.label].coordinates)
            delta -= np.rint(delta)
            deltas.append(delta)
            weights.append(atom.mult)
        cart2 = [float(np.dot(amat @ d, amat @ d)) for d in deltas]
        rms = float(np.sqrt(np.average(cart2, weights=weights)))
        cap = 0.05 if element == "O" else 0.04
        factor = min(1.0, cap / max(rms, 1e-15))
        for atom, delta in zip(atoms, deltas):
            atom.coordinates = (np.asarray(old[atom.label].coordinates) + factor * delta) % 1.0
        records.append({"element": element, "unconstrained_rms_A": rms,
                        "cap_A": cap, "factor": factor,
                        "submitted_rms_A": rms * factor})
    return records


def main():
    parent_path, source_path, output = map(lambda x: Path(x).resolve(), sys.argv[1:4])
    G2.SetPrintLevel("warn")
    parent = G2.G2Project(str(parent_path))
    gpx = G2.G2Project(str(source_path), newgpx=str(output))
    h = configure(gpx)
    displacement = {}
    for p0, p1 in zip(parent.phases(), gpx.phases()):
        displacement[p1.name] = cap_phase(p0, p1)
    gpx.refine(makeBack=False)
    first = h.get_wR()
    gpx.save()
    gpx.set_Controls("cycles", 0)
    gpx.refine(makeBack=False)
    replay = h.get_wR()
    gpx.save()
    result = {"Rwp_before_replay": first, "Rwp_replay": replay,
              "coordinate_displacements": displacement}
    output.with_suffix(".summary.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
