#!/usr/bin/env python3
"""Common-state replacement tests for alternative crystallographic references."""

from __future__ import annotations

import copy
import json
import sys
import traceback
from pathlib import Path

from GSASII import GSASIIscriptable as G2


COD = Path("<HOME>/.local/share/characterizagent/backends/dara/cod-filtered-2024/cif")
TRIALS = (
    (0, "5910088"),
    (0, "1546035"),
    (1, "1528915"),
    (1, "2106293"),
    (1, "1010618"),
    (2, "1547370"),
)


def cod_path(cod_id: str) -> Path:
    return COD / cod_id[0] / cod_id[1:3] / cod_id[3:5] / f"{cod_id}.cif"


def clear_flags(gpx: G2.G2Project) -> None:
    hist = gpx.histogram(0)
    hist.clear_refinements({"Background": True})
    hist.clear_refinements({"Instrument Parameters": list(hist.InstrumentParameters)})
    hist.clear_refinements({
        "Sample Parameters": [
            k for k, v in hist.SampleParameters.items()
            if isinstance(v, list) and len(v) > 1
        ]
    })
    for phase in gpx.phases():
        phase.clear_refinements({"Cell": True})
        phase.clear_HAP_refinements({
            "Scale": True, "Size": True, "Mustrain": True,
            "Pref.Ori.": True, "HStrain": True,
        })
        ct = phase.data["General"]["AtomPtrs"][1]
        for atom in phase.data["Atoms"]:
            atom[ct + 1] = " "


def normalize_isotropic_adps(phase: G2.G2Phase, uiso: float) -> None:
    ct = phase.data["General"]["AtomPtrs"][1]
    cia = phase.data["General"]["AtomPtrs"][3]
    for atom in phase.data["Atoms"]:
        atom[ct + 1] = " "
        atom[cia] = "I"
        atom[cia + 1] = float(uiso)
        for idx in range(cia + 2, min(cia + 8, len(atom) - 1)):
            atom[idx] = 0.0


def run_trial(source: Path, outdir: Path, target_idx: int, cod_id: str) -> dict:
    tag = f"replace_p{target_idx}_{cod_id}"
    output = outdir / f"{tag}.gpx"
    gpx = G2.G2Project(str(source), newgpx=str(output))
    clear_flags(gpx)
    hist = gpx.histogram(0)
    old = gpx.phase(target_idx)
    old_hap = copy.deepcopy(old.data["Histograms"][hist.name])
    old.data["Histograms"][hist.name]["Use"] = False
    old.clear_HAP_refinements({"Scale": True})
    target_uiso = float(old.data["Atoms"][0][old.data["General"]["AtomPtrs"][3] + 1])

    candidate = gpx.add_phase(
        str(cod_path(cod_id)), phasename=f"trial_{cod_id}",
        histograms=[hist], fmthint="CIF",
    )
    # Keep the candidate's symmetry-dependent HStrain/generalized arrays.
    # Transfer only settings whose definitions are common across symmetries.
    candidate_hap = candidate.data["Histograms"][hist.name]
    candidate_hap["Use"] = True
    candidate_hap["Scale"] = copy.deepcopy(old_hap["Scale"])
    for key in ("Size", "Mustrain"):
        candidate_hap[key][0] = old_hap[key][0]
        candidate_hap[key][1] = copy.deepcopy(old_hap[key][1])
        candidate_hap[key][2] = [False] * len(candidate_hap[key][2])
        candidate_hap[key][3] = copy.deepcopy(old_hap[key][3])
    candidate_hap["Pref.Ori."] = copy.deepcopy(old_hap["Pref.Ori."])
    candidate_hap["Pref.Ori."][2] = False
    normalize_isotropic_adps(candidate, target_uiso)
    candidate.set_HAP_refinements({"Scale": True})

    controls = gpx.data["Controls"]["data"]
    controls["parmMinDict"] = {}
    controls["parmMaxDict"] = {}
    controls["parmFrozen"] = {}
    gpx.set_Controls("parmMin", 1e-10, f"{candidate.id}:0:Scale")
    gpx.set_Controls("cycles", 8)
    gpx.refine(makeBack=False)
    scale_only = hist.get_wR()

    candidate.set_refinements({"Cell": True})
    gpx.refine(makeBack=False)
    cell_scale = hist.get_wR()

    candidate.clear_refinements({"Cell": True})
    candidate.clear_HAP_refinements({"Scale": True})
    gpx.data["Controls"]["data"]["parmFrozen"] = {}
    gpx.set_Controls("cycles", 0)
    gpx.refine(makeBack=False)
    row = {
        "status": "completed",
        "target_index": target_idx,
        "replaced_phase": old.name,
        "candidate_cod_id": cod_id,
        "candidate_space_group": candidate.data["General"]["SGData"]["SpGrp"],
        "candidate_cell": candidate.get_cell(),
        "candidate_scale": candidate.data["Histograms"][hist.name]["Scale"][0],
        "Rwp_scale_only_percent": scale_only,
        "Rwp_cell_scale_percent": cell_scale,
        "Rwp_replay_percent": hist.get_wR(),
    }
    gpx.save()
    return row


def main() -> None:
    source = Path(sys.argv[1]).resolve()
    outdir = Path(sys.argv[2]).resolve()
    outdir.mkdir(parents=True, exist_ok=True)
    G2.SetPrintLevel("warn")
    rows = []
    for target_idx, cod_id in TRIALS:
        try:
            row = run_trial(source, outdir, target_idx, cod_id)
        except Exception as exc:
            row = {
                "status": "unknown_trial_failed",
                "target_index": target_idx,
                "candidate_cod_id": cod_id,
                "error": f"{type(exc).__name__}: {exc}",
                "traceback": traceback.format_exc(),
            }
        rows.append(row)
        print(json.dumps(row), flush=True)
    (outdir / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
