#!/usr/bin/env python3
"""Common-state March-Dollase tests for each allowed phase/axis combination."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "profiled.gpx"
OUT = ROOT / ".tmp" / "po_trials"
AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def configure(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        p.set_refinements({"Cell": False})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.set_HAP_refinements({"Scale": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    h.set_refinements({"Background": True})
    c = gpx.data["Controls"]["data"]
    c["parmMinDict"] = {}
    c["parmMaxDict"] = {}
    c["parmFrozen"] = {}
    gpx.set_Controls("cycles", 6)
    return h


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    for pidx in range(3):
        for aidx, axis in enumerate(AXES):
            dst = OUT / f"po_p{pidx}_a{aidx}.gpx"
            shutil.copy2(SOURCE, dst)
            gpx = G2.G2Project(str(dst))
            h = configure(gpx)
            p = gpx.phases()[pidx]
            hap = p.data["Histograms"][h.name]
            hap["Pref.Ori."][0] = "MD"
            hap["Pref.Ori."][1] = 1.0
            hap["Pref.Ori."][3] = list(axis)
            p.set_HAP_refinements({"Pref.Ori.": True})
            gpx.refine(makeBack=False)
            gpx.save()
            row = {"phase_index": pidx, "phase": p.name, "axis": axis,
                   "ratio": hap["Pref.Ori."][1], "Rwp": h.get_wR()}
            rows.append(row)
            print(json.dumps(row), flush=True)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
