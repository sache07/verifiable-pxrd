#!/usr/bin/env python3
"""Test the generator's per-phase common-isotropic ADP convention."""

from pathlib import Path
import json
import shutil

from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / ".tmp" / "profiled.gpx"
OUT = ROOT / ".tmp" / "uiso_trials"
VALUES = (0.003, 0.005, 0.008, 0.012, 0.016, 0.020)


def configure(gpx):
    h = gpx.histogram(0)
    for p in gpx.phases():
        p.set_refinements({"Cell": False, "Atoms": {"all": " "}})
        p.clear_HAP_refinements({"Size": True, "Mustrain": True, "Pref.Ori.": True})
        p.set_HAP_refinements({"Scale": True})
    h.clear_refinements({"Instrument Parameters": ["Zero", "U", "V", "W", "X", "Y", "Z", "SH/L", "Polariz."]})
    h.clear_refinements({"Sample Parameters": ["Shift", "Transparency", "SurfRoughA", "SurfRoughB"]})
    h.set_refinements({"Background": True})
    c = gpx.data["Controls"]["data"]
    c["parmMinDict"] = {}
    c["parmMaxDict"] = {}
    c["parmFrozen"] = {}
    gpx.set_Controls("cycles", 5)
    return h


def set_phase_uiso(phase, value):
    cia = phase.data["General"]["AtomPtrs"][3]
    for atom in phase.data["Atoms"]:
        atom[cia] = "I"
        atom[cia + 1] = float(value)
        atom[cia + 2:cia + 8] = [0.0] * 6


def main():
    G2.SetPrintLevel("error")
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    tests = [(None, 0.005)] + [(p, u) for p in range(3) for u in VALUES]
    for index, (pidx, value) in enumerate(tests):
        dst = OUT / f"uiso_{index:02d}.gpx"
        shutil.copy2(SOURCE, dst)
        gpx = G2.G2Project(str(dst))
        h = configure(gpx)
        values = [0.005, 0.005, 0.005]
        if pidx is not None:
            values[pidx] = value
        for p, u in zip(gpx.phases(), values):
            set_phase_uiso(p, u)
        gpx.refine(makeBack=False)
        gpx.save()
        row = {"index": index, "phase_index": pidx, "tested_value": value,
               "values": values, "Rwp": h.get_wR()}
        rows.append(row)
        print(json.dumps(row), flush=True)
    (OUT / "summary.json").write_text(json.dumps(rows, indent=2) + "\n")


if __name__ == "__main__":
    main()
