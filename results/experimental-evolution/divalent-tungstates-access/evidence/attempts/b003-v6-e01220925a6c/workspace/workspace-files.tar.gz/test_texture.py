#!/usr/bin/env python3
"""Test physical March-Dollase axes one phase at a time from a checkpoint."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0], [1, 1, 0], [1, 1, 1])


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def fractions(project: G2.G2Project) -> dict[str, float]:
    vals = project.histograms()[0].ComputeMassFracs()
    return {name: float(value[0]) for name, value in vals.items()}


def branch(source: Path, out: Path, phase_index: int, axis: list[int]) -> dict:
    project = G2.G2Project(gpxfile=str(source), newgpx=str(out))
    clear_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    hap["Pref.Ori."][0] = "MD"
    hap["Pref.Ori."][1] = 1.0
    hap["Pref.Ori."][2] = True
    hap["Pref.Ori."][3] = list(axis)
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.7, variable=f"{pid}:0:MD")
    project.set_Controls("parmMax", 1.4, variable=f"{pid}:0:MD")
    project.set_Controls("cycles", 10)
    project.save()
    project.refine(makeBack=False)
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": axis,
        "ratio": float(hap["Pref.Ori."][1]),
        "Rwp_percent": float(hist.get_wR()),
        "fractions": fractions(project),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "output": str(out),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--phase", type=int, action="append")
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    probe = G2.G2Project(gpxfile=str(source))
    indices = args.phase if args.phase is not None else list(range(len(probe.phases())))
    records = []
    for phase_index in indices:
        for axis in AXES:
            tag = "".join(str(v) for v in axis)
            out = args.outdir / f"phase{phase_index}_axis{tag}.gpx"
            try:
                record = branch(source, out, phase_index, list(axis))
            except Exception as exc:
                record = {
                    "phase_index": phase_index,
                    "axis": axis,
                    "status": "failed",
                    "error": str(exc),
                    "output": str(out),
                }
            records.append(record)
            print(json.dumps(record), flush=True)
    (args.outdir / "texture_tests.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
