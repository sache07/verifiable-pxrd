#!/usr/bin/env python3
"""Test the laboratory's supported uniaxial microstrain axes phasewise."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_texture import clear_flags


AXES = ([0, 0, 1], [1, 0, 0], [0, 1, 0])


def branch(
    source: Path, out: Path, phase_index: int, axis: list[int], axial_max: float
) -> dict:
    project = G2.G2Project(gpxfile=str(source), newgpx=str(out))
    clear_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        if abs(float(hap["Pref.Ori."][1]) - 1.0) > 0.03:
            phase.set_HAP_refinements({"Pref.Ori.": True})
    phase = project.phases()[phase_index]
    hap = phase.data["Histograms"][hist.name]
    strain = max(float(hap["Mustrain"][1][0]), 100.0)
    phase.setSampleProfile(hist, "microstrain", "uniaxial", strain, strain, axis)
    phase.set_HAP_refinements(
        {
            "Mustrain": {
                "type": "uniaxial",
                "direction": list(axis),
                "refine": True,
            }
        }
    )
    pid = phase.data["pId"]
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
    project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;a")
    project.set_Controls("parmMax", axial_max, variable=f"{pid}:0:Mustrain;a")
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "phase_index": phase_index,
        "phase": phase.name,
        "axis": axis,
        "equatorial_ppm": float(hap["Mustrain"][1][0]),
        "axial_ppm": float(hap["Mustrain"][1][1]),
        "Rwp_percent": float(hist.get_wR()),
        "fractions": {k: float(v[0]) for k, v in hist.ComputeMassFracs().items()},
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "output": str(out),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("outdir", type=Path)
    parser.add_argument("--phase", type=int, action="append")
    parser.add_argument("--axial-max", type=float, default=8000.0)
    args = parser.parse_args()
    args.outdir.mkdir(parents=True, exist_ok=True)
    source = args.source.resolve()
    probe = G2.G2Project(gpxfile=str(source))
    indices = args.phase if args.phase is not None else list(range(len(probe.phases())))
    records = []
    for phase_index in indices:
        for axis in AXES:
            tag = "".join(str(v) for v in axis)
            out = args.outdir / f"phase{phase_index}_axis{tag}.gpx"
            try:
                record = branch(
                    source, out.resolve(), phase_index, list(axis), args.axial_max
                )
            except Exception as exc:
                record = {
                    "phase_index": phase_index,
                    "axis": axis,
                    "status": "failed",
                    "error": str(exc),
                    "output": str(out),
                }
            records.append(record)
            print(json.dumps(record), flush=True)
    (args.outdir / "uniaxial_tests.json").write_text(json.dumps(records, indent=2) + "\n")


if __name__ == "__main__":
    main()
