#!/usr/bin/env python3
"""Compare the staged-polish selection against its physical checkpoint."""

from __future__ import annotations

import json
import math
import sys

import numpy as np
from GSASII import GSASIIscriptable as G2


def lattice_matrix(cell: dict) -> np.ndarray:
    a, b, c = (float(cell[f"length_{axis}"]) for axis in "abc")
    alpha, beta, gamma = (
        math.radians(float(cell[f"angle_{name}"]))
        for name in ("alpha", "beta", "gamma")
    )
    avec = np.array([a, 0.0, 0.0])
    bvec = np.array([b * math.cos(gamma), b * math.sin(gamma), 0.0])
    cx = c * math.cos(beta)
    cy = c * (math.cos(alpha) - math.cos(beta) * math.cos(gamma)) / math.sin(gamma)
    cz = math.sqrt(max(c * c - cx * cx - cy * cy, 0.0))
    return np.array([avec, bvec, np.array([cx, cy, cz])])


def phase_record(source, branch):
    source_cell = source.get_cell()
    branch_cell = branch.get_cell()
    matrix = lattice_matrix(source_cell)
    shifts = []
    for old, new in zip(source.atoms(), branch.atoms()):
        delta = np.asarray(new.coordinates, dtype=float) - np.asarray(old.coordinates, dtype=float)
        delta -= np.rint(delta)
        distance = float(np.linalg.norm(delta @ matrix))
        shifts.append({"label": new.label, "element": new.element, "shift_A": distance})
    return {
        "space_group": branch.data["General"]["SGData"]["SpGrp"],
        "source_cell": source_cell,
        "branch_cell": branch_cell,
        "maximum_atom_shift_A": max(row["shift_A"] for row in shifts),
        "atom_shifts": shifts,
        "short_distances": [list(item) for item in branch.ShortDistances(useAll=False)],
        "uiso_A2": [float(atom.uiso) for atom in branch.atoms()],
    }


def main() -> None:
    source = G2.G2Project(gpxfile=sys.argv[1])
    branch = G2.G2Project(gpxfile=sys.argv[2])
    source_phases = {phase.name: phase for phase in source.phases()}
    hist = branch.histograms()[0]
    rvals = branch.data.get("Covariance", {}).get("data", {}).get("Rvals", {})
    report = {
        "Rwp_percent": float(hist.get_wR()),
        "fractions": {name: float(value[0]) for name, value in hist.ComputeMassFracs().items()},
        "converged": rvals.get("converged"),
        "max_shift_esd": rvals.get("Max shft/sig"),
        "frozen": [str(item) for item in branch.get_Frozen()],
        "phases": {
            phase.name: phase_record(source_phases[phase.name], phase)
            for phase in branch.phases()
        },
    }
    print(json.dumps(report, indent=2, default=str))


if __name__ == "__main__":
    main()
