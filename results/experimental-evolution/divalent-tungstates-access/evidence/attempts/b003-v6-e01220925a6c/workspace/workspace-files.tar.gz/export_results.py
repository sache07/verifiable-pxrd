#!/usr/bin/env python3
"""Export all submitted artifacts from the accepted final GSAS-II project."""

from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path

import numpy as np
from GSASII import GSASIIscriptable as G2


ROOT = Path(__file__).resolve().parent
PROJECT = ROOT / "final.gpx"
PATTERN = ROOT / "inputs" / "pattern.csv"
REPLAY_DIR = ROOT / ".tmp" / "replay_final"
PREDICTION = REPLAY_DIR / "prediction.npz"
REPLAY_REPORT = REPLAY_DIR / "replay.json"

PHASE_INFO = {
    "MnWO4": {
        "formula": "MnWO4",
        "cif_path": "phase_MnWO4.cif",
        "reference": "COD 1520200",
    },
    "Mn3WO6": {
        "formula": "Mn3WO6",
        "cif_path": "phase_Mn3WO6.cif",
        "reference": "COD 2002703",
    },
    "WO3": {
        "formula": "WO3",
        "cif_path": "phase_WO3.cif",
        "reference": "COD 2311041",
    },
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def finite(value):
    if value is None:
        return None
    value = float(value)
    return value if np.isfinite(value) else None


def main() -> None:
    project_hash = sha256(PROJECT)
    replay = json.loads(REPLAY_REPORT.read_text())
    if replay.get("status") != "replayed":
        raise RuntimeError(f"independent replay failed: {replay}")
    if replay.get("project_sha256") != project_hash:
        raise RuntimeError("prediction was not generated from the submitted final.gpx")

    prediction = np.load(PREDICTION)
    x = np.asarray(prediction["x"], dtype=float)
    observed = np.asarray(prediction["observed"], dtype=float)
    calculated = np.asarray(prediction["predicted"], dtype=float)
    background = np.asarray(prediction["background"], dtype=float)
    public = np.loadtxt(PATTERN, delimiter=",", skiprows=1, ndmin=2)
    if not (
        x.shape == observed.shape == calculated.shape == background.shape
        and public.shape == (len(x), 2)
        and np.allclose(x, public[:, 0], rtol=0, atol=1e-7)
        and np.allclose(observed, public[:, 1], rtol=0, atol=1e-5)
        and np.all(np.isfinite(calculated))
        and np.all(calculated >= 0)
    ):
        raise RuntimeError("replayed profile does not match the complete input grid")

    difference = observed - calculated
    np.savetxt(
        ROOT / "fit.csv",
        np.column_stack((x, observed, calculated, difference, background)),
        delimiter=",",
        header="two_theta,observed,calculated,difference,background",
        comments="",
        fmt="%.10g",
    )

    project = G2.G2Project(gpxfile=str(PROJECT))
    hist = project.histograms()[0]
    if hist.name != replay.get("histogram"):
        raise RuntimeError("replayed histogram differs from the selected project histogram")
    fractions = hist.ComputeMassFracs()
    fraction_values = {name: float(value[0]) for name, value in fractions.items()}
    if abs(sum(fraction_values.values()) - 1.0) > 1e-10:
        raise RuntimeError("crystalline mass fractions are not normalized")
    replay_fractions = {row["name"]: float(row["weight_fraction"]) for row in replay["phases"]}
    if any(abs(fraction_values[name] - replay_fractions[name]) > 1e-10 for name in fraction_values):
        raise RuntimeError("project and replay mass fractions differ")

    covariance = copy.deepcopy(project.data.get("Covariance", {}).get("data", {}))
    rvals = covariance.get("Rvals", {})
    # Export the full-precision saved atoms rather than any stale covariance
    # parameter vector. This is also the convention used for independent replay.
    project.data.setdefault("Covariance", {})["data"] = {}
    phase_rows = []
    for phase in project.phases():
        info = PHASE_INFO[phase.name]
        output = ROOT / info["cif_path"]
        phase.export_CIF(str(output))
        value, esd = fractions[phase.name]
        phase_rows.append(
            {
                "name": phase.name,
                "formula": info["formula"],
                "space_group": phase.data["General"]["SGData"]["SpGrp"].strip(),
                "cif_path": info["cif_path"],
                "weight_fraction": float(value),
                "weight_fraction_esd": finite(esd),
                "weight_percent": 100.0 * float(value),
                "reference_structure": info["reference"],
            }
        )

    weights = 1.0 / np.maximum(observed, 1.0)
    rwp = 100.0 * np.sqrt(
        np.sum(weights * difference * difference) / np.sum(weights * observed * observed)
    )
    rp = 100.0 * np.sum(np.abs(difference)) / np.sum(observed)
    instrument = hist.InstrumentParameters
    sample = hist.SampleParameters
    result = {
        "phases": phase_rows,
        "fraction_basis": "normalized over the modeled crystalline phases",
        "fit_statistics": {
            "Rwp_percent": float(rwp),
            "Rp_percent": float(rp),
            "GSAS_refinement_interval_Rwp_percent": finite(rvals.get("Rwp")),
            "goodness_of_fit": finite(rvals.get("GOF")),
            "chi_squared": finite(rvals.get("chisq")),
            "observations_in_refinement_interval": int(rvals.get("Nobs", 0)),
            "refined_variables_in_final_settle": int(rvals.get("Nvars", 0)),
        },
        "refinement_histogram": hist.name,
        "profile_path": "fit.csv",
        "project_path": "final.gpx",
        "project_sha256": project_hash,
        "calibration": {
            "zero_deg": float(instrument["Zero"][1]),
            "specimen_shift_micrometre": float(sample["Shift"][0]),
            "wavelength_Kalpha1_A": float(instrument["Lam1"][1]),
            "wavelength_Kalpha2_A": float(instrument["Lam2"][1]),
        },
        "profile_grid": {
            "points": int(len(x)),
            "minimum_two_theta_deg": float(x[0]),
            "maximum_two_theta_deg": float(x[-1]),
        },
    }
    (ROOT / "result.json").write_text(json.dumps(result, indent=2) + "\n")

    if sha256(PROJECT) != project_hash:
        raise RuntimeError("export changed final.gpx")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
