#!/usr/bin/env python3
"""Refine one tied isotropic displacement parameter per crystalline phase."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_texture import clear_flags


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--keep-values", action="store_true")
    args = parser.parse_args()
    project = G2.G2Project(
        gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve())
    )
    G2.SetPrintLevel("warn")
    clear_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True

    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        if abs(float(hap["Pref.Ori."][1]) - 1.0) > 0.03:
            phase.set_HAP_refinements({"Pref.Ori.": True})

        pid = phase.data["pId"]
        variables = []
        for index, atom in enumerate(phase.atoms()):
            # Registered models are normalized to isotropic Uiso=0.005 A^2;
            # the specimen then receives one common phase value in 0.003--0.02.
            if not args.keep_values:
                atom.data[atom.cia] = "I"
                atom.data[atom.cia + 1] = 0.008
            if atom.adp_flag != "I":
                raise RuntimeError(f"{phase.name}:{atom.label} is not isotropic")
            atom.refinement_flags = "U"
            variable = f"{pid}::AUiso:{index}"
            variables.append(variable)
            project.set_Controls("parmMin", 0.003, variable=variable)
            project.set_Controls("parmMax", 0.020, variable=variable)
        if len(variables) > 1 and not args.keep_values:
            project.add_EquivConstr(variables, reloadIdx=True)

    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", 15)
    project.save()
    project.refine(makeBack=False)
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    result = {
        "Rwp_percent": float(hist.get_wR()),
        "fractions": {k: float(v[0]) for k, v in hist.ComputeMassFracs().items()},
        "uiso_A2": {
            phase.name: [float(atom.uiso) for atom in phase.atoms()]
            for phase in project.phases()
        },
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
    }
    args.output.with_suffix(".uiso.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    main()
