#!/usr/bin/env python3
"""Settle all supported non-coordinate terms in a selected GSAS-II model."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2


def clear_flags(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = False
    for value in hist.InstrumentParameters.values():
        if isinstance(value, list) and len(value) > 2:
            value[2] = False
    for value in hist.SampleParameters.values():
        if isinstance(value, list) and len(value) > 1 and isinstance(value[1], bool):
            value[1] = False
    for phase in project.phases():
        phase.set_refinements({"Cell": False, "LeBail": False})
        for atom in phase.atoms():
            atom.refinement_flags = " "
        phase.clear_HAP_refinements(
            {
                "Scale": True,
                "Size": True,
                "Mustrain": True,
                "Pref.Ori.": True,
                "HStrain": True,
                "Extinction": True,
                "Babinet": ["BabA", "BabU"],
            }
        )
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    vals = project.histograms()[0].ComputeMassFracs()
    return {name: float(value[0]) for name, value in vals.items()}


def state(project: G2.G2Project, stage: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "stage": stage,
        "Rwp_percent": float(hist.get_wR()),
        "fractions": mass_fractions(project),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "instrument": {
            k: float(hist.InstrumentParameters[k][1])
            for k in ("Zero", "Polariz.", "U", "V", "W", "X", "SH/L")
        },
        "sample": {
            k: float(hist.SampleParameters[k][0])
            for k in ("Scale", "Shift", "SurfRoughA", "SurfRoughB")
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size_um": float(phase.data["Histograms"][hist.name]["Size"][1][0]),
                "microstrain_ppm": float(phase.data["Histograms"][hist.name]["Mustrain"][1][0]),
                "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
    }


def run(project: G2.G2Project, stage: str, cycles: int, records: list[dict]) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    rec = state(project, stage)
    records.append(rec)
    print(json.dumps(rec, default=str), flush=True)


def enable_core(project: G2.G2Project) -> None:
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_refinements({"Cell": True})
        hap = phase.data["Histograms"][hist.name]
        refs = {
            "Scale": True,
            "Size": {"type": "isotropic", "refine": True},
        }
        if hap["Mustrain"][0] == "uniaxial":
            refs["Mustrain"] = {
                "type": "uniaxial",
                "direction": list(hap["Mustrain"][3]),
                "refine": True,
            }
        elif float(hap["Mustrain"][1][0]) > 1.0:
            refs["Mustrain"] = {"type": "isotropic", "refine": True}
        phase.set_HAP_refinements(refs)
        if abs(float(hap["Pref.Ori."][1]) - 1.0) > 0.03:
            phase.set_HAP_refinements({"Pref.Ori.": True})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    project = G2.G2Project(
        gpxfile=str(args.source.resolve()), newgpx=str(args.output.resolve())
    )
    G2.SetPrintLevel("warn")
    clear_flags(project)
    hist = project.histograms()[0]
    hist.SampleParameters["Scale"] = [1.0, False]
    enable_core(project)
    records: list[dict] = []

    run(project, "core_settle", 15, records)

    hist.set_refinements(
        {"Instrument Parameters": ["Polariz.", "U", "W", "X", "SH/L"]}
    )
    run(project, "instrument_profile", 15, records)

    # Resolve the highly correlated zero/displacement pair sequentially.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run(project, "angular_zero", 10, records)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run(project, "specimen_shift", 10, records)
    hist.clear_refinements({"Sample Parameters": ["Shift"]})

    # Keep any profile parameter that reached a physical boundary at that
    # value, but remove its stale refine flag for a clean final covariance.
    frozen = {str(v) for v in project.get_Frozen()}
    for key in ("U", "W", "X", "SH/L", "Polariz."):
        if f":0:{key}" in frozen:
            hist.InstrumentParameters[key][2] = False
    run(project, "final_noncoordinate_settle", 15, records)

    args.output.with_suffix(".complete.json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )
    project.save(str(args.output.resolve()))


if __name__ == "__main__":
    main()
