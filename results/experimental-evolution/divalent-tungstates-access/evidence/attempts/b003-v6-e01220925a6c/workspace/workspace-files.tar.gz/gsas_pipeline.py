#!/usr/bin/env python3
"""Build and refine a replayable GSAS-II powder project for this specimen.

Run with the GSAS-II Python interpreter.  The script is intentionally kept
case-local: candidate phases are supplied on the command line as
``name=/absolute/path/to/source.cif`` entries.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import shutil

import numpy as np
from GSASII import GSASIIscriptable as G2
from GSASII import GSASIIlattice as G2lat


ROOT = Path(__file__).resolve().parent
PATTERN = ROOT / "inputs" / "pattern.csv"


def instrument_text() -> str:
    return (
        "#GSAS-II Cu Kalpha Bragg-Brentano starting model\n"
        "Type:PXC;Bank:1\n"
        "Lam1:1.540598;Lam2:1.544426;I(L2)/I(L1):0.5\n"
        "Zero:0.0;Polariz.:0.8;Azimuth:0.0\n"
        "U:10.0;V:0.0;W:10.0;X:1.0;Y:0.0;Z:0.0;SH/L:0.03\n"
    )


def prepare_data(work: Path) -> tuple[Path, Path]:
    work.mkdir(parents=True, exist_ok=True)
    inst = work / "instrument.instprm"
    inst.write_text(instrument_text())
    x, y = np.loadtxt(PATTERN, delimiter=",", skiprows=1).T
    sigma = np.sqrt(np.maximum(y, 1.0))
    xye = work / "pattern.xye"
    np.savetxt(xye, np.column_stack((x, y, sigma)), fmt="%.8f %.8f %.8f")
    return xye, inst


def mass_fractions(project: G2.G2Project) -> dict[str, float]:
    hist = project.histograms()[0]
    try:
        values = hist.ComputeMassFracs()
    except Exception:
        values = {}
    if values:
        return {str(k): float(v[0]) for k, v in values.items()}
    weighted = {}
    for phase in project.phases():
        hap = phase.data["Histograms"].get(hist.name)
        if not hap or not hap.get("Use", True):
            continue
        weighted[phase.name] = max(
            0.0,
            float(phase.data["General"].get("Mass", 0.0))
            * float(hap["Scale"][0]),
        )
    total = sum(weighted.values())
    if total <= 0:
        return {name: 0.0 for name in weighted}
    return {name: value / total for name, value in weighted.items()}


def state(project: G2.G2Project, label: str) -> dict:
    hist = project.histograms()[0]
    cov = project.data.get("Covariance", {}).get("data", {})
    inst = hist.InstrumentParameters
    sample = hist.SampleParameters
    return {
        "stage": label,
        "Rwp_percent": None if hist.get_wR() is None else float(hist.get_wR()),
        "GOF": cov.get("Rvals", {}).get("GOF"),
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "fractions": mass_fractions(project),
        "instrument": {
            key: float(inst[key][1])
            for key in ("Lam1", "Lam2", "I(L2)/I(L1)", "Zero", "Polariz.", "U", "V", "W", "X", "Y", "SH/L")
            if key in inst
        },
        "sample": {
            key: (float(value[0]) if isinstance(value, list) else value)
            for key, value in sample.items()
            if key in {"Scale", "Shift", "Transparency", "SurfRoughA", "SurfRoughB", "Gonio. radius", "Type"}
        },
        "phases": {
            phase.name: {
                "cell": phase.get_cell(),
                "scale": float(phase.data["Histograms"][hist.name]["Scale"][0]),
                "size": phase.data["Histograms"][hist.name]["Size"],
                "mustrain": phase.data["Histograms"][hist.name]["Mustrain"],
                "preferred_orientation": phase.data["Histograms"][hist.name]["Pref.Ori."],
            }
            for phase in project.phases()
        },
    }


def run_stage(project: G2.G2Project, label: str, cycles: int, records: list[dict]) -> None:
    project.data["Controls"]["data"]["parmFrozen"] = {"FrozenList": []}
    project.set_Controls("cycles", cycles)
    project.save()
    project.refine(makeBack=False)
    project.save()
    record = state(project, label)
    records.append(record)
    print(json.dumps(record, default=str), flush=True)


def make_project(output: Path, phase_specs: list[str]) -> G2.G2Project:
    work = output.parent / f".{output.stem}_files"
    xye, inst = prepare_data(work)
    project = G2.G2Project(newgpx=str(output))
    phases = []
    for spec in phase_specs:
        name, source = spec.split("=", 1)
        phases.append(
            project.add_phase(
                str(Path(source).resolve()), phasename=name, fmthint="CIF"
            )
        )
    hist = project.add_powder_histogram(
        str(xye), str(inst), phases=phases, fmthint="xye"
    )
    hist.SampleParameters["Type"] = "Bragg-Brentano"
    hist.SampleParameters["Gonio. radius"] = 200.0
    hist.SampleParameters["Scale"] = [1.0, False]
    hist.SampleParameters["Shift"] = [0.0, False]
    hist.SampleParameters["Transparency"] = [0.0, False]
    hist.SampleParameters["SurfRoughA"] = [0.0, False]
    hist.SampleParameters["SurfRoughB"] = [0.0, False]
    hist.set_refinements(
        {
            "Limits": [10.0, 100.0],
            "Background": {
                "type": "chebyschev-1",
                "no. coeffs": 10,
                "coeffs": [3900.0] + [0.0] * 9,
                "refine": False,
            },
        }
    )
    # Start all phases on comparable mass fractions and with realistic broadening.
    for phase in phases:
        hap = phase.data["Histograms"][hist.name]
        mass = float(phase.data["General"]["Mass"])
        hap["Scale"] = [1000.0 / max(mass, 1.0), False]
        phase.setSampleProfile(hist, "size", "isotropic", 0.25, LGmix=1.0)
        phase.setSampleProfile(hist, "microstrain", "isotropic", 1000.0, LGmix=0.0)
        hap["Pref.Ori."][0] = "MD"
        hap["Pref.Ori."][1] = 1.0
        hap["Pref.Ori."][2] = False
        hap["Pref.Ori."][3] = [0, 0, 1]
    project.data["Controls"]["data"]["deriv type"] = "analytic Hessian"
    project.data["Controls"]["data"]["min dM/M"] = 0.0001
    project.save()
    project.index_ids()
    # Bounds are the frozen laboratory's physically available ranges, with a
    # modest cell window around each published reference.
    for variable, low, high in (
        (":0:Zero", -0.25, 0.25),
        (":0:Shift", -800.0, 800.0),
        (":0:U", 0.0, 40.0),
        (":0:W", 2.0, 40.0),
        (":0:X", 0.1, 6.0),
        (":0:SH/L", 0.005, 0.10),
        (":0:Polariz.", 0.5, 1.0),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    for phase in phases:
        pid = phase.data["pId"]
        hap = phase.data["Histograms"][hist.name]
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMax", 200.0, variable=f"{pid}:0:Scale")
        project.set_Controls("parmMin", 0.04, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMax", 1.5, variable=f"{pid}:0:Size;i")
        project.set_Controls("parmMin", 0.0, variable=f"{pid}:0:Mustrain;i")
        project.set_Controls("parmMax", 8000.0, variable=f"{pid}:0:Mustrain;i")
        cell = phase.get_cell()
        reciprocal = G2lat.cell2A(
            [
                cell["length_a"], cell["length_b"], cell["length_c"],
                cell["angle_alpha"], cell["angle_beta"], cell["angle_gamma"],
            ]
        )
        for index, value in enumerate(reciprocal):
            span = max(0.01 * abs(float(value)), 0.0003)
            project.set_Controls("parmMin", float(value) - span, variable=f"{pid}::A{index}")
            project.set_Controls("parmMax", float(value) + span, variable=f"{pid}::A{index}")
    project.save()
    return project


def basic_refine(project: G2.G2Project, records: list[dict]) -> None:
    hist = project.histograms()[0]
    phases = project.phases()

    # Establish the background and positive phase scales first.
    hist.set_refinements({"Background": True})
    for phase in phases:
        phase.set_HAP_refinements({"Scale": True})
    run_stage(project, "background_scales", 8, records)

    # Establish global calibration/specimen displacement before changing cells.
    hist.set_refinements({"Instrument Parameters": ["Zero"]})
    run_stage(project, "zero", 8, records)
    hist.clear_refinements({"Instrument Parameters": ["Zero"]})
    hist.set_refinements({"Sample Parameters": ["Shift"]})
    run_stage(project, "shift", 8, records)

    # Refine unit cells and the ordinary instrumental profile.
    for phase in phases:
        phase.set_refinements({"Cell": True})
    hist.set_refinements({"Instrument Parameters": ["U", "W", "X", "SH/L"]})
    run_stage(project, "cells_instrument", 10, records)

    # Add phase-specific isotropic broadening.
    for phase in phases:
        phase.set_HAP_refinements(
            {
                "Size": {"type": "isotropic", "refine": True},
                "Mustrain": {"type": "isotropic", "refine": True},
            }
        )
    run_stage(project, "isotropic_profiles", 12, records)
    hist.set_refinements({"Instrument Parameters": ["Zero", "Polariz."]})
    run_stage(project, "joint_settle", 12, records)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    parser.add_argument("phases", nargs="*", help="phase_name=/path/to/source.cif")
    parser.add_argument("--resume", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    if args.resume:
        project = G2.G2Project(gpxfile=str(output))
    else:
        if not args.phases:
            raise SystemExit("at least one phase is required")
        project = make_project(output, args.phases)
    G2.SetPrintLevel("warn")
    records: list[dict] = []
    run_stage(project, "initial_calculation", 0, records)
    basic_refine(project, records)
    output.with_suffix(".stages.json").write_text(
        json.dumps(records, indent=2, default=str) + "\n"
    )
    project.save(str(output))


if __name__ == "__main__":
    main()
