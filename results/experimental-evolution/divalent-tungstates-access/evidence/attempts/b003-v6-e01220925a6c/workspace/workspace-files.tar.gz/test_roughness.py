#!/usr/bin/env python3
"""Branch a checkpoint through physically allowed surface-roughness starts."""

from __future__ import annotations

import json
from pathlib import Path

from GSASII import GSASIIscriptable as G2

from test_texture import clear_flags


SOURCE = Path("checkpoint_complete.bak0.gpx").resolve()
OUTDIR = Path("roughness_tests")


def run(start_a: float, start_b: float) -> dict:
    OUTDIR.mkdir(exist_ok=True)
    tag = f"A{start_a:.2f}_B{start_b:.2f}".replace(".", "p")
    out = OUTDIR / f"{tag}.gpx"
    project = G2.G2Project(gpxfile=str(SOURCE), newgpx=str(out.resolve()))
    clear_flags(project)
    hist = project.histograms()[0]
    hist.Background[0][1] = True
    for phase in project.phases():
        phase.set_HAP_refinements({"Scale": True})
        hap = phase.data["Histograms"][hist.name]
        if abs(float(hap["Pref.Ori."][1]) - 1.0) > 0.03:
            phase.set_HAP_refinements({"Pref.Ori.": True})
    hist.SampleParameters["SurfRoughA"] = [start_a, True]
    hist.SampleParameters["SurfRoughB"] = [start_b, True]
    for variable, low, high in (
        (":0:SurfRoughA", 0.05, 0.6),
        (":0:SurfRoughB", 0.02, 0.5),
    ):
        project.set_Controls("parmMin", low, variable=variable)
        project.set_Controls("parmMax", high, variable=variable)
    project.set_Controls("cycles", 12)
    project.save()
    project.refine(makeBack=False)
    project.save()
    cov = project.data.get("Covariance", {}).get("data", {})
    return {
        "start": [start_a, start_b],
        "values": [
            float(hist.SampleParameters["SurfRoughA"][0]),
            float(hist.SampleParameters["SurfRoughB"][0]),
        ],
        "Rwp_percent": float(hist.get_wR()),
        "fractions": {
            k: float(v[0]) for k, v in hist.ComputeMassFracs().items()
        },
        "converged": cov.get("Rvals", {}).get("converged"),
        "max_shift_esd": cov.get("Rvals", {}).get("Max shft/sig"),
        "frozen": [str(v) for v in project.get_Frozen()],
        "output": str(out),
    }


records = []
for values in ((0.10, 0.05), (0.30, 0.10), (0.50, 0.30)):
    try:
        record = run(*values)
    except Exception as exc:
        record = {"start": values, "status": "failed", "error": str(exc)}
    records.append(record)
    print(json.dumps(record), flush=True)
(OUTDIR / "roughness_tests.json").write_text(json.dumps(records, indent=2) + "\n")
